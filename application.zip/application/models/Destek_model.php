<?php
class Destek_model extends CI_Model
{

	public function __construct()
	{
		parent::__construct();
	}

	public function menucek($where = array()){
		return $this->db->where($where)->order_by("kategori_sira DESC")->get("kategori")->result();
	}

    public function tummenucek(){
        return $this->db->order_by("kategori_sira DESC")->get("kategori")->result();
    }

    public function uwucek(){
        return $this->db->where(array('parent' => 0))->order_by("kategori_sira DESC")->get("kategori")->result();
    }

    public function parentcat(){
        return $this->db->where('parent >' , 0)->get("kategori")->result();
    }

    public function populerKategoriOne($where = array()){
        return $this->db->where($where)->order_by("kategori_sira DESC")->limit(10, 1)->get("kategori")->result();
    }

    public function populerKategoriTwo($where = array()){
        return $this->db->where($where)->order_by("kategori_sira DESC")->limit(12, 11)->get("kategori")->result();
    }

    public function blogkategoriler($where = array()){
        return $this->db->where($where)->order_by("kategori_sira DESC")->get("blog_kategori")->result();
    }

	public function kullaniciget($where = array()){
		return $this->db->where($where)->get("kullanici")->row();
	}

	public function yorumcek($where = array()){
		return $this->db->join('kullanici', 'kullanici.kullanici_id = yorum.kullanici_id')->where($where)->order_by("yorum.yorum_id ASC")->get("yorum")->result();
	}

	public function blogcek($where = array()){
		return $this->db->join('blog_kategori', 'blog_kategori.id = blog.blog_kategori_id')->where($where)->order_by("blog_id DESC")->get("blog")->result();
	}
	public function bankacek($where = array()){
		return $this->db->where($where)->order_by("order_no ASC")->get("bank_accounts")->result();
	}

    public function anasayfa_blog($where = array()){
        return $this->db->join('blog_kategori', 'blog_kategori.id = blog.blog_kategori_id')->where($where)->order_by("blog_id DESC")->limit(3)->get("blog")->result();
    }

	public function fmenucek($where = array()){
		return $this->db->where($where)->order_by("kategori_sira ASC")->get("kategori")->result();
	}

	public function sayfacek($where = array()){
		return $this->db->where($where)->order_by("sayfa_sira ASC")->get("sayfa")->result();
	}

	public function fsayfacek($where = array()){
		return $this->db->where($where)->order_by("sayfa_sira ASC")->limit(12)->get("sayfa")->result();
	}

    public function blogsay($where = array())
    {
        $query = $this->db->where($where)->get("blog");
        return $query->num_rows();
    }

	public function detaykategori($where = array()){
		return $this->db->where($where)->get("kategori")->row();
	}

    public function randomKategori($where = array()){
        return $this->db->where($where)->where('kategori_resim_rand is NOT NULL', NULL, FALSE)->where('parent != 0')->order_by('rand()')->limit(2)->get("kategori")->result();
    }

	public function siparissay($where = array())
	{
		$query = $this->db->where($where)->get("siparis");
		return $query->num_rows();
	}

	public function odemesay($where = array())
	{
		$query = $this->db->select_sum("siparis_odeme")->where($where)->get("siparis");
		$result = $query->result();
		return $result[0]->siparis_odeme;
	}
	public function yorumsay($where = array())
	{
		$query = $this->db->where($where)->get("yorum");
		return $query->num_rows();
	}

	public function kategorisay($where = array())
	{
		$query = $this->db->where($where)->get("kategori");
		return $query->num_rows();
	}

	public function sayfalar($where = array()){
		return $this->db->where($where)->order_by("sayfa_sira ASC")->get("sayfa")->result();
	}

    public function sss($where = array()){
        return $this->db->where($where)->get("sss")->result();
    }

	public function kullanicilar($where = array()){
		return $this->db->select('kullanici.*')->join('magaza','kullanici.kullanici_id=magaza.kullanici_id','LEFT')->where($where)->order_by("kullanici.kullanici_id DESC")->get("kullanici")->result();
	}

	public function adminadres($link)
	{
		$link = seo($link);
		if (empty($link)) {
			$link = "admin";
		}
		$start = '<?php defined("BASEPATH") OR exit("No direct script access allowed");' . PHP_EOL;
		$keys = '$custom_slug_array["admin"] = "' . $link . '";';
		$end = '?>';

		$content = $start . $keys . $end;

		file_put_contents(FCPATH . "application/config/route_slugs.php", $content);
	}


    public function ozellikupdate($where = array(), $data = array())
	{
		return $this->db->where($where)->update("kullanici", $data);
	}

	public function yorumupdate($where = array(), $data = array())
	{
		return $this->db->where($where)->update("yorum", $data);
	}

	public function kullaniciupdate($where = array(), $data = array())
	{
		return $this->db->where($where)->update("kullanici", $data);
	}

    public function token_add($data = array())
    {
        return $this->db->insert("token", $data);
    }

    public function token_update($where = array(), $data = array())
    {
        return $this->db->where($where)->update("token", $data);
    }

    public function token($where = array()){
        return $this->db->where($where)->get("token")->row();
    }

    public function token_delete($where = array())
    {
        return $this->db->where($where)->delete("token");
    }

    public function urunara($search)

    {
        $this->db->like('urun_ad', $search);
        $this->db->limit(8);
        $query = $this->db->get('urunler');
        return $query->result();
    }

    public function kategoriara($search)
    {
        $this->db->like('kategori_ad', $search);
        $this->db->where(['parent' => 0]);
        $query = $this->db->get('kategori');
        return $query->result();
    }

    public function slider($where = array()){
        return $this->db->where($where)->order_by("slider_sira ASC")->get("slider")->result();
    }
}
?>