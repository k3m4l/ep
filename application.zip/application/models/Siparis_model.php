<?php

class Siparis_model extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
    }

    public function siparisler($where = array())
    {
        return $this->db->where($where)->join('urunler', 'urunler.urun_id = siparis.urun_id')->join('magaza', 'siparis.magaza = magaza.magaza_id', 'LEFT')->join('kullanici', 'kullanici.kullanici_id = siparis.kullanici_id')->order_by('siparis.siparis_tarih', 'DESC')->get("siparis")->result();
    }
    
    public function satislar($where = array())
    {
        return $this->db->where($where)->join('urunler', 'urunler.urun_id = siparis_satis.urun_id')->join('magaza', 'siparis_satis.magaza = magaza.magaza_id')->join('kullanici', 'kullanici.kullanici_id = siparis_satis.kullanici_id')->order_by('siparis_satis.siparis_tarih', 'DESC')->get("siparis_satis")->result();
    }

    public function siparis_kontrol($where = array())
    {
        return $this->db->where($where)->where('siparis_tarih <= DATE_SUB(CURDATE(), INTERVAL 4 DAY)')->get("siparis")->result();
    }

    public function siparis_5($where = array())
    {
        return $this->db->where($where)->join('urunler', 'urunler.urun_id = siparis.urun_id')->join('kullanici', 'kullanici.kullanici_id = siparis.kullanici_id')->limit(5)->order_by('siparis.siparis_id', 'DESC')->get("siparis")->result();
    }

    public function siparisler_sayfalama($where = array(), $limit, $count)
    {
        return $this->db->where($where)->join('urunler', 'urunler.urun_id = siparis.urun_id')->join('kullanici', 'kullanici.kullanici_id = siparis.kullanici_id')->order_by("siparis.siparis_id DESC")->limit($limit, $count)->get("siparis")->result();
    }

    public function aldigim_ilanlar($where = array(), $limit, $count, $filter)
    {
        error_reporting(E_ALL);
        ini_set("display_errors", 1);

        if (!empty($filter->search)) {
            $this->db->group_start();
            $this->db->like('siparis.siparis_no', $filter->search);
            $this->db->or_like('urunler.urun_ad', $filter->search);
            $this->db->group_end();
        }
        if (!empty($filter->date)) {
            $this->db->like('siparis.siparis_tarih', $filter->date);
        }
        return $this->db->where($where)->join('urunler', 'urunler.urun_id = siparis.urun_id')->join('kullanici', 'kullanici.kullanici_id = siparis.kullanici_id')->order_by("siparis.siparis_id DESC")->limit($limit, $count*$limit)->from("siparis")->get()->result();
    }

    public function aldigim_urunler($where = array(), $limit, $count)
    {
        return $this->db->where($where)->join('urunler', 'urunler.urun_id = siparis.urun_id')->join('kullanici', 'kullanici.kullanici_id = siparis.kullanici_id')->order_by("siparis.siparis_id DESC")->limit($limit, $count*$limit)->get("siparis")->result();
    }

    public function sattigim_ilanlar($where = array(), $limit, $count)
    {
        return $this->db->where($where)->join('urunler', 'urunler.urun_id = siparis.urun_id')->join('kullanici', 'kullanici.kullanici_id = siparis.kullanici_id')->order_by("siparis.siparis_id DESC")->limit($limit, $count*$limit)->get("siparis")->result();
    }

    public function get_selected_siparis($order_id)
    {
        return $this->db->where(['siparis.siparis_id' => $order_id])->join('urunler', 'urunler.urun_id = siparis.urun_id')->join('kullanici', 'kullanici.kullanici_id = siparis.kullanici_id')->get("siparis")->row();
    }

    public function siparisler_satis_sayfalama($where = array(), $limit, $count)
    {
        return $this->db->where($where)->join('urunler', 'urunler.urun_id = siparis_satis.urun_id')->join('kullanici', 'kullanici.kullanici_id = siparis_satis.kullanici_id')->order_by("siparis_satis.siparis_id DESC")->limit($limit, $count)->get("siparis_satis")->result();
    }

    public function siparis($where = array())
    {
        return $this->db->where($where)->join('urunler', 'urunler.urun_id = siparis.urun_id')->join('kullanici', 'kullanici.kullanici_id = siparis.kullanici_id')->join('magaza', 'magaza.magaza_id = urunler.magaza_id', 'LEFT')->get("siparis")->row();
    }
    public function satis($where = array())
    {
        return $this->db->where($where)->join('urunler', 'urunler.urun_id = siparis_satis.urun_id')->join('kullanici', 'kullanici.kullanici_id = siparis_satis.kullanici_id')->join('magaza', 'magaza.magaza_id = urunler.magaza_id')->get("siparis_satis")->row();
    }
    public function siparis_satis($where = array())
    {
        return $this->db->where($where)->join('urunler', 'urunler.urun_id = siparis_satis.urun_id')->join('kullanici', 'kullanici.kullanici_id = siparis_satis.kullanici_id')->join('magaza', 'magaza.magaza_id = urunler.magaza_id')->get("siparis_satis")->row();
    }

    public function satislarim_sayfalama($where = array(), $limit, $count)
    {
        return $this->db->where($where)->where('(siparis.siparis_durum = 1 or siparis.siparis_durum = 2 or siparis.siparis_durum = 3)')->join('urunler', 'urunler.urun_id = siparis.urun_id')->join('kullanici', 'kullanici.kullanici_id = siparis.kullanici_id')->order_by("siparis.siparis_id DESC")->limit($limit, $count)->get("siparis")->result();
    }

    public function siparis_add($data = array())
    {
        return $this->db->insert("siparis", $data);
    }
    
    public function siparis_satis_add($data = array())
    {
        return $this->db->insert("siparis_satis", $data);
    }

    public function siparis_satis_say($where = array())
    {
        $query = $this->db->where($where)->get("siparis_satis");
        return $query->num_rows();
    }

    public function siparis_say($where = array())
    {
        $query = $this->db->where($where)->get("siparis");
        return $query->num_rows();
    }

    public function siparis_update($where = array(), $data = array())
    {
        return $this->db->where($where)->update("siparis", $data);
    }
    public function update_bakiye($where = array(), $data = array())
    {
        return $this->db->where($where)->update("kullanici", $data);
    }
    public function satis_update($where = array(), $data = array())
    {
        return $this->db->where($where)->update("siparis_satis", $data);
    }

    public function siparis_sil($where = array())
    {
        return $this->db->where($where)->delete("siparis");
    }

    public function sehir($id = "")
    {
        return $this->db->where(array('id' => $id))->get('iller')->row();
    }

    public function ilce($id = "")
    {
        return $this->db->where(array('id' => $id))->get('ilceler')->row();
    }

    public function siparis_download($where = array())
    {
        return $this->db->where($where)->where('(siparis.siparis_durum = 1 or siparis.siparis_durum = 2)')->join('urunler', 'urunler.urun_id = siparis.urun_id')->join('kullanici', 'kullanici.kullanici_id = siparis.kullanici_id')->join('magaza', 'magaza.magaza_id = urunler.magaza_id')->get("siparis")->row();
    }


    /**
     * Teslimat Model
     */
    public function teslimat_add($data = array())
    {
        return $this->db->insert("teslimat", $data);
    }

    public function teslimat($id)
    {
        return $this->db->where(array('siparis_no' => $id))->get('teslimat')->row();
        //where('(teslimat_durum = 0 or teslimat_durum = 2)')
    }

    public function get_itiraz_ettiklerim($kullanici_id)
    {
        return $this->db->where(array('teslimat.kullanici_id' => $kullanici_id))->join('siparis', 'teslimat.siparis_no = siparis.siparis_no')->join('urunler', 'urunler.urun_id = siparis.urun_id')->get('teslimat')->result();
    }

    public function teslimat_kontrol($id)
    {
        return $this->db->where(array('siparis_no' => $id))->where('(teslimat_durum = 0 or teslimat_durum = 1)')->get('teslimat')->row();
    }

    public function teslimat_row($where = array())
    {
        return $this->db->where($where)->get('teslimat')->row();
    }

    public function mesajlar($where = array())
    {
        return $this->db->where($where)->join('kullanici', 'mesaj.mesaj_gonderen=kullanici.kullanici_id')->order_by('mesaj.mesaj_id', 'DESC')->get('mesaj')->result();
    }


    /**
     * Mesaj Model
     */
    public function mesaj_add($data = array())
    {
        return $this->db->insert("mesaj", $data);
    }


    /**
     * Yorum Model
     */
    public function yorum_say($where = array())
    {
        $query = $this->db->where($where)->get("yorum");
        return $query->num_rows();
    }

    public function yorum_add($data = array())
    {
        return $this->db->insert("yorum", $data);
    }

    public function yorum($where = array())
    {
        return $this->db->where($where)->get('yorum')->row();
    }

    public function yorumlar($where = array())
    {
        return $this->db->where($where)->join('kullanici', 'yorum.kullanici_id=kullanici.kullanici_id')->get('yorum')->result();
    }

    public function yorum_update($where = array(), $data = array())
    {
        return $this->db->where($where)->update("yorum", $data);
    }

    public function yorumlar_sayfalama($where = array(), $limit, $count)
    {
        return $this->db->where($where)->join('kullanici', 'yorum.kullanici_id=kullanici.kullanici_id')->order_by("yorum.yorum_id DESC")->limit($limit, $count)->get("yorum")->result();
    }

    /**
     * Destek Talepleri
     */

    public function destek_sayfalama($where = array(), $limit, $count)
    {
        return $this->db->where($where)->join('kullanici', 'kullanici.kullanici_id = talep.kullanici_id')->order_by("talep.talep_id", "DESC")->limit($limit, $count)->get("talep")->result();
    }

    public function destek_say($where = array())
    {
        $query = $this->db->where($where)->get("talep");
        return $query->num_rows();
    }

    public function talep_add($data = array())
    {
        return $this->db->insert("talep", $data);
    }

    public function cevap_add($data = array())
    {
        return $this->db->insert("talep_cevap", $data);
    }
    public function talep_update($where = array(), $data = array())
    {
        return $this->db->where($where)->update("talep", $data);
    }

    public function destek($where = array())
    {
        return $this->db->join('kullanici', 'kullanici.kullanici_id = talep.kullanici_id')->where($where)->get('talep')->row();
    }

    public function destekler($where = array())
    {
        return $this->db->where($where)->order_by("talep.talep_id", "DESC")->get('talep')->result();
    }

    public function destek_update($where = array(), $data = array())
    {
        return $this->db->where($where)->update("talep", $data);
    }

    public function talep_sil($where = array())
    {
        return $this->db->where($where)->delete("talep");
    }

    public function yorum_yildiz_toplam($urun_id)
    {
        $this->db->select_sum('yorum_puan');
        $this->db->from('yorum');
        $this->db->where(['yorum_durum' => 1,'urun_id' => $urun_id]);
        $return_query = $this->db->get();
        if($return_query->num_rows() > 0) {
            return $return_query->row();
        } else {
            return [];
        }
    }

    public function magaza_yorum_yildiz_toplam($magaza_id)
    {
        $this->db->select_sum('yorum_puan');
        $this->db->from('yorum');
        $this->db->where(['yorum_durum' => 1,'magaza_id' => $magaza_id]);
        $return_query = $this->db->get();
        if($return_query->num_rows() > 0) {
            return $return_query->row();
        } else {
            return [];
        }
    }

    public function siteye_sattiklarim_getir($where = array())
    {
        $this->db->select('b.*,
            u.urun_alimbaslik, u.urun_resim_min, u.urun_ad, u.urun_alimfiyat,
            k.kullanici_ad,
        ');
        $this->db->from('bize_sat b');
        $this->db->join('urunler u', 'u.urun_id = b.urun_id');
        $this->db->join('kullanici k', 'k.kullanici_id = b.user_id');
        $this->db->where($where);
        $this->db->order_by('id', 'DESC');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result();
        } else {
            return [];
        }
    }

}