<?php
class Home_model extends CI_Model
{

	public $ayarName = "ayarlar";


	public function __construct()
	{
		parent::__construct();
	}

	public function ayarlar()
	{
		return $this->db->where(array("ayar_id" => 1))->get("ayarlar")->row();
	}

	public function get($where = array()){
		return $this->db->where($where)->get($this->ayarName)->row();
	}

	public function firmaadd($data = array()){
		return $this->db->insert("firma", $data);
	}

	public function kullaniciadd($data = array()){
		return $this->db->insert("kullanici", $data);
	}

	public function siparisadd($data = array()){
		return $this->db->insert("siparis", $data);
	}

	public function kategoriler($where = array(), $limit = 1){
		return $this->db->where($where)->order_by("kategori_sira ASC")->limit($limit)->get("kategori")->result();
	}

	public function kategoridetay($where = array()){
		return $this->db->where($where)->order_by("kategori_sira ASC")->get("kategori")->result();
	}

	public function get_records($where = array(), $limit, $count)
	{
		return $this->db->join('kategori', 'kategori.kategori_id = firma.kategori_id')->where($where)->order_by("firma.firma_id DESC")->limit($limit, $count)->get("firma")->result();
	}

	public function get_blog($limit, $count)
	{
		return $this->db->join('blog_kategori', 'blog_kategori.id = blog.blog_kategori_id')->limit($limit, $count)->get("blog")->result();
	}

    public function kategori_get_blog($limit, $count, $id)
    {
        return $this->db->join('blog_kategori', 'blog_kategori.id = blog.blog_kategori_id')->limit($limit, $count)->where('blog_kategori_id =', $id)->get("blog")->result();
    }

	public function kategoricek($where = array()){
		return $this->db->where($where)->get("kategori")->row();
	}

	public function blogcek($where = array()){
		return $this->db->join('blog_kategori', 'blog_kategori.id = blog.blog_kategori_id')->where($where)->get("blog")->row();
	}

    public function limitblogcek($where = array()){
        return $this->db->join('blog_kategori', 'blog_kategori.id = blog.blog_kategori_id')->where($where)->limit(3)->order_by("blog.blog_id DESC")->get("blog")->result();
    }

    public function blogkategoricek($where = array()){
        return $this->db->where($where)->get("blog_kategori")->row();
    }

	public function populerpaket($where = array(), $limit = 1){
		return $this->db->where($where)->order_by("paket_sira ASC")->limit($limit)->get("paket")->result();
	}

	public function slidercek($where = array()) {
    $query = $this->db->where($where)
                      ->order_by("slider_sira", "ASC")
                      ->get("slider");
                      
    return ($query && $query->num_rows() > 0) ? $query->result() : array();
	}

	public function blogana($where = array()){
		return $this->db->where($where)->order_by("blog_id DESC")->limit(3)->get("blog")->result();
	}

	public function firmalar($where = array()){
		return $this->db->join('kategori', 'kategori.kategori_id = firma.kategori_id')->join('kullanici', 'kullanici.kullanici_id = firma.kullanici_id')->where($where)->get("firma")->row();
	}

	public function sayfa($where = array()){
		return $this->db->where($where)->get("sayfa")->row();
	}

	public function aramayap($keyword, $category){
		return $this->db->join('kategori', 'kategori.kategori_id = firma.kategori_id')->join('kullanici', 'kullanici.kullanici_id = firma.kullanici_id')->group_start()->like(array('firma.firma_ad' => $keyword, 'kategori.kategori_ad' => $category))->group_end()->where(array("firma_durum" => 1))->order_by("firma_id DESC")->get("firma")->result();

	}

	public function siparisler($where = array()){
		return $this->db->where($where)->get("siparis")->row();
	}

	public function kuponlar($where = array()){
		return $this->db->where($where)->get("kupon")->row();
	}

	public function kuponguncelle($where = array(), $data = array())
	{
		return $this->db->where($where)->update("kupon", $data);
	}

	public function siparisguncelle($where = array(), $data = array())
	{
		return $this->db->where($where)->update("siparis", $data);
	}

	public function odeme_bildirimi_olustur($data) {
		$insert = $this->db->insert("balance_upload_request", $data);
		return $insert ? $this->db->insert_id():false;
	}
	public function uyelik_olustur($email){
		$getUserData = $this->db->where(array("email" => $email))->get("musteriler")->row();
		if(!$getUserData){
			$insert = $this->db->insert("musteriler",array(
				"email" => $email,
				"tarih" => time()
			));


			if($insert)
				return $this->db->insert_id();
			else
				return false;
		}

		return $getUserData->id;

	}
	function basvuru_durum($id) {
		return $this->db->where('kullanici_id',$id)->get('bayi_basvuru')->row(); 
	}
	function basvuru_olustur($data) {
		$insert = $this->db->insert("bayi_basvuru",$data);
		if($insert)
			return $this->db->insert_id();
		else
			return false;
	}

    public function get_onaylanacak_siparisler()
    {
        $sql = "SELECT siparis.*, urunler.*
                    FROM siparis
                    INNER JOIN urunler ON siparis.urun_id = urunler.urun_id
                    WHERE siparis.siparis_tarih <= DATE_SUB(NOW(), INTERVAL 24 HOUR)
                    AND siparis.siparis_durum = 1;";
        $query = $this->db->query($sql);
        return $query->result();
    }

    public function siparis_teslimat_control($siparis_no)
    {
        return $this->db->where(['siparis_no' => $siparis_no])->get('teslimat')->row();
    }

    public function get_banka($id)
    {
        $this->db->from('bank_accounts');
        $this->db->where(['id' => $id]);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->row();
        } else {
            return false;
        }
    }

    public function sorular_cek($urun_id)
    {
        $this->db->from('sorular');
        $this->db->where(['urun_id' => $urun_id, 'soru_durum' => 1, 'cevap' => 0]);
        $this->db->order_by('soru_id', 'ASC');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result();
        } else {
            return false;
        }
    }

    public function control_soru($id)
    {
        $this->db->from('sorular');
        $this->db->where(['soru_id' => $id]);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return true;
        } else {
            return false;
        }
    }

    public function get_category_filter($kategori_id)
    {
        $this->db->from('filtreler');
        $this->db->where(['kategori_id' => $kategori_id, 'filtre_durum' => 1, 'sub_filter' => 0]);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result();
        } else {
            return false;
        }
    }
    
    public function get_sub_filters($filter_id) 
    {
        $this->db->from('filtreler');
        $this->db->where(['filtre_durum' => 1, 'sub_filter' => $filter_id]);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result();
        } else {
            return false;
        }
    }

    public function get_filter_ozellik($filtre_id)
    {
        $this->db->from('filtre_ozellikler');
        $this->db->where(['durum' => 1, 'filtre_id' => $filtre_id]);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result();
        } else {
            return false;
        }
    }

    public function update_dogrulama_kod($id, $kod)
    {
        $this->db->set(['tel_dogrulama_kod' => $kod, 'tel_dogrulama_kod_tarih' => date('Y-m-d H:i:s')])->where(['kullanici_id' => $id])->update('kullanici');
        if ($this->db->affected_rows() > 0) {
            return true;
        } else {
            return false;
        }
    }

    public function tel_code_control($kod, $user_id)
    {
        $this->db->from('kullanici');
        $this->db->where(['kullanici_id' => $user_id, 'tel_dogrulama_kod' => $kod, 'tel_dogrulama' => 0]);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->row();
        } else {
            return false;
        }
    }

    public function update_tel_dogrulama($user_id)
    {
        $this->db->set(['tel_dogrulama' => 1, 'tel_dogrulama_kod' => ''])->where(['kullanici_id' => $user_id])->update('kullanici');
        if ($this->db->affected_rows() > 0) {
            return true;
        } else {
            return false;
        }
    }

    public function get_pvp_servers()
    {
        $this->db->from('pvp_servers');
        $this->db->order_by('sira', 'ASC');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result();
        } else {
            return [];
        }
    }

    public function get_urun($urun)
    {
        $this->db->from('urunler');
        $this->db->where(['urun_id' => $urun, 'urun_durum' => 1]);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->row();
        } else {
            return [];
        }
    }

    public function get_excel_users()
    {
        $this->db->select('kullanici_id, kullanici_ad, kullanici_tel');
        $this->db->from('kullanici');
        $this->db->where(['kullanici_durum' => 1]);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result();
        } else {
            return [];
        }
    }

    public function bizesatadd($data = array()){
        return $this->db->insert("bize_sat", $data);
    }
    
    public function control_bize_sat($user_id)
    {
        $this->db->from('bize_sat');
        $this->db->where(['deleted' => 0, 'user_id' => $user_id, 'status' => 0]);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return true;
        } else {
            return false;
        }
    }

    public function vitrinler($where = array()) {
    try {
        // Tablo var mı kontrol et
        if (!$this->db->table_exists('vitrinler')) {
            return array();
        }
        
        // Sorguyu çalıştır
        $query = $this->db->where($where)
                         ->order_by('sira', 'ASC')
                         ->get('vitrinler');
                         
        // Sorgu başarılı mı ve veri var mı kontrol et
        if ($query && $query->num_rows() > 0) {
            return $query->result();
        }
        
        return array();
        
    } catch (Exception $e) {
        log_message('error', 'Vitrinler sorgu hatası: ' . $e->getMessage());
        return array();
    }
	}

    public function selected_user($id)
    {
        $this->db->from('kullanici');
        $this->db->where(['id' => $id]);
        $query = $this->db->get();
        if ($query->num_rows () > 0) {
            return $query->row();
        } else {
            return [];
        }
    }

    public function get_comments_by_product_ids($product_ids, $limit, $offset) {
        $limit_start      = $offset > 1 ? ($offset - 1) * $limit : 0;
        $this->db->select('yorum.*,
            kullanici.kullanici_ad, kullanici.kullanici_resim,
            urunler.urun_ad,
        ');
        $this->db->from('yorum');
        $this->db->join('kullanici', 'yorum.kullanici_id = kullanici.kullanici_id');
        $this->db->join('urunler', 'yorum.urun_id = urunler.urun_id');
        $this->db->where_in('yorum.urun_id', $product_ids);
        $this->db->where('yorum.yorum_durum', 1);  // Sadece onaylı yorumları al
        $this->db->limit($limit, $limit_start);   // Sayfalama limit ve offset
        $query = $this->db->get();
        return $query->result();
    }

    public function count_comments_by_product_ids($product_ids) {
        $this->db->where_in('urun_id', $product_ids);
        $this->db->where('yorum_durum', 1);  // Sadece onaylı yorumları say
        return $this->db->count_all_results('yorum');
    }
}
?>