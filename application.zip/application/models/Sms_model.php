<?php

class Sms_model extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
    }

    public function sms_sablon_add($data = array())
    {
        return $this->db->insert("sms_sablon", $data);
    }

    public function sms_log_add($data = array())
    {
        return $this->db->insert("sms_log", $data);
    }

    public function sms_sablon($where = array())
    {
        return $this->db->where($where)->get("sms_sablon")->row();
    }

    public function sms_sablonlar($where = array())
    {
        return $this->db->where($where)->order_By('sablon_id', 'DESC')->get("sms_sablon")->result();
    }

    public function sms_sablon_update($where = array(), $data = array())
    {
        return $this->db->where($where)->update("sms_sablon", $data);
    }

    public function sms_sablon_say($where = array())
    {
        $query = $this->db->where($where)->get("sms_sablon");
        return $query->num_rows();
    }

    public function sms_sablon_sil($where = array())
    {
        return $this->db->where($where)->delete("sms_sablon");
    }
}