<?php
class Kupon_model extends CI_Model
{
	
	public function __construct()
	{
		parent::__construct();
	}
    function get($where=array()) {
        return $this->db->where($where)->get("kuponlar")->row();
    }
    function get_all($where=array()) {
        return $this->db->where($where)->get("kuponlar")->result();
    }
    function add($data) {
        return $this->db->insert("kuponlar", $data);
    }
    function update($where,$data) {
        return $this->db->where($where)->update("kuponlar", $data);
    }
    function delete($where) {
        return $this->db->where($where)->delete("kuponlar");
    }
    function logdelete($where) {
        return $this->db->where($where)->delete("kupon_log");
    }
    function get_all_logs($where=array()) {
        return $this->db->select("kullanici.kullanici_ad,kupon_log.*")->join("kullanici","kullanici.kullanici_id=kupon_log.kullanici")->where($where)->get("kupon_log")->result();
    }
    function get_log($where=array()) {
        return $this->db->where($where)->get("kupon_log")->row();
    }
    function insert_log($data) {
        return $this->db->insert("kupon_log", $data);
    }
}