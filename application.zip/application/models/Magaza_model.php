<?php

class Magaza_model extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
    }

    public function sponsor_check($id)
    {
        return $this->db->where(array("kullanici_id" => $id))->get("sponsors")->row();
    }

    public function magaza_check($id)
    {
        return $this->db->where(array("kullanici_id" => $id))->get("magaza")->row();
    }

    public function iller($where = array())
    {
        return $this->db->where($where)->get("iller")->result();
    }

    public function getwho($where = array())
    {
        return $this->db->where($where)->get("kullanici")->row();
    }

    public function ilceler($where = array())
    {
        return $this->db->where($where)->get("ilceler")->result();
    }

    public function magaza_username_check($where = array())
    {
        return $this->db->where($where)->get("magaza")->row();
    }

    public function magaza_add($data = array())
    {
        return $this->db->insert("magaza", $data);
    }

    public function sponsor_add($data = array())
    {
        return $this->db->insert("sponsors", $data);
    }

    public function magaza_update($where = array(), $data = array())
    {
        return $this->db->where($where)->update("magaza", $data);
    }

    public function magaza($where = array())
    {
        return $this->db->where($where)->get("magaza")->row();
    }

    public function magazalar_tam($where = array())
    {
        return $this->db->where($where)->order_by('magaza_id', 'DESC')->get("magaza")->result();
    }
    
    public function magazalar($where = array())
    {
        return $this->db->where($where)->order_by('magaza_id', 'DESC')->limit(10)->get("magaza")->result();
    }

    public function urunler($where = array())
    {
        return $this->db->where($where)->get("urunler")->result();
    }

    public function urunler_anasayfa($where = array(), $katid)
    {
        $this->db->join('magaza', 'urunler.magaza_id=magaza.magaza_id');
        $this->db->join('kullanici', 'urunler.kullanici_id=kullanici.kullanici_id');
        return $this->db->where($where)->where("(JSON_CONTAINS(kategori_json,'[\"$katid\"]')) > ", 0)->where('urunler.urun_populer != 1')->order_by('urunler.urun_populer', 'DESC')->order_by('urunler.urun_id', 'DESC')->limit(8)->get("urunler")->result();
    }

    public function urunler_vitrin($where = array())
    {
        $this->db->join('magaza', 'urunler.magaza_id=magaza.magaza_id');
        $this->db->join('kullanici', 'urunler.kullanici_id=kullanici.kullanici_id');
        return $this->db->where($where)->order_by('urunler.urun_vitrin_sira', 'ASC')->get("urunler")->result();
    }

    public function urunler_yeni($where = array())
    {
        $this->db->join('magaza', 'urunler.magaza_id=magaza.magaza_id');
        $this->db->join('kullanici', 'urunler.kullanici_id=kullanici.kullanici_id');
        return $this->db->where($where)->order_by('urunler.urun_id', 'ASC')->get("urunler")->result();
    }
    public function urunler_cok_satan($where = array())
    {
        $this->db->select('urunler.*,kullanici.*');
        $this->db->join('urunler', 'urunler.urun_id=siparis.urun_id');
        $this->db->join('magaza', 'siparis.magaza=magaza.magaza_id');
        $this->db->join('kullanici', 'urunler.kullanici_id=kullanici.kullanici_id');
        return $this->db->where($where)->group_by("siparis.urun_id")->order_by('count(1)', 'DESC')->get("siparis")->result();
    }

    public function urunler_coksatan(){
        
    }

    public function urun($where = array())
    {
        return $this->db->where($where)->get("urunler")->row();
    }

    public function urun_komisyon($where = array())
    {
        $val = $this->db->where($where)->get("urunler")->result();

        $js = json_decode($val[0]->kategori_json, true);
        $komisyon = "0";
        foreach ($js as $valx) {
            $valxm = $this->db->where(array('kategori_id' => $valx))->get("kategori")->result();
            if ($valxm[0]->komisyon != Null) {
                $komisyon = $valxm[0]->komisyon;
            }
        }
        return $komisyon;
    }
    public function magaza_urunsay($where = array()) {
        $this->db->join("magaza","magaza.magaza_id=urunler.magaza_id");
        $query = $this->db->where($where)->get("urunler");
        return $query->num_rows();
    }
    public function urunsay($where = array())
    {
        $query = $this->db->where($where)->get("urunler");
        return $query->num_rows();
    }

    public function kat_urunsay($katid)
    {
        $query = $this->db->where("(JSON_CONTAINS(kategori_json,'[\"$katid\"]')) > ", 0)->get("urunler");
        return $query->num_rows();
    }

    public function kat_urun_sayfalama($where = array(), $katid, $limit, $count)
    {
        $this->db->join('magaza', 'urunler.magaza_id=magaza.magaza_id');
        return $this->db->where($where)->where("(JSON_CONTAINS(urunler.kategori_json,'[\"$katid\"]')) > ", 0)->order_by('urunler.urun_populer_kat', 'DESC')->where('urunler.urun_populer_kat != 1')->order_by('urunler.urun_sira', 'ASC')->limit($limit, $count)->get("urunler")->result();
    }

    public function kat_vitrin_urun_sayfalama($where = array(), $katid)
    {
        $this->db->join('magaza', 'urunler.magaza_id=magaza.magaza_id');
        return $this->db->where($where)->where("(JSON_CONTAINS(urunler.kategori_json,'[\"$katid\"]')) > ", 0)->order_by('urunler.urun_populer_kat', 'DESC')->order_by('urunler.urun_sira', 'ASC')->get("urunler")->result();
    }

    public function urun_sayfalama($where = array(), $limit, $count)
    {
        return $this->db->where($where)->order_by("urunler.urun_id DESC")->limit($limit, $count)->get("urunler")->result();
    }

    public function magaza_urun_sayfalama($where = array(), $limit, $count)
    {
        $this->db->join('magaza', 'urunler.magaza_id=magaza.magaza_id');
        return $this->db->where($where)->order_by("urunler.urun_id DESC")->limit($limit, $count)->get("urunler")->result();
    }
    
    public function vitrin_add($data = array())
    {
        return $this->db->insert("vitrinler", $data);
    }

    public function vitrin_update($where = array(),$data = array())
    {
        return $this->db->where($where)->update("vitrinler", $data);
    }

    public function vitrin_delete($where = array())
    {
        $this->db->where('vitrin_id',$where['id'])->delete('vitrin_urunler');
        return $this->db->where($where)->delete("vitrinler");
    }
    public function vitrinurun_delete($where = array())
    {
        return $this->db->where($where)->delete("vitrin_urunler");
    }
    public function vitrinurun_add($data = array())
    {
        return $this->db->insert("vitrin_urunler", $data);
    }
    public function vitrinurun_update($where = array(),$data = array())
    {
        return $this->db->where($where)->update("vitrin_urunler", $data);
    }

    public function urun_add($data = array())
    {
        return $this->db->insert("urunler", $data);
    }

    public function urun_update($where = array(), $data = array())
    {
        return $this->db->where($where)->update("urunler", $data);
    }

    public function urun_delete($where = array())
    {
        return $this->db->set(['urun_durum' => 2])->where($where)->update("urunler");
    }

    /**
     * Yorum İşlemleri
     */

    public function magaza_yorumsay()
    {
        $kullanici = kullanicicek();
        $magaza = $this->db->where(array('kullanici_id' => $kullanici->kullanici_id))->get('magaza')->row();

        if ($magaza) {
            $query = $this->db->where(array('magaza_id' => $magaza->magaza_id))->where('(yorum_durum = 1 or yorum_durum = 2)')->get("yorum");
            return $query->num_rows();
        } else {
            return 0;
        }
    }

    public function yorum_sayfalama($limit, $count)
    {
        $kullanici = kullanicicek();
        $magaza = $this->db->where(array('kullanici_id' => $kullanici->kullanici_id))->get('magaza')->row();
        $this->db->join('kullanici', 'yorum.kullanici_id = kullanici.kullanici_id');
        $this->db->join('urunler', 'yorum.urun_id = urunler.urun_id');
        return $this->db->where(array('yorum.magaza_id' => $magaza->magaza_id))->where('(yorum.yorum_durum = 1 or yorum.yorum_durum = 2)')->order_by("yorum.yorum_id DESC")->limit($limit, $count)->get("yorum")->result();
    }

    public function get_yorumlar($magaza_id)
    {
        $this->db->join('kullanici', 'yorum.kullanici_id = kullanici.kullanici_id');
        $this->db->join('urunler', 'yorum.urun_id = urunler.urun_id');
        $this->db->join('magaza', 'yorum.magaza_id = magaza.magaza_id');
        return $this->db->where(array('yorum.magaza_id' => $magaza_id))->where('(yorum.yorum_durum = 1 or yorum.yorum_durum = 2)')->order_by("yorum.yorum_id DESC")->get("yorum")->result();
    }

    public function yorum($where = array())
    {
        $this->db->join('kullanici', 'yorum.kullanici_id = kullanici.kullanici_id');
        $this->db->join('urunler', 'yorum.urun_id = urunler.urun_id');
        return $this->db->where($where)->get("yorum")->row();
    }

    public function yorum_itiraz_ekle($data = array())
    {
        return $this->db->insert("yorum_itiraz", $data);
    }

    public function yorum_itiraz_say($where = array())
    {
        $query = $this->db->where($where)->get("yorum_itiraz");
        return $query->num_rows();
    }

    public function yorum_itiraz($where = array())
    {
        $this->db->join('yorum', 'yorum_itiraz.yorum_id = yorum.yorum_id');
        return $this->db->where($where)->get("yorum_itiraz")->row();
    }

    public function yorum_itirazlar($where = array())
    {
        $this->db->join('yorum', 'yorum_itiraz.yorum_id = yorum.yorum_id');
        return $this->db->where($where)->get("yorum_itiraz")->result();
    }

    public function itiraz_update($where = array(), $data = array())
    {
        return $this->db->where($where)->update("yorum_itiraz", $data);
    }

    public function itiraz_sil($where = array())
    {
        return $this->db->where($where)->delete("yorum_itiraz");
    }

    public function aylik_siparis($magaza_id = null)
    {
        $this->db->query("SET lc_time_names = 'tr_TR'");
        $this->db->select('SUM(siparis_ktutar) as toplam,MONTHNAME(siparis_tarih) as ay');
        $this->db->where("YEAR(siparis_tarih) = '" . date('Y') . "' AND magaza = " . $magaza_id . " AND siparis_durum = 2");
        $this->db->group_by("YEAR(siparis_tarih),MONTH(siparis_tarih)");
        return $this->db->get('siparis')->result();
    }


    public function gunluk_siparis_tutari($magaza_id)
    {
        $this->db->query("SET lc_time_names = 'tr_TR'");
        $this->db->select('SUM(siparis_ktutar) as toplam');
        $this->db->where("DAY(siparis_tarih) = DAY(CURDATE()) AND MONTH(siparis_tarih) = MONTH(CURDATE()) AND magaza = " . $magaza_id . " AND siparis_durum = 2");
        return $this->db->get('siparis')->result();
    }

    public function aylik_siparis_tutari($magaza_id)
    {
        $this->db->query("SET lc_time_names = 'tr_TR'");
        $this->db->select('SUM(siparis_ktutar) as toplam');
        $this->db->where("MONTH(siparis_tarih) = MONTH(CURDATE()) AND magaza = " . $magaza_id . " AND siparis_durum = 2");
        return $this->db->get('siparis')->result();
    }

    public function odenen_kazanclar($magaza_id)
    {
        $this->db->query("SET lc_time_names = 'tr_TR'");
        $this->db->select('SUM(siparis_ktutar) as toplam');
        $this->db->where("magaza = " . $magaza_id . " AND siparis_durum = 2 AND odeme_onay = 1");
        return $this->db->get('siparis')->result();
    }

    public function odenebilir_kazanclar($magaza_id)
    {
        $this->db->query("SET lc_time_names = 'tr_TR'");
        $this->db->select('SUM(siparis_ktutar) as toplam');
        $this->db->where("magaza = " . $magaza_id . " AND siparis_durum = 2 AND odeme_onay = 0");
        return $this->db->get('siparis')->result();
    }

    public function odenebilir_kazanclar_id($magaza_id)
    {
        $this->db->query("SET lc_time_names = 'tr_TR'");
        $this->db->select('siparis_id as id');
        $this->db->where("magaza = " . $magaza_id . " AND siparis_durum = 2 AND odeme_onay = 0");
        return $this->db->get('siparis')->result();
    }

    public function toplam_kazanclar($magaza_id)
    {
        $this->db->query("SET lc_time_names = 'tr_TR'");
        $this->db->select('SUM(siparis_ktutar) as toplam');
        $this->db->where("magaza = " . $magaza_id . " AND siparis_durum = 2");
        return $this->db->get('siparis')->result();
    }

    public function aylik_siparis_adet($magaza_id)
    {
        $this->db->query("SET lc_time_names = 'tr_TR'");
        $this->db->select('COUNT(siparis_id) as toplam');
        $this->db->where("MONTH(siparis_tarih) = MONTH(CURDATE()) AND magaza = " . $magaza_id . " AND siparis_durum = 2 OR siparis_durum = 1 OR siparis_durum = 3");
        return $this->db->get('siparis')->result();
    }

    public function toplam_siparis_adet($magaza_id)
    {
        $this->db->query("SET lc_time_names = 'tr_TR'");
        $this->db->select('COUNT(siparis_id) as toplam');
        $this->db->where("magaza = " . $magaza_id . " AND siparis_durum = 2 OR siparis_durum = 1 OR siparis_durum = 3");
        return $this->db->get('siparis')->result();
    }

    public function toplam_yorum_ortalamasi($magaza_id)
    {
        $this->db->query("SET lc_time_names = 'tr_TR'");
        $this->db->select('SUM(yorum_puan) as puan, COUNT(yorum_id) as toplam');
        $this->db->where("magaza_id = " . $magaza_id . " AND yorum_durum = 1");
        return $this->db->get('yorum')->result();
    }

    public function urun_toplam_yorum_ortalamasi($magaza_id, $urun_id)
    {
        $this->db->query("SET lc_time_names = 'tr_TR'");
        $this->db->select('SUM(yorum_puan) as puan, COUNT(yorum_id) as toplam');
        $this->db->where("magaza_id = " . $magaza_id . " AND urun_id = " . $urun_id . " AND yorum_durum = 1");
        return $this->db->get('yorum')->result();
    }

    public function paracek_add($data = array())
    {
        return $this->db->insert("para_cek", $data);
    }

    public function paracek($where = array())
    {
        return $this->db->where($where)->get("para_cek")->row();
    }

    public function para_cek($where = array())
    {
        return $this->db->where($where)->get("para_cek")->result();
    }

    public function bakiye_talep_cek($where = array())
    {
        return $this->db->where($where)->select("balance_upload_request.*,bank_accounts.name as bank_name,kullanici.kullanici_ad as user_name")
                                        ->join('kullanici', 'balance_upload_request.user_id = kullanici.kullanici_id')
                                        ->join('bank_accounts','balance_upload_request.bank_id = bank_accounts.id')
                                        ->get("balance_upload_request")->result();
    }
    public function bakiyetalepcek($where = array())
    {
        return $this->db->where($where)->select("balance_upload_request.*,bank_accounts.name as bank_name,kullanici.kullanici_ad as user_name")
                                        ->join('kullanici', 'balance_upload_request.user_id = kullanici.kullanici_id')
                                        ->join('bank_accounts','balance_upload_request.bank_id = bank_accounts.id')
                                        ->get("balance_upload_request")->row();
    }
    public function kpara_cek($where = array())
    {
        return $this->db->where($where)->join('kullanici', 'para_cek.kullanici_id = kullanici.kullanici_id')->get("para_cek")->result();
    }

    public function kparacek($where = array())
    {
        return $this->db->where($where)->join('kullanici', 'para_cek.kullanici_id = kullanici.kullanici_id')->get("para_cek")->row();
    }

    public function paracek_check($kullanici_id)
    {
        $query = $this->db->where(array('kullanici_id' => $kullanici_id, 'paracek_durum' => 0))->get("para_cek");
        if ($query->num_rows() > 0) {
            return true;
        } else {
            return false;
        }
    }

    public function paracek_say($kullanici_id)
    {
        $query = $this->db->where(array('kullanici_id' => $kullanici_id))->get("para_cek");
        return $query->num_rows();
    }

    public function paracek_sayfalama($where = array(), $limit, $count)
    {
        return $this->db->where($where)->join('kullanici', 'para_cek.kullanici_id = kullanici.kullanici_id')->order_by("para_cek.paracek_id DESC")->limit($limit, $count)->get("para_cek")->result();
    }

    public function bakiyetalep_update($where = array(), $data = array())
    {
        return $this->db->where($where)->update("balance_upload_request", $data);
    }

    public function update_user_bakiye($user, $bakiye)
    {
        return $this->db->set(['bakiye' => $bakiye])->where(['kullanici_id' => $user])->update("kullanici");
    }

    public function paracek_update($where = array(), $data = array())
    {
        return $this->db->where($where)->update("para_cek", $data);
    }

    public function paracek_sil($where = array())
    {
        return $this->db->where($where)->delete("para_cek");
    }
    public function bakiyetalep_sil($where = array())
    {
        return $this->db->where($where)->delete("balance_upload_request");
    }

    /**
     * Reklam model
     */
    public function reklam($where = array())
    {
        return $this->db->where($where)->join('urunler', 'reklam.urun_id=urunler.urun_id')->get("reklam")->row();
    }

    public function reklamlar($where = array())
    {
        return $this->db->where($where)->join('magaza', 'magaza.magaza_id=magaza.magaza_id')->join('urunler', 'reklam.urun_id=urunler.urun_id')->get("reklam")->result();
    }

    public function reklam_say($urun_id, $tur)
    {
        $query = $this->db->where(array('urun_id' => $urun_id, 'reklam_turu' => $tur))->get("reklam");
        return $query->num_rows();
    }

    public function reklam_say2($urun_id)
    {
        $query = $this->db->where(array('urun_id' => $urun_id, 'reklam_durum' => 1))->get("reklam");
        return $query->num_rows();
    }

    public function reklam_add($data = array())
    {
        return $this->db->insert("reklam", $data);
    }

    public function reklam_update($where = array(), $data = array())
    {
        return $this->db->where($where)->update("reklam", $data);
    }

    public function reklam_delete($where = array())
    {
        return $this->db->where($where)->delete("reklam");
    }

    public function get_sorular($magaza)
    {
        $this->db->select('s.*, 
            u.urun_ad,
            u.urun_seo,
            u.urun_resim_min,
        ');
        $this->db->from('sorular s');
        $this->db->join('urunler u', 'u.urun_id = s.urun_id');
        $this->db->where(['s.magaza_id' => $magaza, 'u.urun_durum' => 1, 's.cevap' => 0]);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result();
        } else {
            return [];
        }
    }

    public function get_soru_cevap($soru_id)
    {
        $this->db->select('soru, tarih');
        $this->db->from('sorular');
        $this->db->where(['cevap' => $soru_id, 'soru_durum' => 1]);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->row();
        } else {
            return [];
        }
    }

    public function get_kategori_filtreler($kategori)
    {
        $this->db->from('filtreler');
        $this->db->where(['kategori_id' => $kategori, 'filtre_durum' => 1, 'sub_filter' => 0]);
        $this->db->order_by('sira', 'ASC');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result();
        } else {
            return [];
        }
    }

    public function new_liste_urunler($vericek, $type, $desc, $title, $min, $maks, $filters_array)
    {
        error_reporting(E_ALL);
        ini_set("display_errors", 1);

        $this->db->from('urunler');
        $this->db->where(['urun_durum' => 1, 'urun_bitis_tarihi>' => date('Y-m-d H:i'), 'urun_alim' => 0]);
        $this->db->group_start();
            $this->db->like('kategori_json', $vericek->kategori_id);
            if (!empty($type) && $type != 'all') {
                $this->db->like('filtre', $type);
            }
            if (!empty($desc)) {
                $this->db->like('urun_aciklama', $desc);
            }
            if (!empty($title)) {
                $this->db->like('urun_ad', $title);
            }
            if (!empty($min)) {
                $this->db->where(['urun_fiyat >=' => $min]);
            }
            if (!empty($maks)) {
                $this->db->where(['urun_fiyat <=' => $maks]);
            }
            if (!empty($filters_array)) {
                //$this->db->where("JSON_EXTRACT(your_json_column, '$." . $key . "')", $value);
                foreach ($filters_array as $key => $val) {
                    if (!empty($val)) {
                        if (!empty($val)) {
                            $like_value = '"'.$key.'":"'.$val.'"';
                            $this->db->where("alt_filtreler LIKE '%{$like_value}%'", null, false);
                        }
                    }
                }
            }
        $this->db->group_end();

        /*$key = 'your_key'; // Değiştirmeniz gereken anahtar
        $value = 'your_value'; // Değiştirmeniz gereken değer
        $this->db->where("JSON_SEARCH(alt_filtreler, 'one', '$.{$key}:{$value}') IS NOT NULL");*/

        $this->db->order_by('urun_sira', 'ASC');
        $query = $this->db->get();
        //prex($this->db->last_query());
        if (!$query) {
            die($this->db->error());
        }
        if ($query->num_rows() > 0) {
            return $query->result();
        } else {
            return [];
        }

    }

    public function get_my_sorular($user)
    {
        $this->db->select('s.*, 
            u.urun_ad,
            u.urun_seo,
            u.urun_resim_min,
        ');
        $this->db->from('sorular s');
        $this->db->join('urunler u', 'u.urun_id = s.urun_id');
        $this->db->where(['s.kullanici_id' => $user, 'u.urun_durum' => 1, 's.cevap' => 0]);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result();
        } else {
            return [];
        }
    }

    public function get_para_cekme_yontemler()
    {
        $this->db->from('para_cekme_ayarlari');
        $this->db->order_by('row_sira', 'ASC');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result();
        } else {
            return [];
        }
    }

    public function get_magaza_ilanlar($id, $status)
    {
        $this->db->from('urunler');
        $this->db->where(['kullanici_id' => $id, 'admin' => 0, 'urun_durum' => $status]);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result();
        } else {
            return [];
        }
    }

    public function get_cekilisler($id, $status)
    {
        $this->db->from('cekilis');
        $this->db->where(['magaza_id' => $id, 'onay' => $status]);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result();
        } else {
            return [];
        }
    }

    public function get_order_count($magaza)
    {
        return $this->db->where(['magaza' => $magaza])->count_all_results('siparis');
    }

    public function get_sales_count($magaza)
    {
        return $this->db->where(['magaza' => $magaza, 'siparis_durum' => 2])->count_all_results('siparis');
    }

    public function get_total_earning($magaza)
    {
        return $this->db->where(['magaza' => $magaza, 'siparis_durum' => 2])->select_sum('siparis_tutar')->get('siparis')->row()->siparis_tutar;
    }

    public function get_month_total_earning($magaza_id)
    {
        $this->db->select('SUM(siparis_tutar) as toplam');
        $this->db->where("MONTH(siparis_tarih) = MONTH(CURDATE()) AND magaza = " . $magaza_id . " AND siparis_durum = 2");
        return $this->db->get('siparis')->row()->toplam;
    }

    public function get_month_order_count($magaza)
    {
        $this->db->where("MONTH(siparis_tarih) = MONTH(CURDATE()) AND magaza = " . $magaza);
        return $this->db->count_all_results('siparis');
    }

    public function get_destek_taleperim($kullanici_id)
    {
        return $this->db->where(['talep.kullanici_id' => $kullanici_id])->join('kullanici', 'kullanici.kullanici_id = talep.kullanici_id')->order_by("talep.talep_id", "DESC")->get("talep")->result();
    }

    public function get_ilan_yorumlari($magaza_id)
    {
        $this->db->select('y.*, u.urun_ad, u.urun_resim_min, u.urun_seo');
        $this->db->from('yorum y');
        $this->db->join('urunler u', 'u.urun_id = y.urun_id', 'left');
        $this->db->where(['y.magaza_id' => $magaza_id, 'y.yorum_durum' => 1]);
        $this->db->order_by('y.yorum_id', 'DESC');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result();
        } else {
            return [];
        }
    }
}
