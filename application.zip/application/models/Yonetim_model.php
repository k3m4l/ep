<?php
class Yonetim_model extends CI_Model
{

	public $tableName = "kullanici";
	
	public function __construct()
	{
		parent::__construct();
	}

	public function getAll($where = array()){
		return $this->db->where($where)->get($this->tableName)->result();
	}

	public function get($where = array()){
		return $this->db->where($where)->get($this->tableName)->row();
	}

    public function login_user($email_or_username){
        return $this->db->where(['kullanici_ad' => $email_or_username])->or_where(['kullanici_mail' => $email_or_username])->get($this->tableName)->row();
    }



    /*public function get_siteye_satislar($status)
    {
        $this->db->select('b.*, 
            u.urun_ad, u.urun_alimfiyat, u.urun_ad,
            k.kullanici_ad, k.kullanici_soyisim,
        ');
        $this->db->from('bize_sat b');
        $this->db->join('urunler u', 'u.urun_id = b.urun_id');
        $this->db->join('kullanici k', 'k.kullanici_id = b.user_id');
        $this->db->where(['b.status' => $status, 'b.deleted' => 0]);
        $this->db->order_by('b.id', 'DESC');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result();
        } else {
            return [];
        }
    }*/
	
	public function get_siteye_satislar($status)
{
    $this->db->select('b.*, 
        u.urun_ad, u.urun_alimfiyat,
        k.kullanici_ad, k.kullanici_soyisim
    ');
    $this->db->from('bize_sat b');
    $this->db->join('urunler u', 'u.urun_id = b.urun_id', 'left'); // 'left' kullanımı isteğe bağlı
    $this->db->join('kullanici k', 'k.kullanici_id = b.user_id', 'left'); // 'left' kullanımı isteğe bağlı
    $this->db->where(['b.status' => $status, 'b.deleted' => 0]);
    $this->db->order_by('b.id', 'DESC');

    // Sorguyu çalıştır
    $query = $this->db->get();

    // Hata Kontrolü
    if (!$query) {
        log_message('error', 'SQL Error: ' . $this->db->last_query());
        return []; // Hata durumunda boş bir dizi döndür
    }

    // Sonuçları döndür
    if ($query->num_rows() > 0) {
        return $query->result();
    } else {
        return [];
    }
	}


    public function get_gold_alim_satim($id)
    {
        $this->db->from('bize_sat');
        $this->db->where(['id' => $id, 'deleted' => 0]);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->row();
        } else {
            return [];
        }
    }

    public function update_gold_alim_satim_status($id, $status)
    {
        return $this->db->set(['status' => $status])->where(['id' => $id])->update('bize_sat');
    }

    public function delete_gold_alim_satim($id, $text)
    {
        return $this->db->set(['reason_for_cancellation' => $text, 'status' => 2])->where(['id' => $id])->update('bize_sat');

    }

	public function talepget($where = array()){
		return $this->db->where($where)->get("balance_upload_request")->row();
	}
	public function kategoriget($where = array()){
		return $this->db->where($where)->get("kategori")->row();
	}

    public function filtreget($where = array()){
        return $this->db->where($where)->get("filtreler")->row();
    }

    public function blogkategoriget($where = array()){
        return $this->db->where($where)->get("blog_kategori")->row();
    }

	public function blogget($where = array()){
		return $this->db->where($where)->get("blog")->row();
	}
	public function bankaget($where = array()){
		return $this->db->where($where)->get("bank_accounts")->row();
	}

	public function sayfaget($where = array()){
		return $this->db->where($where)->get("sayfa")->row();
	}

    public function sssget($where = array()){
        return $this->db->where($where)->get("sss")->row();
    }

	public function sliderget($where = array()){
		return $this->db->where($where)->get("slider")->row();
	}
	public function reklamget($where = array()){
		return $this->db->where($where)->get("home_sliders")->row();
	}

	public function kullaniciget($where = array()){
		return $this->db->where($where)->get("kullanici")->row();
	}

	public function paketget($where = array()){
		return $this->db->join('kategori', 'kategori.kategori_id = paket.paket_altkategori')->where($where)->get("paket")->row();
	}

	public function destekget($where = array()){
		return $this->db->join('destek_konu', 'destek_konu.konu_id = destek.destek_konu')->where($where)->get("destek")->row();
	}

	public function kuponget($where = array()){
		return $this->db->join('paket', 'paket.paket_id = kupon.paket_id')->where($where)->get("kupon")->row();
	}

	public function siparisget($where = array()){
		return $this->db->where($where)->get("siparis")->row();
	}

	public function get_all($where = array(), $order = "users_id ASC"){
		return $this->db->where($where)->order_by($order)->get($this->tableName)->result();
	}

	public function add($data = array()){
		return $this->db->insert($this->tableName, $data);
	}

	public function kategoriadd($data = array())
	{
		return $this->db->insert("kategori", $data);
	}

    public function serveradd($data = array())
    {
        return $this->db->insert("pvp_servers", $data);
    }

    public function filtreadd($data = array())
    {
        return $this->db->insert("filtreler", $data);
    }

    public function ozellikadd($data = array())
    {
        return $this->db->insert("filtre_ozellikler", $data);
    }

    public function blogkategoriadd($data = array())
    {
        return $this->db->insert("blog_kategori", $data);
    }

	public function blogadd($data = array())
	{
		return $this->db->insert("blog", $data);
	}
	public function bankaadd($data = array())
	{
		return $this->db->insert("bank_accounts", $data);
	}

    public function headeradd($data = array()){
        return $this->db->insert("headers", $data);
    }

    public function headerdelete($where = array())
    {
        return $this->db->where($where)->delete("headers");
    }

    public function getsubhd() {
    $query = $this->db->where('subheader_status', '1')
                      ->order_by('subheader_order', 'ASC')
                      ->get('subheaders');
                      
    return ($query && $query->num_rows() > 0) ? $query->result() : array();
}

    public function getsubhdrand(){
    $query = $this->db->where('durum', 1)
                      ->order_by('sira', 'ASC')
                      ->get("subheaders");
                      
    if ($query && $query->num_rows() > 0) {
        return $query->result();
    }
    
    // Varsayılan veri döndür
    return array(
        (object)array(
            'baslik' => 'Hoş Geldiniz',
            'link' => '#'
        )
    );
}

    public function addsubhd($data = array()){
        return $this->db->insert("subheaders", $data);
    }

    public function upsubhd($where = array(), $data = array())
    {
        return $this->db->where($where)->update("subheaders", $data);
    }

    public function dropdownadd($data = array()){
        return $this->db->insert("dropdowns", $data);
    }
    public function headerupdate($where = array(), $data = array())
	{
		return $this->db->where($where)->update("headers", $data);
	}
    public function dropdownupdate($where = array(), $data = array())
    {
        return $this->db->where($where)->update("dropdowns", $data);
    }
	public function slideradd($data = array())
	{
		return $this->db->insert("slider", $data);
	}
	public function reklamadd($data = array())
	{
		return $this->db->insert("home_sliders", $data);
	}

	public function paketadd($data = array())
	{
		return $this->db->insert("paket", $data);
	}

	public function siparisadd($data = array())
	{
		return $this->db->insert("siparis", $data);
	}

	public function konuadd($data = array())
	{
		return $this->db->insert("destek_konu", $data);
	}

	public function kuponadd($data = array())
	{
		return $this->db->insert("kupon", $data);
	}

	public function sayfaadd($data = array())
	{
		return $this->db->insert("sayfa", $data);
	}

    public function sssadd($data = array())
    {
        return $this->db->insert("sss", $data);
    }

	public function yoneticiadd($data = array())
	{
		return $this->db->insert("kullanici", $data);
	}

	public function update($where = array(), $data = array())
	{
		return $this->db->where($where)->update($this->tableName, $data);
	}

	public function katupdate($where = array(), $data = array())
	{
		return $this->db->where($where)->update("kategori", $data);
	}

    public function filtrepdate($where = array(), $data = array())
    {
        return $this->db->where($where)->update("filtreler", $data);
    }

    public function ozellikupdate($where = array(), $data = array())
    {
        return $this->db->where($where)->update("filtre_ozellikler", $data);
    }
    public function blogkatupdate($where = array(), $data = array())
    {
        return $this->db->where($where)->update("blog_kategori", $data);
    }

	public function sipupdate($where = array(), $data = array())
	{
		return $this->db->where($where)->update("siparis", $data);
	}

	public function firmaupdate($where = array(), $data = array())
	{
		return $this->db->where($where)->update("firma", $data);
	}

	public function kuponupdate($where = array(), $data = array())
	{
		return $this->db->where($where)->update("kupon", $data);
	}

	public function sayfaupdate($where = array(), $data = array())
	{
		return $this->db->where($where)->update("sayfa", $data);
	}

    public function sssupdate($where = array(), $data = array())
    {
        return $this->db->where($where)->update("sss", $data);
    }

	public function destekupdate($where = array(), $data = array())
	{
		return $this->db->where($where)->update("destek", $data);
	}

	public function kategoriupdate($where = array(), $data = array())
	{
		return $this->db->where($where)->update("kategori", $data);
	}

    public function kategorifiltreupdate($where = array(), $data = array())
    {
        return $this->db->where($where)->update("filtreler", $data);
    }

    public function blogkategoriupdate($where = array(), $data = array())
    {
        return $this->db->where($where)->update("blog_kategori", $data);
    }

	public function blogupdate($where = array(), $data = array())
	{
		return $this->db->where($where)->update("blog", $data);
	}
	public function bankaupdate($where = array(), $data = array())
	{
		return $this->db->where($where)->update("bank_accounts", $data);
	}

    public function paracekmeyontemupdate($where = array(), $data = array())
    {
        return $this->db->where($where)->update("para_cekme_ayarlari", $data);
    }

	public function sliderupdate($where = array(), $data = array())
	{
		return $this->db->where($where)->update("slider", $data);
	}
	public function reklamupdate($where = array(), $data)
	{
		return $this->db->where($where)->update("home_sliders", $data);
	}

	public function yoneticiupdate($where = array(), $data = array())
	{
		return $this->db->where($where)->update("kullanici", $data);
	}

	public function delete($where = array())
	{
		return $this->db->where($where)->delete($this->tableName);
	}

	public function kategoridelete($where = array())
	{
		return $this->db->where($where)->delete("kategori");
	}

    public function filtredelete($where = array())
    {
        return $this->db->where($where)->delete("filtreler");
    }

    public function ozellikdelete($where = array())
    {
        return $this->db->where($where)->delete("filtre_ozellikler");
    }

    public function blogkategoridelete($where = array())
    {
        return $this->db->where($where)->delete("blog_kategori");
    }

	public function firmadelete($where = array())
	{
		return $this->db->where($where)->delete("firma");
	}

	public function yorumdelete($where = array())
	{
		return $this->db->where($where)->delete("yorum");
	}

	public function kupondelete($where = array())
	{
		return $this->db->where($where)->delete("kupon");
	}

	public function sayfadelete($where = array())
	{
		return $this->db->where($where)->delete("sayfa");
	}

    public function sssdelete($where = array())
    {
        return $this->db->where($where)->delete("sss");
    }

	public function blogdelete($where = array())
	{
		return $this->db->where($where)->delete("blog");
	}
	public function bankadelete($where = array())
	{
		return $this->db->where($where)->delete("bank_accounts");
	}

	public function kullanicidelete($where = array())
	{
		return $this->db->where($where)->delete("kullanici");
	}

	public function sliderdelete($where = array())
	{
		return $this->db->where($where)->delete("slider");
	}
	public function reklamdelete($where = array())
	{
		return $this->db->where($where)->delete("home_sliders");
	}

	public function destekdelete($where = array())
	{
		return $this->db->where($where)->delete("destek");
	}

	public function alt_kategori($kategori_id)
	{
		$this->db->where('kategori_ust', $kategori_id);
		$this->db->order_by('kategori_sira', 'ASC');
		$query = $this->db->get('kategori');
		$output = '<option value="">Alt Kategori Seç</option>';
		foreach($query->result() as $row)
		{
			$output .= '<option value="'.$row->kategori_id.'">'.$row->kategori_ad.'</option>';
		}
		return $output;
	}

	public function konudelete($where = array())
	{
		return $this->db->where($where)->delete("destek_konu");
	}

	public function ayarupdate($where = array(), $data = array())
	{
		return $this->db->where($where)->update("ayarlar", $data);
	}

    public function get_kategoriget($where = array()){
        return $this->db->where($where)->get("kategori")->row();
    }


    public function get_bekleyen_destekler()
    {
        $this->db->from('talep');
        $this->db->where(['talep_durum' => 0]);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result();
        } else {
            return [];
        }
    }
	public function bayipara_cek($where = array()) {
		return $this->db->select("kullanici.kullanici_ad,balance_withdraw_requests.*")
				->join('kullanici','kullanici.kullanici_id=balance_withdraw_requests.user_id')
				->where($where)->get('balance_withdraw_requests')->result();
	}
    public function bayiparacek_update($where = array(), $data = array())
    {
        return $this->db->where($where)->update("balance_withdraw_requests", $data);
    }
    public function bayiparacek_sil($where = array())
    {
        return $this->db->where($where)->delete("balance_withdraw_requests");
    }

    public function control_alt_kategori($id)
    {
        $this->db->from('kategori');
        $this->db->where(['kategori_id' => $id]);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->row();
        } else {
            return false;
        }
    }

    public function kategori_filtreler_getir($id)
    {
        $this->db->from('filtreler');
        $this->db->where(['kategori_id' => $id, 'sub_filter' => 0]);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result();
        } else {
            return false;
        }
    }

    public function filtre_ozellikler_getir($id)
    {
        $this->db->from('filtre_ozellikler');
        $this->db->where(['filtre_id' => $id]);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result();
        } else {
            return false;
        }
    }

    public function control_filtre($id)
    {
        $this->db->from('filtreler');
        $this->db->where(['filtre_id' => $id]);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->row();
        } else {
            return false;
        }
    }
    
    public function kategori_alt_filtreler_getir($id)
    {
        $this->db->from('filtreler');
        $this->db->where(['sub_filter' => $id]);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result();
        } else {
            return false;
        }
    }

    public function get_yan_slider($sira)
    {
        $this->db->from('slider');
        $this->db->where(['tur' => 4, 'slider_sira' => $sira]);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->row();
        } else {
            return [];
        }
    }

    public function get_para_cekme_yontemleri()
    {
        $this->db->from('para_cekme_ayarlari');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result();
        } else {
            return [];
        }
    }

    public function para_cekme_yontem_get($id)
    {
        $this->db->from('para_cekme_ayarlari');
        $this->db->where(['id' => $id]);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->row();
        } else {
            return [];
        }
    }

    public function get_pvp_servers()
    {
        $this->db->from('pvp_servers');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result();
        } else {
            return [];
        }
    }

    public function serverdelete($where = array())
    {
        return $this->db->where($where)->delete("pvp_servers");
    }

    public function get_selected_pvp_server($id)
    {
        $this->db->from('pvp_servers');
        $this->db->where(['id' => $id]);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->row();
        } else {
            return [];
        }
    }

    public function server_update($data = array(), $server_id)
    {
        return $this->db->where(['id' => $server_id])->update("pvp_servers", $data);
    }

    public function get_sub_categories($type)
    {
        $this->db->from('kategori');
        $this->db->where(['parent >' => 0]);
        if (!empty($type)) {
            if ($type == 'ürün') {
                $type = '0';
            } else if ($type == 'ilan') {
                $type = '1';
            } else if ($type == 'gold') {
                $type = '2';
            }
            $this->db->where(['kategori_tur' => $type]);
        }
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result();
        } else {
            return [];
        }
    }

    public function get_selected_siteye_satis($id)
    {
        $this->db->select('b.*, 
            u.urun_ad, u.urun_alimfiyat, u.urun_ad,
            k.kullanici_ad, k.kullanici_soyisim,
        ');
        $this->db->from('bize_sat b');
        $this->db->join('urunler u', 'u.urun_id = b.urun_id');
        $this->db->join('kullanici k', 'k.kullanici_id = b.user_id');
        $this->db->where(['b.id' => $id, 'b.deleted' => 0]);
        $this->db->order_by('b.id', 'DESC');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->row();
        } else {
            return [];
        }
    }

    public function update_siteye_satis($data, $id)
    {
        return $this->db->where(['id' => $id])->update("bize_sat", $data);
    }

    public function update_urun_stok($urun_id, $stok)
    {
        return $this->db->set(['urun_stok' => $stok])->where(['urun_id' => $urun_id])->update("urunler");
    }

    public function update_urun_alim_stok($urun_id, $stok)
    {
        return $this->db->set(['urun_alim_stok' => $stok])->where(['urun_id' => $urun_id])->update("urunler");
    }

    public function gold_alim_satim_delete($where = array())
    {
        return $this->db->where($where)->delete("bize_sat");
    }

    public function get_selected_siparis($id)
    {
        $this->db->from('siparis');
        $this->db->where(['siparis_id' => $id]);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->row();
        } else {
            return [];
        }
    }

    public function update_user_balance($user_id, $balance)
    {
        return $this->db->set(['bakiye' => $balance])->where(['kullanici_id' => $user_id])->update("kullanici");
    }
}