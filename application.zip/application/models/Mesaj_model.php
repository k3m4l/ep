<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Mesaj_model extends CI_Model
{
    //add conversation
    public function add_amesaj($magaza_uniq)
    {
        $magaza = magaza_bilgi_uniq($magaza_uniq);
        $kullanici = kullanicicek();
        $data = array(
            'gonderen_id' => $kullanici->kullanici_id,
            'alan_id' => $magaza->kullanici_id,
            'tarih' => date("Y-m-d H:i:s"),
            'uniq' => uniqid()
        );

        $this->db->where('gonderen_id', $data['gonderen_id']);
        $this->db->where('alan_id', $data['alan_id']);
        $query = $this->db->get('amesaj');
        $row = $query->row();

        if (!empty($row)) {
            return $row->id;
        } else {
            if ($this->db->insert('amesaj', $data)) {
                return $this->db->insert_id();
            } else {
                return false;
            }
        }
    }

    public function add_amesaj_oto($magaza_id, $kullanici_id)
    {
        $magaza = magaza_bilgi($magaza_id);
        $kullanici = kullanici_bilgi($kullanici_id);
        $data = array(
            'gonderen_id' => $magaza->kullanici_id,
            'alan_id' => $kullanici->kullanici_id,
            'tarih' => date("Y-m-d H:i:s"),
            'uniq' => uniqid()
        );
        $this->db->where('gonderen_id', $data['gonderen_id']);
        $this->db->where('alan_id', $data['alan_id']);
        $query = $this->db->get('amesaj');
        $row = $query->row();

        if (!empty($row)) {
            return $row->id;
        } else {
            if ($this->db->insert('amesaj', $data)) {
                return $this->db->insert_id();
            } else {
                return false;
            }
        }
    }

    public function control_amesaj($kullanici_id, $gonderen_id)
    {
        $this->db->from('amesaj');
        $this->db->where(['alan_id' => $kullanici_id, 'gonderen_id' => $gonderen_id]);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->row();
        } else {
            return false;
        }
    }

    public function control_amesaj_reverse($kullanici_id, $gonderen_id)
    {
        $this->db->from('amesaj');
        $this->db->where(['alan_id' => $gonderen_id, 'gonderen_id' => $kullanici_id]);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->row();
        } else {
            return false;
        }
    }

    public function amesaj($where = array()){
        return $this->db->where($where)->order_by("id DESC")->get("amesaj")->result();
    }
    public function amesajRow($where = array()){
        return $this->db->where($where)->get("amesaj")->row();
    }

    public function mesaj($where = array()){
        return $this->db->where($where)->order_by("id ASC")->get("kmesaj")->result();
    }

    public function mesaj_add($data = array())
    {
        return $this->db->insert("kmesaj", $data);
    }

    public function mesajRow($where = array()){
        return $this->db->where($where)->get("kmesaj")->row();
    }

    public function mesajOkunmamis($where = array())
    {
        $query = $this->db->where($where)->get("kmesaj");
        return $query->num_rows();
    }

    public function mesajUpdate($where = array(), $data = array())
    {
        return $this->db->where($where)->update("kmesaj", $data);
    }

    public function control_username($username)
    {
        $this->db->from('kullanici');
        $this->db->where(['kullanici_ad' => $username, 'kullanici_durum' => 1]);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->row();
        } else {
            return false;
        }
    }

    public function add_amesaj_new($data)
    {
        $this->db->where('gonderen_id', $data['gonderen_id']);
        $this->db->where('alan_id', $data['alan_id']);
        $query = $this->db->get('amesaj');
        $row = $query->row();

        if (!empty($row)) {
            return $row->id;
        } else {
            if ($this->db->insert('amesaj', $data)) {
                return $this->db->insert_id();
            } else {
                return false;
            }
        }
    }

    public function mesajResult($where = array()){
        return $this->db->where($where)->get("kmesaj")->result();
    }

    public function get_kullanici_bilgi($id)
    {
        $this->db->from('kullanici');
        $this->db->where(['kullanici_id' => $id]);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->row();
        } else {
            return false;
        }
    }


}