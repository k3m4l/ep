<?php

class Bakiye_model extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
    }

    public function bakiye_add($data = array())
    {
        return $this->db->insert("bakiye", $data);
    }

    public function bakiye($where = array())
    {
        return $this->db->where($where)->join('kullanici', 'kullanici.kullanici_id = bakiye.kullanici_id')->get("bakiye")->row();
    }

    public function bakiyeler($where = array(), $limit, $count)
    {
        return $this->db->where($where)->join('kullanici', 'kullanici.kullanici_id = bakiye.kullanici_id')->limit($limit, $count)->order_By('bakiye.bakiye_id', 'DESC')->get("bakiye")->result();
    }

    public function bakiyelerAdmin($where = array())
    {
        return $this->db->join('kullanici', 'kullanici.kullanici_id = bakiye.kullanici_id')->order_By('bakiye.bakiye_id', 'DESC')->get("bakiye")->result();
    }

    public function bakiye_update($where = array(), $data = array())
    {
        return $this->db->where($where)->update("bakiye", $data);
    }

    public function bakiye_say($where = array())
    {
        $query = $this->db->where($where)->get("bakiye");
        return $query->num_rows();
    }

    public function bakiye_sil($where = array())
    {
        return $this->db->where($where)->delete("bakiye");
    }
}