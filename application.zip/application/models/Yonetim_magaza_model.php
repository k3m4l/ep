<?php

class Yonetim_magaza_model extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
    }

    public function magaza_check($id)
    {
        return $this->db->where(array("kullanici_id" => $id))->get("magaza")->row();
    }

    public function iller($where = array())
    {
        return $this->db->where($where)->get("iller")->result();
    }

    public function ilceler($where = array())
    {
        return $this->db->where($where)->get("ilceler")->result();
    }

    public function magaza_username_check($where = array())
    {
        return $this->db->where($where)->get("magaza")->row();
    }

    public function magaza_add($data = array())
    {
        return $this->db->insert("magaza", $data);
    }

    public function magaza($where = array())
    {
        return $this->db->where($where)->join('kullanici', 'magaza.kullanici_id=kullanici.kullanici_id')->get("magaza")->row();
    }

    public function magazalar($where = array())
    {
        return $this->db->where($where)->join('kullanici', 'magaza.kullanici_id=kullanici.kullanici_id')->get("magaza")->result();
    }

    public function sponsorlar($where = array())
    {
        return $this->db->where($where)->join('kullanici', 'sponsors.kullanici_id=kullanici.kullanici_id')->get("sponsors")->result();
    }
    
    public function bayiler($where = array())
    {
        return $this->db->where($where)->join('kullanici', 'bayi_basvuru.kullanici_id=kullanici.kullanici_id')->get("bayi_basvuru")->result();
    }
    
    public function magaza_update($where = array(), $data = array())
    {
        return $this->db->where($where)->update("magaza", $data);
    }

    public function magaza_sil($where = array())
    {
        return $this->db->where($where)->delete("magaza");
    }

    public function sponsor_sil($where = array())
    {
        return $this->db->where($where)->delete("sponsors");
    }
    public function basvuru_sil($where = array())
    {
        return $this->db->where($where)->delete("bayi_basvuru");
    }
    public function basvuru_update($where = array(), $data = array())
    {
        return $this->db->where($where)->update("bayi_basvuru", $data);
    }

    /**
     * Ürünler
     */

    public function urunler($where = array())
    {
        $this->db->where($where);
        $this->db->join('kullanici', 'urunler.kullanici_id = kullanici.kullanici_id');
        $this->db->join('magaza', 'urunler.magaza_id = magaza.magaza_id');
        return $this->db->get("urunler")->result();
    }

    public function urun($where = array())
    {
        $this->db->where($where);
        $this->db->join('kullanici', 'urunler.kullanici_id = kullanici.kullanici_id');
        $this->db->join('magaza', 'urunler.magaza_id = magaza.magaza_id');
        return $this->db->get("urunler")->row();
    }

    public function urun_sil($where = array())
    {
        return $this->db->where($where)->delete("urunler");
    }


    /**
     * Teslimat
     */

    public function teslimatlar($where = array())
    {
        $this->db->where($where);
        $this->db->join('kullanici', 'teslimat.kullanici_id = kullanici.kullanici_id');
        $this->db->join('siparis', 'teslimat.siparis_no = siparis.siparis_no');
        return $this->db->get("teslimat")->result();
    }

    public function teslimat($where = array())
    {
        $this->db->where($where);
        $this->db->join('kullanici', 'teslimat.kullanici_id = kullanici.kullanici_id');
        $this->db->join('siparis', 'teslimat.siparis_no = siparis.siparis_no');
        return $this->db->get("teslimat")->row();
    }

    public function teslimat_update($where = array(), $data = array())
    {
        return $this->db->where($where)->update("teslimat", $data);
    }

    public function teslimat_sil($where = array())
    {
        return $this->db->where($where)->delete("teslimat");
    }
}
