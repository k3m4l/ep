<?php

date_default_timezone_set('Europe/Istanbul');

if (!function_exists('active_user')) {
    function active_user()
    {
        $t = &get_instance();

        $user = $t->session->userdata("kullanici");

        if ($user)
            return $user;
        else
            return false;
    }
}

if (!function_exists('get_months')) {
    function get_months($val)
    {
        $months = [
            '01' => 'Ocak',
            '02' => 'Şubat',
            '03' => 'Mart',
            '04' => 'Nisan',
            '05' => 'Mayıs',
            '06' => 'Haziran',
            '07' => 'Temmuz',
            '08' => 'Ağustos',
            '09' => 'Eylül',
            '10' => 'Ekim',
            '11' => 'Kasım',
            '12' => 'Aralık'
        ];


        return $months[$val];
    }
}

if (!function_exists('prex')) {
    function prex($val)
    {
        echo "<pre>";
        print_r($val);
        echo "</pre>";
        exit;
    }
}

if (!function_exists('pre')) {
    function pre($val)
    {
        echo "<pre>";
        print_r($val);
        echo "</pre>";
    }
}

if (!function_exists('array_to_object')) {
    function array_to_object($array)
    {
        $object = new stdClass();
        foreach ($array as $key => $value) {
            if (is_array($value)) {
                $value = array_to_object($value);
            }
            $object->$key = $value;
        }
        return $object;
    }
}

if (!function_exists('aktif_kullanici')) {
    function aktif_kullanici()
    {
        $t = &get_instance();

        $user = $t->session->userdata("aktifkullanici");

        if ($user) {
            $db_user = $t->yonetim_model->get(array(
                "kullanici_id" => $user->kullanici_id
            ));

            if ($db_user)
                return $db_user;
            else
                return false;
        } else {
            return false;
        }
    }
}

if (!function_exists('kullanicicek')) {
    function kullanicicek()
    {
        $t = &get_instance();
        if ($t->session->userdata("aktifkullanici")) {

            $user = $t->session->userdata("aktifkullanici");

            $kullanici = $t->yonetim_model->get(array(
                "kullanici_id" => $user->kullanici_id
            ));

            if ($kullanici)
                return $kullanici;
            else
                return false;
        }
    }
}

if (!function_exists('admin_kullanicicek')) {
    function admin_kullanicicek()
    {
        $t = &get_instance();
        if ($t->session->userdata("kullanici")) {

            $user = $t->session->userdata("kullanici");

            $kullanici = $t->yonetim_model->get(array("kullanici_id" => $user->kullanici_id));

            if ($kullanici)
                return $kullanici;
            else
                return false;
        }
    }
}

if (!function_exists('ayarlar')) {
    function ayarlar()
    {
        $ci = &get_instance();
        return $ci->home_model->ayarlar();
    }
}

if (!function_exists('zamanCevir')) {
    function zamanCevir($zaman)
    {
        $zaman = strtotime($zaman);
        $zaman_farki = time() - $zaman;
        $saniye = $zaman_farki;
        $dakika = round($zaman_farki / 60);
        $saat = round($zaman_farki / 3600);
        $gun = round($zaman_farki / 86400);
        $hafta = round($zaman_farki / 604800);
        $ay = round($zaman_farki / 2419200);
        $yil = round($zaman_farki / 29030400);
        if ($saniye < 60) {
            if ($saniye == 0) {
                return "Az Önce";
            } else {
                return $saniye . ' Saniye Önce';
            }
        } else if ($dakika < 60) {
            return $dakika . ' Dakika Önce';
        } else if ($saat < 24) {
            return $saat . ' Saat Önce';
        } else if ($gun < 7) {
            return $gun . ' Gün Önce';
        } else if ($hafta < 4) {
            return $hafta . ' Hafta Önce';
        } else if ($ay < 12) {
            return $ay . ' Ay Önce';
        } else {
            return $yil . ' Yıl Önce';
        }
    }
}

if (!function_exists('time_ago')) {
    function time_ago($time)
    {
        $periods = array("sn", "dk", "sn", "gün", "hafta", "ay", "yıl", "decade");
        $lengths = array("60", "60", "24", "7", "4.35", "12", "10");

        $now = strtotime(date('Y-m-d H:i:s'), time());
        $time = strtotime($time, time());
        $difference     = $now - $time;
        $tense         = "önce";

        for ($j = 0; $difference >= $lengths[$j] && $j < count($lengths) - 1; $j++) {
            $difference /= $lengths[$j];
        }

        $difference = round($difference);

        if ($difference != 1) {
            $periods[$j] .= "";
        }

        return "$difference$periods[$j] ";
    }
}

if (!function_exists('seo')) {
    function seo($str, $options = array())
    {
        $str = mb_convert_encoding((string)$str, 'UTF-8', mb_list_encodings());
        $defaults = array(
            'delimiter' => '-',
            'limit' => null,
            'lowercase' => true,
            'replacements' => array(),
            'transliterate' => true
        );
        $options = array_merge($defaults, $options);
        $char_map = array(
            // Latin
            'À' => 'A', 'Á' => 'A', 'Â' => 'A', 'Ã' => 'A', 'Ä' => 'A', 'Å' => 'A', 'Æ' => 'AE', 'Ç' => 'C',
            'È' => 'E', 'É' => 'E', 'Ê' => 'E', 'Ë' => 'E', 'Ì' => 'I', 'Í' => 'I', 'Î' => 'I', 'Ï' => 'I',
            'Ð' => 'D', 'Ñ' => 'N', 'Ò' => 'O', 'Ó' => 'O', 'Ô' => 'O', 'Õ' => 'O', 'Ö' => 'O', 'Ő' => 'O',
            'Ø' => 'O', 'Ù' => 'U', 'Ú' => 'U', 'Û' => 'U', 'Ü' => 'U', 'Ű' => 'U', 'Ý' => 'Y', 'Þ' => 'TH',
            'ß' => 'ss',
            'à' => 'a', 'á' => 'a', 'â' => 'a', 'ã' => 'a', 'ä' => 'a', 'å' => 'a', 'æ' => 'ae', 'ç' => 'c',
            'è' => 'e', 'é' => 'e', 'ê' => 'e', 'ë' => 'e', 'ì' => 'i', 'í' => 'i', 'î' => 'i', 'ï' => 'i',
            'ð' => 'd', 'ñ' => 'n', 'ò' => 'o', 'ó' => 'o', 'ô' => 'o', 'õ' => 'o', 'ö' => 'o', 'ő' => 'o',
            'ø' => 'o', 'ù' => 'u', 'ú' => 'u', 'û' => 'u', 'ü' => 'u', 'ű' => 'u', 'ý' => 'y', 'þ' => 'th',
            'ÿ' => 'y',
            // Latin symbols
            '©' => '(c)',
            // Greek
            'Α' => 'A', 'Β' => 'B', 'Γ' => 'G', 'Δ' => 'D', 'Ε' => 'E', 'Ζ' => 'Z', 'Η' => 'H', 'Θ' => '8',
            'Ι' => 'I', 'Κ' => 'K', 'Λ' => 'L', 'Μ' => 'M', 'Ν' => 'N', 'Ξ' => '3', 'Ο' => 'O', 'Π' => 'P',
            'Ρ' => 'R', 'Σ' => 'S', 'Τ' => 'T', 'Υ' => 'Y', 'Φ' => 'F', 'Χ' => 'X', 'Ψ' => 'PS', 'Ω' => 'W',
            'Ά' => 'A', 'Έ' => 'E', 'Ί' => 'I', 'Ό' => 'O', 'Ύ' => 'Y', 'Ή' => 'H', 'Ώ' => 'W', 'Ϊ' => 'I',
            'Ϋ' => 'Y',
            'α' => 'a', 'β' => 'b', 'γ' => 'g', 'δ' => 'd', 'ε' => 'e', 'ζ' => 'z', 'η' => 'h', 'θ' => '8',
            'ι' => 'i', 'κ' => 'k', 'λ' => 'l', 'μ' => 'm', 'ν' => 'n', 'ξ' => '3', 'ο' => 'o', 'π' => 'p',
            'ρ' => 'r', 'σ' => 's', 'τ' => 't', 'υ' => 'y', 'φ' => 'f', 'χ' => 'x', 'ψ' => 'ps', 'ω' => 'w',
            'ά' => 'a', 'έ' => 'e', 'ί' => 'i', 'ό' => 'o', 'ύ' => 'y', 'ή' => 'h', 'ώ' => 'w', 'ς' => 's',
            'ϊ' => 'i', 'ΰ' => 'y', 'ϋ' => 'y', 'ΐ' => 'i',
            // Turkish
            'Ş' => 'S', 'İ' => 'I', 'Ç' => 'C', 'Ü' => 'U', 'Ö' => 'O', 'Ğ' => 'G',
            'ş' => 's', 'ı' => 'i', 'ç' => 'c', 'ü' => 'u', 'ö' => 'o', 'ğ' => 'g',
            // Russian
            'А' => 'A', 'Б' => 'B', 'В' => 'V', 'Г' => 'G', 'Д' => 'D', 'Е' => 'E', 'Ё' => 'Yo', 'Ж' => 'Zh',
            'З' => 'Z', 'И' => 'I', 'Й' => 'J', 'К' => 'K', 'Л' => 'L', 'М' => 'M', 'Н' => 'N', 'О' => 'O',
            'П' => 'P', 'Р' => 'R', 'С' => 'S', 'Т' => 'T', 'У' => 'U', 'Ф' => 'F', 'Х' => 'H', 'Ц' => 'C',
            'Ч' => 'Ch', 'Ш' => 'Sh', 'Щ' => 'Sh', 'Ъ' => '', 'Ы' => 'Y', 'Ь' => '', 'Э' => 'E', 'Ю' => 'Yu',
            'Я' => 'Ya',
            'а' => 'a', 'б' => 'b', 'в' => 'v', 'г' => 'g', 'д' => 'd', 'е' => 'e', 'ё' => 'yo', 'ж' => 'zh',
            'з' => 'z', 'и' => 'i', 'й' => 'j', 'к' => 'k', 'л' => 'l', 'м' => 'm', 'н' => 'n', 'о' => 'o',
            'п' => 'p', 'р' => 'r', 'с' => 's', 'т' => 't', 'у' => 'u', 'ф' => 'f', 'х' => 'h', 'ц' => 'c',
            'ч' => 'ch', 'ш' => 'sh', 'щ' => 'sh', 'ъ' => '', 'ы' => 'y', 'ь' => '', 'э' => 'e', 'ю' => 'yu',
            'я' => 'ya',
            // Ukrainian
            'Є' => 'Ye', 'І' => 'I', 'Ї' => 'Yi', 'Ґ' => 'G',
            'є' => 'ye', 'і' => 'i', 'ї' => 'yi', 'ґ' => 'g',
            // Czech
            'Č' => 'C', 'Ď' => 'D', 'Ě' => 'E', 'Ň' => 'N', 'Ř' => 'R', 'Š' => 'S', 'Ť' => 'T', 'Ů' => 'U',
            'Ž' => 'Z',
            'č' => 'c', 'ď' => 'd', 'ě' => 'e', 'ň' => 'n', 'ř' => 'r', 'š' => 's', 'ť' => 't', 'ů' => 'u',
            'ž' => 'z',
            // Polish
            'Ą' => 'A', 'Ć' => 'C', 'Ę' => 'e', 'Ł' => 'L', 'Ń' => 'N', 'Ó' => 'o', 'Ś' => 'S', 'Ź' => 'Z',
            'Ż' => 'Z',
            'ą' => 'a', 'ć' => 'c', 'ę' => 'e', 'ł' => 'l', 'ń' => 'n', 'ó' => 'o', 'ś' => 's', 'ź' => 'z',
            'ż' => 'z',
            // Latvian
            'Ā' => 'A', 'Č' => 'C', 'Ē' => 'E', 'Ģ' => 'G', 'Ī' => 'i', 'Ķ' => 'k', 'Ļ' => 'L', 'Ņ' => 'N',
            'Š' => 'S', 'Ū' => 'u', 'Ž' => 'Z',
            'ā' => 'a', 'č' => 'c', 'ē' => 'e', 'ģ' => 'g', 'ī' => 'i', 'ķ' => 'k', 'ļ' => 'l', 'ņ' => 'n',
            'š' => 's', 'ū' => 'u', 'ž' => 'z'
        );
        $str = preg_replace(array_keys($options['replacements']), $options['replacements'], $str);
        if ($options['transliterate']) {
            $str = str_replace(array_keys($char_map), $char_map, $str);
        }
        $str = preg_replace('/[^\p{L}\p{Nd}]+/u', $options['delimiter'], $str);
        $str = preg_replace('/(' . preg_quote($options['delimiter'], '/') . '){2,}/', '$1', $str);
        $str = mb_substr($str, 0, ($options['limit'] ? $options['limit'] : mb_strlen($str, 'UTF-8')), 'UTF-8');
        $str = trim($str, $options['delimiter']);
        return $options['lowercase'] ? mb_strtolower($str, 'UTF-8') : $str;
    }
}

if (!function_exists('aylar')) {
    function aylar($ay)
    {
        $aylar = array(

            1 => "OCAK",

            2 => "ŞUBAT",

            3 => "MART",

            4 => "NİSAN",

            5 => "MAYIS",

            6 => "HAZİRAN",

            7 => "TEMMUZ",

            8 => "AĞUSTOS",

            9 => "EYLÜL",

            10 => "EKİM",

            11 => "KASIM",

            12 => "ARALIK"

        );

        return $aylar[$ay];
    }
}

if (!function_exists('populerkategori')) {
    function populerkategori($ayarlar)
    {
        $t = &get_instance();
        $where = $t->home_model->kategoriler(array("kategori_durum" => 1, "kategori_populer" => 1), $ayarlar);
        return $where;
    }
}

if (!function_exists('kategoricek')) {
    function kategoricek()
    {
        $t = &get_instance();
        $where = $t->home_model->kategoridetay(array("kategori_durum" => 1));
        return $where;
    }
}

if (!function_exists('onekategori')) {
    function onekategori()
    {
        $t = &get_instance();
        $where = $t->home_model->kategoridetay(array("kategori_durum" => 1, "kategori_onecikart" => 1));
        return $where;
    }
}

if (!function_exists('menuler')) {
    function menuler()
    {
        $t = &get_instance();
        $where = $t->destek_model->menucek(array("kategori_durum" => 1));
        return $where;
    }
}

if (!function_exists('fmenuler')) {
    function fmenuler()
    {
        $t = &get_instance();
        $where = $t->destek_model->fmenucek(array("kategori_durum" => 1));
        return $where;
    }
}


if (!function_exists('randomKategori')) {
    function randomKategori()
    {
        $t = &get_instance();
        $where = $t->destek_model->randomKategori(array("kategori_durum" => 1));
        return $where;
    }
}

if (!function_exists('sayfalar')) {
    function sayfalar()
    {
        $t = &get_instance();
        $where = $t->destek_model->sayfacek(array("sayfa_durum" => 1, "sayfa_konum" => 1));
        return $where;
    }
}

if (!function_exists('footersayfa')) {
    function footersayfa()
    {
        $t = &get_instance();
        $where = $t->destek_model->fsayfacek(array("sayfa_durum" => 1, "sayfa_konum" => 0));
        return $where;
    }
}

if (!function_exists('footermenusayfa')) {
    function footermenusayfa($konum)
    {
        $t = &get_instance();
        $where = $t->destek_model->fsayfacek(array("sayfa_durum" => 1, "sayfa_konum" => $konum));
        return $where;
    }
}

if (!function_exists('uretken')) {
    function uretken($len)
    {

        $karaktersizler = strtoupper("abcdefghijklmnopqrstuvwxyz0123456789");
        $xx = "";
        $max = strlen($karaktersizler) - 1;
        for ($i = 0; $i < $len; $i++) {
            $xx .= $karaktersizler[rand(0, $max)];
        }
        return $xx;
    }
}

if (!function_exists('sayfalar2')) {
    function sayfalar2()
    {
        $t = &get_instance();
        $where = $t->destek_model->sayfalar(array());
        return $where;
    }
}

if (!function_exists('sss')) {
    function sss()
    {
        $t = &get_instance();
        $where = $t->destek_model->sss(array());
        return $where;
    }
}

if (!function_exists('kullanicilar')) {
    function kullanicilar($type)
    {
        $t = &get_instance();
        $where = array();
        if($type == 1) {
            $where['magaza.magaza_id !='] = NULL;
        } else if($type == 2) {
            $where["kullanici.kullanici_bayi"] = 1;
        }
        $where = $t->destek_model->kullanicilar($where);
        return $where;
    }
}

if (!function_exists('detaykategori')) {
    function detaykategori($id)
    {
        $t = &get_instance();
        $where = $t->destek_model->detaykategori(array("kategori_id" => $id));
        return $where;
    }
}

if (!function_exists('isletimsistemi')) {
    function isletimsistemi()
    {
        $tespit = $_SERVER['HTTP_USER_AGENT'];
        if (stristr($tespit, "Windows 95")) {
            $os = "Windows 95";
        } elseif (stristr($tespit, "Windows 98")) {
            $os = "Windows 98";
        } elseif (stristr($tespit, "Windows NT 5.0")) {
            $os = "Windows 2000";
        } elseif (stristr($tespit, "Windows NT 5.1")) {
            $os = "Windows XP";
        } elseif (stristr($tespit, "Windows NT 6.0")) {
            $os = "Windows Vista";
        } elseif (stristr($tespit, "Windows NT 6.1")) {
            $os = "Windows 7";
        } elseif (stristr($tespit, "Windows NT 6.2")) {
            $os = "Windows 8";
        } elseif (stristr($tespit, "Windows NT 10.0")) {
            $os = "Windows 10";
        } elseif (stristr($tespit, "Mac")) {
            $os = "Mac";
        } elseif (stristr($tespit, "Linux")) {
            $os = "Linux";
        } else {
            $os = "Bilinmiyor ?";
        }
        return $os;
    }
}

if (!function_exists('tarayici')) {
    function tarayici()
    {
        $tespit2 = $_SERVER['HTTP_USER_AGENT'];
        if (stristr($tespit2, "MSIE")) {
            $tarayici = "Internet Explorer";
        } elseif (stristr($tespit2, "Firefox")) {
            $tarayici = "Mozilla Firefox";
        } elseif (stristr($tespit2, "YaBrowser")) {
            $tarayici = "Yandex Browser";
        } elseif (stristr($tespit2, "Chrome")) {
            $tarayici = "Google Chrome";
        } elseif (stristr($tespit2, "Safari")) {
            $tarayici = "Safari";
        } elseif (stristr($tespit2, "Opera")) {
            $tarayici = "Opera";
        } else {
            $tarayici = "Bilinmiyor";
        }
        return $tarayici;
    }
}

if (!function_exists('admin_url')) {
    function admin_url()
    {
        require APPPATH . "config/route_slugs.php";
        return $custom_slug_array["admin"] . "/";
    }
}

if (!function_exists('safadmin_url')) {
    function safadmin_url()
    {
        require APPPATH . "config/route_slugs.php";
        return $custom_slug_array["admin"];
    }
}

if (!function_exists('curl_resim_kaydet')) {
    function curl_resim_kaydet($url, $saveto)
    {
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_BINARYTRANSFER, 1);
        $raw = curl_exec($ch);
        curl_close($ch);
        if (file_exists($saveto)) {
            unlink($saveto);
        }
        $fp = fopen($saveto, 'x');
        fwrite($fp, $raw);
        fclose($fp);
    }
}

if (!function_exists('random_color_part')) {
    function random_color_part()
    {
        return str_pad(dechex(mt_rand(0, 255)), 2, '0', STR_PAD_LEFT);
    }
}

if (!function_exists('arkaplan_color')) {
    function arkaplan_color()
    {
        return random_color_part() . random_color_part() . random_color_part();
    }
}

if (!function_exists('getIPAddress')) {
    function getIPAddress()
    {
        if (getenv("HTTP_CLIENT_IP"))
            $ip = getenv("HTTP_CLIENT_IP");
        else if (getenv("HTTP_X_FORWARDED_FOR")) {
            $ip = getenv("HTTP_X_FORWARDED_FOR");
            if (strstr($ip, ',')) {
                $tmp = explode(',', $ip);
                $ip = trim($tmp[0]);
            }
        } else
            $ip = getenv("REMOTE_ADDR");
        return $ip;
    }
}

if (!function_exists('kisalt')) {
    function kisalt($kelime, $str = 10)
    {
        if (strlen($kelime) > $str) {
            if (function_exists("mb_substr")) $kelime = mb_substr($kelime, 0, $str, "UTF-8") . '..';
            else $kelime = substr($kelime, 0, $str) . '..';
        }
        return $kelime;
    }
}

if (!function_exists('favoriekle')) {
    function favoriekle($kullanici_id, $firma_id)
    {
        $ci = &get_instance();
        return $ci->destek_model->favoriekle($kullanici_id, $firma_id);
    }
}

if (!function_exists('magaza_check')) {
    function magaza_check()
    {
        $ci = &get_instance();
        $kullanici = kullanicicek();
        $magaza_check = $ci->magaza_model->magaza_check($kullanici->kullanici_id);
        if ($magaza_check) {
            return true;
        } else {
            return false;
        }
    }
}

if (!function_exists('sponsor_check')) {
    function sponsor_check()
    {
        $ci = &get_instance();
        $kullanici = kullanicicek();
        $sponsor_check = $ci->magaza_model->sponsor_check($kullanici->kullanici_id);
        if ($sponsor_check) {
            return true;
        } else {
            return false;
        }
    }
}

if (!function_exists('admin_magaza_check')) {
    function admin_magaza_check($id)
    {
        $ci = &get_instance();
        $kullanici = kullanicicek();
        $magaza_check = $ci->magaza_model->magaza_check($id);
        if ($magaza_check) {
            return true;
        } else {
            return false;
        }
    }
}

if (!function_exists('fetchCategoryTree')) {
    function fetchCategoryTree($parent = 0, $spacing = '', $user_tree_array = '')
    {
        if (!is_array($user_tree_array)) {
            $user_tree_array = array();
        }
        $ci = &get_instance();
        $kategori = $ci->db->where(array('parent' => $parent))->order_by('kategori_sira', 'ASC')->get('kategori')->result();
        if ($kategori) {
            foreach ($kategori as $kat) {
                $user_tree_array[] = array("id" => $kat->kategori_id, "komisyon" => $kat->komisyon, "name" => $spacing . $kat->kategori_ad);
                $user_tree_array = fetchCategoryTree($kat->kategori_id, $spacing . '--', $user_tree_array);
            }
        }
        return $user_tree_array;
    }
}

if (!function_exists('fetchCategoryTreeList')) {
    function fetchCategoryTreeList($parent = 0, $user_tree_array = '')
    {

        if (!is_array($user_tree_array)) {
            $user_tree_array = array();
        }
        $ci = &get_instance();
        $dropdowns = $ci->db->where(array('mainid' => $parent))->order_by("sort ASC")->get('dropdowns')->result();
        
        if ($dropdowns) {
            $user_tree_array[] = '<div class="dropdown-menu dropdown-image" aria-labelledby="navbarDropdown"><div class="dropdown-items">';
            foreach ($dropdowns as $kat) {
                $user_tree_array[] = '<a class="dropdown-item" href="' . $kat->link . '" title="' . $kat->heading . '">';
                $user_tree_array[] = '<img src="/uploads/img/' . $kat->img . '" alt="' . $kat->heading . '" title="' . $kat->heading . '">';
                $user_tree_array[] = '<span class="text-white">' . $kat->heading . '</span>';
                $user_tree_array[] = '</a>';
            }
            $user_tree_array[] = "</div></div>";
        }

        return $user_tree_array;
    }
}

if (!function_exists('getheaders')) {
    function getheaders()
    {
        $t = &get_instance();
        $where = $t->db->get('headers')->result();
        return $where;
    }
}
if (!function_exists('getheaderswhere')) {
    function getheaderswhere($arg)
    {
        $t = &get_instance();
        return $t->db->where(array("dropdown" => $arg))->get('headers')->result();
    }
}

if (!function_exists('getheadersdrp')) {
    function getheadersdrp($arg)
    {
        $t = &get_instance();
        return $t->db->where(array("id" => $arg))->get('headers')->result();
    }
}
if (!function_exists('getdropdowns')) {
    function getdropdowns(){
        $t = &get_instance();
        return $t->db->order_by('id DESC')->get('dropdowns')->result();
    }
}

if (!function_exists('getsubheader')) {
    function getsubheader(){
        $t = &get_instance();
        return $t->db->get('subheaders')->result();
    }
}

if (!function_exists('fetchCategoryTreeMenu')) {
    function fetchCategoryTreeMenu($parent = 0, $user_tree_array = '')
    {
        if (!is_array($user_tree_array)) {
            $user_tree_array = array();
        }
        
        $ci = &get_instance();
        
        // Headers sorgusu
        $query = $ci->db->where('status', 1)
                        ->order_by('sort', 'ASC')
                        ->get('headers');
                        
        if (!$query || $query->num_rows() == 0) {
            // Varsayılan menü öğesi
            return array('<li class="nav-item"><a class="nav-link" href="'.base_url().'">Ana Sayfa</a></li>');
        }
        
        $headers = $query->result();
        
        foreach ($headers as $kat) {
            if($kat->dropdown == 1){
                $icon = !empty($kat->icon) ? 
                    '<i style="margin: auto; margin-right: 5px;" class="' . $kat->icon . '"></i>' : 
                    (!empty($kat->pngicon) ? 
                        '<img title="'.$kat->heading.'" src="' . base_url($kat->pngicon) . '" class="" style="margin:auto; margin-right:5px; max-height:16px; max-width:16px;" loading="lazy">' : 
                        '');
                
                $user_tree_array[] = '<li class="nav-item dropdown full-width d-none d-sm-block">';
                $user_tree_array[] = '<a class="nav-link dropdown-toggle ' . ($kat->pop == 1 ? 'custom-color' : '') . '" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" href="' . $kat->link . '">' . $icon;
                $user_tree_array[] = $kat->heading;
                $user_tree_array[] = '</a>';
                $user_tree_array = fetchCategoryTreeList($kat->id, $user_tree_array);
                $user_tree_array[] = "</li>";
            } else {
                $icon = !empty($kat->icon) ? 
                    '<i style="margin: auto; margin-right: 5px;" class="' . $kat->icon . '"></i>' : 
                    (!empty($kat->pngicon) ? 
                        '<img title="'.$kat->heading.'" src="' . base_url($kat->pngicon) . '" class="" style="margin:auto; margin-right:5px; max-height:16px;" loading="lazy">' : 
                        '');
                
                $user_tree_array[] = '<li class="nav-item full-width d-none d-sm-block">';
                $user_tree_array[] = '<a class="nav-link ' . ($kat->pop == 1 ? 'custom-color' : '') . '" href="' . $kat->link . '" aria-haspopup="true" aria-expanded="false">' . $icon;
                $user_tree_array[] = $kat->heading;
                $user_tree_array[] = '</a>';
                $user_tree_array[] = "</li>";
            }
        }

        return $user_tree_array;
    }
}
if (!function_exists('fetchCategoryTreeMenu2')) {
    function fetchCategoryTreeMenu2($parent = 0, $user_tree_array = '')
    {

        if (!is_array($user_tree_array)) {
            $user_tree_array = array();
        }
        $ci = &get_instance();
        $kategori = $ci->db->where(array('parent' => $parent))->order_by('kategori_sira', 'ASC')->get('kategori')->result();

        if ($kategori) {
            foreach ($kategori as $kat) {
                $user_tree_array[] = '<a  href="' . base_url("kategori/" . $kat->kategori_seo) . '">';
                $user_tree_array[] = $kat->kategori_ad;
                $user_tree_array[] = '</a>';
                $user_tree_array = fetchCategoryTreeList($kat->kategori_id, $user_tree_array);
            }
        }

        return $user_tree_array;
    }
}



//if (!function_exists('fetchCategoryTreeMenu')) {
//    function fetchCategoryTreeMenu($parent = 0, $user_tree_array = '')
//    {
//
//        if (!is_array($user_tree_array)) {
//            $user_tree_array = array();
//        }
//        $ci =& get_instance();
//        $kategori = $ci->db->where(array('parent' => $parent))->order_by('kategori_sira', 'ASC')->get('kategori')->result();
//
//        if ($kategori) {
//            $user_tree_array[] = '<div class="dropdown-menu dropdown-image" aria-labelledby="navbarDropdown"><div class="dropdown-items">';
//            foreach ($kategori as $kat) {
//                $user_tree_array[] = '<a class="dropdown-item" href="' . base_url("kategori/" . $kat->kategori_seo) . '" title="'.$kat->kategori_ad.'">';
//                $user_tree_array[] = '<img src="' . base_url($kat->kategori_resim) . '" alt="'.$kat->kategori_ad.'" title="'.$kat->kategori_ad.'">';
//                $user_tree_array[] = '<span>'.$kat->kategori_ad.'</span>';
//                $user_tree_array[] = '</a>';
//            }
//            $user_tree_array[] = "</div>
//                    </div>";
//        }
//
//        return $user_tree_array;
//    }
//}

if (!function_exists('tcno_dogrula')) {
    function tcno_dogrula($bilgiler)
    {
        $gonder = '<?xml version="1.0" encoding="utf-8"?>
		<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
		<soap:Body>
		<TCKimlikNoDogrula xmlns="http://tckimlik.nvi.gov.tr/WS">
		<TCKimlikNo>' . $bilgiler["tcno"] . '</TCKimlikNo>
		<Ad>' . $bilgiler["isim"] . '</Ad>
		<Soyad>' . $bilgiler["soyisim"] . '</Soyad>
		<DogumYili>' . $bilgiler["dogumyili"] . '</DogumYili>
		</TCKimlikNoDogrula>
		</soap:Body>
		</soap:Envelope>';

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "https://tckimlik.nvi.gov.tr/Service/KPSPublic.asmx");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_HEADER, FALSE);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $gonder);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'POST /Service/KPSPublic.asmx HTTP/1.1',
            'Host: tckimlik.nvi.gov.tr',
            'Content-Type: text/xml; charset=utf-8',
            'SOAPAction: "http://tckimlik.nvi.gov.tr/WS/TCKimlikNoDogrula"',
            'Content-Length: ' . strlen($gonder)
        ));
        $gelen = curl_exec($ch);
        curl_close($ch);

        return strip_tags($gelen);
    }
}

if (!function_exists('yazi_boyut')) {
    function yazi_boyut($keyword, $transform = 'lowercase')
    {
        $low = array('a', 'b', 'c', 'ç', 'd', 'e', 'f', 'g', 'ğ', 'h', 'ı', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'ö', 'p', 'r', 's', 'ş', 't', 'u', 'ü', 'v', 'y', 'z', 'q', 'w', 'x');
        $upp = array('A', 'B', 'C', 'Ç', 'D', 'E', 'F', 'G', 'Ğ', 'H', 'I', 'İ', 'J', 'K', 'L', 'M', 'N', 'O', 'Ö', 'P', 'R', 'S', 'Ş', 'T', 'U', 'Ü', 'V', 'Y', 'Z', 'Q', 'W', 'X');

        if ($transform == 'uppercase' or $transform == 'u') {
            $keyword = str_replace($low, $upp, $keyword);
            $keyword = function_exists('mb_strtoupper') ? mb_strtoupper($keyword) : $keyword;
        } elseif ($transform == 'lowercase' or $transform == 'l') {

            $keyword = str_replace($upp, $low, $keyword);
            $keyword = function_exists('mb_strtolower') ? mb_strtolower($keyword) : $keyword;
        }

        return $keyword;
    }
}

if (!function_exists('kat_urunsay')) {
    function kat_urunsay($id)
    {
        $t = &get_instance();
        $say = $t->magaza_model->kat_urunsay($id);
        return $say;
    }
}

if (!function_exists('magaza_urunsay')) {
    function magaza_urunsay($id,$seo)
    {
        $t = &get_instance();
        $say = $t->magaza_model->magaza_urunsay(array("urunler.kullanici_id" => $id,"magaza.magaza_seo"=>$seo));
        return $say;
    }
}

if (!function_exists('urunsay')) {
    function urunsay($id)
    {
        $t = &get_instance();
        $say = $t->magaza_model->urunsay(array("kullanici_id" => $id));
        return $say;
    }
}

if (!function_exists('urunsay_magza')) {
    function urunsay_magza($id)
    {
        $t = &get_instance();
        $say = $t->magaza_model->urunsay(array("magaza_id" => $id));
        return $say;
    }
}

if (!function_exists('resize_img')) {
    function resize_img($target, $newcopy, $w, $h, $ext)
    {
        list($w_orig, $h_orig) = getimagesize($target);
        $scale_ratio = $w_orig / $h_orig;
        if (($w / $h) > $scale_ratio) {
            $w = $h * $scale_ratio;
        } else {
            $h = $w / $scale_ratio;
        }
        $img = "";
        $ext = strtolower($ext);
        if ($ext == "gif") {
            $img = imagecreatefromgif($target);
        } else if ($ext == "png") {
            $img = imagecreatefrompng($target);
        } else {
            $img = imagecreatefromjpeg($target);
        }
        $tci = imagecreatetruecolor($w, $h);
        // imagecopyresampled(dst_img, src_img, dst_x, dst_y, src_x, src_y, dst_w, dst_h, src_w, src_h)
        imagecopyresampled($tci, $img, 0, 0, 0, 0, $w, $h, $w_orig, $h_orig);
        imagejpeg($tci, $newcopy, 80);
    }
}

if (!function_exists('resize_img_specific')) {
    function resize_img_specific($target, $newcopy, $w, $h, $ext)
    {
        list($w_orig, $h_orig) = getimagesize($target);
        $img = "";
        $ext = strtolower($ext);
        if ($ext == "gif") {
            $img = imagecreatefromgif($target);
        } else if ($ext == "png") {
            $img = imagecreatefrompng($target);
        } else {
            $img = imagecreatefromjpeg($target);
        }
        $tci = imagecreatetruecolor($w, $h);

        // start changes
        switch ($ext) {

            case 'gif':
            case 'png':
                // integer representation of the color black (rgb: 0,0,0)
                $background = imagecolorallocate($tci , 0, 0, 0);
                // removing the black from the placeholder
                imagecolortransparent($tci, $background);

                // turning off alpha blending (to ensure alpha channel information
                // is preserved, rather than removed (blending with the rest of the
                // image in the form of black))
                imagealphablending($tci, false);

                // turning on alpha channel information saving (to ensure the full range
                // of transparency is preserved)
                imagesavealpha($tci, true);
                break;
            default:
                break;
        }
        // imagecopyresampled(dst_img, src_img, dst_x, dst_y, src_x, src_y, dst_w, dst_h, src_w, src_h)
        imagecopyresampled($tci, $img, 0, 0, 0, 0, $w, $h, $w_orig, $h_orig);
        imagepng($tci, $newcopy);
    }
}

if (!function_exists('tarihCevir')) {
    function tarihCevir($tarih)
    {
        return date("d.m.Y H:i", strtotime($tarih));
    }
}

if (!function_exists('ayli_tarih')) {
    function ayli_tarih($tarih)
    {
        $verilenTarihSaat = $tarih;

        $dateTime = new DateTime($verilenTarihSaat);

        $turkceAylar = [
            '01' => 'Ocak',
            '02' => 'Şubat',
            '03' => 'Mart',
            '04' => 'Nisan',
            '05' => 'Mayıs',
            '06' => 'Haziran',
            '07' => 'Temmuz',
            '08' => 'Ağustos',
            '09' => 'Eylül',
            '10' => 'Ekim',
            '11' => 'Kasım',
            '12' => 'Aralık',
        ];

        $gun = $dateTime->format('d');
        $ay = $turkceAylar[$dateTime->format('m')];
        $yil = $dateTime->format('Y');
        $yeniTarihFormati = $gun . ' ' . $ay . ' ' . $yil;

        return $yeniTarihFormati;
    }
}

if (!function_exists('komisyon_hesap')) {
    function komisyon_hesap($fiyat)
    {
        $ayarlar = ayarlar();
        $oran = $fiyat * ($ayarlar->komisyon / 100);
        return number_format($fiyat - $oran, 2);
    }
}

if (!function_exists('kategori_komisyon_hesap')) {
    function kategori_komisyon_hesap($fiyat, $komisyon)
    {
        $oran = $fiyat * ($komisyon / 100);
        return number_format($oran, 2);
    }
}

if (!function_exists('filesize_formatted')) {
    function filesize_formatted($path)
    {
        $size = filesize($path);
        $units = array('B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB');
        $power = $size > 0 ? floor(log($size, 1024)) : 0;
        return number_format($size / pow(1024, $power), 2, '.', ',') . ' ' . $units[$power];
    }
}

if (!function_exists('kullanici_ad')) {
    function kullanici_ad($id)
    {
        $t = &get_instance();
        $kullanici = $t->yonetim_model->get(array("kullanici_id" => $id));
        return $kullanici->kullanici_ad;
    }
}

if (!function_exists('magaza')) {
    function magaza($id)
    {
        $t = &get_instance();
        return $t->magaza_model->magaza(array("kullanici_id" => $id));
    }
}

if (!function_exists('magaza_bilgi')) {
    function magaza_bilgi($id)
    {
        $t = &get_instance();
        return $t->magaza_model->magaza(array("magaza_id" => $id));
    }
}

if (!function_exists('magaza_kbilgi')) {
    function magaza_kbilgi($id)
    {
        $t = &get_instance();
        return $t->magaza_model->magaza(array("kullanici_id" => $id));
    }
}

if (!function_exists('magaza_bilgi_uniq')) {
    function magaza_bilgi_uniq($id)
    {
        $t = &get_instance();
        return $t->magaza_model->magaza(array("magaza_uniq" => $id));
    }
}

if (!function_exists('sehir_ad')) {
    function sehir_ad($id)
    {
        $t = &get_instance();
        $il = $t->siparis_model->sehir($id);
        return $il->il_adi;
    }
}

if (!function_exists('ilce_ad')) {
    function ilce_ad($id)
    {
        $t = &get_instance();
        $il = $t->siparis_model->ilce($id);
        return $il->ilce_adi;
    }
}

if (!function_exists('urun_ad')) {
    function urun_ad($id)
    {
        $t = &get_instance();
        return $t->magaza_model->urun(array("urun_id" => $id))->urun_ad;
    }
}

if (!function_exists('urun_bilgiler')) {
    function urun_bilgiler($id)
    {
        $t = &get_instance();
        return $t->magaza_model->urun(array("urun_id" => $id));
    }
}

if (!function_exists('teslimat_kontrol')) {
    function teslimat_kontrol($siparis_id)
    {
        $t = &get_instance();
        return $t->siparis_model->teslimat($siparis_id);
    }
}

if (!function_exists('teslimat_kontrol2')) {
    function teslimat_kontrol2($siparis_id)
    {
        $t = &get_instance();
        return $t->siparis_model->teslimat_kontrol($siparis_id);
    }
}

if (!function_exists('kullanici_bilgi')) {
    function kullanici_bilgi($kullanici_id)
    {
        $t = &get_instance();
        return $t->yonetim_model->get(array('kullanici_id' => $kullanici_id));
    }
}

if (!function_exists('get_kategori')) {
    function get_kategori($katid)
    {
        $ci = &get_instance();
        return $ci->yonetim_model->get_kategoriget(array("kategori_id" => $katid));
    }
}

if (!function_exists('siparis_say')) {
    function siparis_say($id)
    {
        $t = &get_instance();
        $say = $t->siparis_model->siparis_say(array("kullanici_id" => $id));
        return $say;
    }
}
if (!function_exists('siparis_satis_say')) {
    function siparis_satis_say($id)
    {
        $t = &get_instance();
        $say = $t->siparis_model->siparis_satis_say(array("kullanici_id" => $id));
        return $say;
    }
}

if (!function_exists('bakiye_say')) {
    function bakiye_say($id)
    {
        $t = &get_instance();
        $say = $t->bakiye_model->bakiye_say(array("kullanici_id" => $id));
        return $say;
    }
}

if (!function_exists('yorum_kontrol')) {
    function yorum_kontrol($id, $siparis_no)
    {
        $t = &get_instance();
        $say = $t->siparis_model->yorum_say(array("kullanici_id" => $id, 'siparis_no' => $siparis_no));
        return $say;
    }
}

if (!function_exists('yorum_say')) {
    function yorum_say($id)
    {
        $t = &get_instance();
        $say = $t->siparis_model->yorum_say(array("urun_id" => $id));
        return $say;
    }
}

if (!function_exists('yorum')) {
    function yorum($id, $siparis_no)
    {
        $t = &get_instance();
        $say = $t->siparis_model->yorum(array("kullanici_id" => $id, 'siparis_no' => $siparis_no));
        return $say;
    }
}

if (!function_exists('destek_say')) {
    function destek_say($id)
    {
        $t = &get_instance();
        $say = $t->siparis_model->destek_say(array("kullanici_id" => $id));
        return $say;
    }
}

if (!function_exists('magaza_yorumsay')) {
    function magaza_yorumsay()
    {
        $t = &get_instance();
        $say = $t->magaza_model->magaza_yorumsay();
        return $say;
    }
}

if (!function_exists('yorum_yildiz')) {
    function yorum_yildiz($sayi)
    {

        if ($sayi == 1) {
            return '<i class="mdi mdi-star mr-n1 mb-2 text-warning font-size-xs"></i>
													<i class="mdi mdi-star-outline mr-n1 mb-2 text-warning font-size-xs"></i>
													<i class="mdi mdi-star-outline mr-n1 mb-2 text-warning font-size-xs"></i>
													<i class="mdi mdi-star-outline mr-n1 mb-2 text-warning font-size-xs"></i>
													<i class="mdi mdi-star-outline mb-2 text-warning font-size-xs"></i>
													';
        } elseif ($sayi == 2) {
            return '<i class="mdi mdi-star mr-n1 mb-2 text-warning font-size-xs"></i>
													<i class="mdi mdi-star mr-n1 mb-2 text-warning font-size-xs"></i>
													<i class="mdi mdi-star-outline mr-n1 mb-2 text-warning font-size-xs"></i>
													<i class="mdi mdi-star-outline mr-n1 mb-2 text-warning font-size-xs"></i>
													<i class="mdi mdi-star-outline mb-2 text-warning font-size-xs"></i>
													';
        } elseif ($sayi == 3) {
            return '<i class="mdi mdi-star mr-n1 mb-2 text-warning font-size-xs"></i>
													<i class="mdi mdi-star mr-n1 mb-2 text-warning font-size-xs"></i>
													<i class="mdi mdi-star mr-n1 mb-2 text-warning font-size-xs"></i>
													<i class="mdi mdi-star-outline mr-n1 mb-2 text-warning font-size-xs"></i>
													<i class="mdi mdi-star-outline mb-2 text-warning font-size-xs"></i>
													';
        } elseif ($sayi == 4) {
            return '<i class="mdi mdi-star mr-n1 mb-2 text-warning font-size-xs"></i>
													<i class="mdi mdi-star mr-n1 mb-2 text-warning font-size-xs"></i>
													<i class="mdi mdi-star mr-n1 mb-2 text-warning font-size-xs"></i>
													<i class="mdi mdi-star mr-n1 mb-2 text-warning font-size-xs"></i>
													<i class="mdi mdi-star-outline mb-2 text-warning font-size-xs"></i>
													';
        } elseif ($sayi == 5) {
            return '<i class="mdi mdi-star mr-n1 mb-2 text-warning font-size-xs"></i>
													<i class="mdi mdi-star mr-n1 mb-2 text-warning font-size-xs"></i>
													<i class="mdi mdi-star mr-n1 mb-2 text-warning font-size-xs"></i>
													<i class="mdi mdi-star mr-n1 mb-2 text-warning font-size-xs"></i>
													<i class="mdi mdi-star mb-2 text-warning font-size-xs"></i>
													';
        }
    }
}

if (!function_exists('yorum_itiraz_say')) {
    function yorum_itiraz_say($id)
    {
        $t = &get_instance();
        $say = $t->magaza_model->yorum_itiraz_say(array('yorum_id' => $id));
        return $say;
    }
}

if (!function_exists('yorum_itiraz')) {
    function yorum_itiraz($id)
    {
        $t = &get_instance();
        $say = $t->magaza_model->yorum_itiraz(array('yorum_itiraz.yorum_id' => $id));
        return $say;
    }
}

if (!function_exists('aylik_kazanc')) {
    function aylik_kazanc($kullanici_id)
    {
        $t = &get_instance();
        $magaza = $t->magaza_model->magaza(array('kullanici_id' => $kullanici_id));

        if (!$magaza) {
            return false;
            die();
        }


        $aylik_siparis = $t->magaza_model->aylik_siparis($magaza->magaza_id);
        $data = [];
        foreach ($aylik_siparis as $row) {
            $data['ay'][] = $row->ay;
            $data['veri'][] = $row->toplam;
        }
        $data['data'] = $data;
        return $data;
    }
}

if (!function_exists('gunluk_toplam_kazanc')) {
    function gunluk_toplam_kazanc($kullanici_id)
    {
        $t = &get_instance();
        $magaza = $t->magaza_model->magaza(array('kullanici_id' => $kullanici_id));

        if (!$magaza) {
            return false;
            die();
        }

        $gunluk_siparis = $t->magaza_model->gunluk_siparis_tutari($magaza->magaza_id);
        $data = [];
        foreach ($gunluk_siparis as $row) {
            $data[] += $row->toplam;
        }
        return $data[0];
    }
}

if (!function_exists('aylik_toplam_kazanc')) {
    function aylik_toplam_kazanc($kullanici_id)
    {
        $t = &get_instance();
        $magaza = $t->magaza_model->magaza(array('kullanici_id' => $kullanici_id));

        if (!$magaza) {
            return false;
            die();
        }

        $gunluk_siparis = $t->magaza_model->aylik_siparis_tutari($magaza->magaza_id);
        $data = [];
        foreach ($gunluk_siparis as $row) {
            $data[] += $row->toplam;
        }
        return $data[0];
    }
}

if (!function_exists('odenen_kazanclar')) {
    function odenen_kazanclar($kullanici_id)
    {
        $t = &get_instance();
        $magaza = $t->magaza_model->magaza(array('kullanici_id' => $kullanici_id));

        if (!$magaza) {
            return false;
            die();
        }

        $odenen_kazanclar = $t->magaza_model->odenen_kazanclar($magaza->magaza_id);
        $data = [];
        foreach ($odenen_kazanclar as $row) {
            $data[] += $row->toplam;
        }
        return $data[0];
    }
}

if (!function_exists('odenebilir_kazanclar')) {
    function odenebilir_kazanclar($kullanici_id)
    {
        $t = &get_instance();
        $magaza = $t->magaza_model->magaza(array('kullanici_id' => $kullanici_id));
        if (!$magaza) {
            return false;
            die();
        }

        $odenen_kazanclar = $t->magaza_model->odenebilir_kazanclar($magaza->magaza_id);
        $data = [];
        foreach ($odenen_kazanclar as $row) {
            $data[] += $row->toplam;
        }
        return $data[0];
    }
}

if (!function_exists('toplam_kazanclar')) {
    function toplam_kazanclar($kullanici_id)
    {
        $t = &get_instance();
        $magaza = $t->magaza_model->magaza(array('kullanici_id' => $kullanici_id));

        if (!$magaza) {
            return false;
            die();
        }

        $odenen_kazanclar = $t->magaza_model->toplam_kazanclar($magaza->magaza_id);
        $data = [];
        foreach ($odenen_kazanclar as $row) {
            $data[] += $row->toplam;
        }
        return $data[0];
    }
}

if (!function_exists('aylik_siparis_adet')) {
    function aylik_siparis_adet($kullanici_id)
    {
        $t = &get_instance();
        $magaza = $t->magaza_model->magaza(array('kullanici_id' => $kullanici_id));

        if (!$magaza) {
            return false;
            die();
        }

        $aylik_siparis_adet = $t->magaza_model->aylik_siparis_adet($magaza->magaza_id);
        $data = [];
        foreach ($aylik_siparis_adet as $row) {
            $data[] += $row->toplam;
        }
        return $data[0];
    }
}

if (!function_exists('toplam_siparis_adet')) {
    function toplam_siparis_adet($kullanici_id)
    {
        $t = &get_instance();
        $magaza = $t->magaza_model->magaza(array('kullanici_id' => $kullanici_id));

        if (!$magaza) {
            return false;
            die();
        }

        $aylik_siparis_adet = $t->magaza_model->toplam_siparis_adet($magaza->magaza_id);
        $data = [];
        foreach ($aylik_siparis_adet as $row) {
            $data[] += $row->toplam;
        }
        return $data[0];
    }
}

if (!function_exists('toplam_yorum_ortalamasi')) {
    function toplam_yorum_ortalamasi($kullanici_id)
    {
        $t = &get_instance();
        $magaza = $t->magaza_model->magaza(array('kullanici_id' => $kullanici_id));

        if (!$magaza) {
            return false;
            die();
        }

        $toplam_yorum_ortalamasi = $t->magaza_model->toplam_yorum_ortalamasi($magaza->magaza_id);
        $data = [];
        foreach ($toplam_yorum_ortalamasi as $row) {
            $data['toplam'] = $row->toplam;
            $data['puan'] = $row->puan;
        }

        if ($data['toplam'] == 0) {
            return "0.0";
        } else {
            return number_format($data['puan'] / $data['toplam'], 1);
        }
    }
}

if (!function_exists('yorum_ortalamasi')) {
    function yorum_ortalamasi($magaza_id)
    {
        $t = &get_instance();
        $toplam_yorum_ortalamasi = $t->magaza_model->toplam_yorum_ortalamasi($magaza_id);
        $data = [];
        foreach ($toplam_yorum_ortalamasi as $row) {
            $data['toplam'] = $row->toplam;
            $data['puan'] = $row->puan;
        }

        if ($data['toplam'] == 0) {
            return "0.0";
        } else {
            return number_format($data['puan'] / $data['toplam'], 1);
        }
    }
}

if (!function_exists('urun_yorum_ortalamasi')) {
    function urun_yorum_ortalamasi($magaza_id, $urun_id)
    {
        $t = &get_instance();
        $toplam_yorum_ortalamasi = $t->magaza_model->urun_toplam_yorum_ortalamasi($magaza_id, $urun_id);
        $data = [];
        foreach ($toplam_yorum_ortalamasi as $row) {
            $data['toplam'] = $row->toplam;
            $data['puan'] = $row->puan;
        }

        if ($data['toplam'] == 0) {
            return "0.0";
        } else {
            return number_format($data['puan'] / $data['toplam'], 1);
        }
    }
}

if (!function_exists('checkIBAN')) {
    function checkIBAN($iban)
    {
        $iban = strtolower(str_replace(' ', '', $iban));
        $Countries = array('al' => 28, 'ad' => 24, 'at' => 20, 'az' => 28, 'bh' => 22, 'be' => 16, 'ba' => 20, 'br' => 29, 'bg' => 22, 'cr' => 21, 'hr' => 21, 'cy' => 28, 'cz' => 24, 'dk' => 18, 'do' => 28, 'ee' => 20, 'fo' => 18, 'fi' => 18, 'fr' => 27, 'ge' => 22, 'de' => 22, 'gi' => 23, 'gr' => 27, 'gl' => 18, 'gt' => 28, 'hu' => 28, 'is' => 26, 'ie' => 22, 'il' => 23, 'it' => 27, 'jo' => 30, 'kz' => 20, 'kw' => 30, 'lv' => 21, 'lb' => 28, 'li' => 21, 'lt' => 20, 'lu' => 20, 'mk' => 19, 'mt' => 31, 'mr' => 27, 'mu' => 30, 'mc' => 27, 'md' => 24, 'me' => 22, 'nl' => 18, 'no' => 15, 'pk' => 24, 'ps' => 29, 'pl' => 28, 'pt' => 25, 'qa' => 29, 'ro' => 24, 'sm' => 27, 'sa' => 24, 'rs' => 22, 'sk' => 24, 'si' => 19, 'es' => 24, 'se' => 24, 'ch' => 21, 'tn' => 24, 'tr' => 26, 'ae' => 23, 'gb' => 22, 'vg' => 24);
        $Chars = array('a' => 10, 'b' => 11, 'c' => 12, 'd' => 13, 'e' => 14, 'f' => 15, 'g' => 16, 'h' => 17, 'i' => 18, 'j' => 19, 'k' => 20, 'l' => 21, 'm' => 22, 'n' => 23, 'o' => 24, 'p' => 25, 'q' => 26, 'r' => 27, 's' => 28, 't' => 29, 'u' => 30, 'v' => 31, 'w' => 32, 'x' => 33, 'y' => 34, 'z' => 35);

        if (strlen($iban) == $Countries[substr($iban, 0, 2)]) {

            $MovedChar = substr($iban, 4) . substr($iban, 0, 4);
            $MovedCharArray = str_split($MovedChar);
            $NewString = "";

            foreach ($MovedCharArray as $key => $value) {
                if (!is_numeric($MovedCharArray[$key])) {
                    $MovedCharArray[$key] = $Chars[$MovedCharArray[$key]];
                }
                $NewString .= $MovedCharArray[$key];
            }

            if (bcmod($NewString, '97') == 1) {
                return true;
            }
        }
        return false;
    }
}

if (!function_exists('tum_bosluk_sil')) {
    function tum_bosluk_sil($veri)
    {
        $veri = str_replace("/s+/", "", $veri);
        $veri = str_replace(" ", "", $veri);
        $veri = str_replace(" ", "", $veri);
        $veri = str_replace(" ", "", $veri);
        $veri = str_replace("/s/g", "", $veri);
        $veri = str_replace("/s+/g", "", $veri);
        $veri = trim($veri);
        return $veri;
    }
}

if (!function_exists('paracek_say')) {
    function paracek_say($id)
    {
        $t = &get_instance();
        $say = $t->magaza_model->paracek_say($id);
        return $say;
    }
}

if (!function_exists('kategoriler')) {
    function kategoriler()
    {
        $t = &get_instance();
        $where = $t->destek_model->menucek(array('parent' => 0, 'kategori_durum' => 1));
        return $where;
    }
}


if (!function_exists('populer_kategoriler')) {
    function populer_kategoriler()
    {
        $t = &get_instance();
        $where = $t->destek_model->populerKategoriOne(array('kategori_durum' => 1, 'kategori_populer' => '1'));
        return $where;
    }
}

if (!function_exists('populer_kategoriler_two')) {
    function populer_kategoriler_two()
    {
        $t = &get_instance();
        $where = $t->destek_model->populerKategoriTwo(array('kategori_durum' => 1, 'kategori_populer' => '1'));
        return $where;
    }
}

if (!function_exists('kategoriler_yonetim')) {
    function kategoriler_yonetim()
    {
        $t = &get_instance();
        $where = $t->destek_model->tummenucek(array());
        return $where;
    }
}
if (!function_exists('kategoriler_yonetimss')) {
    function kategoriler_yonetimss()
    {
        $t = &get_instance();
        $where = $t->destek_model->menucek(array("parent" => 0));
        return $where;
    }
}
if (!function_exists('kategoriler_yonetims')) {
    function kategoriler_yonetims()
    {
        $t = &get_instance();
        $where = $t->destek_model->parentcat();
        return $where;
    }
}

if (!function_exists('blog_kategoriler_yonetim')) {
    function blog_kategoriler_yonetim()
    {
        $t = &get_instance();
        $where = $t->destek_model->blogkategoriler(array());
        return $where;
    }
}

if (!function_exists('alt_kategoriler')) {
    function alt_kategoriler($id)
    {
        $t = &get_instance();
        $where = $t->destek_model->menucek(array('parent' => $id, 'kategori_durum' => 1));
        return $where;
    }
}

if (!function_exists('gunHesapla')) {
    function gunHesapla($ikinci)
    {
        $simdikiZaman = strtotime(date('Y-m-d H:i:s'));
        $bitisZaman = strtotime($ikinci);
        if ($simdikiZaman > $bitisZaman) {
            return true;
        } else {
            return false;
        }
    }
}

if (!function_exists('reklam_kontrol')) {
    function reklam_kontrol($urun_id, $reklam_tur)
    {
        $ci = &get_instance();
        $reklam_cek = $ci->magaza_model->reklam(array('reklam.urun_id' => $urun_id, 'reklam.reklam_turu' => $reklam_tur));
        if ($reklam_cek) {
            if (gunHesapla($reklam_cek->reklam_bitis)) {
                return true;
            } else {
                return false;
            }
        } else {
            return true;
        }
    }
}

if (!function_exists('reklam_kontrol2')) {
    function reklam_kontrol2($urun_id)
    {
        $ci = &get_instance();
        $reklam_cek = $ci->magaza_model->reklam(array('reklam.urun_id' => $urun_id, 'reklam.reklam_durum' => 1));
        if ($reklam_cek) {
            if (gunHesapla($reklam_cek->reklam_bitis)) {
                return true;
            } else {
                return false;
            }
        } else {
            return true;
        }
    }
}

if (!function_exists('zamanHesapla')) {
    function zamanHesapla($tarih)
    {
        $tarih1 = new DateTime(date('Y-m-d H:i:s'));
        $tarih2 = new DateTime($tarih);
        $interval = $tarih1->diff($tarih2);
        return $interval->format('%a gün %h saat');
    }
}

if (!function_exists('kat_urunler')) {
    function kat_urunler($kat_id)
    {
        $ci = &get_instance();
        return $ci->magaza_model->urunler_anasayfa(array('urunler.urun_durum' => 1), $kat_id);
    }
}

if (!function_exists('urunler_vitrin')) {
    function urunler_vitrin()
    {
        $ci = &get_instance();
        return $ci->magaza_model->urunler_vitrin(array('urunler.urun_durum' => 1, 'urunler.urun_populer' => 1,'urunler.urun_bitis_tarihi>'=>date('Y-m-d H:i')));
    }
}
if (!function_exists('urunler_yeni')) {
    function urunler_yeni()
    {
        $ci = &get_instance();
        return $ci->magaza_model->urunler_yeni(array('urunler.urun_durum' => 1,'urunler.urun_bitis_tarihi>'=>date('Y-m-d H:i')));
    }
}
if (!function_exists('urunler_cok_satan')) {
    function urunler_cok_satan()
    {
        $ci = &get_instance();
        return $ci->magaza_model->urunler_cok_satan(array('urunler.urun_durum' => 1,'urunler.urun_bitis_tarihi>'=>date('Y-m-d H:i')));
    }
}



if (!function_exists('anasayfa_reklam_kontrol')) {
    function anasayfa_reklam_kontrol($urun_id)
    {
        $ci = &get_instance();
        $reklam_cek = $ci->magaza_model->reklam(array('reklam.urun_id' => $urun_id, 'reklam.reklam_durum' => 1, 'reklam.reklam_turu' => 'anasayfa'));
        if ($reklam_cek) {
            if (gunHesapla($reklam_cek->reklam_bitis)) {
                return true;
            } else {
                return false;
            }
        } else {
            return true;
        }
    }
}

if (!function_exists('kategori_reklam_kontrol')) {
    function kategori_reklam_kontrol($urun_id)
    {
        $ci = &get_instance();
        $reklam_cek = $ci->magaza_model->reklam(array('reklam.urun_id' => $urun_id, 'reklam.reklam_durum' => 1, 'reklam.reklam_turu' => 'kategori'));
        if ($reklam_cek) {
            if (gunHesapla($reklam_cek->reklam_bitis)) {
                return true;
            } else {
                return false;
            }
        } else {
            return true;
        }
    }
}


if (!function_exists('mesajRow')) {
    function mesajRow($uniq)
    {
        $ci = &get_instance();
        return $ci->mesaj_model->mesajRow(array('uniq' => $uniq));
    }
}

if (!function_exists('clean_number')) {
    function clean_number($num)
    {
        $ci = &get_instance();
        $num = @trim($num);
        $num = $ci->security->xss_clean($num);
        $num = intval($num);
        return $num;
    }
}

if (!function_exists('mesajOkunmamis')) {
    function mesajOkunmamis()
    {
        $t = &get_instance();
        $kullanici = kullanicicek();
        $mesaj = $t->mesaj_model->mesajOkunmamis(['alan_id' => $kullanici->kullanici_id, 'okunma' => 1]);
        if ($mesaj > 0) {
            return true;
        } else {
            return false;
        }
    }
}

if (!function_exists('mesajOkunmamisSay')) {
    function mesajOkunmamisSay()
    {
        $t = &get_instance();
        $kullanici = kullanicicek();
        return $t->mesaj_model->mesajOkunmamis(['alan_id' => $kullanici->kullanici_id, 'okunma' => 1]);
    }
}

if (!function_exists('mesajOku')) {
    function mesajOku()
    {
        $t = &get_instance();
        $kullanici = kullanicicek();
        $mesaj = $t->mesaj_model->mesaj(['alan_id' => $kullanici->kullanici_id, 'okunma' => 1]);
        foreach ($mesaj as $m) {
            $t->mesaj_model->mesajUpdate(['alan_id' => $kullanici->kullanici_id, 'okunma' => 1], ['okunma' => 0]);
        }
    }
}

if (!function_exists('magaza_check_id')) {
    function magaza_check_id($id)
    {
        $ci = &get_instance();
        $kullanici = kullanicicek();
        $magaza_check = $ci->magaza_model->magaza_check($id);
        if ($magaza_check) {
            return true;
        } else {
            return false;
        }
    }
}

if (!function_exists('kullanici_resim')) {
    function kullanici_resim($id)
    {
        $t = &get_instance();
        $kullanici = $t->yonetim_model->get(array("kullanici_id" => $id));
        return $kullanici->kullanici_resim;
    }
}

if (!function_exists('kullanici_isim_soyisim')) {
    function kullanici_isim_soyisim($id)
    {
        $t = &get_instance();
        $kullanici = $t->yonetim_model->get(array("kullanici_id" => $id));
        return $kullanici->kullanici_isim . " " . $kullanici->kullanici_soyisim;
    }
}

if (!function_exists('kullanici_username')) {
    function kullanici_username($id)
    {
        $t = &get_instance();
        $kullanici = $t->yonetim_model->get(array("kullanici_id" => $id));
        return $kullanici->kullanici_ad;
    }
}

function bloglar()
{
    $t = &get_instance();
    $where = $t->destek_model->blogcek(array());
    return $where;
}
function bankalar($where=array())
{
    $t = &get_instance();
    $where = $t->destek_model->bankacek($where);
    return $where;
}

function kategoribloglar($id)
{
    $t = &get_instance();
    $where = $t->destek_model->blogcek(['blog_kategori_id' => $id]);
    return $where;
}

function blogkategoricek($seo)
{
    $t = &get_instance();
    $where = $t->home_model->blogkategoricek(['kategori_seo' => $seo]);
    return $where;
}

function blogsay()
{
    $t = &get_instance();
    $say = $t->destek_model->blogsay(array());
    return $say;
}

function kategoriblogsay($id)
{
    $t = &get_instance();
    $say = $t->destek_model->blogsay(['blog_kategori_id' => $id]);
    return $say;
}

function limitblogcek()
{
    $t = &get_instance();
    $say = $t->home_model->limitblogcek();
    return $say;
}

function blogana()
{
    $t = &get_instance();
    $where = $t->home_model->blogana(array());
    return $where;
}

if (!function_exists('mailGonder')) {
    function mailGonder($alici, $baslik, $html)
    {
        $t = &get_instance();
        $siteayar = ayarlar();
        $SMTP_HOST = $siteayar->smtp_host;
        $SMTP_USER = $siteayar->smtp_mail;
        $SMTP_PASS = $siteayar->smtp_sifre;
        $SMTP_PORT = $siteayar->smtp_port;
        $SMTP_GO = $siteayar->smtp_gomail;
        $alan = $alici;
        $konu = $baslik;
        $t->load->library('email');
        $config['protocol'] = 'smtp';
        $config['smtp_host'] = $SMTP_HOST;
        $config['smtp_user'] = $SMTP_USER;
        $config['smtp_pass'] = $SMTP_PASS;
        $config['smtp_port'] = $SMTP_PORT;
        $config['mailtype'] = 'html';
        $t->email->initialize($config);
        $t->email->from("$SMTP_USER", $baslik);
        $t->email->to($alan);
        $t->email->subject($konu);
        $t->email->message($html);
        if ($t->email->send()) {
            return true;
        } else {
            return false;
        }
    }
}


function slider()
{
    $t = &get_instance();
    $where = $t->destek_model->slider(array());
    return $where;
}
function slidercek()
{
    $t = &get_instance();
    $where = $t->home_model->slidercek(array());
    return $where;
}

function dizi_goster($veri){
    echo "<pre>";
    print_r($veri);
    echo "</pre>";
}


function kullanici_ad_getir($id){
    $ci = &get_instance();
    $ci->db->where(array('kullanici_id' => $id));
    $query = $ci->db->get('kullanici');
    $veri = $query->row();
    return $veri->kullanici_ad;
}

function kullanici_email_getir($id){
    $ci = &get_instance();
    $ci->db->where(array('kullanici_id' => $id));
    $query = $ci->db->get('kullanici');
    $veri = $query->row();
    return $veri->kullanici_mail;
}

function generateVerificationCode($length = 6) {
    $characters = '0123456789';
    $code = '';

    for ($i = 0; $i < $length; $i++) {
        $code .= $characters[rand(0, strlen($characters) - 1)];
    }

    return $code;
}