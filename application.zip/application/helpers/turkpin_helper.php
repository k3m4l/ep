<?php 

    function getBalance (){
        return 25;
    }
?>