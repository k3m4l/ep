<section class="profileMainCard fsb">
<div class="container">
    <div class="panel m-0">
        <div class="panel-body pa-dys" style="background-position: center;background-image: url('<?php echo !empty($magaza->magaza_banner) ? base_url($magaza->magaza_banner) : 'https://kemalellidort.com.tr/uploads/logo/654fdd26a3671_invite-bg.png' ?>') !important">
            <div class="flexCard">
                <div class="userAvatar">
                    <img src="<?= !empty($magaza->magaza_resim) ? base_url($magaza->magaza_resim) : 'https://ui-avatars.com/api/?name='. $magaza_kullanici_bilgi->kullanici_ad .'&background=0D8ABC&color=fff' ?>" title="<?= $magaza->magaza_ad ?>"
                         alt="<?= $magaza->magaza_ad ?>">
                </div>

                <div class="userDetails">
                    <small>@<?= $magaza->magaza_seo ?> / <?= ucwords(strtolower($magaza->magaza_tur)) ?>
                        Mağaza</small>
                    <h1><?= $magaza->magaza_ad ?>
                        <?php if ($magaza->magaza_dogrulama == 1) { ?>
                            <a href="javascript:void(0)" class="top-0 right-0" data-toggle="tooltip"
                               data-placement="top" title="" data-original-title="Doğrulanmış Mağaza">
                                <img src="<?= base_url('assets/front/') ?>images/checked-mark.svg" alt=""
                                     height="30"
                                     width="30"/>
                            </a>
                        <?php } ?></h1>
                    <div class="profileBtns">
                        <?php if ($kullanici) { ?>
                            <?php if ($kullanici->kullanici_id != $magaza->kullanici_id) { ?>
                                <a href="<?= base_url('yeni-mesaj/' . $magaza->magaza_uniq); ?>"
                                   class="btn header-button btn-message"><i class="mdi mdi-message"></i> Mesaj
                                    Gönder
                                </a>
                            <?php } ?>
                        <?php } else { ?>
                            <button class="btn header-button btn-message" id="notLogin"><i
                                        class="mdi mdi-message"></i>
                                Mesaj Gönder
                            </button>
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php if (magaza(kullanicicek()->kullanici_id)->magaza_id == $magaza->magaza_id) { ?>
    <div class="k-panel-warper mb-s">
        <div class="sec-warper">
            <div class="container m-0 p-0  sb-container">
                <div class="k-panel-g-warper m-bg pls">
                    <?php if (magaza(kullanicicek()->kullanici_id)->magaza_id == $magaza->magaza_id) { ?>
                        <div class="col-12 md-none bg-none">
                            <div class="k-panel-left-navbar-warper">
                                <div class="k-panel-left-navbar-area spsw">
                                    <div class="nav d-flex justify-content-space-between nav-pills bg-custom-none"
                                         id="v-pills-tab"
                                         role="tablist" aria-orientation="vertical">
                                        <button class="nav-link kpc-nav-btn w-spacial active" id="store-tab"
                                                data-bs-toggle="pill" data-bs-target="#store" type="button"
                                                role="tab" aria-controls="store"
                                                aria-selected="true"><img class="btn-img" src="<?= base_url('assets/front/images/s6.png') ?>" alt="">
                                            Mağazam
                                        </button>

                                        <button class="nav-link kpc-nav-btn w-spacial" id="advert-tab"
                                                data-bs-toggle="pill" data-bs-target="#advert" type="button"
                                                role="tab" aria-controls="advert"
                                                aria-selected="false"><img class="btn-img" src="<?= base_url('assets/front/images/s5.png') ?>" alt="">
                                            İlanlarım
                                        </button>

                                        <button class="nav-link kpc-nav-btn w-spacial" id="atq-tab" data-bs-toggle="pill"
                                                data-bs-target="#atq" type="button" role="tab"
                                                aria-controls="atq"
                                                aria-selected="false"><img class="btn-img" src="<?= base_url('assets/front/images/s4.png') ?>" alt="">
                                            İlan Sorularım
                                        </button>

                                        <button class="nav-link kpc-nav-btn w-spacial" id="product-evaluation-tab"
                                                data-bs-toggle="pill" data-bs-target="#product-evaluation"
                                                type="button" role="tab" aria-controls="product-evaluation"
                                                aria-selected="false"><img class="btn-img" src="<?= base_url('assets/front/images/s3.png') ?>" alt="">
                                            İlan Yorumları
                                        </button>

                                        <button class="nav-link kpc-nav-btn w-spacial" id="raffle-tab"
                                                data-bs-toggle="pill" data-bs-target="#raffle" type="button"
                                                role="tab" aria-controls="raffle"
                                                aria-selected="false"><img class="btn-img" src="<?= base_url('assets/front/images/s2.png') ?>" alt="">
                                            Çekilişlerim
                                        </button>


                                        <button class="nav-link kpc-nav-btn w-spacial" id="store-settings-tab"
                                                data-bs-toggle="pill" data-bs-target="#store-settings"
                                                type="button"
                                                role="tab" aria-controls="store-settings"
                                                aria-selected="false"><img class="btn-img" src="<?= base_url('assets/front/images/s1.png') ?>" alt="">
                                            Mağza Ayarlarım
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php } ?>
                    <div class="row">
                        <div class="col-12 ">
                            <div class="k-panel-content-right">
                                <div class="tab-content" id="v-pills-tabContent">
                                    <div class="tab-pane fade show active" id="store" role="tabpanel"
                                         aria-labelledby="store-tab" tabindex="0">
                                        <div class="container m-0 p-0">
                                            <div class="k-panel-content-box">
                                                <div class="row">
                                                    <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 mb-3">
                                                        <div class="card">
                                                            <div class="card-content">
                                                                <div class="card-body mh-85 bc-22">
                                                                    <div class="card-img-body">
                                                                        <div class="media  ">
                                                                            <div class="card-img-body-warper">
                                                                                <img class="card-img-body-icon" src="<?= base_url('assets/images/money-bag.png') ?> " alt="">
                                                                            </div>
                                                                            <div class="media-body text-right-c">
                                                                                <h3><?php echo (!empty($total_earning) || $total_earning != '0') ? $total_earning : '0.00' ?>
                                                                                    TL</h3>
                                                                                <span>Toplam Kazanç</span>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 mb-3">
                                                        <div class="card">
                                                            <div class="card-content">
                                                                <div class="card-body mh-85 bc-22">
                                                                    <div class="card-img-body">
                                                                        <div class="media">
                                                                            <div class="card-img-body-warper">
                                                                                <img class="card-img-body-icon"
                                                                                     src="<?= base_url('assets/images/ty6.png') ?> "
                                                                                     alt="">
                                                                            </div>
                                                                            <div class="media-body text-right-c">
                                                                                <h3><?php echo !empty($month_total_earning) ? $month_total_earning : '0.00' ?>
                                                                                    TL</h3>
                                                                                <span>Aylık Kazanç</span>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 mb-3">
                                                        <div class="card">
                                                            <div class="card-content">
                                                                <div class="card-body mh-85 bc-22">
                                                                    <div class="card-img-body">
                                                                        <div class="media">
                                                                            <div class="card-img-body-warper">
                                                                                <img class="card-img-body-icon"
                                                                                     src="<?= base_url('assets/images/ty7.png') ?> "
                                                                                     alt="">
                                                                            </div>
                                                                            <div class="media-body text-right-c">
                                                                                <h3><?php echo $month_order_count ?>
                                                                                    Adet</h3>
                                                                                <span>Aylık Sipariş</span>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 mb-3">
                                                        <div class="card">
                                                            <div class="card-content">
                                                                <div class="card-body mh-85 bc-22">
                                                                    <div class="card-img-body">
                                                                        <div class="media  ">
                                                                            <div class="card-img-body-warper">
                                                                                <img class="card-img-body-icon"
                                                                                     src="<?= base_url('assets/images/reconciliation.png') ?> "
                                                                                     alt="">
                                                                            </div>
                                                                            <div class="media-body text-right-c">
                                                                                <h3><?php echo $order_count ?>
                                                                                    Adet</h3>
                                                                                <span>Toplam Sipariş</span>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 mb-3">
                                                        <div class="card">
                                                            <div class="card-content">
                                                                <div class="card-body mh-85 bc-22">
                                                                    <div class="card-img-body">
                                                                        <div class="media  ">
                                                                            <div class="card-img-body-warper">
                                                                                <img class="card-img-body-icon"
                                                                                     src="<?= base_url('assets/images/ty1.png') ?> "
                                                                                     alt="">
                                                                            </div>
                                                                            <div class="media-body text-right-c">
                                                                                <h3><?php echo $ilan_count ?>
                                                                                    Adet</h3>
                                                                                <span> İlanlar</span>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 mb-3">
                                                        <div class="card">
                                                            <div class="card-content">
                                                                <div class="card-body mh-85 bc-22">
                                                                    <div class="card-img-body">
                                                                        <div class="media  ">
                                                                            <div class="card-img-body-warper">
                                                                                <img class="card-img-body-icon"
                                                                                     src="<?= base_url('assets/images/ty2.png') ?> "
                                                                                     alt="">
                                                                            </div>
                                                                            <div class="media-body text-right-c">
                                                                                <h3><?php echo $sales_count ?>
                                                                                    Adet</h3>
                                                                                <span>Toplam Satışlar</span>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>


                                    <div class="tab-pane fade" id="message" role="tabpanel"
                                         aria-labelledby="message-tab" tabindex="0">
                                        <div class="container-fluid">
                                            <div class="k-panel-content-box">
                                                <div class="row">
                                                    <div class="col-12">
                                                        <div class="kpc-tt">
                                                            Mesajlarım
                                                        </div>
                                                        <main class="main-content pt-xl-4 pt-3 pb-xl-4 pb-3">
                                                            <div class="container-fluid">
                                                                <div class="row align-items-center no-gutters justify-content-between">
                                                                </div>
                                                                <div class="row mt-4 mb-4">
                                                                    <div class="col-xl-3 col-lg-3 col-12 mb-xl-0 mb-3">
                                                                        <div class="bg-color message-users"
                                                                             id="box_list">
                                                                            <div id="asagial"></div>
                                                                            <div class="">
                                                                                <a class="newmessage"
                                                                                   data-toggle="modal"
                                                                                   data-target="#sohbet"><i>+</i>
                                                                                    YENİ SOHBET</a>
                                                                            </div>
                                                                            <div class="chat-search">
                                                                                <input type="text" name="s"
                                                                                       class="cat-search"
                                                                                       onkeyup="var value = $(this).val().toLowerCase();
                                                                                $(&quot;.isim&quot;).filter(function() {
                                                                                    $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
                                                                                });" placeholder="Aradığınız Kullanıcıyı Yazın...">
                                                                            </div>
                                                                            <div class="d-flex align-items-center">
                                                                            </div>
                                                                            <ul id="yenimesaj"
                                                                                class="chat-list-name">
                                                                                <?php if ($mesaj || $giden_mesaj) { ?>
                                                                                    <?php foreach ($mesaj as $key => $val) { ?>
                                                                                        <?php $user = kullanici_bilgi($val->gonderen_id); ?>
                                                                                        <li class="messageus menu-left-area"
                                                                                            data-target="<?php echo $val->uniq ?>">
                                                                                            <div style="cursor:pointer;"
                                                                                                 onclick="$(document).scrollTop($('div#asagial').offset().top);">
                                                                                                <a class="row no-gutters align-items-center isim">
                                                                                                    <span class="col-3">
                                                                                                        <span class="mu-image">
                                                                                                            <?php if (strpos($user->kullanici_resim, "/.jpg") !== false) { ?>
                                                                                                                <img src="https://ui-avatars.com/api/?name=<?= $user->kullanici_isim ?>+<?= $user->kullanici_soyisim ?>&background=0D8ABC&color=fff"
                                                                                                                     alt="">
                                                                                                            <?php } else { ?>
                                                                                                                <img src="<?= base_url($user->kullanici_resim) ?>"
                                                                                                                     alt="">
                                                                                                            <?php } ?>
                                                                                                        </span>
                                                                                                    </span>
                                                                                                    <span class="col-9">
                                                                                                        <span class="row justify-content-between"></span>
                                                                                                        <span class="col-auto">
                                                                                                            <span class="mu-name"><?= $user->kullanici_ad ?>
                                                                                                            </span>
                                                                                                            <br><span class="col-auto">
                                                                                                                <span id=""
                                                                                                                      class="mu-date">
                                                                                                                    <?php echo $val->tarih ?>
                                                                                                                </span>
                                                                                                            </span>
                                                                                                        </span>
                                                                                                    </span>
                                                                                                </a>
                                                                                            </div>
                                                                                        </li>
                                                                                    <?php } ?>
                                                                                    <?php foreach ($giden_mesaj as $key => $val) { ?>
                                                                                        <?php $user = kullanici_bilgi($val->alan_id); ?>
                                                                                        <li class="messageus menu-left-area"
                                                                                            data-target="<?php echo $val->uniq ?>">
                                                                                            <div style="cursor:pointer;"
                                                                                                 onclick="$(document).scrollTop($('div#asagial').offset().top);">
                                                                                                <a class="row no-gutters align-items-center isim">
                                                                                                    <span class="col-3">
                                                                                                        <span
                                                                                                                class="mu-image">
                                                                                                            <?php if (strpos($user->kullanici_resim, "/.jpg") !== false) { ?>
                                                                                                                <img src="https://ui-avatars.com/api/?name=<?= $user->kullanici_isim ?>+<?= $user->kullanici_soyisim ?>&background=0D8ABC&color=fff"
                                                                                                                     alt="">
                                                                                                            <?php } else { ?>
                                                                                                                <img src="<?= base_url($user->kullanici_resim) ?>"
                                                                                                                     alt="">
                                                                                                            <?php } ?>
                                                                                                        </span>
                                                                                                    </span>
                                                                                                    <span class="col-9">
                                                                                                        <span class="row justify-content-between"></span>
                                                                                                        <span class="col-auto">
                                                                                                            <span class="mu-name"><?= $user->kullanici_ad ?>
                                                                                                            </span>
                                                                                                            <br><span class="col-auto">
                                                                                                                <span id=""
                                                                                                                      class="mu-date">
                                                                                                                    <?php echo $val->tarih ?>
                                                                                                                </span>
                                                                                                            </span>
                                                                                                        </span>
                                                                                                    </span>
                                                                                                </a>
                                                                                            </div>
                                                                                        </li>
                                                                                    <?php } ?>
                                                                                <?php } else { ?>
                                                                                    <li class="messageus"
                                                                                        data-target="0">
                                                                                        <div style="cursor:pointer;"
                                                                                             onclick="$(document).scrollTop($('div#asagial').offset().top);">
                                                                                            <a class="row no-gutters align-items-center isim">
                                                                                                    <span class="col-12"
                                                                                                          style="text-align: center;margin-top:15px">
                                                                                                        <span class="row justify-content-between"></span>
                                                                                                        <span class="col-auto">
                                                                                                            <span class="mu-name">Mesaj
                                                                                                                Bulunmamaktadır.
                                                                                                            </span>
                                                                                                            <br><span class="col-auto">
                                                                                                            </span>
                                                                                                        </span>
                                                                                                    </span>
                                                                                            </a>
                                                                                        </div>
                                                                                    </li>
                                                                                <?php } ?>
                                                                            </ul>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-xl-9 col-lg-9 col-12"
                                                                         id="n">
                                                                        <div class="bg-color mu-message-area pl-3 pb-3 pr-3">
                                                                            <div class="empty-chat">
                                                                                <div class="mma-top border-bottom">
                                                                                    <div class="row mma-row justify-content-between align-items-center">
                                                                                    </div>
                                                                                </div>
                                                                                <div class="mma-content"
                                                                                     id="mma-content">
                                                                                    <div id="mma-red"
                                                                                         style="text-align: center;padding: 15px; display: block;">
                                                                                        <img height="300"
                                                                                             src="<?php echo base_url('assets/images/chats-1.png') ?>">
                                                                                    </div>
                                                                                    <div id="mma-red-text"
                                                                                         class="mma-chat-text"
                                                                                         style="text-align: center;">
                                                                                        <h4>Anlık sohbet
                                                                                            sistemine hoşgeldin
                                                                                        </h4>
                                                                                        <span>Buradan anlık
                                                                                                    olarak sitemiz
                                                                                                    üzerindeki
                                                                                                    kullanıcılar ile
                                                                                                    mesajlaşabilir ve
                                                                                                    Yeni sohbet oluştur
                                                                                                    butonuna tıklayarak
                                                                                                    yeni bir sohbet
                                                                                                    başlatabilirsin.</span>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <?php if ($mesaj || $giden_mesaj) { ?>
                                                                                <?php foreach ($mesaj as $key => $val) { ?>
                                                                                    <?php $user = kullanici_bilgi($val->alan_id); ?>
                                                                                    <div class="chat-area"
                                                                                         id="select-chat-<?php echo $val->uniq ?>">
                                                                                        <div class="row mma-row justify-content-between align-items-center">
                                                                                            <div style="display: block;"
                                                                                                 id="mma-ustbar"
                                                                                                 class="col-xl-auto col-12">
                                                                                                <div class="row align-items-center">
                                                                                                    <div class="col-auto">
                                                                                                        <div class="mma-image">
                                                                                                            <a id="profilegit"
                                                                                                               alt=""
                                                                                                               href="javascript:void(0)">
                                                                                                                <?php if (strpos($user->kullanici_resim, "/.jpg") !== false) { ?>
                                                                                                                    <img src="https://ui-avatars.com/api/?name=<?= $user->kullanici_isim ?>+<?= $user->kullanici_soyisim ?>&background=0D8ABC&color=fff"
                                                                                                                         alt=""
                                                                                                                         id="pp">
                                                                                                                <?php } else { ?>
                                                                                                                    <img id="pp"
                                                                                                                         alt=""
                                                                                                                         src="<?= base_url($user->kullanici_resim) ?>">
                                                                                                                <?php } ?>
                                                                                                            </a>
                                                                                                        </div>
                                                                                                    </div>
                                                                                                    <div class="col-auto">
                                                                                                        <div class="mma-name"
                                                                                                             id="mma-name">
                                                                                                            <?php echo $user->kullanici_ad ?>
                                                                                                        </div>
                                                                                                    </div>
                                                                                                    <marquee
                                                                                                            class="duyurutext">
                                                                                                        <?php echo $ayarlar->mesaj_detay_kayan_yazi ?>
                                                                                                    </marquee>
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div class="chat-bar">

                                                                                        </div>

                                                                                        <div class="mm-chat-sender">
                                                                                            <div class="row no-gutters chat-container">
                                                                                                <div class="col-xl-11 col-10">
                                                                                                    <input style="display: block;"
                                                                                                           id="sendmessage"
                                                                                                           type="text"
                                                                                                           class="chat-input"
                                                                                                           name="remessage"
                                                                                                           placeholder="Bir şeyler yazın...">
                                                                                                </div>
                                                                                                <div class="col-xl-1 col-2">
                                                                                                    <button style="display: block;"
                                                                                                            id="sendmessagebutton"
                                                                                                            data-target="<?php echo $val->uniq ?>"
                                                                                                            class="chat-button sendReMessage"></button>
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                <?php } ?>
                                                                                <?php foreach ($giden_mesaj as $key => $val) { ?>
                                                                                    <?php $user = kullanici_bilgi($val->alan_id); ?>
                                                                                    <div class="chat-area"
                                                                                         id="select-chat-<?php echo $val->uniq ?>">
                                                                                        <div class="row mma-row justify-content-between align-items-center">
                                                                                            <div style="display: block;"
                                                                                                 id="mma-ustbar"
                                                                                                 class="col-xl-auto col-12">
                                                                                                <div class="row align-items-center">
                                                                                                    <div class="col-auto">
                                                                                                        <div class="mma-image">
                                                                                                            <a id="profilegit"
                                                                                                               alt=""
                                                                                                               href="javascript:void(0)">
                                                                                                                <?php if (strpos($user->kullanici_resim, "/.jpg") !== false) { ?>
                                                                                                                    <img src="https://ui-avatars.com/api/?name=<?= $user->kullanici_isim ?>+<?= $user->kullanici_soyisim ?>&background=0D8ABC&color=fff"
                                                                                                                         alt=""
                                                                                                                         id="pp">
                                                                                                                <?php } else { ?>
                                                                                                                    <img id="pp"
                                                                                                                         alt=""
                                                                                                                         src="<?= base_url($user->kullanici_resim) ?>">
                                                                                                                <?php } ?>
                                                                                                            </a>
                                                                                                        </div>
                                                                                                    </div>
                                                                                                    <div class="col-auto">
                                                                                                        <div class="mma-name"
                                                                                                             id="mma-name">
                                                                                                            <?php echo $user->kullanici_ad ?>
                                                                                                        </div>
                                                                                                    </div>
                                                                                                    <marquee class="duyurutext">
                                                                                                        <?php echo $ayarlar->mesaj_detay_kayan_yazi ?>
                                                                                                    </marquee>
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div class="chat-bar">

                                                                                        </div>
                                                                                        <div class="mm-chat-sender">
                                                                                            <div class="row no-gutters chat-container">
                                                                                                <div class="col-xl-11 col-10">
                                                                                                    <input style="display: block;"
                                                                                                           id="sendmessage"
                                                                                                           type="text"
                                                                                                           class="chat-input"
                                                                                                           name="remessage"
                                                                                                           placeholder="Bir şeyler yazın...">
                                                                                                </div>
                                                                                                <div class="col-xl-1 col-2">
                                                                                                    <button
                                                                                                            style="display: block;"
                                                                                                            id="sendmessagebutton"
                                                                                                            data-target="<?php echo $val->uniq ?>"
                                                                                                            class="chat-button sendReMessage"></button>
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                <?php } ?>
                                                                            <?php } ?>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </main>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="tab-pane fade" id="advert" role="tabpanel"
                                         aria-labelledby="advert-tab" tabindex="0">
                                        <div class="container-fluid">
                                            <div class="k-panel-content-box">
                                                <div class="row">
                                                    <div class="col-12">
                                                        <div class="col-12">
                                                            <div class="kpc-tt">
                                                                İlanlarım
                                                            </div>
                                                        </div>
                                                        <div class="col-12">
                                                            <ul class="nav nav-pills bg-nav-pills mb-3"
                                                                id="pills-tab" role="tablist">
                                                                <li class="nav-item" role="presentation">
                                                                    <button class="nav-link active"
                                                                            id="pills-active-advert-2-tab"
                                                                            data-bs-toggle="pill"
                                                                            data-bs-target="#pills-active-advert-2"
                                                                            type="button" role="tab"
                                                                            aria-controls="pills-active-advert-2"
                                                                            aria-selected="true">Aktif
                                                                        İlanlar
                                                                    </button>
                                                                </li>
                                                                <li class="nav-item" role="presentation">
                                                                    <button class="nav-link"
                                                                            id="pills-ads-awaiting-approval-2-tab"
                                                                            data-bs-toggle="pill"
                                                                            data-bs-target="#pills-ads-awaiting-approval-2"
                                                                            type="button" role="tab"
                                                                            aria-controls="pills-ads-awaiting-approval-2"
                                                                            aria-selected="false">Onay Bekleyen
                                                                        İlanlar
                                                                    </button>
                                                                </li>
                                                                <li class="nav-item" role="presentation">
                                                                    <button class="nav-link"
                                                                            id="pills-pasive-advert-2-tab"
                                                                            data-bs-toggle="pill"
                                                                            data-bs-target="#pills-pasive-advert-2"
                                                                            type="button" role="tab"
                                                                            aria-controls="pills-pasive-advert-2"
                                                                            aria-selected="false">Pasif
                                                                        İlanlar
                                                                    </button>
                                                                </li>
                                                            </ul>
                                                            <div class="tab-content" id="pills-tabContent">
                                                                <div class="tab-pane fade show active"
                                                                     id="pills-active-advert-2" role="tabpanel"
                                                                     aria-labelledby="pills-active-advert-2-tab">
                                                                    <?php if (!empty($aktif_ilanlar)) { ?>
                                                                        <?php foreach ($aktif_ilanlar as $key => $val) { ?>
                                                                            <div class="kpc-item">
                                                                                <div class="kpc-border">
                                                                                    <a href="<?php echo base_url($val->urun_seo) ?>">
                                                                                        <img src="<?php echo base_url($val->urun_resim_min) ?>"
                                                                                             alt=""
                                                                                             class="rounded img-4by3-lg product-table-img"></a>
                                                                                    <div class="product-name-panel">
                                                                                        <h4 class="custom-text-area">
                                                                                            <a href="<?php echo base_url($val->urun_seo) ?>"
                                                                                               class="custom-text"><?php echo $val->urun_ad ?></a>
                                                                                        </h4>
                                                                                    </div>
                                                                                    <ul class="list-inline font-size-xs mb-0">
                                                                                        <li class="list-inline-item">
                                                                                            <i class="far fa-clock mr-1"></i>
                                                                                            <?php echo $val->urun_zaman ?>
                                                                                        </li>
                                                                                    </ul>
                                                                                    <div class="align-middle border-top-0">
                                                                                        <span class="badge badge-success">Yayınlandı</span>
                                                                                    </div>
                                                                                    <div class="gain-price-area">
                                                                                        <div class="price-box">
                                                                                            Fiyat:
                                                                                            <span><?php echo $val->urun_fiyat ?>₺</span>
                                                                                        </div>
                                                                                    </div>
                                                                                    <span class="dropdown">
                                                                                        <a class="text-muted text-decoration-none"
                                                                                           href="#!" role="button"
                                                                                           id="courseDropdown"
                                                                                           data-toggle="dropdown"
                                                                                           aria-haspopup="true"
                                                                                           aria-expanded="false">
                                                                                            <i class="fe fe-more-vertical"></i>
                                                                                        </a>
                                                                                        <span class="dropdown-menu"
                                                                                              aria-labelledby="courseDropdown">
                                                                                            <span class="dropdown-header">İşlemler
                                                                                            </span>
                                                                                            <a class="dropdown-item"
                                                                                               href="<?php echo base_url('ilan-duzenle/' . $val->urun_uniq) ?>"><i
                                                                                                        class="fe fe-edit dropdown-item-icon"></i><span
                                                                                                        class="text-white">İlanı
                                                                                                    Düzenle</span></a>
                                                                                            <a class="dropdown-item"
                                                                                               href="<?php echo base_url('ilan-galeri/' . $val->urun_uniq) ?>"><i
                                                                                                        class="fe fe-image dropdown-item-icon"></i><span
                                                                                                        class="text-white">Galeri
                                                                                                    Düzenle</span></a>
                                                                                            <a class="dropdown-item remove-btn"
                                                                                               href="javascript:void(0)"
                                                                                               data-url="<?php echo base_url('urun-sil/' . $val->urun_uniq) ?>"><i
                                                                                                        class="fe fe-trash dropdown-item-icon"></i><span
                                                                                                        class="text-white">Sil</span></a>
                                                                                        </span>
                                                                                    </span>
                                                                                </div>
                                                                            </div>
                                                                        <?php } ?>
                                                                    <?php } else { ?>
                                                                        <div class="alert alert-primary"
                                                                             role="alert">
                                                                            Aktif İlanınız Bulunmamaktadır. <a
                                                                                    href="<?php echo base_url('ilan-ekle') ?>">Yeni
                                                                                İlan</a> Ekliyebilirsiniz.
                                                                        </div>
                                                                    <?php } ?>
                                                                </div>
                                                                <div class="tab-pane fade"
                                                                     id="pills-ads-awaiting-approval-2"
                                                                     role="tabpanel"
                                                                     aria-labelledby="pills-ads-awaiting-approval-2-tab">
                                                                    <?php if (!empty($bekleyen_ilanlar)) { ?>
                                                                        <?php foreach ($bekleyen_ilanlar as $key => $val) { ?>
                                                                            <div class="kpc-item">
                                                                                <div class="kpc-border">
                                                                                    <a target="_blank"
                                                                                       href="javascript:void(0)">
                                                                                        <img src="<?php echo base_url($val->urun_resim_min) ?>"
                                                                                             alt=""
                                                                                             class="rounded img-4by3-lg product-table-img">
                                                                                    </a>
                                                                                    <div class="product-name-panel">
                                                                                        <h4 class="custom-text-area">
                                                                                            <a target="_blank"
                                                                                               href="javascript:void(0)"
                                                                                               class="custom-text"><?php echo $val->urun_ad ?></a>
                                                                                        </h4>
                                                                                    </div>
                                                                                    <ul class="list-inline font-size-xs mb-0">
                                                                                        <li class="list-inline-item">
                                                                                            <i class="far fa-clock mr-1"></i>
                                                                                            <?php echo $val->urun_zaman ?>
                                                                                        </li>
                                                                                    </ul>
                                                                                    <div class="align-middle border-top-0">
                                                                                                <span class="badge badge-warning">Yayınlanmayı
                                                                                                    Bekliyor..
                                                                                                </span>
                                                                                    </div>

                                                                                    <div class="gain-price-area">
                                                                                        <div class="price-box">
                                                                                            Fiyat:
                                                                                            <span><?php echo $val->urun_fiyat ?>₺</span>
                                                                                        </div>
                                                                                    </div>
                                                                                    <span class="dropdown">
                                                                                        <a class="text-muted text-decoration-none"
                                                                                           href="#!" role="button"
                                                                                           id="courseDropdown"
                                                                                           data-toggle="dropdown"
                                                                                           aria-haspopup="true"
                                                                                           aria-expanded="false">
                                                                                            <i
                                                                                                    class="fe fe-more-vertical"></i>
                                                                                        </a>
                                                                                        <span class="dropdown-menu"
                                                                                              aria-labelledby="courseDropdown">
                                                                                            <span
                                                                                                    class="dropdown-header">İşlemler
                                                                                            </span>
                                                                                            <a class="dropdown-item"
                                                                                               href="<?php echo base_url('ilan-duzenle/' . $val->urun_uniq) ?>"><i
                                                                                                        class="fe fe-edit dropdown-item-icon"></i><span
                                                                                                        class="text-white">İlanı
                                                                                                    Düzenle</span></a>
                                                                                            <a class="dropdown-item"
                                                                                               href="<?php echo base_url('ilan-galeri/' . $val->urun_uniq) ?>"><i
                                                                                                        class="fe fe-image dropdown-item-icon"></i><span
                                                                                                        class="text-white">Galeri
                                                                                                    Düzenle</span></a>
                                                                                            <a class="dropdown-item remove-btn"
                                                                                               href="javascript:void(0)"
                                                                                               data-url="<?php echo base_url('urun-sil/' . $val->urun_uniq) ?>"><i
                                                                                                        class="fe fe-trash dropdown-item-icon"></i><span
                                                                                                        class="text-white">Sil</span></a>
                                                                                        </span>
                                                                                    </span>
                                                                                </div>
                                                                            </div>
                                                                        <?php } ?>
                                                                    <?php } else { ?>
                                                                        <div class="alert alert-primary"
                                                                             role="alert">
                                                                            Onay Bekleyen İlanınız
                                                                            Bulunmamaktadır. <a
                                                                                    href="<?php echo base_url('ilan-ekle') ?>">Yeni
                                                                                İlan</a> Ekliyebilirsiniz.
                                                                        </div>
                                                                    <?php } ?>
                                                                </div>
                                                                <div class="tab-pane fade"
                                                                     id="pills-pasive-advert-2" role="tabpanel"
                                                                     aria-labelledby="pills-pasive-advert-2-tab">
                                                                    <?php if (!empty($pasif_ilanlar)) { ?>
                                                                        <?php foreach ($pasif_ilanlar as $key => $val) { ?>
                                                                            <div class="kpc-item">
                                                                                <div class="kpc-border">
                                                                                    <a href="javascript:void(0)">
                                                                                        <img src="<?php echo base_url($val->urun_resim_min) ?>"
                                                                                             alt=""
                                                                                             class="rounded img-4by3-lg product-table-img"></a>

                                                                                    <div class="product-name-panel">
                                                                                        <h4 class="custom-text-area">
                                                                                            <a href="javascript:void(0)"
                                                                                               class="custom-text"><?php echo $val->urun_ad ?></a>
                                                                                        </h4>
                                                                                    </div>
                                                                                    <ul class="list-inline font-size-xs mb-0">
                                                                                        <li class="list-inline-item">
                                                                                            <i class="far fa-clock mr-1"></i>
                                                                                            <?php echo $val->urun_zaman ?>
                                                                                        </li>
                                                                                    </ul>
                                                                                    <div class="align-middle border-top-0">
                                                                                        <span class="badge badge-danger">Pasif</span>
                                                                                    </div>

                                                                                    <div class="gain-price-area">
                                                                                        <div class="price-box">
                                                                                            Fiyat:
                                                                                            <span><?php echo $val->urun_fiyat ?>₺</span>
                                                                                        </div>
                                                                                    </div>
                                                                                    <span class="dropdown">
                                                                                        <a class="text-muted text-decoration-none"
                                                                                           href="#!" role="button"
                                                                                           id="courseDropdown"
                                                                                           data-toggle="dropdown"
                                                                                           aria-haspopup="true"
                                                                                           aria-expanded="false">
                                                                                            <i class="fe fe-more-vertical"></i>
                                                                                        </a>
                                                                                        <span class="dropdown-menu"
                                                                                              aria-labelledby="courseDropdown">
                                                                                            <span class="dropdown-header">İşlemler
                                                                                            </span>
                                                                                            <a class="dropdown-item"
                                                                                               href="<?php echo base_url('ilan-duzenle/' . $val->urun_uniq) ?>"><i
                                                                                                        class="fe fe-edit dropdown-item-icon"></i><span
                                                                                                        class="text-white">İlanı
                                                                                                    Düzenle</span></a>
                                                                                            <a class="dropdown-item"
                                                                                               href="<?php echo base_url('ilan-galeri/' . $val->urun_uniq) ?>"><i
                                                                                                        class="fe fe-image dropdown-item-icon"></i><span
                                                                                                        class="text-white">Galeri
                                                                                                    Düzenle</span></a>
                                                                                            <a class="dropdown-item remove-btn" href=""
                                                                                               data-url="<?php echo base_url('urun-sil/' . $val->urun_uniq) ?>"><i
                                                                                                        class="fe fe-trash dropdown-item-icon"></i><span
                                                                                                        class="text-white">Sil</span></a>
                                                                                        </span>
                                                                                    </span>
                                                                                </div>
                                                                            </div>
                                                                        <?php } ?>
                                                                    <?php } else { ?>
                                                                        <div class="alert alert-primary mt-3"
                                                                             role="alert">
                                                                            Pasif İlanınız
                                                                            Bulunmamaktadır. <a
                                                                                    href="<?php echo base_url('ilan-ekle') ?>">Yeni
                                                                                İlan</a> Ekliyebilirsiniz.
                                                                        </div>
                                                                    <?php } ?>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="tab-pane fade" id="product-evaluation" role="tabpanel"
                                         aria-labelledby="product-evaluation-tab" tabindex="0">
                                        <div class="container-fluid">
                                            <div class="k-panel-content-box">
                                                <div class="row">
                                                    <div class="col-12">
                                                        <div class="kpc-tt">
                                                            İlanlarınıza Yapılan Yorumlar
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-12 col-md-12">
                                                        <div class="dashboard-list-box  margin-top-0">
                                                            <ul class="dw-item-list">
                                                                <?php if ($yorumlar) { ?>
                                                                    <?php foreach ($yorumlar as $key) { ?>
                                                                        <li class="dw-item">
                                                                            <div class="comments listing-reviews">
                                                                                <ul class="dw-item-sub-list">
                                                                                    <li class="dw-item-sub-list-item">
                                                                                        <div class="avatar">
                                                                                            <?php if (strpos($key->kullanici_resim, "/.jpg") !== false) { ?>
                                                                                                <img src="https://ui-avatars.com/api/?name=<?= $key->kullanici_isim ?>+<?= $key->kullanici_soyisim ?>&background=0D8ABC&color=fff" alt="Avatar">
                                                                                            <?php } else { ?>
                                                                                                <img src="<?= base_url() . $key->kullanici_resim ?>" alt="<?= $key->kullanici_isim . " " . $key->kullanici_soyisim ?>"/>
                                                                                            <?php } ?>
                                                                                        </div>
                                                                                        <div class="comment-content">
                                                                                            <div class="arrow-comment">
                                                                                            </div>
                                                                                            <div class="comment-by">
                                                                                                <?= $key->kullanici_isim . " " . $key->kullanici_soyisim ?>
                                                                                                <div class="comment-by-listing">
                                                                                                    - <a href="<?= base_url($key->urun_seo) ?>"><?= $key->urun_ad ?>
                                                                                                    </a>
                                                                                                </div>
                                                                                                <span class="date"><?= zamanCevir($key->yorum_zaman) ?></span>
                                                                                                <div class="star-rating"
                                                                                                     data-rating="<?= $key->yorum_puan ?>">
                                                                                                </div>
                                                                                            </div>
                                                                                            <p><?= $key->yorum_detay ?>
                                                                                            </p>
                                                                                            <?php if ($key->yorum_durum == 0) { ?>
                                                                                                <div class="notification warning closeable text-center">
                                                                                                    <p><span>Yorum Yönetim
                                                                                                        Tarafından Onay
                                                                                                        Beklemektedir</span>
                                                                                                    </p>
                                                                                                </div>
                                                                                            <?php } ?>
                                                                                        </div>
                                                                                    </li>
                                                                                </ul>
                                                                            </div>
                                                                        </li>
                                                                    <?php } ?>
                                                                <?php } else { ?>
                                                                    <div class="alert alert-primary mt-3"
                                                                         role="alert">
                                                                        İlan Yorumunuz Bulunmamaktadır.
                                                                    </div>
                                                                <?php } ?>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="tab-pane fade" id="sales" role="tabpanel"
                                         aria-labelledby="sales-tab" tabindex="0">
                                        <div class="container-fluid">
                                            <div class="k-panel-content-box">
                                                <div class="row">
                                                    <div class="col-12">
                                                        <div class="kpc-tt">
                                                            Satışlarım
                                                        </div>
                                                    </div>
                                                    <div class="col-12">
                                                        <div class="my-sales-tabs">
                                                            <ul class="nav nav-pills bg-nav-pills mb-3"
                                                                id="pills-tab" role="tablist">
                                                                <li class="nav-item" role="presentation">
                                                                    <button class="nav-link active"
                                                                            id="pills-waiting-2-tab"
                                                                            data-bs-toggle="pill"
                                                                            data-bs-target="#pills-waiting-2"
                                                                            type="button" role="tab"
                                                                            aria-controls="pills-waiting-2"
                                                                            aria-selected="true">Bekleyen
                                                                    </button>
                                                                </li>
                                                                <li class="nav-item" role="presentation">
                                                                    <button class="nav-link"
                                                                            id="pills-complate-2-tab"
                                                                            data-bs-toggle="pill"
                                                                            data-bs-target="#pills-complate-2"
                                                                            type="button" role="tab"
                                                                            aria-controls="pills-complate-2"
                                                                            aria-selected="false">Tamamlanan
                                                                    </button>
                                                                </li>
                                                                <li class="nav-item" role="presentation">
                                                                    <button class="nav-link"
                                                                            id="pills-cancel-2-tab"
                                                                            data-bs-toggle="pill"
                                                                            data-bs-target="#pills-cancel-2"
                                                                            type="button" role="tab"
                                                                            aria-controls="pills-cancel-2"
                                                                            aria-selected="false">İptal
                                                                        Edilenler
                                                                    </button>
                                                                </li>
                                                            </ul>
                                                            <div class="tab-content" id="pills-tabContent">
                                                                <div class="tab-pane fade show active"
                                                                     id="pills-waiting-2" role="tabpanel"
                                                                     aria-labelledby="pills-waiting-2-tab">
                                                                    <div class="sales-box-warper">
                                                                        <div class="sale-cards">
                                                                            <div class="sale-container">
                                                                                <div class="sale-card">
                                                                                    <div class="product-detail">
                                                                                        <div class="sale-img"><a
                                                                                                    href=""><img src="https://kemalellidort.com.tr/uploads/urunler/images/min/8399e2b6f9b8a91709d8dbbffc4b6e18.png"></a>
                                                                                        </div>
                                                                                        <div
                                                                                                class="product-info">
                                                                                            <div class="p-name">
                                                                                                <a href="">Silkroad
                                                                                                    Turkey 300
                                                                                                    Silk</a>
                                                                                            </div>
                                                                                            <div
                                                                                                    class="p-price">
                                                                                                Fiyat:
                                                                                                <span>180
                                                                                                            TL</span>
                                                                                            </div>
                                                                                            <div
                                                                                                    class="p-price">
                                                                                                Toplam
                                                                                                Kazanç:<span>360.00
                                                                                                            TL</span>
                                                                                            </div>
                                                                                            <div
                                                                                                    class="p-quantity">
                                                                                                Adet:<span>2</span>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div
                                                                                            class="sale-status status-0">
                                                                                        <i
                                                                                                class="fa-solid fa-gauge-high"></i>
                                                                                        Teslimat bekliyor
                                                                                        <button
                                                                                                class="btn btn-primary btn-sm sale-detail-button align-self-end mt-2"
                                                                                                data-bs-toggle="modal"
                                                                                                data-bs-target="#info-modal-3">
                                                                                            İletilen Bilgiler
                                                                                        </button>
                                                                                    </div>
                                                                                    <div class="sale-info">
                                                                                        <div class="s-date"><i
                                                                                                    class="fa-regular fa-clock"></i>2024-03-08
                                                                                            17:53:27
                                                                                        </div>
                                                                                        <div class="s-delivery">
                                                                                            Satıcı: <a
                                                                                                    class="p-seller"
                                                                                                    href="">admin</a>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="sale-alerts ">
                                                                                    <div>Teslim Yeri : denemee
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="modal fade" id="info-modal-3"
                                                                         tabindex="-1"
                                                                         aria-labelledby="exampleModalLabel"
                                                                         aria-hidden="true">
                                                                        <div class="modal-dialog">
                                                                            <div class="modal-content">
                                                                                <div class="modal-header">
                                                                                    <button type="button"
                                                                                            class="btn-close"
                                                                                            data-bs-dismiss="modal"
                                                                                            aria-label="Close"></button>
                                                                                </div>
                                                                                <div class="modal-body">
                                                                                    <div class="detail-data-rows">
                                                                                        <div class="detail-data-row">
                                                                                                    <span class="detail-data-name">Oyundaki
                                                                                                        Karakter Adınız
                                                                                                        :</span><span
                                                                                                    class="detail-data-val">eeeee</span>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div
                                                                                        class="modal-footer boder-0">
                                                                                    <button type="button"
                                                                                            class="btn btn-secondary"
                                                                                            data-bs-dismiss="modal">
                                                                                        Kapat
                                                                                    </button>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="tab-pane fade" id="pills-complate-2"
                                                                     role="tabpanel"
                                                                     aria-labelledby="pills-complate-2-tab">
                                                                    <div class="sale-cards">
                                                                        <div class="sale-container">
                                                                            <div class="sale-card">
                                                                                <div class="product-detail">
                                                                                    <div class="sale-img">
                                                                                        <a href="">
                                                                                            <img src="https://bursagb.s3.eu-central-1.amazonaws.com/AGARTHA_1691835141.webp">
                                                                                        </a>
                                                                                    </div>
                                                                                    <div class="product-info">
                                                                                        <div class="p-name">
                                                                                            <a href="">Agartha
                                                                                                10M Gold Bar</a>
                                                                                        </div>
                                                                                        <div class="p-price">
                                                                                            Fiyat: <span>32.21
                                                                                                        TL</span>
                                                                                        </div>
                                                                                        <div class="p-price">
                                                                                            Toplam Kazanç:
                                                                                            <span>32.21
                                                                                                        TL</span>
                                                                                        </div>
                                                                                        <div class="p-quantity">
                                                                                            Adet: <span>1</span>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="sale-info">
                                                                                    <div class="s-date">
                                                                                        <i class="fa-regular fa-clock"></i>
                                                                                        2024-03-07 14:16:57
                                                                                    </div>
                                                                                    <div class="s-delivery">
                                                                                        Teslimat Tarihi:
                                                                                        <span>2024-03-07
                                                                                                    17:41:34</span>
                                                                                    </div>
                                                                                    <div class="s-delivery">
                                                                                        Satıcı: <a
                                                                                                class="p-seller"
                                                                                                href="">Hyper</a>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div
                                                                                    class="sale-status status-1 dflx">
                                                                                <div class="te-ip">
                                                                                    <i
                                                                                            class="fa-solid fa-circle-check"></i>
                                                                                    Teslim edildi
                                                                                </div>
                                                                                <div class="s-name">
                                                                                    Teslim edilecek karakter
                                                                                    adı:
                                                                                    <span>*******</span>
                                                                                </div>
                                                                                <div class="btn btn-primary btn-sm sale-detail-button align-self-end ">
                                                                                    İletilen Bilgiler
                                                                                </div>

                                                                            </div>
                                                                            <div class="sale-alerts">
                                                                                <div>Teslimat Yeri : Agartha 2.
                                                                                    Server Folk
                                                                                    Banka Teslimat '' TRADE ''
                                                                                    ile yapılır.
                                                                                    Takas geçmeden önce
                                                                                    belirtilen alanda
                                                                                    hazır olunuz.
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="tab-pane fade" id="pills-cancel-2"
                                                                     role="tabpanel"
                                                                     aria-labelledby="pills-cancel-2-tab">
                                                                    <div class="sale-cards">
                                                                        <div class="sale-container">
                                                                            <div class="sale-card">
                                                                                <div class="product-detail">
                                                                                    <div class="sale-img">
                                                                                        <a href="">
                                                                                            <img src="https://bursagb.s3.eu-central-1.amazonaws.com/AGARTHA_1691835141.webp">
                                                                                        </a>
                                                                                    </div>
                                                                                    <div class="product-info">
                                                                                        <div class="p-name">
                                                                                            <a href="">Agartha
                                                                                                10M Gold Bar</a>
                                                                                        </div>
                                                                                        <div class="p-price">
                                                                                            Fiyat: <span>32.20
                                                                                                        TL</span>
                                                                                        </div>
                                                                                        <div class="p-price">
                                                                                            Toplam Kazanç:
                                                                                            <span>64.40
                                                                                                        TL</span>
                                                                                        </div>
                                                                                        <div class="p-quantity">
                                                                                            Adet: <span>2</span>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div
                                                                                        class="sale-status status-2">
                                                                                    <i
                                                                                            class="fa-solid fa-ban"></i>
                                                                                    İptal edildi
                                                                                    <div
                                                                                            class="btn btn-primary btn-sm sale-detail-button align-self-end mt-2">
                                                                                        İletilen Bilgiler
                                                                                    </div>
                                                                                </div>
                                                                                <div class="sale-info">
                                                                                    <div class="s-date">
                                                                                        <i
                                                                                                class="fa-regular fa-clock"></i>
                                                                                        2024-03-09 17:44:25
                                                                                    </div>
                                                                                    <div class="s-delivery">
                                                                                        Satıcı: <a
                                                                                                class="p-seller"
                                                                                                href="">Hyper</a>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="sale-alerts red">
                                                                                Satışınız iptal
                                                                                edilmiştir. Karakter Oyunda yada
                                                                                Teslimat
                                                                                Noktasında Değil.
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="tab-pane fade" id="gains" role="tabpanel"
                                         aria-labelledby="gains-tab" tabindex="0">
                                        <div class="container-fluid">
                                            <div class="k-panel-content-box">
                                                <div class="row">
                                                    <div class="col-12">
                                                        <div class="kpc-tt">
                                                            Mağzam
                                                        </div>
                                                    </div>
                                                    <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 mb-3">
                                                        <div class="card">
                                                            <div class="card-content">
                                                                <div class="card-body mh-85 bc-22">
                                                                    <div class="card-img-body">
                                                                        <div class="media ">
                                                                            <div class="card-img-body-warper">
                                                                                <img class="card-img-body-icon"
                                                                                     src="assets/images/ty1.png"
                                                                                     alt="">
                                                                            </div>
                                                                            <div
                                                                                    class="media-body text-right-c">
                                                                                <h3>5349.00 TL</h3>
                                                                                <span>Toplam Ödenen Kazanç
                                                                                        </span>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 mb-3">
                                                        <div class="card">
                                                            <div class="card-content">
                                                                <div class="card-body mh-85 bc-22">
                                                                    <div class="card-img-body">
                                                                        <div class="media  ">
                                                                            <div class="card-img-body-warper">
                                                                                <img class="card-img-body-icon"
                                                                                     src="https://kemalellidort.com.tr/assets/yonetim/img/wallet.png"
                                                                                     alt="">
                                                                            </div>
                                                                            <div
                                                                                    class="media-body text-right-c">
                                                                                <h3>5349.00 TL</h3>
                                                                                <span>Ödenebilir Kazanç</span>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 mb-3">
                                                        <div class="card">
                                                            <div class="card-content">
                                                                <div class="card-body mh-85 bc-22">
                                                                    <div class="card-img-body">
                                                                        <div class="media  ">
                                                                            <div class="card-img-body-warper">
                                                                                <img class="card-img-body-icon"
                                                                                     src="https://kemalellidort.com.tr/assets/yonetim/img/wallet.png"
                                                                                     alt="">
                                                                            </div>
                                                                            <div
                                                                                    class="media-body text-right-c">
                                                                                <h3>5349.00 TL</h3>
                                                                                <span>Şimdiye Kadarki
                                                                                            Kazanç</span>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 mb-3">
                                                        <div class="card">
                                                            <div class="card-content">
                                                                <div class="card-body mh-85 bc-22">
                                                                    <div class="card-img-body">
                                                                        <div class="media  ">
                                                                            <div class="card-img-body-warper">
                                                                                <img class="card-img-body-icon"
                                                                                     src="https://kemalellidort.com.tr/assets/yonetim/img/wallet.png"
                                                                                     alt="">
                                                                            </div>
                                                                            <div
                                                                                    class="media-body text-right-c">
                                                                                <h3>5349.00 TL</h3>
                                                                                <span>Bu Ay Toplam
                                                                                            Kazancınız</span>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 mb-3">
                                                        <div class="card">
                                                            <div class="card-content">
                                                                <div class="card-body mh-85 bc-22">
                                                                    <div class="card-img-body">
                                                                        <div class="media  ">
                                                                            <div class="card-img-body-warper">
                                                                                <img class="card-img-body-icon"
                                                                                     src="https://kemalellidort.com.tr/assets/yonetim/img/wallet.png"
                                                                                     alt="">
                                                                            </div>
                                                                            <div
                                                                                    class="media-body text-right-c">
                                                                                <h3>5349.00 TL</h3>
                                                                                <span>Bugün Toplam
                                                                                            Kazancınız</span>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-12">
                                                        <div id="earning" class="apex-charts"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="tab-pane fade" id="raffle" role="tabpanel"
                                         aria-labelledby="raffle-tab" tabindex="0">
                                        <div class="container-fluid">
                                            <div class="k-panel-content-box">
                                                <div class="row">
                                                    <div class="col-12">
                                                        <div class="kpc-tt">
                                                            Çekilişler
                                                        </div>
                                                        <ul class="nav nav-pills bg-nav-pills mb-3"
                                                            id="pills-tab" role="tablist">
                                                            <li class="nav-item" role="presentation">
                                                                <button class="nav-link active"
                                                                        id="pills-raffle-confim-tab"
                                                                        data-bs-toggle="pill"
                                                                        data-bs-target="#pills-raffle-confim"
                                                                        type="button" role="tab"
                                                                        aria-controls="pills-raffle-confim"
                                                                        aria-selected="true">Onaylanan
                                                                    Çekilişler
                                                                </button>
                                                            </li>
                                                            <li class="nav-item" role="presentation">
                                                                <button class="nav-link"
                                                                        id="pills-waiting-raffle-tab"
                                                                        data-bs-toggle="pill"
                                                                        data-bs-target="#pills-waiting-raffle"
                                                                        type="button" role="tab"
                                                                        aria-controls="pills-waiting-raffle"
                                                                        aria-selected="false">Onay Bekleyen
                                                                    Çekilişler
                                                                </button>
                                                            </li>
                                                            <li class="nav-item" role="presentation">
                                                                <button class="nav-link"
                                                                        id="pills-denied-raffle-tab"
                                                                        data-bs-toggle="pill"
                                                                        data-bs-target="#pills-denied-raffle"
                                                                        type="button" role="tab"
                                                                        aria-controls="pills-denied-raffle"
                                                                        aria-selected="false">İptal Edilen
                                                                    Çeklişler
                                                                </button>
                                                            </li>
                                                        </ul>
                                                        <div class="tab-content" id="pills-tabContent">
                                                            <div class="tab-pane fade show active"
                                                                 id="pills-raffle-confim" role="tabpanel"
                                                                 aria-labelledby="pills-raffle-confim-tab">
                                                                <?php if (!empty($aktif_cekilisler)) { ?>
                                                                    <?php foreach ($aktif_cekilisler as $key => $val) { ?>
                                                                        <div class="kpc-item">
                                                                            <div class="kpc-border">
                                                                                <div class="raffle-id">
                                                                                    <span># <?php echo $val->id ?></span>
                                                                                </div>
                                                                                <div class="product-name-panel">
                                                                                    <h4 class="custom-text-area">
                                                                                        <a target="_blank"
                                                                                           href=""
                                                                                           class="custom-text"><?php echo $val->title ?></a>
                                                                                    </h4>
                                                                                </div>
                                                                                <ul
                                                                                        class="list-inline font-size-xs mb-0">
                                                                                    <li class="list-inline-item">
                                                                                        <i
                                                                                                class="far fa-clock mr-1"></i>
                                                                                        <?php echo $val->end_date ?>
                                                                                    </li>
                                                                                </ul>

                                                                                <div class="align-middle border-top-0">
                                                                                    <?php if ($val->turu == 1) { ?>
                                                                                        <span class="badge badge-info">Ürün Çekilişi</span>
                                                                                    <?php } elseif ($val->turu == 2) { ?>
                                                                                        <span class="badge badge-info">Bakiye Çekilişi</span>
                                                                                    <?php } ?>
                                                                                </div>

                                                                                <div class="align-middle border-top-0">
                                                                                    <span class="badge badge-success">Onaylandı</span>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    <?php } ?>
                                                                <?php } else { ?>
                                                                    <div class="alert alert-primary"
                                                                         role="alert">
                                                                        Aktif Çekilişiniz Bulunmamaktadır. <a
                                                                                href="<?php echo base_url('cekilis/olustur') ?>">Yeni
                                                                            Çekiliş</a> Ekliyebilirsiniz.
                                                                    </div>
                                                                <?php } ?>
                                                            </div>
                                                            <div class="tab-pane fade" id="pills-waiting-raffle"
                                                                 role="tabpanel"
                                                                 aria-labelledby="pills-waiting-raffle-tab">
                                                                <?php if (!empty($bekleyen_cekilisler)) { ?>
                                                                    <?php foreach ($bekleyen_cekilisler as $key => $val) { ?>
                                                                        <div class="kpc-item">
                                                                            <div class="kpc-border">
                                                                                <div class="raffle-id">
                                                                                    <span># <?php echo $val->id ?></span>
                                                                                </div>
                                                                                <div class="product-name-panel">
                                                                                    <h4 class="custom-text-area">
                                                                                        <a href="javascript:void(0)"
                                                                                           class="custom-text"><?php echo $val->title ?></a>
                                                                                    </h4>
                                                                                </div>
                                                                                <ul class="list-inline font-size-xs mb-0">
                                                                                    <li class="list-inline-item">
                                                                                        <i class="far fa-clock mr-1"></i>
                                                                                        <?php echo $val->end_date ?>
                                                                                    </li>
                                                                                </ul>

                                                                                <div class="align-middle border-top-0">
                                                                                    <?php if ($val->turu == 1) { ?>
                                                                                        <span class="badge badge-info">Ürün Çekilişi</span>
                                                                                    <?php } elseif ($val->turu == 2) { ?>
                                                                                        <span class="badge badge-info">Bakiye Çekilişi</span>
                                                                                    <?php } ?>
                                                                                </div>

                                                                                <div class="align-middle border-top-0">
                                                                                    <span class="badge badge-warning">Onay Bekliyor...</span>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    <?php } ?>
                                                                <?php } else { ?>
                                                                    <div class="alert alert-primary"
                                                                         role="alert">
                                                                        Onay Çekilişiniz Bulunmamaktadır. <a
                                                                                href="<?php echo base_url('cekilis/olustur') ?>">Yeni
                                                                            Çekiliş</a> Ekliyebilirsiniz.
                                                                    </div>
                                                                <?php } ?>
                                                            </div>
                                                            <div class="tab-pane fade" id="pills-denied-raffle"
                                                                 role="tabpanel"
                                                                 aria-labelledby="pills-denied-raffle-tab">
                                                                <?php if (!empty($iptal_cekilisler)) { ?>
                                                                    <?php foreach ($iptal_cekilisler as $key => $val) { ?>
                                                                        <div class="kpc-item">
                                                                            <div class="kpc-border">
                                                                                <div class="raffle-id">
                                                                                    <span># <?php echo $val->id ?></span>
                                                                                </div>
                                                                                <div class="product-name-panel">
                                                                                    <h4 class="custom-text-area">
                                                                                        <a href="javascript:void(0)"
                                                                                           class="custom-text"><?php echo $val->title ?></a>
                                                                                    </h4>
                                                                                </div>
                                                                                <ul class="list-inline font-size-xs mb-0">
                                                                                    <li class="list-inline-item">
                                                                                        <i class="far fa-clock mr-1"></i>
                                                                                        <?php echo $val->end_date ?>
                                                                                    </li>
                                                                                </ul>

                                                                                <div class="align-middle border-top-0">
                                                                                    <?php if ($val->turu == 1) { ?>
                                                                                        <span class="badge badge-info">Ürün Çekilişi</span>
                                                                                    <?php } elseif ($val->turu == 2) { ?>
                                                                                        <span class="badge badge-info">Bakiye Çekilişi</span>
                                                                                    <?php } ?>
                                                                                </div>

                                                                                <div class="align-middle border-top-0">
                                                                                    <span class="badge badge-danger">İptal Edildi</span>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    <?php } ?>
                                                                <?php } else { ?>
                                                                    <div class="alert alert-primary"
                                                                         role="alert">
                                                                        İptal Edilen Çekilişiniz
                                                                        Bulunmamaktadır. <a
                                                                                href="<?php echo base_url('cekilis/olustur') ?>">Yeni
                                                                            Çekiliş</a> Ekliyebilirsiniz.
                                                                    </div>
                                                                <?php } ?>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="tab-pane fade" id="atq" role="tabpanel"
                                         aria-labelledby="atq-tab" tabindex="0">
                                        <div class="container-fluid">
                                            <div class="k-panel-content-box">
                                                <div class="row">
                                                    <div class="col-12">
                                                        <div class="kpc-tt">
                                                            İlan Sorularım
                                                        </div>
                                                        <?php if (!empty($sorular)) { ?>
                                                            <?php foreach ($sorular as $key => $val) { ?>
                                                                <div class="kpc-item">
                                                                    <div class="kpc-border">
                                                                        <a href="<?php echo base_url($val->urun_seo) ?>">
                                                                            <img src="<?php echo base_url($val->urun_resim_min) ?>"
                                                                                 alt=""
                                                                                 class="rounded img-4by3-lg product-table-img">
                                                                        </a>
                                                                        <div class="product-name-panel">
                                                                            <h4 class="custom-text-area">
                                                                                <a href="<?php echo base_url($val->urun_seo) ?>"
                                                                                   class="custom-text"><?php echo $val->urun_ad ?></a>
                                                                            </h4>
                                                                        </div>
                                                                        <ul class="list-inline font-size-xs mb-0">
                                                                            <li class="list-inline-item">
                                                                                <i class="far fa-clock mr-1"></i>
                                                                                <?= ayli_tarih($val->tarih) ?>
                                                                            </li>
                                                                        </ul>
                                                                        <div class="align-middle border-top-0">
                                                                            <?php if (empty($val->soru_cevap)) { ?>
                                                                                <span class="badge badge-warning">Cevap Bekliyor..</span>
                                                                            <?php } else { ?>
                                                                                <span class="badge badge-success">Cevap Verildi</span>
                                                                            <?php } ?>
                                                                        </div>
                                                                        <div class="atq-modal-btn">
                                                                            <button type="button"
                                                                                    class="btn btn-primary"
                                                                                    data-toggle="modal"
                                                                                    data-target="#sorucevap-<?php echo $val->soru_id ?>">
                                                                                <i class="far fa-eye"></i>
                                                                            </button>
                                                                            <button type="button"
                                                                                    onclick="window.location.href='<?php echo base_url($val->urun_seo) ?>'"
                                                                                    class="btn btn-info"><i
                                                                                        class="fas fa-external-link-alt"></i>
                                                                            </button>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="modal fade"
                                                                     id="sorucevap-<?php echo $val->soru_id ?>"
                                                                     tabindex="-1"
                                                                     role="dialog"
                                                                     aria-labelledby="exampleModalCenterTitle"
                                                                     aria-hidden="true">
                                                                    <div class="modal-dialog modal-dialog-centered"
                                                                         role="document">
                                                                        <div class="modal-content sms">
                                                                            <div class="modal-header">
                                                                                <h4 class="modal-title text-center"
                                                                                    id="exampleModalCenterTitle"><?php echo $val->urun_ad ?>
                                                                                    İlanınızın Sorusu</h4>
                                                                                <button type="button"
                                                                                        class="close"
                                                                                        data-dismiss="modal"
                                                                                        aria-label="Close">
                                                                                    <span aria-hidden="true">&times;</span>
                                                                                </button>
                                                                            </div>
                                                                            <div class="alert alert-info alert-dismissible text-left alert-grid"
                                                                                 role="alert">
                                                                                <i class="fas fa-question"></i>
                                                                                <div>
                                                                                    <strong>Soru:</strong><br><?php echo $val->soru ?>
                                                                                </div>
                                                                            </div>
                                                                            <?php if (!empty($val->soru_cevap)) { ?>
                                                                                <div
                                                                                        class="alert alert-info alert-dismissible text-left alert-grid"
                                                                                        role="alert">
                                                                                    <div>
                                                                                        <strong>Cevap:</strong><br><?php echo $val->soru_cevap->soru ?>
                                                                                    </div>
                                                                                </div>
                                                                            <?php } ?>
                                                                            <?php if (empty($val->soru_cevap)) { ?>
                                                                                <form class="p-2 soru-cevap-form">
                                                                                    <input type="hidden"
                                                                                           name="soru_id"
                                                                                           value="<?php echo $val->soru_id ?>">
                                                                                    <div class="row">
                                                                                        <div class="col-12">
                                                                                            <label class="form-label">Cevabınız</label>
                                                                                            <textarea
                                                                                                    class="form-control"
                                                                                                    name="cevap"
                                                                                                    placeholder="Lütfen Bir Cevap Yazınız..."
                                                                                                    rows="4"></textarea>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="py-2">
                                                                                        <button type="submit"
                                                                                                class="btn btn-primary rounded-pill soru-cevap-btn w-100">
                                                                                            Cevap Ver
                                                                                        </button>
                                                                                    </div>
                                                                                </form>
                                                                            <?php } ?>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            <?php } ?>
                                                        <?php } else { ?>
                                                            <div class="alert alert-primary mt-3"
                                                                 role="alert">
                                                                İlan Sorunuz Bulunmamaktadır.
                                                            </div>
                                                        <?php } ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="tab-pane fade" id="store-settings" role="tabpanel"
                                         aria-labelledby="store-settings-tab" tabindex="0">
                                        <div class="container-fluid">
                                            <div class="k-panel-content-box">
                                                <div class="row">
                                                    <div class="col-12">
                                                        <div class="kpc-tt">
                                                            Mağza Ayarlarım
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-lg-12 col-md-12">
                                                                <div class="dashboard-list-box margin-top-0">
                                                                    <div class="dashboard-list-box-static">
                                                                        <div class="tab-content p-4">
                                                                            <div class="tab-pane tab-example-design fade show active"
                                                                                 id="hesap-bilgileri"
                                                                                 role="tabpanel"
                                                                                 aria-labelledby="hesap-bilgileri-tab">

                                                                                <form method="post" action="<?php echo base_url('magaza-foto') ?>"
                                                                                      enctype="multipart/form-data">
                                                                                    <style>
                                                                                        .avatar-upload {
                                                                                            max-width: 100%;
                                                                                        }

                                                                                        .avatar-upload .avatar-preview {
                                                                                            width: 100%;
                                                                                            height: 120px;
                                                                                            position: relative;
                                                                                            border-radius:% 0;
                                                                                            border: none;
                                                                                            box-shadow: 0px 2px 4px 0px rgba(0, 0, 0, 0.1);
                                                                                        }

                                                                                        .avatar-upload .avatar-edit {
                                                                                            position: absolute;
                                                                                            right: 10px;
                                                                                            z-index: 1;
                                                                                            top: 10px;
                                                                                        }

                                                                                        .avatar-upload .avatar-preview > div {
                                                                                            width: 100%;
                                                                                            height: 100%;
                                                                                            border-radius: 0px;
                                                                                            background-size: cover;
                                                                                            background-repeat: no-repeat;
                                                                                            background-position: center;
                                                                                        }
                                                                                    </style>
                                                                                    <div style="display: flex;width: 100%">
                                                                                        <div class="avatar-upload" style="width: 50%;margin-left: 0; margin-right: 30px;">
                                                                                            <label>Mağaza Fotoğrafı</label>
                                                                                            <div class="avatar-edit">
                                                                                                <input type="file"
                                                                                                       id="imageUpload"
                                                                                                       name="file"
                                                                                                       accept=".png, .jpg, .jpeg">
                                                                                                <label for="imageUpload"></label>
                                                                                            </div>
                                                                                            <div class="avatar-preview">
                                                                                                <div id="imagePreview"
                                                                                                     style="background-image: url(<?php echo base_url($magaza->magaza_resim) ?>);background-position: center;">
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div class="avatar-upload" style="width: 50%;margin-left: 0; margin-right: 0;">
                                                                                            <label>Mağaza Banner Fotoğrafı</label>
                                                                                            <div class="avatar-edit">
                                                                                                <input type="file"
                                                                                                       id="bannerUpload"
                                                                                                       name="banner"
                                                                                                       accept=".png, .jpg, .jpeg">
                                                                                                <label for="bannerUpload"></label>
                                                                                            </div>
                                                                                            <div class="avatar-preview">
                                                                                                <div id="bannerPreview"
                                                                                                     style="background-position: center;background-image: url(<?php echo !empty($magaza->magaza_banner) ? base_url($magaza->magaza_banner) : 'https://kemalellidort.com.tr/assets/images/default-banner.jpeg' ?>);">
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="row">
                                                                                        <div class="form-group col-12 col-md-6">
                                                                                            <label class="form-label">Mağaza
                                                                                                Adı</label>
                                                                                            <input type="text"
                                                                                                   class="form-control"
                                                                                                   placeholder="Mağaza Adı"
                                                                                                   value="<?= $magaza->magaza_ad ?>"
                                                                                                   disabled>
                                                                                        </div>

                                                                                        <div class="form-group col-12 col-md-6">
                                                                                            <label class="form-label">Mağaza
                                                                                                Türü</label>
                                                                                            <input type="text"
                                                                                                   class="form-control"
                                                                                                   placeholder="Mağaza Türü"
                                                                                                   value="<?= ucwords(strtolower($magaza->magaza_tur)) ?>"
                                                                                                   disabled>
                                                                                        </div>

                                                                                        <div class="col-md-12" <?php echo ($magaza->magaza_tur != 'kurumsal') ? 'style="display:none"' : '' ?>>
                                                                                            <div class="row">
                                                                                                <div class="form-group col-md-12">
                                                                                                    <label class="form-label">Firma
                                                                                                        Adı</label>
                                                                                                    <input type="text"
                                                                                                           class="form-control"
                                                                                                           placeholder="Mağaza Türü"
                                                                                                           value="<?= $magaza->firma_ad ?>"
                                                                                                           disabled>
                                                                                                </div>

                                                                                                <div class="form-group col-12 col-md-6">
                                                                                                    <label class="form-label">Vergi
                                                                                                        Dairesi</label>
                                                                                                    <input type="text"
                                                                                                           class="form-control"
                                                                                                           placeholder="Vergi Dairesi"
                                                                                                           value="<?= $magaza->vergi_dairesi ?>"
                                                                                                           disabled>
                                                                                                </div>

                                                                                                <div class="form-group col-12 col-md-6">
                                                                                                    <label class="form-label">Vergi
                                                                                                        Numarası</label>
                                                                                                    <input type="text"
                                                                                                           class="form-control"
                                                                                                           placeholder="Vergi Numarası"
                                                                                                           value="<?= $magaza->vergi_numarasi ?>"
                                                                                                           disabled>
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>

                                                                                        <div class="form-group col-12 col-md-6">
                                                                                            <label class="form-label">Adınız</label>
                                                                                            <input type="text"
                                                                                                   class="form-control"
                                                                                                   placeholder="Adınız"
                                                                                                   value="<?= $magaza->isim ?>"
                                                                                                   disabled>
                                                                                        </div>

                                                                                        <div class="form-group col-12 col-md-6">
                                                                                            <label class="form-label">Soyadınız</label>
                                                                                            <input type="text"
                                                                                                   class="form-control"
                                                                                                   placeholder="Soyadınız"
                                                                                                   value="<?= $magaza->soyisim ?>"
                                                                                                   disabled>
                                                                                        </div>

                                                                                        <div class="form-group col-12 col-md-6">
                                                                                            <label class="form-label">TC
                                                                                                Kimlik
                                                                                                Numarası</label>
                                                                                            <input type="text"
                                                                                                   class="form-control"
                                                                                                   placeholder="TC Kimlik Numarası"
                                                                                                   value="<?= $magaza->tc ?>"
                                                                                                   disabled>
                                                                                        </div>

                                                                                        <div class="form-group col-12 col-md-6">
                                                                                            <label class="form-label">Doğum
                                                                                                Tarihi</label>
                                                                                            <input type="text"
                                                                                                   class="form-control"
                                                                                                   placeholder="Doğum Tarihi"
                                                                                                   value="<?= $magaza->dogum_tarihi ?>"
                                                                                                   disabled>
                                                                                        </div>

                                                                                        <div class="form-group col-12 col-md-6">
                                                                                            <label class="form-label">Şehir</label>
                                                                                            <input type="text"
                                                                                                   class="form-control"
                                                                                                   placeholder="Şehir"
                                                                                                   value="<?= sehir_ad($magaza->sehir) ?>"
                                                                                                   disabled>
                                                                                        </div>

                                                                                        <div class="form-group col-12 col-md-6">
                                                                                            <label class="form-label">İlçe</label>
                                                                                            <input type="text"
                                                                                                   class="form-control"
                                                                                                   placeholder="İlçe"
                                                                                                   value="<?= ilce_ad($magaza->ilce) ?>"
                                                                                                   disabled>
                                                                                        </div>

                                                                                        <div class="form-group col-12 col-md-12">
                                                                                            <label class="form-label">Fatura
                                                                                                Adresi</label>
                                                                                            <textarea
                                                                                                    class="form-control"
                                                                                                    rows="4"
                                                                                                    disabled><?= $magaza->fatura_adres ?></textarea>
                                                                                        </div>

                                                                                    </div>

                                                                                    <button type="submit"
                                                                                            class="btn btn-primary rounded-pill mt-3">
                                                                                        Fotoğraf Güncelle
                                                                                    </button>
                                                                                </form>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php } ?>

<div class="alt-content k-panel-g-warper m-bg">
    <?php if (magaza(kullanicicek()->kullanici_id)->magaza_id == $magaza->magaza_id) { ?>
        <div class="col-xl-3 col-lg-3 col-md-12 col-sm-12 wd-none mt-3 p-0">
            <div class="accordion accordion-flush acc-kpc-menu" id="accordionFlushExample">
                <div class="accordion-item acc-kpc-menu-item">
                    <h2 class="accordion-header acc-kpc-menu-header" id="flush-headingOne">
                        <button class="accordion-button collapsed acc-kpc-menu-btn" type="button"
                                data-bs-toggle="collapse" data-bs-target="#flush-collapseOne"
                                aria-expanded="false"
                                aria-controls="flush-collapseOne">
                            Hızlı Menü
                        </button>
                    </h2>
                    <div id="flush-collapseOne" class="accordion-collapse collapse"
                         aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
                        <div class="accordion-body acc-kpc-menu-body">
                            <div class="k-panel-left-navbar-warper">
                                <div class="k-panel-left-navbar-area">
                                    <div class="nav flex-column nav-pills bg-custom-nav " id="v-pills-tab"
                                         role="tablist" aria-orientation="vertical">

                                        <button class="nav-link kpc-nav-btn active" id="store-tab"
                                                data-bs-toggle="pill" data-bs-target="#store" type="button"
                                                role="tab"
                                                aria-controls="store" aria-selected="true">Mağzam
                                        </button>

                                        <button class="nav-link kpc-nav-btn" id="advert-tab"
                                                data-bs-toggle="pill"
                                                data-bs-target="#advert" type="button" role="tab"
                                                aria-controls="advert"
                                                aria-selected="false">İlanlarım
                                        </button>

                                        <button class="nav-link kpc-nav-btn" id="atq-tab" data-bs-toggle="pill"
                                                data-bs-target="#atq" type="button" role="tab"
                                                aria-controls="atq"
                                                aria-selected="false">İlan Sorularım
                                        </button>

                                        <button class="nav-link kpc-nav-btn" id="product-evaluation-tab"
                                                data-bs-toggle="pill" data-bs-target="#product-evaluation"
                                                type="button"
                                                role="tab" aria-controls="product-evaluation"
                                                aria-selected="false">İlan
                                            Yorumları
                                        </button>

                                        <button class="nav-link kpc-nav-btn" id="raffle-tab"
                                                data-bs-toggle="pill"
                                                data-bs-target="#raffle" type="button" role="tab"
                                                aria-controls="raffle"
                                                aria-selected="false">Çekilişlerim
                                        </button>

                                        <button class="nav-link kpc-nav-btn" id="store-settings-tab"
                                                data-bs-toggle="pill" data-bs-target="#store-settings"
                                                type="button"
                                                role="tab" aria-controls="store-settings" aria-selected="false">
                                            Mağza
                                            Ayarlarım
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php } ?>

    <?php if (magaza(kullanicicek()->kullanici_id)->magaza_id != $magaza->magaza_id) { ?>
        <div class="col-12 p-0">
            <ul class="nav nav-pills justify-content-end bg-none mb-3 spsw" id="pills-tab" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link kpc-nav-btn w-spacial active" id="classifieds-tab" data-bs-toggle="pill" data-bs-target="#classifieds" type="button" role="tab" aria-controls="classifieds" aria-selected="true"><img class="btn-img" src="<?= base_url('assets/front/images/s5.png') ?>" alt=""> İlanlar</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link kpc-nav-btn w-spacial" id="Advert-store-tab" data-bs-toggle="pill" data-bs-target="#Advert-store" type="button" role="tab" aria-controls="Advert-store" aria-selected="false"><img class="btn-img" src="<?= base_url('assets/front/images/s3.png') ?>" alt="">İlan Yorumları</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link kpc-nav-btn w-spacial" id="ranks-tab" data-bs-toggle="pill" data-bs-target="#ranks" type="button" role="tab" aria-controls="ranks" aria-selected="false"><img class="btn-img" src="<?= base_url('assets/front/images/star-medal.png') ?>" alt="">Rütbeler</button>
                </li>
            </ul>
        </div>
        <div class="srb-content">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="tab-content" id="pills-tabContent">
                            <div class="tab-pane fade show active" id="classifieds" role="tabpanel" aria-labelledby="classifieds-tab" tabindex="0">
                                <div class="kpc-ofcer-area">
                                    <div class="container">
                                        <div class="content-boxi">
                                            <div class="row">
                                                <?php
                                                if ($urunler) {
                                                    foreach ($urunler as $urun) { ?>
                                                        <div class="col-xl-2 col-lg-3 col-md-6 col-12 mb-3">
                                                            <div class="product-item">
                                                                <div class="pimg-base">
                                                                    <a title="<?= base_url($urun->urun_ad) ?>" href="<?php echo base_url($urun->urun_seo) ?>" tabindex="0">
                                                                        <?php if (!$magaza && $urun->urun_eski_fiyat > $urun->urun_fiyat):
                                                                            $oran = 100 - ceil($urun->urun_fiyat * 100 / $urun->urun_eski_fiyat);
                                                                            ?>
                                                                            <div class="DiscountBox">
                                                                        <span>
                                                                            <b><?= $oran ?>%</b>
                                                                            <small>İndirim</small>
                                                                        </span>
                                                                            </div>
                                                                        <?php endif; ?>
                                                                        <img class="product-image lazy entered loaded" alt="<?php echo $urun->urun_ad ?>" src="<?php echo base_url($urun->urun_resim) ?>" loading="lazy">
                                                                    </a>
                                                                </div>
                                                                <a title="<?php echo $urun->urun_ad ?>" href="<?php echo base_url($urun->urun_seo) ?>" tabindex="0"></a>
                                                                <div class="product-detail s-detail"><a title="<?php echo $urun->urun_ad ?>" href="<?php echo $urun->urun_seo ?>" tabindex="0">
                                                                        <div class="slg-box">
                                                                            <span class="product-name d-block threedots color-white"><?php echo $urun->urun_ad ?></span>
                                                                            <div class="product-info-bottom">
                                                                                <div class="star-rating-container">
                                                                                    <ul role="radiogroup" class="star-rating">
                                                                                        <li role="radio" aria-setsize="1" aria-checked="true" aria-posinset="1" aria-label="1" disabled="" style="margin: 0px 2px;">
                                                                                            <div class="star-div">
                                                                                                <img width="12" height="12" src="https://kemalellidort.com.tr/assets/front/images/star/rating_star.webp" alt="star">
                                                                                            </div>
                                                                                            <img width="12" height="12" src="https://kemalellidort.com.tr/assets/front/images/star/rating_star.webp" alt="star gray">
                                                                                        </li>
                                                                                        <li role="radio" aria-setsize="2" aria-checked="true" aria-posinset="1" aria-label="1" disabled="" style="margin: 0px 2px;">
                                                                                            <div class="star-div">
                                                                                                <img width="12" height="12" src="https://kemalellidort.com.tr/assets/front/images/star/rating_star.webp" alt="star">
                                                                                            </div>
                                                                                            <img width="12" height="12" src="https://kemalellidort.com.tr/assets/front/images/star/rating_star.webp" alt="star gray">
                                                                                        </li>
                                                                                        <li role="radio" aria-setsize="3" aria-checked="true" aria-posinset="1" aria-label="1" disabled="" style="margin: 0px 2px;">
                                                                                            <div class="star-div">
                                                                                                <img width="12" height="12" src="https://kemalellidort.com.tr/assets/front/images/star/rating_star.webp" alt="star">
                                                                                            </div>
                                                                                            <img width="12" height="12" src="https://kemalellidort.com.tr/assets/front/images/star/rating_star.webp" alt="star gray">
                                                                                        </li>
                                                                                        <li role="radio" aria-setsize="4" aria-checked="true" aria-posinset="1" aria-label="1" disabled="" style="margin: 0px 2px;">
                                                                                            <div class="star-div">
                                                                                                <img width="12" height="12" src="https://kemalellidort.com.tr/assets/front/images/star/rating_star.webp" alt="star">
                                                                                            </div>
                                                                                            <img width="12" height="12" src="https://kemalellidort.com.tr/assets/front/images/star/rating_star.webp" alt="star gray">
                                                                                        </li>
                                                                                        <li role="radio" aria-setsize="5" aria-checked="true" aria-posinset="1" aria-label="1" disabled="" style="margin: 0px 2px;">
                                                                                            <div class="star-div">
                                                                                                <img width="12" height="12" src="https://kemalellidort.com.tr/assets/front/images/star/rating_star.webp" alt="star">
                                                                                            </div>
                                                                                            <img width="12" height="12" src="https://kemalellidort.com.tr/assets/front/images/star/rating_star.webp" alt="star gray">
                                                                                        </li>
                                                                                        <li><span style="margin-left: 5px"> (3)</span></li>
                                                                                    </ul>
                                                                                </div>
                                                                                <div class="product-price pull-left">
                                                                                    <div class="sales-price fw-600 fs-18">
                                                                                        <?= $urun->urun_fiyat ?>
                                                                                        <span class="price-type"> ₺</span>
                                                                                    </div>
                                                                                    <?php if ($urun->urun_eski_fiyat != '0.00') { ?>
                                                                                        <div class="list-price">
                                                                                            <?= $urun->urun_eski_fiyat ?>
                                                                                            ₺
                                                                                        </div>
                                                                                    <?php } ?>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    <?php }
                                                } else { ?>
                                                    <div class="col-md-12">
                                                        <div class="alert alert-warning text-center">
                                                            Mağazaya Ait İlan Bulunamadı
                                                        </div>
                                                    </div>
                                                <?php } ?>
                                                <?= $links ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="Advert-store" role="tabpanel" aria-labelledby="Advert-store-tab" tabindex="0">
                                <div class="bg-reviews p-3 product-det-reviews">
                                    <div class="d-flex flex-wrap ii-review align-items-center justify-content-xl-between">
                                        <div class="pdr-col">
                                            <div class="fs-12 font-weight-bold">
                                                <div class="total-value d-flex align-items-center">
                                                    <div class="value mr-2">
                                                        <?php
                                                        $rating = empty($rating) ? 0 : $rating;

                                                        echo $rating;
                                                        ?>
                                                    </div>
                                                    <div class="stars">
                                                        <?php if ($rating == 0) { ?>
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                        <?php } else if ($rating >= 1 && $rating < 2) { ?>
                                                            <i class="fas fa-star rated" style="color:#E4B91D!important;"></i>
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                        <?php } else if ($rating >= 2 && $rating < 3) {?>
                                                            <i class="fas fa-star rated" style="color:#E4B91D!important;"></i>
                                                            <i class="fas fa-star rated" style="color:#E4B91D!important;"></i>
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                        <?php } else if ($rating >= 3 && $rating < 4) {?>
                                                            <i class="fas fa-star rated" style="color:#E4B91D!important;"></i>
                                                            <i class="fas fa-star rated" style="color:#E4B91D!important;"></i>
                                                            <i class="fas fa-star rated" style="color:#E4B91D!important;"></i>
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                        <?php } else if ($rating >= 4 && $rating < 5) {?>
                                                            <i class="fas fa-star rated" style="color:#E4B91D!important;"></i>
                                                            <i class="fas fa-star rated" style="color:#E4B91D!important;"></i>
                                                            <i class="fas fa-star rated" style="color:#E4B91D!important;"></i>
                                                            <i class="fas fa-star rated" style="color:#E4B91D!important;"></i>
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                        <?php } else if ($rating == 5 || $rating > 5) { ?>
                                                            <i class="fas fa-star rated" style="color:#E4B91D!important;"></i>
                                                            <i class="fas fa-star rated" style="color:#E4B91D!important;"></i>
                                                            <i class="fas fa-star rated" style="color:#E4B91D!important;"></i>
                                                            <i class="fas fa-star rated" style="color:#E4B91D!important;"></i>
                                                            <i class="fas fa-star rated" style="color:#E4B91D!important;"></i>
                                                        <?php } ?>
                                                    </div>
                                                </div>
                                                <?php echo count($yorumlar) ?> Değerlendirme
                                            </div>
                                        </div>
                                        <div class="pdr-col">
                                            <div class="pdr-text">
                                                <div class="fs-12 font-weight-bold">Bilgilendirme</div>
                                                Bu kısımda satıcıya ait yorumları görüntüleyebilirsiniz.
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="review-comments">
                                    <div class="rc-answer d-flex flex-wrap align-items-center rc-kp-row">
                                        <?php if ($yorumlar) {
                                            foreach ($yorumlar as $yorum) { ?>
                                                <div class="media w-100 align-items-center">
                                                    <div class="user-comment-logo">
                                                        <?php if (strpos($yorum->kullanici_resim, "/.jpg") !== false) { ?>
                                                            <img src="https://ui-avatars.com/api/?name=<?= $yorum->kullanici_isim ?>&background=0D8ABC&color=fff"
                                                                 alt="<?= $yorum->kullanici_isim . " " . $yorum->kullanici_soyisim ?>"
                                                                 class="rounded-circle avatar-lg"/>
                                                        <?php } else { ?>
                                                            <img src="<?= base_url($yorum->kullanici_resim) ?>"
                                                                 alt="<?= $yorum->kullanici_isim . " " . $yorum->kullanici_soyisim ?>"
                                                                 class="rounded-circle avatar-lg"/>
                                                        <?php } ?>
                                                    </div>
                                                    <div class="ml-3 mt-2 media-body">
                                                        <div class="d-flex align-items-center justify-content-between">
                                                            <div  class="d-flex align-items-center">
                                                                <h4 class="mb-0"><?= $yorum->kullanici_isim . " " . $yorum->kullanici_soyisim ?>
                                                                </h4>
                                                                <span class="ml-2">
                                                        <?= yorum_yildiz($yorum->yorum_puan) ?>
                                                    </span>
                                                            </div>
                                                            <span class="text-muted font-size-xs"><?= date('d.m.Y H:i', strtotime($yorum->yorum_zaman)) ?></span>
                                                        </div>
                                                        <div class="mt-2">
                                                            <p class="mt-2"><?= $yorum->yorum_detay ?></p>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php }
                                        } else { ?>
                                            <div class="alert alert-warning text-center">
                                                Ürüne ait yorum bulunamadı.
                                            </div>
                                        <?php } ?>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="ranks" role="tabpanel" aria-labelledby="ranks-tab" tabindex="0">
                                <div class="bg-reviews p-3 product-det-reviews">
                                    <div class="rank-warper">
                                        <div class="alert alert-info text-center w-100">
                                            Rütbe Sistemi Çok Yakında Aktif Olacaktır.
                                        </div>
                                       <?php if (1 == 2) { ?>
                                        <div class="ranks-item">
                                            <img class="btn-img" src="<?= base_url('assets/front/images/s3.png') ?>" alt=""> <span>Yeni Üye</span>
                                        </div>
                                        <div class="ranks-item">
                                            <img class="btn-img" src="<?= base_url('assets/front/images/s3.png') ?>" alt=""> <span>Yeni Üye</span>
                                        </div>
                                        <div class="ranks-item">
                                            <img class="btn-img" src="<?= base_url('assets/front/images/s3.png') ?>" alt=""> <span>Yeni Üye</span>
                                        </div>
                                        <div class="ranks-item">
                                            <img class="btn-img" src="<?= base_url('assets/front/images/s3.png') ?>" alt=""> <span>Yeni Üye</span>
                                        </div>
                                        <?php } ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php } ?>

</div>
</div>
</section>

<div class="modal fade" id="sohbet" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
     aria-hidden="true">
    <form action="" method="post" id="infoSohbet">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="form-group">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                        <label for="recipient-name" class="col-form-label">Sohbet'i başlatmak istediğiniz üyenin
                            kullanıcı adını
                            yazın</label>
                        <input name="username" type="text" class="form-control" id="recipient-name"
                               placeholder="Üyenin Kullanıcı Adı">
                        <label for="message-text" class="col-form-label">Mesajınız:</label>
                        <textarea rows="4" cols="50" class="form-control" name="gidicekmesaj" id="mesaj"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-info btn-lg btn-block">Sohbeti Başlat</button>
                </div>
            </div>
        </div>
    </form>
</div>
<script>
    $('.chat-list-name li').click(function () {
        var select_chat = $(this).attr('data-target');
        if ($('.chat-area').hasClass('open')) {
            $('.chat-area').removeClass('open')
            $('#select-chat-' + select_chat).addClass('open')
        } else {
            $('#select-chat-' + select_chat).addClass('open')
        }
    })

    $('#sendmessage').keypress(function (e) {
        if (e.which === 13) {
            $('.sendReMessage').click()
        }
    })

    $(document).on("submit", "#infoSohbet", function (event) {
        <?php if (aktif_kullanici()) : ?>
        $.ajax({
            type: "POST",
            url: base_url + "ajax_controller/sohbet_add_mesaj",
            data: {
                mesaj: $('textarea[name="gidicekmesaj"]').val(),
                username: $('input[name="username"]').val(),
                kullanici_id: <?=  $kullanici->kullanici_id ?>
            },
            success: function (data) {
                var d = JSON.parse(data);
                if (d.status.status == 'error') {
                    Swal.fire(
                        'Hata!',
                        d.status.message,
                        d.status.status,
                    );
                } else if (d.status.status == 'success') {
                    Swal.fire(
                        'Başarılı!',
                        d.status.message,
                        d.status.status,
                    ).then((result) => {
                        location.reload();
                    })
                }

            }
        })
        ;
        event.preventDefault();
        <?php else : ?>
        Swal.fire({
            title: 'Giriş Yap',
            text: "Mesajlaşmak için giriş yapmalısınız.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Giriş Yap',
            cancelButtonText: 'Hayır, İptal Et',
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = "<?= base_url('giris-yap') ?>";
            }
        }) <?php endif; ?>
    });

    $(document).on("click", ".menu-left-area", function (event) {
        <?php if (aktif_kullanici()): ?>
        var uniq = $(this).data('target');
        $.ajax({
            type: "POST",
            url: base_url + "ajax_controller/sohbet_getir",
            data: {
                uniq: uniq,
                kullanici_id: <?= $kullanici->kullanici_id ?>
            },
            success: function (data) {
                var d = JSON.parse(data);
                if (d.status == 'error') {
                    Swal.fire(
                        'Hata!',
                        d.message,
                        d.status,
                    );
                } else if (d.status == 'success') {
                    var targetDiv = $('#select-chat-' + uniq).find('.chat-bar');
                    targetDiv.html(d.html); // İçerik kısmını kendi isteğinize göre güncelleyin
                    $('.chat-bar').scrollTop($('.chat-bar')[0].scrollHeight)
                }

            }
        });
        event.preventDefault();
        <?php else : ?>
        Swal.fire({
            title: 'Giriş Yap',
            text: "Mesajlaşmak için giriş yapmalısınız.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Giriş Yap',
            cancelButtonText: 'Hayır, İptal Et',
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = "<?= base_url('giris-yap') ?>";
            }
        }) <?php endif; ?>
    });

    $(document).on("click", ".sendReMessage", function (event) {
        <?php if (aktif_kullanici()): ?>
        var inputValue = $(this).closest('.chat-container').find('input[name="remessage"]').val();
        var uniq = $(this).data('target');
        $.ajax({
            type: "POST",
            url: base_url + "ajax_controller/send_re_message",
            data: {
                uniq: uniq,
                kullanici_id: <?= $kullanici->kullanici_id ?> ,
                message: inputValue
            },
            success: function (data) {
                var d = JSON.parse(data);
                if (d.status == 'error') {
                    Swal.fire(
                        'Hata!',
                        d.message,
                        d.status,
                    );
                } else if (d.status == 'success') {
                    var targetDiv = $('#select-chat-' + uniq).find('.chat-bar');
                    targetDiv.append(d.html); // İçerik kısmını kendi isteğinize göre güncelleyin
                    $('#sendmessage').val(' ');
                    $('.chat-bar').scrollTop($('.chat-bar')[0].scrollHeight)
                }

            }
        });
        event.preventDefault();
        <?php else : ?>
        Swal.fire({
            title: 'Giriş Yap',
            text: "Mesajlaşmak için giriş yapmalısınız.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Giriş Yap',
            cancelButtonText: 'Hayır, İptal Et',
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = "<?= base_url('giris-yap') ?>";
            }
        }) <?php endif; ?>
    });

    $(document).ready(function () {
        $(".soru-cevap-form").submit(function (event) {
            event.preventDefault();
            var serialized = $(this).serializeArray();
            $.ajax({
                type: "POST",
                url: base_url + "ajax_controller/soru_cevap",
                data: serialized,
                success: function (data) {
                    var d = JSON.parse(data);
                    if (d.status.status == 'error') {
                        Swal.fire(
                            'Hata!',
                            d.status.message,
                            d.status.status,
                        );
                    } else if (d.status.status == 'success') {
                        Swal.fire(
                            'Başarılı!',
                            d.status.message,
                            d.status.status,
                        ).then((result) => {
                            location.reload();
                        })
                    }

                }
            });
        });

    });
</script>

<div class="modal fade" id="teldogrula_step_1" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
     aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content sms">
            <div class="modal-header">
                <h4 class="modal-title text-center" id="exampleModalCenterTitle">Telefon Doğrulama</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="tel-dogrula-alert">
                <div class="alert alert-danger alert-dismissible text-left alert-grid" role="alert">
                    <i class="fas fa-check"></i>
                    <div><strong>Doğrulama Gerekiyor</strong><br>
                        Ödeme bildirimi oluşturabilmek için telefon numaranızı doğrulamanız gerekmektedir.
                    </div>
                </div>
            </div>
            <div class="p-2">
                <div class="row">
                    <div class="col-12">
                        <label class="form-label">Telefon No</label>
                        <input type="text" class="form-control" name="telefon" id="telefon" value="0" maxlength="11">
                    </div>
                </div>
                <div class="py-2">
                    <button type="button" class="btn btn-primary rounded-pill tel-dogrula-button w-100"
                            data-id="<?php echo $kullanici->kullanici_id ?>">SMS Gönder
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="teldogrula" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
     aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content sms">
            <div class="modal-header">
                <h4 class="modal-title text-center" id="exampleModalCenterTitle">Telefon Doğrulama</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="tel-dogrula-alert">
                <div class="alert alert-success alert-dismissible text-left alert-grid" role="alert">
                    <i class="fas fa-check"></i>
                    <div><strong>Başarılı</strong><br>
                        Doğrulama Kodunuz Başarılı Şekilde Gönderilmiştir. Lütfen Aşağıda ki alana kodu giriniz.
                    </div>
                </div>
            </div>
            <style>
                #countdown {
                    display: none;
                    font-size: 15px;
                    margin-left: 5px;
                    margin-top: 7px;
                }

                .countdown-area {
                    display: flex;
                    margin-top: 5px;
                    margin-bottom: 10px;
                }
            </style>
            <form class="p-2 tel-dogrulama-form" method="post">
                <div class="row">
                    <div class="col-12">
                        <label class="form-label">Doğrulama Kodu</label>
                        <input type="text" class="form-control" name="tel_dogrulama">
                    </div>
                </div>
                <div class="py-2">
                    <div class="countdown-area">
                        <button id="sendSMS" type="button" data-id="<?php echo $kullanici->kullanici_id ?>"
                                class="btn btn-warning rounded-pill">SMS Gönder
                        </button>
                        <div id="countdown"></div>
                    </div>
                    <button type="submit" class="btn btn-primary rounded-pill soru-sor-btn w-100">Doğrula</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php if ($kullanici->tel_dogrula == 0) { ?>
    <script>
        var countdownTimer;
        var countdownDuration = 60; // 60 saniye

        function startCountdown() {
            $("#sendSMS").prop("disabled", true);
            $("#countdown").show();

            countdownTimer = setInterval(function () {
                $("#countdown").text("Kalan süre: " + countdownDuration + " saniye");

                if (countdownDuration === 0) {
                    clearInterval(countdownTimer);
                    $("#sendSMS").prop("disabled", false);
                    $("#countdown").hide();
                } else {
                    countdownDuration--;
                }
            }, 1000);
        }

        function resetCountdown() {
            clearInterval(countdownTimer);
            countdownDuration = 60;
            $("#sendSMS").prop("disabled", true);
            startCountdown();
        }

        // Sayfa yüklendiğinde otomatik geri sayım başlat
        //startCountdown();

        $("#sendSMS").click(function () {
            // Eğer geri sayım başlamamışsa başlat
            if (countdownDuration === 60) {
                startCountdown();
                var user = $(this).data('id');
                $.ajax({
                    type: "POST",
                    url: base_url + "ajax_controller/tel_dogrulama_resend",
                    data: {
                        kullanici: user,
                        telefon: $("#accountPhone").val()
                    },
                    success: function (data) {
                        var d = JSON.parse(data);
                        if (d.status.status == 'success') {
                            startCountdown();
                            $(".tel-dogrula-alert").html(d.status.alert_html);
                        } else {
                            $(".tel-dogrula-alert").html(d.status.alert_html);
                        }
                    }
                });
            } else {
                // Eğer geri sayım başlamışsa sıfırla ve tekrar başlat
                resetCountdown();
                var user = $(this).data('id');
                $.ajax({
                    type: "POST",
                    url: base_url + "ajax_controller/tel_dogrulama_resend",
                    data: {
                        kullanici: user,
                        telefon: $("#accountPhone").val()
                    },
                    success: function (data) {
                        var d = JSON.parse(data);
                        if (d.status.status == 'success') {
                            startCountdown();
                            $(".tel-dogrula-alert").html(d.status.alert_html);
                        } else {
                            $(".tel-dogrula-alert").html(d.status.alert_html);
                        }
                    }
                });
            }

            // Burada SMS gönderme işlemlerini gerçekleştirebilirsiniz.
        });


        $('.tel-dogrula-button').on('click', function () {
            var user = $(this).data('id');
            $.ajax({
                type: "POST",
                url: base_url + "ajax_controller/tel_dogrulama",
                data: {
                    kullanici: user,
                    telefon: $("#accountPhone").val()
                },
                success: function (data) {
                    var d = JSON.parse(data);
                    if (d.status.status == 'success') {
                        startCountdown();
                        $(".tel-dogrula-alert").html(d.status.alert_html);
                    } else {
                        $(".tel-dogrula-alert").html(d.status.alert_html);
                    }
                }
            });

        });

        $('.tel-dogrulama-form').on('submit', function () {
            var kod = $('input[name="tel_dogrulama"]').val();
            $.ajax({
                type: "POST",
                url: base_url + "ajax_controller/tel_kod_dogrulama",
                data: {
                    code: kod,
                },
                success: function (data) {
                    var d = JSON.parse(data);
                    if (d.status.status == 'success') {
                        Swal.fire(
                            'Başarılı!',
                            d.status.message,
                            d.status.status,
                        );
                        setTimeout(
                            function () {
                                window.location.reload();
                            }, 2000);
                    } else {
                        Swal.fire(
                            'Hata!',
                            d.status.message,
                            d.status.status,
                        );
                    }
                }
            });

        });
    </script>

<?php } ?>