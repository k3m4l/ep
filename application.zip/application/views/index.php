<div class="bg-white p-sec-20">
    <div class="container justify-content-center main-margin">
        <div class="row justify-content-center">
            <div class="col-xl-8 col-lg-8 col-md-12 col-sm-12 mb-2 spr-2 main-slider">
                <div class="swiper slider-big">
                    <div class="swiper-wrapper">
						<?php 
						$sliders = slidercek();
						if (!empty($sliders)) {
							foreach ($sliders as $slider) {
								if ($slider->tur != "1") continue;
								?>
								<div class="swiper-slide">
									<a href="<?= !empty($slider->slider_url) ? $slider->slider_url : '#' ?>"
									   title="<?= !empty($slider->slider_baslik) ? $slider->slider_baslik : '' ?>">
										<img src="<?= base_url(!empty($slider->slider_resim) ? $slider->slider_resim : 'uploads/slider/default.jpg') ?>" 
											 class="d-block w-100"
											 alt="<?= !empty($slider->slider_baslik) ? $slider->slider_baslik : '' ?>" 
											 loading="lazy">
									</a>
								</div>
							<?php }
						} ?>
					</div>
                    <div class="swiper-button-prev"></div>
                    <div class="swiper-button-next"></div>
                </div>
            </div>
            <div class="col-xl-4 col-lg-4 col-md-12 col-sm-12 mb-2 spl-0">
                <div class="row justify-content-center">
                    <?php $where = $this->yonetim_model->get_yan_slider(3); ?>
                    <div class="col-xl-12 col-lg-12 col-md-6 col-sm-6 mb-10px">
                        <a href="<?= $where->slider_url ?>" title="Yan Slider 3">
                            <div class="card bg-dark text-white slider-card">
                                <img class="right-slider" src="<?= base_url($where->slider_resim) ?>"
                                     alt="Yan Slider 3" loading="lazy">
                            </div>
                        </a>
                    </div>
                    <?php $where = $this->yonetim_model->get_yan_slider(4); ?>
                    <div class="col-xl-12 col-lg-12 col-md-6 col-sm-6 mb-10px">
                        <a href="<?= $where->slider_url ?>" title="Yan Slider 4">
                            <div class="card bg-dark text-white slider-card ">
                                <img class="right-slider" src="<?= base_url($where->slider_resim) ?>"
                                     alt="Yan Slider 4" loading="lazy">
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>
<div class="icon-facebook"></div>
<?php if (!empty($alt_slider)) { ?>
    <div class="container">
    <ul class="sb-card">
            <?php foreach ($alt_slider as $key => $val) { ?>
                <li class="sb-card-item">
                    <div class="salazr">
                        <a href="<?php echo $val->slider_url ?>">
                            <div class="img-sm-warper-bnr">
                                <div class="img-psl">
                                    <img class="sm-img" src="<?= base_url($val->slider_resim) ?>" loading="lazy"
                                        alt="<?php echo $val->slider_baslik ?>">
                                    <div class="dsc-sm">
                                        <span class="dsc-sm-tt"><?php echo $val->slider_baslik ?></span>
                                        <span class="dsc-sm-content"><?php echo $val->slider_aciklama ?></span>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                </li>
            <?php } ?>
        </ul>
    </div>
<?php } ?>


<div class="bg-white p-sec-20">
    <div class="container">
        <div class="col-12 p-0">
            <div class="swiper-tab sw-bg">
                <div class="swiper tab-co-slider">
                    <?php if (!empty($vitrin_1) && is_array($vitrin_1)): ?>
						<div class="swiper-wrapper">
							<?php foreach ($vitrin_1 as $keys => $vitrin): ?>
								<?php if (isset($vitrin->baslik)): // veya name, hangisi kullanılıyorsa ?>
									<div class="swiper-slide">
										<button class="btn taby-btn light-color-indexy <?= $keys == 0 ? 'active' : '' ?>"
												data-tb-id="#taby<?= $vitrin->id ?? $keys ?>">
											<?php if (!empty($vitrin->resim)): // veya icon ?>
												<img src="<?= base_url($vitrin->resim) ?>" 
													 width="32px" 
													 height="32px" 
													 alt="<?= htmlspecialchars($vitrin->baslik) ?>" 
													 loading="lazy">
											<?php endif; ?>
											<?php 
											$exploded = explode(' ', $vitrin->baslik);
											foreach ($exploded as $key => $txt) {
												echo $key == 0 ? "<b>" . htmlspecialchars($txt) . "</b>" : " " . htmlspecialchars($txt);
											}
											?>
										</button>
									</div>
								<?php endif; ?>
							<?php endforeach; ?>
						</div>
					<?php endif; ?>
                    <div class="swiper-button-next"></div>
                    <div class="swiper-button-prev"></div>
                </div>
            </div>
        </div>
        <div class="col-12 p-0">
            <div class="taby-content">
                <?php
                if ($vitrin_1) {
                    foreach ($vitrin_1 as $vkey => $vitrin) {
                        $tab_name = seo($vitrin->name);
                        $exploded = explode(' ', $vitrin->name);
                        ?>
                        <div class="tb-content <?= $vkey == 0 ? 'active' : '' ?>" id="taby<?= $vitrin->id ?>">
                            <div class="p-sec-20">
                                <?php
                                $vitrin_urunler = $this->db->select('u.*,m.*')
                                    ->join('urunler u', 'u.urun_id=vt.urun_id')
                                    ->join('magaza m', 'm.magaza_id=u.magaza_id', 'left')
                                    ->where('u.urun_durum', 1)
                                    ->where('vt.vitrin_id', $vitrin->id)
                                    ->order_by('vt.sira', 'ASC')
                                    ->get('vitrin_urunler vt')->result();
                                if ($vitrin_urunler) {
                                    ?>
                                    <div class="row mx-0">
                                        <?php foreach ($vitrin_urunler as $urun) {
                                            $json = json_decode($urun->kategori_json);
                                            $urun_kategori = $this->yonetim_model->kategoriget(array("kategori_id" => $json[0]));
                                            $magaza = false;
                                            if ($urun->magaza_id != null) {
                                                $magaza = magaza($urun->kullanici_id);
                                            }

                                            $yorumlar = $this->siparis_model->yorumlar(['urun_id' => $urun->urun_id, 'yorum_durum' => 1]);

                                            if (!empty($yorumlar)) {
                                                $yorumlar_yildiz_toplam = $this->siparis_model->yorum_yildiz_toplam($urun->urun_id);
                                                $rating = $yorumlar_yildiz_toplam->yorum_puan / count($yorumlar);
                                            }

                                            $rating = empty($rating) ? 0 : $rating;
                                        ?>
                                            <?php if ($vitrin->contents == 2) { // ilan ürünler kart tasarımı ?>
                                                <?php if ($urun->urun_bitis_tarihi > date('Y-m-d H:i:s')) { ?>
                                                <div class="col-xl-2 col-lg-3 col-md-6 col-12 mb-3 ">
                                                    <div class="product-item pioff-product-item">
                                                        <div class="pimg-base pioff-pimg-base">
                                                            <?php if (!$magaza && $urun->urun_eski_fiyat > $urun->urun_fiyat):
                                                                $oran = 100 - ceil($urun->urun_fiyat * 100 / $urun->urun_eski_fiyat);
                                                                ?>
                                                                <div class="DiscountBox">
                                                                    <span>
                                                                        <b><?= $oran ?>%</b>
                                                                        <small>İndirim</small>
                                                                    </span>
                                                                </div>
                                                            <?php endif; ?>
                                                            <div class="inline-platform-list">
                                                                <div class="swwr">
                                                                    <a href="<?= base_url('kategori/' . $urun_kategori->kategori_seo) ?>">
                                                                        <div class="img-platform-box mr-3">
                                                                            <img width="24" height="24"
                                                                                src="<?= $urun_kategori->kategori_resim; ?>"
                                                                                alt="<?= $urun_kategori->kategori_ad; ?>"
                                                                                loading="lazy" aria-label="<?php echo $urun_kategori->kategori_ad . ' Kategori' ?>">
                                                                        </div>
                                                                        <div class="img-pcn">
                                                                            <span><?= $urun_kategori->kategori_ad; ?></span>
                                                                        </div>
                                                                    </a>
                                                                </div>
                                                            </div>
                                                            <a href="<?php echo $urun->urun_seo ?>">
                                                                <img class="product-image pioff lazy entered loaded"
                                                                     alt="<?= $urun->urun_ad ?>"
                                                                     src="<?= base_url($magaza ? $urun->urun_resim_min : $urun->urun_resim); ?>"
                                                                     loading="lazy">
                                                            </a>
                                                            <div class="product-detail s-detail">
                                                                <a href="<?php echo $urun->urun_seo ?>">
                                                                    <span class="product-name d-block threedots color-white"><?= $urun->urun_ad ?></span>
                                                                </a>
                                                                <div class="product-info-bottom">
                                                                    <div class="star-rating-container">
                                                                        <ul class="star-rating">
                                                                            <?php if ($rating == 0) { ?>
                                                                                <li>
                                                                                    <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                </li>
                                                                                <li>
                                                                                    <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                </li>
                                                                                <li>
                                                                                    <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                </li>
                                                                                <li>
                                                                                    <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                </li>
                                                                                <li>
                                                                                    <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                </li>
                                                                            <?php } else if ($rating >= 1 && $rating < 2) { ?>
                                                                                <li>
                                                                                    <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star">
                                                                                </li>
                                                                                <li>
                                                                                    <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                </li>
                                                                                <li>
                                                                                    <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                </li>
                                                                                <li>
                                                                                    <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                </li>
                                                                                <li>
                                                                                    <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                </li>
                                                                            <?php } else if ($rating >= 2 && $rating < 3) { ?>
                                                                                <li>
                                                                                    <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star">
                                                                                </li>
                                                                                <li>
                                                                                    <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star">
                                                                                </li>
                                                                                <li>
                                                                                    <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                </li>
                                                                                <li>
                                                                                    <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                </li>
                                                                                <li>
                                                                                    <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                </li>
                                                                            <?php } else if ($rating >= 3 && $rating < 4) { ?>
                                                                                <li>
                                                                                    <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star">
                                                                                </li>
                                                                                <li>
                                                                                    <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star">
                                                                                </li>
                                                                                <li>
                                                                                    <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star">
                                                                                </li>
                                                                                <li>
                                                                                    <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                </li>
                                                                                <li>
                                                                                    <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                </li>
                                                                            <?php } else if ($rating >= 4 && $rating < 5) { ?>
                                                                                <li>
                                                                                    <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star">
                                                                                </li>
                                                                                <li>
                                                                                    <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star">
                                                                                </li>
                                                                                <li>
                                                                                    <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star">
                                                                                </li>
                                                                                <li>
                                                                                    <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star">
                                                                                </li>
                                                                                <li>
                                                                                    <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                </li>
                                                                            <?php } else if ($rating == 5 && $rating > 5) { ?>
                                                                                <li>
                                                                                    <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star">
                                                                                </li>
                                                                                <li>
                                                                                    <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star">
                                                                                </li>
                                                                                <li>
                                                                                    <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star">
                                                                                </li>
                                                                                <li>
                                                                                    <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star">
                                                                                </li>
                                                                                <li>
                                                                                    <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star">
                                                                                </li>
                                                                            <?php } else { ?>
                                                                                <li>
                                                                                    <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                </li>
                                                                                <li>
                                                                                    <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                </li>
                                                                                <li>
                                                                                    <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                </li>
                                                                                <li>
                                                                                    <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                </li>
                                                                                <li>
                                                                                    <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                </li>
                                                                            <?php } ?>
                                                                            <li>
                                                                                <span style="margin-left: 5px"> (<?php echo count($yorumlar) ?>)</span>
                                                                            </li>
                                                                        </ul>
                                                                    </div>
                                                                    <div class="product-price">
                                                                        <div class="sales-price fw-600 fs-18">
                                                                            <?= $urun->urun_fiyat ?>
                                                                            <span class="price-type"> ₺</span>
                                                                        </div>
                                                                        <?php if ($urun->urun_eski_fiyat != '0.00') { ?>
                                                                            <div class="list-price">
                                                                                <?= $urun->urun_eski_fiyat ?>
                                                                                ₺
                                                                            </div>
                                                                        <?php } ?>
                                                                    </div>
                                                                </div>
                                                                <a href="<?php echo $urun->urun_seo ?>">
                                                                    <div class="blog-btn">
                                                                        <div class="btn btn-success see-next-btn br-top-0 w-100">
                                                                            Satın Al
                                                                        </div>
                                                                    </div>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <?php } ?>
                                            <?php } else if ($vitrin->contents == 1) { // Ürün için kart tasarımı ?>
                                                <div class="col-xl-2 col-lg-3 col-md-6 col-12 mb-3 ">
                                                    <div class="product-item">
                                                        <div class="pimg-base">
                                                            <a href="<?= base_url($magaza ? $urun->urun_seo : ('kategori/' . $urun_kategori->kategori_seo)) ?>"
                                                               tabindex="0">
                                                                <?php if (!$magaza && $urun->urun_eski_fiyat > $urun->urun_fiyat):
                                                                    $oran = 100 - ceil($urun->urun_fiyat * 100 / $urun->urun_eski_fiyat);
                                                                    ?>
                                                                    <div class="DiscountBox">
                                                                        <span>
                                                                            <b><?= $oran ?>%</b>
                                                                            <small>İndirim</small>
                                                                        </span>
                                                                    </div>
                                                                <?php endif; ?>
                                                                <img class="product-image lazy entered loaded"
                                                                     alt="<?= $urun->urun_ad ?>"
                                                                     src="<?= base_url($magaza ? $urun->urun_resim_min : $urun->urun_resim); ?>"
                                                                     loading="lazy">
                                                                <div class="product-detail s-detail">
                                                                    <div class="slg-box">
                                                                        <span class="product-name d-block threedots color-white"><?= $urun->urun_ad ?></span>
                                                                        <div class="product-info-bottom">
                                                                            <div class="star-rating-container">
                                                                                <ul class="star-rating">
                                                                                    <?php if ($rating == 0) { ?>
                                                                                        <li>
                                                                                            <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                        </li>
                                                                                        <li>
                                                                                            <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                        </li>
                                                                                        <li>
                                                                                            <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                        </li>
                                                                                        <li>
                                                                                            <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                        </li>
                                                                                        <li>
                                                                                            <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                        </li>
                                                                                    <?php } else if ($rating >= 1 && $rating < 2) { ?>
                                                                                        <li>
                                                                                            <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star">
                                                                                        </li>
                                                                                        <li>
                                                                                            <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                        </li>
                                                                                        <li>
                                                                                            <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                        </li>
                                                                                        <li>
                                                                                            <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                        </li>
                                                                                        <li>
                                                                                            <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                        </li>
                                                                                    <?php } else if ($rating >= 2 && $rating < 3) { ?>
                                                                                        <li>
                                                                                            <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star">
                                                                                        </li>
                                                                                        <li>
                                                                                            <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star">
                                                                                        </li>
                                                                                        <li>
                                                                                            <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                        </li>
                                                                                        <li>
                                                                                            <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                        </li>
                                                                                        <li>
                                                                                            <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                        </li>
                                                                                    <?php } else if ($rating >= 3 && $rating < 4) { ?>
                                                                                        <li>
                                                                                            <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star">
                                                                                        </li>
                                                                                        <li>
                                                                                            <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star">
                                                                                        </li>
                                                                                        <li>
                                                                                            <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star">
                                                                                        </li>
                                                                                        <li>
                                                                                            <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                        </li>
                                                                                        <li>
                                                                                            <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                        </li>
                                                                                    <?php } else if ($rating >= 4 && $rating < 5) { ?>
                                                                                        <li>
                                                                                            <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star">
                                                                                        </li>
                                                                                        <li>
                                                                                            <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star">
                                                                                        </li>
                                                                                        <li>
                                                                                            <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star">
                                                                                        </li>
                                                                                        <li>
                                                                                            <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star">
                                                                                        </li>
                                                                                        <li>
                                                                                            <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                        </li>
                                                                                    <?php } else if ($rating == 5 && $rating > 5) { ?>
                                                                                        <li>
                                                                                            <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star">
                                                                                        </li>
                                                                                        <li>
                                                                                            <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star">
                                                                                        </li>
                                                                                        <li>
                                                                                            <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star">
                                                                                        </li>
                                                                                        <li>
                                                                                            <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star">
                                                                                        </li>
                                                                                        <li>
                                                                                            <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star">
                                                                                        </li>
                                                                                    <?php } else { ?>
                                                                                        <li>
                                                                                            <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                        </li>
                                                                                        <li>
                                                                                            <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                        </li>
                                                                                        <li>
                                                                                            <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                        </li>
                                                                                        <li>
                                                                                            <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                        </li>
                                                                                        <li>
                                                                                            <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                        </li>
                                                                                    <?php } ?>
                                                                                    <li>
                                                                                        <span style="margin-left: 5px"> (<?php echo count($yorumlar) ?>)</span>
                                                                                    </li>
                                                                                </ul>
                                                                            </div>
                                                                            <div class="product-price pull-left">
                                                                                <div class="sales-price fw-600 fs-18">
                                                                                    <?= $urun->urun_fiyat ?>
                                                                                    <span class="price-type"> ₺</span>
                                                                                </div>
                                                                                <?php if ($urun->urun_eski_fiyat != '0.00') { ?>
                                                                                    <div class="list-price">
                                                                                        <?= $urun->urun_eski_fiyat ?>
                                                                                        ₺
                                                                                    </div>
                                                                                <?php } ?>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="blog-btn">
                                                                        <div class="btn btn-success see-next-btn br-top-0 w-100">
                                                                            Satın Al
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php } ?>
                                        <?php } ?>
                                    </div>
                                    <?php
                                } else {
                                    ?>
                                    <div class="alert alert-warning alert-custom text-center mx-2 m-0">
                                        İlgili Vitrinde İçerik Bulunamadı.
                                    </div>
                                    <?php
                                }
                                ?>
                            </div>
                        </div>
                        <?php
                    }
                }
                ?>
            </div>
        </div>
    </div>
</div>

<?php if (count($ust_reklam) > 0) { ?>
    <div class="bg-white p-sec-20">
        <div class="container mls-b">
            <div class="row">
                <?php foreach (!empty($ust_reklam) ? $ust_reklam : [] as $key => $value) { ?>
                    <div class="col-xl-2 col-lg-2 col-sm-6 col-sm-6 mb-2">
                        <a href="<?= $value->link ?>">
                            <div class="card-chk">
                                <div class="wrapper-chk">
                                    <img src="<?= base_url($value->image); ?>" class="cover-image-chk" loading="lazy" alt="Reklam <?php echo $value->order_no ?>"/>
                                </div>
                                <img src="<?= base_url($value->image_three); ?>" class="title-chk" loading="lazy" alt="Reklam Logo <?php echo $value->order_no ?>"/>
                                <img src="<?= base_url($value->image_two); ?>" class="character-chk" loading="lazy" alt="Reklam 2. Resim <?php echo $value->order_no ?>"/>
                            </div>
                        </a>
                    </div>
                <?php } ?>
            </div>
        </div>
    </div>
<?php } ?>

<div class="bg-white p-sec-20">
    <div class="container">
        <div class="col-12 p-0">
            <div class="swiper-tab sw-bg">
                <div class="swiper tab-co-slider">
                    <div class="swiper-wrapper">
                        <?php
                        if ($vitrin_2) {
                            foreach ($vitrin_2 as $keys => $vitrin) {
                                $tab_name = seo($vitrin->name);
                                $exploded = explode(' ', $vitrin->name);
                                ?>
                                <div class="swiper-slide">
                                    <button class="btn taby-btn2 light-color-indexy <?= $keys == 0 ? 'active' : '' ?>"
                                            data-tb2-id="#tabt<?php echo $vitrin->id ?>">
                                            <img src="<?= base_url($vitrin->icon) ?>" width="32px" height="32px"
                                                alt="icon" loading="lazy">
                                        <?php foreach ($exploded as $key => $txt):
                                            echo $key == 0 ? "<b>$txt</b>" : " $txt";
                                        endforeach; ?>
                                    </button>
                                </div>
                                <?php
                            }
                        }
                        ?>
                    </div>
                    <div class="swiper-button-next"></div>
                    <div class="swiper-button-prev"></div>
                </div>
            </div>
        </div>
        <div class="col-12 p-0">
            <div class="taby-content">
                <?php
                if ($vitrin_2) {
                    foreach ($vitrin_2 as $vkey => $vitrin) {
                        $tab_name = seo($vitrin->name);
                        $exploded = explode(' ', $vitrin->name);
                        ?>
                        <div class="tab-secp <?= $vkey == 0 ? 'active' : '' ?>" id="tabt<?= $vitrin->id ?>">
                            <div class="p-sec-20">
                                <?php
                                $vitrin_urunler = $this->db->select('u.*,m.*')
                                    ->join('urunler u', 'u.urun_id=vt.urun_id')
                                    ->join('magaza m', 'm.magaza_id=u.magaza_id', 'left')
                                    ->where('u.urun_durum', 1)
                                    ->where('vt.vitrin_id', $vitrin->id)
                                    ->order_by('vt.sira', 'ASC')
                                    ->get('vitrin_urunler vt')->result();
                                if ($vitrin_urunler) {
                                    ?>
                                    <div class="row mx-0">
                                        <?php foreach ($vitrin_urunler as $urun) {
                                            $json = json_decode($urun->kategori_json);
                                            $urun_kategori = $this->yonetim_model->kategoriget(array("kategori_id" => $json[0]));
                                            $magaza = false;
                                            if ($urun->magaza_id != null) {
                                                $magaza = magaza($urun->kullanici_id);
                                            }

                                            $yorumlar_2 = $this->siparis_model->yorumlar(['urun_id' => $urun->urun_id, 'yorum_durum' => 1]);

                                            if (!empty($yorumlar_2)) {
                                                $yorumlar_yildiz_toplam_2 = $this->siparis_model->yorum_yildiz_toplam($urun->urun_id);
                                                $rating_2 = $yorumlar_yildiz_toplam_2->yorum_puan / count($yorumlar_2);
                                            }

                                            $rating_2 = empty($rating_2) ? 0 : $rating_2;
                                            ?>
                                            <?php if ($vitrin->contents == 2) { // ilan ürünler kart tasarımı ?>
                                                <?php if ($urun->urun_bitis_tarihi > date('Y-m-d H:i:s')) { ?>
                                                <div class="col-xl-2 col-lg-3 col-md-6 col-12 mb-3 ">
                                                    <div class="product-item pioff-product-item">
                                                        <div class="pimg-base pioff-pimg-base">
                                                            <?php if (!$magaza && $urun->urun_eski_fiyat > $urun->urun_fiyat):
                                                                $oran = 100 - ceil($urun->urun_fiyat * 100 / $urun->urun_eski_fiyat);
                                                                ?>
                                                                <div class="DiscountBox">
                                                                    <span>
                                                                        <b><?= $oran ?>%</b>
                                                                        <small>İndirim</small>
                                                                    </span>
                                                                </div>
                                                            <?php endif; ?>
                                                            <a href="<?php echo base_url('kategori/' . $urun_kategori->kategori_seo) ?>">
                                                                <div class="inline-platform-list">
                                                                    <div class="img-platform-box mr-3">
                                                                        <img width="24" height="24"
                                                                             src="<?= $urun_kategori->kategori_resim; ?>"
                                                                             alt="<?= $urun_kategori->kategori_ad; ?>"
                                                                             loading="lazy" aria-label="<?php echo $urun_kategori->kategori_ad . ' Kategori' ?>">
                                                                    </div>
                                                                    <div class="img-pcn">
                                                                        <span><?= $urun_kategori->kategori_ad; ?></span>
                                                                    </div>
                                                                </div>
                                                            </a>
                                                            <img class="product-image pioff lazy entered loaded"
                                                                 alt="<?= $urun->urun_ad ?>"
                                                                 src="<?= base_url($magaza ? $urun->urun_resim_min : $urun->urun_resim); ?>"
                                                                 loading="lazy">
                                                            <div class="product-detail s-detail">
                                                                <a href="<?php echo base_url($urun->urun_seo) ?>">
                                                                    <span class="product-name d-block threedots color-white"><?= $urun->urun_ad ?></span>
                                                                </a>
                                                                <div class="product-info-bottom">
                                                                    <div class="star-rating-container">
                                                                        <ul class="star-rating">
                                                                            <?php if ($rating_2 == 0) { ?>
                                                                                <li>
                                                                                    <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                </li>
                                                                                <li>
                                                                                    <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                </li>
                                                                                <li>
                                                                                    <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                </li>
                                                                                <li>
                                                                                    <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                </li>
                                                                                <li>
                                                                                    <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                </li>
                                                                            <?php } else if ($rating_2 >= 1 && $rating_2 < 2) { ?>
                                                                                <li>
                                                                                    <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star">
                                                                                </li>
                                                                                <li>
                                                                                    <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                </li>
                                                                                <li>
                                                                                    <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                </li>
                                                                                <li>
                                                                                    <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                </li>
                                                                                <li>
                                                                                    <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                </li>
                                                                            <?php } else if ($rating_2 >= 2 && $rating_2 < 3) { ?>
                                                                                <li>
                                                                                    <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star">
                                                                                </li>
                                                                                <li>
                                                                                    <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star">
                                                                                </li>
                                                                                <li>
                                                                                    <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                </li>
                                                                                <li>
                                                                                    <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                </li>
                                                                                <li>
                                                                                    <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                </li>
                                                                            <?php } else if ($rating_2 >= 3 && $rating_2 < 4) { ?>
                                                                                <li>
                                                                                    <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star">
                                                                                </li>
                                                                                <li>
                                                                                    <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star">
                                                                                </li>
                                                                                <li>
                                                                                    <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star">
                                                                                </li>
                                                                                <li>
                                                                                    <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                </li>
                                                                                <li>
                                                                                    <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                </li>
                                                                            <?php } else if ($rating_2 >= 4 && $rating_2 < 5) { ?>
                                                                                <li>
                                                                                    <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star">
                                                                                </li>
                                                                                <li>
                                                                                    <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star">
                                                                                </li>
                                                                                <li>
                                                                                    <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star">
                                                                                </li>
                                                                                <li>
                                                                                    <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star">
                                                                                </li>
                                                                                <li>
                                                                                    <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                </li>
                                                                            <?php } else if ($rating_2 == 5 && $rating_2 > 5) { ?>
                                                                                <li>
                                                                                    <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star">
                                                                                </li>
                                                                                <li>
                                                                                    <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star">
                                                                                </li>
                                                                                <li>
                                                                                    <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star">
                                                                                </li>
                                                                                <li>
                                                                                    <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star">
                                                                                </li>
                                                                                <li>
                                                                                    <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star">
                                                                                </li>
                                                                            <?php } else { ?>
                                                                                <li>
                                                                                    <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                </li>
                                                                                <li>
                                                                                    <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                </li>
                                                                                <li>
                                                                                    <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                </li>
                                                                                <li>
                                                                                    <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                </li>
                                                                                <li>
                                                                                    <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                </li>
                                                                            <?php } ?>
                                                                            <li>
                                                                                <span style="margin-left: 5px"> (<?php echo count($yorumlar_2) ?>)</span>
                                                                            </li>
                                                                        </ul>
                                                                    </div>
                                                                    <div class="product-price">
                                                                        <div class="sales-price fw-600 fs-18">
                                                                            <?= $urun->urun_fiyat ?>
                                                                            <span class="price-type"> ₺</span>
                                                                        </div>
                                                                        <?php if ($urun->urun_eski_fiyat != '0.00') { ?>
                                                                            <div class="list-price">
                                                                                <?= $urun->urun_eski_fiyat ?>
                                                                                ₺
                                                                            </div>
                                                                        <?php } ?>
                                                                    </div>
                                                                </div>
                                                                <a href="<?php echo $urun->urun_seo ?>">
                                                                    <div class="blog-btn">
                                                                        <div class="btn btn-success see-next-btn br-top-0 w-100">
                                                                            Satın Al
                                                                        </div>
                                                                    </div>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                               <?php } ?>
                                            <?php } else if ($vitrin->contents == 1) { ?>
                                                <div class="col-xl-2 col-lg-3 col-md-6 col-12 mb-3 ">
                                                    <div class="product-item">
                                                        <div class="pimg-base">
                                                            <a href="<?= base_url($magaza ? $urun->urun_seo : ('kategori/' . $urun_kategori->kategori_seo)) ?>"
                                                               tabindex="0">
                                                                <?php if (!$magaza && $urun->urun_eski_fiyat > $urun->urun_fiyat):
                                                                    $oran = 100 - ceil($urun->urun_fiyat * 100 / $urun->urun_eski_fiyat);
                                                                    ?>
                                                                    <div class="DiscountBox">
                                                                            <span>
                                                                                <b><?= $oran ?>%</b>
                                                                                <small>İndirim</small>
                                                                            </span>
                                                                    </div>
                                                                <?php endif; ?>
                                                                <img class="product-image lazy entered loaded"
                                                                     alt="<?= $urun->urun_ad ?>"
                                                                     data-src="<?= base_url($magaza ? $urun->urun_resim_min : $urun->urun_resim); ?>"
                                                                     src="<?= base_url($magaza ? $urun->urun_resim_min : $urun->urun_resim); ?>"
                                                                     loading="lazy">
                                                                <div class="product-detail s-detail">
                                                                    <div class="slg-box">
                                                                        <span class="product-name d-block threedots color-white"><?= $urun->urun_ad ?></span>
                                                                        <div class="product-info-bottom">
                                                                            <div class="star-rating-container ">
                                                                                <ul class="star-rating">
                                                                                    <?php if ($rating_2 == 0) { ?>
                                                                                        <li>
                                                                                            <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                        </li>
                                                                                        <li>
                                                                                            <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                        </li>
                                                                                        <li>
                                                                                            <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                        </li>
                                                                                        <li>
                                                                                            <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                        </li>
                                                                                        <li>
                                                                                            <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                        </li>
                                                                                    <?php } else if ($rating_2 >= 1 && $rating_2 < 2) { ?>
                                                                                        <li>
                                                                                            <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star">
                                                                                        </li>
                                                                                        <li>
                                                                                            <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                        </li>
                                                                                        <li>
                                                                                            <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                        </li>
                                                                                        <li>
                                                                                            <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                        </li>
                                                                                        <li>
                                                                                            <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                        </li>
                                                                                    <?php } else if ($rating_2 >= 2 && $rating_2 < 3) { ?>
                                                                                        <li>
                                                                                            <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star">
                                                                                        </li>
                                                                                        <li>
                                                                                            <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star">
                                                                                        </li>
                                                                                        <li>
                                                                                            <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                        </li>
                                                                                        <li>
                                                                                            <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                        </li>
                                                                                        <li>
                                                                                            <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                        </li>
                                                                                    <?php } else if ($rating_2 >= 3 && $rating_2 < 4) { ?>
                                                                                        <li>
                                                                                            <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star">
                                                                                        </li>
                                                                                        <li>
                                                                                            <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star">
                                                                                        </li>
                                                                                        <li>
                                                                                            <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star">
                                                                                        </li>
                                                                                        <li>
                                                                                            <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                        </li>
                                                                                        <li>
                                                                                            <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                        </li>
                                                                                    <?php } else if ($rating_2 >= 4 && $rating_2 < 5) { ?>
                                                                                        <li>
                                                                                            <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star">
                                                                                        </li>
                                                                                        <li>
                                                                                            <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star">
                                                                                        </li>
                                                                                        <li>
                                                                                            <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star">
                                                                                        </li>
                                                                                        <li>
                                                                                            <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star">
                                                                                        </li>
                                                                                        <li>
                                                                                            <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                        </li>
                                                                                    <?php } else if ($rating_2 == 5 && $rating_2 > 5) { ?>
                                                                                        <li>
                                                                                            <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star">
                                                                                        </li>
                                                                                        <li>
                                                                                            <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star">
                                                                                        </li>
                                                                                        <li>
                                                                                            <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star">
                                                                                        </li>
                                                                                        <li>
                                                                                            <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star">
                                                                                        </li>
                                                                                        <li>
                                                                                            <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star">
                                                                                        </li>
                                                                                    <?php } else { ?>
                                                                                        <li>
                                                                                            <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                        </li>
                                                                                        <li>
                                                                                            <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                        </li>
                                                                                        <li>
                                                                                            <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                        </li>
                                                                                        <li>
                                                                                            <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                        </li>
                                                                                        <li>
                                                                                            <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                                        </li>
                                                                                    <?php } ?>
                                                                                    <li>
                                                                                        <span style="margin-left: 5px"> (<?php echo count($yorumlar_2) ?>)</span>
                                                                                    </li>
                                                                                </ul>
                                                                            </div>
                                                                            <div class="product-price pull-left">
                                                                                <div class="sales-price fw-600 fs-18">
                                                                                    <?= $urun->urun_fiyat ?>
                                                                                    <span class="price-type"> ₺</span>
                                                                                </div>
                                                                                <?php if ($urun->urun_eski_fiyat != '0.00') { ?>
                                                                                    <div class="list-price">
                                                                                        <?= $urun->urun_eski_fiyat ?>
                                                                                        ₺
                                                                                    </div>
                                                                                <?php } ?>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="blog-btn">
                                                                        <div class="btn btn-success see-next-btn br-top-0 w-100">
                                                                            Satın Al
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php } ?>
                                        <?php } ?>
                                    </div>
                                    <?php
                                } else {
                                    ?>
                                    <div class="alert alert-warning alert-custom text-center mx-2 m-0">
                                        İlgili Vitrinde İçerik Bulunamadı.
                                    </div>
                                    <?php
                                }
                                ?>
                            </div>
                        </div>
                        <?php
                    }
                }
                ?>
            </div>
        </div>
    </div>
</div>


<?php if ($ayarlar->kategori_json != '[]' && 1 == 0) {
    $kategoriler = json_decode($ayarlar->kategori_json);
    foreach ($kategoriler as $kat) {
        $kategori = detaykategori($kat);
        $kat_urunler = kat_urunler($kat);
        if ($kategori) {
            ?>
            <div class="pb-lg-3 pt-5 pb-6 bg-white">
                <div class="container">
                    <div class="row align-items-center justify-content-center">

                        <div class="col-sm-12">
                            <div class="row d-lg-flex align-items-center mb-4">
                                <div class="col">
                                    <h2 class="mb-0"><?= $kategori->kategori_ad ?></h2>
                                </div>
                                <div class="col-auto"><!--
                            <a  href="<?= base_url('kategori/' . $kategori->kategori_seo) ?>"
                               class="btn btn-outline-primary btn-sm">Tümünü Göster</a>-->
                                </div>
                            </div>
                            <div class="row">
                                <?php if ($kat_urunler) {
                                    $s = 0;
                                    foreach ($kat_urunler as $urun) { ?>
                                        <?php if ($urun->urun_bitis_tarihi > date('Y-m-d H:i:s')) { ?>

                                        <div class="col-lg-2 col-md-4 col-12 <?= $kategori->kategori_seo; ?>" <?php if ($s >= 4) {
                                            echo 'style="display:none;"';
                                        } ?>>
                                            <div class="card  mb-4 card-hover" <?php if ($urun->kenar != Null) {
                                                echo 'style="border: 3px solid ' . $urun->kenar . ';box-shadow: 0 0 20px ' . $urun->kenar . ', 0 0 10px ' . $urun->kenar . ';"';
                                            } ?>>
                                                <a href="<?= base_url($urun->urun_seo) ?>" class="card-img-top"
                                                   title="<?php echo $urun->urun_ad ?>"
                                                   aria-label="<?php echo $urun->urun_ad ?>">
                                                    <img src="<?= base_url($urun->urun_resim) ?>" alt="img"
                                                         class="rounded-top card-img-top card-cover" loading="lazy">
                                                    <?php if (!anasayfa_reklam_kontrol($urun->urun_id)) { ?>
                                                        <span class="fas fa-bolt onecikan" data-toggle="tooltip"
                                                              data-placement="top"
                                                              data-original-title="Öne Çıkan"></span>
                                                    <?php } ?>
                                                </a>
                                                <div class="card-body card-body-p">
                                                    <h4 class="mb-2 text-truncate-line-2 card-min-max">
                                                        <a href="<?= base_url($urun->urun_seo) ?>"
                                                           title="<?php echo $urun->urun_ad ?>"
                                                           aria-label="<?php echo $urun->urun_ad ?>"
                                                           class="text-inherit"><?= $urun->urun_ad ?></a>
                                                    </h4>
                                                </div>
                                                <div class="card-footer">
                                                    <div class="row align-items-center no-gutters">
                                                        <?php if ($urun->magaza_id != "3") { ?>
                                                            <div class="col-auto">
                                                                <img src="<?= base_url($urun->magaza_resim) ?>"
                                                                     class="rounded-circle avatar-xs"
                                                                     alt="<?php echo $urun->magaza_ad . ' Mağaza' ?>">
                                                            </div>
                                                            <div class="col ml-2">
                                                                <a
                                                                        href="<?= base_url('m/' . $urun->magaza_seo) ?>"
                                                                        title="<?php echo $urun->magaza_ad ?>"
                                                                        aria-label="<?php echo $urun->magaza_ad ?>">
                                                                    <span><?= $urun->magaza_ad ?></span>
                                                                </a>
                                                            </div>
                                                        <?php } ?>
                                                        <div class="col-auto">
                                                            <span style="font-size: 20px;font-weight: 900;color2: #0a0a0a;"><?= $urun->urun_fiyat ?> <small
                                                                        style="font-size: 13px;color2: #0a0a0a;">TL</small></span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php $s++;
                                        }
                                    }
                                } ?>
                                <div class="col-12 text-center">
                                    <a href="<?= base_url('kategori/' . $kategori->kategori_seo) ?>"
                                       title="Kategori"
                                       class="btn btn-primary">Daha Fazla Göster</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php }
    }
} ?>

<?php if (count($alt_reklam) > 0) { ?>
    <div class="bg-white p-sec-20">
        <div class="container">
            <div class="row">
                <?php foreach (!empty($alt_reklam) ? $alt_reklam : [] as $key => $value) { ?>
                    <div class="col-xl-2 col-lg-2 col-sm-6 col-sm-6 mb-2">
                        <a href="<?= $value->link ?>">
                            <div class="card-chk">
                                <div class="wrapper-chk">
                                    <img src="<?= base_url($value->image); ?>" class="cover-image-chk" loading="lazy" alt="Alt Reklam Resim <?php echo $value->order_no ?>"/>
                                </div>
                                <img src="<?= base_url($value->image_three); ?>" class="title-chk " loading="lazy" alt="Alt Reklam Logo <?php echo $value->order_no ?>"/>
                                <img src="<?= base_url($value->image_two); ?>" class="character-chk " loading="lazy" alt="Alt Reklam 2. Resim <?php echo $value->order_no ?>"/>
                            </div>
                        </a>
                    </div>
                <?php } ?>
            </div>
        </div>
    </div>
<?php } ?>

<div class="p-sec-20 bg-white">
    <div class="container">
        <hr class="mb-10">
        <div class="row d-lg-flex align-items-center mb-4">
            <div class="col">
                <h2 class="mb-0 l-color">Blog Yazıları</h2>
            </div>
        </div>
        <div class="blog-slider owl-carousel">
            <?php foreach ($bloglar as $key) { ?>
                <div class="card  mb-6 shadow-lg dark-radius">
                    <a href="<?= base_url("blog/$key->blog_seo") ?>" class="card-img-top"
                       title="Blog <?php echo $key->blog_ad ?>">
                        <img src="<?= base_url($key->blog_resim) ?>" class="card-img-top img-card rounded-top-md"
                             alt="<?= $key->blog_ad ?>" loading="lazy">
                        <div class="card-body custom-card-body p-2">
                                <div class="text-inherit c-custom">
                                    <?= strip_tags(kisalt($key->blog_ad, 25)); ?>
                                </div>
                            <p class="font-size-11 mb-0 c-custom"><?= zamanCevir($key->blog_zaman) ?></p>
                            <p class="c-custom"><?= strip_tags(kisalt($key->blog_detay, 100)); ?></p>
                            <div class="blog-btn">
                                <div class="btn btn-success see-next-btn">Devamını Gör</div>
                            </div>
                        </div>
                    </a>
                </div>
            <?php } ?>
        </div>
    </div>
</div>

