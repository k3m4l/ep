
<div class="bg-primary bc-custom"  style="background:linear-gradient(0deg, rgb(0 0 0 / 40%), rgb(0 0 0 / 40%)),background-size:cover; background-position: center; background-image:url(<?php echo base_url($ayarlar->faq_bg) ?>)">
    
            <div class="bc-head-tt-area">
                <h1 class="bc-head-tt">Sıkca Sorulan Sorular</h1>
            </div>
  
</div>
<section class="py-6">
    <div class="container">
        <div class="row">
            <div class="offset-md-2 col-md-8 col-12">
                <div class="accordion accordion-flush" id="accordionExample3">
                    <?php $sss = sss();
                    if ($sss) { ?>
                        <?php foreach ($sss as $key) { ?>
                            <div class="acc-custom-border p-3 rounded-3 mb-2" id="heading<?=$key->sss_id?>">
                                <h3 class="mb-0 fs-4">
                                    <a href="#" class="d-flex align-items-center text-inherit text-decoration-none cls"
                                       data-bs-toggle="collapse" data-bs-target="#collapse<?=$key->sss_id?>" aria-expanded="true"
                                       aria-controls="collapse<?=$key->sss_id?>">
                                <span class="me-auto">
                                  <?=$key->sss_baslik?>
                                </span>
                                <span class="collapse-toggle ms-4">
                                    <i class="fe fe-chevron-down text-muted"></i>
                                </span>
                                    </a>
                                </h3>
                                <div id="collapse<?=$key->sss_id?>" class="collapse" aria-labelledby="heading<?=$key->sss_id?>"
                                     data-bs-parent="#accordionExample3" style="">
                                    <div class="pt-2 acc-dsc">
                                        <?=$key->sss_aciklama?>
                                    </div>
                                </div>
                            </div>
                        <?php }
                    } ?>
                </div>
            </div>
        </div>
    </div>
</section>