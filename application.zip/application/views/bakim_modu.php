<!DOCTYPE html>
<html lang="tr">

<head>
    <meta charset="UTF-8">
    <meta name="robots" content="noindex, nofollow" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bakım Modundayız</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg">
    <style>
        .bakim-img {
            width: 100%;
            height: 500px;
            object-fit: contain;
        }

        .bg {
            background: #151a27;
            margin-top: 30px;
        }

        .page-desc p {
            color: white;
        }

        .page-desc strong {
            color: white;
        }

        .see-next-btn {
            background: #5623c5 !important;
            border: 0;
            width: 100%;
            font-weight: 700;
            display: inline-block;
            font-weight: 500;
            color: #ffffff;
            text-align: center;
            vertical-align: middle;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
            background-color: transparent;
            border: 1px solid transparent;
            padding: .5rem 1rem;
            font-size: .875rem;
            line-height: 1.6;
            border-radius: .25rem;
            transition: color .15s ease-in-out, background-color .15s ease-in-out, border-color .15s ease-in-out, box-shadow .15s ease-in-out;
        }
    </style>
    <div class="container bg">
        <div class="row justify-content-center align-items-center">
            <div class="col-8">
                <div class="img-warper">
                    <img class="bakim-img" src="assets/front/images/mainentarance-mode-img.png" alt="">
                </div>
                <div class="page-desc">
                    <p>Şu anda web sitemizi geliştirme ve iyileştirme çalışmaları yapmaktayız. Bu nedenle geçici bir
                        süreliğine bakımdayız. Size daha iyi hizmet verebilmek ve kullanıcı deneyimimizi artırmak için
                        çalışıyoruz.</p>

                    <p> Sitemiz yeniden hazır olduğunda sizleri tekrar aramızda görmekten mutluluk duyacağız.
                        Anlayışınız için teşekkür ederiz.</p>

                    <p> Saygılarımızla,</p>

                    <Strong>Herşeyoyun Ekibi</Strong>


                   <a href="<?php echo base_url() ?>"><div class="btn btn-success see-next-btn mt-5">Anasayfaya dön</div></a>
                </div>
            </div>
        </div>
    </div>







    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>