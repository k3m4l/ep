<?php date_default_timezone_set('Europe/Istanbul'); ?>
<?php $link = $_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI']; ?>

<div class="py-4 py-lg-8 pb-14">
    <div class="container">
        <div class="row">
            <div class="col-xl-8 col-lg-8 col-md-12 col-sm-12">
                <div class="card bg-shadow" style="overflow:hidden">
                    <div class="card-body p-0">
                        <div class="image w-100">
                            <img class="blog-img-big" src="<?=base_url($where->blog_resim)?>" alt="<?=$where->blog_ad?>" width="100%">
                        </div>
                        <header >
                            <div class="content p-3">
                                <h1 class="fw-bold"><?=$where->blog_ad?></h1>
                                <a href="<?= base_url("blog-kategori/$where->kategori_seo") ?>" class="fs-5 mb-2 fw-semi-bold d-block vs-color"><?= $where->kategori_ad ?></a>
                                <div class="d-flex flex-wrap align-items-center" style="gap:15px">
                                    <span class="text-secondary ts-custom"><img src="<?= base_url($ayarlar->site_favicon) ?>" height="24">&nbsp;<?= $ayarlar->site_baslik; ?></span>
                                    <span class="text-secondary ts-custom"><i class="fa fa-clock"></i>&nbsp;<?=zamanCevir($where->blog_zaman);?></span>
                                </div>
                            </div>
                        </header>
                        <div class="descripton ds-border-top p-3">
                            <?=$where->blog_detay?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-4 col-lg-4 col-md-12 col-12 ">
                <div class="row">
                    <div class="col-12 ">
                        <div class="mb-3">
                            <h2>Son Blog Yazıları</h2>
                        </div>
                    </div>
                    <?php foreach (limitblogcek() as $key){ ?>
                        <div class="col-12">
                            <div class="card mb-4 shadow-lg">
                                <a href="<?= base_url("blog/$key->blog_seo") ?>" class="card-img-top">
                                    <img src="<?= base_url($key->blog_resim) ?>"
                                        class="card-img-top img-card rounded-top-md"
                                        alt="<?= $key->blog_ad ?>"></a>
                                <div class="card-body">
                                    <a href="<?= base_url("blog-kategori/$key->kategori_seo") ?>" class="fs-5  fw-semi-bold d-block text-primary"><?= $key->kategori_ad ?></a>
                                    <h3 class="m-10b">
                                        <a href="<?= base_url("blog/$key->blog_seo") ?>"
                                        class="text-inherit"><?= $key->blog_ad ?></a>
                                    </h3>
                                    <p><?= strip_tags(kisalt($key->blog_detay, 200)); ?></p>
                                    <!-- Row  -->
                                    <div class="row align-items-center ">
                                        <div class="col lh-1">
                                            <p class="fs-6 mb-0"><?= zamanCevir($key->blog_zaman) ?></p>
                                            <a href="<?= base_url("blog/$key->blog_seo") ?>">
                                            <div class="blog-btn mb-2 mt-2 ">
                                                <div class="btn btn-success w-100 see-next-btn">Davamını Gör</div>
                                            </div>
                                        </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php } ?>
                </div>
            </div>   
        </div>  
    </div>
</div> 