<?php date_default_timezone_set('Europe/Istanbul'); ?>

<div class="p-lg-5 py-5">
    <div class="container">
        <div class="row">
            <div class="col-xl-12 col-lg-12 col-md-12 col-12 ">
                <!-- Flush Nav -->
                <div class="flush-nav mb-2">
                    <h2><?=$where->kategori_ad?></h2>
                    <span><?=$where->kategori_ad?> Blog Yazıları</span>
                </div>

                <div class="flush-nav">
                    <nav class="nav">
                        <a class="nav-link ps-0" href="<?= base_url('blog'); ?>">Tümü</a>
                        <?php foreach (blog_kategoriler_yonetim() as $item){ ?>
                            <a class="nav-link <?php if ($where->id === $item->id){ echo 'active'; } ?>" href="<?= base_url("blog-kategori/$item->kategori_seo") ?>"><?=$item->kategori_ad?></a>
                        <?php } ?>
                    </nav>
                </div>
            </div>
            <?php $ilk = 0;
            foreach ($bloglar as $key) {
                $ilk++; ?>
                <?php if ($ilk === 1) { ?>
                    <div class="col-xl-4 col-lg-4 col-md-6 col-12">
                        
                        <div class="card mb-4 shadow-lg">
                            <div class="row g-0">
                                <!-- Image -->
                                <div class="col-12">
                                    <a href="<?= base_url("blog/$key->blog_seo") ?>" class=" bg-cover  img-left-rounded"
                                    style="background-image: url(<?= base_url($key->blog_resim) ?>);">
                                        <img src="<?= base_url($key->blog_resim) ?>" class="img-fluid  blog-custom-img" alt="<?= $key->blog_ad ?>">
                                    </a>
                                </div>

                                <div class="col-12">
                                    
                                    <div class="card-body cc-h300">
                                        <a href="<?= base_url("blog-kategori/$key->kategori_seo") ?>" class="fs-5  fw-semi-bold d-block text-primary"><?= $key->kategori_ad ?></a>
                                        <h1 class="mb-2 mt-2">
                                            <a href="<?= base_url("blog/$key->blog_seo") ?>" class=" fs-18 text-inherit">
                                                <?= $key->blog_ad ?>
                                            </a>
                                        </h1>
                                        <p><?= strip_tags(kisalt($key->blog_detay, 200)); ?></p>
                                        <!-- Media content -->
                                        <div class="row align-items-center">
                                            <div class="col lh-1 ">
                                                <p class="fs-6 mb-0"><?= zamanCevir($key->blog_zaman) ?></p>
                                                <a href="<?= base_url("blog/$key->blog_seo") ?>">
                                                    <div class="blog-btn mb-2 mt-2 ">
                                                        <div class="btn btn-success w-100 see-next-btn">Davamını Gör</div>
                                                    </div>
                                               </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php } else {
                    break;
                } ?>

            <?php } ?>
            <?php $i = 0;
            foreach ($bloglar as $key) {
                $i++; ?>
                <?php if ($i === 1) { continue; } ?>
                <div class="col-xl-4 col-lg-4 col-md-6 col-12">
                    
                    <div class="card mb-4 shadow-lg">
                        <a href="<?= base_url("blog/$key->blog_seo") ?>" class="card-img-top">
                            <img src="<?= base_url($key->blog_resim) ?>"
                                 class="card-img-top img-card rounded-top-md"
                                 alt="<?= $key->blog_ad ?>"></a>
                        
                        <div class="card-body cc-h300">
                            <a href="<?= base_url("blog-kategori/$key->kategori_seo") ?>" class="fs-5  fw-semi-bold d-block text-primary"><?= $key->kategori_ad ?></a>
                            <h3 class="mb-2 mt-2">
                                <a href="<?= base_url("blog/$key->blog_seo") ?>"
                                   class="text-inherit"><?= $key->blog_ad ?></a>
                            </h3>
                            <p><?= strip_tags(kisalt($key->blog_detay, 200)); ?></p>
                            <!-- Row  -->
                            <div class="row align-items-center ">
                                <div class="col lh-1">
                                    <p class="fs-6 mb-0"><?= zamanCevir($key->blog_zaman) ?></p>
                                    <a href="<?= base_url("blog/$key->blog_seo") ?>">
                                        <div class="blog-btn mb-2 mt-2 ">
                                            <div class="btn btn-success w-100 see-next-btn">Davamını Gör</div>
                                        </div>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            <?php } ?>
            <div class="col-md-12">
                <!-- Pagination -->
                <div class="pagination-container margin-bottom-40">
                    <nav class="pagination">
                        <?= $links ?>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>