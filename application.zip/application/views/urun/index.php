<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/photoswipe/4.1.0/photoswipe.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/photoswipe/4.1.0/default-skin/default-skin.css">

<link href='https://fonts.googleapis.com/css?family=Bitter:400,700,400italic' rel='stylesheet' type='text/css'>
<style>
    .pswp__caption__center {
        text-align: center;
    }

    figure {
        display: inline-block;
        width: 33.333%;
        float: left;
    }

    .spacer {
        height: 5em;
    }

    .product-card-description span {
        color: #fff;
    }

    p,
    h1,
    a {
        color: white;
    }

    span {
        color: white;
    }
</style>

<?php if (!isset($_SESSION["theme"])) {
    $_SESSION["theme"] = $ayarlar->renk_varsayilan;
}
if (@$_GET["theme"] == "1" || @$_GET["theme"] == "2") {

    $_SESSION["theme"] = $_GET["theme"];
    header("Location:" . current_url());
    exit;
}
if ($_SESSION["theme"] == "1") : ?>
    <style>
        .swal2-label {
            color: black;
        }
    </style>

<?php endif; ?>
<div class="breadcrumb">
    <div class="container">
        <ul>
            <li>
                <a title="Anasayfa" href="<?= base_url(); ?>">Anasayfa</a>
            </li>
            <li>
                <a title="Kategoriler" href="<?= base_url('kategoriler') ?>">Kategoriler</a>
            </li>
            <?php if (isset($ust_kategori)): ?>
                <li>
                    <a title="<?= $ust_kategori->kategori_ad ?>" href="<?= base_url('kategoriler/' . $ust_kategori->kategori_seo) ?>"><?= $ust_kategori->kategori_ad ?></a>
                </li>
            <?php endif; ?>
            <li>
                <a title="<?= $kategori->kategori_ad ?>" href="<?= base_url('kategori/' . $kategori->kategori_seo) ?>"><?= $kategori->kategori_ad ?></a>
            </li>
            <li>
                <a title="<?= $urun->urun_ad; ?>" href><?= $urun->urun_ad; ?></a>
            </li>
        </ul>
    </div>
</div>
<div class="p-lg-5 py-5">
    <div class="container">
        <div class="row mx-0 product_row">
            <div class="col-xl-9 col-md-9 col-12 px-0">
                <div class="row">
                    <div class="col-xl-7 col-md-6 col-12 pr-md-0">
                        <div class="swiper gallery-swiper">
                            <div class="swiper-wrapper">
                                <div class="swiper-slide" style="border-radius:10px;overflow:hidden;">
                                    <a href="<?= base_url($urun->urun_resim) ?>">
                                        <img src="<?= base_url($urun->urun_resim) ?>" width="620px" height="450px" title="<?php echo $urun->urun_ad ?>">
                                    </a>
                                </div>
                                <?php if ($urun->urun_galeri != '[]' && $urun->urun_galeri):
                                    $galeri = json_decode($urun->urun_galeri); ?>
                                    <?php foreach ($galeri as $key => $val) : ?>
                                    <div class="swiper-slide" style="border-radius:10px;overflow:hidden;">
                                        <a href="<?= base_url('uploads/img/' . $val) ?>">
                                            <img src="<?= base_url('uploads/img/' . $val) ?>"
                                                 width="620px" height="450px" title="<?php echo $urun->urun_ad ?>">
                                        </a>
                                    </div>
                                <?php endforeach; ?>
                                <?php endif; ?>
                            </div>
                            <div class="swiper-button-next"></div>
                            <div class="swiper-button-prev"></div>
                        </div>
                    </div>
                    <div class="col-xl-5 col-md-6 col-12">
                        <div class="sproduct-detail">
                            <div class="sproduct-detail__top">
                                <div class="row justify-content-between align-items-center">
                                    <div class="col-auto">
                                        <div class="sproduct-no">#<span class="ilanno"><?= $urun->urun_id ?></span>
                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <div class="sproduct-stock">
                                            <span> <?= $urun->urun_stok ?></span>
                                            Stok
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="sproduct-detail__long">
                                <font size="5">
                                    <b><?= $urun->urun_ad ?></b>
                                </font>
                                <?php
                                    if (!empty($urun->urun_short_aciklama)) {
                                        echo $urun->urun_short_aciklama;
                                    } else {
                                        echo $urun->urun_aciklama;
                                    }
                                ?>
                            </div>
                            <div class="sproduct__ranks" style="position:absolute; bottom:0; margin-bottom:13px;">
                                <div class="row justify-content-md-end justify-content-center gutters-small">
                                    <div class="col-auto">
                                        <?php if ($magaza->magaza_dogrulama == 1): ?>
                                            <div class="trust-seller" style="cursor:help;">
                                                <span><img height="24px" width="24px"
                                                           src="<?= base_url('assets/images/guarantee.svg') ?>" alt=""></span>
                                                <span>Güvenilir Satıcı</span>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="col-auto">
                                        <?php if ($urun->urun_turu == 2): ?>
                                            <div class="auto-complete mb-xl-3 mb-2" style="cursor:help;">
                                                <span><img height="24px" width="24px"
                                                           src="<?= base_url('assets/images/lightning.svg') ?>" alt=""></span>
                                                <span>Otomatik Teslimat</span>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-md-3 col-12 px-0">
                <div class="sproduct-dealer">
                    <div class="dealer-buttons">
                        <a title="Sohbet Et" href="/yeni-mesaj/<?= $magaza->magaza_uniq ?>">
                            <i class="far fa-comments"></i>&nbsp;
                            Sohbet Et
                        </a>
                        <?php if ($kullanici) : ?>
                            <?php if ($ayarlar->netgsm_durum == 1) : ?>
                                <a title="SMS Gönder" type="button" data-toggle="modal" data-target="#smsgonder">
                                    <i class="fas fa-mobile-alt"></i>&nbsp;
                                    SMS Gönder
                                </a>
                            <?php endif; ?>
                        <?php else : ?>
                            <a type="button" data-toggle="tooltip" data-placement="top"
                               title="SMS Göndermek İçin Giriş Yapmalısın!">
                                <i class="fas fa-mobile-alt"></i>&nbsp;
                                SMS Gönder
                            </a>
                        <?php endif; ?>
                    </div>
                    <div class="row">
                        <div class="col-4">
                            <div class="dealer-img mt-2">
                                <?php if (empty($magaza->magaza_resim)) { ?>
                                    <a  href="<?= base_url('m/' . $magaza->magaza_seo) ?>"><img
                                            src="https://ui-avatars.com/api/?name=<?= $kadijoin->kullanici_ad ?>&background=0D8ABC&color=fff"
                                            alt="<?= $kadijoin->kullanici_ad ?>" width="100%" height="100%"></a>
                                <?php } else { ?>
                                    <a title="Kullanıcı Adı" href="<?= base_url('m/' . $magaza->magaza_seo) ?>"><img
                                                src="<?= base_url($magaza->magaza_resim) ?>" alt="<?= $kadijoin->kullanici_ad ?>" width="100%"
                                                height="100%"></a>
                                <?php } ?>
                            </div>
                        </div>
                        <div class="col-8">
                            <div class="d-flex align-items-center h-100">
                                <a href="<?= base_url('m/' . $magaza->magaza_seo) ?>"><b><?= $magaza->magaza_ad ?></b></a>
                            </div>
                        </div>
                    </div>
                    <div class="dealer-ranks mt-3" style="width:100%">
                        <?php if ($urun->urun_turu == 2): ?>
                            <img height="16px" width="16px" src="<?= base_url('assets/images/lightning.svg') ?>" alt="ürün stok miktarı">
                            <font color="#c957f9">Bu ürün Stoktan anında teslim edilecektir.</font>
                        <?php endif; ?>
                    </div>
                    <div class="sproduct-price w-100 mt-3">
                        <?= $urun->urun_fiyat ?> TL
                    </div>
                    <a title="Satın Al" href="javascript:void(0)" onclick="satinAl('<?= $urun->urun_id ?>')" class="sproduct-buy mt-2">
                        <span>
                            <i class="fas fa-shopping-cart"></i>&nbsp;
                            Satın Al
                        </span>
                    </a>
                </div>
            </div>
        </div>
        <div class="row mt-4 gutters-small">
            <div class="col-md-4 col-12">
                <div class="order-autocomplete">
                    <span><img src="<?= base_url('assets/images/lightning.svg') ?>" alt="" height="20px" width="20px"></span>
                    <?php if ($urun->urun_turu == 2): ?>
                        <span>Siparişleriniz <b>otomatik</b> olarak teslim edilecektir.</span>
                    <?php else: ?>
                        <span>Siparişleriniz <b>Mağaza</b> tarafından teslim edilecektir.</span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-md-4 col-12">
                <div class="order-secure">
                    <span><img src="<?= base_url('assets/images/security.svg') ?>" alt="" height="20px" width="20px"></span>
                    <span>Paranız <b>%100 Herşeyoyun</b> güvencesi altındadır.</span>
                </div>
            </div>
            <div class="col-md-4 col-12">
                <?php
                $now = new DateTime();
                $future = new DateTime($urun->urun_bitis_tarihi);
                $interval = $future->diff($now);
                $text = $interval->format("<b>%a</b> gün <b>%h</b> saat <b>%i</b> dakika");
                ?>
                <div class="order-clock">
                    <span><img src="<?= base_url('assets/images/chronometer.svg') ?>" alt="" height="20px" width="20px"></span>
                    <span>Kalan süre: <?= $text ?></span>
                </div>
            </div>
        </div>
        <div class="home-products tab-system mt-xl-4 mt-3">
            <ul class="home-pro-tabs tabs "  id="nav-tab" >
                <li data-tab="description" class="active">
                    <div class="row align-items-center gutters-small justify-content-center">
                        <div class="col-xl-auto col-12"><img height="28px" width="28px"
                                                             src="<?= base_url('assets/images/personal-profile.svg') ?>"
                                                             alt=""></div>
                        <div class="col-xl-auto col-12 mt-xl-0 mt-2">
                            <span class="c-fff">Ürün Açıklaması</span>
                        </div>
                    </div>
                </li>
                <li data-tab="questions">
                    <div class="row align-items-center gutters-small justify-content-center">
                        <div class="col-xl-auto col-12"><img height="28px" width="28px"
                                                             src="<?= base_url('assets/images/question-mark.png') ?>"
                                                             alt=""></div>
                        <div class="col-xl-auto col-12 mt-xl-0 mt-2">
                           <span class="c-fff">Soru / Cevap</span> 
                        </div>
                    </div>
                </li>
                <li data-tab="comments">
                    <div class="row align-items-center gutters-small justify-content-center">
                        <div class="col-xl-auto col-12"><img height="28px" width="28px"
                                                             src="<?= base_url('assets/images/good-review.svg') ?>"
                                                             alt=""></div>
                        <div class="col-xl-auto col-12 mt-xl-0 mt-2">
                           <span class="c-fff">Satıcı Yorumları</span> 
                        </div>
                    </div>
                </li>
                <li data-tab="security">
                    <div class="row align-items-center gutters-small justify-content-center">
                        <div class="col-xl-auto col-12"><img height="28px" width="28px"
                                                             src="<?= base_url('assets/images/security.svg') ?>" alt="">
                        </div>
                        <div class="col-xl-auto col-12 mt-xl-0 mt-2">
                           <span class="c-fff">Güvenli Ticaret</span> 
                        </div>
                    </div>
                </li>
            </ul>
            <div class="tab-content active" id="description">
                <div class="bg-white p-3 btl-r0">
                    <?= $urun->urun_aciklama ?>
                </div>
            </div>
            <div class="tab-content" id="comments">
                <div class="bg-white p-3 btl-r0">
                    <div class="bg-grey p-3 product-det-reviews">
                        <div class="d-flex flex-wrap ii-review align-items-center justify-content-xl-between">
                            <div class="pdr-col">
                                <div class="fs-12 font-weight-bold">
                                    <div class="total-value d-flex align-items-center">
                                        <div class="value mr-2">
                                            <?php

                                                $rating = empty($rating) ? 0 : $rating;

                                                echo $rating;
                                            ?>
                                        </div>
                                        <div class="stars">
                                            <?php if ($rating == 0) { ?>
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                            <?php } else if ($rating >= 1 && $rating < 2) { ?>
                                                <i class="fas fa-star rated" style="color:#E4B91D!important;"></i>
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                            <?php } else if ($rating >= 2 && $rating < 3) {?>
                                                <i class="fas fa-star rated" style="color:#E4B91D!important;"></i>
                                                <i class="fas fa-star rated" style="color:#E4B91D!important;"></i>
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                            <?php } else if ($rating >= 3 && $rating < 4) {?>
                                                <i class="fas fa-star rated" style="color:#E4B91D!important;"></i>
                                                <i class="fas fa-star rated" style="color:#E4B91D!important;"></i>
                                                <i class="fas fa-star rated" style="color:#E4B91D!important;"></i>
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                            <?php } else if ($rating >= 4 && $rating < 5) {?>
                                                <i class="fas fa-star rated" style="color:#E4B91D!important;"></i>
                                                <i class="fas fa-star rated" style="color:#E4B91D!important;"></i>
                                                <i class="fas fa-star rated" style="color:#E4B91D!important;"></i>
                                                <i class="fas fa-star rated" style="color:#E4B91D!important;"></i>
                                                <i class="fas fa-star"></i>
                                            <?php } else if ($rating == 5 && $rating > 5) { ?>
                                                <i class="fas fa-star rated" style="color:#E4B91D!important;"></i>
                                                <i class="fas fa-star rated" style="color:#E4B91D!important;"></i>
                                                <i class="fas fa-star rated" style="color:#E4B91D!important;"></i>
                                                <i class="fas fa-star rated" style="color:#E4B91D!important;"></i>
                                                <i class="fas fa-star rated" style="color:#E4B91D!important;"></i>
                                           <?php } ?>
                                        </div>
                                    </div>
                                    <?php echo count($yorumlar) ?> Değerlendirme
                                </div>
                            </div>
                            <div class="pdr-col">
                                <div class="pdr-text">
                                    <div class="fs-12 font-weight-bold">Bilgilendirme</div>
                                    Bu kısımda satıcıya ait yorumları görüntüleyebilirsiniz.
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="review-comments">
                        <div class="rc-answer d-flex flex-wrap align-items-center rc-kp-row">
                            <?php if ($yorumlar) {
                                foreach ($yorumlar as $yorum) { ?>
                                    <div class="media w-100 align-items-center">
                                        <div class="user-comment-logo">
                                            <?php if (strpos($yorum->kullanici_resim, "/.jpg") !== false) { ?>
                                                <img src="https://ui-avatars.com/api/?name=<?= $yorum->kullanici_isim ?>&background=0D8ABC&color=fff"
                                                     alt="<?= $yorum->kullanici_isim . " " . $yorum->kullanici_soyisim ?>"
                                                     class="rounded-circle avatar-lg"/>
                                            <?php } else { ?>
                                            <img src="<?= base_url($yorum->kullanici_resim) ?>"
                                                 alt="<?= $yorum->kullanici_isim . " " . $yorum->kullanici_soyisim ?>"
                                                 class="rounded-circle avatar-lg"/>
                                             <?php } ?>
                                        </div>
                                        <div class="ml-3 mt-2 media-body">
                                            <div class="d-flex align-items-center justify-content-between">
                                                <div  class="d-flex align-items-center">
                                                    <h4 class="mb-0"><?= $yorum->kullanici_isim . " " . $yorum->kullanici_soyisim ?>
                                                    </h4>
                                                    <span class="ml-2">
                                                        <?= yorum_yildiz($yorum->yorum_puan) ?>
                                                    </span>
                                                    </div>
                                                <span class="text-muted font-size-xs"><?= date('d.m.Y H:i', strtotime($yorum->yorum_zaman)) ?></span>
                                            </div>
                                            <div class="mt-2">
                                                <p class="mt-2"><?= $yorum->yorum_detay ?></p>
                                            </div>
                                        </div>
                                    </div>
                                <?php }
                            } else { ?>
                                <div class="alert alert-warning text-center">
                                    Ürüne ait yorum bulunamadı.
                                </div>
                            <?php } ?>
                        </div>
                        <?php if (1 == 2) { ?>
                        <div class="rc-answer sub-comment mt-2">
                            <div class="media w-100 align-items-center">
                                <div class="user-comment-logo">
                                    <img src="https://kemalellidort.com.tr/uploads/img/6c9a4a04bccf4c9a8d050c32b4420227.jpeg"
                                         alt="melih kaya" class="rounded-circle avatar-lg">
                                </div>
                                <div class="ml-3 mt-2 media-body">
                                    <div class="d-flex align-items-center">
                                            <h4 class="mb-0">melih kaya</h4>
                                            <span class="text-muted font-size-xs ml-2">05.01.2024 02:21</span>
                                    </div>
                                    <div class="mt-2">
                                        <p class="mt-2">Memnun Kaldım Gerçekten Hızlı Teslimat</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php } ?>
                    </div>
                </div>
            </div>
            <div class="tab-content" id="questions">
                <div class="bg-white p-3 btl-r0">
                    <?php if (!empty($sorular)) { ?>
                        <button class="btn btn-soru-sor" data-id="<?php echo $urun->urun_id ?>" type="button"
                                data-toggle="modal" data-target="#sorusor"
                                data-title="<?php echo $urun->urun_ad ?>"><i class="fas fa-question"></i>
                            Soru Sor
                        </button>
                        <?php foreach ($sorular as $key => $val) { ?>
                            <div class="question-box">
                                <div class="question-box-question">
                                    <div class="soru-area">
                                        <div class="question-box-question-title">
                                            <span
                                                class="question-box-question-title-text">Soru : <?php echo $val->soru ?></span>
                                        </div>
                                        <div class="question-box-question-date">
                                            <span
                                                class="question-box-question-date-text"><?php echo ayli_tarih($val->tarih) ?> tarihinde soruldu</span>
                                        </div>
                                    </div>
                                    <?php if (empty($val->soru_cevap)) { ?>
                                        <?php if ($user_magaza->magaza_id == $val->magaza_id) { ?>
                                            <div class="cevap-ver-area">
                                                <button class="btn btn-soru-sor" data-id="106" type="button"
                                                        data-toggle="modal"
                                                        data-target="#sorucevap-<?php echo $val->soru_id ?>"
                                                        data-title="last ilan"><i class="fas fa-reply"></i>
                                                    Cevapla
                                                </button>
                                            </div>
                                        <?php } ?>
                                    <?php } ?>
                                </div>
                                <?php if (!empty($val->soru_cevap)) { ?>
                                    <div class="question-box-answer">
                                        <div class="question-box-answer-user">
                                            <div class="user-box-data">
                                                <img
                                                    src="<?php echo base_url($val->soru_cevap->magaza->magaza_resim) ?>"
                                                    alt="<?php echo $val->soru_cevap->magaza->magaza_ad ?>"
                                                    title="<?php echo $val->soru_cevap->magaza->magaza_ad ?>">
                                                <span><b><?php echo $val->soru_cevap->magaza->magaza_ad ?></b><br>Satıcının Cevabı</span>
                                            </div>
                                            <span
                                                class="question-box-answer-date-text"><?php echo ayli_tarih($val->tarih) ?></span>
                                        </div>
                                        <div class="question-box-answer-title">
                                            <span
                                                class="question-box-answer-title-text"><?php echo $val->soru_cevap->soru ?></span>
                                        </div>
                                    </div>
                                <?php } ?>
                            </div>
                            <div class="modal fade" id="sorucevap-<?php echo $val->soru_id ?>" tabindex="-1"
                                 role="dialog" aria-labelledby="exampleModalCenterTitle"
                                 aria-hidden="true">
                                <div class="modal-dialog modal-dialog-centered" role="document">
                                    <div class="modal-content cevap-ver">
                                        <div class="modal-header">
                                            <h4 class="modal-title text-center"
                                                id="exampleModalCenterTitle"><?php echo $val->urun_ad ?> İlanınızın
                                                Sorusu</h4>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <div class="alert alert-info alert-dismissible text-left alert-grid"
                                             role="alert">
                                            <i class="fas fa-question"></i>
                                            <div><strong>Soru:</strong><br><?php echo $val->soru ?>
                                            </div>
                                        </div>
                                        <?php if (!empty($val->soru_cevap)) { ?>
                                            <div class="alert alert-info alert-dismissible text-left alert-grid"
                                                 role="alert">
                                                <div><strong>Cevap:</strong><br><?php echo $val->soru_cevap->soru ?>
                                                </div>
                                            </div>
                                        <?php } ?>
                                        <?php if (empty($val->soru_cevap)) { ?>
                                            <form class="p-2 soru-cevap-form">
                                                <input type="hidden" name="soru_id" value="<?php echo $val->soru_id ?>">
                                                <div class="row">
                                                    <div class="col-12">
                                                        <label class="form-label">Cevabınız</label>
                                                        <textarea class="form-control" name="cevap"
                                                                  placeholder="Lütfen Bir Cevap Yazınız..."
                                                                  rows="4"></textarea>
                                                    </div>
                                                </div>
                                                <div class="py-2">
                                                    <button type="submit"
                                                            class="btn btn-primary rounded-pill soru-cevap-btn w-100">
                                                        Cevap Ver
                                                    </button>
                                                </div>
                                            </form>
                                        <?php } ?>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                    <?php } else { ?>
                        <div class="row">
                            <div class="col-md-12 text-center" style="padding: 30px 0px;">
                                <img src="<?php echo base_url('assets/images/empty-soru.png') ?>" style="width: 80px;">
                                <h3 class="m-b-0">Soru bulunamadı</h3>
                                <p class="">Bu ilana ait soru bulunmamaktadır.<br>Aşağıdaki butona tıklayarak merak
                                    ettiklerinizi satıcıya sorabilirsiniz.</p>
                                <button type="button" data-toggle="modal" data-target="#sorusor"
                                        class="btn btn-primary btn-soru-sor" data-id="<?php echo $urun->urun_id ?>"
                                        data-title="<?php echo $urun->urun_ad ?>"><i class="fas fa-feather-alt"
                                                                                     style="margin-right: 5px"></i> Soru
                                    sormak için tıklayın
                                </button>
                            </div>
                        </div>
                    <?php } ?>
                </div>
            </div>
            <div class="tab-content" id="security">
                <div class="bg-white p-3 btl-r0">
                    <ul>
                        <li>
                            <span>Herşeyoyun alışveriş süreci sona erene kadar ücretinizi güvene almaktadır.</span>
                            <span>Alışveriş sonrası süreçte iade, teknik destek gibi konulardan ürünün satıcısı sorumludur.</span>
                        </li>
                        <li>
                            <span> İlan başlığı ve açıklamasında telefon numarası, sosyal medya hesabı paylaşmak yasaktır, tespiti halinde ilan ve hesabınız kapatılır.</span>
                        </li>
                        <li>
                            <span>Takas işlemleri kesinlikle yasaktır</span> ve oluşabilecek sorunlarda her iki tarafa
                            da <span>destek sağlanmamaktadır.</span>
                        </li>
                        <li>
                            <span>Hesap satışlarında eğer satıcı hesabı geri alma girişiminde bulunursa</span> ve alıcı
                            şikayette bulunduğunda satıcının
                            <span>tüm kişisel bilgileri savcılık ile paylaşılacaktır.</span>
                        </li>
                        <li>
                            <a href="#">
                                <span>Bu linkten yardım merkezine giderek site hakkında daha detaylı bilgi sahibi olabilirsiniz.</span>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<?php if ($ayarlar->netgsm_durum == 1) { ?>
    <div class="modal fade" id="smsgonder" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
         aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content sms">
                <div class="modal-header">
                    <h4 class="modal-title text-center" id="exampleModalCenterTitle">Satıcıya SMS
                        Gönder</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="" method="post" class="p-2 sms-form">
                    <p>Buradan ilan sahibine SMS olarak mesaj gönderebilirsiniz.</p>
                    <div class="row">
                        <div class="col-12 mb-2">
                            <label class="form-label">SMS Mesajları</label>
                            <select id="sablonsec" name="sablon" class="form-control" data-width="100%" required="">
                                <option value="0" hidden>Sms Mesajı Seçiniz...</option>
                                <?php foreach ($sms_sablonlar as $item) { ?>
                                    <option value="<?= $item->sablon_id ?>"><?= $item->sablon_baslik ?></option>
                                <?php } ?>
                            </select>
                        </div>
                        <div class="col-12" id="sms_sablon">
                            <label class="form-label">SMS Mesajları</label>
                            <textarea class="form-control" placeholder="Lütfen SMS Şablonu Seçin!" id="sablon" disabled
                                      rows="4"></textarea>
                        </div>
                    </div>
                    <div class="py-2">
                        <button type="submit" class="btn btn-primary rounded-pill sms-btn w-100">SMS
                            Gönder (<?= $ayarlar->sms_tutar ?>₺)
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php } ?>
<div class="modal fade" id="sorusor" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
     aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content sms">
            <div class="modal-header">
                <h4 class="modal-title text-center" id="exampleModalCenterTitle">Satıcıya Soru Sor</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="alert alert-warning alert-dismissible text-left alert-grid" role="alert">
                <i class="fas fa-question"></i>
                <div><strong>Satıcıya Sor</strong><br>Bu alandan <b class="soru-ilan-baslik"></b> adlı ilanın
                    satıcısında soru sorabilirsiniz, sorduğunuz soru satıcı tarafından cevaplandıktan sonra ilan
                    detayında herkes tarafından görülebilir olacaktır.
                </div>
            </div>
            <form class="p-2 sorusor-form">
                <div class="row">
                    <div class="col-12">
                        <label class="form-label">Sorunuz</label>
                        <textarea class="form-control" id="soru-textarea" placeholder="Lütfen Bir Soru Sorunuz"
                                  rows="4"></textarea>
                    </div>
                </div>
                <div class="py-2">
                    <button type="button" class="btn btn-primary rounded-pill soru-sor-btn w-100">Soru Sor</button>
                </div>
            </form>
        </div>
    </div>
</div>


<script src="https://code.jquery.com/jquery-2.1.4.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/photoswipe/4.1.0/photoswipe.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/photoswipe/4.1.0/photoswipe-ui-default.min.js"></script>

<script src="<?= base_url('assets/front/') ?>libs/jquery/dist/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/jquery.magnific-popup.min.js"
        integrity="sha512-IsNh5E3eYy3tr/JiX2Yx4vsCujtkhwl7SLqgnwLNgf04Hrt9BT9SXlLlZlWx+OK4ndzAoALhsMNcCmkggjZB1w=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/simplelightbox/2.14.1/simple-lightbox.min.js"
        integrity="sha512-X1tKd7cMiYWKVDmFHSn+z1Y+BdrNG6Qvrhj3emg0ZOMsAuzug4ET9PmOFBgYyvcjI1hHGxhkQ1IXhOd9obYeFQ=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script>
    $(document).ready(function () {
        $(".home-pro-tabs>li").on('click', function () {
            var target = $(this).attr('data-tab');
            $(".home-pro-tabs>li").removeClass('active')
            $(".home-products>.tab-content").removeClass('active');
            $(this).addClass('active');
            $(".home-products>#" + target).addClass('active');
        })
        var base_url = "<?= base_url() ?>";
        $('#sablonsec').on('change', function () {
            $('#sms_sablon').show();
            var sablon_id = $("#sablonsec option:selected").val();
            $.ajax({
                type: "POST",
                url: base_url + "ajax_controller/sms_sablon",
                data: {
                    "sablon_id": sablon_id,
                    "baslik": "<?= $urun->urun_ad ?>"
                },
                success: function (data) {
                    $("#sablon").html(data);
                }
            });
        });

        $(".soru-cevap-form").submit(function (event) {
            event.preventDefault();
            var serialized = $(this).serializeArray();
            $.ajax({
                type: "POST",
                url: base_url + "ajax_controller/soru_cevap",
                data: serialized,
                success: function (data) {
                    var d = JSON.parse(data);
                    if (d.status.status == 'error') {
                        Swal.fire(
                            'Hata!',
                            d.status.message,
                            d.status.status,
                        );
                    } else if (d.status.status == 'success') {
                        Swal.fire(
                            'Başarılı!',
                            d.status.message,
                            d.status.status,
                        ).then((result) => {
                            location.reload();
                        })
                    }

                }
            });
        });


        $(".sms-form").submit(function (event) {
            $.ajax({
                type: "POST",
                url: base_url + "ajax_controller/sms_gonder",
                data: {
                    sablon_id: $("#sablonsec option:selected").val(),
                    urun_id: <?= $urun->urun_id ?>
                },
                success: function (data) {
                    var d = JSON.parse(data);
                    if (d.status.status == 'error') {
                        Swal.fire(
                            'Hata!',
                            d.status.message,
                            d.status.status,
                        );
                    } else if (d.status.status == 'success') {
                        Swal.fire(
                            'Başarılı!',
                            d.status.message,
                            d.status.status,
                        ).then((result) => {
                            location.reload();
                        })
                    }

                }
            });
            event.preventDefault();
        });
        $(".btn-soru-sor").click(function () {
            var dataTitleValue = $(this).data("title");

            $(".soru-ilan-baslik").text(dataTitleValue);
        });
        $(".soru-sor-btn").click(function (event) {
            <?php if (aktif_kullanici()) : ?>
            $.ajax({
                type: "POST",
                url: base_url + "ajax_controller/soru_sor",
                data: {
                    soru: $("#soru-textarea").val(),
                    urun_id: <?= $urun->urun_id ?>,
                    kullanici_id: <?= $kullanici->kullanici_id ?>
                },
                success: function (data) {
                    var d = JSON.parse(data);
                    if (d.status.status == 'error') {
                        Swal.fire(
                            'Hata!',
                            d.status.message,
                            d.status.status,
                        );
                    } else if (d.status.status == 'success') {
                        Swal.fire(
                            'Başarılı!',
                            d.status.message,
                            d.status.status,
                        ).then((result) => {
                            location.reload();
                        })
                    }

                }
            });
            event.preventDefault();
            <?php else : ?>
            Swal.fire({
                title: 'Giriş Yap',
                text: "Soru Sormak için giriş yapmalısınız.",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Giriş Yap',
                cancelButtonText: 'Hayır, İptal Et',
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = "<?= base_url('giris-yap') ?>";
                }
            })
            <?php endif; ?>
        });
    });
    $('.owl-carousel').magnificPopup({
        delegate: 'a', // child items selector, by clicking on it popup will open
        type: 'image',
        gallery: {
            enabled: true
        },
        // other options
    });
    // $('.fotograf<?= $key ?>').magnificPopup({type:'image'});
</script>

<script>
    function satinAl(urun_id) {
        Swal.fire({
            type: 'info',
            width: '70em',
            title: 'Açık Rıza Onayı',
            html: 'Bu kategorideki hesaplar RANDOM (Rastgele) hesaplardır. Hesapların bilgileri değişmeyebilir, email erişimi olmayabilir veya banlı çıkabilir. Yalnızca banlı çıkan hesaplarda satıcılar iade yapmak zorundadır.<br><br>Hesaplarla ilgili yaşadığınız sorunlarda lütfen ÖNCELİKLE SATICIYA mesaj gönderiniz. ',
            input: 'checkbox',
            inputPlaceholder: 'Açıklamayı okudum ve kabul ediyorum',
            cancelButtonText: 'İptal',
            confirmButtonText: 'Satın almaya devam et!',
            showCancelButton: true
        }).then(function (result) {
            if (result.value) {
                console.log(result);
                <?php if (aktif_kullanici()) : ?>
                var kullanici_bakiye = <?= $kullanici->bakiye ?>;
                $.post("<?=base_url(); ?>urun_detay/" + urun_id, function (data, status) {
                    let urun_fiyat = data.urun_fiyat;
                    let urun_stok = data.urun_stok;
                    /*let urun_id = data.urun_id;*/

                    if (urun_stok <= 0) {
                        Swal.fire({
                            title: 'Stokta Yok',
                            text: "Bu ürün stokta bulunmamaktadır.",
                            icon: 'error',
                            showCancelButton: true,
                            confirmButtonText: 'Tamam',
                        }).then((result) => {
                        });
                        return false;
                    }
                    if (urun_fiyat > kullanici_bakiye) {

                        Swal.fire({
                            title: 'Bakiye Yetersiz',
                            text: "Bu ürünü satın almak için bakiyeniz yetersiz.",
                            icon: 'error',
                            showCancelButton: true,
                            confirmButtonText: 'Bakiye Yükle',
                            cancelButtonText: 'Hayır, İptal Et',
                        }).then((result) => {
                            if (result.isConfirmed) {
                                window.location.href = "<?= base_url('bakiye') ?>";
                            }
                        });
                        return false;
                    }
                    $.post({
                        url: "<?=base_url(); ?>odeme-yap/" + urun_id,
                        type: 'POST',
                        data: {
                            urun_id: urun_id
                        },
                        success: function (response) {
                            if (response.status == 'success') {
                                Swal.fire({
                                    title: 'Satın alma işlemi başarılı',
                                    text: response.message,
                                    icon: 'success',
                                    showCancelButton: true,
                                    confirmButtonText: 'Siparişlerim Sayfasına Git',
                                    cancelButtonText: 'Geri Dön',
                                }).then((result) => {
                                    if (result.isConfirmed) {
                                        window.location.href = "<?= base_url('siparislerim') ?>";
                                    }
                                })
                            } else {
                                Swal.fire({
                                    title: 'Hata!',
                                    html: response.message,
                                    type: 'error',
                                    icon: 'success',
                                    confirmButtonText: 'Tamam'
                                });
                            }
                        },
                        error: function (response) {
                            Swal.fire({
                                title: 'Hata!',
                                html: 'Bağlantı Hatası Lütfen Daha Sonra Tekrar Deneyiniz!!',
                                type: 'error',
                                confirmButtonText: 'Tamam'
                            });
                        }
                    });

                });

                <?php else : ?>
                Swal.fire({
                    title: 'Giriş Yap',
                    text: "Ürünü satın almak için giriş yapmalısınız.",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonText: 'Giriş Yap',
                    cancelButtonText: 'Hayır, İptal Et',
                }).then((result) => {
                    if (result.isConfirmed) {
                        window.location.href = "<?= base_url('giris-yap') ?>";
                    }
                })
                <?php endif; ?>

                // window.location.href = "<?= base_url('siparis/' . $urun->urun_seo) ?>";
                // href="<?= base_url('siparis/' . $urun->urun_seo) ?>"
            } else if (result.value === 0) {
                Swal.fire({
                    type: 'error',
                    text: "Açık rıza onayını kabul etmeden bu kategoride satın alma işlemi gerçekleştiremezsiniz."
                });
            } else {
                console.log(`modal was dismissed by ${result.dismiss}`);
            }
        });
    }

    var swiper = new Swiper(".gallery-swiper", {
        centeredSlides: true,
        loop: true,
        autoplay: {
            delay: 2500,
        },
        navigation: {
            nextEl: ".swiper-button-next",
            prevEl: ".swiper-button-prev",
        }
    });

    var gallery = new SimpleLightbox('.swiper-slide a', {});

</script>