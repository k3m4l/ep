<!-- Page header -->
<style>
    .panel {
        border: none;
        border-radius: 4px;
        box-shadow: 0 5px 5px 0 rgba(85, 85, 85, .06);
        background: #fff;
        margin-bottom: 20px;
    }

    .panel-body {
        background: #2f3144;
        color: #979aae;
    }

    .accordion {
        --bs-accordion-bg: unset;
        --bs-accordion-border-color: none;
        --bs-accordion-border: none;
        --bs-accordion-btn-icon: none;
        --bs-accordion-active-bg: none;
        --bs-accordion-btn-active-icon: none;
        --bs-accordion-btn-focus-border-color: none;
        --bs-accordion-btn-focus-box-shadow: none;

    }

    .accordion-button {
        background: linear-gradient(to bottom, #363a62, #2f3144);
        color: #d7d8e6;
        border: none;
        padding: 15px;
        width: 100%;
        text-align: left;
        font-size: 20px;
    }

    .accordion-button:focus {
        border: none;
        box-shadow: none;
        outline: 0;
    }

    .accordion-body {
        background: linear-gradient(324.27deg, #0e1929 0, #2c425e 98.33%);
        text-align: left;
        padding: 5px;
    }

    .accordion-button:not(.collapsed) {
        color: #d7d8e6;
    }

    .accordion-tex {
        text-align: left;
    }


    .accordion-item {
        color: #979aae;
        border: none;
    }

    .accordion-text {
        padding: 10px;
        color: #979aae;
    }

    .accordion-header {
        margin: 0;
    }
</style>
<div class="active-raffle mt-5">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-xl-12 col-lg-12 col-md-12 col-12">
                <div class="row">
                    <div class="col-md-12">
                        <div class="bg-sbq-2">


                            <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link active" id="active-raffles-tab" data-bs-toggle="pill" data-bs-target="#active-raffles"
                                            type="button" role="tab" aria-controls="active-raffles" aria-selected="true">Aktif Çekilişler
                                    </button>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link" id="deactive-raffles-tab" data-bs-toggle="pill" data-bs-target="#deactive-raffles"
                                            type="button" role="tab" aria-controls="deactive-raffles" aria-selected="false">Tamamlanmış Çeklişler
                                    </button>
                                </li>

                            </ul>
                            <div class="tab-content" id="pills-tabContent">
                                <div class="tab-pane fade show active" id="active-raffles" role="tabpanel" aria-labelledby="active-raffles-tab">
                                    <div class="draw-area mt-3 ">
                                        <div class="row">
                                            <?php if (!empty($veriler)) { ?>
                                                <?php foreach ($veriler as $cekilis) : ?>
                                                    <div class="col-md-3 mt-2">
                                                        <div class="card panel-giveaway">
                                                            <div class="card-body">
                                                                <a href="<?= base_url('m/' . $cekilis->magaza->magaza_seo) ?>"
                                                                   title="<?= $cekilis->title ?>">
                                                                    <div class="giveaway-creator">
                                                                        <div class="giveaway-creator-image">
                                                                            <img src="<?= base_url($cekilis->resim) ?>"
                                                                                 style="width: 40px;height: 40px; object-fit: cover;">
                                                                        </div>
                                                                        <div class="creator-name-title">
                                                                            <div
                                                                                    class="creator-name"><?= $cekilis->magaza->magaza_ad ?></div>
                                                                            <div class="giveaway-title"><?= $cekilis->title ?></div>
                                                                        </div>
                                                                    </div>
                                                                </a>
                                                                <div class="giveaway-datetime">
                                                                    <i class="fas fa-calendar-alt"></i>

                                                                    <?php

                                                                    $startDateTime = new DateTime();

                                                                    $endDateTime = new DateTime($cekilis->end_date);

                                                                    $interval = $endDateTime->diff($startDateTime);

                                                                    $formatString = '';
                                                                    if ($interval->y > 0) {
                                                                        $formatString .= '%y yıl, ';
                                                                    }
                                                                    if ($interval->m > 0) {
                                                                        $formatString .= '%m ay, ';
                                                                    }
                                                                    if ($interval->d > 0) {
                                                                        $formatString .= '%d gün, ';
                                                                    }
                                                                    if ($interval->h > 0) {
                                                                        $formatString .= '%h saat, ';
                                                                    }
                                                                    if ($interval->i > 0) {
                                                                        $formatString .= '%i dakika, ';
                                                                    }


                                                                    echo "Çekiliş: " . rtrim($interval->format($formatString), ', ');

                                                                    ?> sonra sona erecek
                                                                </div>
                                                                <div class="giveaway-info">
                                                                    <div class="giveaway-prize">
                                                                        <b><?= $cekilis->toplam_fiyat ?> <small>₺</small></b>
                                                                        <span>değerinde çekiliş havuzu</span>
                                                                    </div>
                                                                    <div class="giveaway-total-join">
                                                                        <b><?= $cekilis->katilimcisayi ?></b>
                                                                        <span>Katılımcı</span>
                                                                    </div>
                                                                </div>
                                                                <div class="giveaway-content">
                                                                    <?php foreach ($cekilis->esyalar as $esya) : ?>

                                                                        <div class="giveaway-content-item">
                                                                            <a href="" ttitle="1 TL Hediye Kartı"
                                                                               style="position:relative; display: block">
                                                                                <?php if (isset($esya->bakiyem)) : ?>
                                                                                    <img src="<?= $esya->urun_resim ?>"
                                                                                         title="1 TL Hediye Kartı">
                                                                                <?php else : ?>
                                                                                    <img src="<?= base_url($esya->urun_resim) ?>"
                                                                                         title="1 TL Hediye Kartı">
                                                                                <?php endif; ?>
                                                                                <span
                                                                                        style="text-shadow: 0 0 5px #000, 0 0 5px #000; white-space: nowrap; bottom: 0; position: absolute; left: 0; right: 0; background: rgba(0,0,0,0.7); width: 100%; text-align: center;"><?= $esya->urun_fiyat ?> TL</span>

                                                                                <span
                                                                                        class="giveaway-item-count"><?= $esya->urun_miktar ?> Kişiye</span>
                                                                            </a>
                                                                        </div>
                                                                    <?php endforeach; ?>

                                                                </div>
                                                                <?php if ($cekilis->katildimi == 1) : ?>
                                                                    <button class="btn btn-block btn-success"
                                                                            style="margin-top: 10px !important; width: 100%;">
                                                                        Çekilişe katıldınız <i class="fa fa-check"></i>
                                                                    </button>
                                                                <?php else : ?>
                                                                    <a href="<?= base_url("cekilisler/katil/" . $cekilis->id) ?>"
                                                                       class="btn btn-primary btn-block btn-cekilis" data-id="372"
                                                                       style="margin-top:10px;  margin-right: 5px !important;">
                                                                        <i class="fas fa-user-plus"></i> Çekilişe Katıl
                                                                    </a>
                                                                <?php endif; ?>

                                                                <a href="<?= base_url("cekilisler/detay/" . $cekilis->id) ?>"
                                                                   title="TAKİP EDENLERE ÖZEL ÇEKİLİŞ!!! MAĞAZAMA BEKLERİM :)"
                                                                   class="btn btn-secondary btn-block"
                                                                   style="margin-top: 10px !important; width: 100%;"><i
                                                                            class="far fa-list-alt"></i> Çekiliş Detayları</a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                <?php endforeach; ?>
                                            <?php } else { ?>
                                                <div class="alert alert-warning alert-custom  w-100 m-0 text-center" role="alert">
                                                    Aktif Çekiliş Bulunmamaktadır
                                                </div>
                                            <?php } ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="tab-pane fade" id="deactive-raffles" role="tabpanel" aria-labelledby="deactive-raffles-tab">
                                    <div class="draw-area mt-3 bg-sbq">
                                        <div class="row">
                                            <?php if (!empty($sonaerenler)) { ?>
                                                <?php foreach ($sonaerenler as $cekilis) : ?>
                                                    <div class="col-lg-3 col-md-6 col-12 mt-2">
                                                        <div class="card panel-giveaway">
                                                            <div class="card-body">
                                                                <a href="<?= base_url("cekilisler/detay/" . $cekilis->id) ?>"
                                                                   title="<?= $cekilis->title ?>">
                                                                    <div class="giveaway-creator">
                                                                        <div class="giveaway-creator-image">
                                                                            <img src="<?= base_url($cekilis->resim) ?>">
                                                                        </div>
                                                                        <div class="creator-name-title">
                                                                            <div
                                                                                    class="creator-name"><?= $cekilis->magaza->magaza_ad ?></div>
                                                                            <div class="giveaway-title"><?= $cekilis->title ?></div>
                                                                        </div>
                                                                    </div>
                                                                </a>
                                                                <div class="giveaway-datetime">
                                                                    <i class="fas fa-calendar-alt"></i>
                                                                    <?php
                                                                    date_default_timezone_set('Europe/Istanbul');

                                                                    $turkceGunler = array(
                                                                        'Pazartesi',
                                                                        'Salı',
                                                                        'Çarşamba',
                                                                        'Perşembe',
                                                                        'Cuma',
                                                                        'Cumartesi',
                                                                        'Pazar'
                                                                    );

                                                                    $turkceAylar = array(
                                                                        'Ocak',
                                                                        'Şubat',
                                                                        'Mart',
                                                                        'Nisan',
                                                                        'Mayıs',
                                                                        'Haziran',
                                                                        'Temmuz',
                                                                        'Ağustos',
                                                                        'Eylül',
                                                                        'Ekim',
                                                                        'Kasım',
                                                                        'Aralık'
                                                                    );

                                                                    //çekiliş bitiş tarihine göre eşle
                                                                    $turkceAy = $turkceAylar[date('m', strtotime($cekilis->end_date)) - 1]; // Dönen değer 4s
                                                                    $turkceGun = $turkceGunler[date('N', strtotime($cekilis->end_date)) - 1]; // Dönen değer 5
                                                                    echo date('j ', strtotime($cekilis->end_date)) . $turkceAy . date(' Y ', strtotime($cekilis->end_date)) . $turkceGun . date(' H:i:s', strtotime($cekilis->end_date));
                                                                    ?>
                                                                </div>
                                                                <div class="giveaway-info">
                                                                    <div class="giveaway-prize">
                                                                        <b><?= $cekilis->toplam_fiyat ?> <small>₺</small></b>
                                                                        <span>değerinde çekiliş havuzu</span>
                                                                    </div>
                                                                    <div class="giveaway-total-join">
                                                                        <b><?= $cekilis->katilimcisayi ?></b>
                                                                        <span>Katılımcı</span>
                                                                    </div>
                                                                </div>
                                                                <div class="giveaway-content">
                                                                    <?php foreach ($cekilis->esyalar as $esya) : ?>

                                                                        <div class="giveaway-content-item">
                                                                            <a href="" ttitle="1 TL Hediye Kartı"
                                                                               style="position:relative; display: block">
                                                                                <?php if (isset($esya->bakiyem)) : ?>
                                                                                    <img src="<?= $esya->urun_resim ?>"
                                                                                         title="1 TL Hediye Kartı">
                                                                                <?php else : ?>
                                                                                    <img src="<?= base_url($esya->urun_resim) ?>"
                                                                                         title="1 TL Hediye Kartı">
                                                                                <?php endif; ?>
                                                                                <span
                                                                                        style="text-shadow: 0 0 5px #000, 0 0 5px #000; white-space: nowrap; bottom: 0; position: absolute; left: 0; right: 0; background: rgba(0,0,0,0.7); width: 100%; text-align: center; "><?= $esya->urun_fiyat ?> ₺</span>

                                                                                <span
                                                                                        class="giveaway-item-count"><?= $esya->urun_miktar ?> Kişiye</span>
                                                                            </a>
                                                                        </div>
                                                                    <?php endforeach; ?>

                                                                </div>

                                                                <a href="<?= base_url("cekilisler/detay/" . $cekilis->id) ?>"
                                                                   title="TAKİP EDENLERE ÖZEL ÇEKİLİŞ!!! MAĞAZAMA BEKLERİM :)"
                                                                   class="btn btn-secondary btn-block" style="margin-top:10px;"><i
                                                                            class="far fa-list-alt"></i> Çekiliş Sonuçları</a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                <?php endforeach; ?>
                                            <?php } else { ?>
                                                <div class="alert alert-warning alert-custom w-100 text-center " role="alert">
                                                    Tamamlanmış Çekiliş Bulunmamaktadır
                                                </div>
                                            <?php } ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="draw-element pb-4 pb-lg-15">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-xl-12 col-lg-12 col-md-12 col-12">
                    <div class="row">
                        <div class="col-md-12">
                            <ul class="home-pro-tabs tabs4 br-none" style="padding: 0;margin-top: 35px;">
                                <li data-tab4="populer-urunler" style="width: 100% !important;" class="active">
                                    <div class="row align-items-center gutters-small justify-content-center">
                                        <!--<div class="col-xl-auto col-12"><img src="https://kemalellidort.com.tr/uploads/vitrinler/64c5e53e214cb_trending.png" height="32px" alt=""></div>-->
                                        <div class="col-xl-auto col-12 mt-xl-0 mt-2 pl-lg-0">
                                            <h2 class="dranw-title">Çekiliş Sistemi</h2>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                            <div class="text-center panel-body bg-sbq mt-3">
                                <div class="row">
                                    <div class="col-lg-6 col-md-12 order-lg-1 order-2">
                                        <p class="text-left accordion-text">
                                            Herseyoyun üyesi olmanın avantajları saymakla bitmez! Tamamen
                                            ücretsiz düzenlenen çekilişlere katılarak dijital oyun pinleri,
                                            hediye kartları ve oyun içi ürünler kazanabilirsiniz. Üstelik bu
                                            çekilişlere katılmak için tek yapmanız gereken üye olup, çekilişe
                                            katıl butonuna tıklamak, hemen siteye üye olun ve kazanmaya
                                            başlayın.
                                        </p>
                                        <div class="accordion" id="accordionExample">
                                            <div class="accordion-item mb-3">
                                                <h2 class="accordion-header acc-header-cekilis">
                                                    <button class="accordion-button acc-header-cekilis-btn" type="button"
                                                            data-bs-toggle="collapse"
                                                            data-bs-target="#collapseOne" aria-expanded="true"
                                                            aria-controls="collapseOne">
                                                        Bir çekilişe nasıl katılırım?
                                                        <span class="collapse-toggle ms-4">
                                                             <i class="fe fe-chevron-down text-muted"></i>
                                                         </span>
                                                    </button>

                                                </h2>
                                                <div id="collapseOne" class="accordion-collapse collapse show"
                                                     data-bs-parent="#accordionExample">
                                                    <div class="accordion-body text-start acc-cb-item">
                                                        Bir mağazanın veya Herseyoyun’ın düzenlediği çekilişlere
                                                        katılmak için bu sayfadan “çekilişe katıl” butonuna
                                                        tıklayabilir veya “çekiliş detayları” butonuna tıkladıktan
                                                        sonra açılan sayfadan çekilişlere katılabilirsiniz.
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="accordion-item mb-3">
                                                <h2 class="accordion-header acc-header-cekilis">
                                                    <button class="accordion-button collapsed acc-header-cekilis-btn" type="button"
                                                            data-bs-toggle="collapse" data-bs-target="#collapseTwo"
                                                            aria-expanded="false" aria-controls="collapseTwo">
                                                        Çekiliş ödüllerini nereden görebilirim?
                                                        <span class="collapse-toggle ms-4">
                                                             <i class="fe fe-chevron-down text-muted"></i>
                                                         </span>
                                                    </button>
                                                </h2>
                                                <div id="collapseTwo" class="accordion-collapse collapse"
                                                     data-bs-parent="#accordionExample">
                                                    <div class="accordion-body text-start acc-cb-item">
                                                        Bu sayfadaki çekiliş bilgisi bulunan alandan ve çekiliş
                                                        detayları sayfasından verilecek ödülü görebilirsiniz.
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="accordion-item mb-3">
                                                <h2 class="accordion-header acc-header-cekilis">
                                                    <button class="accordion-button collapsed acc-header-cekilis-btn" type="button"
                                                            data-bs-toggle="collapse" data-bs-target="#collapseThree"
                                                            aria-expanded="false" aria-controls="collapseThree">
                                                        Kazandığımı nasıl anlarım?
                                                        <span class="collapse-toggle ms-4">
                                                             <i class="fe fe-chevron-down text-muted"></i>
                                                         </span>
                                                    </button>
                                                </h2>
                                                <div id="collapseThree" class="accordion-collapse collapse"
                                                     data-bs-parent="#accordionExample">
                                                    <div class="accordion-body text-start acc-cb-item">
                                                        Katıldığınız çekilişin detay sayfasından sonra ereceği
                                                        tarihi görebilirsiniz. Bu tarih sona erdikten sonra tekrar
                                                        sayfaya girerek kazananları kontrol edebilirsiniz. Çekilişi
                                                        kazanan kişilere SMS veya Mail Gönderilmektedir.
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="accordion-item mb-3">
                                                <h2 class="accordion-header acc-header-cekilis">
                                                    <button class="accordion-button collapsed acc-header-cekilis-btn" type="button"
                                                            data-bs-toggle="collapse" data-bs-target="#collapseFour"
                                                            aria-expanded="false" aria-controls="collapseFive">
                                                        Çekilişe katılım ücretli mi?
                                                        <span class="collapse-toggle ms-4">
                                                             <i class="fe fe-chevron-down text-muted"></i>
                                                         </span>
                                                    </button>
                                                </h2>
                                                <div id="collapseFour" class="accordion-collapse collapse"
                                                     data-bs-parent="#accordionExample">
                                                    <div class="accordion-body text-start acc-cb-item">
                                                        Herseyoyun’ta düzenlenen tüm çekilişlere katılım tamamen
                                                        ücretsizdir. Düzenli olarak bu sayfayı takip edin ve
                                                        ücretsiz çekilişleri kazanma şansı yakalayın.
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="accordion-item mb-3">
                                                <h2 class="accordion-header acc-header-cekilis">
                                                    <button class="accordion-button collapsed acc-header-cekilis-btn" type="button"
                                                            data-bs-toggle="collapse" data-bs-target="#collapseFive"
                                                            aria-expanded="false" aria-controls="collapseFive">
                                                        Nasıl çekiliş düzenleyebilirim?
                                                        <span class="collapse-toggle ms-4">
                                                             <i class="fe fe-chevron-down text-muted"></i>
                                                         </span>
                                                    </button>
                                                </h2>
                                                <div id="collapseFive" class="accordion-collapse collapse"
                                                     data-bs-parent="#accordionExample">
                                                    <div class="accordion-body text-start acc-cb-item">
                                                        Herseyoyun’ta çekiliş düzenleyebilmek için Mağaza olmanız
                                                        gerekmektedir. Mağaza üyelerimiz mağaza panelinden
                                                        "Çekilişler" sekmesinde gerekli yönlendirmeleri uygulayarak
                                                        çekiliş oluşturabilirler.
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-12 order-lg-2 order-1">
                                        <img
                                                src="<?php echo base_url('assets/front/images/1boo5zg.jpeg') ?>"
                                                alt="" class="draw-free-img"/>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<!-- Footer -->

</style>