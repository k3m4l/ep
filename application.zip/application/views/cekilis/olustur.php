<!-- Page header -->

<div class="bg-dark py-4 py-lg-15">
    <div class="siyahlik"></div>
    <div class="container">
        <div class="row align-items-center">
            <div class="col-xl-12 col-lg-12 col-md-12 col-12">
                <form action="<?= base_url("cekilis/baslat") ?>" method="POST" enctype="multipart/form-data">
                    <div class="row">
                        <div class="col-md-9">
                            <div class="col-md-12 p-0"  style="text-align: center">
                                <ul class="home-pro-tabs tabs4" style="padding: 0">
                                    <li data-tab4="populer-urunler" style="width: 100% !important;" class="active">
                                        <div class="row align-items-center gutters-small justify-content-center">
                                            <!--<div class="col-xl-auto col-12"><img src="https://kemalellidort.com.tr/uploads/vitrinler/64c5e53e214cb_trending.png" height="32px" alt=""></div>-->
                                            <div class="col-xl-auto col-12 mt-xl-0 mt-2 pl-lg-0">
                                                <h2 class="dranw-title">Çekiliş Oluştur</h2>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                            <div class="card">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-12 text-center">
                                            <span class="badge badge-warning font-weight-bold" style="font-size: 100%">Lütfen Ürünleri Çekilişi Kazanıcak Kişi Sırasına Göre Sepete Ekleyiniz!!</span>
                                        </div>
                                        <div class="col-md-12 mb-3">
                                            <label for="">Çekiliş Görseli</label>
                                            <input type="file" class="form-control" name="file" placeholder="Çekiliş Görseli" required>
                                        </div>
                                        <div class="col-md-12 mb-3">
                                            <label for="">Çekiliş Adı</label>
                                            <input type="text" class="form-control" name="title" placeholder="Çekiliş Adı" required>
                                        </div>
                                        <div class="col-md-12 mb-3">
                                            <label for="">Çekiliş Türü</label>
                                            <select name="cekilis_turu" id="cekilisturu" class="form-control">
                                                <option value="1">Ürün</option>
                                                <option value="2">Bakiye</option>
                                            </select>
                                        </div>


                                        <div class="col-md-12 mb-3" id="bakiyemiktari" style="display: none;">
                                            <label for="">Bakiye Miktarı</label>
                                            <input type="text" class="form-control" id="bakiyemiktar">
                                            <button type="button" class="btn btn-success mt-2" id="bakiyeekle">Sepete Ekle</button>
                                        </div>


                                        <div class="col-md-6 mb-3" id="urunsecimi">
                                            <label for="">Ürün Seçimi</label>
                                            <select class="urun_id form-control" name="urun_id" id="urun_id">
                                                <?php foreach ($urunler as $urun) : ?>
                                                    <option data-fiyat="<?= $urun->urun_fiyat ?>" value="<?= $urun->urun_id ?>"><?= $urun->urun_ad . ' ' . $urun->urun_fiyat . '₺ - Stok: ' . $urun->urun_stok . ' adet' ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                            <button type="button" class="btn btn-success mt-2" onclick="urunekle(this)" value="urunekle" id="urunekleme">Seçili ürünü sepete ekle</button>
                                        </div>
                                        <div class="col-md-6 mb-3" id="urunmiktari">
                                            <label for="">Ürün Miktarı</label>
                                            <input type="number" class="form-control" name="urun_miktar" id="urun_miktar" min="1" value="1">
                                        </div>
                                        <div class="col-md-12 mb-3">
                                            <label for="">Çekilişi Kazanacak Kişi Sayısı</label>
                                            <input type="text" class="form-control" name="winner_count" value="1" placeholder="Çekilişi Kazanacak Kişi Sayısı" required>
                                        </div>
                                        <div class="col-md-12 mb-3">
                                            <label for="">Çekiliş Açıklaması</label>
                                            <textarea name="aciklama" class="form-control" id="" cols="30" rows="10" required></textarea>
                                        </div>
                                        <div class="col-md-12 mb-3">
                                            <label for="">Çekiliş Bitiş Tarihi</label>
                                            <input type="datetime-local" class="form-control" name="bitis_tarihi" placeholder="Çekiliş Bitiş Tarihi" required>
                                        </div>
                                        <div class="col-md-12">
                                        <button type="submit" class="btn btn-success mt-2">Çekilişi Başlat</button>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="card">
                                <ul class="home-pro-tabs tabs4" style="padding: 0">
                                    <li data-tab4="populer-urunler" style="width: 100% !important;" class="active">
                                        <div class="row align-items-center gutters-small justify-content-center">
                                            <!--<div class="col-xl-auto col-12"><img src="https://kemalellidort.com.tr/uploads/vitrinler/64c5e53e214cb_trending.png" height="32px" alt=""></div>-->
                                            <div class="col-xl-auto col-12 mt-xl-0 mt-2 pl-lg-0">
                                                <h2 class="dranw-title d-flex align-items-center">Ürünler<div class="draw-icon"><img src="<?php echo base_url('assets/images/gift.png') ?>" alt=""></div></h2>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                                <div class="card-body">
                                    <div id="urunler">
                                        <span id="empty_text">Şuanda bir ürün seçilmedi.</span>

                                    </div>
                                    <span id="urun_info" class="badge badge-info" style="font-size: 13px; display: none;">
                                        Toplam ürün sayısı: <span id="urun_sayisi">0</span>

                                    </span>

                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

</div>
<script>
    $('#cekilisturu').change(function() {
        if ($(this).val() == 1) {
            // Ürün aktif etme
            $('#urunsecimi').show();
            $('#urunmiktari').show();
            $('#urunekleme').show();
            // Bakiye gizleme
            $('#bakiyemiktari').hide();
        } else {
            // Ürün gizleme
            $('#urunsecimi').hide();
            $('#urunmiktari').hide();
            $('#urunekleme').hide();
            //Bakiye aktif etme
            $('#bakiyemiktari').show();

        }
    })

    var kazanan = 0;

    function urunekle(target) {
        if (target.value == "urunekle") {
            $('#empty_text').hide();
            $('#urun_info').show();
            var urun_id = $(".urun_id :selected").val();
            var urun_ad = $(".urun_id :selected").text();
            var urun_fiyat = $(".urun_id :selected").data('fiyat');
            var urun_miktar = $('#urun_miktar').val();

            if (urun_miktar == "") {
                urun_miktar = 1;
            }

            var urun_fiyat_toplam = urun_fiyat * urun_miktar;

            if (urun_fiyat_toplam > <?= $kullanici->bakiye ?>) {
                Swal.fire({
                    icon: 'error',
                    title: 'Bakiye Yetersiz',
                    text: 'Bakiyeniz yetersiz olduğu için bu ürünü sepete ekleyemezsiniz.',
                })
                return false;
            }

            /*if ($('.urun_id[data-id="' + urun_id + '"]').length > 0) {
                var urun_miktar = parseInt($('.urun_id[data-id="' + urun_id + '"]').parent().find('.urun_miktar').text().replace('Miktar: ', '')) + parseInt(urun_miktar);
                $('.urun_id[data-id="' + urun_id + '"]').parent().find('.urun_miktar').text('Miktar: ' + urun_miktar);
                $('.urun_id[data-id="' + urun_id + '"]').parent().find('input[name="miktar[]"]').val(urun_miktar);
                $('#urun_sayisi').text(parseInt($('#urun_sayisi').text()) + parseInt(urun_miktar));
                return false;
            } else {*/
                kazanan = kazanan + 1;
                $('#urunler').append(`
                <div class="div">
                    <span class="badge badge-secondary font-weight-bold" style="border-radius:0;width: 100%">Verilecek Kişi: ` + kazanan + `.</span>
                    <div class="alert alert-success d-flex align-items-center" style="border-radius:0">
                        <div>
                            <input type="hidden" name="urunler[]" value="` + urun_id + `">
                            <input type="hidden" class="form-control" name="miktar[]" placeholder="Ürün Miktarı" value="` + urun_miktar + `">
                            <span class="urun_id draw-add-info" style="font-size: 15px;font-weight: 600;" data-id="` + urun_id + `">` + urun_ad + `</span>
                            <br>
                            <span class="urun_miktar">Miktar: ` + urun_miktar + `</span>
                            <br>
                        </div>
                        <button class="btn btn-danger btn-sm" onclick="urunsil(this)" value="urunsil"><i class="fa fa-trash"></i></button>
                    </div>
                </div>
            `);
            /*}*/

            $('#urun_sayisi').text(parseInt($('#urun_sayisi').text()) + 1);

            console.log(urun_id);
        }
    }

    $('#bakiyeekle').click(function() {
        var bakiye = $('#bakiyemiktar').val();
        var toplam_bakiye = parseInt(bakiye);


        $.each($('.bakiye_id'), function(index, value) {
            toplam_bakiye += parseInt($(value).val());
        });

        console.log(toplam_bakiye, "awd");

        if (toplam_bakiye > <?= $kullanici->bakiye ?>) {
            Swal.fire({
                icon: 'error',
                title: 'Oops...',
                html: `Bakiyeniz yetersiz! <br>Mevcut Bakiyeniz: <?= $kullanici->bakiye ?>₺`,
                confirmButtonText: 'Bakiye yükle',
                confirmButtonColor: '#28a745',
                showCancelButton: true,
                cancelButtonText: 'İptal',
                cancelButtonColor: '#dc3545',
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = "<?= base_url('bakiye') ?>"
                }
            })
            return false;
        }

        $('#empty_text').hide();
        $('#urun_info').show();
        kazanan = kazanan + 1;
        $('#urunler').append(`
                <div class="div">
                    <span class="badge badge-secondary font-weight-bold" style="border-radius:0;width: 100%">Verilecek Kişi: ` + kazanan + `.</span>
                    <div class="alert alert-success d-flex align-items-center" style="border-radius:0">
                        <div>
                            <input class="bakiye_id" type="hidden" name="bakiye[]" value="` + bakiye + `">
                            <span class="urun_id" data-bakiye="` + bakiye + `">` + bakiye + `₺ bakiye</span>
                            <br>
                        </div>
                        <button class="btn btn-danger btn-sm ml-3" onclick="urunsil(this)" value="urunsil"><i class="fa fa-trash"></i></button>
                    </div>
                </div>
        `);
        $('#urun_sayisi').text(parseInt($('#urun_sayisi').text()) + 1);
        $('#urun_fiyat').text(parseInt($('#urun_fiyat').text()) + toplam_bakiye);
    });

    function urunsil(target) {
        if (target.value == "urunsil") {
            var urun_id = $(target).parent().find('.urun_id').data('id');
            $(target).parent().parent().remove();
            $('#urun_sayisi').text(parseInt($('#urun_sayisi').text()) - 1);
            console.log(urun_id);
            kazanan = kazanan - 1;
            //eğer ürün sayısı 0 ise empty_text'i göster
            if ($('#urun_sayisi').text() == 0) {
                $('#empty_text').show();
                $('#urun_info').hide();
            }

        }
    }
</script>


<!-- Footer -->

</style>