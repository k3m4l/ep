<!-- Page header -->

<div class="bg-dark py-4 py-lg-15">
    <div class="siyahlik"></div>
    <div class="container">
        <div class="row align-items-center">
            <div class="col-xl-12 col-lg-12 col-md-12 col-12">
                <div class="row">
                    <div class="col-md-12">
                        <div class="row">
                            <div class="card-body">
                                <div class="draw-info-title mb-0">
                                    <!--<h2 class="dranw-title">Aktif Çekilişler</h2>-->
                                    <ul class="home-pro-tabs tabs4 pr-0 pl-0">
                                        <li data-tab4="populer-urunler" style="width: 100% !important;" class="active">
                                            <div class="row align-items-center gutters-small justify-content-center">
                                                <!--<div class="col-xl-auto col-12"><img src="https://kemalellidort.com.tr/uploads/vitrinler/64c5e53e214cb_trending.png" height="32px" alt=""></div>-->
                                                <div class="col-xl-auto col-12 mt-xl-0 mt-2 pl-lg-0">
                                                    <h2 class="dranw-title">Çekiliş Detayları</h2>
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                                <div class="card">
                                    <div class="card-body">
                                        <h3><?= $cekilis->title ?></h3>
                                        <div class="giveaway-modal-info-boxes">
                                            <div class="giveaway-info-box">
                                                <a href="<?= base_url('m/'. $cekilis->magaza->magaza_seo) ?>" title="AztekShop">
                                                    <div class="giveaway-info-user-box">
                                                        <img src="<?= base_url($cekilis->image) ?>">
                                                        <div class="giveaway-info-user">
                                                            <div class="giveaway-user-title">Çekilişi sağlayan</div>
                                                            <div class="giveaway-user-name"><?= $cekilis->magaza->magaza_ad ?></div>
                                                        </div>
                                                    </div>
                                                </a>
                                            </div>
                                            <div class="giveaway-info-box">
                                                <b><?= $cekilis->toplam_fiyat ?><small>₺</small></b> <span>değerinde çekiliş havuzu</span>
                                            </div>
                                            <div class="giveaway-info-box">
                                                <b><?= $cekilis->katilimcisayi ?></b> <span>Katılımcı</span>
                                            </div>
                                            <div class="giveaway-info-box">
                                                <?php if ($cekilis->status == 0) : ?>
                                                    <b>
                                                        <?php

                                                        $startDateTime = new DateTime();

                                                        $endDateTime = new DateTime($cekilis->end_date);

                                                        $interval = $endDateTime->diff($startDateTime);

                                                        $formatString = '';
                                                        if ($interval->y > 0) {
                                                            $formatString .= '%y yıl, ';
                                                        }
                                                        if ($interval->m > 0) {
                                                            $formatString .= '%m ay, ';
                                                        }
                                                        if ($interval->d > 0) {
                                                            $formatString .= '%d gün, ';
                                                        }
                                                        if ($interval->h > 0) {
                                                            $formatString .= '%h saat, ';
                                                        }
                                                        if ($interval->i > 0) {
                                                            $formatString .= '%i dakika, ';
                                                        }
                                                        

                                                        echo rtrim($interval->format($formatString), ', ');


                                                        ?>
                                                    </b> <span>sonra çekiliş sona erecek</span>
                                                <?php else : ?>
                                                    <b>Çekiliş sona erdi</b>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <p></p>
                                        <p>
                                            <?= $cekilis->aciklama ?>
                                        </p>
                                        <p></p>
                                        
                                        <div class="giveaway-prize-data">
                                            <h3 class="mt-2">Çekiliş Ödülleri</h3>
                                            <div class="giveaway-content">

                                                <?php foreach ($cekilis->esyalar as $esya) : ?>

                                                    <div class="giveaway-content-item detail">
                                                        <a ttitle="1 TL İtemsatış Hediye Kartı" style="position:relative; display: block; height: auto;">
                                                            <?php if (isset($esya->bakiyem)) : ?>
                                                                <img src="<?= $esya->urun_resim ?>" title="1 TL Hediye Kartı">
                                                            <?php else : ?>
                                                                <img src="<?= base_url($esya->urun_resim) ?>" title="1 TL Hediye Kartı">
                                                            <?php endif; ?>

                                                            <span style="text-shadow: 0 0 5px #000, 0 0 5px #000; white-space: nowrap; bottom: 0; position: absolute; left: 0; right: 0; background: rgba(0,0,0,0.7); width: 100%; text-align: center;"><?= $esya->urun_fiyat ?> TL</span>

                                                            <span class="giveaway-item-count"><?= $esya->urun_miktar ?> Kişiye</span>
                                                        </a>
                                                    </div>
                                                <?php endforeach; ?>


                                            </div>
                                        </div>


                                        <h3 class="mt-2">Çekilişi Kazananlar</h3>
                                        <?php if ($cekilis->status == 0) : ?>
                                            <div class="text-center error-message" style="padding: 50px 15px;">
                                                <img src="https://cdn.itemsatis.com/uploads/admin/9uCcrafVKiFgJqOwvmnpyDGjt.png" style="width:90px">
                                                <h3>Çekiliş Sonuçlanmadı</h3>
                                                <p>Çekiliş sonuçları henüz açıklanmadı,<br>Sonuçlar açıklandıktan sonra kazananlar burada listelenecek.</p>
                                            </div>
                                        <?php else : ?>
                                            <div class="giveaway-joiner-user-list">
                                                <?php foreach ($cekilis->kazananlar as $row) : ?>
                                                    <div class="giveaway-join-user-box">
                                                        <a href="" title="" class="d-flex" target="_blank">
                                                            <img src="<?= base_url($row->kullanici->kullanici_resim) ?>">
                                                            <div class="giveaway-join-user-data">
                                                                <span class="join-user-name"><?= $row->kullanici->kullanici_ad ?></span>

                                                            </div>
                                                        </a>
                                                    </div>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<!-- Footer -->

</style>