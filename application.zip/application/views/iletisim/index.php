<?php $siteayar = ayarlar(); ?>
<div class="bg-primary bc-custom"  style="background:linear-gradient(0deg, rgb(0 0 0 / 40%), rgb(0 0 0 / 40%)),background-size:cover; background-position: center; background-image:url(assets/front/images/ghostunner.jpg)">
    <div class="bc-head-tt-area">
        <h1 class="bc-head-tt">İletişim</h1>
    </div>
</div>
<section class="py-6">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-md-4">
                <div class="card">
                    <div class="card-body">
                        <h3 class="mt-1 mb-5">Bizimle İletişime Geçin !</h3>
                        <?php if ($siteayar->adres) { ?>
                            <div class="contact-info-item">
                                <h6 class="text-dark contact-custom-info"><i class="mdi mdi-home-map-marker"></i> Adres :</h6>
                                <p><?= $siteayar->adres ?></p>
                            </div>
                        <?php } ?>
                        <?php if ($siteayar->iletisim_sabit) { ?>
                            <div class="contact-info-item">
                                <h6 class="text-dark contact-custom-info"><i class="mdi mdi-phone"></i> Sabit Telefon :</h6>
                                <p><?= $siteayar->iletisim_sabit ?></p>
                            </div>
                        <?php } ?>
                        <?php if ($siteayar->iletisim_tel) { ?>
                            <div class="contact-info-item">
                                <h6 class="text-dark contact-custom-info"><i class="mdi mdi-deskphone"></i> Telefon :</h6>
                                <p><?= $siteayar->iletisim_tel ?></p>
                            </div>
                        <?php } ?>
                        <?php if ($siteayar->iletisim_mail) { ?>
                            <div class="contact-info-item">
                                <h6 class="text-dark contact-custom-info"><i class="mdi mdi-email"></i> E-Posta :</h6>
                                <p><?= $siteayar->iletisim_mail ?></p>
                            </div>
                        <?php } ?>
                    </div>
                </div>
            </div>
            <div class="col-lg-8 col-md-8">
                <div class="card">
                    <div class="card-body">
                        <iframe class="google-maps-frame" src="<?= $siteayar->harita; ?>" width="100%" height="450" frameborder="0"
                                style="border:0" allowfullscreen></iframe>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>