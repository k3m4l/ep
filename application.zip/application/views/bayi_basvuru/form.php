<!DOCTYPE html>
<html lang="tr">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <meta name="description" content="<?php if (!$description) {
                                            echo html_escape($ayarlar->header_aciklama);
                                        } else {
                                            echo html_escape($description);
                                        } ?>">
    <meta name="keywords" content="<?php if (!$keywords) {
                                        echo html_escape($ayarlar->site_keyw);
                                    } else {
                                        echo html_escape($keywords);
                                    } ?>">
    <title><?php if ($title) {
                echo $title . " - " . $ayarlar->header_baslik;
            } else {
                echo $ayarlar->header_baslik;
            } ?></title>
    <meta charset="utf-8">
    <link rel="icon" type="image/png" href="<?= base_url($ayarlar->site_favicon) ?>">
    
</head>
<body>
</body>
</html>
