<main class="mt-5 mb-5">
<div class="container">
    <div class="row align-items-center justify-content-center ">
        <div class="col-12">
            <img class="big-404" src="<?=base_url('assets/front/images/asf.svg')?>" alt="404"/>
        </div>
        <div class="col-12 text-center">
            <h1 class="display-1 mb-3">Oops!</h1>
            <h3>Üzgünüz, aradığınız sayfayı bulamadık.</h3>
            <p class="mb-4 small">Hata Kodu: 404 bulunamadı.</p>
            <a href="<?=base_url()?>" class="btn btn-primary mr-2">Anasayfa'ya Geri Dön</a>
        </div>
    </div>
</div>
</main>