<section class="server-sec mb-3 mb-3">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="pvp-table-warper table-responsive">
                    <table class="server-table">
                        <thead class="server-table-thead">
                            <tr class="server-table-tr">
                                <th class="server-table-th">Server</th>
                                <th class="server-table-th">Durum</th>
                                <th class="server-table-th"> 
                                       Beta Tarihi</th>
                                <th class="server-table-th"> 
                                        Official Tarihi</th>
                                <th class="server-table-th">
                                       Oyun Türü</th>
                                <th class="server-table-th">
                                       Web Sitesi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach (!empty($servers) ? $servers : [] as $key => $val) { ?>
                            <tr>
                                <td class="title">
                                    <a class="server-name" href="">
                                        <img src="<?php echo base_url($val->image) ?>" class="image"
                                            alt=""><?php echo $val->server ?>
                                    </a>
                                </td>
                                <td>
                                    <?php if ($val->server_status == 2) { ?>
                                    <div class="badge-green  rgb-danger-waiting "><span class="rgb-danger c-fff">YAKINDA
                                            <img class="icon-pvp-table"
                                                src="<?php echo base_url('assets/images/game-icon/time.png') ?>  "
                                                loading="lazy">
                                        </span>
                                    </div>
                                    <?php } else { ?>
                                    <div class="badge-green  rgb-danger-waiting">
                                        <span class="c-fff rgb-danger">
                                            ONLİNE <img class="icon-pvp-table k-icon ml-2"
                                                src="https://kemalellidort.com.tr/assets/images/game-icon/check-mark3.png "
                                                loading="lazy">
                                        </span>
                                    </div>
                                    <?php } ?>
                                </td>
                                <td class="date">
                                    <span class="table-title">Beta Tarihi</span>
                                    <span class="text-color hover-fff">
                                        <?php echo !empty($val->beta_tarih) ? $val->beta_tarih : '-' ?>
                                    </span>
                                </td>
                                <td class="date">
                                    <span class="table-title">Official Tarihi</span>
                                    <span class="text-color-dark hover-fff">
                                        <?php echo !empty($val->offical_tarih) ? $val->offical_tarih : '-' ?>
                                    </span>
                                </td>
                                <td>
                                    <span class="table-title"> Oyun Türü</span>
                                    <span class="badge-gradient hover-fff  ">
                                        <span
                                            class="badge bg-warning cs-type"><?php echo $val->oyun_turu ?>
                                        </span>
                                    </span>
                                </td>
                                <td>
                                   <a href="<?php echo $val->link ?>" target="_blank"> <span class=" badge bg-warning cs-type hover-fff">Git</span></a>
                                </td>
                               
                            </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>