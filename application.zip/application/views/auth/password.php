<div class="container py-4 py-lg-5 my-4">

    <div class="row justify-content-center">

        <div class="card border-0 box-shadow">

            <div class="card-body">

                <div class="col-lg-12 col-md-12">

                    <h2 class="h3 mb-4">Şifremi Unuttum?</h2>

                    <p class="font-size-md">Şifrenizi üç kolay adımda değiştirin. Bu, yeni şifrenizi güvende tutmanıza yardımcı olur.</p>

                    <ol class="list-unstyled font-size-md">

                        <li><span class="text-primary mr-2">1.</span>E-posta adresinizi aşağıya girin.</li>

                        <li><span class="text-primary mr-2">2.</span>Size geçici bir bağlantı göndereceğiz.</li>

                        <li><span class="text-primary mr-2">3.</span>Şifrenizi güvenli bir şekilde değiştirmek için geçici bağlantıyı kullanın.</li>

                    </ol>

                    <form class="card-body needs-validation" method="post" action="<?php echo base_url('password-rest'); ?>" novalidate>

                        <div class="form-group">

                            <label for="recover-email">E-posta adresinizi giriniz</label>

                            <input class="form-control" type="email" name="mail" id="recover-email" placeholder="E-posta adresinizi giriniz" required>

                            <div class="invalid-feedback">Lütfen geçerli bir e-posta adresi girin.</div>

                            <?php if (isset($form_error)) { ?> <?=form_error('mail', '<p class="p_error">', '</p>')?> <?php } ?>

                        </div>

                        <div class="g-recaptcha" style="margin-bottom: 10px" data-sitekey="<?php echo $google_key; ?>"></div>

                        <button class="btn btn-primary" type="submit">Yeni Şifre Bağlantısı Gönder</button>

                    </form>

                </div>

            </div>

        </div>

    </div>

</div>