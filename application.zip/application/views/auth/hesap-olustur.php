<div class="container d-flex flex-column">
    <div class="row align-items-center justify-content-center no-gutters min-vh-100">
        <div class="col-lg-5 col-md-8 py-8 py-xl-0">
            
            <div class="card shadow">
                
                <div class="card-body">
                    <div class="mb-4 text-center">
                        <img src="<?= base_url($ayarlar->site_logo) ?>" class="mb-4" alt="Hesap Oluştur">
                        <h1 class="mb-1 font-weight-bold">Hesap Oluştur</h1>
                        <span>
                            Zaten hesabınız var mı?
                            <a href="<?= base_url('giris-yap') ?>" class="ml-1">Giriş Yap</a>
                        </span>
                    </div>
                    <!-- Form -->
                    <form action="<?= base_url('hesap') ?>" method="post">
                        <!-- Username -->
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="ad" class="form-label">Kullanıcı Adı</label>
                                    <input type="text" class="form-control" name="kullaniciadi"
                                           placeholder="kullanıcı adınız.." required/>
                                    <?php echo form_error('ad', '<div class="error_input">', '</div>'); ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="ad" class="form-label">Adınız</label>
                                    <input type="text" class="form-control" name="ad"
                                           placeholder="Adınız.." value="<?= set_value('ad'); ?>" required/>
                                    <?php echo form_error('ad', '<div class="error_input">', '</div>'); ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="soyad" class="form-label">Soyadınız</label>
                                    <input type="text" class="form-control" name="soyad"
                                           placeholder="Soyadınız.." value="<?= set_value('soyad'); ?>" required/>
                                    <?php echo form_error('soyad', '<div class="error_input">', '</div>'); ?>
                                </div>
                            </div>
                        </div>

                        <!-- Email -->
                        <div class="form-group">
                            <label for="email" class="form-label">E-Posta</label>
                            <input type="email" class="form-control" name="mail"
                                   placeholder="E-Posta" value="<?= set_value('mail'); ?>" required/>
                            <?php echo form_error('mail', '<div class="error_input">', '</div>'); ?>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="password" class="form-label">Şifre</label>
                                    <input type="password" class="form-control" name="sifre"
                                           placeholder="**************" required/>
                                    <?php echo form_error('sifre', '<div class="error_input">', '</div>'); ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="password" class="form-label">Şifre Tekrar</label>
                                    <input type="password" class="form-control" name="sifretekrar"
                                           placeholder="**************" required/>
                                </div>
                            </div>
                        </div>

                        <!-- Checkbox -->
                        <div class="form-group">
                            <div class="custom-control custom-checkbox">
                                <input type="checkbox" class="custom-control-input" id="agreeCheck" required/>
                                <label class="custom-control-label" for="agreeCheck">
                                    <a href="<?=$ayarlar->hizmet_sozlesmesi; ?>">Üyelik Sözleşmesi</a> ve <a href="<?=$ayarlar->hizmet_kosulu; ?>">Gizlilik
                                        Politikasını</a> kabul ediyorum.
                                </label>
                            </div>
                        </div>
                        <div class="g-recaptcha" style="margin-top: 10px; margin-bottom: 10px;"
                             data-sitekey="<?php echo $ayarlar->google_key; ?>" data-theme="dark">
                        </div>
                        <div>
                            <button type="submit" class="btn btn-primary btn-block">
                                Hesap Oluştur
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>