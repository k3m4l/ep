<div class="landing">
    <div class="landing-decoration"></div>
    <div class="landing-info">
        <h2 class="landing-info-pretitle"></h2>
        <div class="text-center">
            <img src="<?php echo base_url($ayarlar->site_logo) ?>" class="landing-info-logo">
        </div>
        <p class="landing-info-text"><?php echo $ayarlar->sifremi_unuttum_yazi ?></p>
    </div>
    <div class="landing-form">
        <div class="form-box login-register-form-element" style="">
            <img class="form-box-decoration overflowing" src="<?php echo base_url('assets/images/') ?>rocket.png"
                 alt="rocket">
            <h2 class="form-box-title">Yeni Şifre</h2>
            <?php echo form_open(base_url() . 'sifre-yenile-post', array('class' => 'needs-validation form', 'id' => 'login')); ?>
                a<input type="hidden" name="tkn" value="<?php echo $token; ?>">
                <div class="form-row">
                    <div class="form-item">
                        <div class="form-input login-register-form">
                            <label for="password">Yeni Şifre</label>
                            <input type="password" id="password" name="password" required="">
                        </div>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-item">
                        <div class="form-input login-register-form">
                            <label for="repassword">Yeni Şifre Tekrarla</label>
                            <input type="password" id="repassword" name="repassword" required="">
                        </div>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-item">
                        <button type="submit" class="button medium secondary w-100">Sıfırla</button>
                    </div>
                </div>
            <?php echo form_close(); ?>
        </div>
    </div>
</div>
<script src="<?php echo base_url('assets/front/js/app.bundle.min.js') ?>"></script>
