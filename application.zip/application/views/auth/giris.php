<div class="container d-flex flex-column">
    <div class="row align-items-center justify-content-center no-gutters min-vh-100">
        <div class="col-lg-5 col-md-8 py-8 py-xl-0">
            
            <div class="card shadow ">
                
                <div class="card-body">
                    <div class="mb-4 text-center">
                        <img src="<?= base_url($ayarlar->site_logo) ?>" class="mb-4" alt="Giriş Yap">
                        <h1 class="mb-1 font-weight-bold">Giriş Yap</h1>
                        <span>Hesabın yok mu? <a href="<?= base_url('hesap-olustur') ?>" class="ml-1">Hesap Oluştur</a></span>
                    </div>
                    <!-- Form -->
                    <form action="<?= base_url('girisyap') ?>" method="post">
                        <!-- Username -->
                        <div class="form-group">
                            <label for="text" class="form-label">Kullanıcı Adı</label>
                            <input type="text" class="form-control" name="username" placeholder="Kullanıcı Adınız" required>
                        </div>
                        <!-- Password -->
                        <div class="form-group">
                            <label for="password" class="form-label">Şifre</label>
                            <input type="password" class="form-control" name="password" placeholder="**************" required>
                        </div>
                        <!-- Checkbox -->
                        <div class="d-lg-flex justify-content-between align-items-center mb-4">
                            <!-- <div class="custom-control custom-checkbox">
                                <input type="checkbox" class="custom-control-input" name="beni_hatirla" id="rememberme">
                                <label class="custom-control-label " for="rememberme">Beni Hatırla</label>
                            </div> -->
                            <div>
                                <a href="<?= base_url('sifremi-unuttum') ?>">Şifremi Unuttum?</a>
                            </div>
                        </div>
                        <div>
                            <!-- Button -->
                            <button type="submit" class="btn btn-primary btn-block">Giriş Yap</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>