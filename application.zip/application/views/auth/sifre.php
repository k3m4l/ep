<div class="container py-4 py-lg-5 my-4 mb-20 mt-20">

    <div class="row justify-content-center">

        <div class="card border-0 box-shadow">

            <div class="card-body">

                <div class="col-lg-12 col-md-12">

                    <h2 class="h3 mb-4">Şifre Yenile</h2>

                    <?php echo form_open(base_url() . 'sifre-yenile-post', array('class' => 'needs-validation', 'id' => 'login')); ?>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">

                                <label for="recover-email">Yeni Şifre</label>

                                <input class="form-control prepended-form-control" name="password" type="password"
                                       placeholder="Yeni Şifre" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">

                                <label for="recover-email">Yeni Şifre Tekrarla</label>

                                <input class="form-control prepended-form-control" name="repassword" type="password"
                                       placeholder="Yeni Şifre Tekrar" required>
                            </div>
                        </div>
                    </div>

                    <input type="hidden" name="tkn" value="<?php echo $token; ?>">
                    <button class="btn btn-primary" type="submit">Şifre Yenile</button>

                    <?php echo form_close(); ?>

                </div>

            </div>

        </div>

    </div>

</div>