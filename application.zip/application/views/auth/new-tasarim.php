<div class="landing">
    <div class="landing-decoration"></div>
    <div class="landing-info">
        <h2 class="landing-info-pretitle"></h2>
        <div class="text-center">
            <img src="<?php echo base_url($ayarlar->site_logo) ?>" class="landing-info-logo">
        </div>
        <p class="landing-info-text"><?php echo $ayarlar->giris_yazi ?></p>
        <div class="tab-switch">
            <p class="tab-switch-button login-register-form-trigger" id="giris-yap"
               data-url="https://kemalellidort.com.tr/giris-yap">
                Giriş Yap</p>
            <p class="tab-switch-button login-register-form-trigger" id="hesap-olustur"
               data-url="https://kemalellidort.com.tr/hesap-olustur">
                Kayıt Ol</p>
        </div>
    </div>
    <div class="landing-form">
        <div class="form-box login-register-form-element" style="">
            <img class="form-box-decoration overflowing" src="<?php echo base_url('assets/images/') ?>rocket.png"
                 alt="rocket">
            <h2 class="form-box-title">Giriş Yap</h2>
            <form action="<?= base_url('girisyap') ?>" method="post" class="form">
                <div class="form-row">
                    <div class="form-item">
                        <div class="form-input login-register-form">
                            <label for="email">Kullanıcı Adınız Veya E-Posta Adresiniz</label>
                            <input type="text" id="username" name="username" required="">
                        </div>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-item">
                        <div class="form-input login-register-form">
                            <label for="password">Şifre</label>
                            <input type="password" id="password" name="password" required="">
                        </div>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-item">
                        <div class="g-recaptcha" style="margin-top: 10px; margin-bottom: 10px;"
                             data-sitekey="<?php echo $ayarlar->google_key; ?>">
                        </div>
                    </div>
                </div>
                <div class="form-row space-between">
                    <div class="form-item">
                        <div class="checkbox-wrap">
                            <input type="checkbox" id="login-remember" name="login_remember" checked=""
                                   style="display: none">
                            <div class="checkbox-box">
                                <i class="fas fa-check"></i>
                            </div>
                            <label for="login-remember">Beni Hatırla</label>
                        </div>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-item">
                        <button type="submit" class="button medium secondary w-100">Giriş Yap</button>
                    </div>
                </div>
            </form>
            <p class="form-text login-register-form-text">Şifrenizi unuttuysanız <a href="<?php echo base_url('sifremi-unuttum') ?>">buradan</a> şifrenizi
                sıfırlayabilirsiniz.</p>
        </div>
        <div class="form-box login-register-form-element" style="">
            <img class="form-box-decoration" src="<?php echo base_url('assets/images/') ?>rocket.png" alt="rocket">
            <h2 class="form-box-title">Kayıt Ol</h2>
            <form action="<?= base_url('hesap') ?>" method="post" class="form">
                <div class="form-row">
                    <div class="form-item">
                        <div class="form-input login-register-form">
                            <label for="phone">Kullanıcı Adınız</label>
                            <input type="text" name="kullaniciadi" required="">
                        </div>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-item">
                        <div class="form-input login-register-form">
                            <label for="full_name">Adınız</label>
                            <input type="text" id="full_name" name="ad" required="">
                        </div>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-item">
                        <div class="form-input login-register-form">
                            <label for="full_name">Soyadınız</label>
                            <input type="text" id="full_name" name="soyad" required="">
                        </div>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-item">
                        <div class="form-input login-register-form">
                            <label for="email">Email</label>
                            <input type="text" id="email" name="mail" required="">
                        </div>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-item">
                        <div class="form-input login-register-form">
                            <label for="password">Şifre</label>
                            <input type="password" id="password" name="sifre" required="">
                        </div>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-item">
                        <div class="form-input login-register-form">
                            <label for="password_confirmation">Şifre Tekrar</label>
                            <input type="password" id="password_confirmation" name="sifretekrar" required="">
                        </div>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-item">
                        <div class="g-recaptcha"
                             data-sitekey="<?php echo $ayarlar->google_key; ?>">
                        </div>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-item">
                        <button type="submit" class="button medium primary">Kayıt Ol</button>
                    </div>
                </div>
                <script>
                    function validateInput() {
                        var input = document.getElementById("phone").value;

                        if (input.length < 10) {
                            swal("Uyarı!", "Lütfen geçerli bir telefon numarası giriniz. (5XXXXXXXXX).", "warning");
                            return false;
                        }

                        if (input.charAt(0) !== '5') {
                            swal("Uyarı!", "Lütfen geçerli bir telefon numarası giriniz. (5XXXXXXXXX)", "warning");
                            return false;
                        }

                        return true;
                    }
                </script>
            </form>
            <p class="form-text login-register-form-text">Kayıt olarak <a href="<?= $ayarlar->hizmet_sozlesmesi; ?>"
                                                                          target="_blank">Üyelik Sözleşmesini</a> ve <a
                    href="<?= $ayarlar->hizmet_kosulu; ?>">Gizlilik sözleşmesini</a> okumuş ve kabul etmiş sayılırsınız.
            </p>
        </div>
    </div>
</div>
<script src="<?php echo base_url('assets/front/js/app.bundle.min.js') ?>"></script>
<script>
    var site_url = "<?php echo base_url(); ?>";
    $('.login-register-form input').click(function () {
        $(this).closest('.login-register-form').find('label').addClass('active');
    })
    $('.login-register-form input').on('blur', function () {
        if ($(this).val().trim() === '') {
            $(this).closest('.login-register-form').find('label').removeClass('active');
        }
    });
    $('.tab-switch .login-register-form-trigger').click(function () {
        var pageurl = $(this).data('url')
        if (pageurl != window.location) {
            window.history.pushState({path: pageurl}, '', pageurl);
        }
    })
    var url = window.location.href
    $(document).ready(function () {
        if (url == site_url + 'hesap-olustur') {
            $('#hesap-olustur').click()
        }
    })
</script>