<div class="landing">
    <div class="landing-decoration"></div>
    <div class="landing-info">
        <h2 class="landing-info-pretitle"></h2>
        <div class="text-center">
            <img src="<?php echo base_url($ayarlar->site_logo) ?>" class="landing-info-logo">
        </div>
        <p class="landing-info-text"><?php echo $ayarlar->sifremi_unuttum_yazi ?></p>
    </div>
    <div class="landing-form">
        <div class="form-box login-register-form-element" style="">
            <img class="form-box-decoration overflowing" src="<?php echo base_url('assets/images/') ?>rocket.png"
                 alt="rocket">
            <h2 class="form-box-title">Şifre Sıfırla</h2>
            <form action="<?= base_url('password-rest') ?>" method="post" class="form">
                <div class="form-row">
                    <div class="form-item">
                        <div class="form-input login-register-form">
                            <label for="email">E-Posta Adresiniz</label>
                            <input type="text" id="email" name="mail" required="">
                        </div>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-item">
                        <div class="g-recaptcha" style="margin-top: 10px; margin-bottom: 10px;"
                             data-sitekey="<?php echo $ayarlar->google_key; ?>">
                        </div>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-item">
                        <button type="submit" class="button medium secondary w-100">Gönder</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<script src="<?php echo base_url('assets/front/js/app.bundle.min.js') ?>"></script>
