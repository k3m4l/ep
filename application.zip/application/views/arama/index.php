<?php $ayarlar = ayarlar(); ?>
<?php $kullanici = kullanicicek(); ?>

<div id="titlebar" class="gradient">
	<div class="container">
		<div class="row">
			<div class="col-md-12">

				<h2>Arama</h2><span><?php if (isset($aranan)) { echo "Aranan : ".$aranan; }else{ echo "Sonucu"; } ?></span>

				<!-- Breadcrumbs -->
				<nav id="breadcrumbs">
					<ul>
						<li><a href="<?=base_url()?>">Anasayfa</a></li>
						<li>Arama Sonucu</li>
					</ul>
				</nav>

			</div>
		</div>
	</div>
</div>

<div class="container">
	<div class="row">
		<!-- Search -->
		<div class="col-md-12">
			<form method="post" action="<?=base_url('arama')?>">
				<div class="main-search-input gray-style margin-top-0 margin-bottom-10">
					<div class="main-search-input-item">
						<input type="text" placeholder="Ne arıyorsun?" name="kelime" value=""/>
					</div>

					<div class="main-search-input-item">
						<select data-placeholder="Tüm Kategoriler" name="cat" class="chosen-select" >
							<option value="">Tüm Kategoriler</option>
							<?php $kategoriler = kategoricek(); ?>
							<?php foreach ($kategoriler as $key) { ?>
								<option value="<?=$key->kategori_ad?>"><?=$key->kategori_ad?></option>
							<?php } ?>
						</select>
					</div>

					<button type="submit" class="button">Arama Yap</button>
				</div>
			</form>
		</div>
		<!-- Search Section / End -->


		<div class="col-md-12">

			<div class="row">
				<div class="margin-bottom-30"></div>

				<?php if (!$where) { ?>
					<div class="notification warning text-center" role="alert">
						Aradığınız Ürün Bulunamadı
					</div>
				<?php }else{ ?>
					<div class="row">
						<?php foreach ($where as $key) { ?>
							<?php $yorumpuan = yorumpsay($key->firma_id); ?>

							<div class="col-lg-4 col-md-12">
								<a href="<?=base_url("firma/".$key->firma_seo)?>" class="listing-item-container">
								<div class="listing-item">
									<img src="<?=base_url($key->firma_resim)?>" alt="<?=$key->firma_ad?>">

									<?php if ($key->firma_populer==1) { echo '<div class="listing-badge now-open">Popüler</div>'; } ?>
									<div class="listing-item-content">
										<span class="tag"><?=$key->kategori_ad?></span>
										<h3><?=$key->firma_ad?> <?php if ($key->firma_dogrulama==1) { echo '<i class="verified-icon"></i>'; } ?></h3>
										<span><?=$key->firma_adres?></span>
									</div>
									<?php if (aktif_kullanici()) { ?>
										<span class="item-favorite-button item-favorite-enable like-icon <?php if(favoriekle($kullanici->kullanici_id, $key->firma_id) == true){ echo "liked"; } ?>" data-product-id="<?=$key->firma_id; ?>"></span>
									<?php }else{ ?>
										<span class="like-icon"></span>
									<?php } ?>
								</div>
								<div class="star-rating" data-rating="<?=$yorumpuan->yorum_puan?>">
									<div class="rating-counter">(<?php echo yorumsaydir($key->firma_id); ?> yorum)</div>
								</div>
							</a>
						</div>
						<?php } ?>
					</div>
				<?php } ?>

			</div>

		</div>
	</div>
</div>


