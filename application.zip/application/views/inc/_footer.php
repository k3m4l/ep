<?php $ayarlar = ayarlar();
$sayfalar = footersayfa(); ?>
<div class="footer bd-cr  <?php echo empty($none) ? '' : $none; ?>">
    <div class="container">
        <hr class="mt-0 mb-4" style="background:#b3c8ff;">
        <div class="row justify-content-center ">
            <div class="col-lg-3 col-12 border-right-1">
                <div class="mb-4 ">
                    <img src="<?= base_url($ayarlar->site_darklogo) ?>" alt="footer_logo" style="width: 200px;" class="footer_logo" width="200"
                         height="64"/>

                    <div class="contact-warper">
                     <span class="d-flex text-center align-items-center mb-2">
                            <i class="fas fa-map-marker-alt font-size-19"></i>
                            <div class="d-flex flex-column ml-3">
                                <p class="font-weight-bold m-0 tl-pull font-size-12"><?= $ayarlar->footer_aciklama ?></p>
                                    <?php if ($ayarlar->adres) { ?>
                                        <p class="font-size-12"><?= $ayarlar->adres ?></p> <?php } ?>
                            </div>
                    </span>
                        <?php if ($ayarlar->iletisim_tel) { ?>
                        <span class="d-flex text-center align-items-center mb-2">
                                <div class="contact-2">
                                    <i class="fas fa-phone mr-2 font-size-19" aria-hidden="true"></i>
                                    <div class="d-flex flex-column">
                                        <a href="tel:<?= $ayarlar->iletisim_tel ?>" title="<?= $ayarlar->iletisim_tel ?>"
                                           class="m-0 font-size-15 l-color text-dark"><span><?= $ayarlar->iletisim_tel ?></span></a>
                                        <small style="color: rgb(159 203 173);margin-top: -5px">Yalnızca WhatsApp</small>
                                    </div>
                                </div>
                            <?php } ?>

                            </span>
                        <?php if ($ayarlar->iletisim_mail) { ?>
                            <a href="mailto:<?= $ayarlar->iletisim_mail ?>" class="mb-3 l-color" title="Mail Adresimiz">
                                <i class="fas fa-envelope-open-text font-size-19 mr-2" aria-hidden="true"></i>
                                <span class="font-size-15"><?= $ayarlar->iletisim_mail ?></span>
                            </a>
                        <?php } ?>
                        <div class="font-size-md mt-4">
                            <a href="<?= $ayarlar->facebook ?>" class="mdi mdi-facebook text-muted mr-2" title="Facebook"
                               style="font-size: 30px"></a>
                            <a href="<?= $ayarlar->twitter ?>" class="mdi mdi-twitter text-muted mr-2" title="Twitter"
                               style="font-size: 30px"></a>
                            <a href="<?= $ayarlar->instagram ?>" class="mdi mdi-instagram text-muted mr-2" title="Instagram"
                               style="font-size: 30px"></a>
                            <a href="<?= $ayarlar->discord ?>" class="mdi mdi-discord text-muted" title="Discord"
                               style="font-size: 30px"></a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-2 col-md-3 col-6">
                <div class="mb-4">
                    <span class="font-weight-bold l-color mb-3 c-custom">Hızlı Sayfalar</span>
                    <ul class="list-unstyled nav nav-footer flex-column nav-x-0">
                        <?php foreach (footermenusayfa(2) as $item) { ?>
                            <?php if ($item->sayfa_tur == 0) { ?>
                                <li><a class="nav-link p-0 font-size-12" title="<?= $item->sayfa_ad ?>"
                                       href="<?= base_url('sayfa/' . $item->sayfa_seo) ?>"><?= $item->sayfa_ad ?></a>
                                </li>
                            <?php } else { ?>
                                <li><a class="nav-link p-0 font-size-12" title="<?= $item->sayfa_ad ?>"
                                       href="<?= $item->sayfa_url ?>"><?= $item->sayfa_ad ?></a></li>
                            <?php } ?>
                        <?php } ?>
                        <li><a title="İletişim" class="nav-link p-0 font-size-12" href="<?= base_url('iletisim') ?>">İletişim</a></li>
                        <li><a title="S.S.S" class="nav-link p-0 font-size-12" href="<?= base_url('sss') ?>">S.S.S</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-2 col-md-3 col-6">
                <div class="mb-4">
                    <span class="font-weight-bold l-color mb-3 c-custom">Sözleşmeler</span>
                    <ul class="list-unstyled nav nav-footer flex-column nav-x-0">
                        <?php foreach (footermenusayfa(3) as $item) { ?>
                            <li><a class="nav-link p-0 font-size-12" title="<?= $item->sayfa_ad ?>"
                                   href="<?= base_url('sayfa/' . $item->sayfa_seo) ?>"><?= $item->sayfa_ad ?></a></li>
                        <?php } ?>
                    </ul>
                </div>
            </div>
            <div class="col-lg-2 col-md-3 col-6">
                <div class="mb-4">
                    <span class="font-weight-bold l-color mb-3 c-custom">Popüler Kategoriler</span>
                    <ul class="list-unstyled nav nav-footer flex-column nav-x-0">
                        <?php foreach (populer_kategoriler() as $item) { ?>
                            <li><a href="<?= base_url("kategori/" . $item->kategori_seo) ?>" title="<?= $item->kategori_ad ?>"
                                   class="nav-link p-0 font-size-12"><?= $item->kategori_ad ?></a></li>
                        <?php } ?>
                    </ul>

                </div>
            </div>
            <div class="col-lg-2 col-md-3 col-6">
                <div class="mb-4">
                    <ul class="list-unstyled nav nav-footer flex-column nav-x-0">
                        <?php foreach (populer_kategoriler_two() as $item) { ?>
                            <li><a href="<?= base_url("kategori/" . $item->kategori_seo) ?>" title="<?= $item->kategori_ad ?>"
                                   class="nav-link p-0 font-size-12"><?= $item->kategori_ad ?></a></li>
                        <?php } ?>
                    </ul>

                </div>
            </div>

            <div class="col-md-12 text-center mt-5">
                <ul class="list-unstyled nav nav-footer nav-x-0 footer-menu justify-content-center">
                    <?php if ($sayfalar) {
                        foreach ($sayfalar as $sayfa) { ?>
                            <?php if ($sayfa->sayfa_tur == 0) { ?>
                                <li><a class="nav-link text-black-50 pl-0 mr-2 font-size-12" title="<?= $sayfa->sayfa_ad ?>"
                                       href="<?= base_url('sayfa/' . $sayfa->sayfa_seo) ?>"><?= $sayfa->sayfa_ad ?></a>
                                </li>
                            <?php } else { ?>
                                <li><a class="nav-link text-black-50 pl-0 mr-2 font-size-12" title="<?= $sayfa->sayfa_ad ?>"
                                       href="<?= $sayfa->sayfa_url ?>"><?= $sayfa->sayfa_ad ?></a></li>
                            <?php } ?>

                        <?php }
                    } ?>
                </ul>
            </div>
        </div>

        <div class="row align-items-center justify-content-center g-0  py-2 ">
            <div class="col-lg-4 col-md-5 col-12 text-center">
                <span><?= $ayarlar->copyright ?></span>
            </div>
        </div>
        <div class="row align-items-center g-0 py-2 ">
            <div class="col-12">
                <p class="text-center font-size-11 m-0"><?= $ayarlar->footer_uyari ?></p>
            </div>
        </div>
    </div>
</div>
<script src="https://www.googletagmanager.com/gtag/js?id=G-HQ4FDDV0G2" defer></script>
<script>
    function loadGoogleAnalytics() {
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }

        gtag('js', new Date());

        gtag('config', 'G-HQ4FDDV0G2');
    }

    window.addEventListener('load', loadGoogleAnalytics);
</script>
<script src="<?= base_url('assets/front/') ?>libs/bootstrap/dist/js/bootstrap.bundle.min.js" async></script>
<script src="<?= base_url('assets') ?>/js/bootstrap.bundle.min.js" async></script>
<script src="<?= base_url('assets/front/') ?>libs/odometer/odometer.min.js" async></script>
<script src="<?= base_url('assets/front/') ?>libs/inputmask/dist/jquery.inputmask.min.js"></script>
<script src="<?= base_url('assets/front/') ?>libs/inputmask/dist/jquery.mask.js"></script>

<script src="<?= base_url('assets/front/') ?>libs/owl/owl.carousel.min.js"></script>
<script src="<?= base_url("assets/js/iziToast.min.js") ?>"></script>
<script src='https://www.google.com/recaptcha/api.js' defer></script>
<script src="<?= base_url('assets/front/') ?>js/image-uploader.min.js"></script>
<?php if (empty($this->uri->segment(1))) { ?>
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            var tabButtons = document.querySelectorAll('.taby-btn');
            var tabContents = document.querySelectorAll('.tb-content');
            tabContents[0].classList.add('active');
            for (var i = 1; i < tabContents.length; i++) {
                tabContents[i].classList.remove('active');
            }
            tabButtons.forEach(function (button) {
                button.addEventListener('click', function () {
                    var targetId = this.getAttribute('data-tb-id');
                    tabContents.forEach(function (content) {
                        content.classList.remove('active');
                    });
                    var targetContent = document.querySelector(targetId);
                    targetContent.classList.add('active');
                });
            });
        });

        document.addEventListener('DOMContentLoaded', function () {
            var tabs = document.querySelectorAll('.taby-btn');

            tabs.forEach(function (tab) {
                tab.addEventListener('click', function () {
                    tabs.forEach(function (tab) {
                        tab.classList.remove('active');
                    });
                    this.classList.add('active');
                });
            });
        });

        document.addEventListener("DOMContentLoaded", function () {
            var tabButtons2 = document.querySelectorAll('.taby-btn2');
            var tabContents2 = document.querySelectorAll('.tab-secp');

            tabContents2[0].classList.add('active');
            for (var i = 1; i < tabContents2.length; i++) {
                tabContents2[i].classList.remove('active');
            }
            tabButtons2.forEach(function (button) {
                button.addEventListener('click', function () {
                    var targetIds = this.getAttribute('data-tb2-id');
                    tabContents2.forEach(function (content) {
                        content.classList.remove('active');
                    });
                    var targetContents = document.querySelector(targetIds);
                    targetContents.classList.add('active');
                });
            });
        });

        document.addEventListener('DOMContentLoaded', function () {
            var tabs = document.querySelectorAll('.taby-btn2');
            tabs.forEach(function (tab) {
                tab.addEventListener('click', function () {
                    tabs.forEach(function (tab) {
                        tab.classList.remove('active');
                    });
                    this.classList.add('active');
                });
            });
        });
    </script>
<?php } ?>
<?php if ($this->uri->segment(1) == 'ilan-ekle' || $this->uri->segment(1) == 'ilan-duzenle') { ?>
    <script src="<?= base_url('assets/front/') ?>libs/ckeditor/ckeditor.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js"
            integrity="sha512-2ImtlRlf2VVmiGZsjm9bEyhjGW4dU7B6TNwh/hx/iSByxNENtj3WVE6o/9Lj4TJeVXPi4bnOIMXFIJJAeufa0A=="
            crossorigin="anonymous"></script>
    <script>
        $('#mult-cat').select2({
            placeholder: 'Kategori seçiniz (çoklu seçim yapılabilir)',
            allowClear: true,
            closeOnSelect: false
        });
        $('.kategori').select2({
            placeholder: "Lütfen Kategori Seçin",
            allowClear: true
        });
        var myURL = new URL(window.location.href);
        var path = myURL.pathname;

        if (path == 'ilan-ekle') {
            $(window).on('load', function () {
                CKEDITOR.replace('urun_detay');
            });
        }

        $("body").on("keyup", "#IlanIcerigi", function () {
            var value = $(this).text();
            $("#IcerikInput").val(value);
        });

        $(document).ready(function () {
            <?php if(isset($_POST['category_1'])) { ?>
            $('#cat_link_<?=$_POST['category_1']; ?>').trigger("click");
            $("input[name='category_1']").val("<?=$_POST['category_1']; ?>");
            $("input[name='category_2']").val("<?=$_POST['category_2']; ?>");
            <?php  } ?>
            <?php if ($this->uri->segment(1) == 'ilan-ekle' || $this->uri->segment(1) == 'ilan-duzenle') { ?>
            CKEDITOR.addCss('.cke_editable { background-color: #2a3147!important; color: white }');
            <?php } ?>
            $("input[name=postType]").on("change", function (event) {
                if ($(this).val() == "KEY") {
                    $(".alimIlaniGizle").fadeIn();
                    $(".stokluIlan").fadeIn();
                    $(".stokluGizle").fadeOut();
                    $(".alimIlani").fadeOut();
                } else if ($(this).val() == "REQUEST") {
                    $(".alimIlani").fadeIn();
                    $(".stokluIlan").fadeOut();
                    $(".stokluGizle").fadeOut();
                    $(".alimIlaniGizle").fadeOut();
                } else {
                    $(".alimIlaniGizle").fadeIn();
                    $(".stokluIlan").fadeOut();
                    $(".stokluGizle").fadeIn();
                    $(".alimIlani").fadeOut();
                }
            });

            //$(".ui.radio.checkbox").checkbox();

        });

        $("body").on("keyup", ".category-search-input", function () {
            var value = $(this).val().toLowerCase();
            $(".layer-items-" + $(this).data("layer") + " .category-item").filter(
                function () {
                    $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1);
                }
            );
        });

        $("body").on('change', '.category-layer-input', function () {
            pageLoading();
            $(".step-2-btn").prop("disabled", true);
            var $el = $(this);
            var layerID = $el.data("layer");
            var layerIDPlus = layerID + 1;
            for (var fakeID = layerID + 1; fakeID < 10; fakeID++) {
                $("[data-category-layer=" + fakeID + "]").remove();
            }
            $.post(
                "api/getCategory",
                "Id=" + $el.val(),
                function (data) {
                    pageLoaded();
                    var items = [];
                    var data = JSON.parse(data);
                    $(".ilan-ozel-kurallari").html(" ");
                    if (data.success == true) {
                        $("[data-category-layer=" + layerID + "]").after('<div class="field category-layer category-selector" data-category-layer="' + layerIDPlus + '" style="display: none;">\n' + '<div class="ui vertical menu">' + '<div class="ui mini icon input">\n' + '<input type="text" placeholder="Filtreleme yapın..." class="category-search-input" data-layer="' + layerIDPlus + '">\n' + '<i class="search icons fas fa-search" style="margin-left:-19px!important"></i>\n' + "</div>\n" + '<input type="hidden" class="category-layer-input" name="category_' + layerIDPlus + '" data-layer="' + layerIDPlus + '" onchange="layerCategoryChange(this)">\n' + '<div class="list-categories-scroll layer-items-' + layerIDPlus + '">\n' + "</div>\n" + "</div>");
                        $.each(data.results, function (key, val) {
                            <?php if(isset($_POST['category_2'])) { ?>
                            if (val.value == <?=trim($_POST['category_2']); ?>) {
                                items.push('<div class="item category-item cat_link active" onclick="alt_categorySelect(this)" data-layer-value="' + layerIDPlus + '" data-value="' + val.value + '" id="alt_cat_link_' + val.value + '"><img src="https://kemalellidort.com.tr/' + val.image + '">' + val.text + "</div>");
                            }
                            <?php } else { ?>
                            items.push('<div class="item category-item cat_link" onclick="alt_categorySelect(this)" data-layer-value="' + layerIDPlus + '" data-value="' + val.value + '" id="alt_cat_link_' + val.value + '"><img src="https://kemalellidort.com.tr/' + val.image + '">' + val.text + "</div>");
                            <?php } ?>
                        });
                        $("[data-category-layer=" + layerIDPlus + "] .list-categories-scroll").html(items.join(""));
                        $("[data-category-layer=" + layerIDPlus + "]").fadeIn();
                    } else if (data.advert) {
                        layerTypesChange(inputdata);
                    }
                    if (data.contract !== false) {
                        $(".ilan-ozel-kurallari").html('<div class="ozel-kural-text">' + data.contract + "</div>");
                    }
                }
            );

        });

        $('.cat_link').on('click', function () {
            var $el = $(this);
            pageLoading();
            $(".field.category-layer.category-selector[data-category-layer=" + $el.data("layer-value") + "] .item.category-item").removeClass("active");
            $el.addClass("active");
            DataCategory[$el.data("layer-value")] = $el.text();
            $("input[name=category_" + $el.data("layer-value") + "]").val($el.data("value"));
            $("input[name=category_" + $el.data("layer-value") + "]").trigger("change");
            var categoryID = $el.data("value");
            if (categoryID > 0) {
                $.ajax({
                    type: "POST",
                    url: "api/categoryDefaultImages",
                    data: "category=" + categoryID,
                    success: function (data) {
                        data = JSON.parse(data);
                        if (data.success) {
                            $(".eight.wide.column.modal-login-left form").html(" ");
                            $(data.image).each(
                                function (index, value) {
                                    $(".eight.wide.column.modal-login-left form").append('<input type="radio" name="defaultResim" id="defaultResim_' + index + '" class="input-hidden" value="' + value + '"><label class="selectImageLabel" for="defaultResim_' + index + '"><img src="https://cdn.itempazar.com/' + value + '"></label>');
                                });
                            CONST_komisyonOran = data.comission;
                            $(".define-comission").text(data.comission);
                            $("input[name=IlanUcreti]").trigger("keyup");
                            if (data.requestPost) {
                                $(".alimIlaniType").css("display", "inline-block");
                            } else {
                                $(".alimIlaniType").css("display", "none");
                            }
                            $("select[name=IlanTeslimati]").html("");
                            $.each(data.deliveryTimes, function (key, val) {
                                $("select[name=IlanTeslimati]").append('<option value="' + key + '">' + val + '</option>');
                            });
                            pageLoaded();
                        }
                    }
                });
            }

        });

        var DataCategory = [];

        function makeRandom(length) {
            var result = "";
            var characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
            var charactersLength = characters.length;
            for (var i = 0; i < length; i++) {
                result += characters.charAt(Math.floor(Math.random() * charactersLength));
            }
            return result;
        }

        function alt_categorySelect(divdata) {
            var typeID = $(divdata).data("value");
            $("input[name=category_2]").val(typeID);
            $(".field.category-layer.category-selector[data-category-layer=" + $(divdata).data("layer-value") + "] .item.category-item").removeClass("active");
            $(divdata).addClass("active");
            DataCategory[$(divdata).data("layer-value")] = $(divdata).text();
            $("input[name=type]").val($(divdata).data("value"));
            $("input[name=type]").trigger("change");
            $(".step-2-btn").prop("disabled", false);
            $(".step-2-btn").trigger("click");
            pageLoading();
            $("#IlanDetaylari").removeClass("active");
            $.post("api/getTypeDetail", "Id=" + typeID, function (data) {
                    pageLoaded();
                    var data = JSON.parse(data);
                    if (data.success == true) {
                        if (data.Details.length > 0) {
                            var tempHTML = '';
                            tempHTML += '<option>Lütfen Filtre Seçiniz</option>';
                            $.each(data.Details, function (key, value) {
                                tempHTML += '<option value="' + value.filtre_id + '">' + value.filtre_adi + '</option>';
                            });
                            $("#filtre-select").html(tempHTML);
                        } else {
                            $("#filtre-select").html('<option>Lütfen Filtre Seçiniz</option>');
                        }
                    }
                }
            );
        }

        $(document).ready(function () {
            $("#filtre-select").change(function () {
                var selectedValue = $(this).val();
                $.ajax({
                    url: "api/getSubFilter",
                    method: "POST",
                    data: "value=" + selectedValue,
                    success: function (data) {
                        data = JSON.parse(data);
                        if (data.success) {
                            $("#sub-filter-area").html(data.tempHtml);
                        }
                    }
                });
            });
        });
    </script>
<?php } ?>
<script>
    function pageLoading() {
        document.querySelector("body").classList.add("is-loading");
    }

    function pageLoaded() {
        document.querySelector("body").classList.remove("is-loading");
    }
</script>
<?php if ($ayarlar->reklam_durum == 1 && !isset($_SESSION["modalac"])) {
    $_SESSION["modalac"] = "1"; ?>
    <button type="button" class="btn btn-info btn-lg" id="clickadsss" data-toggle="modal" data-target="#myModal2a"
            style="display:none;"></button>

    <div id="myModal2a" class="modal fade" role="dialog">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <span class="modal-title" style="color:black !important;"><?= $ayarlar->reklam_baslik ?></span>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body">
                    <?= $ayarlar->reklam_icerik ?>
                </div>
            </div>
        </div>
    </div>
    <script>
        $(document).ready(function () {
            $("#clickadsss").click();
        });
    </script>
<?php } ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/clipboard.js/1.5.12/clipboard.min.js"></script>
<script src="<?= base_url('assets/front/') ?>js/theme.min.js?v=3.2"></script>
<script>
    var base_url = '<?= base_url() ?>';
    <?php if ($this->uri->segment(1) == "ilan-duzenle") {  ?>
    var urun_kategori = <?php echo $urun->kategori_json; ?>;
    <?php } ?>
    var site_komisyon = '<?php echo $ayarlar->komisyon; ?>';
    var anasayfa_reklam_fiyat = '<?php echo $ayarlar->anasayfa_urun_reklam; ?>';
    var kategori_reklam_fiyat = '<?php echo $ayarlar->kategori_urun_reklam; ?>';

    <?php if (($this->uri->segment(1) == "urun-duzenle") || ($this->uri->segment(1) == "ilan-duzenle"))  {  ?>
    $("#kategori").select2().val(urun_kategori).trigger('change');
    <?php } ?>


</script>
<script src="<?= base_url('assets/front/js/theme.js?v=' . strtotime("now")) ?>"></script>
<?= $ayarlar->analytics ?>
<?php
$alert = $this->session->userdata("alert");
if ($alert) {
    if ($alert["type"] === "success") { ?>
        <script type="text/javascript">
            iziToast.success({
                title: '<?= $alert["title"] ?>',
                message: '<?= $alert["text"] ?>',
                position: 'topCenter'
            });
        </script>
    <?php } else { ?>
        <script type="text/javascript">
            iziToast.<?= $alert["type"] ?>({
                title: '<?= $alert["title"] ?>',
                message: '<?= $alert["text"] ?>',
                position: 'topCenter'
            });
        </script>
    <?php }
} ?>
</body>
<script src="<?php echo base_url('assets/front/js/sweetalert2.all.min.js') ?>"></script>
<?php if ($this->uri->segment(1) == 'bakiye') { ?>
    <div class="ui coupled payment-info-modal transfer-modal modal">
        <div class="ui grid" style="margin:0;">
            <div class="modal-payment-transfer-area">
                <div class="modal-transfer-bank-img">
                    <img class="modal-bank-img" src="https://kemalellidort.com.tr/uploads/banka/654636e8163fa_akbank.png" alt="">
                </div>
                <div class="modal-transfer-bank-name">AKBANK T.A.Ş.</div>
                <div class="padding-left-modal-transfer">
                    <ul class="modal-transfer-bank-info-list">
                        <li>
                            <div class="bold-text">IBAN</div>
                            <p class="modal-iban-area">TR2800 0100 0975 7907 5041 5001</p>
                        </li>
                        <?php if (1 == 2) { ?>
                            <li>
                                <div class="bold-text">Şube Kodu</div>
                                45444
                            </li>
                            <li>
                                <div class="bold-text">Hesap Numarası</div>
                                0456464564
                            </li>
                        <?php } ?>
                        <li>
                            <div class="bold-text">Detay</div>
                            <p class="modal-bank-desc">GPAY Elektronik Ticaret AŞ</p>
                        </li>
                    </ul>
                    <div class="form-area">
                        <form class="ui form" id="odemeBildirimForm" method="POST"
                              action="<?= base_url('odemebildirimiolustur') ?>">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-12 p-0">
                                        <div class="form-group">
                                            <label for="text" class="form-label text-white light-text-black">Ödeme Tarihi</label>
                                            <input type="date" class="form-control" name="date" id="odeme_bildirim_date" onfocus="this.showPicker()"
                                                   placeholder="Tarih Giriniz ( Örn: 31.12.2023 )" min="<?php echo date('Y-m-d') ?>"
                                                   value="<?php echo date('Y-m-d') ?>"
                                                   required>
                                        </div>
                                    </div>
                                    <div class="col-6 pl-0">
                                        <div class="form-group">
                                            <label for="text" class="form-label text-white light-text-black">Gönderen Adı Soyadı</label>
                                            <input type="text" class="form-control" name="name" placeholder="Gönderen Adı Soyadı"
                                                   required>
                                        </div>
                                    </div>
                                    <div class="col-6 pr-0">
                                        <div class="form-group">
                                            <label for="text" class="form-label text-white light-text-black">Ödenecek Tutar</label>
                                            <input type="text" class="form-control" name="amount" id="havale_tutar" placeholder="Miktar"
                                                   required>
                                        </div>
                                    </div>
                                    <div class="col-6 pl-0">
                                        <div class="form-group">
                                            <label for="text" class="form-label text-white light-text-black">Hesaba Geçicek Tutar</label>
                                            <span class="form-control" id="havale_odenecek_tutar"></span>
                                        </div>
                                    </div>
                                    <div class="col-6 pr-0">
                                        <div class="form-group">
                                            <label for="text" class="form-label text-white light-text-black">Banka Hesabı</label>
                                            <select name="bank_id" class="form-control modal-bank-select" required>
                                                <?php
                                                $bankalar = bankalar(['status' => 1]);
                                                foreach ($bankalar as $banka):
                                                    ?>
                                                    <option value="<?= $banka->id ?>"><?= $banka->name ?></option>
                                                <?php
                                                endforeach; ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-12 p-0">
                                        <div class="form-group">
                                            <label for="text" class="form-label text-white light-text-black">Bize İletmek İstediğiniz</label>
                                            <textarea name="description" rows="5" class="form-control"></textarea>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <button type="submit" class="btn btn-primary btn-block">Ödeme Bildir</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php } ?>
</html>
<?php echo $ayarlar->canli_destek_jivo ?>
<?php echo $ayarlar->canli_destek_tawk ?>
<script type="text/javascript">
    var Tawk_API = Tawk_API || {};
    Tawk_API.customStyle = {
        visibility: {
            desktop: {
                position: 'br',
                xOffset: '60px',
                yOffset: 20
            },
            mobile: {
                position: 'br',
                xOffset: 0,
                yOffset: 0
            },
            bubble: {
                rotate: '0deg',
                xOffset: -20,
                yOffset: 0
            }
        }
    };
    var currentTheme = <?= $_SESSION['theme']; ?>;

    function changeThemeColor() {
        var oldsweet = document.getElementById("sweet_css");
        var oldtheme = document.getElementById("theme_css");
        var newsweetlink = document.createElement("link");
        newsweetlink.setAttribute("rel", "stylesheet");
        newsweetlink.setAttribute("type", "text/css");
        newsweetlink.setAttribute("id", "sweet_css");
        newsweetlink.setAttribute("href", currentTheme == 2 ? '<?=(base_url('assets/front/') . 'css/sweetalert2.min.css')?>' : 'https://cdn.jsdelivr.net/npm/@sweetalert2/theme-dark@4/dark.css');
        if (currentTheme == 2) {
            $('body').addClass('theme_light');
        } else {
            $('body').removeClass('theme_light');
        }
        document.getElementById("sweet_css").replaceWith(newsweetlink);
        currentTheme = currentTheme == 1 ? 2 : 1;
        fetch("<?= base_url('change_theme') ?>/" + currentTheme)
            .then((response) => response.json())
            .then((json) => true);
        if (currentTheme == 2) {
            $(".mode.dark.dark-mode").show();
            $(".mode.dark.light-mode").hide();
        } else {
            $(".mode.dark.dark-mode").hide();
            $(".mode.dark.light-mode").show();
        }
    }

</script>
<?php if ($this->uri->segment(1) == 'siparislerim') { ?>
    <script src="<?= base_url('assets/') ?>js/MyOrders.js?v=<?= time(); ?>"></script>
<?php } ?>

