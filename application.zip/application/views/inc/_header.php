<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="robots" content="index, follow">
    <meta name="description" content="<?php if (!$description) {
        echo html_escape($ayarlar->header_aciklama);
    } else {
        echo html_escape($description);
    } ?>">
    <meta name="keywords" content="<?php if (!$keywords) {
        echo html_escape($ayarlar->site_keyw);
    } else {
        echo html_escape($keywords);
    } ?>">
    <title>
        <?php if ($title) {
            echo $title . " - " . $ayarlar->header_baslik;
        } else {
            echo $ayarlar->header_baslik;
        } ?></title>
    <meta charset="utf-8">
    <link rel="icon" type="image/png" href="<?php echo base_url($ayarlar->site_favicon) ?>">
    <link rel="canonical" href="<?php echo current_url() ?>"/>
    <link rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap.min.css') ?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/swiper-bundle.min.css') ?>"/>
    <link rel="stylesheet" href="<?php echo base_url('assets/css/all.min.css') ?>"/>
    <link href="<?= base_url('assets/front/') ?>fonts/feather/feather.css?v=<?= time(); ?>" rel="stylesheet"/>
    <link href="<?= base_url('assets/front/') ?>libs/%40mdi/font/css/materialdesignicons.min.css" rel="stylesheet"/>
    <link rel="stylesheet" href="<?= base_url('assets/front/') ?>libs/owl/assets/owl.carousel.min.css">
    <link rel="stylesheet" href="<?= base_url('assets/front/') ?>libs/owl/assets/owl.theme.default.min.css">
    <link rel="stylesheet" href="<?= base_url('assets/front/') ?>css/theme.min.css?v='12.11.5">
    <link rel="stylesheet" href="<?= base_url("assets") ?>/css/iziToast.min.css">
    <link type="text/css" rel="stylesheet" href="<?= base_url('assets/front/'); ?>css/image-uploader.min.css">
    <link rel="stylesheet" href="<?= base_url('assets/css/custom.css') ?>?ver=<?= time(); ?>">
    <?php if ($this->uri->segment(1) == 'ilan-duzenle') { ?>
    <link rel="stylesheet" href="<?php echo base_url('assets/css/select2.min.css') ?>"/>
    <?php } ?>
    <?php if ($this->uri->segment(1) == 'ilan-ekle') { ?>
        <link rel="stylesheet" href="<?php echo base_url('assets/yonetim/css/dropzone.min.css?v=1.2') ?>">
        <link rel="stylesheet" href="<?php echo base_url('assets/yonetim/css/dropzone.css?v=1.2') ?>">
        <script src="<?php echo base_url('assets/yonetim/js/dropzone.min.js?v=1.2') ?>" defer></script>
    <?php } ?>
    <script src="<?php echo base_url('assets/front/js/swiper-bundle.min.js') ?>" async></script>
    <script src="<?php echo base_url('assets/front/js/jquery.min.js') ?>" referrerpolicy="no-referrer" async></script>

    <link rel="stylesheet" href="assets/css/simple-lightbox.min.css" referrerpolicy="no-referrer"/>
    <script type="text/javascript" src="assets/front/js/daterangepicker.min.js" defer></script>
    <link rel="stylesheet" type="text/css" href="assets/css/daterangepicker.css"/>
    <?php if (1 == 2) { ?>
    <script src="https://js.stripe.com/v3/" defer></script>
    <?php } ?>
</head>
<link rel="stylesheet" id="sweet_css" href="<?= ($_SESSION["theme"] == 2)?'assets/css/dark-swa.css':(base_url('assets/front/').'css/sweetalert2.min.css'); ?>">
<link rel="stylesheet" id="sweet_css" href="<?= (base_url('assets/css/').'dark.css?ver='.time()); ?>">
<link rel="stylesheet" id="sweet_css" href="<?= (base_url('assets/css/').'light.css?ver='.time()); ?>">
<meta http-equiv="x-dns-prefetch-control" content="on">
<link rel="dns-prefetch" href="https://www.googletagmanager.com/">
<link rel="dns-prefetch" href="https://www.google-analytics.com/">
<body class="<?= ($_SESSION["theme"] == 2) ? "" : "theme_light"; ?>">
<?php if (1 == 2) { ?>
    <div id="mySidebar " class="sidebar hello">
        <a href="javascript:void(0)" class="closebtn" onclick="closeNav()" title="close">×</a>
        <?php
        $res = fetchCategoryTreeMenu2();
        foreach ($res as $r) {
            echo $r;
        }
        ?>
    </div>
<?php } ?>
<div class="header-top <?php echo empty($none) ? '': $none; ?>" onscroll="kontrolEt()">
    <div class="container">
        <div class="row">
            <div class="col-12 col-md-12 col-lg-5 header-top-menu-mobile-left">
                <div class="header-slick">
                    <?php
                    $hsg = $this->yonetim_model->getsubhdrand();
                    $rand_keys = array_rand($hsg, 1);
                    $secilen = $hsg[$rand_keys];
                    ?>
                    <span style="color: white;">
                        <a class="h-slick-p" style="color: white;" href="<?= $secilen->link; ?>"
                            title="<?= $secilen->baslik; ?>"><?= $secilen->baslik; ?>
                        </a>
                    </span>
                </div>
            </div>
            <div class="col-12 col-md-12 col-lg-7 float-right header-top-menu-mobile-right pr-responsiv ">
                <ul class="header-links" style="display: flex; align-items: center;">
                    <li class="hidden-not-pc">
                        <a href="/blog" title="Blog">Blog</a>
                    </li>
                    <li class="hidden-not-pc">
                        <a href="/sss" title="SSS">SSS</a>
                    </li>

                    <li class="hidden-not-pc">
                        <a href="https://discord.gg/kem4l" rel="nofollow" target="_blank"
                           title="Discord">Discord</a>
                    </li>

                    <li class="hidden-not-pc">
                        <a href="/bayimiz-olun" title="Bayi Başvuru">Bayi Başvuru</a>
                    </li>
                    <li class="language">
                        <a class="language-icon-link" href="/" onclick="doGTranslate('tr|tr');return false;" title="Türkçe">
                            <img class="language-icon" src="<?php echo base_url('assets/images/flag/turkey2.png') ?>" alt="Türkçe" width="20" height="20">
                        </a>       
                        <a class="language-icon-link" href="/" onclick="doGTranslate('tr|en');return false;" title="English">
                            <img class="language-icon" src="<?php echo base_url('assets/images/flag/english2.png') ?>" alt="English" width="20" height="20">
                        </a>
                        <style>
                            #google_translate_element2 {display:none!important;}
                            a.glink.nturl.notranslate {
                                padding: 2px;
                            }
                            body {
                              top: 0px !important;
                            }
                            .skiptranslate {
                             display: none !important;
                            }
                        </style>
                        <div id="google_translate_element2"></div>
                        <script defer>
                            function googleTranslateElementInit2() {new google.translate.TranslateElement({pageLanguage: 'tr',autoDisplay: false}, 'google_translate_element2');}
                        </script>
                        <script src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit2" defer></script>
                        <script defer>
                            function GTranslateGetCurrentLang() {var keyValue = document['cookie'].match('(^|;) ?googtrans=([^;]*)(;|$)');return keyValue ? keyValue[2].split('/')[2] : null;}
                            function GTranslateFireEvent(element,event){try{if(document.createEventObject){var evt=document.createEventObject();element.fireEvent('on'+event,evt)}else{var evt=document.createEvent('HTMLEvents');evt.initEvent(event,true,true);element.dispatchEvent(evt)}}catch(e){}}
                            function doGTranslate(lang_pair){if(lang_pair.value)lang_pair=lang_pair.value;if(lang_pair=='')return;var lang=lang_pair.split('|')[1];if(GTranslateGetCurrentLang() == null && lang == lang_pair.split('|')[0])return;var teCombo;var sel=document.getElementsByTagName('select');for(var i=0;i<sel.length;i++)if(sel[i].className.indexOf('goog-te-combo')!=-1){teCombo=sel[i];break;}if(document.getElementById('google_translate_element2')==null||document.getElementById('google_translate_element2').innerHTML.length==0||teCombo.length==0||teCombo.innerHTML.length==0){setTimeout(function(){doGTranslate(lang_pair)},500)}else{teCombo.value=lang;GTranslateFireEvent(teCombo,'change');GTranslateFireEvent(teCombo,'change')}}
                        </script>
                    </li>
                    
                    <li class=" dark-mode crdm"
                        style="position: relative; ">
                        <label class="mode-switch">
                            <input type="checkbox" onchange="changeThemeColor()" id="mode" <?= $_SESSION['theme'] == 2?'checked':'';?>>
                            <span class="sun">Aydınlık</span>
                            <span class="night">Karanlık</span>
                            <div class="icon">
                                <i class="fe fe-sun"></i>
                            </div>
                        </label>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>
<div style="background: #1C2438;" class=" <?php echo empty($none) ? '': $none; ?>">
    <div class="container">
        <div class="row align-items-center items-center">
            <div class="col-xl-2 col-lg-2 col-12 text-lg-left text-center">
                <a class="navbar-brand header-logo" href="<?= base_url() ?>" style="margin-right: 0" title="Herşey Oyun">
                    <img src="<?= base_url($ayarlar->site_darklogo) ?>" alt="Logo" width="200" height="64"/>
                </a>
            </div>
            <div class="col-xl-6 col-lg-6 col-sm-6 col-12 pr-0 padding-havva">
                <form class=" mt-lg-0 d-flex align-items-center mr-3 search-inputs position-relative"
                      style="width: 100%;">
                        <span class="position-absolute pr-3 search-icon" style="right:0;">
                            <i class="fe fe-search text-white"></i>
                        </span>
                    <input pattern=".*\S+.*" type="text" id="input_search"
                           style="background-color:#12192A!important; border:1px solid #313d5a!important; color:white"
                           name="arama" <?php echo (!empty($filter_search)) ? $filter_search : ''; ?>
                           class="form-control badge-pill pl-3 pr-6"
                           placeholder="Ürün, kategori veya ilan arayabilirsiniz..."/>
                    <div id="response_search_results" class="search-results-ajax"></div>
                </form>
            </div>
            <div class="col-xl-4 col-lg-4 col-sm-6 col-12 pr-0">
                <div class="user-panel-links">
                    <div class="customer-links">
                        <div class="user-text LoginButton">
                            <div class="text-top">
                            </div>
                            <div class="text-bottom">
                            </div>
                        </div>

                        <?php if (aktif_kullanici()) { ?>
                            <li class="dropdown d-inline-block header-border"
                            style="position: relative; padding-right: 10px;padding-left: 10px">
                            <a style="z-index:10; justify-content: center;
                            padding-top: 25px;align-items: center;" class="toolbar-btn toolbar-btn-end light-dark-f not-hover" role="button"
                               id="dropdownUserProfileDiv" data-toggle="dropdown" aria-haspopup="true" aria-hidden="true"
                               aria-expanded="false" href="javascript:void(0)">
                                <?php
                                if (!isset($_SESSION["sistembildir"])) {
                                    $_SESSION["sistembildir"] = "0";
                                }
                                $this->db->where("kullanici_id='" . $kullanici->kullanici_id . "' and talep_durum='0'");
                                $aylik_siparis_adet = $this->db->get('talep')->result();
                                $data = [];
                                $say = "0";
                                $yaz = "";
                                foreach ($aylik_siparis_adet as $row) {
                                    $say++;
                                    $yaz .= '<a class="dropdown-item w-full" href="/destek-detay/' . $row->talep_no . '">
                                  ' . $say . ' - ' . $row->talep . '
                                    </a>
                                    ';
                                }
                                $magaza = magaza_kbilgi($kullanici->kullanici_id);
                                if (!empty($magaza)) {
                                    $onayli_cekilis = $this->db->where(['onay' => 1, 'status' => 0, 'magaza_id' => $magaza->magaza_id])->get('cekilis')->result();
                                    foreach ($onayli_cekilis as $row) {
                                        $say++;
                                        $yaz .= '<a class="dropdown-item w-full" href="/cekilislerim">
                                  ' . $say . ' - ' . $row->title . '
                                    </a>
                                    ';
                                    }
                                }
                                $cevaplanan_itirazlar = $this->db->where(['teslimat_durum' => 3, 'kullanici_id' => $kullanici->kullanici_id])->get('teslimat')->result();
                                foreach ($cevaplanan_itirazlar as $row) {
                                    $say++;
                                    $yaz .= '<a class="dropdown-item w-full" href="/teslimat/'.$row->siparis_no.'">
                                  ' . $say . ' - Teslimat İtirazı Cevaplandı
                                    </a>
                                    ';
                                }

                                if ($say != $_SESSION["sistembildir"]) {
                                    if ($say > $_SESSION["sistembildir"]) {
                                    }
                                    $_SESSION["sistembildir"] = $say;
                                }
                                ?>
                                <div class="d-flex flex-column align-items-center ">
                                    <i class="fa fa-bell fa-2x" style="font-size: 24px;color:#9fbbff !important;"></i>
                                    <i class="icon-bell"></i>
                                </div>
                            </a>
                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownUserProfileDiv">
                                <span class="px-3">
                                    Bildirimlerim
                                </span>
                                <div class="dropdown-divider"></div>
                                <ul class="list-unstyled" id="list-unstyled">
                                    <?php if (!empty($yaz)): ?>
                                        <li>
                                            <?= $yaz; ?>
                                        </li>
                                    <?php else: ?>
                                        <span class="px-3">Bildiriminiz yok</span>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </li>
                            <li class=" d-inline-block header-border"
                            style="position: relative; padding-right: 10px;padding-left: 10px">
                            <a style="z-index:10; justify-content: center;
                            padding-top: 25px;align-items: center;" class="toolbar-btn toolbar-btn-end light-dark-f not-hover" role="button" id=""
                               href="/mesajlar" title="Mesajlar">
                                <div class="d-flex flex-column align-items-center ">
                                    <i class="fas fa-comments"
                                       style="width: 21px; color: #9fbbff; font-size: 22px;"></i>
                                </div>
                            </a>
                        </li>
                        <?php } ?>
                        <?php if (aktif_kullanici()) { ?>
                            <li class="dropdown d-inline-block">
                                <a class="not-hover" title="Hesabım" role="button" id="dropdownUserProfileDiv" data-toggle="dropdown" aria-hidden="true"
                                   aria-expanded="false" href="javascript:void(0)">
                                    <div style="padding:0 !important;" class="dropdown-item w-full not-hover">
                                        <div class="d-flex w-full">
                                            <?php if (strpos($kullanici->kullanici_resim, "/.jpg") !== false) { ?>
                                                <span title="User Icon" class="icon-user">
                                                    <img
                                                        src="https://ui-avatars.com/api/?name=<?= $kullanici->kullanici_isim ?>+<?= $kullanici->kullanici_soyisim ?>&background=0D8ABC&color=fff"
                                                        width="28" height="26" class="userAvatar" alt="Avatar">
                                                </span>
                                            <?php } else { ?>
                                                <span title="User Icon" class="icon-user">
                                                    <img src="<?= base_url($kullanici->kullanici_resim) ?>" width="28"
                                                         height="26" class="userAvatar" alt="Avatar">
                                                </span>
                                            <?php } ?>
                                            <div class="ml-1 lh-1 items-center">
                                                <span class="mb-2 mt-2 avatar-font"
                                                      title="Profil"><span><?= $kullanici->kullanici_isim . " " . $kullanici->kullanici_soyisim ?></span></span>
                                                <span style="margin-left: 5px">
                                                    <i class="fas fa-angle-down"></i>
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                                <div style="" class="abo dropdown-menu dropdown-menu-right"
                                     aria-labelledby="dropdownUserProfileDiv">
                                    <ul class="uwu list-unstyled" id="list-unstyled" style="padding: 0px!important;margin-bottom: 0px!important;">
                                        <li style="width: 100%">
                                            <?php if (magaza_check()) { ?>
                                                <a class="dropdown-item w-full guvenilirItem" href="<?php echo base_url('m/'.magaza($kullanici->kullanici_id)->magaza_seo) ?>" style="width: 100%!important; line-height: 1em; border-bottom: 1px solid #232c42" title="Mağazam">
                                                    <i class="fe fe-shopping-bag mr-2"></i>Mağazam
                                                </a>
                                            <?php } else { ?>
                                                <a class="dropdown-item w-full guvenilirItem"
                                                   href="<?= base_url('magaza-olustur') ?>" style="width: 100%!important; line-height: 1em; border-bottom: 1px solid #232c42" title="Mağaza Oluştur">
                                                    <i class="fe fe-shopping-bag mr-2"></i>Mağaza Oluştur
                                                </a>
                                            <?php } ?>
                                            <a class="dropdown-item w-full" href="<?= base_url('hesabim') ?>" style="width: 100%!important; line-height: 1em; border-bottom: 1px solid #232c42" title="Profilim">
                                                <i class="fe fe-user mr-2"></i>Profilim
                                            </a>
                                            <a class="dropdown-item w-full" href="<?= base_url('mesajlar') ?>" style="width: 100%!important; line-height: 1em; border-bottom: 1px solid #232c42" title="Mesajlarım">
                                                <i class="fe fe-message-circle mr-2 <?php if (mesajOkunmamis()) {
                                                    echo "indicator indicator-primary";
                                                } ?>"></i>Mesajlarım
                                            </a>
                                            <a class="dropdown-item w-full" href="<?= base_url('bakiye') ?>" style="width: 100%!important; line-height: 1em; border-bottom: 1px solid #232c42" title="Bakiye">
                                                <i class="fas fa-coins mr-2"></i>Bakiye: <?= $kullanici->bakiye ?>₺
                                            </a>
                                            <?php if (magaza_check()) { ?>
                                                <a class="dropdown-item w-full" href="<?php echo base_url('m/'.magaza($kullanici->kullanici_id)->magaza_seo) ?>" style="width: 100%!important; line-height: 1em; border-bottom: 1px solid #232c42" title="İlanlarım">
                                                    <i class="fas fa-store mr-2"></i>İlanlarım
                                                </a>
                                            <?php } ?>
                                            <a class="dropdown-item w-full" href="<?= base_url('siparislerim') ?>" style="width: 100%!important; line-height: 1em; border-bottom: 1px solid #232c42" title="Siparişlerim">
                                                <i class="fas fa-shopping-basket mr-2"></i>Siparişlerim
                                            </a>
                                            <a class="dropdown-item w-full" href="<?= base_url('odeme-talep') ?>" style="width: 100%!important; line-height: 1em; border-bottom: 1px solid #232c42" title="Para Çek">
                                                <i class="fas fa-wallet mr-2"></i>Para Çek
                                            </a>
                                            <a class="dropdown-item w-full" href="<?= base_url('destek-taleplerim') ?>" style="width: 100%!important; line-height: 1em; border-bottom: 1px solid #232c42" title="Destek Sistemi">
                                                <i class="far fa-life-ring mr-2"></i>Destek Sistemi
                                            </a>
                                            <?php if (magaza_check()) { ?>
                                                <a class="dropdown-item w-full"
                                                   href="<?= base_url('cekilis/olustur') ?>" style="width: 100%!important; line-height: 1em; border-bottom: 1px solid #232c42" title="Çekiliş Oluştur">
                                                    <i class="fas fa-shopping-basket mr-2"></i>Çekiliş Oluştur
                                                </a>
                                            <?php } ?>
                                        </li>
                                        <li style="width: 100%">
                                            <a class="dropdown-item w-full text-danger" href="<?= base_url('cikis') ?>" style="width: 100%!important; line-height: 1em;" title="Çıkış Yap">
                                                <i class="fe fe-power nav-icon"></i> Çıkış Yap
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                        <?php } else { ?>
                            <ul class="log-res-btn-area">
                                <li class="login-btn-area">
                                    <div class="login-btn mr-2" onclick="window.location.href='<?php echo base_url('giris-yap') ?>'" title="Giriş Yap">
                                        <div class="logser-warper">
                                            <div class="logsr-icon">
                                                 <i class="fas fa-user mr-2"></i>
                                            </div>
                                            <div class="lgsr ml-2">
                                                  Giriş
                                             </div>
                                        </div>
                                    </div>
                                </li>

                                <li class="login-btn-area">
                                    <div class="regis-btn ml-2" onclick="window.location.href='<?php echo base_url('hesap-olustur') ?>'" title="Kayıt">
                                        <div class="logser-warper mls-bg">
                                            <div class="logsr-icon">
                                                 <i class="fas fa-user-plus mr-2"></i>
                                            </div>
                                            <div class="lgsr ml-2">
                                                Kayıt Ol
                                             </div>
                                        </div>
                                    </div>
                                </li>
                                
                            </ul>
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<button href="javascript:void(0);" type="button" class="icon d-sm-none menu-close-icon " onclick="openMobileMenu()" title="Menü"></button>
<div class=" p-0 m-0">
    <nav style="background-color: #313D5A!important;border-bottom: 1px solid #404b66;border-top: 1px solid #404b66;"
        class="navbar navbar-expand-lg navbar-default p-0 justify-content-center navbars-icons  <?php echo empty($none) ? '': $none; ?>">
    
        <div class="container hello-icons c-p" style="justify-content: space-between !important;">
            <script defer>
                function openNav() {
                    document.getElementById("mySidebar").style.width = "250px";
                    document.getElementById("main").style.marginLeft = "250px";
                }
                function closeNav() {
                    document.getElementById("mySidebar").style.width = "0";
                    document.getElementById("main").style.marginLeft = "0";
                }
            </script>
            <ul class="navbar-nav mobile-menus top-nav-list-area">
                <?php
                $res = fetchCategoryTreeMenu();
                foreach ($res as $r) {
                    echo $r;
                }
                ?>
            </ul>
            <div class="d-flex justify-content-end ">
                <?php if (aktif_kullanici()) { ?>
                    <a class="dropdown-item w-full advert light-color" href="<?php echo base_url('ilan-ekle') ?>"><i
                            class="fas fa-plus mr-2"></i> İlan Ekle</a>
                    <a class="dropdown-item w-full balance-active" href="<?= base_url('bakiye') ?>">
                        <i class="fas fa-coins mr-2"></i>Bakiye: <?= $kullanici->bakiye ?>₺
                    </a>
                <?php } ?>
            </div>
            <div class=" mobil-menu-new">
                <p>Menu</p>
                <i class="fa fa-bars" style="font-size: 24px;"></i>
            </div>
        </div>
    </nav>
</div>
<div class="search-modal" style="display: none">
    <div class="search-close"></div>
    <form class=" mt-lg-0 d-flex align-items-center mr-3 search-inputs position-relative">
                        <span class="position-absolute pr-3 search-icon" style="right:0;">
                            <i class="fe fe-search text-white"></i>
                        </span>
        <input pattern=".*\S+.*" type="text" id="input_searchs"
               style="background-color:#12192A!important; border:1px solid #313d5a !important; color:white"
               name="arama" <?php echo (!empty($filter_search)) ? $filter_search : ''; ?>
               class="form-control badge-pill pl-3 pr-6"
               placeholder="Ürün, kategori veya ilan arayabilirsiniz..."/>
        <div id="response_search_results" class="search-results-ajax"></div>
    </form>
</div>