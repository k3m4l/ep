<?php $ustkategori = detaykategori($where->kategori_id); ?>
<?php $ayarlar = ayarlar(); ?>
<?php $yorumpuan = yorumpsay($where->firma_id); ?>
<?php $yorumpuani = yorumpsay($where->firma_id)->yorum_puan; ?>
<?php $kullanici = kullanicicek(); ?>
<?php $link = $_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI']; ?>

<!-- Slider
================================================== -->
<?php if ($where->ozellik_galeri==1) { ?>
	<?php if (!empty($where->firma_galeri) && $where->firma_galeri!="[]") { ?>
    <?php $galeri = json_decode($where->firma_galeri); ?>
     <?php if ($galeri) { ?>
  	  <div class="listing-slider mfp-gallery-container margin-bottom-0">
        <?php $i=0; foreach ($galeri as $key) { $i++; ?>
  	       <a href="<?=base_url("uploads/firma/galeri/").$key?>" data-background-image="<?=base_url("uploads/firma/galeri/").$key?>" class="item mfp-gallery" title="<?=$where->firma_ad." ".$i?> "></a>
        <?php } ?>
  	  </div>
      <?php } ?>
	<?php } ?>
<?php } ?>


<!-- Content
================================================== -->
<div class="container">
  <div class="row sticky-wrapper">
    <div class="col-lg-8 col-md-8 padding-right-30">

      <!-- Titlebar -->
      <div id="titlebar" class="listing-titlebar">
        <div class="listing-titlebar-title">
          <h2><?=$where->firma_ad?> <span class="listing-tag"><?=$where->kategori_ad?></span></h2>
          <span>
            <a href="#listing-location" class="listing-address">
              <i class="fa fa-map-marker"></i>
              <?=$where->firma_adres?>
            </a>
          </span>
          <?php if ($where->ozellik_yorum==1) { ?>
	          <div class="star-rating" data-rating="<?=$yorumpuan->yorum_puan?>">
	            <div class="rating-counter"><a href="#listing-reviews">(<?php echo yorumsaydir($where->firma_id); ?> yorum)</a></div>
	          </div>
          <?php } ?>
        </div>
      </div>

      <?php if ($ayarlar->ortasolreklam) {?>
        <div class="headline centered margin-bottom-30">
           <?=$ayarlar->ortasolreklam?>
        </div>
      <?php } ?>

      <!-- Listing Nav -->
      <div id="listing-nav" class="listing-nav-container">
        <ul class="listing-nav">
          <li><a href="#listing-overview" class="active">Tanıtım</a></li>
          <li><a href="#listing-location">Harita</a></li>
          <?php if ($where->ozellik_yorum==1) { ?>
	          <li><a href="#listing-reviews">Yorumlar</a></li>
	          <li><a href="#add-review">Yorum Yap</a></li>
          <?php } ?>
        </ul>
      </div>
      
      <!-- Overview -->
      <div id="listing-overview" class="listing-section">

        <!-- Description -->

        <p><?=$where->firma_aciklama?></p>        
        
        <!-- Listing Contacts -->
        <div class="listing-links-container">

          <ul class="listing-links contact-links">
            <?php if ($where->firma_tel) { ?>
              <li><a href="tel:<?=$where->firma_tel?>" class="listing-links"><i class="fa fa-phone"></i> <?=$where->firma_tel?></a></li>
            <?php } ?>
            <?php if ($where->firma_mail) { ?>
              <li><a href="mailto:<?=$where->firma_mail?>" class="listing-links"><i class="fa fa-envelope-o"></i> <?=$where->firma_mail?></a>
              </li>
            <?php } ?>
            <?php if ($where->firma_website) { ?>
              <li><a href="<?=$where->firma_website?>" target="_blank"  class="listing-links"><i class="fa fa-link"></i> <?=$where->firma_website?></a></li>
            <?php } ?>
          </ul>
          <div class="clearfix"></div>

          <ul class="listing-links">
            <?php if ($where->firma_facebook) { ?>
              <li><a href="<?=$where->firma_facebook?>" target="_blank" class="listing-links-fb"><i class="fa fa-facebook-square"></i> Facebook</a></li>
            <?php } ?>
            <?php if ($where->firma_twitter) { ?>
              <li><a href="<?=$where->firma_twitter?>" target="_blank" class="listing-links-tt"><i class="fa fa-twitter"></i> Twitter</a></li>
            <?php } ?>
            <?php if ($where->firma_instagram) { ?>
              <li><a href="<?=$where->firma_instagram?>" target="_blank" class="listing-links-ig"><i class="fa fa-instagram"></i> Instagram</a></li>
            <?php } ?>
          </ul>
          <div class="clearfix"></div>

        </div>
        <div class="clearfix"></div>

      <?php if ($where->firma_hizmetler) { ?>
          <?php if ($where->ozellik_hizmet==1) { ?>
  	        <!-- Amenities -->
  	        <h3 class="listing-desc-headline">Hizmetlerimiz</h3>
  	        <ul class="listing-features checkboxes margin-top-0">
  	          <?php $hizmet = json_decode($where->firma_hizmetler); ?>
              <?php if ($hizmet) { ?>
  	          <?php foreach ($hizmet as $himetim) { ?>
  	            <li><?=$himetim?></li>
  	          <?php } ?>
              <?php } ?>
  	        </ul>
          <?php } ?>
          <?php } ?>
        </div>

    
      <!-- Location -->
      <div id="listing-location" class="listing-section">
        <h3 class="listing-desc-headline margin-top-60 margin-bottom-30">Harita</h3>

        <div id="singleListingMap-container">
          <div id="singleListingMap" data-latitude="<?=$where->firma_lat?>" data-longitude="<?=$where->firma_lon?>" data-map-icon="<?=$where->kategori_ikon?>"></div>
          <a href="#" id="streetView">Sokak Görünümü</a>
        </div>
      </div>
        
      <!-- Reviews -->
      <?php if ($where->ozellik_yorum==1) { ?>
      <div id="listing-reviews" class="listing-section">
        <h3 class="listing-desc-headline margin-top-75 margin-bottom-20">Yorumlar <span>(<?php echo yorumsaydir($where->firma_id); ?>)</span></h3>

        <!-- Rating Overview -->
        <div class="rating-overview">
          <div class="rating-overview-box">
            <span class="rating-overview-box-total"><?=$yorumpuani;?></span>
            <span class="rating-overview-box-percent">5.0 üzerinden</span>
            <div class="star-rating" data-rating="<?=$yorumpuani;?>"></div>
          </div>

          <div class="rating-bars">
              <div class="rating-bars-item">
                <span class="rating-bars-name">Müşteri Yorum Derecelendirme <i class="tip" data-tip-content="Müşterilerden firma hakkında yorum puan ortalaması"></i></span>
                <span class="rating-bars-inner">
                  <span class="rating-bars-rating" data-rating="<?=$yorumpuani;?>">
                    <span class="rating-bars-rating-inner"></span>
                  </span>
                  <strong><?=$yorumpuani;?></strong>
                </span>
              </div>
          </div>
        </div>
        <!-- Rating Overview / End -->


        <div class="clearfix"></div>

        <!-- Reviews -->
        <section class="comments listing-reviews">
          <ul>
            <?php if (!$yorumlar) { ?>
              <div class="notification warning closeable text-center">
                <p>Hiç Yorum Bulunamadı..</p>
              </div>
            <?php }else{ ?>
            <?php foreach ($yorumlar as $key) { ?>
              <li>
                <div class="avatar"><img src="<?=base_url($key->kullanici_resim)?>" alt="<?=$key->kullanici_isim." ".$key->kullanici_soyisim?>" /> </div>
                <div class="comment-content"><div class="arrow-comment"></div>
                  <div class="comment-by"><?=$key->kullanici_isim." ".$key->kullanici_soyisim?><span class="date"><?=zamanCevir($key->yorum_zaman)?></span>
                    <div class="star-rating" data-rating="<?=$key->yorum_puan?>"></div>
                  </div>
                  <p><?=$key->yorum_detay?></p>
                </div>

              </li>
              <?php } ?>
            <?php } ?>
           </ul>
        </section>

      </div>


      <!-- Add Review Box -->
      <div id="add-review" class="add-review-box">

        <!-- Add Review -->
        <h3 class="listing-desc-headline margin-bottom-10">Yorum Yap</h3>

        <!-- Subratings Container -->
        <?php if (aktif_kullanici()) {?>
        <form method="post" action="<?=base_url("yorumyap")?>" class="add-comment">
        <div class="sub-ratings-container">

          <!-- Subrating #1 -->
          <div class="add-sub-rating">
            <div class="sub-rating-title">Firma Puanla <i class="tip" data-tip-content="Firmayı puanlama yaparak diğer müşteriler için fikir bırakabilirsiniz."></i></div>
            <div class="sub-rating-stars">
              <!-- Leave Rating -->
              <div class="clearfix"></div>
              <div class="leave-rating">
                <input type="radio" name="rating" id="rating-1" value="5"/>
                <label for="rating-1" class="fa fa-star"></label>
                <input type="radio" name="rating" id="rating-2" value="4"/>
                <label for="rating-2" class="fa fa-star"></label>
                <input type="radio" name="rating" id="rating-3" value="3"/>
                <label for="rating-3" class="fa fa-star"></label>
                <input type="radio" name="rating" id="rating-4" value="2"/>
                <label for="rating-4" class="fa fa-star"></label>
                <input type="radio" name="rating" id="rating-5" value="1"/>
                <label for="rating-5" class="fa fa-star"></label>
              </div>
            </div>
          </div>

        </div>
        <!-- Subratings Container / End -->

        <!-- Review Comment -->
            <fieldset>

              <div>
                <label>Yorum:</label>
                <textarea cols="40" name="yorum" rows="3" placeholder="Yorum yapınız.." required=""></textarea>
                <input type="hidden" name="dd1dc666b5f6977ab0778d9285e245bdf3926915" value="<?=$where->firma_id?>">
              </div>

            </fieldset>

            <button type="submit" class="button">Yorum Yap</button>
            <div class="clearfix"></div>
          </form>
        <?php }else{ ?>
          <fieldset>

              <div>
                <label>Yorum:</label>
                <textarea cols="40" rows="3" placeholder="Yorum yapmak için giriş yapın!" disabled=""></textarea>
              </div>

            </fieldset>

            <button class="button" disabled="">Yorum Yap</button>
            <div class="clearfix"></div>
        <?php } ?>

      </div>
      <!-- Add Review Box / End -->
      <?php } ?>

    </div>


    <!-- Sidebar
    ================================================== -->
    <div class="col-lg-4 col-md-4 margin-top-75 sticky">

        
      <!-- Verified Badge -->
      <?php if ($where->firma_dogrulama==1) { ?>
        <div class="verified-badge with-tip" data-tip-content="Bu Firma Gerçek Kişiyi Temsil Etmektedir">
          <i class="sl sl-icon-check"></i> Doğrulanmış Firma
        </div>
      <?php } ?>


      <?php if ($where->ozellik_rezervasyon==1) { ?>
      	<?php if (!empty($where->ozellik_rezmail)) { ?>
		      <div class="boxed-widget booking-widget message-vendor margin-top-35">
			      	<form method="post" action="<?=base_url("rezervasyongonder/$where->firma_uniq")?>">
						<h3><i class="fa fa-envelope-o"></i> Teklif Al</h3>
						<div class="row with-forms  margin-top-0">

							<div class="col-lg-12">
								<input type="text" name="ad" placeholder="İsim Soyisim">
								<input type="text" name="mail" placeholder="E-Posta Adresi">
								<input type="text" name="tel" placeholder="Telefon Numarası">
								<textarea name="mesaj" cols="10" rows="2" placeholder="Mesajınız.."></textarea>
							</div>

						</div>

						<!-- Recaptcha Holder -->

							<div class="g-recaptcha" style="margin-top: 10px; margin-bottom: 10px" data-sitekey="<?php print_r($google_key); ?>"></div>

						
						<!-- Book Now -->
						<button type="submit" class="button book-now fullwidth margin-top-5">Fiyat Teklifi Al</button>
					</form>
				</div>
			<?php } ?>
		<?php } ?>
    
      <!-- Opening Hours -->
      <?php if ($where->ozellik_saat==1) { ?>
	      <div class="boxed-widget opening-hours margin-top-35">
	        <h3><i class="sl sl-icon-clock"></i> Çalışma Saatleri</h3>
	        <ul>
	          <?php if ($where->firma_his == "24 Saat Açık" && $where->firma_hia == "24 Saat Açık") { ?>

	             <li>Hafta İçi <span><?=$where->firma_his?></span></li>
	             <li>Hafta Sonu <span><?=$where->firma_hss?></span></li>

	          <?php }elseif ($where->firma_his == "24 Saat Açık") { ?>

	            <li>Hafta İçi <span><?=$where->firma_his?></span></li>
	            <li>Hafta Sonu <span><?=$where->firma_hss?> - <?=$where->firma_hsa?></span></li>

	          <?php }elseif ($where->firma_hss == "24 Saat Açık") { ?>

	            <li>Hafta İçi <span><?=$where->firma_his?> - <?=$where->firma_hia?></span></li>
	            <li>Hafta Sonu <span><?=$where->firma_hss?></span></li>

	          <?php }else{ ?>
	            <li>Hafta İçi <span><?=$where->firma_his?> - <?=$where->firma_hia?></span></li>
	            <li>Hafta Sonu <span><?=$where->firma_hss?> - <?=$where->firma_hsa?></span></li>
	          <?php } ?>
	        </ul>
	      </div>
      <?php } ?>
      <!-- Opening Hours / End -->


      <!-- Contact -->
      <?php if ($where->ozellik_yetkili==1) { ?>
	      <div class="boxed-widget margin-top-35">
	        <div class="hosted-by-title">
	          <h4><span>Firma Yetkilisi</span> <a href="javascript:void(0)"><?=$where->kullanici_isim." ".$where->kullanici_soyisim?></a></h4>
	          <a href="javascript:void(0)" class="hosted-by-avatar"><img src="<?=base_url($where->kullanici_resim)?>" alt=""></a>
	        </div>
	        <ul class="listing-details-sidebar">
	          <?php if ($where->firma_tel) { ?>
	            <li><i class="sl sl-icon-phone"></i> <?=$where->firma_tel?></li>
	          <?php } ?>
	          <?php if ($where->firma_website) { ?>
	            <li><i class="sl sl-icon-globe"></i> <a target="_blank" href="<?=$where->firma_website?>"><?=$where->firma_website?></a></li>
	          <?php } ?>
	          <?php if ($where->firma_mail) { ?>
	            <li><i class="fa fa-envelope-o"></i> <a href="mailto:<?=$where->firma_mail?>"><?=$where->firma_mail?></a></li>
	          <?php } ?>
	        </ul>

	        <ul class="listing-details-sidebar social-profiles">
	          <?php if ($where->firma_facebook) { ?>
	            <li><a href="<?=$where->firma_facebook?>" class="facebook-profile"><i class="fa fa-facebook-square"></i> Facebook</a></li>
	          <?php } ?>
	          <?php if ($where->firma_twitter) { ?>
	            <li><a href="<?=$where->firma_twitter?>" class="twitter-profile"><i class="fa fa-twitter"></i> Twitter</a></li>
	          <?php } ?>
	          <?php if ($where->firma_instagram) { ?>
	            <li><a href="<?=$where->firma_instagram?>" class="instagram-profile"><i class="fa fa-instagram"></i> İnstagram</a></li>
	          <?php } ?>
	        </ul>

	      </div>
      <?php } ?>
      <!-- Contact / End-->


      <!-- Share / Like -->
      <div class="listing-share margin-top-40 margin-bottom-40 no-border">
        <?php if (aktif_kullanici()) { ?>
              <button class="item-favorite-button item-favorite-enable like-button" data-product-id="<?=$where->firma_id; ?>"><span class="like-icon <?php if(favoriekle($kullanici->kullanici_id, $where->firma_id) == true){ echo "liked"; } ?>"></span> Favorilere Ekle</button>
        <?php }else{ ?>
              <button class="like-button"><span class="like-icon"></span> Favorilere Ekle</button>
        <?php } ?>
        <span>Bu Firmayı Favorilerinize Ekleyebilirsiniz</span>

          <div class="clearfix"></div>
      </div>

    </div>
    <!-- Sidebar / End -->

  </div>
</div>
<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCCKWWLQs2S3C0q-Qqp7m2nP-c0flEjA64&sensor=false&libraries=places"></script>