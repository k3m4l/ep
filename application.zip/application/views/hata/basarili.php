<section class="not-found-page section-padding">
   <div class="container">
      <div class="row">
         <div class="col-md-8 mx-auto text-center  pt-4 pb-5">
            <h1 style="color: #0cc5b7;">Ödeme Başarılı!</h1>
            <p class="land">Ödemeniz Başarılı Şekilde Yapıldı! Siparişlerinizi Takip Etmek İçin Sipariş Takip Bölümünden Yapabilirsiniz. <br>Sipariş Takip Numaranız : <b><?=$siparis->siparis_takipno?></b></p>
            <div class="mt-5">
               <a href="<?=base_url("odeme/$where->paket_seo/$siparis->siparis_takipno")?>" class="btn btn-success btn-lg"><i class="mdi mdi-credit-card-multiple"></i> Sipariş Detay</a>
            </div>
         </div>
      </div>
   </div>
</section>