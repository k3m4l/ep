<section class="not-found-page section-padding">
   <div class="container">
      <div class="row">
         <div class="col-md-8 mx-auto text-center  pt-4 pb-5">
            <h1 style="color: #ff4e4e;">Ödeme İşlemi Başarısız Oldu!</h1>
            <p class="land">Ödemeniz Başarısız Oldu. Siparişinizi Tamamlayamadık. <br>Lütfen Site Yöneticileri İletişime Geçin!</p>
            <div class="mt-5">
               <a href="<?=base_url("destek-sistemi")?>" class="btn btn-success btn-lg"><i class="mdi mdi-comment-alert-outline"></i> Destek Sistemi</a> - <a href="<?=base_url("odeme/$where->paket_seo/$siparis->siparis_takipno")?>" class="btn btn-success btn-lg"><i class="mdi mdi-credit-card-multiple"></i> Siparişe Dön</a>
            </div>
         </div>
      </div>
   </div>
</section>