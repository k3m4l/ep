<?php 

$kategoriler = kategoricek();
$ayarlar = ayarlar();

?>
<style type="text/css">
	#map {
    width: 100%;
    height: 400px;
	}
</style>
<div id="titlebar" class="gradient">
	<div class="container">
		<div class="row">
			<div class="col-md-12">

				<h2><i class="sl sl-icon-plus"></i> Firma Ekle</h2>

				<!-- Breadcrumbs -->
				<nav id="breadcrumbs">
					<ul>
						<li><a href="<?=base_url()?>">Anasayfa</a></li>
						<li>Firma Ekle</li>
					</ul>
				</nav>

			</div>
		</div>
	</div>
</div>


<!-- Content
================================================== -->


<!-- Container -->
<div class="container">

		<div class="row">
			<div class="col-lg-12">

				<?php if (!aktif_kullanici()) { ?>

					<div class="notification notice large margin-bottom-55">
						<h4>Hesabınız yok mu? 🙂</h4>
						<p>Bir hesabınız yoksa, firma bilgilerinizi doldurduktan sonra en son aşamada bilgilerinizi doldurarak hem firmanızı ekleyin hemde hızlı bir şekilde üyelik oluşturun. Üyelikler tamamen ücretsizdir.</p>
					</div>

				<?php } ?>

				<form method="post" action="<?=base_url("firmaekle")?>" enctype="multipart/form-data">

					<div id="add-listing" class="separated-form">

						<!-- Section -->
						<div class="add-listing-section">

							<!-- Headline -->
							<div class="add-listing-headline">
								<h3><i class="sl sl-icon-doc"></i> Firma Bilgileri</h3>
							</div>

							<!-- Title -->
							<div class="row with-forms">
								<div class="col-md-12">
									<h5>Firma Adı <i class="tip" data-tip-content="Firmanızın adını girerek daha fazla kişiye ulaşın."></i></h5>
									<input class="search-field" type="text" name="firmaad" placeholder="Firma Adı.." required="" />
								</div>
							</div>

							<!-- Row -->
							<div class="row with-forms">

								<!-- Status -->
								<div class="col-md-6">
									<h5>Kategoriler</h5>
									<select class="chosen-select-no-single" name="kategori" required="">
										<option label="blank" value="">Kategori Seçin</option>
										<?php foreach ($kategoriler as $key) { ?>
											<option value="<?=$key->kategori_id?>"><?=$key->kategori_ad?></option>
										<?php } ?>
									</select>
								</div>

								<!-- Type -->
								<div class="col-md-6">
									<h5>Firma Anahtar Kelimeler <i class="tip" data-tip-content="Firmanıza ait anahtar kelimeler eklemeniz daha fazla kişiye ulaşmanızı sağlar. Örn : rota bisiklet, bisikletçi, bisiklet tamiri"></i></h5>
									<input type="text" name="anahtar" placeholder="En fazla 15 tane anahtar kelime ekleyiniz..">
								</div>

							</div>
							<!-- Row / End -->

						</div>
						<!-- Section / End -->

						<!-- Section -->
						<div class="add-listing-section margin-top-45">

							<!-- Headline -->
							<div class="add-listing-headline">
								<h3><i class="sl sl-icon-location"></i> Adres ve Harita</h3>
							</div>

							<div class="submit-section">

								<!-- Row -->
								<div class="row with-forms">
									<div class="col-md-12">
										<small><code>Haritada seçtiğiniz nokta otomatik olarak adresi almaktadır.</code></small>
									</div>
									<div class="col-md-12">
										<h5>Haritada Ara</h5>
										<input id="searchInput" class="controls" type="text" placeholder="Haritada ara..">
									</div>

									<div class="col-md-12">
										<div class="map" id="map"></div>
									</div>

									<div class="col-md-12" id="form_area">
										<input type="hidden" name="adres" id="location" value="">
										<input type="hidden" name="lat" id="lat" value="">
										<input type="hidden" name="lng" id="lng" value="">
									</div>

								</div>
								<!-- Row / End -->

							</div>
						</div>
						<!-- Section / End -->


						<!-- Section -->
						<div class="add-listing-section margin-top-45">

							<!-- Headline -->
							<div class="add-listing-headline">
								<h3><i class="sl sl-icon-picture"></i> Firma Kapak Fotoğrafı</h3>
							</div>

							<div class="row with-forms">
								<div class="col-md-12">
									<h5>Kapak Fotoğrafı <i class="tip" data-tip-content="Firma listelemesinde nasıl görünmek istersin?"></i></h5>
									<input class="search-field" type="file" name="file" accept=".jpg, .png, .jpeg" placeholder="Firma Kapak Fotoğrafı.." required="" />
								</div>
							</div>

							<!-- Dropzone -->
							<div class="notification warning closeable text-center"><p>Firma Galerisi Eklemek İçin İşlemleri Tamamlayın..</p></div>

						</div>
						<!-- Section / End -->


						<!-- Section -->
						<div class="add-listing-section margin-top-45">

							<!-- Headline -->
							<div class="add-listing-headline">
								<h3><i class="sl sl-icon-docs"></i> Detaylar</h3>
							</div>

							<!-- Description -->
							<div class="form">
								<h5>Tanıtım Yazısı</h5>
								<textarea class="WYSIWYG" name="tanitim" cols="40" rows="3" spellcheck="true" placeholder="Firma Tanıtım Yazısı"></textarea>
							</div>

							<!-- Row -->
							<div class="row with-forms">

								<!-- Phone -->
								<div class="col-md-4">
									<h5>Telefon Numarası <span>(isteğe bağlı)</span></h5>
									<input type="number" name="tel" placeholder="Örn : 05xxxxxxxxx">
								</div>

								<!-- Website -->
								<div class="col-md-4">
									<h5>Web Site <span>(isteğe bağlı)</span></h5>
									<input type="text" name="website" placeholder="Örn : https://siteadresi.com.tr">
								</div>

								<!-- Email Address -->
								<div class="col-md-4">
									<h5>E-Posta <span>(isteğe bağlı)</span></h5>
									<input type="text" name="mail" placeholder="Örn : info@siteadresi.com.tr">
								</div>

							</div>
							<!-- Row / End -->


							<!-- Row -->
							<div class="row with-forms">

								<!-- Phone -->
								<div class="col-md-4">
									<h5 class="fb-input"><i class="fa fa-facebook-square"></i> Facebook <span>(isteğe bağlı)</span></h5>
									<input type="text" name="facebook" placeholder="https://www.facebook.com/">
								</div>

								<!-- Website -->
								<div class="col-md-4">
									<h5 class="twitter-input"><i class="fa fa-twitter"></i> Twitter <span>(isteğe bağlı)</span></h5>
									<input type="text" name="twitter" placeholder="https://www.twitter.com/">
								</div>

								<!-- Email Address -->
								<div class="col-md-4">
									<h5 class="gplus-input"><i class="fa fa-instagram"></i> İnstagram <span>(isteğe bağlı)</span></h5>
									<input type="text" name="instagram" placeholder="https://instagram.com/">
								</div>

							</div>
							<!-- Row / End -->


							<!-- Checkboxes -->
							<h5 class="margin-top-30 margin-bottom-10">Firma Hizmetleri <span>(isteğe bağlı)</span></h5>
							<div class="row with-forms">


								<div class="row">
									<div class="col-md-12">
										<table id="pricing-list-container">

										</table>
										<a href="#" class="button add-pricing-submenu">Yeni Hizmet Ekle</a>
									</div>
								</div>

							</div>

						</div>
						<!-- Section / End -->


						<!-- Section -->
						<div class="add-listing-section margin-top-45">
							
							<!-- Headline -->
							<div class="add-listing-headline">
								<h3><i class="sl sl-icon-clock"></i> Çalışma Saatleri</h3>
							</div>

								<!-- Day -->
								<div class="row opening-day">
									<div class="col-md-2"><h5>Hafta İçi</h5></div>
									<div class="col-md-5">
										<select class="chosen-select" name="haftaicisabah" data-placeholder="Açılış Saati">
											<option label="Açılış Saati"></option>
											<option>Kapalı</option>
											<option>24 Saat Açık</option>
											<option>06:00</option>
											<option>07:00</option>
											<option>08:00</option>
											<option>09:00</option>
											<option>10:00</option>
											<option>11:00</option>
											<option>12:00</option>
											<option>13:00</option>
											<option>14:00</option>
											<option>15:00</option>
											<option>16:00</option>
											<option>17:00</option>
										</select>
									</div>
									<div class="col-md-5">
										<select class="chosen-select" name="haftaiciaksam" data-placeholder="Kapanış Saati">
											<option label="Kapanış Saati"></option>
											<option>Kapalı</option>
											<option>24 Saat Açık</option>
											<option>06:00</option>
											<option>07:00</option>
											<option>08:00</option>
											<option>09:00</option>
											<option>10:00</option>
											<option>11:00</option>
											<option>12:00</option>
											<option>13:00</option>
											<option>14:00</option>
											<option>15:00</option>
											<option>16:00</option>
											<option>17:00</option>
											<option>18:00</option>
											<option>19:00</option>
											<option>20:00</option>
											<option>21:00</option>
											<option>22:00</option>
											<option>23:00</option>
											<option>00:00</option>
										</select>
									</div>
								</div>

								<div class="row opening-day">
									<div class="col-md-2"><h5>Hafta Sonu</h5></div>
									<div class="col-md-5">
										<select class="chosen-select" name="haftasonusabah" data-placeholder="Açılış Saati">
											<option label="Açılış Saati"></option>
											<option>Kapalı</option>
											<option>24 Saat Açık</option>
											<option>06:00</option>
											<option>07:00</option>
											<option>08:00</option>
											<option>09:00</option>
											<option>10:00</option>
											<option>11:00</option>
											<option>12:00</option>
											<option>13:00</option>
											<option>14:00</option>
											<option>15:00</option>
											<option>16:00</option>
											<option>17:00</option>
										</select>
									</div>
									<div class="col-md-5">
										<select class="chosen-select" name="haftasonuaksam" data-placeholder="Kapanış Saati">
											<option label="Kapanış Saati"></option>
											<option>Kapalı</option>
											<option>24 Saat Açık</option>
											<option>06:00</option>
											<option>07:00</option>
											<option>08:00</option>
											<option>09:00</option>
											<option>10:00</option>
											<option>11:00</option>
											<option>12:00</option>
											<option>13:00</option>
											<option>14:00</option>
											<option>15:00</option>
											<option>16:00</option>
											<option>17:00</option>
											<option>18:00</option>
											<option>19:00</option>
											<option>20:00</option>
											<option>21:00</option>
											<option>22:00</option>
											<option>23:00</option>
											<option>00:00</option>
										</select>
									</div>
								</div>
								<!-- Day / End -->

						</div>
						<!-- Section / End -->

						<?php if (!aktif_kullanici()) { ?>

							<div class="add-listing-section margin-top-45">

								<!-- Headline -->
								<div class="add-listing-headline">
									<h3><i class="sl sl-icon-doc"></i> Üyelik Oluştur <i class="tip" data-tip-content="Firmanızı sahiplenmek istiyorsanız üye olmanız gerekmektedir."></i></h3>
								</div>

								<!-- Title -->
								<div class="row with-forms">
									<div class="col-md-6">
										<h5>Adınız</h5>
										<input class="search-field" type="text" placeholder="Adınız" name="kullanici_isim" required="" />
									</div>
									<div class="col-md-6">
										<h5>Soyadınız</h5>
										<input class="search-field" type="text" placeholder="Soyadınız" name="kullanici_soyisim" required="" />
									</div>
								</div>
								<div class="row with-forms">
									<div class="col-md-4">
										<h5>E-Posta Adresiniz</h5>
										<input class="search-field" type="text" placeholder="E-Posta Adresiniz" name="kullanici_mail" required="" />
									</div>
									<div class="col-md-4">
										<h5>Kullanıcı Adı <i class="tip" data-tip-content="Site girişlerinde kullanılacaktır."></i></h5>
										<input class="search-field" type="text" placeholder="Kullanıcı Adı" name="kullanici_ad" required="" />
									</div>
									<div class="col-md-4">
										<h5>Şifre</h5>
										<input class="search-field" type="password" name="kullanici_sifre" placeholder="Şifre (minimum 7 karakter)" required="" />
									</div>
								</div>

							</div>

						<?php } ?>

						<div class="g-recaptcha" style="margin-top: 10px; margin-bottom: 10px" data-sitekey="<?php print_r($google_key); ?>"></div>

						<button type="submit" class="button preview">Firma Ekle <i class="fa fa-arrow-circle-right"></i></button>

					</div>

				</form>
			</div>

		</div>

	</div>