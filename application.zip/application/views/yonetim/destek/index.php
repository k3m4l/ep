
<div class="br-pageheader pd-y-15 pd-md-l-20">
  <nav class="breadcrumb pd-0 mg-0 tx-12">
    <a class="breadcrumb-item" href="<?=base_url(admin_url())?>">Kontrol Paneli</a>
    <span class="breadcrumb-item active">Destek Talepleri</span>
  </nav>
</div>
<!-- br-pageheader -->

<div class="br-pagetitle">
  <i class="far fa-life-ring fa-4x"></i>
  <div>
    <h4>Destek Talepleri</h4>
    <p class="mg-b-0">Müşterilerinizin sorunlarını ve saorularını yanıtlayabilirsiniz.</p>
  </div>
</div>
<!-- d-flex -->

<div class="d-flex align-items-center justify-content-start pd-x-20 pd-sm-x-30 pd-t-25 mg-b-20 mg-sm-b-30">

  <div class="mg-l-auto">
    <a href="<?=base_url(admin_url()."kdestek")?>" class="btn btn-danger">Kapatılan Talepler</a>
    <a href="javascript:void(0)" data-toggle="modal" data-target="#destekekle" class="btn btn-success"><i class="fas fa-plus"></i> Destek Konu Ekle</a>
    <a href="javascript:void(0)" data-toggle="modal" data-target="#destekler" class="btn btn-info"><i class="fas fa-search"></i> Destek Konuları</a>
  </div>

</div>

<div id="destekekle" class="modal fade" aria-hidden="true" style="display: none;">
  <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
    <div class="modal-content bd-0 bg-transparent rounded overflow-hidden">
      <div class="modal-body pd-0">
        <div class="row no-gutters">
          <div class="col-lg-12 bg-white">
            <div class="pd-30">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">×</span>
              </button>
              <form action="<?=base_url(admin_url()."konuekle")?>" method="post">
                <div class="pd-x-30 pd-y-10">
                  <h3 class="tx-inverse  mg-b-5">Destek Konusu Ekle</h3>
                  <p>Müşterilerin Sorunları İle Alakalı Konular Ekleyin!</p>
                  <br>
                  <div class="form-group mg-b-20">
                    <input type="text" name="ad" class="form-control pd-y-12" placeholder="Destek Konusu">
                  </div><!-- form-group -->

                  <button class="btn btn-primary pd-y-12 btn-block">Ekle</button>
                </div>
              </form>
            </div><!-- pd-20 -->
          </div><!-- col-6 -->
        </div><!-- row -->

      </div><!-- modal-body -->
    </div><!-- modal-content -->
  </div><!-- modal-dialog -->
</div>

<div id="destekler" class="modal fade" aria-hidden="true" style="display: none;">
  <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
    <div class="modal-content bd-0 bg-transparent rounded overflow-hidden">
      <div class="modal-body pd-0">
        <div class="row no-gutters">
          <div class="col-lg-12 bg-white">
            <div class="pd-30">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">×</span>
              </button>
              <?php $konular = konular(); ?>
              <table class="table">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Konu Adı</th>
                    <th>İŞLEM</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $i=0; foreach ($konular as $key) { $i++; ?>
                    <tr>
                      <th scope="row"><?=$i?></th>
                      <td><?=$key->konu_ad?></td>
                      <td>
                        <a href="javascript:void(0)" data-url="<?=base_url(admin_url()."konusil/$key->konu_id")?>" class="btn btn-danger btn-with-icon remove-btn">
                          <div class="ht-40">
                            <span class="icon far fa-trash-alt wd-40"><i class="fa fa-send"></i></span>
                            <span class="pd-x-15">Sil</span>
                          </div>
                        </a>
                      </td>
                    </tr>
                  <?php } ?>
                </tbody>
              </table>
            </div><!-- pd-20 -->
          </div><!-- col-6 -->
        </div><!-- row -->

      </div><!-- modal-body -->
    </div><!-- modal-content -->
  </div><!-- modal-dialog -->
</div>
<!-- d-flex -->

<div class="br-pagebody">
  <div class="br-section-wrapper">
    <div class="table-wrapper">
      <table id="datatable1" class="table display responsive nowrap">
        <thead>
          <tr>
            <th class="wd-5p text-center">#</th>
            <th class="wd-15p text-center">GONDEREN</th>
            <th class="wd-15p text-center">TELEFON</th>
            <th class="wd-15p text-center">KONU</th>
            <th class="wd-15p text-center">DESTEK AÇ/KAPA</th>
            <th class="wd-10p text-center">DESTEK İŞLEM</th>
          </tr>
        </thead>
        <tbody>
          <?php $destek = destek(); ?>
          <?php if ($destek) { ?>
            <?php $i=0; foreach ($destek as $key) { $i++; ?>
              <tr>
                <td class="text-center"><?=$i?></td>
                <td class="text-center">
                  <img src="https://via.placeholder.com/500" class="wd-40 rounded-circle" alt="">
                  <div class="mg-l-15">
                    <div class="tx-inverse"><?=$key->destek_adsoy?></div>
                    <span class="tx-12"><?=$key->destek_mail?></span>
                  </div>
                </td>
                <td class="text-center"><?=$key->destek_tel?></td>
                <td class="text-center"><?=$key->konu_ad?></td>
                <td class="text-center">
                  <label class="switch">
                    <input class="durum" data-url="<?=base_url(admin_url()."destekdurum/$key->destek_id")?>" type="checkbox" <?php if ($key->destek_durum==1){ echo 'checked'; } ?>>
                    <span class="slider2 round2"></span>
                  </label>
                </td>
                <td class="text-center">
                  <a href="<?=base_url(admin_url()."destek-oku/$key->destek_id")?>" class="btn btn-info btn-with-icon">
                    <div class="ht-40">
                      <span class="icon far fa-eye wd-40"><i class="fa fa-send"></i></span>
                      <span class="pd-x-15">Oku</span>
                    </div>
                  </a>
                  <a href="javascript:void(0)" data-url="<?=base_url(admin_url()."desteksil/$key->destek_id")?>" class="btn btn-danger btn-with-icon remove-btn">
                    <div class="ht-40">
                      <span class="icon far fa-trash-alt wd-40"><i class="fa fa-send"></i></span>
                      <span class="pd-x-15">Sil</span>
                    </div>
                  </a>
                </td>
              </tr>
            <?php } ?>
          <?php } ?>
        </tbody>
      </table>
    </div><!-- table-wrapper -->
  </div><!-- br-section-wrapper -->
</div>
<br>
<br>