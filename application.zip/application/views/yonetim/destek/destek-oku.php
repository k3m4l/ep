<div class="br-pageheader">
	<nav class="breadcrumb pd-0 mg-0 tx-12">
		<a class="breadcrumb-item" href="<?=base_url(admin_url())?>">Kontrol Paneli</a>
		<a class="breadcrumb-item" href="<?=base_url(admin_url()."destek")?>">Destek Talepleri</a>
		<span class="breadcrumb-item active">Destek Detay</span>
	</nav>
</div><!-- br-pageheader -->
<div class="br-pagetitle">
	<i class="far fa-life-ring fa-4x"></i>
	<div>
		<h4>Destek Talepleri</h4>
		<p class="mg-b-0">Gelen destek taleplerini yanıtlayabilirsiniz.</p>
	</div>
</div><!-- d-flex -->

<div class="br-pagebody">
	<div class="br-section-wrapper">
		<form action="<?=base_url(admin_url()."destekcevap"); ?>" method="post">
			<div class="form-layout form-layout-1">
				<div class="row mg-b-25">
					<div class="col-lg-4">
						<div class="form-group">
							<label class="form-control-label">Müşteri Ad Soyad <span class="tx-danger">*</span></label>
							<input class="form-control" type="text" placeholder="Müşteri Ad Soyad" value="<?=$where->destek_adsoy?>" disabled>
						</div>
					</div><!-- col-4 -->
					<div class="col-lg-4">
						<div class="form-group">
							<label class="form-control-label">Müşteri E-Posta <span class="tx-danger">*</span></label>
							<input class="form-control" type="text" placeholder="Müşteri E-Posta" value="<?=$where->destek_mail?>" disabled>
						</div>
					</div><!-- col-4 -->
					<div class="col-lg-4">
						<div class="form-group">
							<label class="form-control-label">Müşteri Telefon <span class="tx-danger">*</span></label>
							<input class="form-control" type="text" placeholder="Müşteri Telefon" value="<?=$where->destek_tel?>" disabled>
						</div>
					</div><!-- col-4 -->
					<div class="col-lg-4">
						<div class="form-group">
							<label class="form-control-label">Destek Konusu <span class="tx-danger">*</span></label>
							<input class="form-control" type="text" placeholder="Destek Konusu" value="<?=$where->konu_ad?>" disabled>
						</div>
					</div><!-- col-4 -->
					<div class="col-lg-4">
						<div class="form-group">
							<label class="form-control-label">Destek Durum <span class="tx-danger">*</span></label>
							<input class="form-control" type="text" value="<?php if($where->destek_durum==1){ echo "Kapatıldı"; }elseif($where->destek_durum==0){ echo "Cevap Bekliyor.."; } ?>" disabled>
						</div>
					</div><!-- col-4 -->
					<div class="col-lg-4">
						<div class="form-group">
							<label class="form-control-label">Gönderen IP <span class="tx-danger">*</span></label>
							<input class="form-control" type="text" value="<?=$where->destek_ip?>" disabled>
						</div>
					</div><!-- col-4 -->
					<div class="col-lg-6">
						<div class="form-group">
							<label class="form-control-label">Gönderen Tarayıcı <span class="tx-danger">*</span></label>
							<input class="form-control" type="text" value="<?=$where->destek_tarayici?>" disabled>
						</div>
					</div><!-- col-4 -->
					<div class="col-lg-6">
						<div class="form-group">
							<label class="form-control-label">Gönderen İşletim Sistemi <span class="tx-danger">*</span></label>
							<input class="form-control" type="text" value="<?=$where->destek_isletim?>" disabled>
						</div>
					</div><!-- col-4 -->
					<div class="col-lg-12">
						<div class="form-group">
							<label class="form-control-label">Destek Mesajı <span class="tx-danger">*</span></label>
							<textarea class="form-control" type="text" disabled><?=$where->destek_mesaj?></textarea> 
						</div>
					</div><!-- col-4 -->
					<input type="hidden" name="alan" value="<?=$where->destek_mail?>">
					<input type="hidden" name="konu" value="<?=$where->konu_ad?>">
					<div class="col-lg-12">
						<div class="form-group">
							<label class="form-control-label">Destek Talebini Cevapla <span class="tx-danger">*</span> <small><code>Bu Mesaj Kullanıcının E-Posta Adresine Gönderilmektedir.</code></small></label>
							<textarea class="form-control" type="text" name="mesaj" placeholder="Mesajınız" rows="5"></textarea> 
						</div>
					</div><!-- col-4 -->

				</div>

				<div class="form-layout-footer">
					<button type="submit" class="btn btn-info">Cevap Gönder</button>
				</div><!-- form-layout-footer -->
			</div>
		</form><!-- form-layout -->
	</div>
</div>