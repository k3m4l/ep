
<div class="br-pageheader pd-y-15 pd-md-l-20">
    <nav class="breadcrumb pd-0 mg-0 tx-12">
        <a class="breadcrumb-item" href="<?=base_url(admin_url())?>">Kontrol Paneli</a>
        <span class="breadcrumb-item active">Kapatılan Destek Talepleri</span>
    </nav>
</div>
<!-- br-pageheader -->

<div class="br-pagetitle">
    <i class="far fa-life-ring fa-4x"></i>
    <div>
        <h4>Kapatılan Destek Talepleri</h4>
        <p class="mg-b-0">Müşterilerinizin sorunlarını ve saorularını yanıtlayabilirsiniz.</p>
    </div>
</div>
<!-- d-flex -->

<div class="d-flex align-items-center justify-content-start pd-x-20 pd-sm-x-30 pd-t-25 mg-b-20 mg-sm-b-30">

    <div class="mg-l-auto">
        <a href="<?=base_url(admin_url()."destek")?>" class="btn btn-warning">Bekleyen Talepler</a>
    </div>

</div>
<!-- d-flex -->

<div class="br-pagebody">
  <div class="br-section-wrapper">
    <div class="table-wrapper">
      <table id="datatable1" class="table display responsive nowrap">
        <thead>
          <tr>
            <th class="wd-5p text-center">#</th>
            <th class="wd-15p text-center">GONDEREN</th>
            <th class="wd-15p text-center">TELEFON</th>
            <th class="wd-15p text-center">KONU</th>
            <th class="wd-15p text-center">DESTEK AÇ/KAPA</th>
            <th class="wd-10p text-center">DESTEK İŞLEM</th>
        </tr>
    </thead>
    <tbody>
      <?php $destek = kdestek(); ?>
      <?php if ($destek) { ?>
        <?php $i=0; foreach ($destek as $key) { $i++; ?>
          <tr>
            <td class="text-center"><?=$i?></td>
            <td class="text-center">
                <img src="https://via.placeholder.com/500" class="wd-40 rounded-circle" alt="">
                <div class="mg-l-15">
                    <div class="tx-inverse"><?=$key->destek_adsoy?></div>
                    <span class="tx-12"><?=$key->destek_mail?></span>
                </div>
            </td>
            <td class="text-center"><?=$key->destek_tel?></td>
            <td class="text-center"><?=$key->konu_ad?></td>
            <td class="text-center">
              <label class="switch">
                <input class="durum" data-url="<?=base_url(admin_url()."destekdurum/$key->destek_id")?>" type="checkbox" <?php if ($key->destek_durum==1){ echo 'checked'; } ?>>
                <span class="slider2 round2"></span>
            </label>
        </td>
        <td class="text-center">
            <a href="<?=base_url(admin_url()."destek-oku/$key->destek_id")?>" class="btn btn-info btn-with-icon">
                <div class="ht-40">
                  <span class="icon far fa-eye wd-40"><i class="fa fa-send"></i></span>
                  <span class="pd-x-15">Oku</span>
              </div>
          </a>
          <a href="javascript:void(0)" data-url="<?=base_url(admin_url()."desteksil/$key->destek_id")?>" class="btn btn-danger btn-with-icon remove-btn">
            <div class="ht-40">
              <span class="icon far fa-trash-alt wd-40"><i class="fa fa-send"></i></span>
              <span class="pd-x-15">Sil</span>
          </div>
      </a>
  </td>
</tr>
<?php } ?>
<?php } ?>
</tbody>
</table>
</div><!-- table-wrapper -->
</div><!-- br-section-wrapper -->
</div>
<br>
<br>