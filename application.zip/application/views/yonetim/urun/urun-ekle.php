<div class="br-pageheader">
    <nav class="breadcrumb pd-0 mg-0 tx-12">
        <a class="breadcrumb-item" href="<?= base_url(admin_url()) ?>">Kontrol Paneli</a>
        <a class="breadcrumb-item" href="<?= base_url(admin_url() . 'urunler') ?>">Mağazalar</a>
        <span class="breadcrumb-item active">Ürün Ekle</span>
    </nav>
</div><!-- br-pageheader -->
<div class="br-pagetitle">
    <i class="fas fa-store fa-4x"></i>
    <div>
        <h4>Ürün Ekle</h4>
    </div>
</div><!-- d-flex -->

<div class="br-pagebody">
    <div class="br-section-wrapper">
        <form action="<?= base_url('yonetim_magaza_controller/urunekle') ?>" method="post" enctype="multipart/form-data">

            <!-- Form -->
            <div class="row">
                <div class="form-group col-md-12">
                    <!-- Title -->
                    <label for="postTitle" class="form-label">Ürün Adı</label>
                    <input type="text" name="urun_ad" class="form-control text-dark" placeholder="Ürün Adı" value="<?= set_value('urun_ad'); ?>" required />
                    <small>Lütfen özel karakter kullanmamaya çalışın ve yazım kurallarına göre
                        başlık yazın.</small>
                    <?php echo form_error('urun_ad', '<div class="error_input">', '</div>'); ?>
                </div>

                <div class="col-md-12" id="teslimturu">
                    <label for="">Teslim Türü</label>
                    <select class="form-control" name="teslim_turu" id="teslim_turu" required>
                        <option value="1">Manuel</option>
                        <option value="2">Türkpin</option>
                    </select>
                </div>

                <div class="col-md-6 d-none" id="turkpinkategori">
                    <label for="">Türkpin Kategori</label>
                    <select class="form-control" name="urunlistesi" id="urunlistesi"></select>
                </div>

                <div class="col-md-12 d-none" id="turkpinurunlistesi">
                    <label for="">Türkpin Ürün Listesi</label>
                    <select name="turkpinurunler" id="turkpinurunler" class="form-control"></select>
                </div>
                <script>
                    $(document).ready(function() {
                        $('#teslim_turu').on('change', function() {
                            if (this.value == '2') {
                                $('#turkpinkategori').removeClass('d-none');
                                $('#turkpinurunlistesi').removeClass('d-none');
                                $('#teslimturu').removeClass('col-md-12');
                                $('#teslimturu').addClass('col-md-6');
                                console.log('2');
                                //Ajax post
                                $.ajax({
                                    url: '<?= base_url('turkpin-kategori-post') ?>',
                                    type: 'POST',
                                    data: {
                                        eren: 1,
                                    },
                                    success: function(data) {
                                        //data each
                                        $('#urunlistesi').empty();
                                        var epinlist = data.epinlist;
                                        epinlist.forEach(element => {
                                            $('#urunlistesi').append('<option value="' + element.id + '">' + element.name + '</option>');
                                        });
                                    },
                                    error: function() {
                                        alert('Hata');
                                    }
                                });
                            } else {
                                $('#turkpinkategori').addClass('d-none');
                                $('#turkpinurunlistesi').addClass('d-none');
                                $('#teslimturu').removeClass('col-md-6');
                                $('#teslimturu').addClass('col-md-12');
                            }
                        });

                        $('#urunlistesi').on('change', function() {
                            var epin_id = this.value;
                            $.ajax({
                                url: '<?= base_url('turkpin-urun-post') ?>',
                                type: 'POST',
                                data: {
                                    epin_id: epin_id,
                                },
                                success: function(data) {
                                    //data each
                                    $('#turkpinurunler').empty();
                                    //console.log(data);
                                    var epinlist = data.epinlist;
                                    $('#turkpinurunler').append('<option>Lütefen Seçim Yapınız...</option>');
                                    epinlist.forEach(element => {
                                        $('#turkpinurunler').append('<option value="' + element.id + '" data-stock="'+element.stock+'">Ürün Adı: ' + element.name + ' - Ürün Stok: ' + element.stock + ' - Fiyat: ' + element.price + '</option>');
                                    });
                                },
                                error: function() {
                                    alert('Hata');
                                }
                            });
                        });

                        $('#turkpinurunler').on('change', function() {
                            var stock = $('#turkpinurunler option:selected').data('stock');
                            $('input[name="urun_stok"]').val(stock);
                        });
                    });
                </script>

                <div class="form-group col-md-12 mt-3">
                    <label class="form-label">Ürün Kategorisi</label>
                    <select class="form-control kategori" data-width="100%" name="kategori[]" multiple="multiple" required onchange="komisyonchange(this.value)">
                        <?php foreach (fetchCategoryTree() as $cl) { ?>
                            <option value="<?php echo $cl["id"] ?>"><?php echo $cl["name"]; ?></option>
                        <?php } ?>
                    </select>
                    <?php echo form_error('kategori', '<div class="error_input">', '</div>'); ?>
                </div>

                <div class="form-group col-md-12">
                    <label class="form-label">Ürün Türü</label>
                    <select class="form-control" id="urun_turu" data-width="100%" name="urun_turu" required>
                        <option hidden="">Ürün Türü Seçin..</option>
                        <option value="1">Fiziksel Ürün</option>
                        <option value="2">Sanal Ürün</option>
                        <option value="3">İndirilebilir Ürün</option>
                    </select>
                    <?php echo form_error('urun_turu', '<div class="error_input">', '</div>'); ?>
                </div>
                <?php if (1 == 2) { ?>
                <div class="form-group col-md-12 sanal_urun_bilgileri" style="display: none;">
                    <!-- Title -->
                    <label class="form-label">Sanal Ürün Bilgileri</label>
                    <textarea type="text" name="sanal_urun_bilgileri" class="form-control text-dark" id="sanal_urun_bilgileri" placeholder="Sanal Ürün Bilgileri"></textarea>
                    <small>Ürün bilgileri ödeme yapıldıktan sonra otomatik olarak kişiye
                        görünecektir.</small>
                </div>
                <?php } ?>
                <div class="form-group col-md-12 indirilebilir" style="display: none;">
                    <label class="input-label">İndirilecek Ürün</label>
                    <div class="custom-file">
                        <input type="file" name="dosya" id="dosya" class="custom-file-input" accept=".zip" onchange="getFileData(this);">
                        <label class="custom-file-label" for="dosya">Dosya Seç</label>
                    </div>
                    <small>Ürün bilgileri ödeme yapıldıktan sonra otomatik olarak kişiye
                        görünecektir. Sadece <span class="badge badge-danger badge-pill badge-sm">.zip</span> dosya türü desteklenmektedir.</small>
                    <div class="card mt-2" id="dosya_goster" style="display: none">
                        <div class="p-3 d-flex justify-content-between">
                            <div>
                                <i class="fe fe-file"></i> <span class="dosya_adi"></span> / <small class="dosya_size"></small>
                            </div>
                            <div>
                                <a href="javascript:void(0)" id="dosya_sil"><i class="fe fe-x"></i></a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="form-group col-md-12 fiziksel" style="display: none;">
                    <!-- Title -->
                    <label for="postTitle" class="form-label">Ürün Markası <small>(İsteğe
                            Bağlı)</small></label>
                    <input type="text" name="urun_marka" class="form-control text-dark" placeholder="Ürün Markası" />
                </div>

                <div class="form-group col-md-12  mb-5">
                    <label class="form-label">Ürün Vitrin Fotoğrafı</label>
                    <div class="custom-file">
                        <input type="file" class="custom-file-input" id="vitrin" name="file" accept=".jpg, .jpeg, .png" onchange="getPhotoData(this);" required>
                        <label class="custom-file-label" for="vitrin">Ürün Vitrin
                            Fotoğrafı</label>
                        <small>Sadece <span class="badge badge-danger badge-pill badge-sm">.png/.jpg/.jpeg</span> dosya türü
                            desteklenmektedir.</small>
                        <div class="card mt-2" id="resim_goster" style="display: none">
                            <div class="p-3 d-flex justify-content-between">
                                <div>
                                    <i class="fe fe-file"></i> <span class="resim_adi"></span> /
                                    <small class="resim_size"></small>
                                </div>
                                <div>
                                    <a href="javascript:void(0)" id="resim_sil"><i class="fe fe-x"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="form-group col-md-4">
                    <label for="postTitle" class="form-label">Ürün Stok *</label>
                    <input name="urun_stok" type="number" class="form-control text-dark" placeholder="Ürün Stok" required />
                </div>
                
                <div class="form-group col-md-4">
                    <label for="form-label">Ürün Eski Fiyatı</label>
                    <input class="form-control text-left" type="number" name="eski_fiyat" step="any" value="0" id="eski_fiyat">
                    <div class="mt-2 text-center">
                        <span class="badge badge-success d-flex">İndirim Oranı&nbsp;<div id="indirim_yuzdesi">Yok</div></span>
                    </div>
                </div>

                <div class="form-group col-md-4">
                    <label class="form-label" for="currency">Ürün Fiyatı</label>
                    <input class="form-control text-left" type="number" name="fiyat" step="any" value="<?= set_value('fiyat'); ?>" placeholder="Ürün Fiyatı" id="fiyat" required>
                    <?php echo form_error('fiyat', '<div class="error_input">', '</div>'); ?>
                    <div class="mt-2 text-center" style="display:none;">
                        <span class="badge badge-success d-flex flex-column">
                            <div class="d-flex justify-content-between align-items-center text-center">
                                <span class="font-size-md">Hesabınıza Geçecek Kazanç :</span>
                                <span class="font-size-md font-weight-bold" id="kazanc">
                                    0.00 ₺
                                </span>
                            </div>
                            <div class="d-flex justify-content-between align-items-center text-center mt-1">
                                <span>Komisyon Oranı :</span>
                                <span class="komyaz">%0</span>
                                <!-- <span class="komyaz">%<?= $ayarlar->komisyon ?></span>-->
                            </div>
                        </span>
                    </div>
                </div>

            </div>
            <script>
                var site_komisyon2 = "0";

                function komisyonchange(val) {
                    <?php foreach (fetchCategoryTree() as $cl) { ?>
                        if (val == "<?php echo $cl["id"] ?>") {
                            $(".komyaz").html('%<?php if ($cl["komisyon"] == "") {
                                                    $cl["komisyon"] = "0";
                                                }
                                                echo $cl["komisyon"]; ?>');
                            site_komisyon2 = '<?= $cl["komisyon"]; ?>';
                        }
                    <?php } ?>
                }
            </script>
            <?php if (1 == 2) { ?>
            <div class="form-group">
                <label class="form-control-label">Ürün Fotoğrafları</label><br>
                <input type="file" class="form-control" id="galeri-1671310458158" name="galeri[]" multiple="multiple">
            </div>
            <?php } ?>
            <div class="row">
            <div class="form-group col-md-12 mt-2">
                <!-- Title -->
                <label for="postTitle" class="form-label">Ürün Sıra</label>
                <input type="text" name="urun_sira" class="form-control text-dark"
                       placeholder="Ürün Sıra"/>

            </div>
            <?php if (1 == 2) { ?>
            <div class="form-group col-md-6 mt-2">
                <!-- Title -->
                <label for="postTitle" class="form-label">Ürün Vitrin Sıra</label>
                <input type="text" name="urun_vitrin_sira" class="form-control text-dark"
                       placeholder="Ürün Vitrin Sıra"/>
            </div>
            <?php } ?>
            </div>
            <!-- Editor -->
            <div class="mt-2 mb-4">
                <label class="form-control-label">Ürün Açıklaması</label>
                <textarea class="ckeditor" name="urun_aciklama" id="urun_detay" required><?= set_value('urun_detay'); ?></textarea>
                <?php echo form_error('urun_aciklama', '<div class="error_input">', '</div>'); ?>
            </div>

            <div class="row">
                <div class="col-12">
                    <hr>
                    <h4>Üyelerden Ürün Alma</h4>
                </div>
                <div class="form-group col-md-12">
                    <label class="form-label">Ürün Satın Alım</label>
                    <select class="form-control" id="urun_alim" data-width="100%" name="urun_alim" required>
                        <option value="0">Pasif
                        </option>
                        <option value="1">Aktif
                        </option>
                    </select>
                </div>

                <div class="form-group col-md-6 urun_alim_fiyat_alan d-none">
                    <label for="postTitle" class="form-label">Satın Alım Fiyat</label>
                    <input name="urun_alimfiyat" type="text" pattern="[0-9.]*" class="form-control text-dark" />
                </div>

                <div class="form-group col-md-6 urun_alim_stok_alan d-none">
                    <label for="postTitle" class="form-label">Satın Alım Stok</label>
                    <input name="urun_alim_stok" type="number" class="form-control text-dark" />
                </div>

                <div class="form-group col-md-12 mb-5 urun_alim_image_alan d-none">
                    <label class="form-label">Ürün Alım & Satım Fotoğrafı</label>
                    <div class="custom-file">
                        <input type="file" class="custom-file-input" id="vitrin" name="urun_alimimg"
                               accept=".jpg, .jpeg, .png" onchange="getPhotoData(this);">
                        <label class="custom-file-label" for="vitrin">Ürün Alım & Satım
                            Fotoğrafı</label>
                        <small>Sadece <span class="badge badge-danger badge-pill badge-sm">.png/.jpg/.jpeg</span>
                            dosya türü
                            desteklenmektedir.</small>
                        <div class="card mt-2" id="resim_goster" style="display: none">
                            <div class="p-3 d-flex justify-content-between">
                                <div>
                                    <i class="fe fe-file"></i> <span class="resim_adi"></span> /
                                    <small
                                            class="resim_size"></small>
                                </div>
                                <div>
                                    <a href="javascript:void(0)" id="resim_sil"><i
                                                class="fe fe-x"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="form-group col-md-12 urun_alim_yazi_alan d-none">
                    <label for="postTitle" class="form-label">Satın Alım Yazı</label>
                    <textarea name="urun_alimbaslik" class="form-control" id="" cols="10" rows="5"></textarea>
                </div>

                <div class="form-group col-md-12 urun_alim_uyari_alan d-none">
                    <label for="postTitle" class="form-label">Satın Alım Uyarı Mesajı</label>
                    <textarea name="urun_alim_uyari" class="form-control" id="" cols="10" rows="5"></textarea>
                </div>
            </div>

            <!-- button -->
            <button type="submit" class="btn btn-primary badge-pill"> Ürün Ekle</button>
        </form>
    </div>
</div>

<script>
    $('.durum').on('change', function() {
        if (this.value == 2) {
            $('.urun_iptal').show();
            $(".iptal").prop('required', true);
        } else {
            $('.urun_iptal').hide();
            $(".iptal").prop('required', false);
        }
    });

    $('#urun_alim').on('change', function() {
        if ($(this).val() == '1') {
            $('.urun_alim_fiyat_alan').removeClass('d-none');
            $('.urun_alim_stok_alan').removeClass('d-none');
            $('.urun_alim_image_alan').removeClass('d-none');
            $('.urun_alim_yazi_alan').removeClass('d-none');
            $('.urun_alim_uyari_alan').removeClass('d-none');
        } else {
            $('.urun_alim_fiyat_alan').addClass('d-none');
            $('.urun_alim_stok_alan').addClass('d-none');
            $('.urun_alim_image_alan').addClass('d-none');
            $('.urun_alim_yazi_alan').addClass('d-none');
            $('.urun_alim_uyari_alan').addClass('d-none');
        }
    });

    /**
     * Dosya Seçme işlemleri
     */
    var es = document.getElementById('dosya');
    var vt = document.getElementById('vitrin');

    function getFileData(myFile) {
        var file = myFile.files[0];
        if (file) {
            var filename = file.name;
            $('.dosya_adi').html(filename);
            $('.dosya_size').html(bytesToSize(file.size));
            $('#dosya_goster').show();
        } else {
            $('.dosya_adi').html('');
            $('.dosya_size').html('');
            $('#dosya_goster').hide();
        }
    }

    function getPhotoData(myFile) {
        var file = myFile.files[0];
        if (file) {
            var filename = file.name;
            $('.resim_adi').html(filename);
            $('.resim_size').html(bytesToSize(file.size));
            $('#resim_goster').show();
        } else {
            $('.resim_adi').html('');
            $('.resim_size').html('');
            $('#resim_goster').hide();
        }
    }

    $(document).on('click', '#dosya_sil', function() {
        clearInputFile(es);
    });

    $(document).on('click', '#resim_sil', function() {
        clearInputPhoto(vt);
    });

    function clearInputFile(f) {
        if (f.value) {
            try {
                f.value = ''; //for IE11, latest Chrome/Firefox/Opera...
            } catch (err) {}
            if (f.value) { //for IE5 ~ IE10
                var form = document.createElement('form'),
                    ref = f.nextSibling;
                form.appendChild(f);
                form.reset();
                ref.parentNode.insertBefore(f, ref);
            }
            getFileData(f);
        }
    }

    function clearInputPhoto(f) {
        if (f.value) {
            try {
                f.value = ''; //for IE11, latest Chrome/Firefox/Opera...
            } catch (err) {}
            if (f.value) { //for IE5 ~ IE10
                var form = document.createElement('form'),
                    ref = f.nextSibling;
                form.appendChild(f);
                form.reset();
                ref.parentNode.insertBefore(f, ref);
            }
            getPhotoData(f);
        }
    }

    /**
     * Byte To MB Convert
     */
    function bytesToSize(bytes) {
        var sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
        if (bytes == 0) return '0 Byte';
        var i = parseInt(Math.floor(Math.log(bytes) / Math.log(1024)));
        return Math.round(bytes / Math.pow(1024, i), 2) + ' ' + sizes[i];
    }

    /**
     * Ürün Türü Select Event
     */
    $('#urun_turu').on('change', function() {
        if (this.value == 1) {
            $('.sanal_urun_bilgileri').hide();
            $('.indirilebilir').hide();
            $('.fiziksel').show();
            $("#sanal_urun_bilgileri").prop('required', false);
            $("#dosya").prop('required', false);
        } else if (this.value == 2) {
            $('.sanal_urun_bilgileri').show();
            $("#sanal_urun_bilgileri").prop('required', true);
            $("#dosya").prop('required', false);
            $('.indirilebilir').hide();
            $('.fiziksel').hide();
        } else if (this.value == 3) {
            $('.sanal_urun_bilgileri').hide();
            $('.indirilebilir').show();
            $("#dosya").prop('required', true);
            $("#sanal_urun_bilgileri").prop('required', false);
            $('.fiziksel').hide();
        } else {
            $('.sanal_urun_bilgileri').hide();
            $('.indirilebilir').hide();
            $('.fiziksel').hide();
            $("#sanal_urun_bilgileri").prop('required', false);
            $("#dosya").prop('required', false);
        }
    });

    /**
     * Komisyon Hesaplama
     */
    $(document).on("input paste focus", "#fiyat", function() {
        /* var fiyat = parseFloat($(this).val());
         if (!fiyat || fiyat == 0) {
             $('#kazanc').html('0.00 ₺');
         } else {
             var komisyon_bol = parseFloat(<?= $ayarlar->komisyon ?>) / 100;
             var komisyon_carp = parseFloat(fiyat * komisyon_bol).toFixed(2);
             var komisyom_topla = parseFloat(fiyat - komisyon_carp).toFixed(2);
             $('#kazanc').html(komisyom_topla + ' ₺');
         }*/
    });
    
    $(document).on("input paste focus", "#eski_fiyat,#fiyat", function() {
        var fiyat = parseFloat($("#eski_fiyat").val());
        var urun_fiyat = parseFloat($("#fiyat").val());
        if(!fiyat || fiyat == 0 || !urun_fiyat || urun_fiyat == 0 || fiyat < urun_fiyat) {
            $("#indirim_yuzdesi").html("Yok")
        } else {
            var oran =  100 - Math.ceil((urun_fiyat * 100) / fiyat);
            $("#indirim_yuzdesi").html(oran + "%");
        }
    });
</script>