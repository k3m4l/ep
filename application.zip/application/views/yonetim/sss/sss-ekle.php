<div class="br-pageheader">
	<nav class="breadcrumb pd-0 mg-0 tx-12">
		<a class="breadcrumb-item" href="<?=base_url(admin_url())?>">Kontrol Paneli</a>
		<span class="breadcrumb-item active">Yeni SSS Oluştur</span>
	</nav>
</div><!-- br-pageheader -->
<div class="br-pagetitle">
	<i class="far fa-file-alt fa-4x"></i>
	<div>
		<h4>Yeni SSS Oluştur</h4>
	</div>
</div><!-- d-flex -->

<div class="br-pagebody">
	<div class="br-section-wrapper">
		<form action="<?=base_url(admin_url()."sssekle"); ?>" method="post" enctype="multipart/form-data">
			<div class="form-layout form-layout-1">
				<div class="row mg-b-25">
					<div class="col-lg-12">
						<div class="form-group">
							<label class="form-control-label">SSS Başlık <span class="tx-danger">*</span></label>
							<input class="form-control" type="text" name="baslik" placeholder="SSS Başlık" required="">
						</div>
					</div><!-- col-4 -->

					<div class="col-lg-12">
						<div class="form-group">
							<label class="form-control-label">SSS Açıklama</label>
							<textarea class="form-control" rows="15" name="aciklama" placeholder="SSS Açıklama" required=""></textarea>
						</div>
					</div><!-- col-8 -->
				</div>

				<div class="form-layout-footer">
					<button type="submit" class="btn btn-info">SSS Ekle</button>
				</div><!-- form-layout-footer -->
			</div>
		</form><!-- form-layout -->
	</div>
</div>
<script>
	$(document).ready(function(){
		CKEDITOR.replace( 'aciklama' );
	});
</script>