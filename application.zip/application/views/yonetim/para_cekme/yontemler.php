<div class="br-pageheader">
    <nav class="breadcrumb pd-0 mg-0 tx-12">
        <a class="breadcrumb-item" href="<?=base_url(admin_url())?>">Kontrol Paneli</a>
        <span class="breadcrumb-item active">Para Çekme Ayarları</span>
    </nav>
</div><!-- br-pageheader -->
<div class="br-pagetitle">
    <i class="far fa-images fa-4x"></i>
    <div>
        <h4>Para Çekme Ayarları</h4>
    </div>
</div><!-- d-flex -->

<div class="br-pagebody">
    <div class="br-section-wrapper">
        <div class="table-wrapper">
            <table id="datatable1" class="table display responsive nowrap">
                <thead>
                <tr>
                    <th class="wd-15p text-center">#</th>
                    <th class="wd-15p text-center">Yöntem</th>
                    <th class="wd-15p text-center">Resim</th>
                    <th class="wd-10p text-center">Sıra</th>
                    <th class="wd-10p text-center">İşlemler</th>
                </tr>
                </thead>
                <tbody>
                <?php // $slider = slider(); ?>
                <?php if ($yontemler) { ?>
                    <?php $i=0; foreach ($yontemler as $key) { $i++; ?>
                        <tr>
                            <td class="text-center"><?=$i?></td>
                            <td class="text-center"><?=$key->row_title?></td>
                            <td class="text-center"><img width="50px" style="width: 50px" src="<?=base_url($key->row_image)?>"></td>
                            <td class="text-center"><?=$key->row_sira?></td>
                            <td class="text-center">
                                <a href="<?php echo base_url(admin_url()."para-cekme-yontem-duzenle/$key->id"); ?>" class="btn btn-warning btn-with-icon">
                                    <div class="ht-40">
                                        <span class="icon fas fa-edit wd-40"><i class="fa fa-send"></i></span>
                                        <span class="pd-x-15">Düzenle</span>
                                    </div>
                                </a>
                            </td>
                        </tr>
                    <?php } ?>
                <?php } ?>
                </tbody>
            </table>
        </div><!-- table-wrapper -->
    </div><!-- br-section-wrapper -->
</div><!-- br-pagebody -->