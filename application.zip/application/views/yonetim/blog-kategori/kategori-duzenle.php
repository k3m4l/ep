<div class="br-pageheader">
	<nav class="breadcrumb pd-0 mg-0 tx-12">
		<a class="breadcrumb-item" href="<?=base_url(admin_url())?>">Kontrol Paneli</a>
		<a class="breadcrumb-item" href="<?=base_url(admin_url().'blog-kategori')?>">Blog Kategoriler</a>
		<span class="breadcrumb-item active"><?=$where->kategori_ad?> - Düzenle</span>
	</nav>
</div><!-- br-pageheader -->
<div class="br-pagetitle">
	<i class="fas fa-grip-horizontal fa-4x"></i>
	<div>
		<h4><?=$where->kategori_ad?> - Düzenle</h4>
	</div>
</div><!-- d-flex -->

<div class="br-pagebody">
	<div class="br-section-wrapper">
		<form action="<?=base_url(admin_url()."blogkategoriduzenle/$where->id"); ?>" method="post" enctype="multipart/form-data">
			<div class="form-layout form-layout-1">
				<div class="row mg-b-25">
					<div class="col-lg-6">
						<div class="form-group">
							<label class="form-control-label">Kategori Adı <span class="tx-danger">*</span></label>
							<input class="form-control" type="text" name="ad" placeholder="Kategori Adı" value="<?=$where->kategori_ad?>">
							<?php if (isset($form_error)) { ?> <code class="pull-right"><?=form_error('ad')?></code><?php } ?>
						</div>
					</div>
					<div class="col-lg-6">
						<div class="form-group">
							<label class="form-control-label">Kategori Seo Url <small><code>Boş Bırakırsanız Otomatik Oluşturur</code></small></label>
							<input class="form-control" type="text" name="seo" placeholder="Kategori Seo Url" value="<?=$where->kategori_seo?>">
						</div>
					</div>
					<div class="col-lg-6">
						<div class="form-group">
							<label class="form-control-label">Kategori Sıra</label>
							<input class="form-control" type="number" name="sira" placeholder="Kategori Sıralama" value="<?=$where->kategori_sira?>">
						</div>
					</div>
					<div class="col-lg-6">
						<div class="form-group mg-b-10-force">
							<label class="form-control-label">Kategori Durum <span class="tx-danger">*</span></label>
							<select class="form-control" name="durum">
								<option <?php if ($where->kategori_durum==1) { echo 'selected'; } ?> value="1">Aktif</option>
								<option <?php if ($where->kategori_durum==0) { echo 'selected'; } ?> value="0">Pasif</option>
							</select>
						</div>
					</div>


					<div class="col-lg-4">
						<div class="form-group">
							<label class="form-control-label">Kategori Seo Başlık <small><code>Boş Bırakırsanız Varsayılan Başlık Görünür</code></small></label>
							<input class="form-control" type="text" name="title" placeholder="Kategori Seo Başlık" value="<?=$where->kategori_title?>">
						</div>
					</div>
					<div class="col-lg-4">
						<div class="form-group">
							<label class="form-control-label">Kategori Seo Açıklama <small><code>Boş Bırakırsanız Varsayılan Açıklama Görünür</code></small></label>
							<input class="form-control" type="text" name="desc" placeholder="Kategori Seo Açıklama" value="<?=$where->kategori_desc?>">
						</div>
					</div>
					<div class="col-lg-4">
						<div class="form-group">
							<label class="form-control-label">Kategori Seo Anahtar Kelime <small><code>Boş Bırakırsanız Varsayılan Anahtar Kelime Görünür</code></small></label>
							<input class="form-control" type="text" name="keyw" placeholder="Kategori Anahtar Kelime" value="<?=$where->kategori_keyw?>">
						</div>
					</div>

				</div>

				<div class="form-layout-footer">
					<button type="submit" class="btn btn-info">Blog Kategori Güncelle</button>
				</div><!-- form-layout-footer -->
			</div>
		</form><!-- form-layout -->
	</div>
</div>