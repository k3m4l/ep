<div class="br-pageheader">
    <nav class="breadcrumb pd-0 mg-0 tx-12">
        <a class="breadcrumb-item" href="<?= base_url(admin_url()) ?>">Kontrol Paneli</a>
        <span class="breadcrumb-item active">Blog Kategoriler</span>
    </nav>
</div><!-- br-pageheader -->
<div class="br-pagetitle justify-content-between">
    <div class="d-flex align-items-center">
        <i class="fas fa-grip-horizontal fa-4x mr-2"></i>
        <div>
            <h4>Blog Kategoriler</h4>
            <p class="mg-b-0">Blog Kategorileri</p>
        </div>
    </div>
    <a href="<?= base_url(admin_url() . "blog-kategori-ekle"); ?>" class="btn btn-primary float-end">Yeni Kategori Ekle</a>
</div><!-- d-flex -->

<div class="br-pagebody">
    <div class="br-section-wrapper">
        <div class="table-wrapper">
            <table id="datatable1" class="table-responsive table display responsive nowrap">
                <thead>
                <tr>
                    <th class="wd-15p text-center">KATEGORİ ADI</th>
                    <th class="wd-5p text-center">KATEGORİ SIRA</th>
                    <th class="wd-15p text-center">KATEGORİ DURUM</th>
                    <th class="wd-10p text-center">KATEGORİ İŞLEM</th>
                </tr>
                </thead>
                <tbody>
                <?php $kategoriler = blog_kategoriler_yonetim(); ?>
                <?php if ($kategoriler) { ?>
                    <?php foreach ($kategoriler as $key) { ?>
                        <tr>
                            <td><?= $key->kategori_ad ?></td>
                            <td class="text-center">
                                <div class="badge badge-success"><?= $key->kategori_sira ?></div>
                            </td>
                            <td class="text-center">
                                <label class="switch">
                                    <input class="durum"
                                           data-url="<?= base_url(admin_url() . "blog_durum/$key->id") ?>"
                                           type="checkbox" <?php if ($key->kategori_durum == 1) {
                                        echo 'checked';
                                    } ?>>
                                    <span class="slider round"></span>
                                </label>
                            </td>
                            <td class="text-center">
                                <a href="<?php echo base_url(admin_url() . "blog-kategori-duzenle/$key->id"); ?>"
                                   class="btn btn-warning btn-with-icon">
                                    <div class="ht-40">
                                        <span class="icon fas fa-edit wd-40"><i class="fa fa-send"></i></span>
                                        <span class="pd-x-15">Düzenle</span>
                                    </div>
                                </a>
                                <a href="javascript:void(0)"
                                   data-url="<?= base_url(admin_url() . "blogkategorisil/$key->id") ?>"
                                   class="btn btn-danger btn-with-icon remove-btn">
                                    <div class="ht-40">
                                        <span class="icon far fa-trash-alt wd-40"><i class="fa fa-send"></i></span>
                                        <span class="pd-x-15">Sil</span>
                                    </div>
                                </a>
                            </td>
                        </tr>
                    <?php } ?>
                <?php } ?>
                </tbody>
            </table>
        </div><!-- table-wrapper -->
    </div><!-- br-section-wrapper -->
</div><!-- br-pagebody -->