<?php $kullanici = active_user();
$siteayar = ayarlar(); ?>
<!DOCTYPE html>
<html lang="tr">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title><?php echo html_escape($siteayar->header_baslik); ?></title>
    <link rel="icon" type="image/png" href="<?= base_url($siteayar->site_favicon) ?>">

    <!-- vendor css -->
    <link href="<?= base_url('assets/yonetim/') ?>lib/@fortawesome/fontawesome-free/css/all.min.css" rel="stylesheet">
    <link href="<?= base_url('assets/yonetim/') ?>lib/ionicons/css/ionicons.min.css" rel="stylesheet">

    <link href="<?= base_url('assets/yonetim/') ?>lib/highlightjs/styles/github.css" rel="stylesheet">
    <link href="<?= base_url('assets/yonetim/') ?>lib/select2/css/select2.min.css" rel="stylesheet">
    <link href="<?= base_url('assets/yonetim/') ?>lib/timepicker/jquery.timepicker.css" rel="stylesheet">
    <link href="<?= base_url('assets/yonetim/') ?>lib/spectrum-colorpicker/spectrum.css" rel="stylesheet">
    <link href="<?= base_url('assets/yonetim/') ?>lib/bootstrap-tagsinput/bootstrap-tagsinput.css" rel="stylesheet">
    <link href="<?= base_url('assets/yonetim/') ?>lib/ion-rangeslider/css/ion.rangeSlider.css" rel="stylesheet">
    <link href="<?= base_url('assets/yonetim/') ?>lib/ion-rangeslider/css/ion.rangeSlider.skinFlat.css" rel="stylesheet">
    <link href="<?= base_url('assets/yonetim/') ?>lib/datatables.net-dt/css/jquery.dataTables.min.css" rel="stylesheet">
    <link href="//cdn.datatables.net/responsive/2.1.1/css/dataTables.responsive.css" />

    <!-- Bracket CSS -->
    <link rel="stylesheet" href="<?=base_url('assets/yonetim/css/bracket.css?v=')?>">
    <link rel="stylesheet" href="<?= base_url('assets/yonetim/') ?>css/bracket.simple-white.css?v=1.1.1">
    <link rel="stylesheet" href="<?= base_url("assets") ?>/css/iziToast.min.css">
    <link href="https://gitcdn.github.io/bootstrap-toggle/2.2.2/css/bootstrap-toggle.min.css" rel="stylesheet">
    <script src="<?= base_url('assets/yonetim/') ?>lib/jquery/jquery.min.js"></script>
    <script src="<?= base_url('assets/yonetim/js/custom.js') ?>"></script>
    <script src="https://gitcdn.github.io/bootstrap-toggle/2.2.2/js/bootstrap-toggle.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.33.1/sweetalert2.min.css"/>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.33.1/sweetalert2.min.js"></script>

    <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/vue/dist/vue.js"></script>

    <link rel="stylesheet" href="https://jsuites.net/v4/jsuites.css" type="text/css"/>

    <link rel="stylesheet" href="<?php echo base_url('assets/yonetim/css/dropzone.min.css?v=1.2') ?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/yonetim/css/dropzone.css?v=1.2') ?>">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@yaireo/tagify/dist/tagify.css">
    <script src="https://cdn.jsdelivr.net/npm/@yaireo/tagify"></script>

</head>

<body>
    <div class="br-logo" style="background-color: #1e1e2d;"><a href="<?= base_url(admin_url()) ?>"><img class="img-fluid logo-wodo-img" width="207px" height=67px src="<?= base_url("assets/front/images/logo-wodo.webp") ?>" alt="logo" loading="lazy"></a></div>
    <?php $this->load->view("yonetim/inc/menu"); ?>
    <div class="br-header">
        <div class="br-header-left">
            <div class="navicon-left hidden-md-down"><a id="btnLeftMenu" href=""><i class="icon ion-navicon-round"></i></a></div>
            <div class="navicon-left hidden-lg-up"><a id="btnLeftMenuMobile" href=""><i class="icon ion-navicon-round"></i></a></div>
        </div>
        <div class="br-header-right">
            <nav class="nav">
                <div class="dropdown">
                    <a href="" class="nav-link nav-link-profile" data-toggle="dropdown">
                        <span class="logged-name hidden-md-down"><span class="text-muted">Merhaba</span> ADMİN</span>
                        <span class="alert alert-success">A</span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-header wd-250">
                        <ul class="list-unstyled user-profile-nav">
                            <li><a href="<?= base_url(admin_url() . "cikis") ?>"><i class="icon ion-power"></i> Çıkış Yap</a></li>
                        </ul>
                    </div>
                </div>
            </nav>
        </div>
    </div>

    <div class="br-mainpanel">