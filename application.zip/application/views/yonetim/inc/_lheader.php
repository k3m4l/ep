<?php $siteayar = ayarlar(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Meta -->
    <meta name="description" content="Premium Quality and Responsive UI for Dashboard.">
    <title><?php echo html_escape($siteayar->header_baslik); ?></title>
    <link rel="icon" type="image/png" href="<?= base_url($siteayar->site_favicon) ?>">
    <!-- vendor css -->
    <link href="<?=base_url('assets/yonetim/')?>lib/@fortawesome/fontawesome-free/css/all.min.css" rel="stylesheet">
    <link href="<?=base_url('assets/yonetim/')?>lib/ionicons/css/ionicons.min.css" rel="stylesheet">
    <!-- Bracket CSS -->
    <link rel="stylesheet" href="<?= base_url('assets/yonetim/') ?>css/bracket.css">

    <link rel="stylesheet" href="<?=base_url('assets/yonetim/')?>css/bracket.simple-white.css?v=1.1.1">
    <link rel="stylesheet" href="<?=base_url("assets")?>/css/iziToast.min.css">
    <script src="<?=base_url("assets")?>/js/iziToast.min.js"></script>
</head>

<body>