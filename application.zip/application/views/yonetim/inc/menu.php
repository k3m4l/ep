<?php date_default_timezone_set('Europe/Istanbul'); ?>
<style>
    .br-sideleft {
        background-color: #000;
    }
    .br-menu-link.show-sub {
        background-color: #575757;
        color: #000;
    }
    .br-menu-sub {
        background-color: #000;
    }
</style>

<div class="br-sideleft sideleft-scrollbar  " style="background-color: #1e1e2d !important;">
    <label class="sidebar-label custom-side-bar-label tx-info">Yönetim Paneli</label>
    <div class="br-menu-warper ">
        <ul class="br-menu-list">
            <li class="br-menu-item-new">
                <a title="" class="br-menu-item-link" href="<?= base_url(safadmin_url()); ?>">
                    <i class="menu-item-icon fas fa-desktop  tx-20"></i><span
                        class="br-menu-tt menu-item-label ">Kontrol
                        Paneli</span>
                </a>
            </li>

            <label class="sidebar-label custom-side-bar-label tx-info">Ürün Yönetimi</label>


            <li class="br-menu-item-new">
                <a title="" class="br-menu-item-link" href="">
                    <i class="menu-item-icon fas fa-shopping-basket tx-20"></i><span
                            class="br-menu-tt menu-item-label ">Ürünler</span>
                    <i class="fas fa-chevron-right br-menu-arrow menu-item-label"></i>
                </a>
                <ul class="br-menu-item-new-sub-list">
                    <li class="br-menu-item-new-sub-list-item">
                        <a title="" class="br-menu-item-new-sub-list-item-link"
                           href="<?= base_url(admin_url() . "urun-ekle"); ?>"><i class="fas fa-circle l-dot"></i>
                            Ürün Ekle
                        </a>
                    </li>
                    <li class="br-menu-item-new-sub-list-item">
                        <a title="" class="br-menu-item-new-sub-list-item-link"
                           href="<?= base_url(admin_url() . "urunler"); ?>"><i class="fas fa-circle l-dot"></i>
                            Ürünler
                        </a>
                    </li>
                </ul>
            </li>


            <li class="br-menu-item-new">
                <a title="" class="br-menu-item-link" href="">
                    <i class="menu-item-icon fas fa-grip-horizontal tx-20"></i><span
                        class="br-menu-tt menu-item-label">Kategoriler</span>
                    <i class="fas fa-chevron-right br-menu-arrow menu-item-label"></i>
                </a>
                <ul class="br-menu-item-new-sub-list">
                    <li class="br-menu-item-new-sub-list-item">
                        <a title="" class="br-menu-item-new-sub-list-item-link"
                            href="<?= base_url(admin_url() . "kategori-ekle"); ?>"><i class="fas fa-circle l-dot"></i>
                            Yeni Kategori Ekle</a>
                    </li>
                    <li class="br-menu-item-new-sub-list-item">
                        <a title="" class="br-menu-item-new-sub-list-item-link"
                            href="<?= base_url(admin_url() . "kategoriler"); ?>"><i class="fas fa-circle l-dot"></i>
                            Kategoriler</a>
                    </li>
                    <li class="br-menu-item-new-sub-list-item">
                        <a title="" class="br-menu-item-new-sub-list-item-link"
                            href="<?= base_url(admin_url() . "alt-kategoriler"); ?>"><i class="fas fa-circle l-dot"></i>
                            Alt Kategoriler</a>
                    </li>
                </ul>
            </li>

            <label class="sidebar-label custom-side-bar-label tx-info">Sipariş Yönetimi</label>

            <li class="br-menu-item-new">
                <a title="" class="br-menu-item-link" href="">
                    <i class="menu-item-icon fas fa-cart-plus tx-20"></i><span class="br-menu-tt menu-item-label ">E-PIN Siparişleri</span>
                    <i class="fas fa-chevron-right br-menu-arrow menu-item-label"></i>
                </a>
                <ul class="br-menu-item-new-sub-list">
                    <li class="br-menu-item-new-sub-list-item">
                        <a title="" class="br-menu-item-new-sub-list-item-link"
                            href="<?= base_url(admin_url() . "urun-key-havuzu"); ?>"><i class="fas fa-circle l-dot"></i>
                            Key Havuzu</a>
                    </li>
                    <li class="br-menu-item-new-sub-list-item">
                        <a title="" class="br-menu-item-new-sub-list-item-link"
                            href="<?= base_url(admin_url() . "key-bekleyen-siparisler"); ?>"><i
                                class="fas fa-circle l-dot"></i>
                            Key Bekleyen Siparişler</a>
                    </li>
                    <li class="br-menu-item-new-sub-list-item">
                        <a title="" class="br-menu-item-new-sub-list-item-link"
                            href="<?= base_url(admin_url() . "onaylanan-siparisler"); ?>"><i
                                class="fas fa-circle l-dot"></i>
                            Teslim Edilen Siparişler</a>
                    </li>
                    <li class="br-menu-item-new-sub-list-item">
                        <a title="" class="br-menu-item-new-sub-list-item-link"
                            href="<?= base_url(admin_url() . "iptal-edilen-siparisler"); ?>"><i
                                class="fas fa-circle l-dot"></i>
                            İptal Edilen Siparişler</a>
                    </li>
                </ul>
            </li>

            <li class="br-menu-item-new">
                <a title="" class="br-menu-item-link" href="">
                    <i class="menu-item-icon fas fa-cart-plus tx-20"></i><span class="br-menu-tt menu-item-label ">Reklam Siparişleri</span>
                    <i class="fas fa-chevron-right br-menu-arrow menu-item-label"></i>
                </a>
                <ul class="br-menu-item-new-sub-list">
                    <li class="br-menu-item-new-sub-list-item">
                        <a title="" class="br-menu-item-new-sub-list-item-link"
                           href="<?= base_url(admin_url() . "reklam-siparisler"); ?>"><i
                                    class="fas fa-circle l-dot"></i>
                            Reklam Siparişleri</a>
                    </li>
                </ul>
            </li>

            <label class="sidebar-label custom-side-bar-label tx-info">İlan Yönetimi</label>

            <li class="br-menu-item-new">
                <a title="" class="br-menu-item-link" href="">
                    <i class="menu-item-icon fas fa-shopping-basket tx-20"></i><span
                            class="br-menu-tt menu-item-label ">İlan
                        Sistemi</span>
                    <i class="fas fa-chevron-right br-menu-arrow menu-item-label"></i>
                </a>
                <ul class="br-menu-item-new-sub-list">
                    <li class="br-menu-item-new-sub-list-item">
                        <a title="" class="br-menu-item-new-sub-list-item-link"
                           href="<?= base_url(admin_url() . "ilanlar"); ?>"><i class="fas fa-circle l-dot"></i>
                            Onaylanan İlanlar
                        </a>
                    </li>
                    <li class="br-menu-item-new-sub-list-item">
                        <a title="" class="br-menu-item-new-sub-list-item-link"
                           href="<?= base_url(admin_url() . "bekleyen-ilanlar"); ?>"><i
                                    class="fas fa-circle l-dot"></i>
                            Bekleyen İlanlar
                        </a>
                    </li>
                    <li class="br-menu-item-new-sub-list-item">
                        <a title="" class="br-menu-item-new-sub-list-item-link"
                           href="<?= base_url(admin_url() . "pasif-ilanlar"); ?>"><i
                                    class="fas fa-circle l-dot"></i>
                            Pasif İlanlar
                        </a>
                    </li>
                    <li class="br-menu-item-new-sub-list-item">
                        <a title="" class="br-menu-item-new-sub-list-item-link"
                           href="<?= base_url(admin_url() . "satin-alinan-ilanlar"); ?>"><i
                                    class="fas fa-circle l-dot"></i>
                            Satın Alınan İlanlar
                        </a>
                    </li>
                </ul>
            </li>

            <li class="br-menu-item-new">
                <a title="" class="br-menu-item-link" href="">
                    <i class="menu-item-icon fas fa-store tx-20"></i>
                    <span class="br-menu-tt menu-item-label ">Teslimat İtirazları</span>
                    <i class="fas fa-chevron-right br-menu-arrow menu-item-label"></i>
                </a>
                <ul class="br-menu-item-new-sub-list">
                    <li class="br-menu-item-new-sub-list-item">
                        <a title="" class="br-menu-item-new-sub-list-item-link"
                           href="<?= base_url(admin_url() . "teslimat"); ?>"><i
                                    class="fas fa-circle l-dot"></i>Teslimat</a>
                    </li>
                    <li class="br-menu-item-new-sub-list-item">
                        <a title="" class="br-menu-item-new-sub-list-item-link"
                           href="<?= base_url(admin_url() . "bekleyen-teslimat"); ?>"><i
                                    class="fas fa-circle l-dot"></i>
                            Onay Bekleyen Teslimatlar
                        </a>
                    </li>
                </ul>
            </li>

            <li class="br-menu-item-new">
                <a title="" class="br-menu-item-link" href="">
                    <i class="menu-item-icon fa fa-mobile tx-20"></i><span class="br-menu-tt menu-item-label ">Magaza SMS Şablonu</span>
                    <i class="fas fa-chevron-right br-menu-arrow menu-item-label"></i>

                </a>

                <ul class="br-menu-item-new-sub-list">
                    <li class="br-menu-item-new-sub-list-item">
                        <a title="" class="br-menu-item-new-sub-list-item-link"
                           href="<?= base_url(admin_url() . "sms-sablon-ekle"); ?>"><i
                                    class="fas fa-circle l-dot"></i>Yeni
                            Şablon Ekle
                        </a>
                    </li>
                    <li class="br-menu-item-new-sub-list-item">
                        <a title="" class="br-menu-item-new-sub-list-item-link"
                           href="<?= base_url(admin_url() . "sms-sablonlar"); ?>"><i
                                    class="fas fa-circle l-dot"></i>Şablonlar</a>
                    </li>
                </ul>
            </li>

            <li class="br-menu-item-new">
                <a title="" class="br-menu-item-link" href="">
                    <i class="menu-item-icon fas fa-comment-alt tx-20"></i><span
                            class="br-menu-tt menu-item-label ">Yorumlar</span>

                    <i class="fas fa-chevron-right br-menu-arrow menu-item-label"></i>
                </a>
                <ul class="br-menu-item-new-sub-list">
                    <li class="br-menu-item-new-sub-list-item">
                        <a title="" class="br-menu-item-new-sub-list-item-link"
                           href="<?= base_url(admin_url() . "yorumlar"); ?>"><i class="fas fa-circle l-dot"></i>Yorumlar
                        </a>
                    </li>
                    <li class="br-menu-item-new-sub-list-item">
                        <a title="" class="br-menu-item-new-sub-list-item-link"
                           href="<?= base_url(admin_url() . "bekleyen-yorumlar"); ?>"><i
                                    class="fas fa-circle l-dot"></i>Onay Bekleyen Yorumlar</a>
                    </li>
                    <li class="br-menu-item-new-sub-list-item">
                        <a title="" class="br-menu-item-new-sub-list-item-link"
                           href="<?= base_url(admin_url() . "itiraz-talepleri"); ?>"><i
                                    class="fas fa-circle l-dot"></i>Yorum İtiraz Talepleri </a>
                    </li>
                </ul>
            </li>

            <label class="sidebar-label custom-side-bar-label tx-info">Gold Alım & Satım</label>

            <li class="br-menu-item-new">
                <a title="" class="br-menu-item-link" href="">
                    <i class="menu-item-icon fas fa-cart-plus tx-20"></i><span class="br-menu-tt menu-item-label ">Siteye Satışlar</span>
                    <i class="fas fa-chevron-right br-menu-arrow menu-item-label"></i>
                </a>
                <ul class="br-menu-item-new-sub-list">
                    <li class="br-menu-item-new-sub-list-item">
                        <a title="" class="br-menu-item-new-sub-list-item-link"
                           href="<?= base_url(admin_url() . "siteye-satis-bekleyen"); ?>"><i
                                    class="fas fa-circle l-dot"></i>
                            Teslimat Bekleyenler</a>
                    </li>
                    <li class="br-menu-item-new-sub-list-item">
                        <a title="" class="br-menu-item-new-sub-list-item-link"
                           href="<?= base_url(admin_url() . "siteye-satis-tamamlanan"); ?>"><i class="fas fa-circle l-dot"></i>
                            Tamamlananlar</a>
                    </li>
                    <li class="br-menu-item-new-sub-list-item">
                        <a title="" class="br-menu-item-new-sub-list-item-link"
                           href="<?= base_url(admin_url() . "siteye-satis-iptal"); ?>"><i
                                    class="fas fa-circle l-dot"></i>
                            İptal Edilenler</a>
                    </li>
                </ul>
            </li>

            <label class="sidebar-label custom-side-bar-label tx-info">Pvp Server</label>


            <li class="br-menu-item-new">
                <a title="" class="br-menu-item-link" href="">
                    <i class="menu-item-icon fas fa-list-alt tx-20"></i>
                    <span class="br-menu-tt menu-item-label ">Pvp Serverlar </span>
                    <i class="fas fa-chevron-right br-menu-arrow menu-item-label"></i>
                </a>


                <ul class="br-menu-item-new-sub-list">
                    <li class="br-menu-item-new-sub-list-item">
                        <a title="" class="br-menu-item-new-sub-list-item-link"
                           href="<?= base_url(admin_url() . "pvp-server-ekle"); ?>"><i class="fas fa-circle l-dot"></i>
                            Ekle
                        </a>
                    </li>
                    <li class="br-menu-item-new-sub-list-item">
                        <a title="" class="br-menu-item-new-sub-list-item-link"
                           href="<?= base_url(admin_url() . "pvp-serverlar"); ?>"><i
                                    class="fas fa-circle l-dot"></i>Listele</a>
                    </li>
                </ul>
            </li>

            <label class="sidebar-label custom-side-bar-label tx-info">Çekiliş & Kuponlar</label>

            <li class="br-menu-item-new">
                <a title="" class="br-menu-item-link" href="">
                    <i class="menu-item-icon fas fa-tags tx-20"></i><span
                            class="br-menu-tt menu-item-label ">Kuponlar</span>
                    <i class="fas fa-chevron-right br-menu-arrow menu-item-label"></i>
                </a>
                <ul class="br-menu-item-new-sub-list">
                    <li class="br-menu-item-new-sub-list-item">
                        <a title="" class="br-menu-item-new-sub-list-item-link"
                           href="<?= base_url(admin_url() . "kupon-ekle"); ?>"><i class="fas fa-circle l-dot"></i>
                            Kupon Ekle</a>
                    </li>
                    <li class="br-menu-item-new-sub-list-item">
                        <a title="" class="br-menu-item-new-sub-list-item-link"
                           href="<?= base_url(admin_url() . "kuponlar"); ?>"><i class="fas fa-circle l-dot"></i>
                            Kupon Listesi</a>
                    </li>
                    <li class="br-menu-item-new-sub-list-item">
                        <a title="" class="br-menu-item-new-sub-list-item-link"
                           href="<?= base_url(admin_url() . "kupon-kayitlari"); ?>"><i class="fas fa-circle l-dot"></i>
                            Kupon Kayıtları</a>
                    </li>
                </ul>
            </li>

            <li class="br-menu-item-new">
                <a title="" class="br-menu-item-link" href="">
                    <i class="menu-item-icon fas fa-users tx-20"></i>
                    <span class="br-menu-tt menu-item-label ">Çekliliş Sistemi</span>
                    <i class="fas fa-chevron-right br-menu-arrow menu-item-label"></i>
                </a>
                <ul class="br-menu-item-new-sub-list">
                    <li class="br-menu-item-new-sub-list-item">
                        <a title="" class="br-menu-item-new-sub-list-item-link"
                           href="<?= base_url(admin_url() . "cekilisler"); ?>"><i
                                    class="fas fa-circle l-dot"></i>Çekiliş
                            Listesi</a>
                    </li>
                    <li class="br-menu-item-new-sub-list-item">
                        <a title="" class="br-menu-item-new-sub-list-item-link"
                           href="<?= base_url(admin_url() . "aktif-cekilisler"); ?>"><i
                                    class="fas fa-circle l-dot"></i>Aktif
                            Çekilişler</a>
                    </li>
                    <li class="br-menu-item-new-sub-list-item">
                        <a title="" class="br-menu-item-new-sub-list-item-link"
                           href="<?= base_url(admin_url() . "tamamlanan-cekilisler"); ?>"><i
                                    class="fas fa-circle l-dot"></i>Tamamlanan Çekilişler</a>
                    </li>
                </ul>
            </li>

            <label class="sidebar-label custom-side-bar-label tx-info">Mağza & Bayi & Sponsor</label>


            <li class="br-menu-item-new">
                <a title="" class="br-menu-item-link" href="<?= base_url(admin_url() . "magazalar"); ?>">
                    <i class="menu-item-icon fas fa-store tx-20"></i><span class="br-menu-tt menu-item-label ">
                        Mağzalar
                </a>

            </li>

            <li class="br-menu-item-new">
                <a title="" class="br-menu-item-link" href="<?= base_url(admin_url() . "onayli-bayiler"); ?>">
                    <i class="menu-item-icon fas fa-user tx-20"></i><span class="br-menu-tt menu-item-label ">
                        Bayiler
                </a>

            </li>

            <li class="br-menu-item-new">
                <a title="" class="br-menu-item-link" href="<?= base_url(admin_url() . "onayli-sponsorlar"); ?>">
                    <i class="menu-item-icon fas fa-user tx-20"></i><span class="br-menu-tt menu-item-label ">
                        Sponsorlar
                </a>

            </li>

            <label class="sidebar-label custom-side-bar-label tx-info">Başvurular</label>

            <li class="br-menu-item-new">
                <a title="" class="br-menu-item-link" href="<?= base_url(admin_url() . "bekleyen-magazalar"); ?>">
                    <i class="menu-item-icon fas fa-store tx-20"></i><span class="br-menu-tt menu-item-label ">Mağza
                        Başvuru
                </a>

            </li>

            <li class="br-menu-item-new">
                <a title="" class="br-menu-item-link" href="<?= base_url(admin_url() . "sponsorlar"); ?>">
                    <i class="menu-item-icon fas fa-user tx-20"></i><span class="br-menu-tt menu-item-label ">Sponsor
                        Başvuru
                </a>

            </li>
            <li class="br-menu-item-new">
                <a title="" class="br-menu-item-link" href="<?= base_url(admin_url() . "bayiler"); ?>">
                    <i class="menu-item-icon fas fa-user tx-20"></i><span class="br-menu-tt menu-item-label ">Bayilik
                        Başvuru
                </a>
            </li>

            <label class="sidebar-label custom-side-bar-label tx-info">Pos & Banka & Muhasebe</label>

            <li class="br-menu-item-new">
                <a title="" class="br-menu-item-link" href="<?= base_url(admin_url() . "bayiler"); ?>">
                    <i class="menu-item-icon fas fa-dollar-sign tx-20"></i><span class="br-menu-tt menu-item-label ">
                        Ödeme Yöntemleri
                </a>
            </li>

            <li class="br-menu-item-new">
                <a title="" class="br-menu-item-link" href="">
                    <i class="menu-item-icon fas fa-piggy-bank tx-20"></i><span
                            class="br-menu-tt menu-item-label ">Banka
                        Hesapları</span>
                    <i class="fas fa-chevron-right br-menu-arrow menu-item-label"></i>
                </a>


                <ul class="br-menu-item-new-sub-list">
                    <li class="br-menu-item-new-sub-list-item">
                        <a title="" class="br-menu-item-new-sub-list-item-link"
                           href="<?= base_url(admin_url() . "banka-hesabi-ekle"); ?>"><i
                                    class="fas fa-circle l-dot"></i>Yeni Banka Hesabı Ekle
                        </a>
                    </li>
                    <li class="br-menu-item-new-sub-list-item">
                        <a title="" class="br-menu-item-new-sub-list-item-link"
                           href="<?= base_url(admin_url() . "banka-hesaplari"); ?>"><i
                                    class="fas fa-circle l-dot"></i>Banka Hesapları</a>
                    </li>
                </ul>
            </li>

            <li class="br-menu-item-new">
                <a title="" class="br-menu-item-link" href="<?= base_url(admin_url() . "para-cekme-ayarlari"); ?>">
                    <i class="menu-item-icon fas fa-cogs tx-20"></i><span class="br-menu-tt menu-item-label ">Kullanıcı Banka Hesapları</span>
                </a>
            </li>


            <li class="br-menu-item-new">
                <a title="" class="br-menu-item-link" href="<?= base_url(admin_url() . "bakiyeler"); ?>">
                    <i class="menu-item-icon fas fa-coins tx-20"></i><span class="br-menu-tt menu-item-label ">Sanal Pos Geçmişi</span>
                </a>
            </li>

            <li class="br-menu-item-new">
                <a title="" class="br-menu-item-link" href="">
                    <i class="menu-item-icon fas fa-lira-sign tx-20"></i>
                    <span class="br-menu-tt menu-item-label "> Para Çekim Talepleri</span>

                    <i class="fas fa-chevron-right br-menu-arrow menu-item-label"></i>
                </a>
                <ul class="br-menu-item-new-sub-list">
                    <li class="br-menu-item-new-sub-list-item">
                        <a title="" class="br-menu-item-new-sub-list-item-link"
                           href="<?= base_url(admin_url() . "odeme-talepleri"); ?>">
                            <i class="fas fa-circle l-dot"></i>Kullanıcı Çekim Talepler</a>
                    </li>
                    <li class="br-menu-item-new-sub-list-item">
                        <a title="" class="br-menu-item-new-sub-list-item-link"
                           href="<?= base_url(admin_url() . "bekleyen-odemeler"); ?>"><i
                                    class="fas fa-circle l-dot"></i>Kullanıcı Onay Bekleyen Talepler</a>
                    </li>
                    <li class="br-menu-item-new-sub-list-item">
                        <a title="" class="br-menu-item-new-sub-list-item-link"
                           href="<?= base_url(admin_url() . "bayi-odeme-talepleri"); ?>"><i
                                    class="fas fa-circle l-dot"></i>Bayi Para Çekme Talepler</a>
                    </li>
                    <li class="br-menu-item-new-sub-list-item">
                        <a title="" class="br-menu-item-new-sub-list-item-link"
                           href="<?= base_url(admin_url() . "bayi-bekleyen-odemeler"); ?>"><i
                                    class="fas fa-circle l-dot"></i>Bayi Onay Bekleyen Talepler</a>
                    </li>
                </ul>
            </li>

            <li class="br-menu-item-new">
                <a title="" class="br-menu-item-link" href="">
                    <i class="menu-item-icon fas fa-store tx-20"></i>
                    <span class="br-menu-tt menu-item-label ">Havale İşlemleri</span>
                    <i class="fas fa-chevron-right br-menu-arrow menu-item-label"></i>
                </a>
                <ul class="br-menu-item-new-sub-list">
                    <li class="br-menu-item-new-sub-list-item">
                        <a title="" class="br-menu-item-new-sub-list-item-link"
                           href="<?= base_url(admin_url() . "bakiye-yukleme-talepleri"); ?>"><i
                                    class="fas fa-circle l-dot"></i>Onaylanan Talepler </a>
                    </li>
                    <li class="br-menu-item-new-sub-list-item">
                        <a title="" class="br-menu-item-new-sub-list-item-link"
                           href="<?= base_url(admin_url() . "bekleyen-bakiye-talepleri"); ?>"><i
                                    class="fas fa-circle l-dot"></i>Onay Bekleyen Talepler</a>
                    </li>
                </ul>
            </li>


            <label class="sidebar-label custom-side-bar-label tx-info">Destek Talepleri</label>


            <li class="br-menu-item-new">
            <a title="" class="br-menu-item-link" href="">
                    <i class="menu-item-icon fas fa-store tx-20"></i>
                    <span class="br-menu-tt menu-item-label ">Destek Talepleri</span>
                    <i class="fas fa-chevron-right br-menu-arrow menu-item-label"></i>
                </a>

                </a>
                <ul class="br-menu-item-new-sub-list">
                    <li class="br-menu-item-new-sub-list-item">
                        <a title="" class="br-menu-item-new-sub-list-item-link"
                            href="<?= base_url(admin_url() . "destek-talepleri"); ?>"><i
                                class="fas fa-circle l-dot"></i>Destek Talepleri</a>
                    </li>
                    <li class="br-menu-item-new-sub-list-item">
                        <a title="" class="br-menu-item-new-sub-list-item-link"
                            href="<?= base_url(admin_url() . "bekleyen-talepler"); ?>"><i
                                class="fas fa-circle l-dot"></i>Onay Bekleyen Talepler</a>
                    </li>

                </ul>
            </li>

            <label class="sidebar-label custom-side-bar-label tx-info">Header & Anasayfa & Başlıklar</label>

            <li class="br-menu-item-new">
                <a title="" class="br-menu-item-link" href="">
                    <i class="menu-item-icon fas fa-list-alt tx-20"></i>
                    <span class="br-menu-tt menu-item-label ">Header </span>
                    <i class="fas fa-chevron-right br-menu-arrow menu-item-label"></i>
                </a>


                <ul class="br-menu-item-new-sub-list">
                    <li class="br-menu-item-new-sub-list-item">
                        <a title="" class="br-menu-item-new-sub-list-item-link"
                           href="<?= base_url(admin_url() . "header"); ?>"><i class="fas fa-circle l-dot"></i>Header
                            Sistemi
                        </a>
                    </li>
                    <?php if (1 == 2) { ?>
                    <li class="br-menu-item-new-sub-list-item">
                        <a title="" class="br-menu-item-new-sub-list-item-link"
                           href="<?= base_url(admin_url() . "dropdown"); ?>"><i
                                    class="fas fa-circle l-dot"></i>Dropdown</a>
                    </li>
                    <?php } ?>
                </ul>
            </li>

            <li class="br-menu-item-new">
                <a title="" class="br-menu-item-link" href="">
                    <i class="menu-item-icon fas fa-shopping-basket tx-20"></i><span
                            class="br-menu-tt menu-item-label ">Anasayfa Vitrinler</span>
                    <i class="fas fa-chevron-right br-menu-arrow menu-item-label"></i>
                </a>
                <ul class="br-menu-item-new-sub-list">
                    <li class="br-menu-item-new-sub-list-item">
                        <a title="" class="br-menu-item-new-sub-list-item-link"
                           href="<?= base_url(admin_url() . "vitrin-ekle"); ?>"><i class="fas fa-circle l-dot"></i>
                            Vitrin Ekle</a>
                    </li>
                    <li class="br-menu-item-new-sub-list-item">
                        <a title="" class="br-menu-item-new-sub-list-item-link"
                           href="<?= base_url(admin_url() . "vitrinler"); ?>"><i class="fas fa-circle l-dot"></i>
                            Vitrinler</a>
                    </li>
                </ul>
            </li>

            <li class="br-menu-item-new">
                <a title="" class="br-menu-item-link" href="">
                    <i class="menu-item-icon far fa-images tx-20"></i><span
                            class="br-menu-tt menu-item-label ">Slider</span>
                    <i class="fas fa-chevron-right br-menu-arrow menu-item-label"></i>
                </a>


                <ul class="br-menu-item-new-sub-list">
                    <li class="br-menu-item-new-sub-list-item">
                        <a title="" class="br-menu-item-new-sub-list-item-link"
                           href="<?= base_url(admin_url() . "slider-ekle"); ?>"><i class="fas fa-circle l-dot"></i>Yeni
                            Slider Ekle
                        </a>
                    </li>
                    <li class="br-menu-item-new-sub-list-item">
                        <a title="" class="br-menu-item-new-sub-list-item-link"
                           href="<?= base_url(admin_url() . "slider"); ?>"><i class="fas fa-circle l-dot"></i>Orta
                            Slider</a>
                    </li>
                    <li class="br-menu-item-new-sub-list-item">
                        <a title="" class="br-menu-item-new-sub-list-item-link"
                           href="<?= base_url(admin_url() . "yan-slider"); ?>"><i class="fas fa-circle l-dot"></i>Yan
                            Slider</a>
                    </li>
                    <li class="br-menu-item-new-sub-list-item">
                        <a title="" class="br-menu-item-new-sub-list-item-link"
                           href="<?= base_url(admin_url() . "alt-slider"); ?>"><i class="fas fa-circle l-dot"></i>Alt
                            Slider</a>
                    </li>
                </ul>
            </li>

            <li class="br-menu-item-new">
                <a title="" class="br-menu-item-link" href="">
                    <i class="menu-item-icon fas fa-cart-plus tx-20"></i><span
                            class="br-menu-tt menu-item-label ">Anasayfa Reklamlar</span>
                    <i class="fas fa-chevron-right br-menu-arrow menu-item-label"></i>
                </a>


                <ul class="br-menu-item-new-sub-list">
                    <li class="br-menu-item-new-sub-list-item">
                        <a title="" class="br-menu-item-new-sub-list-item-link"
                           href="<?= base_url(admin_url() . "reklam-ekle"); ?>"><i class="fas fa-circle l-dot"></i>Yeni
                            Reklam Ekle
                        </a>
                    </li>
                    <li class="br-menu-item-new-sub-list-item">
                        <a title="" class="br-menu-item-new-sub-list-item-link"
                           href="<?= base_url(admin_url() . "ust-reklam"); ?>"><i class="fas fa-circle l-dot"></i>Üst
                            Reklam</a>
                    </li>
                    <li class="br-menu-item-new-sub-list-item">
                        <a title="" class="br-menu-item-new-sub-list-item-link"
                           href="<?= base_url(admin_url() . "alt-reklam"); ?>"><i class="fas fa-circle l-dot"></i>Alt
                            Reklam</a>
                    </li>
                </ul>
            </li>


            <label class="sidebar-label custom-side-bar-label tx-info">Sözleşme & SSS & Blog</label>

            <li class="br-menu-item-new">
                <a title="" class="br-menu-item-link" href="">
                    <i class="menu-item-icon far fa-file-alt tx-20"></i><span
                            class="br-menu-tt menu-item-label ">Sayfalar</span>
                    <i class="fas fa-chevron-right br-menu-arrow menu-item-label"></i>
                </a>


                <ul class="br-menu-item-new-sub-list">
                    <li class="br-menu-item-new-sub-list-item">
                        <a title="" class="br-menu-item-new-sub-list-item-link"
                           href="<?= base_url(admin_url() . "sayfa-ekle"); ?>"><i class="fas fa-circle l-dot"></i>Sayfa
                            Ekle
                        </a>
                    </li>
                    <li class="br-menu-item-new-sub-list-item">
                        <a title="" class="br-menu-item-new-sub-list-item-link"
                           href="<?= base_url(admin_url() . "sayfalar"); ?>"><i
                                    class="fas fa-circle l-dot"></i>Sayfalar</a>
                    </li>
                </ul>
            </li>

            <li class="br-menu-item-new">
                <a title="" class="br-menu-item-link" href="">
                    <i class="menu-item-icon fas fa-info-circle tx-20"></i><span
                            class="br-menu-tt menu-item-label ">SSS</span>
                    <i class="fas fa-chevron-right br-menu-arrow menu-item-label"></i>
                </a>


                <ul class="br-menu-item-new-sub-list">
                    <li class="br-menu-item-new-sub-list-item">
                        <a title="" class="br-menu-item-new-sub-list-item-link"
                           href="<?= base_url(admin_url() . "sss-ekle"); ?>"><i class="fas fa-circle l-dot"></i>Yeni
                            SSS
                            Ekle
                        </a>
                    </li>
                    <li class="br-menu-item-new-sub-list-item">
                        <a title="" class="br-menu-item-new-sub-list-item-link"
                           href="<?= base_url(admin_url() . "sss"); ?>"><i class="fas fa-circle l-dot"></i>SSS</a>
                    </li>
                </ul>
            </li>

            <li class="br-menu-item-new">
                <a title="" class="br-menu-item-link" href="">
                    <i class="menu-item-icon fas fa-edit tx-20"></i><span
                            class="br-menu-tt menu-item-label ">Blog</span>
                    <i class="fas fa-chevron-right br-menu-arrow menu-item-label"></i>
                </a>


                <ul class="br-menu-item-new-sub-list">
                    <li class="br-menu-item-new-sub-list-item">
                        <a title="" class="br-menu-item-new-sub-list-item-link"
                           href="<?= base_url(admin_url() . "blog-ekle"); ?>"><i class="fas fa-circle l-dot"></i>Yeni
                            Blog
                            Ekle
                        </a>
                    </li>
                    <li class="br-menu-item-new-sub-list-item">
                        <a title="" class="br-menu-item-new-sub-list-item-link"
                           href="<?= base_url(admin_url() . "bloglar"); ?>"><i
                                    class="fas fa-circle l-dot"></i>Bloglar</a>
                    </li>
                    <li class="br-menu-item-new-sub-list-item">
                        <a title="" class="br-menu-item-new-sub-list-item-link"
                           href="<?= base_url(admin_url() . "blog-kategori"); ?>"><i
                                    class="fas fa-circle l-dot"></i>Blog
                            Kategoriler</a>
                    </li>
                </ul>
            </li>

            <label class="sidebar-label custom-side-bar-label tx-info">Kullanıcı Yönetimi</label>

            <li class="br-menu-item-new">
                <a title="" class="br-menu-item-link" href="">
                    <i class="menu-item-icon fas fa-users tx-20"></i><span
                            class="br-menu-tt menu-item-label ">Kullanıcılar</span>
                    <i class="fas fa-chevron-right br-menu-arrow menu-item-label"></i>
                </a>


                <ul class="br-menu-item-new-sub-list">
                    <li class="br-menu-item-new-sub-list-item">
                        <a title="" class="br-menu-item-new-sub-list-item-link"
                           href="<?= base_url(admin_url() . "kullanici-ekle"); ?>"><i
                                    class="fas fa-circle l-dot"></i>Yeni
                            Kullanıcı Ekle
                        </a>
                    </li>
                    <li class="br-menu-item-new-sub-list-item">
                        <a title="" class="br-menu-item-new-sub-list-item-link"
                           href="<?= base_url(admin_url() . "kullanicilar"); ?>"><i
                                    class="fas fa-circle l-dot"></i>Kullanıcılar</a>
                    </li>
                </ul>
            </li>



            <label class="sidebar-label custom-side-bar-label tx-info">Site Yönetimi</label>
            <?php if (1 == 2) { ?>
            <li class="br-menu-item-new">
                <a title="" class="br-menu-item-link" href="<?= base_url(admin_url() . "site-ayarlari"); ?>">
                    <i class="menu-item-icon fas fa-cogs tx-20"></i><span class="br-menu-tt menu-item-label ">Site
                        Ayarları</span>
                </a>
            </li>
            <?php } ?>




            <li class="br-menu-item-new">
                <a title="" class="br-menu-item-link" href="<?= base_url(admin_url() . "genel-ayarlar"); ?>">
                    <i class="menu-item-icon fas fa-cogs tx-20"></i><span class="br-menu-tt menu-item-label">Genel Ayarlar</span>
                </a>
            </li>
            <li class="br-menu-item-new">
                <a title="" class="br-menu-item-link" href="<?= base_url(admin_url() . "komisyon-ayarlari"); ?>">
                    <i class="menu-item-icon fas fa-cogs tx-20"></i><span class="br-menu-tt menu-item-label">Komisyon Ayarları</span>
                </a>
            </li>
            <li class="br-menu-item-new">
                <a title="" class="br-menu-item-link" href="<?= base_url(admin_url() . "odeme-yontemleri-ayarlari"); ?>">
                    <i class="menu-item-icon fas fa-cogs tx-20"></i><span class="br-menu-tt menu-item-label">Ödeme Yöntemleri</span>
                </a>
            </li>
            <li class="br-menu-item-new">
                <a title="" class="br-menu-item-link" href="<?= base_url(admin_url() . "yonetim-url-ayarlari"); ?>">
                    <i class="menu-item-icon fas fa-cogs tx-20"></i><span class="br-menu-tt menu-item-label">Yönetim Paneli URL</span>
                </a>
            </li>
            <li class="br-menu-item-new">
                <a title="" class="br-menu-item-link" href="<?= base_url(admin_url() . "logo-favicon-ayarlari"); ?>">
                    <i class="menu-item-icon fas fa-cogs tx-20"></i><span class="br-menu-tt menu-item-label">Logo & Favicon Ayarları</span>
                </a>
            </li>
            <li class="br-menu-item-new">
                <a title="" class="br-menu-item-link" href="<?= base_url(admin_url() . "google-api-ayarlari"); ?>">
                    <i class="menu-item-icon fas fa-cogs tx-20"></i><span class="br-menu-tt menu-item-label">Google API Ayarları</span>
                </a>
            </li>
            <li class="br-menu-item-new">
                <a title="" class="br-menu-item-link" href="<?= base_url(admin_url() . "footer-ayarlari"); ?>">
                    <i class="menu-item-icon fas fa-cogs tx-20"></i><span class="br-menu-tt menu-item-label">Footer Ayarları</span>
                </a>
            </li>
            <li class="br-menu-item-new">
                <a title="" class="br-menu-item-link" href="<?= base_url(admin_url() . "subheader-ayarlari"); ?>">
                    <i class="menu-item-icon fas fa-cogs tx-20"></i><span class="br-menu-tt menu-item-label">Sub Header Ayarları</span>
                </a>
            </li>
            <li class="br-menu-item-new">
                <a title="" class="br-menu-item-link" href="<?= base_url(admin_url() . "smtp-ayarlari"); ?>">
                    <i class="menu-item-icon fas fa-cogs tx-20"></i><span class="br-menu-tt menu-item-label">SMTP Ayarları</span>
                </a>
            </li>
            <li class="br-menu-item-new">
                <a title="" class="br-menu-item-link" href="<?= base_url(admin_url() . "netgsm-ayarlari"); ?>">
                    <i class="menu-item-icon fas fa-cogs tx-20"></i><span class="br-menu-tt menu-item-label">NetGSM Ayarları</span>
                </a>
            </li>
            <li class="br-menu-item-new">
                <a title="" class="br-menu-item-link" href="<?= base_url(admin_url() . "giris-reklam-ayarlari"); ?>">
                    <i class="menu-item-icon fas fa-cogs tx-20"></i><span class="br-menu-tt menu-item-label">Giriş Reklam Ayarları</span>
                </a>
            </li>
            <li class="br-menu-item-new">
                <a title="" class="br-menu-item-link" href="<?= base_url(admin_url() . "canli-destek-ayarlari"); ?>">
                    <i class="menu-item-icon fas fa-cogs tx-20"></i><span class="br-menu-tt menu-item-label">Canlı Destek Ayarları</span>
                </a>
            </li>
            <li class="br-menu-item-new">
                <a title="" class="br-menu-item-link" href="<?= base_url(admin_url() . "sozlesmeler"); ?>">
                    <i class="menu-item-icon fas fa-cogs tx-20"></i><span class="br-menu-tt menu-item-label">Sözleşmeler</span>
                </a>
            </li>
            <li class="br-menu-item-new">
                <a title="" class="br-menu-item-link" href="<?= base_url(admin_url() . "turkpin-ayarlari"); ?>">
                    <i class="menu-item-icon fas fa-cogs tx-20"></i><span class="br-menu-tt menu-item-label">Türkpin Ayarları</span>
                </a>
            </li>
            <li class="br-menu-item-new">
                <a title="" class="br-menu-item-link" href="<?= base_url(admin_url() . "giris-kayit-yazi-ayarlari"); ?>">
                    <i class="menu-item-icon fas fa-cogs tx-20"></i><span class="br-menu-tt menu-item-label">Giriş & Kayıt Yazı</span>
                </a>
            </li>


            <label class="sidebar-label custom-side-bar-label tx-info">Yönetici & Sunucu Bilgileri</label>
        </ul>
    </div>

    <?php $kullanici = active_user(); ?> <div class="info-list">
        <div class="info-list-item">
            <div>
                <p class="info-list-label">SON GİRİŞ ZAMANI</p>
                <h5 class="info-list-amount"> <?= zamanCevir($kullanici->kullanici_sonzaman); ?> </h5>
            </div>
        </div>
        <div class="info-list-item">
            <div>
                <p class="info-list-label">HOSTİNG/SUNUCU İP</p>
                <h5 class="info-list-amount"> <?= $_SERVER['SERVER_ADDR']; ?> </h5>
            </div>
        </div>
        <div class="info-list-item">
            <div>
                <p class="info-list-label">İP ADRESİNİZ</p>
                <h5 class="info-list-amount"> <?= $_SERVER['REMOTE_ADDR']; ?> </h5>
            </div>
        </div>
    </div>

</div>