</div>
<script src="<?= base_url('assets/yonetim/') ?>lib/jquery-ui/ui/widgets/datepicker.js"></script>
<script src="<?= base_url('assets/yonetim/') ?>lib/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?= base_url('assets/yonetim/') ?>lib/perfect-scrollbar/perfect-scrollbar.min.js"></script>
<script src="<?= base_url('assets/yonetim/') ?>lib/moment/min/moment.min.js"></script>
<script src="<?= base_url('assets/yonetim/') ?>lib/peity/jquery.peity.min.js"></script>
<script src="<?= base_url('assets/yonetim/') ?>lib/rickshaw/vendor/d3.min.js"></script>
<script src="<?= base_url('assets/yonetim/') ?>lib/rickshaw/vendor/d3.layout.min.js"></script>
<script src="<?= base_url('assets/yonetim/') ?>lib/rickshaw/rickshaw.min.js"></script>
<script src="<?= base_url('assets/yonetim/') ?>lib/jquery.flot/jquery.flot.js"></script>
<script src="<?= base_url('assets/yonetim/') ?>lib/jquery.flot/jquery.flot.resize.js"></script>
<script src="<?= base_url('assets/yonetim/') ?>lib/flot-spline/js/jquery.flot.spline.min.js"></script>
<script src="<?= base_url('assets/yonetim/') ?>lib/jquery-sparkline/jquery.sparkline.min.js"></script>

<script src="<?= base_url('assets/yonetim/') ?>lib/echarts/echarts.min.js"></script>
<script src="<?= base_url('assets/yonetim/') ?>lib/select2/js/select2.full.min.js"></script>

<script src="<?= base_url('assets/yonetim/') ?>lib/highlightjs/highlight.pack.min.js"></script>
<script src="<?= base_url('assets/yonetim/') ?>lib/select2/js/select2.min.js"></script>

<script src="<?php echo base_url('assets/yonetim/js/dropzone.min.js?v=1.2') ?>"></script>


<script src="https://jsuites.net/v4/jsuites.js"></script>
<script src="https://jsuites.net/v4/jsuites.webcomponents.js"></script>



<script src="<?= base_url('assets/yonetim/') ?>lib/datatables.net/js/jquery.dataTables.min.js?v=1"></script>
<script src="<?= base_url('assets/yonetim/') ?>lib/datatables.net-dt/js/dataTables.dataTables.min.js"></script>
<script src="<?= base_url('assets/yonetim/') ?>js/app.js"></script>


<script src="<?= base_url('assets/yonetim/') ?>js/bracket.js?v=1.2.3"></script>
<script src="<?= base_url('assets/yonetim/') ?>js/ResizeSensor.js"></script>
<script src="<?= base_url("assets") ?>/js/iziToast.min.js"></script>

<script>

    $(document).ready(function() {
        $('.ckeditor').summernote({
            height: 200,
            placeholder: "Metin",

            toolbar: [
                ['style', ['bold', 'italic', 'underline', 'clear']],
                ['font', ['strikethrough', 'superscript', 'subscript']],
                ['fontsize', ['fontsize']],
                ['color', ['color']],
                ['para', ['ul', 'ol', 'paragraph']],
                ['height', ['height']],
                ['fontname', ['fontname']],
                ['table', ['table']],
                ['insert', ['link', 'picture', 'video']],
                ['view', ['fullscreen', 'codeview', 'help']],
            ],
        });
    });

    $(function () {
        'use strict';

        $('#datatable1').DataTable({
            bSort: false,
            responsive: true,
            language: {
                searchPlaceholder: 'Arama...',
                sSearch: '',
            }
        });
        $('#datatable2').DataTable({
            bSort: false,
            responsive: true,
            language: {
                searchPlaceholder: 'Arama...',
                sSearch: '',
            }
        });

        $('.fc-datepicker').datepicker({
            showOtherMonths: true,
            dateFormat: "dd.mm.yy",
            selectOtherMonths: true,
            monthNames: ["Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran", "Temmuz", "Ağustos", "Eylül", "Ekim", "Kasım", "Aralık"],
            dayNamesMin: ["Pa", "Pt", "Sl", "Ça", "Pe", "Cu", "Ct"],
            firstDay: 1
        });

    });

    /**
     * Mağaza Kullanıcı Adı Kontrol
     */
    function checkUsername() {
        var seo = $(".magaza_kullanici").val();
        $.ajax({
            type: 'post',
            url: 'ajax_controller/username_check',
            data: {seo: ToSeoUrl(seo)},
            dataType: 'json',
            success: function (response) {
                //alert(response.durum);
                if (response.durum == "success") {
                    $('.magaza_kullanici').removeClass('is-invalid');
                    $('.magaza_kullanici').addClass('is-valid');
                } else if (response.durum == "error") {
                    $('.magaza_kullanici').removeClass('is-valid');
                    $('.magaza_kullanici').addClass('is-invalid');
                }
            }
        });
    }

    $('.magaza_kullanici').keyup(function () {
        if (!$('.url_ad').html()) {
            $('.url_ad').html("firma-adi");
        } else {
            $('.url_ad').html(ToSeoUrl($(this).val()));
        }
    });

    /**
     * Yazılan Kelimeyi Seo Çevirme
     */
    function ToSeoUrl(textString) {

        textString = textString.replace(/ /g, "-");
        textString = textString.replace(/</g, "");
        textString = textString.replace(/>/g, "");
        textString = textString.replace(/"/g, "");
        textString = textString.replace(/é/g, "");
        textString = textString.replace(/!/g, "");
        textString = textString.replace(/’/, "");
        textString = textString.replace(/£/, "");
        textString = textString.replace(/^/, "");
        textString = textString.replace(/#/, "");
        textString = textString.replace(/$/, "");
        textString = textString.replace(/\+/g, "");
        textString = textString.replace(/%/g, "");
        textString = textString.replace(/½/g, "");
        textString = textString.replace(/&/g, "");
        textString = textString.replace(/\//g, "");
        textString = textString.replace(/{/g, "");
        textString = textString.replace(/\(/g, "");
        textString = textString.replace(/\[/g, "");
        textString = textString.replace(/\)/g, "");
        textString = textString.replace(/]/g, "");
        textString = textString.replace(/=/g, "");
        textString = textString.replace(/}/g, "");
        textString = textString.replace(/\?/g, "");
        textString = textString.replace(/\*/g, "");
        textString = textString.replace(/@/g, "");
        textString = textString.replace(/€/g, "");
        textString = textString.replace(/~/g, "");
        textString = textString.replace(/æ/g, "");
        textString = textString.replace(/ß/g, "");
        textString = textString.replace(/;/g, "");
        textString = textString.replace(/,/g, "");
        textString = textString.replace(/`/g, "");
        textString = textString.replace(/|/g, "");
        textString = textString.replace(/\./g, "");
        textString = textString.replace(/:/g, "");
        textString = textString.replace(/İ/g, "i");
        textString = textString.replace(/I/g, "i");
        textString = textString.replace(/ı/g, "i");
        textString = textString.replace(/ğ/g, "g");
        textString = textString.replace(/Ğ/g, "g");
        textString = textString.replace(/ü/g, "u");
        textString = textString.replace(/Ü/g, "u");
        textString = textString.replace(/ş/g, "s");
        textString = textString.replace(/Ş/g, "s");
        textString = textString.replace(/ö/g, "o");
        textString = textString.replace(/Ö/g, "o");
        textString = textString.replace(/ç/g, "c");
        textString = textString.replace(/Ç/g, "c");
        textString = textString.replace(/–/g, "-");
        textString = textString.replace(/—/g, "-");
        textString = textString.replace(/—-/g, "-");
        textString = textString.replace(/—-/g, "-");

        return textString.toLowerCase();
    }

    /**
     * Kategori
     */
    <?php $ayarlar = ayarlar(); ?>
    <?php if (($this->uri->segment(2) == "urun-duzenle") || ($this->uri->segment(2) == "ilan-duzenle") ) {  ?>
    //$("#kategori").select2().val(<?= $urun->kategori_json ?>).trigger('change');
    <?php } ?>
    $("#sayfa_kategori").select2().val(<?= $ayarlar->kategori_json ?>).trigger('change');


</script>
<?php

$alert = $this->session->userdata("alert");

if ($alert) {

    if ($alert["type"] === "success") { ?>

        <script type="text/javascript">
            iziToast.success({
                title: '<?=$alert["title"]?>',
                message: '<?=$alert["text"]?>',
                position: 'topCenter'
            });
        </script>

    <?php } else { ?>

        <script type="text/javascript">
            iziToast.<?=$alert["type"]?>({
                title: '<?=$alert["title"]?>',
                message: '<?=$alert["text"]?>',
                position: 'topCenter'
            });
        </script>

    <?php }
} ?>
</body>


</html>