    <script src="<?=base_url('assets/yonetim/')?>lib/jquery/jquery.min.js"></script>
    <script src="<?=base_url('assets/yonetim/')?>lib/jquery-ui/ui/widgets/datepicker.js"></script>
    <script src="<?=base_url('assets/yonetim/')?>lib/bootstrap/js/bootstrap.bundle.min.js"></script>
    <?php 

    $alert = $this->session->userdata("alert");

    if ($alert) {
    	
    	if ($alert["type"] === "success") { ?>

    		<script type="text/javascript">
    			iziToast.success({
    				title: '<?=$alert["title"]?>',
    				message: '<?=$alert["text"]?>',
    				position: 'topCenter'
    			});
    		</script>
    		
    	<?php  } else { ?>

    		<script type="text/javascript">
    			iziToast.<?=$alert["type"]?>({
    				title: '<?=$alert["title"]?>',
    				message: '<?=$alert["text"]?>',
    				position: 'topCenter'
    			});
    		</script>

    	<?php } 
    } ?>
</body>
</html>