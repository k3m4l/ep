<style>
    body {
        margin-top: 20px;
        background: #FAFAFA;
    }

    .order-card {
        color: #fff;
    }

    .bg-c-blue {
        background: linear-gradient(45deg, #4099ff, #73b4ff);
    }

    .bg-c-green {
        background: linear-gradient(45deg, #2ed8b6, #59e0c5);
    }

    .bg-c-yellow {
        background: linear-gradient(45deg, #FFB64D, #ffcb80);
    }

    .bg-c-pink {
        background: linear-gradient(45deg, #FF5370, #ff869a);
    }


    .card {
        border-radius: 5px;
        -webkit-box-shadow: 0 1px 2.94px 0.06px rgba(4, 26, 55, 0.16);
        box-shadow: 0 1px 2.94px 0.06px rgba(4, 26, 55, 0.16);
        border: none;
        margin-bottom: 30px;
        -webkit-transition: all 0.3s ease-in-out;
        transition: all 0.3s ease-in-out;
    }

    .card .card-block {
        padding: 25px;
    }

    .order-card i {
        font-size: 26px;
    }

    .f-left {
        float: left;
    }

    .f-right {
        float: right;
    }
</style>

<div class="br-pagebody">
    <div class="row">
        <div class="col-xl-4 col-md-6 col-12 mb-3 mt-3">
            <div class="card">
                <div class="card-content">
                    <div class="card-body mh-85 bc-22">
                        <div class="card-img-body">
                            <div class="media  ">
                                <div class="card-img-body-warper">
                                    <img class="card-img-body-icon"
                                        src="<?= base_url('assets/yonetim/img/wallet.png') ?>" alt="">
                                </div>
                                <div class="media-body text-right-c">
									<h3>
										<?= 
											(floatval(number_format($toplamurunpara, 2, '.', '')) ?? 0) + 
											(floatval(number_format($toplamilanpara, 2, '.', '')) ?? 0)
										?> TL
									</h3>
									<span>Toplam Kazanç</span>
								</div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <div class="col-xl-4 col-md-6 col-12 mb-3 mt-3">
            <div class="card">
                <div class="card-body mh-85 bc-22">
                    <div class="card-img-body">
                        <div class="media  ">
                            <div class="card-img-body-warper">
                                <img class="card-img-body-icon" src="<?= base_url('assets/yonetim/img/earnings.png') ?>"
                                    alt="">
                            </div>
                            <div class="media-body text-right-c">
								<?php 
									$buayilanparaNumeric = floatval($buayilanpara ?? 0); 
									$buayurunparaNumeric = floatval($buayurunpara ?? 0);
									$toplamKazanc = $buayilanparaNumeric + $buayurunparaNumeric;
								?>
								<h3><?= number_format($toplamKazanc, 2, ',', '.') ?> TL</h3>
								<span><span class="calander-date"><?php echo get_months(date('m')) ?></span> Ayı Toplam Kazanç</span>
							</div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-4 col-md-6 col-12 mb-3 mt-3">
            <div class="card">
                <div class="card-content">
                    <div class="card-body mh-85 bc-22">
                        <div class="card-img-body">
                            <div class="media  ">
                                <div class="card-img-body-warper">
                                    <img class="card-img-body-icon"
                                        src="<?= base_url('assets/yonetim/img/web-traffic.png') ?>" alt="">
                                </div>
                                <div class="media-body text-right-c">
                                    <h3>756</h3>
                                    <span>Günlük Satılan Ürünler</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-4 col-md-6 col-12 mb-3 mt-3">
            <div class="card">
                <div class="card-body mh-85 bc-22">
                    <div class="card-img-body">
                        <div class="media">
                            <div class="card-img-body-warper">
                                <img class="card-img-body-icon"
                                    src="<?= base_url('assets/yonetim/img/web-traffic2.png') ?>" alt="">
                            </div>
                            <div class="media-body text-right-c">
                                <h3>234</h3>
                                <span>Günlük Gold Alım - Satım</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-4 col-md-6 col-12 mb-3 mt-3">
            <div class="card">
                <div class="card-body mh-85 bc-22">
                    <div class="card-img-body">
                        <div class="media  ">
                            <div class="card-img-body-warper">
                                <img class="card-img-body-icon"
                                    src="<?= base_url('assets/yonetim/img/online-game.png') ?>" alt="">
                            </div>
                            <div class="media-body text-right-c">
                                <h3><?php echo $aktifkullanici ?></h3>
                                <span>Aktif Üye</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-4 col-md-6 col-12 mb-3 mt-3">
            <div class="card">
                <div class="card-body mh-85 bc-22">
                    <div class="card-img-body">
                        <div class="media  ">
                            <div class="card-img-body-warper">
                                <img class="card-img-body-icon"
                                    src="<?= base_url('assets/yonetim/img/community.png') ?>" alt="">
                            </div>
                            <div class="media-body text-right-c">
                                <h3><?= $toplamkullanici ?></h3>
                                <span>Toplam Üye</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-4 col-md-6 col-12 mb-3 mt-3">
            <div class="card">
                <div class="card-body mh-85">
                    <div class="card-img-body">
                        <div class="media  ">
                            <div class="card-img-body-warper">
                                <img class="card-img-body-icon" src="<?= base_url('assets/yonetim/img/menu.png') ?>"
                                    alt="">
                            </div>
                            <div class="media-body text-right">
                                <span>Kategori Yönetimi</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 p-10">
                    <a title="" class="" href="<?php echo base_url(admin_url().'kategori-ekle') ?>">
                        <div class="card w-100">
                            <div class="card-content">
                                <div class="card-body mini-card">
                                    <div class="media ">
                                        <div class="media-body text-right c-fsx">
                                            <span>Kategori ekle</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 p-10">
                    <a title="" class="" href="<?php echo base_url(admin_url().'kategoriler') ?>">
                        <div class="card w-100">
                            <div class="card-content">
                                <div class="card-body mini-card">
                                    <div class="media ">
                                        <div class="media-body text-right c-fsx">
                                            <span>Kategoriler</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 p-10">
                    <a title="" class="" href="<?php echo base_url(admin_url().'alt-kategoriler') ?>">
                        <div class="card w-100">
                            <div class="card-content">
                                <div class="card-body mini-card">
                                    <div class="media ">
                                        <div class="media-body text-right c-fsx">
                                            <span>Alt Kategoriler</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
        </div>



        <div class="col-xl-4 col-md-6 col-12 mb-3 mt-3">
            <div class="card">
                <div class="card-body mh-85">
                    <div class="card-img-body">
                        <div class="media  ">
                            <div class="card-img-body-warper">
                                <img class="card-img-body-icon"
                                    src="<?= base_url('assets/yonetim/img/product-management.png') ?>" alt="">
                            </div>
                            <div class="media-body text-right">
                                <span>Ürün Yönetimi</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 p-10">
                    <a title="" class="" href="<?php echo base_url(admin_url().'urunler') ?>">
                        <div class="card w-100">
                            <div class="card-content">
                                <div class="card-body mini-card">
                                    <div class="media ">
                                        <div class="media-body text-right c-fsx">
                                            <span>Ürünler</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 p-10">
                    <a title="" class="" href="<?php echo base_url(admin_url().'urun-ekle') ?>">
                        <div class="card w-100">
                            <div class="card-content">
                                <div class="card-body mini-card">
                                    <div class="media ">
                                        <div class="media-body text-right c-fsx">
                                            <span>Ürün Ekle</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
        </div>


        <div class="col-xl-4 col-md-6 col-12 mb-3 mt-3">
            <div class="card">
                <div class="card-body mh-85">
                    <div class="card-img-body">
                        <div class="media">
                            <div class="card-img-body-warper">
                                <img class="card-img-body-icon" src="<?= base_url('assets/yonetim/img/support.png') ?>"
                                    alt="">
                            </div>
                            <div class="media-body text-right">
                                <span>Destek Yönetimi</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 p-10">
                    <a title="" class="" href="<?php echo base_url(admin_url().'destek-talepleri') ?>">
                        <div class="card w-100">
                            <div class="card-content">
                                <div class="card-body mini-card">
                                    <div class="media ">
                                        <div class="media-body text-right c-fsx">
                                            <span> Destek Talepleri </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 p-10">
                    <a title="" class="" href="<?php echo base_url(admin_url().'bekleyen-talepler') ?>">
                        <div class="card w-100">
                            <div class="card-content">
                                <div class="card-body mini-card">
                                    <div class="media ">
                                        <div class="media-body text-right c-fsx">
                                            <span>Bekleyen Destek Talepleri</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
        </div>


        <div class="col-xl-4 col-md-6 col-12 mb-3 mt-3">
            <div class="card">
                <div class="card-body mh-85">
                    <div class="card-img-body">
                        <div class="media">
                            <div class="card-img-body-warper">
                                <img class="card-img-body-icon" src="<?= base_url('assets/yonetim/img/comments.png') ?>"
                                    alt="">
                            </div>
                            <div class="media-body text-right">
                                <span>Yorum Yönetimi</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 p-10">
                    <a title="" class="" href="<?php echo base_url(admin_url().'itiraz-talepleri') ?>">
                        <div class="card w-100">
                            <div class="card-content">
                                <div class="card-body mini-card">
                                    <div class="media ">
                                        <div class="media-body text-right c-fsx">
                                            <span> Yorum İtiraz Talepleri </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 p-10">
                    <a title="" class="" href="<?php echo base_url(admin_url().'bekleyen-yorumlar') ?>">
                        <div class="card w-100">
                            <div class="card-content">
                                <div class="card-body mini-card">
                                    <div class="media ">
                                        <div class="media-body text-right c-fsx">
                                            <span> Onay Bekleyen Yorumlar </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 p-10">
                    <a title="" class="" href="<?php echo base_url(admin_url().'yorumlar') ?>">
                        <div class="card w-100">
                            <div class="card-content">
                                <div class="card-body mini-card">
                                    <div class="media ">
                                        <div class="media-body text-right c-fsx">
                                            <span>Yorumlar</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
        </div>

        <div class="col-xl-4 col-md-6 col-12 mb-3 mt-3">
            <div class="card">
                <div class="card-body mh-85">
                    <div class="card-img-body">
                        <div class="media  ">
                            <div class="card-img-body-warper">
                                <img class="card-img-body-icon"
                                    src="<?= base_url('assets/yonetim/img/checklist.png') ?>" alt="">
                            </div>
                            <div class="media-body text-right">
                                <span>Sipariş Yönetimi</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 p-10">
                    <a title="" class="" href="<?php echo base_url(admin_url().'onaylanan-siparisler') ?>">
                        <div class="card w-100">
                            <div class="card-content">
                                <div class="card-body mini-card">
                                    <div class="media ">
                                        <div class="media-body text-right c-fsx">
                                            <span> Teslim Edilen Siparişler </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 p-10">
                    <a title="" class="" href="<?php echo base_url(admin_url().'key-bekleyen-siparisler') ?>">
                        <div class="card w-100">
                            <div class="card-content">
                                <div class="card-body mini-card">
                                    <div class="media ">
                                        <div class="media-body text-right c-fsx">
                                            <span>Key Bekleyen Siparişler </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 p-10">
                    <a title="" class="" href="<?php echo base_url(admin_url().'iptal-edilen-siparisler') ?>">
                        <div class="card w-100">
                            <div class="card-content">
                                <div class="card-body mini-card">
                                    <div class="media ">
                                        <div class="media-body text-right c-fsx">
                                            <span> İptal edilen Siparişler</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
        </div>


        <!-- Alt Row 3'lü !!!!!!!!! -->
        <div class="col-xl-4 col-md-6 col-12 mb-3 mt-3">
            <div class="card">
                <div class="card-body mh-85">
                    <div class="card-img-body">
                        <div class="media  ">
                            <div class="card-img-body-warper">
                                <img class="card-img-body-icon"
                                    src="<?= base_url('assets/yonetim/img/megaphone.png') ?>" alt="">
                            </div>
                            <div class="media-body text-right">
                                <span>İlan Yönetimi </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12 p-10">
                    <a title="" class="" href="<?php echo base_url(admin_url().'ilanlar') ?>">
                        <div class="card w-100">
                            <div class="card-content">
                                <div class="card-body mini-card">
                                    <div class="media ">
                                        <div class="media-body text-right c-fsx">
                                            <span> Onaylanan ilanlar </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12 p-10">
                    <a title="" class="" href="<?php echo base_url(admin_url().'bekleyen-ilanlar') ?>">
                        <div class="card w-100">
                            <div class="card-content">
                                <div class="card-body mini-card">
                                    <div class="media ">
                                        <div class="media-body text-right c-fsx">
                                            <span>Bekleyen ilanlar </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12 p-10">
                    <a title="" class="" href="<?php echo base_url(admin_url().'satin-alinan-ilanlar') ?>">
                        <div class="card w-100">
                            <div class="card-content">
                                <div class="card-body mini-card">
                                    <div class="media ">
                                        <div class="media-body text-right c-fsx">
                                            <span> Satın alınan ilanlar</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12 p-10">
                    <a title="" class="" href="<?php echo base_url(admin_url().'teslimat') ?>">
                        <div class="card w-100">
                            <div class="card-content">
                                <div class="card-body mini-card">
                                    <div class="media ">
                                        <div class="media-body text-right c-fsx">
                                            <span> Teslimat itirazları</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
        </div>



        <div class="col-xl-4 col-md-6 col-12 mb-3 mt-3">
            <div class="card">
                <div class="card-body mh-85">
                    <div class="card-img-body">
                        <div class="media  ">
                            <div class="card-img-body-warper">
                                <img class="card-img-body-icon" src="<?= base_url('assets/yonetim/img/verified.png') ?>"
                                    alt="">
                            </div>
                            <div class="media-body text-right">
                                <span>Başvuru Yönetimi </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 p-10">
                    <a title="" class="" href="<?php echo base_url(admin_url().'sponsorlar') ?>">
                        <div class="card w-100">
                            <div class="card-content">
                                <div class="card-body mini-card">
                                    <div class="media ">
                                        <div class="media-body text-right c-fsx">
                                            <span>Sponsorluk Başvurusu </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 p-10">
                    <a title="" class="" href="<?php echo base_url(admin_url().'bekleyen-magazalar') ?>">
                        <div class="card w-100">
                            <div class="card-content">
                                <div class="card-body mini-card">
                                    <div class="media ">
                                        <div class="media-body text-right c-fsx">
                                            <span> Onay Bekleyen Mağazalar</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 p-10">
                    <a title="" class="" href="<?php echo base_url(admin_url().'bayiler') ?>">
                        <div class="card w-100">
                            <div class="card-content">
                                <div class="card-body mini-card">
                                    <div class="media ">
                                        <div class="media-body text-right c-fsx">
                                            <span> Bayilik Başvurusu</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
        </div>

        <div class="col-xl-4 col-md-6 col-12 mb-3 mt-3">
            <div class="card">
                <div class="card-body mh-85">
                    <div class="card-img-body">
                        <div class="media">
                            <div class="card-img-body-warper">
                                <img class="card-img-body-icon" src="<?= base_url('assets/yonetim/img/winner.png') ?>"
                                    alt="">
                            </div>
                            <div class="media-body text-right">
                                <span>Çekiliş Yönetimi </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 p-10">
                    <a title="" class="" href="<?php echo base_url(admin_url().'cekilisler') ?>">
                        <div class="card w-100">
                            <div class="card-content">
                                <div class="card-body mini-card">
                                    <div class="media ">
                                        <div class="media-body text-right c-fsx">
                                            <span>Çekiliş Listesi</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 p-10">
                    <a title="" class="" href="<?php echo base_url(admin_url().'aktif-cekilisler') ?>">
                        <div class="card w-100">
                            <div class="card-content">
                                <div class="card-body mini-card">
                                    <div class="media ">
                                        <div class="media-body text-right c-fsx">
                                            <span> Aktif Çekilişler</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 p-10">
                    <a title="" class="" href="<?php echo base_url(admin_url().'tamamlanan-cekilisler') ?>">
                        <div class="card w-100">
                            <div class="card-content">
                                <div class="card-body mini-card">
                                    <div class="media ">
                                        <div class="media-body text-right c-fsx">
                                            <span> Biten Çekilişler</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
        </div>




        <div class="col-xl-4 col-md-6 col-12 mb-3 mt-3">
            <div class="card">
                <div class="card-body mh-85">
                    <div class="card-img-body">
                        <div class="media">
                            <div class="card-img-body-warper">
                                <img class="card-img-body-icon" src="<?= base_url('assets/yonetim/img/cost-per-click.png') ?>"
                                    alt="">
                            </div>
                            <div class="media-body text-right">
                                <span>Bakiye Talepleri  </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 p-10">
                    <a title="" class="" href="<?php echo base_url(admin_url().'bekleyen-bakiye-talepleri') ?>">
                        <div class="card w-100">
                            <div class="card-content">
                                <div class="card-body mini-card">
                                    <div class="media ">
                                        <div class="media-body text-right c-fsx">
                                            <span>Bakiye Yükleme Talepleri </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 p-10">
                    <a title="" class="" href="<?php echo base_url(admin_url().'odeme-talepleri') ?>">
                        <div class="card w-100">
                            <div class="card-content">
                                <div class="card-body mini-card">
                                    <div class="media ">
                                        <div class="media-body text-right c-fsx">
                                            <span>Para Çekme Talepleri</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 p-10">
                    <a title="" class="" href="<?php echo base_url(admin_url().'bayi-odeme-talepleri') ?>">
                        <div class="card w-100">
                            <div class="card-content">
                                <div class="card-body mini-card">
                                    <div class="media ">
                                        <div class="media-body text-right c-fsx">
                                            <span>Bayi Para çekme talepleri</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
        </div>





        <!-- 

        <div class="col-xl-4 col-md-6 col-12">
            <div class="card">
                <div class="card-content">
                    <div class="card-body">
                        <div class="media ">
                            <div class="media-body text-right">
                                <h3><?= $bekleyensiparis ?? '0' ?></h3>
                                <span>Bekleyen Siparişler</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-4 col-md-6 col-12">
            <div class="card">
                <div class="card-content">
                    <div class="card-body">
                        <div class="media ">
                            <div class="media-body text-right">
                                <h3><?= $bekleyencekim ?? '0' ?></h3>
                                <span>Bekleyen Çekim Talebi</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-4 col-md-6 col-12">
            <div class="card">
                <div class="card-content">
                    <div class="card-body">
                        <div class="media ">
                            <div class="media-body text-right">
                                <h3><?= $bekleyentalep ?? '0' ?></h3>
                                <span>Bekleyen Talepler</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-4 col-md-6 col-12">
            <div class="card">
                <div class="card-content">
                    <div class="card-body">
                        <div class="media ">
                            <div class="media-body text-right">
                                <h3><?= $bekleyenyorum ?? '0' ?></h3>
                                <span>Bekleyen Yorumlar</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <?php if (1 == 2) { ?>
        <div class=" col-xl-4 col-lg-6 col-md-6 col-sm-12">
            <div class="card bg-c-blue order-card">
                <div class="card-block">
                    <h5 class="m-b-20">Bekleyen Siparişler</h5>
                    <h6>
                        <strong><?= $bekleyensiparis ?? '' ?></strong><small style="font-size: 12px;"> adet bekleyen
                            siparişiniz bulunmaktadır.</small>
                    </h6>
                </div>
            </div>
        </div>
        <div class=" col-xl-4 col-lg-6 col-md-6 col-sm-12">
            <div class="card bg-c-green order-card">
                <div class="card-block">
                    <h5 class="m-b-20">Yeni Çekim Talepleri</h5>
                    <h6>
                        <strong><?= $bekleyencekim ?? '' ?></strong><small style="font-size: 12px;"> adet bekleyen
                            çekim talebiniz bulunmaktadır.</small>
                    </h6>
                </div>
            </div>
        </div>
        <div class=" col-xl-4 col-lg-6 col-md-6 col-sm-12">
            <div class="card bg-c-yellow order-card">
                <div class="card-block">
                    <h5 class="m-b-20">Bekleyen Talepler</h5>
                    <h6>
                        <strong><?= $bekleyentalep ?></strong><small style="font-size: 12px;"> adet bekleyen
                            talebiniz bulunmaktadır.</small>
                    </h6>
                </div>
            </div>
        </div>
        <div class=" col-xl-4 col-lg-6 col-md-6 col-sm-12">
            <div class="card bg-c-pink order-card">
                <div class="card-block">
                    <h5 class="m-b-20">Bekleyen Yorumlar</h5>
                    <h6>
                        <strong><?= $bekleyenyorum ?></strong><small style="font-size: 12px;"> adet bekleyen yorum
                            bulunmaktadır.</small>
                    </h6>
                </div>
            </div>
        </div>
        <?php } ?>
        <div class="col-md-12">
            <div class="row">
                <?php if (1 == 2) { ?>
                <div class="col-xl-3">
                    <div class="card">
                        <div class="card-header dash">
                            <div class="card-title dash">
                                <span>Hızlı İşlemler</span>
                            </div>
                        </div>
                        <div class="card-body">
                            <ul class="nav">
                                <li class="text-muted">
                                    <div class="menu-icon">
                                        <span class="badge badge-warning">
                                            <i class="fa fa-box"></i>
                                        </span>
                                        <strong>Ürünler</strong>
                                        <p>
                                            <small class="text-muted">Ürünlerinizi buradan görebilirsiniz</small>
                                        </p>
                                    </div>
                                </li>
                                <li class="text-muted">
                                    <div class="menu-icon">
                                        <span class="badge badge-success">
                                            <i class="fa fa-gamepad"></i>
                                        </span>
                                        <strong>İlanlar</strong>
                                        <p>
                                            <small class="text-muted">İlanlarınızı buradan görebilirsiniz</small>
                                        </p>
                                    </div>
                                </li>
                                <li class="text-muted">
                                    <div class="menu-icon">
                                        <span class="badge badge-info">
                                            <i class="fa fa-shopping-cart"></i>
                                        </span>
                                        <strong>Ürün Siparişleri</strong>
                                        <p>
                                            <small class="text-muted">Siparişlerinizi buradan görebilirsiniz</small>
                                        </p>
                                    </div>
                                </li>
                                <li class="text-muted">
                                    <div class="menu-icon">
                                        <span class="badge badge-primary">
                                            <i class="fa fa-shopping-basket"></i></span>
                                        </span>
                                        <strong>İlan Siparişleri</strong>
                                        <p>
                                            <small class="text-muted">Siparişlerinize buradan görebilirsiniz</small>
                                        </p>
                                    </div>
                                </li>
                                <li class="text-muted">
                                    <div class="menu-icon">
                                        <span class="badge badge-primary">
                                            <i class="fa fa-user"></i>
                                        </span>
                                        <strong>Çekim Talepleri</strong>
                                        <p>
                                            <small class="text-muted">Çekim taleplerinizi buradan
                                                görebilirsiniz</small>
                                        </p>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <?php } ?>
                <div class="col-md-12">
                    <div class="row">
                        <div class="col-xl-4 col-md-6 col-12">
                            <div class="card">
                                <div class="card-content">
                                    <div class="card-body">
                                        <div class="media d-flex">
                                            <div class="align-self-center">
                                                <img src="<?php echo base_url('assets/images/dash-icon/options-2.png') ?>"
                                                    alt="">
                                            </div>
                                            <div class="media-body text-right">
                                                <h3><?= $toplamkategori ?? '0' ?></h3>
                                                <span>Toplam Kategori</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-xl-4 col-md-6 col-12">
                            <div class="card">
                                <div class="card-content">
                                    <div class="card-body">
                                        <div class="media d-flex">
                                            <div class="align-self-center">
                                                <img src="<?php echo base_url('assets/images/dash-icon/carts.png') ?>"
                                                    alt="">
                                            </div>
                                            <div class="media-body text-right">
                                                <h3><?= $toplamurun ?? '0' ?></h3>
                                                <span>Toplam Ürün</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-xl-4 col-md-6 col-12">
                            <div class="card">
                                <div class="card-content">
                                    <div class="card-body">
                                        <div class="media d-flex">
                                            <div class="align-self-center">
                                                <img src="<?php echo base_url('assets/images/dash-icon/megaphone.png') ?>"
                                                    alt="">
                                            </div>
                                            <div class="media-body text-right">
                                                <h3><?= $toplamilan ?? '0' ?></h3>
                                                <span>Toplam İlan</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-xl-4 col-md-6 col-12">
                            <div class="card">
                                <div class="card-content">
                                    <div class="card-body">
                                        <div class="media d-flex">
                                            <div class="align-self-center">
                                                <img src="<?php echo base_url('assets/images/dash-icon/man.png') ?>"
                                                    alt="">
                                            </div>
                                            <div class="media-body text-right">
                                                <h3><?= $toplamkullanici ?? '0' ?></h3>
                                                <span>Toplam Üye</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <?php if (1 == 2) { ?>
                        <div class="col-md-4 col-xl-3">
                            <div class="card bg-c-blue order-card">
                                <div class="card-block">
                                    <h5 class="m-b-20">Toplam Kategori</h5>
                                    <h6>
                                        <strong><?= $toplamkategori ?></strong><small style="font-size: 12px;"> adet
                                            kategori</small>
                                    </h6>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 col-xl-3">
                            <div class="card bg-c-green order-card">
                                <div class="card-block">
                                    <h5 class="m-b-20">Toplam Ürün</h5>
                                    <h6>
                                        <strong><?= $toplamurun ?></strong><small style="font-size: 12px;"> adet
                                            ürün</small>
                                    </h6>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 col-xl-3">
                            <div class="card bg-c-yellow order-card">
                                <div class="card-block">
                                    <h5 class="m-b-20">Toplam İlan</h5>
                                    <h6>
                                        <strong><?= $toplamilan ?></strong><small style="font-size: 12px;"> adet
                                            ilan</small>
                                    </h6>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 col-xl-3">
                            <div class="card bg-c-pink order-card">
                                <div class="card-block">
                                    <h5 class="m-b-20">Toplam Üye</h5>
                                    <h6>
                                        <strong><?= $toplamkullanici ?></strong><small style="font-size: 12px;">
                                            adet üye</small>
                                    </h6>
                                </div>
                            </div>
                        </div>
                        <?php } ?>
                    </div>
                    <?php if (1 == 2) { ?>
                    <div class="row" style="margin-top:8px">
                        <div class="col-md-4">
                            <div class="card">
                                <div class="card-header dash dash">
                                    <div class="card-title dash">
                                        <span>Bu hafta kazanç</span>
                                    </div>
                                </div>
                                <div class="card-body">
                                    <nav class="navbar navbar-light">
                                        <div class="menu-icon">
                                            <img src="<?php echo base_url('assets/images/dash-icon/money.png') ?>"
                                                alt="">
                                            <strong><?= $buhaftaurunpara ?? 0 ?>₺</strong>
                                            <p>Ürün Satışı</p>
                                        </div>
                                    </nav>
                                    <nav class="navbar navbar-light">
                                        <div class="menu-icon">
                                            <img src="<?php echo base_url('assets/images/dash-icon/money.png') ?>"
                                                alt="">
                                            <strong><?= $buhaftailanpara ?? 0 ?>₺</strong>
                                            <p>İlan Satışı</p>
                                        </div>
                                    </nav>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div class="card">
                                <div class="card-header dash">
                                    <div class="card-title dash">
                                        <span>Bu ay kazanç</span>
                                    </div>
                                </div>
                                <div class="card-body">
                                    <nav class="navbar navbar-light">
                                        <div class="menu-icon">
                                            <img src="<?php echo base_url('assets/images/dash-icon/money.png') ?>"
                                                alt="">
                                            <strong><?= $buayurunpara ?? 0 ?>₺</strong>
                                            <p>Ürün Satışı</p>
                                        </div>
                                    </nav>

                                    <nav class="navbar navbar-light">
                                        <div class="menu-icon">
                                            <img src="<?php echo base_url('assets/images/dash-icon/money.png') ?>"
                                                alt="">
                                            <strong><?= $buayilanpara ?? 0 ?>₺</strong>
                                            <p>İlan Satışı</p>
                                        </div>
                                    </nav>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div class="card">
                                <div class="card-header dash">
                                    <div class="card-title dash">
                                        <span>Tüm kazançlar</span>
                                    </div>
                                </div>
                                <div class="card-body">
                                    <nav class="navbar navbar-light">
                                        <div class="menu-icon">
                                            <img src="<?php echo base_url('assets/images/dash-icon/money.png') ?>"
                                                alt="">
                                            <strong><?= $toplamurunpara ?? 0 ?>₺</strong>
                                            <p>Ürün Satışı</p>
                                        </div>
                                    </nav>

                                    <nav class="navbar navbar-light">
                                        <div class="menu-icon">
                                            <img src="<?php echo base_url('assets/images/dash-icon/money.png') ?>"
                                                alt="">
                                            <strong><?= $toplamilanpara ?? 0 ?>₺</strong>
                                            <p>İlan Satışı</p>
                                        </div>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php } ?>
                </div>
            </div>
        </div>
         -->
    </div>
    <div class="row row-sm">
        <div class="col-12">
            <?php

            if (!isset($_SESSION["sistembildira"])) {
                $_SESSION["sistembildira"] = "0";
            }

            $this->db->select('COUNT(talep_id) as toplam');
            $this->db->where("talep_durum='0'");
            $aylik_siparis_adet = $this->db->get('talep')->result();
            $data = [];
            foreach ($aylik_siparis_adet as $row) {
                $data[] += $row->toplam;
            }
            if ($data[0] != "0") {
                echo '<div class="alert alert-info">' . $data[0] . ' adet talep yanıtlanmayı bekliyor.</div>';
            }

            if ($data[0] != $_SESSION["sistembildira"]) {
                if ($data[0] > $_SESSION["sistembildira"]) {
                    echo '  

                <audio autoplay="autoplay">
                <source src="https://soundbible.com/grab.php?id=2155&type=mp3" type="audio/mpeg" />
                Tarayıcınız audio etiketini desteklemiyor.
                </audio>';
                }
                $_SESSION["sistembildira"] = $data[0];
            }
            ?>
        </div>
    </div><!-- row -->
    <div class="card p-3">
        <div class="table-wrapper">
            <table id="datatable1" class="table display responsive nowrap">
                <thead>
                    <tr>
                        <th class="text-center">DESTEK NO</th>
                        <th class="text-center">DESTEK BAŞLIK</th>
                        <th class="text-center">DESTEK ZAMAN</th>
                        <th class="text-center">DESTEK DURUM</th>
                        <th class="text-center">DESTEK İŞLEM</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($destekler) { ?>
                    <?php foreach ($destekler as $key) { ?>
                    <tr>
                        <td class="text-center">#<?= $key->talep_no ?></td>
                        <td class="text-center"><?= $key->talep ?></td>
                        <td class="text-center"><?= date('d.m.Y H:s', strtotime($key->talep_zaman)) ?></td>
                        <td class="text-center">
                            <?php if ($key->talep_durum == 0) { ?>
                            <span class="badge badge-warning badge-pill">Cevap Bekliyor..</span>
                            <?php } elseif ($key->talep_durum == 1) { ?>
                            <span class="badge badge-success badge-pill">Cevaplandı</span>
                            <?php } elseif ($key->talep_durum == 2) { ?>
                            <span class="badge badge-secondary badge-pill">Kapatıldı</span>
                            <?php } ?>
                        </td>
                        <td class="text-center">
                            <a href="<?php echo base_url(admin_url() . "destek-detay/$key->talep_no"); ?>"
                                class="btn btn-warning btn-with-icon">
                                <div class="ht-40">
                                    <span class="icon fas fa-eye wd-40"><i class="fa fa-send"></i></span>
                                    <span class="pd-x-15">Detay</span>
                                </div>
                            </a>
                            <a href="javascript:void(0)"
                                data-url="<?= base_url(admin_url() . "talep-sil/$key->talep_no") ?>"
                                class="btn btn-danger btn-with-icon remove-btn">
                                <div class="ht-40">
                                    <span class="icon far fa-trash-alt wd-40"><i class="fa fa-send"></i></span>
                                    <span class="pd-x-15">Sil</span>
                                </div>
                            </a>
                        </td>
                    </tr>
                    <?php } ?>
                    <?php } ?>
                </tbody>
            </table>
        </div><!-- table-wrapper -->
    </div>
</div>