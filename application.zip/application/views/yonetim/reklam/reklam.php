<div class="br-pageheader">
  <nav class="breadcrumb pd-0 mg-0 tx-12">
    <a class="breadcrumb-item" href="<?=base_url(admin_url())?>">Kontrol Paneli</a>
    <span class="breadcrumb-item active">Reklam</span>
  </nav>
</div><!-- br-pageheader -->
<div class="br-pagetitle">
  <i class="far fa-images fa-4x"></i>
  <div>
    <h4>Reklam</h4>
  </div>
</div><!-- d-flex -->

<div class="br-pagebody">
  <div class="br-section-wrapper">
    <div class="table-wrapper">
      <table id="datatable1" class="table display responsive nowrap">
        <thead>
          <tr>
            <th class="wd-15p text-center">#</th>
            <th class="wd-15p text-center">Reklam</th>
            <th class="wd-15p text-center">Reklam SIRA</th>
            <th class="wd-10p text-center">Reklam İŞLEM</th>
          </tr>
        </thead>
        <tbody>
          <?php // $slider = slider(); ?>
          <?php if ($slider) { ?>
            <?php $i=0; foreach ($slider as $key) { $i++; ?>
              <tr>
                <td class="text-center"><?=$i?></td>
                <td class="text-center"><img height="60px" width="auto" src="<?=base_url($key->image)?>"></td>
                <td class="text-center"><?=$key->order_no?></td>
                <td class="text-center">
                  <a href="<?php echo base_url(admin_url()."reklam-duzenle/$key->id"); ?>" class="btn btn-warning btn-with-icon">
                    <div class="ht-40">
                      <span class="icon fas fa-edit wd-40"><i class="fa fa-send"></i></span>
                      <span class="pd-x-15">Düzenle</span>
                    </div>
                  </a>
                  <a href="javascript:void(0)" data-url="<?=base_url(admin_url()."reklamsil/$key->id")?>" class="btn btn-danger btn-with-icon remove-btn">
                    <div class="ht-40">
                      <span class="icon far fa-trash-alt wd-40"><i class="fa fa-send"></i></span>
                      <span class="pd-x-15">Sil</span>
                    </div>
                  </a>
                </td>
              </tr>
            <?php } ?>
          <?php } ?>
        </tbody>
      </table>
    </div><!-- table-wrapper -->
  </div><!-- br-section-wrapper -->
</div><!-- br-pagebody -->