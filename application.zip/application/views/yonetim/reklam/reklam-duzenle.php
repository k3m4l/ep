<div class="br-pageheader">
	<nav class="breadcrumb pd-0 mg-0 tx-12">
		<a class="breadcrumb-item" href="<?= base_url(admin_url()) ?>">Kontrol Paneli</a>
		<span class="breadcrumb-item active">Reklam Güncelle</span>
	</nav>
</div><!-- br-pageheader -->
<div class="br-pagetitle">
	<i class="far fa-file-alt fa-4x"></i>
	<div>
		<h4>Reklam Güncelle</h4>
		<p class="mg-b-0">Oluşturduğunuz reklamları güncelleyebilirsiniz.</p>
	</div>
</div><!-- d-flex -->

<div class="br-pagebody">
	<div class="br-section-wrapper">
		<form action="<?= base_url(admin_url() . "reklamguncelle/$where->id"); ?>" method="post" enctype="multipart/form-data">
			<div class="form-layout form-layout-1">
				<div class="row mg-b-25">
                    <div class="col-md-10">
                        <div class="form-group">
                            <div action="<?php echo base_url('image/Add_images/add_image'); ?>" class="dropzone dropzone-area" id="dpz-single-files">
                                <div class="dz-message">
                                    <span class="m-dropzone__msg-desc">
                                        Bir Adet Reklam Resim Yükleyiniz.
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="mt-2 mr-1 text-center">
                            <span>Yüklü Resim</span>
                            <img src="<?php echo !empty($where->image) ? base_url($where->image) : '' ; ?>" alt="Holi" class=" w-100 rounded img-fluid float-left mr-2 mb-1" width="400" height="300" data-action="zoom">
                        </div>
                    </div>

                    <div class="col-md-10">
                        <div class="form-group">
                            <div action="<?php echo base_url('image/Add_images/add_image_two'); ?>" class="dropzone dropzone-area" id="dpz-single-files">
                                <div class="dz-message">
                                    <span class="m-dropzone__msg-desc">
                                        Bir Adet Reklam 2. Resim Yükleyiniz.
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="mt-2 mr-1 text-center">
                            <span>Yüklü Resim</span>
                            <img src="<?php echo !empty($where->image_two) ? base_url($where->image_two) : '' ; ?>" alt="Holi" class=" w-100 rounded img-fluid float-left mr-2 mb-1" width="400" height="300" data-action="zoom">
                        </div>
                    </div>

                    <div class="col-md-10">
                        <div class="form-group">
                            <div action="<?php echo base_url('image/Add_images/add_image_three'); ?>" class="dropzone dropzone-area" id="dpz-single-files">
                                <div class="dz-message">
                                    <span class="m-dropzone__msg-desc">
                                        Bir Adet Reklam Logo Resim Yükleyiniz.
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="mt-2 mr-1 text-center">
                            <span>Yüklü Resim</span>
                            <img src="<?php echo !empty($where->image_three) ? base_url($where->image_three) : '' ; ?>" alt="Holi" class=" w-100 rounded img-fluid float-left mr-2 mb-1" width="400" height="300" data-action="zoom">
                        </div>
                    </div>

					<div class="col-lg-4">
						<div class="form-group">
							<label class="form-control-label">Reklam Sırası</label>
							<input class="form-control" type="number" name="sira" placeholder="Reklam Sırası" value="<?= $where->order_no ?>">
						</div>
					</div><!-- col-8 -->

					<div class="col-lg-4">
						<div class="form-group">
							<label class="form-control-label">Reklam Url <span class="tx-danger">*</span></label>
							<input class="form-control" type="text" name="url" placeholder="Reklam Url" value="<?= $where->link ?>">
						</div>
					</div>
					<div class="col-lg-4">
						<div class="form-group">
							<label class="form-control-label">Tür <span class="tx-danger">*</span></label>
							<select class="form-control" type="text" name="tur" required="">
								<option value="1" <?php if ($where->type == "1") {
														echo 'selected';
													} ?>>Üst Slider</option>
								<option value="2" <?php if ($where->type == "2") {
														echo 'selected';
													} ?>>Alt Slider</option>
							</select>
						</div>
					</div><!-- col-4 -->
				</div>

				<div class="form-layout-footer">
					<button type="submit" class="btn btn-info">Reklam Güncelle</button>
				</div><!-- form-layout-footer -->
			</div>
		</form><!-- form-layout -->
	</div>
</div>
<script>
	$(document).ready(function() {
		CKEDITOR.replace('detay');
	});
</script>