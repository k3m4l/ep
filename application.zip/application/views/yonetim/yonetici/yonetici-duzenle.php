<div class="br-pageheader">
    <nav class="breadcrumb pd-0 mg-0 tx-12">
        <a class="breadcrumb-item" href="<?= base_url(admin_url()) ?>">Kontrol Paneli</a>
        <span class="breadcrumb-item active">Kullanıcı Güncelle</span>
    </nav>
</div><!-- br-pageheader -->
<div class="br-pagetitle">
    <i class="fas fa-users fa-4x"></i>
    <div>
        <h4>Kullanıcı Güncelle</h4>
        <p class="mg-b-0">Kullanıcıları güncelleyebilirsiniz.</p>
    </div>
</div><!-- d-flex -->

<div class="br-pagebody">
    <div class="br-section-wrapper">
        <?php if (admin_magaza_check($where->kullanici_id)) { ?>
            <div class="row">
                <div class="col-md-6">
                    <a href="<?= base_url(admin_url() . 'magaza-duzenle/' . $magaza->magaza_id) ?>"
                       class="btn btn-success btn-block mb-4">Mağazaya Git</a>
                </div>
                <div class="col-md-6">
                    <button class="btn btn-primary btn-block mb-4">Mağaza Adı : <?= $magaza->magaza_ad ?></button>
                </div>
            </div>
            <div class="card mb-4">
                <div class="card-body">
                    <h3 class="mb-0">Kazançları</h3>
                    <p class="mb-0">
                        Kesinleşmiş kazançlarını görebilirsiniz
                    </p>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-4 col-md-6 col-12">
                    
                    <div class="card mb-4">
                        
                        <div class="p-4">
                            <h2 class="h1 font-weight-bold mb-0 mt-4 lh-1">
                                <?= $odenen_kazanclar ?>₺
                            </h2>
                            <p>Toplam Ödenen Kazanç</p>
                            <div class="progress bg-light-primary" style="height: 2px">
                                <div class="progress-bar" role="progressbar" style="width: 100%" aria-valuenow="100"
                                     aria-valuemin="0"
                                     aria-valuemax="100"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-12">
                    
                    <div class="card mb-4">
                        
                        <div class="p-4">
                            <h2 class="h1 font-weight-bold mb-0 mt-4 lh-1">
                                <?= $odenebilir_kazanclar ?>₺
                            </h2>
                            <p>Ödenebilir Kazanç</p>
                            <div class="progress bg-light-danger" style="height: 2px">
                                <div class="progress-bar bg-danger" role="progressbar" style="width: 100%"
                                     aria-valuenow="100"
                                     aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-12">
                    
                    <div class="card mb-4">
                        
                        <div class="p-4">
                            <h2 class="h1 font-weight-bold mb-0 mt-4 lh-1">
                                <?= $toplam_kazanclar ?>₺
                            </h2>
                            <p>Şimdiye Kadarki Kazanç</p>
                            <div class="progress bg-light-warning" style="height: 2px">
                                <div class="progress-bar bg-warning" role="progressbar" style="width: 100%"
                                     aria-valuenow="100"
                                     aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-12">
                    
                    <div class="card mb-4">
                        
                        <div class="p-4">
                            <h2 class="h1 font-weight-bold mb-0 mt-4 lh-1">
                                <?= $aylik_kazanc ?>₺
                            </h2>
                            <p>Bu Ay Toplam Kazanç</p>
                            <div class="progress bg-light-warning" style="height: 2px">
                                <div class="progress-bar bg-warning" role="progressbar" style="width: 100%"
                                     aria-valuenow="100"
                                     aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-12">
                    <div class="card mb-4">
                        
                        <div class="p-4">
                            <h2 class="h1 font-weight-bold mb-0 mt-4 lh-1">
                                <?= $gunluk_kazanc ?>₺
                            </h2>
                            <p>Bugün Toplam Kazanç</p>
                            <div class="progress bg-light-primary" style="height: 2px">
                                <div class="progress-bar" role="progressbar" style="width: 100%" aria-valuenow="100"
                                     aria-valuemin="0"
                                     aria-valuemax="100"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php } ?>
        <form action="<?= base_url(admin_url() . "kullaniciduzenle/$where->kullanici_id"); ?>" method="post"
              enctype="multipart/form-data">
            <div class="form-layout form-layout-1">
                <div class="row mg-b-25">
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label class="form-control-label">Kullanıcı Adı <span class="tx-danger">*</span></label>
                            <input class="form-control" type="text" name="ad" placeholder="Kullanıcı Adı"
                                   value="<?= $where->kullanici_ad ?>" required="" disabled>
                        </div>
                    </div><!-- col-4 -->
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label class="form-control-label">Kullanıcı Şifre</label>
                            <input class="form-control" type="password" name="sifre" placeholder="Kullanıcı Şifre"
                                   value="<?= $where->kullanici_sifre ?>">
                        </div>
                    </div><!-- col-8 -->

                    <div class="col-lg-6">
                        <div class="form-group">
                            <label class="form-control-label">Kullanıcı İsim</label>
                            <input class="form-control" type="text" name="isim" placeholder="Kullanıcı İsim"
                                   value="<?= $where->kullanici_isim ?>">
                        </div>
                    </div><!-- col-8 -->

                    <div class="col-lg-6">
                        <div class="form-group">
                            <label class="form-control-label">Kullanıcı Soyisim</label>
                            <input class="form-control" type="text" name="soyisim" placeholder="Kullanıcı Soyisim"
                                   value="<?= $where->kullanici_soyisim ?>">
                        </div>
                    </div><!-- col-8 -->

                    <div class="col-lg-6">
                        <div class="form-group">
                            <label class="form-control-label">Kullanıcı Bakiye</label>
                            <input class="form-control" type="text" name="bakiye" placeholder="Kullanıcı Bakiye"
                                   value="<?= $where->bakiye ?>">
                        </div>
                    </div><!-- col-8 -->

                    <div class="col-lg-6">
                        <div class="form-group">
                            <label class="form-control-label">Kullanıcı Telefon</label>
                            <input class="form-control" type="text" name="kullanici_tel" placeholder="Kullanıcı Telefon"
                                   value="<?= $where->kullanici_tel ?>">
                        </div>
                    </div><!-- col-8 -->

                    <div class="col-lg-6">
                        <div class="form-group">
                            <label class="form-control-label">Kullanıcı E-Posta</label>
                            <input class="form-control" type="mail" name="mail" placeholder="Kullanıcı E-Posta"
                                   value="<?= $where->kullanici_mail ?>">
                        </div>
                    </div><!-- col-8 -->

                    <div class="col-lg-6">
                        <label class="form-control-label">Kullanıcı Durum <span class="tx-danger">*</span></label>
                        <select class="form-control select2-show-search" data-placeholder="Lütfen Konum Seçin"
                                name="durum" required="">
                            <option <?php if ($where->kullanici_durum == 1) {
                                echo "selected";
                            } ?> value="1">Aktif
                            </option>
                            <option <?php if ($where->kullanici_durum == 0) {
                                echo "selected";
                            } ?> value="0">Pasif
                            </option>
                        </select>
                    </div>

                    <div class="col-lg-6">
                        <label class="form-control-label">Kullanıcı Yetki <span class="tx-danger">*</span></label>
                        <select class="form-control select2-show-search" data-placeholder="Lütfen Konum Seçin"
                                name="yetki" required="">
                            <option <?php if ($where->kullanici_yetki == 9) {
                                echo "selected";
                            } ?> value="9">Yönetici
                            </option>
                            <option <?php if ($where->kullanici_yetki == 1) {
                                echo "selected";
                            } ?> value="1">Normal Üye
                            </option>
                        </select>
                    </div>
                    <div class="col-lg-6">
                        <label class="form-control-label">Bayi mi ? <span class="tx-danger">*</span></label>
                        <select class="form-control select2-show-search" data-placeholder="Lütfen Konum Seçin"
                                name="kullanici_bayi" required="">
                            <option <?php if ($where->kullanici_bayi == 0) {
                                echo "selected";
                            } ?> value="0">Hayır
                            </option>
                            <option <?php if ($where->kullanici_bayi == 1) {
                                echo "selected";
                            } ?> value="1">Evet
                            </option>
                        </select>
                    </div>
                    <div class="col-lg-6 mt-4">
                        <label class="form-control-label">Bayi komisyon <span class="tx-danger">*</span></label>
						<input type="number" class="form-control" name="kullanici_bayi_komisyon" value="<?= $where->kullanici_bayi_komisyon ?>">
                    </div>
                    <div class="col-lg-6 mt-4">
                        <label class="form-control-label">Bayi Bakiye <span class="tx-danger">*</span></label>
						<input type="text" class="form-control" name="kullanici_bayi_bakiye" value="<?= $where->kullanici_bayi_bakiye ?>">
                    </div>
                    <div class="col-lg-12 mt-4">
                        <label class="form-control-label">Bayi Api Key <span class="tx-danger">*</span></label>
                        <input type="text" class="form-control" name="apiKey" value="<?= !empty($where->apiKey) ? $where->apiKey:generate_string(36); ?>">
                    </div>
                </div>

                <div class="form-layout-footer">
                    <button type="submit" class="btn btn-info">Kullanıcı Güncelle</button>
                </div><!-- form-layout-footer -->
            </div>
        </form><!-- form-layout -->
    </div>
</div>
<?php

function generate_string($strength = 36)
{
	$permitted_chars = '0123456789abcdefghijklmnopqrstuvwxyzAB23456789CDEFGHIJKLMNOPQRSTUVWXYZ';
	$input_length = strlen($permitted_chars);
	$random_string = '';
	for ($i = 0; $i < $strength; $i++) {
		$random_character = $permitted_chars[mt_rand(0, $input_length - 1)];
		$random_string .= $random_character;
	}

	return str_shuffle($random_string);
}
?>