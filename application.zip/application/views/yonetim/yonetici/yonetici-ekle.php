<div class="br-pageheader">
	<nav class="breadcrumb pd-0 mg-0 tx-12">
		<a class="breadcrumb-item" href="<?=base_url(admin_url())?>">Kontrol Paneli</a>
		<span class="breadcrumb-item active">Yeni Kullanıcı Oluştur</span>
	</nav>
</div><!-- br-pageheader -->
<div class="br-pagetitle">
	<i class="fas fa-users fa-4x"></i>
	<div>
		<h4>Yeni Kullanıcı Oluştur</h4>
		<p class="mg-b-0">Kullanıcı Hesapları Ekleyebilirsiniz.</p>
	</div>
</div><!-- d-flex -->

<div class="br-pagebody">
	<div class="br-section-wrapper">
		<form action="<?=base_url(admin_url()."kullaniciekle"); ?>" method="post" enctype="multipart/form-data">
			<div class="form-layout form-layout-1">
				<div class="row mg-b-25">
					<div class="col-lg-6">
						<div class="form-group">
							<label class="form-control-label">Kullanıcı Adı <span class="tx-danger">*</span></label>
							<input class="form-control" type="text" name="ad" placeholder="Kullanıcı Adı" required="">
						</div>
					</div><!-- col-4 -->
					<div class="col-lg-6">
						<div class="form-group">
							<label class="form-control-label">Kullanıcı Şifre</label>
							<input class="form-control" type="password" name="sifre" placeholder="Kullanıcı Şifre">
						</div>
					</div><!-- col-8 -->

					<div class="col-lg-6">
						<div class="form-group">
							<label class="form-control-label">Kullanıcı İsim</label>
							<input class="form-control" type="text" name="isim" placeholder="Kullanıcı İsim">
						</div>
					</div><!-- col-8 -->

					<div class="col-lg-6">
						<div class="form-group">
							<label class="form-control-label">Kullanıcı Soyisim</label>
							<input class="form-control" type="text" name="soyisim" placeholder="Kullanıcı Soyisim">
						</div>
					</div><!-- col-8 -->

					<div class="col-lg-6">
						<div class="form-group">
							<label class="form-control-label">Kullanıcı E-Posta</label>
							<input class="form-control" type="mail" name="mail" placeholder="Kullanıcı E-Posta">
						</div>
					</div><!-- col-8 -->

					<div class="col-lg-6">
						<label class="form-control-label">Kullanıcı Durum <span class="tx-danger">*</span></label>
						<select class="form-control select2-show-search" data-placeholder="Lütfen Konum Seçin" name="durum" required="">
							<option value="9">Aktif</option>
							<option value="0">Pasif</option>
						</select>
					</div>

					<div class="col-lg-12">
						<label class="form-control-label">Kullanıcı Yetki <span class="tx-danger">*</span></label>
						<select class="form-control select2-show-search" data-placeholder="Lütfen Konum Seçin" name="yetki" required="">
							<option value="9">Yönetici</option>
							<option selected="" value="1">Normal Üye</option>
						</select>
					</div>
                    <div class="col-lg-6">
                        <label class="form-control-label">Bayi mi ? <span class="tx-danger">*</span></label>
                        <select class="form-control select2-show-search" data-placeholder="Lütfen Konum Seçin"
                                name="kullanici_bayi" required="">
                            <option value="0" selected>Hayır</option>
                            <option value="1">Evet</option>
                        </select>
                    </div>
                    <div class="col-lg-6">
                        <label class="form-control-label">Bayi komisyon <span class="tx-danger">*</span></label>
						<input type="number" class="form-control" name="kullanici_bayi_komisyon" value="0">
                    </div>
					<input type="hidden" name="apiKey" value="<?= generate_string(36); ?>">

				</div>

				<div class="form-layout-footer">
					<button type="submit" class="btn btn-info">Kullanıcı Ekle</button>
				</div><!-- form-layout-footer -->
			</div>
		</form><!-- form-layout -->
	</div>
</div>
<?php

function generate_string($strength = 36)
{
	$permitted_chars = '0123456789abcdefghijklmnopqrstuvwxyzAB23456789CDEFGHIJKLMNOPQRSTUVWXYZ';
	$input_length = strlen($permitted_chars);
	$random_string = '';
	for ($i = 0; $i < $strength; $i++) {
		$random_character = $permitted_chars[mt_rand(0, $input_length - 1)];
		$random_string .= $random_character;
	}

	return str_shuffle($random_string);
}
?>