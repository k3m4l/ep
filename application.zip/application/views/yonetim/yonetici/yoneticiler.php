<div class="br-pageheader">
    <nav class="breadcrumb pd-0 mg-0 tx-12">
        <a class="breadcrumb-item" href="<?= base_url(admin_url()) ?>">Kontrol Paneli</a>
        <span class="breadcrumb-item active">Kullanıcılar</span>
    </nav>
</div><!-- br-pageheader -->
<div class="br-pagetitle">
    <i class="fas fa-users fa-4x"></i>
    <div>
        <h4>Kullanıcılar</h4>
    </div>
</div><!-- d-flex -->

<div class="br-pagebody">
    <div class="br-section-wrapper">
        <div class="row justify-content-end mb-3">
            <a href="<?= base_url(admin_url()."kullanicilar") ?>" class="btn btn-warning btn-sm">Tüm Kullanıcılar</a>
            <a href="<?= base_url(admin_url()."kullanicilar?type=1") ?>" class="btn btn-success btn-sm ml-2">Mağazalar</a>
            <a href="<?= base_url(admin_url()."kullanicilar?type=2") ?>" class="btn btn-primary btn-sm ml-2">Bayiler</a>
        </div>
        <div class="table-wrapper">
            <table id="datatable1" class="table display responsive nowrap">
                <thead>
                <tr>
                    <th class="wd-15p text-center">#</th>
                    <th class="wd-15p text-center">MAĞAZA</th>
                    <th class="wd-15p text-center">BAYİ</th>
                    <th class="wd-15p text-center">KULLANICI YETKİ</th>
                    <th class="wd-15p text-center">KULLANICI ADI</th>
                    <th class="wd-15p text-center">E-POSTA</th>
                    <th class="wd-15p text-center">KULLANICI İSİM</th>
                    <th class="wd-15p text-center">KULLANICI SOYİSİM</th>
                    <th class="wd-10p text-center">KULLANICI İŞLEM</th>
                </tr>
                </thead>
                <tbody>
                <?php $kullanicilar = kullanicilar(isset($_GET['type']) ? $_GET['type']:0); ?>
                <?php if ($kullanicilar) { ?>
                    <?php $i = 0;
                    foreach ($kullanicilar as $key) {
                        $i++; ?>
                        <tr>
                            <td class="text-center"><?= $i ?></td>
                            <td class="text-center">
                                <?php if (admin_magaza_check($key->kullanici_id)) {
                                    echo "<span class='badge badge-primary'>Mağaza Var</span>";
                                } else {
                                    echo "<span class='badge badge-danger'>Mağaza Yok</span>";
                                } ?>
                            </td>
                            <td class="text-center">
                                <?php if ($key->kullanici_bayi) {
                                    echo "<span class='badge badge-primary'>Bayi Var</span>";
                                } else {
                                    echo "<span class='badge badge-danger'>Bayi Yok</span>";
                                } ?>
                            </td>
                            <td class="text-center"><?php if ($key->kullanici_yetki == 9) {
                                    echo "Yönetici";
                                } else {
                                    echo "Normal";
                                } ?></td>
                            <td class="text-center"><?= $key->kullanici_ad ?></td>
                            <td class="text-center"><?= $key->kullanici_mail ?></td>
                            <td class="text-center"><?= $key->kullanici_isim ?></td>
                            <td class="text-center"><?= $key->kullanici_soyisim ?></td>
                            <td class="text-center">
                                <a href="<?php echo base_url(admin_url() . "kullanici-duzenle/$key->kullanici_id"); ?>"
                                   class="btn btn-warning btn-with-icon">
                                    <div class="ht-40">
                                        <span class="icon fas fa-edit wd-40"><i class="fa fa-send"></i></span>
                                        <span class="pd-x-15">Düzenle</span>
                                    </div>
                                </a>
                                <a href="javascript:void(0)"
                                   data-url="<?= base_url(admin_url() . "kullanicisil/$key->kullanici_id") ?>"
                                   class="btn btn-danger btn-with-icon remove-btn">
                                    <div class="ht-40">
                                        <span class="icon far fa-trash-alt wd-40"><i class="fa fa-send"></i></span>
                                        <span class="pd-x-15">Sil</span>
                                    </div>
                                </a>
                            </td>
                        </tr>
                    <?php } ?>
                <?php } ?>
                </tbody>
            </table>
        </div><!-- table-wrapper -->
    </div><!-- br-section-wrapper -->
</div><!-- br-pagebody -->