<div class="br-pageheader">
    <nav class="breadcrumb pd-0 mg-0 tx-12">
        <a class="breadcrumb-item" href="<?= base_url(admin_url()) ?>">Kontrol Paneli</a>
        <a class="breadcrumb-item" href="<?= base_url(admin_url() . 'ilanlar') ?>">İlanlar</a>
        <span class="breadcrumb-item active">İlan Düzenle</span>
    </nav>
</div><!-- br-pageheader -->
<div class="br-pagetitle">
    <i class="fas fa-store fa-4x"></i>
    <div>
        <h4><?= $urun->urun_ad ?> - İlan Düzenle</h4>
    </div>
</div><!-- d-flex -->

<div class="br-pagebody">
    <div class="br-section-wrapper">
        <form action="<?= base_url('yonetim_magaza_controller/ilan_duzenle/' . $urun->urun_id) ?>" method="post"
              enctype="multipart/form-data">
            <!-- Form -->
            <div class="row">
                <div class="form-group col-md-12">
                    <!-- Title -->
                    <label for="postTitle" class="form-label">İlan Adı</label>
                    <input type="text" name="urun_ad" class="form-control text-dark"
                           placeholder="İlan Adı" value="<?= $urun->urun_ad ?>" required/>
                    <small>Lütfen özel karakter kullanmamaya çalışın ve yazım kurallarına göre
                        başlık yazın.</small>
                </div>
                <?php if (1 == 2) { ?>
                    <div class="form-group col-md-12">
                        <!-- Title -->
                        <label for="postTitle" class="form-label">Kenar Rengi</label>
                        <input type="text" name="kenar" class="form-control text-dark"
                               placeholder="Kenar Rengi" value="<?= $urun->kenar ?>"/>
                    </div>
                <?php } ?>

                <div class="form-group col-md-6">
                    <!-- Title -->
                    <label for="postTitle" class="form-label">İlan Sıra</label>
                    <input type="text" name="urun_sira" class="form-control text-dark"
                           placeholder="İlan Sıra" value="<?= $urun->urun_sira ?>"/>

                </div>
                <div class="form-group col-md-6">
                    <!-- Title -->
                    <label for="postTitle" class="form-label">İlan Vitrin Sıra</label>
                    <input type="text" name="urun_vitrin_sira" class="form-control text-dark"
                           placeholder="İlan Vitrin Sıra" value="<?= $urun->urun_vitrin_sira ?>"/>

                </div>

                <div class="form-group col-md-12">
                    <label class="form-label">İlan Kategorisi</label>
                    <select class="form-control kategori" id="kategori" data-width="100%"
                            name="kategori[]"
                            multiple="multiple" required>
                        <?php foreach (fetchCategoryTree() as $cl) { ?>
                            <option value="<?php echo $cl["id"] ?>" <?php echo in_array($cl['id'], json_decode($urun->kategori_json, true)) ? 'selected' : ''; ?>><?php echo $cl["name"]; ?></option>
                        <?php } ?>
                    </select>
                </div>

                <div class="form-group col-md-6">
                    <label class="form-label">İlan Türü</label>
                    <select class="form-control" id="urun_turu" data-width="100%" name="urun_turu"
                            required>
                        <option hidden="">İlan Türü Seçin..</option>
                        <option <?php if ($urun->urun_turu == 1) {
                            echo 'selected';
                        } ?> value="1">Fiziksel Ürün
                        </option>
                        <option <?php if ($urun->urun_turu == 2) {
                            echo 'selected';
                        } ?> value="2">Sanal Ürün
                        </option>
                        <option <?php if ($urun->urun_turu == 3) {
                            echo 'selected';
                        } ?> value="3">İndirilebilir Ürün
                        </option>
                    </select>
                </div>

                <div class="form-group col-md-6">
                    <label class="form-label">İlan Durumu</label>
                    <select class="form-control durum" data-width="100%" name="urun_durum"
                            required>
                        <option <?php if ($urun->urun_durum == 0) {
                            echo 'selected';
                        } ?> value="0">Onay Bekliyor..
                        </option>
                        <option <?php if ($urun->urun_durum == 1) {
                            echo 'selected';
                        } ?> value="1">Onaylandı
                        </option>
                        <option <?php if ($urun->urun_durum == 2) {
                            echo 'selected';
                        } ?> value="2">Onaylanmadı
                        </option>
                    </select>
                </div>

                <div class="form-group col-md-6">
                    <label class="form-label">Anasayfa Vitrin</label>
                    <select class="form-control" id="urun_populer" data-width="100%" name="urun_populer"
                            required>
                        <option <?php if ($urun->urun_populer == 0) {
                            echo 'selected';
                        } ?> value="0">Pasif
                        </option>
                        <option <?php if ($urun->urun_populer == 1) {
                            echo 'selected';
                        } ?> value="1">Aktif
                        </option>
                    </select>
                </div>

                <div class="form-group col-md-6">
                    <label class="form-label">Kategori Vitrin</label>
                    <select class="form-control" id="urun_populer_kat" data-width="100%" name="urun_populer_kat"
                            required>
                        <option <?php if ($urun->urun_populer_kat == 0) {
                            echo 'selected';
                        } ?> value="0">Pasif
                        </option>
                        <option <?php if ($urun->urun_populer_kat == 1) {
                            echo 'selected';
                        } ?> value="1">Aktif
                        </option>
                    </select>
                </div>

                <div class="form-group col-md-12 urun_iptal"
                     style="<?php if ($urun->urun_durum != 2) {
                         echo 'display: none;';
                     } ?>">
                    <!-- Title -->
                    <label class="form-label">İlan İptal Açıklaması</label>
                    <textarea type="text" name="urun_iptal" class="form-control text-dark iptal"
                              placeholder="İlan İptal Açıklaması"><?= $urun->urun_iptal ?></textarea>
                </div>

                <?php if ($urun->urun_indir) {
                    $dosya = explode('/', $urun->urun_indir); ?>
                    <div class="form-group col-md-12 indirilebilir"
                         style="<?php if ($urun->urun_turu != 3) {
                             echo 'display: none;';
                         } ?>">
                        <label class="input-label">Varsayılan Dosya</label>
                        <div class="card">
                            <div class="card-body d-flex justify-content-between align-items-center text-center">
                                <div class="d-flex flex-column">
                                    <span class="badge badge-secondary mb-1">Dosya Adı : <i
                                                class="fe fe-file"></i> <?= $dosya[3] ?></span>
                                    <span class="badge badge-secondary">Dosya Boyutu : <?= filesize_formatted($urun->urun_indir) ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php } ?>

                <div class="form-group col-md-12 sanal_urun_bilgileri"
                     style="<?php if ($urun->urun_turu != 2) {
                         echo 'display: none;';
                     } ?>">
                    <!-- Title -->
                    <label class="form-label">Sanal Ürün Bilgileri</label>
                    <textarea type="text" name="sanal_urun_bilgileri" class="form-control text-dark"
                              placeholder="Sanal Ürün Bilgileri"><?= $urun->urun_sanal_bilgi ?></textarea>
                    <small>Ürün bilgileri ödeme yapıldıktan sonra otomatik olarak kişiye
                        görünecektir.</small>
                </div>

                <div class="form-group col-md-12 fiziksel" style="<?php if ($urun->urun_turu != 1) {
                    echo 'display: none;';
                } ?>">
                    <!-- Title -->
                    <label for="postTitle" class="form-label">Ürün Markası <small>(İsteğe
                            Bağlı)</small></label>
                    <input type="text" name="urun_marka" class="form-control text-dark"
                           placeholder="Ürün Markası" value="<?= $urun->urun_marka ?>"/>
                </div>

                <div class="form-group col-md-12  mb-5">
                    <label class="form-label">Varsayılan İlan Vitrin Fotoğrafı</label>
                    <div>
                        <img width="250" src="<?= base_url($urun->urun_resim) ?>"
                             alt="<?= $urun->urun_ad ?>">
                    </div>
                </div>

                <div class="form-group col-md-12  mb-5">
                    <label class="form-label">İlan Vitrin Fotoğrafı</label>
                    <div class="custom-file">
                        <input type="file" class="custom-file-input" id="vitrin" name="file"
                               accept=".jpg, .jpeg, .png" onchange="getPhotoData(this);">
                        <label class="custom-file-label" for="vitrin">Ürün Vitrin
                            Fotoğrafı</label>
                        <small>Sadece <span class="badge badge-danger badge-pill badge-sm">.png/.jpg/.jpeg</span>
                            dosya türü
                            desteklenmektedir.</small>
                        <div class="card mt-2" id="resim_goster" style="display: none">
                            <div class="p-3 d-flex justify-content-between">
                                <div>
                                    <i class="fe fe-file"></i> <span class="resim_adi"></span> /
                                    <small
                                            class="resim_size"></small>
                                </div>
                                <div>
                                    <a href="javascript:void(0)" id="resim_sil"><i
                                                class="fe fe-x"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="form-group col-md-4">
                    <label for="postTitle" class="form-label">Stok *</label>
                    <input name="urun_stok" type="number" value="<?= $urun->urun_stok ?>"
                           class="form-control text-dark" placeholder="Ürün Stok" required/>
                </div>
                <div class="form-group col-md-4">
                    <label for="form-label">Eski Fiyatı</label>
                    <input class="form-control text-left" type="number" name="eski_fiyat" step="any"
                           value="<?= $urun->urun_eski_fiyat ?>" id="eski_fiyat">
                    <div class="mt-2 text-center">
                        <span class="badge badge-success d-flex">İndirim Oranı&nbsp;<div
                                    id="indirim_yuzdesi"><?= ($urun->urun_eski_fiyat > $urun->urun_fiyat) ? ((100 - ceil($urun->urun_fiyat * 100 / $urun->urun_eski_fiyat)) . '%') : 'Yok' ?></div></span>
                    </div>
                </div>
                <div class="form-group col-md-4">
                    <label class="form-label" for="currency">Ürün Fiyatı</label>
                    <input class="form-control text-left" type="number" name="fiyat" step="any"
                           value="<?= $urun->urun_fiyat ?>" placeholder="Ürün Fiyatı" id="fiyat">
                    <div class="mt-2 text-center">
                                            <span class="badge badge-success d-flex flex-column">
                                                <div class="d-flex justify-content-between align-items-center text-center">
                                                    <span class="font-size-md">Hesabınıza Geçecek Kazanç :</span>
                                                    <span class="font-size-md font-weight-bold" id="kazanc">
                                                        <?= komisyon_hesap($urun->urun_fiyat) ?> ₺
                                                    </span>
                                                </div>
                                                <div class="d-flex justify-content-between align-items-center text-center mt-1">
                                                    <span>Komisyon Oranı :</span>
                                                    <span>%<?= $ayarlar->komisyon ?></span>
                                                </div>
                                            </span>
                    </div>
                </div>

            </div>

            <?php if ($urun->urun_galeri) {
                $urun_galeri = json_decode($urun->urun_galeri); ?>
                <div class="form-group">
                    <label class="form-control-label">İlan Fotoğrafları</label><br>
                    <div class="d-flex">
                        <?php foreach ($urun_galeri as $galeri) { ?>
                            <div class="ilan-fotograflar mr-2" style="display: grid">
                                <img width="200" class="mr-2"
                                     src="<?= base_url('uploads/img/' . $galeri) ?>"
                                     alt="Galeri">
                                <button type="button" onclick="window.location.href='<?php echo base_url('yonetim_magaza_controller/resim_sil/'.$urun->urun_id.'/'.$galeri) ?>'" class="btn btn-danger badge-pill"><i class="fas fa-trash"></i>
                                </button>
                            </div>
                        <?php } ?>
                    </div>
                </div>
            <?php } ?>
            <div class="form-group">
                <label class="form-control-label">İlan Fotoğrafları</label><br>
                <input type="file" class="form-control" id="galeri-1671310458158" name="galeri[]" multiple="multiple">
            </div>
            <!-- Editor -->
            <div class="mt-2 mb-4">
                <label class="form-control-label">İlan Açıklaması</label>
                <textarea class="ckeditor" name="urun_aciklama"
                          id="urun_detay"><?= $urun->urun_aciklama ?></textarea>
            </div>

            <div class="mt-2 mb-4">
                <label class="form-control-label">İlan Kısa Açıklaması</label>
                <textarea class="ckeditor" name="urun_short_aciklama"
                          id="urun_detay"><?= $urun->urun_short_aciklama ?></textarea>
            </div>

            <!-- button -->
            <button type="submit" name="ilan_duzenle" class="btn btn-primary badge-pill"> İlan Düzenle</button>
        </form>
    </div>
</div>

<script>
    $('.durum').on('change', function () {
        if (this.value == 2) {
            $('.urun_iptal').show();
            $(".iptal").prop('required', true);
        } else {
            $('.urun_iptal').hide();
            $(".iptal").prop('required', false);
        }
    });

    /**
     * Dosya Seçme işlemleri
     */
    var es = document.getElementById('dosya');
    var vt = document.getElementById('vitrin');

    function getFileData(myFile) {
        var file = myFile.files[0];
        if (file) {
            var filename = file.name;
            $('.dosya_adi').html(filename);
            $('.dosya_size').html(bytesToSize(file.size));
            $('#dosya_goster').show();
        } else {
            $('.dosya_adi').html('');
            $('.dosya_size').html('');
            $('#dosya_goster').hide();
        }
    }

    function getPhotoData(myFile) {
        var file = myFile.files[0];
        if (file) {
            var filename = file.name;
            $('.resim_adi').html(filename);
            $('.resim_size').html(bytesToSize(file.size));
            $('#resim_goster').show();
        } else {
            $('.resim_adi').html('');
            $('.resim_size').html('');
            $('#resim_goster').hide();
        }
    }

    $(document).on('click', '#dosya_sil', function () {
        clearInputFile(es);
    });

    $(document).on('click', '#resim_sil', function () {
        clearInputPhoto(vt);
    });

    function clearInputFile(f) {
        if (f.value) {
            try {
                f.value = ''; //for IE11, latest Chrome/Firefox/Opera...
            } catch (err) {
            }
            if (f.value) { //for IE5 ~ IE10
                var form = document.createElement('form'), ref = f.nextSibling;
                form.appendChild(f);
                form.reset();
                ref.parentNode.insertBefore(f, ref);
            }
            getFileData(f);
        }
    }

    function clearInputPhoto(f) {
        if (f.value) {
            try {
                f.value = ''; //for IE11, latest Chrome/Firefox/Opera...
            } catch (err) {
            }
            if (f.value) { //for IE5 ~ IE10
                var form = document.createElement('form'), ref = f.nextSibling;
                form.appendChild(f);
                form.reset();
                ref.parentNode.insertBefore(f, ref);
            }
            getPhotoData(f);
        }
    }

    /**
     * Byte To MB Convert
     */
    function bytesToSize(bytes) {
        var sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
        if (bytes == 0) return '0 Byte';
        var i = parseInt(Math.floor(Math.log(bytes) / Math.log(1024)));
        return Math.round(bytes / Math.pow(1024, i), 2) + ' ' + sizes[i];
    }

    /**
     * Ürün Türü Select Event
     */
    $('#urun_turu').on('change', function () {
        if (this.value == 1) {
            $('.sanal_urun_bilgileri').hide();
            $('.indirilebilir').hide();
            $('.fiziksel').show();
            $("#sanal_urun_bilgileri").prop('required', false);
            $("#dosya").prop('required', false);
        } else if (this.value == 2) {
            $('.sanal_urun_bilgileri').show();
            $("#sanal_urun_bilgileri").prop('required', true);
            $("#dosya").prop('required', false);
            $('.indirilebilir').hide();
            $('.fiziksel').hide();
        } else if (this.value == 3) {
            $('.sanal_urun_bilgileri').hide();
            $('.indirilebilir').show();
            $("#dosya").prop('required', true);
            $("#sanal_urun_bilgileri").prop('required', false);
            $('.fiziksel').hide();
        } else {
            $('.sanal_urun_bilgileri').hide();
            $('.indirilebilir').hide();
            $('.fiziksel').hide();
            $("#sanal_urun_bilgileri").prop('required', false);
            $("#dosya").prop('required', false);
        }
    });

    /**
     * Komisyon Hesaplama
     */
    $(document).on("input paste focus", "#fiyat", function () {
        var fiyat = parseFloat($(this).val());
        if (!fiyat || fiyat == 0) {
            $('#kazanc').html('0.00 ₺');
        } else {
            var komisyon_bol = parseFloat(<?=$ayarlar->komisyon?>) / 100;
            var komisyon_carp = parseFloat(fiyat * komisyon_bol).toFixed(2);
            var komisyom_topla = parseFloat(fiyat - komisyon_carp).toFixed(2);
            $('#kazanc').html(komisyom_topla + ' ₺');
        }
    });
    $(document).on("input paste focus", "#eski_fiyat,#fiyat", function () {
        var fiyat = parseFloat($("#eski_fiyat").val());
        var urun_fiyat = parseFloat($("#fiyat").val());
        if (!fiyat || fiyat == 0 || !urun_fiyat || urun_fiyat == 0 || fiyat < urun_fiyat) {
            $("#indirim_yuzdesi").html("Yok")
        } else {
            var oran = 100 - Math.ceil((urun_fiyat * 100) / fiyat);
            $("#indirim_yuzdesi").html(oran + "%");
        }
    });

</script>