<div class="br-pageheader">
    <nav class="breadcrumb pd-0 mg-0 tx-12">
        <a class="breadcrumb-item" href="<?= base_url(admin_url()) ?>">Kontrol Paneli</a>
        <span class="breadcrumb-item active">Satın Alınan İlanlar</span>
    </nav>
</div><!-- br-pageheader -->
<div class="br-pagetitle">
    <i class="fas fa-store fa-4x"></i>
    <div>
        <h4>Satın Alınan İlanlar</h4>
        <p class="mg-b-0">Satın Alınan İlan Listesi</p>
    </div>
</div><!-- d-flex -->

<div class="br-pagebody">
    <div class="br-section-wrapper">
        <div class="table-wrapper">
            <table id="datatable1" class="table display responsive nowrap">
                <thead>
                <tr>
                    <th class="text-center">#</th>
                    <th class="text-center">İlan ADI</th>
                    <th class="text-center">İlan KATEGORİSİ</th>
                    <th class="text-center">İlanı EKLEYEN mağaza</th>
                    <th class="text-center">İlanı ALAN kullanıcı</th>
                    <th class="text-center">İlanı ALAN kullanıcı E-Posta</th>
                    <th class="text-center">Sipariş TUTAR</th>
                    <th class="text-center">İlan DURUM</th>
                    <!--<th class="text-center">İlan İŞLEM</th>-->
                </tr>
                </thead>
                <tbody>
                <?php if ($ilanlar) { ?>
                    <?php $i = 0;
                    foreach ($ilanlar as $key) {
                        $kat_json = json_decode($key->kategori_json);
                        $i++; ?>
                        <tr>
                            <td class="text-center"><?= $i ?></td>
                            <td class="text-center"><?= $key->urun_ad ?></td>
                            <td class="text-center">
                                <?php if ($kat_json) {
                                    foreach ($kat_json as $kat) { ?>
                                        <span class="badge badge-primary badge-pill"><?= get_kategori($kat)->kategori_ad ?></span>
                                    <?php }
                                } ?>
                            </td>
                            <td class="text-center"><?= $key->magaza_ad?></td>
                            <td class="text-center"><?= kullanici_ad_getir($key->kullanici_id); ?></td>
                            <td class="text-center"><?= kullanici_email_getir($key->kullanici_id); ?></td>
                            <td class="text-center"><?= $key->siparis_tutar ?></td>
                            <td class="text-center">
                                <span class="badge badge-success badge-pill">Sipariş Teslim Edildi</span>
                            </td>
                            <!--<td class="text-center">
                                <a href="<?php echo base_url(admin_url() . "ilan-duzenle/$key->urun_id"); ?>"
                                   class="btn btn-warning btn-with-icon">
                                    <div class="ht-40">
                                        <span class="icon fas fa-eye wd-40"><i class="fa fa-send"></i></span>
                                        <span class="pd-x-15">Detay</span>
                                    </div>
                                </a>
                                <a href="javascript:void(0)"
                                   data-url="<?= base_url(admin_url() . "ilan-sil/$key->urun_id") ?>"
                                   class="btn btn-danger btn-with-icon remove-btn">
                                    <div class="ht-40">
                                        <span class="icon far fa-trash-alt wd-40"><i class="fa fa-send"></i></span>
                                        <span class="pd-x-15">Sil</span>
                                    </div>
                                </a>
                            </td>-->
                        </tr>
                    <?php } ?>
                <?php } ?>
                </tbody>
            </table>
        </div><!-- table-wrapper -->
    </div><!-- br-section-wrapper -->
</div><!-- br-pagebody -->