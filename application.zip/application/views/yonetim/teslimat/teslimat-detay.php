<div class="br-pageheader">
    <nav class="breadcrumb pd-0 mg-0 tx-12">
        <a class="breadcrumb-item" href="<?= base_url(admin_url()) ?>">Kontrol Paneli</a>
        <a class="breadcrumb-item" href="<?= base_url(admin_url() . 'teslimat') ?>">Teslimatlar</a>
        <span class="breadcrumb-item active">Teslimat İtiraz Detayı</span>
    </nav>
</div><!-- br-pageheader -->
<div class="br-pagetitle">
    <i class="fas fa-life-ring fa-4x"></i>
    <div>
        <h4>Teslimat İtiraz Detayı</h4>
    </div>
</div><!-- d-flex -->

<div class="br-pagebody">
    <div class="br-section-wrapper">
        <div class="card mb-4">
            <div class="card-body">
                <div class="row no-gutters">
                    <div class="col-md-8">
                        
                        <div class="card-body">
                            <h3 class="mb-2 text-truncate-line-2 ">
                                <a target="_blank" href="<?= base_url($siparis->urun_seo) ?>"
                                   class="text-inherit"><?= $siparis->urun_ad ?></a>
                            </h3>
                            <!-- Row -->
                            <div class="row align-items-center no-gutters">
                                <div class="col-auto">
                                    <img width="35" src="<?= base_url($siparis->magaza_resim) ?>"
                                         class="rounded-circle avatar-xs" alt="<?= $siparis->urun_ad ?>">
                                </div>
                                <div class="col ml-2">
                                    <a target="_blank"
                                       href="<?= base_url('m/' . $siparis->magaza_seo) ?>"><?= $siparis->magaza_ad ?></a>
                                </div>
                            </div>
                            <div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 text-center">
                        <div class="card-body">
                            <span>Sipariş Tutarı</span>
                            <div class="d-flex justify-content-center">
                                <div class="font-weight-bold text-primary"
                                     style="font-size: 27px;"><?= $siparis->siparis_tutar ?></div>
                                <span class="h3 mb-0 font-weight-bold text-primary">₺</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="card mb-5">
            <div class="card-body">
                <div class="row mb-3">
                    <div class="col-md-6">
                        <?php if ($teslimat->teslimat_durum == 0) { ?>
                            <button type="button" class="btn btn-outline-warning btn-block rounded-pill">
                                Teslimat İtiraz Durumu Bekliyor..
                            </button>
                        <?php } elseif ($teslimat->teslimat_durum == 1) { ?>
                            <button type="button" class="btn btn-success btn-block rounded-pill">
                                <i class="fe fe-check-circle"></i> Teslimat İtirazı Çözüldü
                            </button>
                        <?php } elseif ($teslimat->teslimat_durum == 2) { ?>
                            <button type="button" class="btn btn-danger btn-block rounded-pill">
                                <i class="fe fe-x-circle"></i> Teslimat İtirazı Çözülemedi
                            </button>
                        <?php } elseif ($teslimat->teslimat_durum == 3) { ?>
                            <button type="button" class="btn btn-info btn-block rounded-pill">
                                Teslimat İtirazı Cevap Verildi..
                            </button>
                        <?php } ?>
                    </div>
                    <div class="col-md-6">
                        <button type="button" class="btn btn-primary btn-block rounded-pill">
                            <?= date('d.m.Y H:s', strtotime($teslimat->teslimat_zaman)) ?>
                        </button>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <form action="<?= base_url('yonetim_magaza_controller/teslimat_duzenle/' . $teslimat->teslimat_uniq . '/' . $siparis->siparis_no) ?>"
                      method="post">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="form-group">
                                <label class="form-control-label">Mesajınız.. <span
                                            class="tx-danger">*</span></label>
                                <textarea class="form-control" name="mesaj" rows="3" placeholder="Mesajınız.."></textarea>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group mg-b-10-force">
                                <label class="form-control-label">Teslimat İtiraz Durumu <span
                                            class="tx-danger">*</span></label>
                                <select class="form-control" name="teslimat_durum" required>
                                    <option <?php if ($teslimat->teslimat_durum == 0) {
                                        echo 'selected';
                                    } ?> value="0">Teslimat İtiraz Durumu Bekliyor..
                                    </option>
                                    <option <?php if ($teslimat->teslimat_durum == 3) {
                                        echo 'selected';
                                    } ?> value="3">Cevap Verildi
                                    </option>
                                    <option <?php if ($teslimat->teslimat_durum == 1) {
                                        echo 'selected';
                                    } ?> value="1">Teslimat İtirazı Çözüldü
                                    </option>
                                    <option <?php if ($teslimat->teslimat_durum == 2) {
                                        echo 'selected';
                                    } ?> value="2">Teslimat İtirazı Çözülemedi
                                    </option>
                                </select>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group mg-b-10-force">
                                <label class="form-control-label">Sipariş Durumu <span
                                            class="tx-danger">*</span></label>
                                <select class="form-control durum" name="siparis_durum" required>
                                    <option <?php if ($siparis->siparis_durum == 0) {
                                        echo 'selected';
                                    } ?> value="0">Ödeme Yapılmadı..
                                    </option>
                                    <option <?php if ($siparis->siparis_durum == 1) {
                                        echo 'selected';
                                    } ?> value="1">Teslimatı Onaylayın
                                    </option>
                                    <option <?php if ($siparis->siparis_durum == 2) {
                                        echo 'selected';
                                    } ?> value="2">Ödeme Yapıldı
                                    </option>
                                    <option <?php if ($siparis->siparis_durum == 3) {
                                        echo 'selected';
                                    } ?> value="3">Sipariş İptal Edildi
                                    </option>
                                </select>
                            </div>
                        </div>
                        <div class="col-lg-12 siparis_iptal" <?php if ($siparis->siparis_durum != 3) { echo 'style="display: none"'; } ?>>
                            <div class="form-group">
                                <label class="form-control-label">Sipariş İptal Notu <span
                                            class="tx-danger">*</span></label>
                                <textarea class="form-control iptal_input" name="siparis_iptal" rows="3" placeholder="Sipariş İptal Notu.."><?= $siparis->siparis_iptal ?></textarea>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <button type="submit" class="btn btn-primary float-right">Teslimat İtiraz Güncelle</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <div class="card border-0">
            <div class="card-body">
                <?php if ($mesajlar) {
                    foreach ($mesajlar as $mesaj) { ?>

                        <div class="border-bottom pt-0 pb-5 mt-3">
                            <div class="row mb-4">
                                <div class="col-lg-12 mb-2 mb-lg-0">
                                            <span class="d-block">
                                                <?php if ($mesaj->kullanici_yetki != 9) { ?>
                                                    <span class="h4 mb-0"><?= $mesaj->kullanici_isim . " " . $mesaj->kullanici_soyisim ?></span>
                                                <?php } else { ?>
                                                    <span class="h4 mb-0 text-success">Destek Yetkilisi</span>
                                                <?php } ?>
                                                <br>
                                                <?php if ($mesaj->kullanici_yetki != 9) { ?>
                                                    <span class="h6 m-0"><?= $mesaj->kullanici_mail ?></span>
                                                    <br>
                                                    <span class="badge badge-success badge-pill"><?= date('d.m.Y H:s', strtotime($mesaj->mesaj_zaman)) ?></span>
                                                <?php } else { ?>
                                                    <span class="badge badge-success badge-pill"><?= date('d.m.Y H:s', strtotime($mesaj->mesaj_zaman)) ?></span>
                                                <?php } ?>
                                            </span>
                                </div>
                            </div>
                            <!-- Pricing data -->
                            <div class="row">
                                <div class="col-lg-12 mb-2 mb-lg-0">
                                    <span class="font-size-xs">Mesaj</span>
                                    <h6 class="mb-0">
                                        <?= $mesaj->mesaj ?>
                                    </h6>
                                </div>
                            </div>
                        </div>
                    <?php }
                } ?>
            </div>
        </div>
    </div>
</div>


<script>
    $('.durum').on('change', function () {
        if (this.value == 3) {
            $('.siparis_iptal').show();
            $(".iptal_input").prop('required', true);
        } else {
            $('.siparis_iptal').hide();
            $(".iptal_input").prop('required', false);
        }
    });
</script>