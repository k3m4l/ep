<div class="br-pageheader">
    <nav class="breadcrumb pd-0 mg-0 tx-12">
        <a class="breadcrumb-item" href="<?= base_url(admin_url()) ?>">Kontrol Paneli</a>
        <span class="breadcrumb-item active">Teslimat İtirazları</span>
    </nav>
</div><!-- br-pageheader -->
<div class="br-pagetitle">
    <i class="fas fa-life-ring fa-4x"></i>
    <div>
        <h4>Teslimat İtirazları</h4>
    </div>
</div><!-- d-flex -->

<div class="br-pagebody">
    <div class="br-section-wrapper">
        <div class="table-wrapper">
            <table id="datatable1" class="table display responsive nowrap">
                <thead>
                <tr>
                    <th class="text-center">SİPARİŞ NO</th>
                    <th class="text-center">OLUŞTURAN KİŞİ</th>
                    <th class="text-center">OLUŞTURMA TARİHİ</th>
                    <th class="text-center">TESLİMAT DURUM</th>
                    <th class="text-center">TESLİMAT İŞLEM</th>
                </tr>
                </thead>
                <tbody>
                <?php if ($teslimat) { ?>
                    <?php foreach ($teslimat as $key) { ?>
                        <tr>
                            <td class="text-center">#<?= $key->siparis_no ?></td>
                            <td class="text-center"><?= $key->kullanici_isim . " " . $key->kullanici_soyisim ?></td>
                            <td class="text-center"><?= date('d.m.Y H:s', strtotime($key->teslimat_zaman))?></td>
                            <td class="text-center">
                                <?php if ($key->teslimat_durum == 0) { ?>
                                    <span class="badge badge-warning badge-pill">Teslimat İtiraz Durumu Bekliyor..</span>
                                <?php } elseif ($key->teslimat_durum == 1) { ?>
                                    <span class="badge badge-success badge-pill">Teslimat İtirazı Çözüldü</span>
                                <?php } elseif ($key->teslimat_durum == 2) { ?>
                                    <span class="badge badge-danger badge-pill">Teslimat İtirazı Çözülemedi</span>
                                <?php } elseif ($key->teslimat_durum == 3) { ?>
                                    <span class="badge badge-info badge-pill">Teslimat İtirazı Cevap Verildi</span>
                                <?php } ?>
                            </td>
                            <td class="text-center">
                                <a href="<?php echo base_url(admin_url() . "teslimat-detay/$key->siparis_no"); ?>"
                                   class="btn btn-warning btn-with-icon">
                                    <div class="ht-40">
                                        <span class="icon fas fa-eye wd-40"><i class="fa fa-send"></i></span>
                                        <span class="pd-x-15">Detay</span>
                                    </div>
                                </a>
                                <a href="javascript:void(0)"
                                   data-url="<?= base_url(admin_url() . "teslimat-sil/$key->teslimat_id") ?>"
                                   class="btn btn-danger btn-with-icon remove-btn">
                                    <div class="ht-40">
                                        <span class="icon far fa-trash-alt wd-40"><i class="fa fa-send"></i></span>
                                        <span class="pd-x-15">Sil</span>
                                    </div>
                                </a>
                            </td>
                        </tr>
                    <?php } ?>
                <?php } ?>
                </tbody>
            </table>
        </div><!-- table-wrapper -->
    </div><!-- br-section-wrapper -->
</div><!-- br-pagebody -->