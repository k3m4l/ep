<div class="br-pageheader">
    <nav class="breadcrumb pd-0 mg-0 tx-12">
        <a class="breadcrumb-item" href="<?= base_url(admin_url()) ?>">Kontrol Paneli</a>
        <a class="breadcrumb-item" href="<?= base_url(admin_url() . 'magazalar') ?>">Mağazalar</a>
        <span class="breadcrumb-item active">Mağaza Düzenle</span>
    </nav>
</div><!-- br-pageheader -->
<div class="br-pagetitle">
    <i class="fas fa-store fa-4x"></i>
    <div>
        <h4><?= $magaza->magaza_ad ?> - Mağaza Düzenle</h4>
    </div>
</div><!-- d-flex -->

<div class="br-pagebody">
    <div class="br-section-wrapper">
        <form action="<?= base_url("yonetim_magaza_controller/magazaduzenle/" . $magaza->magaza_uniq); ?>" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="magazaduzenle" value="1">
            <div class="form-layout form-layout-1">
                <div class="row mg-b-25">
                    <div class="col-lg-12">
                        <div class="form-group">
                            <label class="form-control-label">Mağaza Varsayılan Fotoğrafı <span class="tx-danger">*</span></label>
                            <input class="form-control" type="file" name="file">
                            <img width="100" class="mt-2" src="<?= base_url($magaza->magaza_resim) ?>" alt="<?= $magaza->magaza_ad ?>">
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label class="form-control-label">Mağaza Adı <span class="tx-danger">*</span></label>
                            <input class="form-control" type="text" name="ad" placeholder="Mağaza Adı" value="<?= $magaza->magaza_ad ?>" required>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group mg-b-10-force">
                            <label class="form-control-label">Mağaza Doğrulama Rozeti <span class="tx-danger">*</span></label>
                            <select class="form-control durum" name="rozet" required>
                                <option <?php if ($magaza->magaza_dogrulama == 0) {
                                            echo 'selected';
                                        } ?> value="0">Doğrulanmadı
                                </option>
                                <option <?php if ($magaza->magaza_dogrulama == 1) {
                                            echo 'selected';
                                        } ?> value="1">Doğrulandı
                                </option>
                            </select>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label class="form-control-label">Mağaza Kullanıcı Adı <small><?= base_url('m/') ?><code class="url_ad"><?= $magaza->magaza_seo ?></code></small></label>
                            <input class="form-control magaza_kullanici" type="text" name="seo" placeholder="Mağaza Kullanıcı Adı" value="<?= $magaza->magaza_seo ?>" required>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="form-group mg-b-10-force">
                            <label class="form-control-label">Mağaza Türü <span class="tx-danger">*</span></label>
                            <input type="text" class="form-control" name="magaza_turu" value="<?= ucwords(strtolower($magaza->magaza_tur)) ?? '' ?>">

                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="form-group mg-b-10-force">
                            <label class="form-control-label">Mağaza Durumu <span class="tx-danger">*</span></label>
                            <select class="form-control durum" name="durum" required>
                                <option <?php if ($magaza->magaza_durum == 0) {
                                            echo 'selected';
                                        } ?> value="0">Onay Bekliyor..
                                </option>
                                <option <?php if ($magaza->magaza_durum == 1) {
                                            echo 'selected';
                                        } ?> value="1">Onaylandı
                                </option>
                                <option <?php if ($magaza->magaza_durum == 2) {
                                            echo 'selected';
                                        } ?> value="2">Onaylanmadı
                                </option>
                            </select>
                        </div>
                    </div>
                    <div class="col-lg-12 magaza_iptal" <?php if ($magaza->magaza_durum != 2) {
                                                            echo 'style="display:none"';
                                                        } ?>>
                        <div class="form-group">
                            <label class="form-control-label">Mağaza Onaylanmadı Açıklaması<span class="tx-danger">*</span></label>
                            <textarea class="form-control magaza_iptal_input" name="magaza_iptal" rows="3" placeholder="Mağaza Onaylanmadı Açıklaması"><?= $magaza->magaza_iptal ?></textarea>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label class="form-control-label">Adı <span class="tx-danger">*</span></label>
                            <input class="form-control" type="text" placeholder="Adı" name="isim" value="<?= $magaza->isim ?>">
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="form-group">
                            <label class="form-control-label">Soyadı <span class="tx-danger">*</span></label>
                            <input class="form-control" type="text" placeholder="Soyadı" name="soyisim" value="<?= $magaza->soyisim ?>">
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="form-group">
                            <label class="form-control-label">Telefon Numarası <span class="tx-danger">*</span></label>
                            <input class="form-control" type="text" placeholder="Telefon Numarası" name="phone" value="<?= $magaza->telefon ?>">
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label class="form-control-label">TC Kimlik Numarası <span class="tx-danger">*</span></label>
                            <input class="form-control" type="text" placeholder="TC Kimlik Numarası" name="tc" value="<?= $magaza->tc ?>">
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label class="form-control-label">Doğum Tarihi <span class="tx-danger">*</span></label>
                            <input class="form-control" type="text" placeholder="Doğum Tarihi" name="dogum_tarihi" value="<?= $magaza->dogum_tarihi ?>">
                        </div>
                    </div>
                    <?php if ($magaza->magaza_tur == 'kurumsal') { ?>
                        <div class="col-lg-4">
                            <div class="form-group">
                                <label class="form-control-label">Firma Ad <span class="tx-danger">*</span></label>
                                <input class="form-control" type="text" placeholder="Firma Ad" value="<?= $magaza->firma_ad ?>" disabled>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="form-group">
                                <label class="form-control-label">Vergi Dairesi <span class="tx-danger">*</span></label>
                                <input class="form-control" type="text" placeholder="Vergi Dairesi" value="<?= $magaza->vergi_dairesi ?>" disabled>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="form-group">
                                <label class="form-control-label">Vergi Numarası <span class="tx-danger">*</span></label>
                                <input class="form-control" type="text" placeholder="Vergi Numarası" value="<?= $magaza->vergi_numarasi ?>" disabled>
                            </div>
                        </div>
                    <?php } ?>

                    <div class="col-lg-12">
                        <div class="form-group">
                            <label class="form-control-label">Fatura Adresi <span class="tx-danger">*</span></label>
                            <textarea class="form-control" rows="3" name="fatura_adres"><?= $magaza->fatura_adres ?></textarea>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group mg-b-10-force">
                            <label class="form-control-label">Şehir <span class="tx-danger">*</span></label>
                            <select class="form-control" name="sehir">
                                <?php foreach ($iller as $il) { ?>
                                    <option <?php if ($il->id == $magaza->sehir) {
                                                echo 'selected';
                                            } ?>><?= $il->il_adi ?></option>
                                <?php } ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group mg-b-10-force">
                            <label class="form-control-label">İlçe <span class="tx-danger">*</span></label>
                            <select class="form-control" name="ilce">
                                <?php foreach ($ilceler as $ilce) { ?>
                                    <option <?php if ($ilce->id == $magaza->ilce) {
                                                echo 'selected';
                                            } ?>><?= $ilce->ilce_adi ?></option>
                                <?php } ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-lg-12">
                        <div class="form-group">
                            <label class="form-control-label">Mağazanızda ne satacaksınız? <span class="tx-danger">*</span></label>
                            <textarea class="form-control" rows="3" name="hakkinda"><?= $magaza->magaza_hakkinda ?? '' ?></textarea>
                        </div>
                    </div>


                </div>

                <div class="form-layout-footer">
                    <button type="submit" class="btn btn-info">Mağaza Güncelle</button>
                </div><!-- form-layout-footer -->
            </div>
        </form><!-- form-layout -->
    </div>
</div>

<script>
    $('.durum').on('change', function() {
        if (this.value == 2) {
            $('.magaza_iptal').show();
            $(".magaza_iptal_input").prop('required', true);
        } else {
            $('.magaza_iptal').hide();
            $(".magaza_iptal_input").prop('required', false);
        }
    });
</script>