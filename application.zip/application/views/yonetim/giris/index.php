<?php $siteayar = ayarlar(); ?>

<style>
    .vf-full {
        height: 100vh;
    }
    .login-wrapper {
       padding: 20px;
    }
</style>
<div class="d-flex align-items-center justify-content-center bg-gray-200 ht-100v vf-full"
     style="background-image: url('<?php echo base_url('assets/yonetim/img/wallpaper.jpg') ?>');background-size: cover;">

    <div class="login-wrapper wd-300 wd-xs-350 pd-25 pd-xs-40  rounded shadow-base"
         style="border-radius: 15px !important;background-color: #1e1e2d;">
        <div class="signin-logo tx-center tx-28 tx-bold tx-inverse mb-4"><img class="img-fluid"
                                                                              src="<?= base_url($siteayar->site_logo) ?>" alt=""></div>
        <div class="tx-center mg-b-35 " style="color:#fff;">Yönetim Paneli - Giriş Yap</div>
        <form action="<?= base_url(admin_url() . "girisyap") ?>" method="post">
            <div class="form-group">
                <input type="text" class="form-control" name="username" placeholder="Kullanıcı Adı">
                <?php if (isset($form_error)) { ?> <code class="pull-right"><?= form_error('username') ?></code><?php } ?>
            </div><!-- form-group -->
            <div class="form-group">
                <input type="password" class="form-control" name="password" placeholder="Şifre">
                <?php if (isset($form_error)) { ?> <code class="pull-right"><?= form_error('password') ?></code><?php } ?>
            </div><!-- form-group -->
            <button type="submit" class="btn btn-info btn-block"
                    style="background-color: #313d5a !important;border-color: #313d5a !important;border-radius: 5px !important;">Giriş
                Yap
            </button>
        </form>
    </div><!-- login-wrapper -->
</div><!-- d-flex -->