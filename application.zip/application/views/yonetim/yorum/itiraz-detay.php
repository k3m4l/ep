<div class="br-pageheader">
    <nav class="breadcrumb pd-0 mg-0 tx-12">
        <a class="breadcrumb-item" href="<?= base_url(admin_url()) ?>">Kontrol Paneli</a>
        <a class="breadcrumb-item" href="<?= base_url(admin_url() . 'yorumlar') ?>">Yorumlar</a>
        <span class="breadcrumb-item active">Yorum Detay</span>
    </nav>
</div><!-- br-pageheader -->
<div class="br-pagetitle">
    <i class="fas fa-comment-alt fa-4x"></i>
    <div>
        <h4>Yorumlar</h4>
    </div>
</div><!-- d-flex -->

<div class="br-pagebody">
    <div class="br-section-wrapper">
        <div class="card mb-5">
            <div class="card-body">
                <div class="row mb-3">
                    <div class="col-md-6">
                        <?php if ($yorum->yorum_durum == 0) { ?>
                            <button type="button" class="btn btn-outline-warning btn-block rounded-pill">
                                Onay Bekliyor..
                            </button>
                        <?php } elseif ($yorum->yorum_durum == 1) { ?>
                            <button type="button" class="btn btn-success btn-block rounded-pill">
                                <i class="fe fe-check-circle"></i> Onaylandı
                            </button>
                        <?php } elseif ($yorum->yorum_durum == 2) { ?>
                            <button type="button" class="btn btn-danger btn-block rounded-pill">
                                <i class="fe fe-x-circle"></i> Onaylanmadı
                            </button>
                        <?php } ?>
                    </div>
                    <div class="col-md-6">
                        <button type="button" class="btn btn-primary btn-block rounded-pill">
                            <?= date('d.m.Y H:s', strtotime($yorum->yorum_zaman)) ?>
                        </button>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <form action="<?= base_url(admin_url().'itiraz-duzenle/' . $yorum->itiraz_id) ?>"
                      method="post">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="form-group">
                                <div id="full-stars-example-two">
                                    <div class="rating-group">
                                        <input class="rating__input rating__input--none"
                                               id="rating3-none" value="0"
                                               type="radio" <?php if ($yorum->yorum_durum == 0) {
                                            echo 'checked';
                                        } ?> disabled>
                                        <label aria-label="1 star" class="rating__label"
                                               for="rating3-1"><i
                                                class="rating__icon rating__icon--star fa fa-star"></i></label>
                                        <input class="rating__input"
                                               id="rating3-1" value="1"
                                               type="radio" <?php if ($yorum->yorum_puan == 1) {
                                            echo 'checked';
                                        } ?> disabled>
                                        <label aria-label="2 stars" class="rating__label"
                                               for="rating3-2"><i
                                                class="rating__icon rating__icon--star fa fa-star"></i></label>
                                        <input class="rating__input"
                                               id="rating3-2" value="2"
                                               type="radio" <?php if ($yorum->yorum_puan == 2) {
                                            echo 'checked';
                                        } ?> disabled>
                                        <label aria-label="3 stars" class="rating__label"
                                               for="rating3-3"><i
                                                class="rating__icon rating__icon--star fa fa-star"></i></label>
                                        <input class="rating__input"
                                               id="rating3-3" value="3"
                                               type="radio" <?php if ($yorum->yorum_puan == 3) {
                                            echo 'checked';
                                        } ?> disabled>
                                        <label aria-label="4 stars" class="rating__label"
                                               for="rating3-4"><i
                                                class="rating__icon rating__icon--star fa fa-star"></i></label>
                                        <input class="rating__input"
                                               id="rating3-4" value="4"
                                               type="radio" <?php if ($yorum->yorum_puan == 4) {
                                            echo 'checked';
                                        } ?> disabled>
                                        <label aria-label="5 stars" class="rating__label"
                                               for="rating3-5"><i
                                                class="rating__icon rating__icon--star fa fa-star"></i></label>
                                        <input class="rating__input"
                                               id="rating3-5" value="5"
                                               type="radio" <?php if ($yorum->yorum_puan == 5) {
                                            echo 'checked';
                                        } ?> disabled>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <div class="form-group">
                                <label class="form-control-label">Mesajınız.. <span
                                        class="tx-danger">*</span></label>
                                <textarea class="form-control" rows="3" placeholder="Mesajınız.." disabled><?=$yorum->yorum_detay?></textarea>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group mg-b-10-force">
                                <label class="form-control-label">Yorum Durumu <span
                                        class="tx-danger">*</span></label>
                                <select class="form-control" name="yorum_durum" required>
                                    <option <?php if ($yorum->yorum_durum == 0) {
                                        echo 'selected';
                                    } ?> value="0">Onay Bekliyor..
                                    </option>
                                    <option <?php if ($yorum->yorum_durum == 1) {
                                        echo 'selected';
                                    } ?> value="1">Onaylandı
                                    </option>
                                    <option <?php if ($yorum->yorum_durum == 2) {
                                        echo 'selected';
                                    } ?> value="2">Onaylanmadı
                                    </option>
                                </select>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group mg-b-10-force">
                                <label class="form-control-label">Yorum İtiraz Durumu <span
                                            class="tx-danger">*</span></label>
                                <select class="form-control" name="itiraz_durum" required>
                                    <option <?php if ($yorum->itiraz_durum == 0) {
                                        echo 'selected';
                                    } ?> value="0">İnceleniyor..
                                    </option>
                                    <option <?php if ($yorum->itiraz_durum == 1) {
                                        echo 'selected';
                                    } ?> value="1">İtirazınız Onaylandı
                                    </option>
                                    <option <?php if ($yorum->itiraz_durum == 2) {
                                        echo 'selected';
                                    } ?> value="2">İtirazınız Onaylanmadı
                                    </option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <button type="submit" class="btn btn-primary float-right">Yorum Güncelle</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
