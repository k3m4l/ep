<div class="br-pageheader">
    <nav class="breadcrumb pd-0 mg-0 tx-12">
        <a class="breadcrumb-item" href="<?= base_url(admin_url()) ?>">Kontrol Paneli</a>
        <span class="breadcrumb-item active">Yorumlar</span>
    </nav>
</div><!-- br-pageheader -->
<div class="br-pagetitle">
    <i class="fas fa-comment-alt fa-4x"></i>
    <div>
        <h4>Yorumlar</h4>
        <p class="mg-b-0">Yorum Listesi</p>
    </div>
</div><!-- d-flex -->

<div class="br-pagebody">
    <div class="br-section-wrapper">
        <div class="table-wrapper">
            <table id="datatable1" class="table display responsive nowrap">
                <thead>
                <tr>
                    <th class="text-center">SİPARİŞ NO</th>
                    <th class="text-center">YORUM YAPAN</th>
                    <th class="text-center">YORUM PUAN</th>
                    <th class="text-center">YORUM ZAMAN</th>
                    <th class="text-center">YORUM DURUM</th>
                    <th class="text-center">YORUM İŞLEM</th>
                </tr>
                </thead>
                <tbody>
                <?php if ($yorumlar) { ?>
                    <?php foreach ($yorumlar as $key) { ?>
                        <tr>
                            <td class="text-center">#<?= $key->siparis_no ?></td>
                            <td class="text-center"><?= $key->kullanici_isim." ".$key->kullanici_soyisim ?></td>
                            <td class="text-center">
                                <span class="badge badge-primary badge-pill"><?= $key->yorum_puan ?></span>
                            </td>
                            <td class="text-center"><?= date('d.m.Y H:s', strtotime($key->yorum_zaman))?></td>
                            <td class="text-center">
                                <?php if ($key->yorum_durum == 0) { ?>
                                    <span class="badge badge-warning badge-pill">Onay Bekliyor..</span>
                                <?php } elseif ($key->yorum_durum == 1) { ?>
                                    <span class="badge badge-success badge-pill">Onaylandı</span>
                                <?php } elseif ($key->yorum_durum == 2) { ?>
                                    <span class="badge badge-danger badge-pill">Onaylanmadı</span>
                                <?php } ?>
                            </td>
                            <td class="text-center">
                                <a href="<?php echo base_url(admin_url() . "yorum-detay/$key->siparis_no"); ?>"
                                   class="btn btn-warning btn-with-icon">
                                    <div class="ht-40">
                                        <span class="icon fas fa-eye wd-40"><i class="fa fa-send"></i></span>
                                        <span class="pd-x-15">Detay</span>
                                    </div>
                                </a>
                                <a href="javascript:void(0)"
                                   data-url="<?= base_url(admin_url() . "yorum-sil/$key->yorum_id") ?>"
                                   class="btn btn-danger btn-with-icon remove-btn">
                                    <div class="ht-40">
                                        <span class="icon far fa-trash-alt wd-40"><i class="fa fa-send"></i></span>
                                        <span class="pd-x-15">Sil</span>
                                    </div>
                                </a>
                            </td>
                        </tr>
                    <?php } ?>
                <?php } ?>
                </tbody>
            </table>
        </div><!-- table-wrapper -->
    </div><!-- br-section-wrapper -->
</div><!-- br-pagebody -->