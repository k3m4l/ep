<div class="br-pageheader">
    <nav class="breadcrumb pd-0 mg-0 tx-12">
        <a class="breadcrumb-item" href="<?= base_url(admin_url()) ?>">Kontrol Paneli</a>
        <span class="breadcrumb-item active">Yorum İtirazları</span>
    </nav>
</div><!-- br-pageheader -->
<div class="br-pagetitle">
    <i class="fas fa-comment-alt fa-4x"></i>
    <div>
        <h4>Yorum İtirazları</h4>
    </div>
</div><!-- d-flex -->

<div class="br-pagebody">
    <div class="br-section-wrapper">
        <div class="table-wrapper">
            <table id="datatable1" class="table display responsive nowrap">
                <thead>
                <tr>
                    <th class="text-center">SİPARİŞ NO</th>
                    <th class="text-center">İTİRAZ EDEN MAĞAZA</th>
                    <th class="text-center">YORUM PUAN</th>
                    <th class="text-center">İTİRAZ ZAMAN</th>
                    <th class="text-center">İTİRAZ DURUM</th>
                    <th class="text-center">İTİRAZ İŞLEM</th>
                </tr>
                </thead>
                <tbody>
                <?php if ($yorumlar) { ?>
                    <?php foreach ($yorumlar as $key) { $magaza = magaza($key->magaza_id); ?>
                        <tr>
                            <td class="text-center">#<?= $key->siparis_no ?></td>
                            <td class="text-center"><?= $magaza->magaza_ad ?></td>
                            <td class="text-center">
                                <span class="badge badge-primary badge-pill"><?= $key->yorum_puan ?></span>
                            </td>
                            <td class="text-center"><?= date('d.m.Y H:s', strtotime($key->itiraz_zaman))?></td>
                            <td class="text-center">
                                <?php if ($key->itiraz_durum == 0) { ?>
                                    <span class="badge badge-warning badge-pill">İnceleniyor..</span>
                                <?php } elseif ($key->itiraz_durum == 1) { ?>
                                    <span class="badge badge-success badge-pill">İtirazınız Onaylandı</span>
                                <?php } elseif ($key->itiraz_durum == 2) { ?>
                                    <span class="badge badge-danger badge-pill">İtirazınız Onaylanmadı</span>
                                <?php } ?>
                            </td>
                            <td class="text-center">
                                <a href="<?php echo base_url(admin_url() . "itiraz-detay/$key->itiraz_id"); ?>"
                                   class="btn btn-warning btn-with-icon">
                                    <div class="ht-40">
                                        <span class="icon fas fa-eye wd-40"><i class="fa fa-send"></i></span>
                                        <span class="pd-x-15">Detay</span>
                                    </div>
                                </a>
                                <a href="javascript:void(0)"
                                   data-url="<?= base_url(admin_url() . "itiraz-sil/$key->itiraz_id") ?>"
                                   class="btn btn-danger btn-with-icon remove-btn">
                                    <div class="ht-40">
                                        <span class="icon far fa-trash-alt wd-40"><i class="fa fa-send"></i></span>
                                        <span class="pd-x-15">Sil</span>
                                    </div>
                                </a>
                            </td>
                        </tr>
                    <?php } ?>
                <?php } ?>
                </tbody>
            </table>
        </div><!-- table-wrapper -->
    </div><!-- br-section-wrapper -->
</div><!-- br-pagebody -->