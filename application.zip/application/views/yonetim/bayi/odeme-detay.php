<div class="br-pageheader">
    <nav class="breadcrumb pd-0 mg-0 tx-12">
        <a class="breadcrumb-item" href="<?= base_url(admin_url()) ?>">Kontrol Paneli</a>
        <a class="breadcrumb-item" href="<?= base_url(admin_url() . 'bayi-odeme-talepleri') ?>">Para Çekme Talepleri</a>
        <span class="breadcrumb-item active">Para Çekme Detay</span>
    </nav>
</div><!-- br-pageheader -->
<div class="br-pagetitle">
    <i class="fas fa-lira-sign fa-4x"></i>
    <div>
        <h4>Para Çekme Detay</h4>
    </div>
</div><!-- d-flex -->

<div class="br-pagebody">
    <div class="br-section-wrapper">
        <div class="card mb-5">
            <div class="card-body">
                <form action="<?= base_url(admin_url() . 'bayi-odeme-duzenle/' . $talep->id) ?>"
                      method="post">
                    <?php
                    $json = json_decode($talep->information_json);
                    ?>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <?php if ($talep->status == 0) { ?>
                                <span class="btn btn-warning rounded-pill btn-block">Onay Bekliyor..</span>
                            <?php } elseif ($talep->status == 1) { ?>
                                <span class="btn btn-success rounded-pill btn-block">Onaylandı</span>
                            <?php } elseif ($talep->status == 2) { ?>
                                <span class="btn btn-secondary rounded-pill btn-block">Onaylanmadı</span>
                            <?php } ?>
                        </div>
                        <div class="col-md-6">
                            <button type="submit" class="btn btn-primary rounded-pill btn-block">
                                <?= date('d.m.Y H:i', strtotime($talep->created_at)) ?>
                            </button>
                        </div>
                    </div>
                    <div class="card mb-4">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="form-label">IBAN No</label>
                                        <input class="form-control" type="text" value="<?= $json->bank_account->iban ?>"
                                               placeholder="IBAN No" disabled>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="form-label">Çekilecek Tutar</label>
                                        <input class="form-control" type="text" value="<?= $talep->amount ?>₺"
                                               placeholder="Çekilecek Tutar" disabled>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="form-label">Alıcı Ad Soyad</label>
                                        <input class="form-control" type="text" value="<?= $json->bank_account->full_name ?>"
                                               placeholder="Sipariş Numarası" disabled>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="form-label">Komisyonsuz Tutar</label>
                                        <input class="form-control" type="text" value="<?= $json->amountWithoutCommissionAmount ?>₺"
                                                  disabled>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="form-label">Para Çekme Talep Durumu </label>
                                        <select class="form-control" name="odeme_durum" required>
                                            <option <?php if ($talep->status== 0) {
                                                echo 'selected';
                                            } ?> value="0">Onay Bekliyor..
                                            </option>
                                            <option <?php if ($talep->status == 1) {
                                                echo 'selected';
                                            } ?> value="1">Onaylandı
                                            </option>
                                            <option <?php if ($talep->status == 2) {
                                                echo 'selected';
                                            } ?> value="2">Onaylanmadı
                                            </option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <button type="submit" class="btn btn-primary">Para Çekme Talebi Güncelle</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
