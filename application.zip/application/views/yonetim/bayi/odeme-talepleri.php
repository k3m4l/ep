<div class="br-pageheader">
    <nav class="breadcrumb pd-0 mg-0 tx-12">
        <a class="breadcrumb-item" href="<?= base_url(admin_url()) ?>">Kontrol Paneli</a>
        <span class="breadcrumb-item active">Bayi Para Çekme Talepleri</span>
    </nav>
</div><!-- br-pageheader -->
<div class="br-pagetitle">
    <i class="fas fa-lira-sign fa-4x"></i>
    <div>
        <h4>Bayi Para Çekme Talepleri</h4>
        <p class="mg-b-0">Bayi Para Çekme Talep Listesi</p>
    </div>
</div><!-- d-flex -->

<div class="br-pagebody">
    <div class="br-section-wrapper">
        <div class="table-wrapper">
            <table id="datatable1" class="table display responsive nowrap">
                <thead>
                <tr>
                    <th class="text-center">TALEP NO</th>
                    <th class="text-center">TALEP OLUŞTURAN</th>
                    <th class="text-center">TALEP ZAMAN</th>
                    <th class="text-center">TALEP DURUM</th>
                    <th class="text-center">TALEP İŞLEM</th>
                </tr>
                </thead>
                <tbody>
                <?php if ($talepler) { ?>
                    <?php foreach ($talepler as $key) { $json = json_decode($key->information_json);?>
                        <tr>
                            <td class="text-center">#<?= $key->id ?></td>
                            <td class="text-center"><?= $key->kullanici_ad  ?></td>
                            <td class="text-center"><?= date('d.m.Y H:i:s', strtotime($key->created_at)) ?></td>
                            <td class="text-center">
                                <?php if ($key->status == 0) { ?>
                                    <span class="badge badge-warning badge-pill">Onay Bekliyor..</span>
                                <?php } elseif ($key->status == 1) { ?>
                                    <span class="badge badge-success badge-pill">Onaylandı</span>
                                <?php } elseif ($key->status == 2) { ?>
                                    <span class="badge badge-secondary badge-pill">Onaylanmadı</span>
                                <?php } ?>
                            </td>
                            <td class="text-center">
                                <a href="<?php echo base_url(admin_url() . "bayi-odeme-detay/$key->id"); ?>"
                                   class="btn btn-warning btn-with-icon">
                                    <div class="ht-40">
                                        <span class="icon fas fa-eye wd-40"><i class="fa fa-send"></i></span>
                                        <span class="pd-x-15">Detay</span>
                                    </div>
                                </a>
                                <a href="javascript:void(0)"
                                   data-url="<?= base_url(admin_url() . "bayi-odeme-sil/$key->id") ?>"
                                   class="btn btn-danger btn-with-icon remove-btn">
                                    <div class="ht-40">
                                        <span class="icon far fa-trash-alt wd-40"><i class="fa fa-send"></i></span>
                                        <span class="pd-x-15">Sil</span>
                                    </div>
                                </a>
                            </td>
                        </tr>
                    <?php } ?>
                <?php } ?>
                </tbody>
            </table>
        </div><!-- table-wrapper -->
    </div><!-- br-section-wrapper -->
</div><!-- br-pagebody -->