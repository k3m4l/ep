<div class="br-pageheader">
	<nav class="breadcrumb pd-0 mg-0 tx-12">
		<a class="breadcrumb-item" href="<?= base_url(admin_url()) ?>">Kontrol Paneli</a>
		<span class="breadcrumb-item active">Slider Güncelle</span>
	</nav>
</div><!-- br-pageheader -->
<div class="br-pagetitle">
	<i class="far fa-file-alt fa-4x"></i>
	<div>
		<h4>Slider Güncelle</h4>
		<p class="mg-b-0">Oluşturduğunuz sliderları güncelleyebilirsiniz.</p>
	</div>
</div><!-- d-flex -->

<div class="br-pagebody">
	<div class="br-section-wrapper">
		<form action="<?= base_url(admin_url() . "sliderguncelle/$where->slider_id"); ?>" method="post" enctype="multipart/form-data">
			<div class="form-layout form-layout-1">
				<div class="row mg-b-25">
                    <div class="col-md-10">
                        <div class="form-group">
                            <div action="<?php echo base_url('image/Add_images/add_image'); ?>" class="dropzone dropzone-area" id="dpz-single-files">
                                <div class="dz-message">
                                    <span class="m-dropzone__msg-desc">
                                        Bir Adet Resim Yükleyiniz.
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="mt-2 mr-1 text-center">
                            <span>Yüklü Resim</span>
                            <img src="<?php echo !empty($where->slider_resim) ? base_url($where->slider_resim) : '' ; ?>" alt="Holi" class=" w-100 rounded img-fluid float-left mr-2 mb-1" width="400" height="300" data-action="zoom">
                        </div>
                    </div>
					<div class="col-lg-4">
						<div class="form-group">
							<label class="form-control-label">Slider Sırası</label>
							<input class="form-control" type="number" name="sira" placeholder="Slider Sırası" value="<?= $where->slider_sira ?>">
						</div>
					</div><!-- col-8 -->

					<div class="col-lg-4">
						<div class="form-group">
							<label class="form-control-label">Slider Url <span class="tx-danger">*</span></label>
							<input class="form-control" type="text" name="url" placeholder="Slider Url" value="<?= $where->slider_url ?>">
						</div>
					</div>
					<div class="col-lg-4">
						<div class="form-group">
							<label class="form-control-label">Tür <span class="tx-danger">*</span></label>
							<select class="form-control" type="text" name="tur" required="">
								<option value="1">Ana Slider</option>
								<option value="2" <?php if ($where->tur == "2") {
														echo 'selected';
													} ?>>Alt Slider</option>
								<option value="3" <?php if ($where->tur == "3") {
														echo 'selected';
													} ?>>Üst Slider</option>
                                <option value="4" <?php if ($where->tur == "4") {
                                    echo 'selected';
                                } ?>>Yan Slider</option>
							</select>
						</div>
					</div><!-- col-4 -->
                    <?php if ($where->tur != 4) { ?>
					<div class="col-lg-6">
						<label for="">Slider Başlık</label>
						<input class="form-control" type="text" name="slider_baslik" value="<?= $where->slider_baslik ?>" required="">
					</div>
					<div class="col-lg-6">
						<label for="">Slider Açıklama</label>
						<input class="form-control" type="text" name="slider_aciklama" value="<?= $where->slider_aciklama ?>" required="">
					</div>
                    <?php } ?>
				</div>

				<div class="form-layout-footer">
					<button type="submit" class="btn btn-info">Slider Güncelle</button>
				</div><!-- form-layout-footer -->
			</div>
		</form><!-- form-layout -->
	</div>
</div>
<script>
	$(document).ready(function() {
		CKEDITOR.replace('detay');
	});
</script>