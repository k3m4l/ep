<div class="br-pageheader">
	<nav class="breadcrumb pd-0 mg-0 tx-12">
		<a class="breadcrumb-item" href="<?= base_url(admin_url()) ?>">Kontrol Paneli</a>
		<span class="breadcrumb-item active">Yeni Slider Oluştur</span>
	</nav>
</div><!-- br-pageheader -->
<div class="br-pagetitle">
	<i class="far fa-images fa-4x"></i>
	<div>
		<h4>Yeni Slider Oluştur</h4>
	</div>
</div><!-- d-flex -->

<div class="br-pagebody">
	<div class="br-section-wrapper">
		<form action="<?= base_url(admin_url() . "sliderekle"); ?>" method="post" enctype="multipart/form-data">
			<div class="form-layout form-layout-1">
				<div class="row mg-b-25">
                    <div class="col-md-12">
                        <div class="form-group">
                            <div action="<?php echo base_url('image/Add_images/add_image'); ?>" class="dropzone dropzone-area" id="dpz-single-files">
                                <div class="dz-message">
                                    <span class="m-dropzone__msg-desc">
                                        Bir Adet Resim Yükleyiniz.
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
					<div class="col-lg-4">
						<div class="form-group">
							<label class="form-control-label">Slider Sırası</label>
							<input class="form-control" type="number" name="sira" placeholder="Slider Sırası" value="1">
						</div>
					</div><!-- col-8 -->
					<div class="col-lg-4">
						<div class="form-group">
							<label class="form-control-label">Slider Url <span class="tx-danger">*</span></label>
							<input class="form-control" type="text" name="url" placeholder="Slider Url" required="">
						</div>
					</div>
					<div class="col-lg-4">
						<div class="form-group">
							<label class="form-control-label">Tür <span class="tx-danger">*</span></label>
							<select class="form-control" type="text" name="tur" required="">
								<option value="1">Ana Slider</option>
								<option value="2">Alt Slider</option>
								<option value="3">Üst Slider</option>
							</select>
						</div>
					</div><!-- col-4 -->
					<div class="col-lg-6">
						<label for="">Slider Başlık</label>
						<input class="form-control" type="text" name="slider_baslik" placeholder="Slider Başlık" required="">
					</div>
					<div class="col-lg-6">
						<label for="">Slider Açıklama</label>
						<input class="form-control" type="text" name="slider_aciklama" placeholder="Slider Açıklama" required="">
					</div>
				</div>

				<div class="form-layout-footer">
					<button type="submit" class="btn btn-info">Slider Ekle</button>
				</div><!-- form-layout-footer -->
			</div>
		</form><!-- form-layout -->
	</div>
</div>
<script>
	$(document).ready(function() {
		CKEDITOR.replace('detay');
	});
</script>