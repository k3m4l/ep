<div class="br-pageheader">
    <nav class="breadcrumb pd-0 mg-0 tx-12">
        <a class="breadcrumb-item" href="<?= base_url(admin_url()) ?>">Kontrol Paneli</a>
        <span class="breadcrumb-item active">Kategoriler</span>
    </nav>
</div><!-- br-pageheader -->
<div class="br-pagetitle">
    <i class="fas fa-grip-horizontal fa-4x"></i>
    <div>
        <h4>Kategoriler</h4>
        <p class="mg-b-0">Kategoriler</p>
    </div>
</div><!-- d-flex -->
<script>
    function openCity(cityName) {
        var i;
        var x = document.getElementsByClassName("city");
        for (i = 0; i < x.length; i++) {
            x[i].style.display = "none";
        }
        document.getElementById(cityName).style.display = "block";
    }
</script>
<div class="br-pagebody">
    <div class="br-section-wrapper">
        <?php if(1 == 2) { ?>
        <div class="w3-bar w3-black" style="display: flex;justify-content: center">
            <button class="btn btn-info btn-with-icon" style="margin-right: 10px;padding: 10px;" onclick="openCity('categories')">Kategoriler</button>
            <button class="btn btn-info btn-with-icon" style="margin-left: 10px;padding: 10px;" onclick="openCity('sub-categories')">Alt Kategoriler</button>
        </div>
        <hr>
        <?php } ?>
        <?php if (@$_GET["stats"] != Null){
            $where = $this->yonetim_model->kategoriget(array("kategori_id" => $_GET["stats"]));
            ?>
            <h4><?= $where->kategori_ad; ?> istatistikleri</h4>


            <div class="row">

                <div class="col-md-3 mt-3">
                    <div class="card card-animate">
                        <div class="card-body">
                            <div class="d-flex justify-content-between">
                                <div>
                                    <p class="fw-medium text-muted mb-0">Toplam Ürün</p>
                                    <h2 class="mt-4 ff-secondary"><span class="counter-value"
                                                                        data-target="547"><?php $usera = $this->db->query("SELECT * FROM urunler WHERE kategori_json LIKE '" . '%"' . $_GET["stats"] . '"%' . "'");
                                            echo $usera->num_rows(); ?></span></h2>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 mt-3">
                    <div class="card card-animate">
                        <div class="card-body">
                            <div class="d-flex justify-content-between">
                                <div>
                                    <p class="fw-medium text-muted mb-0">Toplam Satış</p>
                                    <h2 class="mt-4 ff-secondary"><span class="counter-value"
                                                                        data-target="547"><?php $wer = "kategori_json LIKE '" . '%"' . $_GET["stats"] . '"%' . "'";
                                            $kategoriler = $this->db->where($wer)->order_by("urun_id DESC")->get("urunler")->result();
                                            $adet = "0";
                                            $satis = "0";
                                            $komisyonlu = "0";
                                            $gun = "0";
                                            $hafta = "0";
                                            $ay = "0";
                                            foreach ($kategoriler as $key) {

                                                $userax = $this->db->query("SELECT * FROM siparis WHERE urun_id = '" . $key->urun_id . "' and siparis_zaman>='" . date("Y-m-d") . "' ");
                                                $v = $userax->num_rows();
                                                $gun = $gun + $v;

                                                $userax = $this->db->query("SELECT * FROM siparis WHERE urun_id = '" . $key->urun_id . "' and siparis_zaman>='" . date("Y-m-d", strtotime('monday this week')) . "' ");
                                                $v = $userax->num_rows();
                                                $hafta = $hafta + $v;

                                                $userax = $this->db->query("SELECT * FROM siparis WHERE urun_id = '" . $key->urun_id . "' and siparis_zaman>='" . date("Y-m-d", strtotime('first day of this month')) . "' ");
                                                $v = $userax->num_rows();
                                                $ay = $ay + $v;

                                                $userax = $this->db->query("SELECT * FROM siparis WHERE urun_id = '" . $key->urun_id . "'");
                                                $v = $userax->num_rows();
                                                $adet = $adet + $v;
                                                $data = $this->db->query("Select SUM(siparis_tutar) as total, SUM(siparis_ktutar) as komisyon from siparis Where urun_id = '" . $key->urun_id . "' ")->row_array();

                                                if ($data["total"] != Null) {
                                                    $satis = $satis + $data["total"];
                                                    $komisyonlu = $komisyonlu + $data["komisyon"];
                                                }
                                            }
                                            echo $adet;
                                            ?></span></h2>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 mt-3">
                    <div class="card card-animate">
                        <div class="card-body">
                            <div class="d-flex justify-content-between">
                                <div>
                                    <p class="fw-medium text-muted mb-0">Toplam Kazanç</p>
                                    <h2 class="mt-4 ff-secondary"><span class="counter-value"
                                                                        data-target="547"><?php echo $satis; ?>TL</span>
                                    </h2>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 mt-3">
                    <div class="card card-animate">
                        <div class="card-body">
                            <div class="d-flex justify-content-between">
                                <div>
                                    <p class="fw-medium text-muted mb-0">Toplam Komisyon Kazancı</p>
                                    <h2 class="mt-4 ff-secondary"><span class="counter-value"
                                                                        data-target="547"><?php echo $satis - $komisyonlu; ?>TL</span>
                                    </h2>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-4 mt-3">
                    <div class="card card-animate">
                        <div class="card-body">
                            <div class="d-flex justify-content-between">
                                <div>
                                    <p class="fw-medium text-muted mb-0">Bugün Yapılan Satış</p>
                                    <h2 class="mt-4 ff-secondary"><span class="counter-value"
                                                                        data-target="547"><?php echo $gun; ?></span>
                                    </h2>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-4 mt-3">
                    <div class="card card-animate">
                        <div class="card-body">
                            <div class="d-flex justify-content-between">
                                <div>
                                    <p class="fw-medium text-muted mb-0">Bu Hafta Yapılan Satış</p>
                                    <h2 class="mt-4 ff-secondary"><span class="counter-value"
                                                                        data-target="547"><?php echo $hafta; ?></span>
                                    </h2>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-4 mt-3">
                    <div class="card card-animate">
                        <div class="card-body">
                            <div class="d-flex justify-content-between">
                                <div>
                                    <p class="fw-medium text-muted mb-0">Bu Ay Yapılan Satış</p>
                                    <h2 class="mt-4 ff-secondary"><span class="counter-value"
                                                                        data-target="547"><?php echo $ay; ?></span></h2>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>


            </div>
            <?php
        } else{ ?>
        <div class="table-wrapper">
            <div id="categories" class="city">
            <h4>Kategoriler</h4>
            <table id="datatable2" class="table-responsive table display responsive nowrap">
                <thead>
                <tr>
                    <th class="wd-15p text-center">KATEGORİ ADI</th>
                    <th class="wd-5p text-center">KATEGORİ SIRA</th>
                    <th class="wd-15p text-center">KATEGORİ DURUM</th>
                    <th class="wd-10p text-center">KATEGORİ İŞLEM</th>
                </tr>
                </thead>
                <tbody>
                <?php $kategoriler = kategoriler_yonetimss(); ?>
                <?php if ($kategoriler) { ?>
                    <?php foreach ($kategoriler as $key) { ?>
                        <tr>
                            <td><?= $key->kategori_ad ?></td>
                            <td class="text-center">
                                <div class="badge badge-success"><?= $key->kategori_sira ?></div>
                            </td>
                            <td class="text-center">
                                <label class="switch">
                                    <input class="durum"
                                           data-url="<?= base_url(admin_url() . "durum/$key->kategori_id") ?>"
                                           type="checkbox" <?php if ($key->kategori_durum == 1) {
                                        echo 'checked';
                                    } ?>>
                                    <span class="slider round"></span>
                                </label>
                            </td>
                            <td class="text-center">
                                <?php if (1 == 2) { ?>
                                <a href="<?= base_url(admin_url() . "kategoriler?stats=$key->kategori_id") ?>"
                                   class="btn btn-info btn-with-icon">
                                    <div class="ht-40">
                                        <span class="pd-x-15">İstatistik</span>
                                    </div>
                                </a>
                                <?php if ($key->parent != 0) { ?>
                                    <a href="javascript:void(0)"
                                       class="btn btn-primary tx-11 pd-y-12 pd-x-25 tx-mont tx-medium"
                                       data-toggle="modal" data-target="#random_<?= $key->kategori_id ?>">
                                        <span class="pd-x-15">Random Fotoğraf</span>
                                    </a>
                                <?php } ?>
                                <a href="javascript:void(0)" data-toggle="modal"
                                   data-target="#banner_<?= $key->kategori_id ?>"
                                   class="btn btn-dark btn-with-icon">
                                    <div class="ht-40">
                                        <span class="icon fas fa-image wd-40"><i class="fa fa-send"></i></span>
                                        <span class="pd-x-15">Banner</span>
                                    </div>
                                </a>
                                <?php } ?>
                                <a href="<?php echo base_url(admin_url() . "kategori-duzenle/$key->kategori_id"); ?>"
                                   class="btn btn-warning btn-with-icon">
                                    <div class="ht-40">
                                        <span class="icon fas fa-edit wd-40"><i class="fa fa-send"></i></span>
                                        <span class="pd-x-15">Düzenle</span>
                                    </div>
                                </a>
                                <a href="javascript:void(0)"
                                   data-url="<?= base_url(admin_url() . "kategorisil/$key->kategori_id") ?>"
                                   class="btn btn-danger btn-with-icon remove-btn">
                                    <div class="ht-40">
                                        <span class="icon far fa-trash-alt wd-40"><i class="fa fa-send"></i></span>
                                        <span class="pd-x-15">Sil</span>
                                    </div>
                                </a>
                            </td>
                        </tr>
                        <div id="random_<?= $key->kategori_id ?>" class="modal fade" aria-hidden="true"
                             style="display: none;">
                            <div class="modal-dialog modal-dialog-vertical-center" role="document">
                                <div class="modal-content bd-0 tx-14">
                                    <div class="modal-header pd-y-20 pd-x-25">
                                        <h6 class="tx-14 mg-b-0 tx-uppercase tx-inverse tx-bold">Random Fotoğraf</h6>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">×</span>
                                        </button>
                                    </div>
                                    <div class="modal-body pd-25">
                                        <form action="<?= base_url(admin_url() . "kategorirandom/$key->kategori_id"); ?>"
                                              method="post" id="randomphoto" enctype="multipart/form-data">
                                            <div class="form-layout form-layout-1">
                                                <div class="d-flex flex-column">
                                                    <label>Varsayılan Kategori Fotoğrafı</label>
                                                    <img style="margin-bottom: 10px;" width="150"
                                                         src="<?= base_url($key->kategori_resim_rand) ?>">
                                                </div>
                                                <hr>
                                                <div class="row mg-b-25">
                                                    <div class="col-lg-12" style="margin-top: 29px;">
                                                        <div class="form-group custom-file">
                                                            <input type="file" class="custom-file-input"
                                                                   id="customFile2" name="file"
                                                                   accept=".jpg, .jpeg, .png">
                                                            <label class="custom-file-label custom-file-label-primary"
                                                                   for="customFile2">Random Fotoğrafı <small>(Sadece
                                                                    .jpg/.jpeg/.png - İsteğe Bağlı)</small></label>
                                                        </div>
                                                    </div><!-- col-4 -->
                                                </div>

                                                <div class="form-layout-footer">
                                                    <button type="submit" class="btn btn-info">Kategori Güncelle
                                                    </button>
                                                </div><!-- form-layout-footer -->
                                            </div>
                                        </form><!-- form-layout -->
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button"
                                                class="btn btn-secondary tx-11 tx-uppercase pd-y-12 pd-x-25 tx-mont tx-medium"
                                                data-dismiss="modal">Kapat
                                        </button>
                                    </div>
                                </div>
                            </div><!-- modal-dialog -->
                        </div>
                        <div id="banner_<?= $key->kategori_id ?>" class="modal fade" aria-hidden="true"
                             style="display: none;">
                            <div class="modal-dialog modal-dialog-vertical-center" role="document">
                                <div class="modal-content bd-0 tx-14">
                                    <div class="modal-header pd-y-20 pd-x-25">
                                        <h6 class="tx-14 mg-b-0 tx-uppercase tx-inverse tx-bold">Banner Fotoğraf</h6>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">×</span>
                                        </button>
                                    </div>
                                    <div class="modal-body pd-25">
                                        <form action="<?= base_url(admin_url() . "kategoribanner/$key->kategori_id"); ?>"
                                              method="post" id="randomphoto" enctype="multipart/form-data">
                                            <div class="form-layout form-layout-1">
                                                <div class="d-flex flex-column">
                                                    <label>Varsayılan Kategori Banner Fotoğrafı</label>
                                                    <img style="margin-bottom: 10px;" width="150"
                                                         src="<?= base_url($key->kategori_resim_banner) ?>">
                                                </div>
                                                <hr>
                                                <div class="row mg-b-25">
                                                    <div class="col-lg-12" style="margin-top: 29px;">
                                                        <div class="form-group custom-file">
                                                            <input type="file" class="custom-file-input"
                                                                   id="customFile2" name="file"
                                                                   accept=".jpg, .jpeg, .png">
                                                            <label class="custom-file-label custom-file-label-primary"
                                                                   for="customFile2">Banner Fotoğrafı <small>(Sadece
                                                                    .jpg/.jpeg/.png - İsteğe Bağlı)</small></label>
                                                        </div>
                                                    </div><!-- col-4 -->
                                                </div>

                                                <div class="form-layout-footer">
                                                    <button type="submit" class="btn btn-info">Kategori Güncelle
                                                    </button>
                                                </div><!-- form-layout-footer -->
                                            </div>
                                        </form><!-- form-layout -->
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button"
                                                class="btn btn-secondary tx-11 tx-uppercase pd-y-12 pd-x-25 tx-mont tx-medium"
                                                data-dismiss="modal">Kapat
                                        </button>
                                    </div>
                                </div>
                            </div><!-- modal-dialog -->
                        </div>
                    <?php } ?>
                <?php } ?>
                </tbody>
            </table>
            <hr>
            </div>
            <?php if (1 == 2) { ?>
            <div id="sub-categories" style="display: none" class="city">
            <h4>Alt Kategoriler</h4>
            <table id="datatable1" class="table-responsive table display responsive nowrap">
                <thead>
                <tr>
                    <th class="wd-15p text-center">KATEGORİ ADI</th>
                    <th class="wd-5p text-center">ÜST KATEGORİ</th>
                    <th class="wd-5p text-center">KATEGORİ SIRA</th>
                    <th class="wd-15p text-center">KATEGORİ DURUM</th>
                    <th class="wd-10p text-center">KATEGORİ İŞLEM</th>
                </tr>
                </thead>
                <tbody>
                <?php $kategorilers = kategoriler_yonetims(); ?>
                <?php if ($kategorilers) { ?>
                    <?php foreach ($kategorilers as $keys) { ?>
                        <tr>
                            <td><?= $keys->kategori_ad ?></td>
                            <td class="text-center">
                                <?php if ($keys->parent != 0) { ?>
                                    <div class="badge badge-success"><?= get_kategori($keys->parent)->kategori_ad ?></div>
                                <?php } else { ?>
                                    <div class="badge badge-primary">Üst Kategori Yok</div>
                                <?php } ?>
                            </td>
                            <td class="text-center">
                                <div class="badge badge-success"><?= $keys->kategori_sira ?></div>
                            </td>
                            <td class="text-center">
                                <label class="switch">
                                    <input class="durum"
                                           data-url="<?= base_url(admin_url() . "durum/$keys->kategori_id") ?>"
                                           type="checkbox" <?php if ($keys->kategori_durum == 1) {
                                        echo 'checked';
                                    } ?>>
                                    <span class="slider round"></span>
                                </label>
                            </td>
                            <td class="text-center">
                                <a href="<?= base_url(admin_url() . "kategoriler?stats=$keys->kategori_id") ?>"
                                   class="btn btn-info btn-with-icon">
                                    <div class="ht-40">
                                        <span class="pd-x-15">İstatistik</span>
                                    </div>
                                </a>
                                <?php if ($keys->parent != 0) { ?>
                                    <a href="javascript:void(0)"
                                       class="btn btn-primary tx-11 pd-y-12 pd-x-25 tx-mont tx-medium"
                                       data-toggle="modal" data-target="#random_<?= $keys->kategori_id ?>">
                                        <span class="pd-x-15">Random Fotoğraf</span>
                                    </a>
                                <?php } ?>
                                <a href="javascript:void(0)" data-toggle="modal"
                                   data-target="#banner_<?= $keys->kategori_id ?>"
                                   class="btn btn-dark btn-with-icon">
                                    <div class="ht-40">
                                        <span class="icon fas fa-image wd-40"><i class="fa fa-send"></i></span>
                                        <span class="pd-x-15">Banner</span>
                                    </div>
                                </a>
                                <a href="<?php echo base_url(admin_url() . "kategori-duzenle/$keys->kategori_id"); ?>"
                                   class="btn btn-warning btn-with-icon">
                                    <div class="ht-40">
                                        <span class="icon fas fa-edit wd-40"><i class="fa fa-send"></i></span>
                                        <span class="pd-x-15">Düzenle</span>
                                    </div>
                                </a>
                                <a href="javascript:void(0)"
                                   data-url="<?= base_url(admin_url() . "kategorisil/$keys->kategori_id") ?>"
                                   class="btn btn-danger btn-with-icon remove-btn">
                                    <div class="ht-40">
                                        <span class="icon far fa-trash-alt wd-40"><i class="fa fa-send"></i></span>
                                        <span class="pd-x-15">Sil</span>
                                    </div>
                                </a>
                            </td>
                        </tr>
                        <div id="random_<?= $keys->kategori_id ?>" class="modal fade" aria-hidden="true"
                             style="display: none;">
                            <div class="modal-dialog modal-dialog-vertical-center" role="document">
                                <div class="modal-content bd-0 tx-14">
                                    <div class="modal-header pd-y-20 pd-x-25">
                                        <h6 class="tx-14 mg-b-0 tx-uppercase tx-inverse tx-bold">Random Fotoğraf</h6>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">×</span>
                                        </button>
                                    </div>
                                    <div class="modal-body pd-25">
                                        <form action="<?= base_url(admin_url() . "kategorirandom/$keys->kategori_id"); ?>"
                                              method="post" id="randomphoto" enctype="multipart/form-data">
                                            <div class="form-layout form-layout-1">
                                                <div class="d-flex flex-column">
                                                    <label>Varsayılan Kategori Fotoğrafı</label>
                                                    <img style="margin-bottom: 10px;" width="150"
                                                         src="<?= base_url($keys->kategori_resim_rand) ?>">
                                                </div>
                                                <hr>
                                                <div class="row mg-b-25">
                                                    <div class="col-lg-12" style="margin-top: 29px;">
                                                        <div class="form-group custom-file">
                                                            <input type="file" class="custom-file-input"
                                                                   id="customFile2" name="file"
                                                                   accept=".jpg, .jpeg, .png">
                                                            <label class="custom-file-label custom-file-label-primary"
                                                                   for="customFile2">Random Fotoğrafı <small>(Sadece
                                                                    .jpg/.jpeg/.png - İsteğe Bağlı)</small></label>
                                                        </div>
                                                    </div><!-- col-4 -->
                                                </div>

                                                <div class="form-layout-footer">
                                                    <button type="submit" class="btn btn-info">Kategori Güncelle
                                                    </button>
                                                </div><!-- form-layout-footer -->
                                            </div>
                                        </form><!-- form-layout -->
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button"
                                                class="btn btn-secondary tx-11 tx-uppercase pd-y-12 pd-x-25 tx-mont tx-medium"
                                                data-dismiss="modal">Kapat
                                        </button>
                                    </div>
                                </div>
                            </div><!-- modal-dialog -->
                        </div>
                        <div id="banner_<?= $keys->kategori_id ?>" class="modal fade" aria-hidden="true"
                             style="display: none;">
                            <div class="modal-dialog modal-dialog-vertical-center" role="document">
                                <div class="modal-content bd-0 tx-14">
                                    <div class="modal-header pd-y-20 pd-x-25">
                                        <h6 class="tx-14 mg-b-0 tx-uppercase tx-inverse tx-bold">Banner Fotoğraf</h6>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">×</span>
                                        </button>
                                    </div>
                                    <div class="modal-body pd-25">
                                        <form action="<?= base_url(admin_url() . "kategoribanner/$keys->kategori_id"); ?>"
                                              method="post" id="randomphoto" enctype="multipart/form-data">
                                            <div class="form-layout form-layout-1">
                                                <div class="d-flex flex-column">
                                                    <label>Varsayılan Kategori Banner Fotoğrafı</label>
                                                    <img style="margin-bottom: 10px;" width="150"
                                                         src="<?= base_url($keys->kategori_resim_banner) ?>">
                                                </div>
                                                <hr>
                                                <div class="row mg-b-25">
                                                    <div class="col-lg-12" style="margin-top: 29px;">
                                                        <div class="form-group custom-file">
                                                            <input type="file" class="custom-file-input"
                                                                   id="customFile2" name="file"
                                                                   accept=".jpg, .jpeg, .png">
                                                            <label class="custom-file-label custom-file-label-primary"
                                                                   for="customFile2">Banner Fotoğrafı <small>(Sadece
                                                                    .jpg/.jpeg/.png - İsteğe Bağlı)</small></label>
                                                        </div>
                                                    </div><!-- col-4 -->
                                                </div>

                                                <div class="form-layout-footer">
                                                    <button type="submit" class="btn btn-info">Kategori Güncelle
                                                    </button>
                                                </div><!-- form-layout-footer -->
                                            </div>
                                        </form><!-- form-layout -->
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button"
                                                class="btn btn-secondary tx-11 tx-uppercase pd-y-12 pd-x-25 tx-mont tx-medium"
                                                data-dismiss="modal">Kapat
                                        </button>
                                    </div>
                                </div>
                            </div><!-- modal-dialog -->
                        </div>
                    <?php } ?>
                <?php } ?>
                </tbody>
            </table>
            <hr>
            </div>
            <?php } ?>
        </div><?php } ?><!-- table-wrapper -->
    </div><!-- br-section-wrapper -->
</div><!-- br-pagebody -->