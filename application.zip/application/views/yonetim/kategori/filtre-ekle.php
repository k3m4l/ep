<div class="br-pageheader">
    <nav class="breadcrumb pd-0 mg-0 tx-12">
        <a class="breadcrumb-item" href="<?=base_url(admin_url())?>">Kontrol Paneli</a>
        <a class="breadcrumb-item" href="kategoriler">Kategoriler</a>
        <span class="breadcrumb-item active">Filtre Ekle</span>
    </nav>
</div><!-- br-pageheader -->
<div class="br-pagetitle">
    <i class="fas fa-grip-horizontal fa-4x"></i>
    <div>
        <h4>Yeni Filtre Ekle</h4>
        <p class="mg-b-0">Yeni Filtre Ekleyebilirsiniz.</p>
    </div>
</div><!-- d-flex -->

<div class="br-pagebody">
    <div class="br-section-wrapper">
        <form action="<?=base_url(admin_url()."filtreekle"); ?>" method="post" enctype="multipart/form-data">
            <input type="hidden" name="kategori" value="<?php echo $alt_kategori->kategori_id ?>">
            <div class="form-layout form-layout-1">
                <div class="row mg-b-25">
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label class="form-control-label">Filtre Adı <span class="tx-danger">*</span></label>
                            <input class="form-control" type="text" name="ad" placeholder="Filtre Adı">
                            <?php if (isset($form_error)) { ?> <code class="pull-right"><?=form_error('ad')?></code><?php } ?>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label class="form-control-label">Filtre Sıra</label>
                            <input class="form-control" type="number" name="sira" placeholder="Filtre Sıralama">
                        </div>
                    </div>
                    <div class="col-lg-12" style="margin-top: 29px;">
                        <div class="form-group custom-file">
                            <input type="file" class="custom-file-input" id="customFile2" name="file" accept=".jpg, .jpeg, .png">
                            <label class="custom-file-label custom-file-label-primary" for="customFile2">Filtre Fotoğrafı <small>(Sadece .jpg/.jpeg/.png - İsteğe Bağlı)</small></label>
                        </div>
                    </div><!-- col-4 -->
                </div>

                <div class="form-layout-footer">
                    <button type="submit" class="btn btn-info">Filtre Ekle</button>
                </div><!-- form-layout-footer -->
            </div>
        </form><!-- form-layout -->
    </div>
</div>