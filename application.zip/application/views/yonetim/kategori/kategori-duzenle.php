<div class="br-pageheader">
	<nav class="breadcrumb pd-0 mg-0 tx-12">
		<a class="breadcrumb-item" href="<?=base_url(admin_url())?>">Kontrol Paneli</a>
		<a class="breadcrumb-item" href="<?=base_url(admin_url().'kategoriler')?>">Kategoriler</a>
		<span class="breadcrumb-item active"><?=$where->kategori_ad?> - Düzenle</span>
	</nav>
</div><!-- br-pageheader -->
<div class="br-pagetitle">
	<i class="fas fa-grip-horizontal fa-4x"></i>
	<div>
		<h4><?=$where->kategori_ad?> - Düzenle</h4>
		<p class="mg-b-0">Kategori ayarlarını güncelleyebilirsiniz.</p>
	</div>
</div><!-- d-flex -->

<div class="br-pagebody">
	<div class="br-section-wrapper">
		<form action="<?=base_url(admin_url()."kategoriduzenle/$where->kategori_id"); ?>" method="post" enctype="multipart/form-data">
			<div class="form-layout form-layout-1">
                <div class="d-flex flex-column">
                    <label>Varsayılan Kategori Fotoğrafı</label>
                    <img style="margin-bottom: 10px;" width="80" src="<?=base_url($where->kategori_resim)?>">
                </div>

                <hr>
				<div class="row mg-b-25">
					<div class="col-lg-6">
						<div class="form-group">
							<label class="form-control-label">Kategori Adı <span class="tx-danger">*</span></label>
							<input class="form-control" type="text" name="ad" placeholder="Kategori Adı" value="<?=$where->kategori_ad?>">
							<?php if (isset($form_error)) { ?> <code class="pull-right"><?=form_error('ad')?></code><?php } ?>
						</div>
					</div>
					<div class="col-lg-6">
						<div class="form-group">
							<label class="form-control-label">Kategori Seo Url <small><code>Boş Bırakırsanız Otomatik Oluşturur</code></small></label>
							<input class="form-control" type="text" name="seo" placeholder="Kategori Seo Url" value="<?=$where->kategori_seo?>">
						</div>
					</div>
                    <div class="col-lg-12" style="margin-top: 29px;">
                        <div class="form-group custom-file">
                            <input type="file" class="custom-file-input" id="customFile2" name="file" accept=".jpg, .jpeg, .png">
                            <label class="custom-file-label custom-file-label-primary" for="customFile2">Kategori Fotoğrafı <small>(Sadece .jpg/.jpeg/.png - İsteğe Bağlı)</small></label>
                        </div>
                    </div><!-- col-4 -->

                        <div class="col-md-10">
                            <div class="form-group">
                                <div action="<?php echo base_url('image/Add_images/add_image'); ?>" class="dropzone dropzone-area" id="dpz-single-files">
                                    <div class="dz-message">
                                        <span class="m-dropzone__msg-desc">
                                            Bir Adet Logo Resim Yükleyiniz.
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <label for="">Yüklü Resim</label>
                            <br>
                            <img style="margin-bottom: 10px;" width="100" src="<?=base_url($where->kategori_logo_resim)?>">
                        </div>

                    <div class="col-lg-6 <?php echo $where->parent == 0 ? 'd-none' : '' ?>">
                        <div class="form-group">
                            <label class="form-control-label">Komisyon Oran</label>
                            <input class="form-control" type="text" pattern="[0-9.]*" name="komisyon" value="<?=$where->komisyon?>" placeholder="Komisyon Oranı">
                        </div>
                    </div>
                    <div class="col-lg-6 <?php echo $where->parent == 0 ? 'd-none' : '' ?>">
                        <div class="form-group mg-b-10-force">
                            <label class="form-control-label">Üst Kategori <span class="tx-danger">*</span></label>
                            <select class="form-control" name="parent">
                                <option <?php if ($where->parent==0) { echo 'selected'; } ?> value="0">Üst Kategori Yok</option>
                                <?php foreach (kategoriler() as $kat) { ?>
                                    <option <?php if ($where->parent==$kat->kategori_id) { echo 'selected'; } ?> value="<?php echo $kat->kategori_id; ?>"><?php echo $kat->kategori_ad; ?></option>
                                <?php } ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-lg-6 <?php echo $where->parent == 0 ? 'd-none' : '' ?>">
                        <div class="form-group">
                            <label class="form-control-label">Komisyon Verilecek Kullanici</label>
                            <select name="komisyon_kullanici_id" class="form-control" id="">
                                <option value="">Kullanici Seçiniz...</option>
                                <?php foreach (!empty($users) ? $users : [] as $key => $val) { ?>
                                    <option value="<?php echo $val->kullanici_id ?>"><?php echo $val->kullanici_ad ?></option>
                                <?php } ?>
                            </select>
                        </div>
                    </div>


					<div class="col-lg-6">
						<div class="form-group">
							<label class="form-control-label">Kategori Sıra</label>
							<input class="form-control" type="number" name="sira" placeholder="Kategori Sıralama" value="<?=$where->kategori_sira?>">
						</div>
					</div>
					<div class="col-lg-6">
						<div class="form-group mg-b-10-force">
							<label class="form-control-label">Kategori Durum <span class="tx-danger">*</span></label>
							<select class="form-control" name="durum">
								<option <?php if ($where->kategori_durum==1) { echo 'selected'; } ?> value="1">Aktif</option>
								<option <?php if ($where->kategori_durum==0) { echo 'selected'; } ?> value="0">Pasif</option>
							</select>
						</div>
					</div>
                    <div class="col-lg-6">
                        <div class="form-group mg-b-10-force">
                            <label class="form-control-label">Kategori Popüler <span class="tx-danger">*</span></label>
                            <select class="form-control" name="populer">
                                <option <?php if ($where->kategori_populer=="1") { echo 'selected'; } ?> value="1">Aktif</option>
                                <option <?php if ($where->kategori_populer=="0") { echo 'selected'; } ?> value="0">Pasif</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group mg-b-10-force">
                            <label class="form-control-label">Kategori Türü <span class="tx-danger">*</span></label>
                            <select class="form-control" name="kategori_tur" id="kategori_tur">
                                <option <?php if ($where->kategori_tur=="0") { echo 'selected'; } ?> value="0">Ürün Kategorisi</option>
                                <option <?php if ($where->kategori_tur=="1") { echo 'selected'; } ?> value="1">İlan Kategorisi</option>
                                <option <?php if ($where->kategori_tur=="2") { echo 'selected'; } ?> value="2">Gold Alım & Satım Kategorisi</option>
                            </select>
                        </div>
                    </div>
                    <script>
                        // Document hazır olduğunda JQuery kullanarak işlemleri gerçekleştirin
                        $(document).ready(function(){
                            // Kategor_tur select elementini seçin
                            var kategorTurSelect = $('#kategori_tur');

                            // Değer değişikliği olduğunda tetiklenen olayı dinleyin
                            kategorTurSelect.change(function(){
                                // Seçilen değeri alın
                                var selectedValue = $(this).val();

                                // Eğer seçilen değer 1 ise istenen alanı gizle (d-none sınıfını ekle)
                                if(selectedValue === '1'){
                                    $('.ust-baslik').addClass('d-none');
                                    $('.ust-baslik-alt-yazi').addClass('d-none');
                                    $('.nasil-kullanilir').addClass('d-none');
                                } else {
                                    // Değilse gizli sınıfı kaldırın
                                    $('.ust-baslik').removeClass('d-none');
                                    $('.ust-baslik-alt-yazi').removeClass('d-none');
                                    $('.nasil-kullanilir').removeClass('d-none');
                                }
                            });
                        });
                    </script>

					<div class="col-lg-4">
						<div class="form-group">
							<label class="form-control-label">Kategori Seo Başlık <br><small><code>Boş Bırakırsanız Varsayılan Başlık Görünür</code></small></label>
							<input class="form-control" type="text" name="title" placeholder="Kategori Seo Başlık" value="<?=$where->kategori_title?>">
						</div>
					</div>
					<div class="col-lg-4">
						<div class="form-group">
							<label class="form-control-label">Kategori Seo Açıklama <br><small><code>Boş Bırakırsanız Varsayılan Açıklama Görünür</code></small></label>
							<input class="form-control" type="text" name="desc" placeholder="Kategori Seo Açıklama" value="<?=$where->kategori_desc?>">
						</div>
					</div>
					<div class="col-lg-4">
						<div class="form-group">
							<label class="form-control-label">Kategori Seo Anahtar Kelime <br><small><code>Boş Bırakırsanız Varsayılan Anahtar Kelime Görünür</code></small></label>
                            <?php if (1 == 2){ ?>
							<input class="form-control" type="text" name="keyw" placeholder="Kategori Anahtar Kelime" value="<?=$where->kategori_keyw?>">
                            <?php } ?>
                            <!--<jsuites-tags value="<?= $where->kategori_keyw ?>" id="tags"></jsuites-tags>
                            <input type="hidden" name="keyw" value="<?= $where->kategori_keyw; ?>">-->
                            <input name="keyw" value="<?= $where->kategori_keyw; ?>" autofocus>
                        </div>
                        <script>
                            // The DOM element you wish to replace with Tagify
                            var input = document.querySelector('input[name="keyw"]');

                            // initialize Tagify on the above input node reference
                            new Tagify(input)
                        </script>
                        <!--<script>
                            document.querySelector('jsuites-tags').addEventListener('onchange', function() {
                                $('input[name="keyw"]').val(this.value);
                            });
                        </script>-->
					</div>
                    <?php if ($where->parent > 0) { ?>
                    <div class="col-lg-6 ust-baslik <?php echo $where->kategori_tur == 1 ? 'd-none' : '' ?>">
                        <div class="form-group">
                            <label class="form-control-label">Üst Başlık</label>
                            <input class="form-control" type="text" name="ust_baslik" placeholder="Üst Başlık" value="<?= $where->ust_baslik; ?>">
                        </div>
                    </div>
                    <div class="col-lg-6 ust-baslik-alt-yazi <?php echo $where->kategori_tur == 1 ? 'd-none' : '' ?>">
                        <div class="form-group">
                            <label class="form-control-label">Üst Başlık Alt Yazı</label>
                            <input class="form-control" type="text" name="ust_baslik_altyazi" placeholder="Üst Başlık Alt Yazı" value="<?= $where->ust_baslik_altyazi; ?>">
                        </div>
                    </div>
					<div class="col-12">
						<div class="form-group">
							<label class="form-control-label">Kategori Açıklaması</label>
							<textarea name="aciklama" class="ckeditor" cols="30" rows="10"><?= $where->aciklama ?></textarea>
						</div>
					</div>
					<div class="col-12 nasil-kullanilir">
						<div class="form-group">
							<label class="form-control-label">Nasıl Kullanılır ?</label>
							<textarea name="nasil_kullanilir" class="ckeditor" cols="30" rows="10"><?= $where->nasil_kullanilir ?></textarea>
						</div>
					</div>
                    <?php } ?>
				</div>

				<div class="form-layout-footer">
					<button type="submit" class="btn btn-info">Kategori Güncelle</button>
				</div><!-- form-layout-footer -->
			</div>
		</form><!-- form-layout -->
	</div>
</div>