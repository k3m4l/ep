<div class="br-pageheader">
    <nav class="breadcrumb pd-0 mg-0 tx-12">
        <a class="breadcrumb-item" href="<?= base_url(admin_url()) ?>">Kontrol Paneli</a>
        <span class="breadcrumb-item active"><?php echo $filtre->filtre_adi ?> Alt Filtreler</span>
    </nav>
</div><!-- br-pageheader -->
<div class="br-pagetitle">
    <i class="fas fa-grip-horizontal fa-4x"></i>
    <div>
        <h4>Filtreler</h4>
        <p class="mg-b-0"><?php echo $filtre->filtre_adi ?> Alt Filtreler</p>
    </div>
</div><!-- d-flex -->
<div class="br-pagebody">
    <div class="br-section-wrapper">
        <div class="table-wrapper">
            <div id="sub-categories" class="city">
                <h4>
                    <?php echo $filtre->filtre_adi ?> Alt Filtreler
                    <a href="<?php echo base_url(admin_url() . "kategori-alt-filtre-ekle/$alt_kategori->kategori_id/$filtre->filtre_id"); ?>" style="float:right;margin-bottom:5px"
                       class="btn btn-warning btn-with-icon">
                        <div class="ht-40">
                            <span class="pd-x-15">Alt Filtre Ekle</span>
                        </div>
                    </a>
                </h4>

                <table id="datatable1" class="table-responsive table display responsive nowrap">
                    <thead>
                    <tr>
                        <th class="wd-15p text-center">FİLTRE ADI</th>
                        <th class="wd-15p text-center">FİLTRE DURUM</th>
                        <th class="wd-10p text-center">FİLTRE İŞLEM</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php if ($filtreler) { ?>
                        <?php foreach ($filtreler as $keys) { ?>
                            <tr>
                                <td class="text-center"><?= $keys->filtre_adi ?></td>
                                <td class="text-center">
                                    <label class="switch">
                                        <input class="durum"
                                               data-url="<?= base_url(admin_url() . "filtre-durum/$keys->filtre_id") ?>"
                                               type="checkbox" <?php if ($keys->filtre_durum == 1) {
                                            echo 'checked';
                                        } ?>>
                                        <span class="slider round"></span>
                                    </label>
                                </td>
                                <td class="text-center">
                                    <?php if ($keys->type == 1) { ?>
                                    <a href="<?= base_url(admin_url() . "filtre-ozellikler/$keys->kategori_id/$keys->filtre_id") ?>"
                                       class="btn btn-primary btn-with-icon">
                                        <div class="ht-40">
                                            <span class="pd-x-15">Özellikler</span>
                                        </div>
                                    </a>
                                    <?php } ?>
                                    <a href="<?php echo base_url(admin_url() . "kategori-filtre-duzenle/$keys->filtre_id"); ?>"
                                       class="btn btn-warning btn-with-icon">
                                        <div class="ht-40">
                                            <span class="icon fas fa-edit wd-40"><i class="fa fa-send"></i></span>
                                            <span class="pd-x-15">Düzenle</span>
                                        </div>
                                    </a>
                                    <a href="javascript:void(0)"
                                       data-url="<?= base_url(admin_url() . "kategorifiltresil/$keys->filtre_id") ?>"
                                       class="btn btn-danger btn-with-icon remove-btn">
                                        <div class="ht-40">
                                            <span class="icon far fa-trash-alt wd-40"><i class="fa fa-send"></i></span>
                                            <span class="pd-x-15">Sil</span>
                                        </div>
                                    </a>
                                </td>
                            </tr>
                        <?php } ?>
                    <?php } ?>
                    </tbody>
                </table>
                <hr>
            </div>
        </div><!-- table-wrapper -->
    </div><!-- br-section-wrapper -->
</div><!-- br-pagebody -->