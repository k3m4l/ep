<div class="br-pageheader">
    <nav class="breadcrumb pd-0 mg-0 tx-12">
        <a class="breadcrumb-item" href="<?=base_url(admin_url())?>">Kontrol Paneli</a>
        <a class="breadcrumb-item" href="<?=base_url(admin_url().'kategoriler')?>">Kategoriler</a>
        <span class="breadcrumb-item active"><?=$where->filtre_adi?> - Düzenle</span>
    </nav>
</div><!-- br-pageheader -->
<div class="br-pagetitle">
    <i class="fas fa-grip-horizontal fa-4x"></i>
    <div>
        <h4><?=$where->filtre_adi?> - Düzenle</h4>
        <p class="mg-b-0">Filtre ayarlarını güncelleyebilirsiniz.</p>
    </div>
</div><!-- d-flex -->

<div class="br-pagebody">
    <div class="br-section-wrapper">
        <form action="<?=base_url(admin_url()."kategorifiltreduzenle/$where->filtre_id"); ?>" method="post" enctype="multipart/form-data">
            <div class="form-layout form-layout-1">
                <?php if ($where->sub_filter == 0) { ?>
                <div class="d-flex flex-column">
                    <label>Varsayılan Filtre Fotoğrafı</label>
                    <img style="margin-bottom: 10px;" width="80" src="<?=base_url($where->filtre_resim)?>">
                </div>
                <hr>
                <?php } ?>
                <div class="row mg-b-25">
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label class="form-control-label">Filtre Adı <span class="tx-danger">*</span></label>
                            <input class="form-control" type="text" name="ad" placeholder="Filtre Adı" value="<?=$where->filtre_adi?>">
                            <?php if (isset($form_error)) { ?> <code class="pull-right"><?=form_error('ad')?></code><?php } ?>
                        </div>
                    </div>
                    <?php if ($where->sub_filter == 0) { ?>
                    <div class="col-lg-6" style="margin-top: 29px;">
                        <div class="form-group custom-file">
                            <input type="file" class="custom-file-input" id="customFile2" name="file" accept=".jpg, .jpeg, .png">
                            <label class="custom-file-label custom-file-label-primary" for="customFile2">Filtre Fotoğrafı <small>(Sadece .jpg/.jpeg/.png - İsteğe Bağlı)</small></label>
                        </div>
                    </div><!-- col-4 -->
                    <?php } ?>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label class="form-control-label">Filtre Sıra</label>
                            <input class="form-control" type="number" name="sira" placeholder="Filtre Sıralama" value="<?=$where->filtre_sira?>">
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group mg-b-10-force">
                            <label class="form-control-label">Filtre Durum <span class="tx-danger">*</span></label>
                            <select class="form-control" name="durum">
                                <option <?php if ($where->filtre_durum==1) { echo 'selected'; } ?> value="1">Aktif</option>
                                <option <?php if ($where->filtre_durum==0) { echo 'selected'; } ?> value="0">Pasif</option>
                            </select>
                        </div>
                    </div>


                </div>

                <div class="form-layout-footer">
                    <button type="submit" class="btn btn-info">Filtre Güncelle</button>
                </div><!-- form-layout-footer -->
            </div>
        </form><!-- form-layout -->
    </div>
</div>