<div class="br-pageheader">
    <nav class="breadcrumb pd-0 mg-0 tx-12">
        <a class="breadcrumb-item" href="<?=base_url(admin_url())?>">Kontrol Paneli</a>
        <a class="breadcrumb-item" href="kategoriler">Kategoriler</a>
        <span class="breadcrumb-item active">Alt Filtre Ekle</span>
    </nav>
</div><!-- br-pageheader -->
<div class="br-pagetitle">
    <i class="fas fa-grip-horizontal fa-4x"></i>
    <div>
        <h4>Yeni Alt Filtre Ekle</h4>
        <p class="mg-b-0">Yeni Alt Filtre Ekleyebilirsiniz.</p>
    </div>
</div><!-- d-flex -->

<div class="br-pagebody">
    <div class="br-section-wrapper">
        <form action="<?=base_url(admin_url()."altfiltreekle"); ?>" method="post" enctype="multipart/form-data">
            <input type="hidden" name="kategori" value="<?php echo $alt_kategori->kategori_id ?>">
            <input type="hidden" name="filtre" value="<?php echo $filtre->filtre_id ?>">
            <div class="form-layout form-layout-1">
                <div class="row mg-b-25">
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label class="form-control-label">Filtre Adı <span class="tx-danger">*</span></label>
                            <input class="form-control" type="text" name="ad" placeholder="Filtre Adı">
                            <?php if (isset($form_error)) { ?> <code class="pull-right"><?=form_error('ad')?></code><?php } ?>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label class="form-control-label">Filtre Sıra</label>
                            <input class="form-control" type="number" name="sira" placeholder="Filtre Sıralama">
                        </div>
                    </div>
                    <div class="col-lg-12">
                        <div class="form-group custom-file">
                            <select name="type" id="" class="form-control">
                                <option value="">Lütfen Filtre Tipini Seçiniz</option>
                                <option value="1">Select (Seçilebilir Seçenekli)</option>
                                <option value="2">İnput (Yazı Şeklinde Arama)</option>
                            </select>
                        </div>
                    </div><!-- col-4 -->
                </div>

                <div class="form-layout-footer">
                    <button type="submit" class="btn btn-info">Alt Filtre Ekle</button>
                </div><!-- form-layout-footer -->
            </div>
        </form><!-- form-layout -->
    </div>
</div>