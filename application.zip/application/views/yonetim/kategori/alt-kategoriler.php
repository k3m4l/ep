<div class="br-pageheader">
    <nav class="breadcrumb pd-0 mg-0 tx-12">
        <a class="breadcrumb-item" href="<?= base_url(admin_url()) ?>">Kontrol Paneli</a>
        <span class="breadcrumb-item active">Alt Kategoriler</span>
    </nav>
</div><!-- br-pageheader -->
<div class="br-pagetitle">
    <i class="fas fa-grip-horizontal fa-4x"></i>
    <div>
        <h4>Alt Kategoriler</h4>
        <p class="mg-b-0">Alt Kategorileri</p>
    </div>
</div><!-- d-flex -->
<div class="br-pagebody">
    <div class="br-section-wrapper">
        <div class="row justify-content-end mb-3">
            <a href="<?= base_url(admin_url()."alt-kategoriler") ?>" class="btn btn-warning btn-sm">Tüm Alt Kategoriler</a>
            <a href="<?= base_url(admin_url()."alt-kategoriler?type=ürün") ?>" class="btn btn-success btn-sm ml-2">Ürün Kategorileri</a>
            <a href="<?= base_url(admin_url()."alt-kategoriler?type=ilan") ?>" class="btn btn-success btn-sm ml-2">İlan Kategorileri</a>
            <a href="<?= base_url(admin_url()."alt-kategoriler?type=gold") ?>" class="btn btn-success btn-sm ml-2">Gold Alım & Satım Kategorileri</a>
        </div>
        <div class="table-wrapper">
            <div id="sub-categories" class="city">
                <h4>Alt Kategoriler</h4>
                <table id="datatable1" class="table-responsive table display responsive nowrap">
                    <thead>
                    <tr>
                        <th class="wd-5p text-center">KATEGORİ SIRA</th>
                        <th class="wd-15p text-center">KATEGORİ ADI</th>
                        <th class="wd-5p text-center">ÜST KATEGORİ</th>
                        <th class="wd-5p text-center">KATEGORİ TÜRÜ</th>
                        <th class="wd-15p text-center">KATEGORİ DURUM</th>
                        <th class="wd-10p text-center">KATEGORİ İŞLEM</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php if ($kategoriler) { ?>
                        <?php foreach ($kategoriler as $keys) { ?>
                            <tr>
                                <td class="text-center">
                                    <div class="badge badge-success"><?= $keys->kategori_sira ?></div>
                                </td>
                                <td><?= $keys->kategori_ad ?></td>
                                <td class="text-center">
                                    <?php if ($keys->parent != 0) { ?>
                                        <div class="badge badge-success"><?= get_kategori($keys->parent)->kategori_ad ?></div>
                                    <?php } else { ?>
                                        <div class="badge badge-primary">Üst Kategori Yok</div>
                                    <?php } ?>
                                </td>
                                <td class="text-center">
                                    <?php if ($keys->kategori_tur == 0) { ?>
                                        <div class="badge badge-info">Ürün Kategorisi</div>
                                    <?php } else if ($keys->kategori_tur == 1) { ?>
                                        <div class="badge badge-info">İlan Kategorisi</div>
                                    <?php } else if ($keys->kategori_tur == 2) { ?>
                                        <div class="badge badge-info">Gold Alım & Satım Kategorisi</div>

                                    <?php } ?>
                                </td>
                                <td class="text-center">
                                    <label class="switch">
                                        <input class="durum"
                                               data-url="<?= base_url(admin_url() . "durum/$keys->kategori_id") ?>"
                                               type="checkbox" <?php if ($keys->kategori_durum == 1) {
                                            echo 'checked';
                                        } ?>>
                                        <span class="slider round"></span>
                                    </label>
                                </td>
                                <td class="text-center">
                                    <?php if ($keys->kategori_tur == 1) { ?>
                                    <a href="<?= base_url(admin_url() . "kategori-filtre/$keys->kategori_id") ?>"
                                       class="btn btn-dark btn-with-icon">
                                        <div class="ht-40">
                                            <span class="pd-x-15">Filtreler</span>
                                        </div>
                                    </a>
                                    <?php } ?>
                                    <a href="<?= base_url(admin_url() . "kategoriler?stats=$keys->kategori_id") ?>"
                                       class="btn btn-info btn-with-icon">
                                        <div class="ht-40">
                                            <span class="pd-x-15">İstatistik</span>
                                        </div>
                                    </a>
                                    <?php if (1 == 2) { ?>
                                        <?php if ($keys->parent != 0) { ?>
                                            <a href="javascript:void(0)"
                                               class="btn btn-primary tx-11 pd-y-12 pd-x-25 tx-mont tx-medium"
                                               data-toggle="modal" data-target="#random_<?= $keys->kategori_id ?>">
                                                <span class="pd-x-15">Random Fotoğraf</span>
                                            </a>
                                        <?php } ?>
                                        <a href="javascript:void(0)" data-toggle="modal"
                                           data-target="#banner_<?= $keys->kategori_id ?>"
                                           class="btn btn-dark btn-with-icon">
                                            <div class="ht-40">
                                                <span class="icon fas fa-image wd-40"><i class="fa fa-send"></i></span>
                                                <span class="pd-x-15">Banner</span>
                                            </div>
                                        </a>
                                    <?php } ?>
                                    <a href="<?php echo base_url(admin_url() . "kategori-duzenle/$keys->kategori_id"); ?>"
                                       class="btn btn-warning btn-with-icon">
                                        <div class="ht-40">
                                            <span class="icon fas fa-edit wd-40"><i class="fa fa-send"></i></span>
                                            <span class="pd-x-15">Düzenle</span>
                                        </div>
                                    </a>
                                    <a href="javascript:void(0)"
                                       data-url="<?= base_url(admin_url() . "kategorisil/$keys->kategori_id") ?>"
                                       class="btn btn-danger btn-with-icon remove-btn">
                                        <div class="ht-40">
                                            <span class="icon far fa-trash-alt wd-40"><i class="fa fa-send"></i></span>
                                            <span class="pd-x-15">Sil</span>
                                        </div>
                                    </a>
                                </td>
                            </tr>
                            <div id="random_<?= $keys->kategori_id ?>" class="modal fade" aria-hidden="true"
                                 style="display: none;">
                                <div class="modal-dialog modal-dialog-vertical-center" role="document">
                                    <div class="modal-content bd-0 tx-14">
                                        <div class="modal-header pd-y-20 pd-x-25">
                                            <h6 class="tx-14 mg-b-0 tx-uppercase tx-inverse tx-bold">Random Fotoğraf</h6>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">×</span>
                                            </button>
                                        </div>
                                        <div class="modal-body pd-25">
                                            <form action="<?= base_url(admin_url() . "kategorirandom/$keys->kategori_id"); ?>"
                                                  method="post" id="randomphoto" enctype="multipart/form-data">
                                                <div class="form-layout form-layout-1">
                                                    <div class="d-flex flex-column">
                                                        <label>Varsayılan Kategori Fotoğrafı</label>
                                                        <img style="margin-bottom: 10px;" width="150"
                                                             src="<?= base_url($keys->kategori_resim_rand) ?>">
                                                    </div>
                                                    <hr>
                                                    <div class="row mg-b-25">
                                                        <div class="col-lg-12" style="margin-top: 29px;">
                                                            <div class="form-group custom-file">
                                                                <input type="file" class="custom-file-input"
                                                                       id="customFile2" name="file"
                                                                       accept=".jpg, .jpeg, .png">
                                                                <label class="custom-file-label custom-file-label-primary"
                                                                       for="customFile2">Random Fotoğrafı <small>(Sadece
                                                                        .jpg/.jpeg/.png - İsteğe Bağlı)</small></label>
                                                            </div>
                                                        </div><!-- col-4 -->
                                                    </div>

                                                    <div class="form-layout-footer">
                                                        <button type="submit" class="btn btn-info">Kategori Güncelle
                                                        </button>
                                                    </div><!-- form-layout-footer -->
                                                </div>
                                            </form><!-- form-layout -->
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button"
                                                    class="btn btn-secondary tx-11 tx-uppercase pd-y-12 pd-x-25 tx-mont tx-medium"
                                                    data-dismiss="modal">Kapat
                                            </button>
                                        </div>
                                    </div>
                                </div><!-- modal-dialog -->
                            </div>
                            <div id="banner_<?= $keys->kategori_id ?>" class="modal fade" aria-hidden="true"
                                 style="display: none;">
                                <div class="modal-dialog modal-dialog-vertical-center" role="document">
                                    <div class="modal-content bd-0 tx-14">
                                        <div class="modal-header pd-y-20 pd-x-25">
                                            <h6 class="tx-14 mg-b-0 tx-uppercase tx-inverse tx-bold">Banner Fotoğraf</h6>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">×</span>
                                            </button>
                                        </div>
                                        <div class="modal-body pd-25">
                                            <form action="<?= base_url(admin_url() . "kategoribanner/$keys->kategori_id"); ?>"
                                                  method="post" id="randomphoto" enctype="multipart/form-data">
                                                <div class="form-layout form-layout-1">
                                                    <div class="d-flex flex-column">
                                                        <label>Varsayılan Kategori Banner Fotoğrafı</label>
                                                        <img style="margin-bottom: 10px;" width="150"
                                                             src="<?= base_url($keys->kategori_resim_banner) ?>">
                                                    </div>
                                                    <hr>
                                                    <div class="row mg-b-25">
                                                        <div class="col-lg-12" style="margin-top: 29px;">
                                                            <div class="form-group custom-file">
                                                                <input type="file" class="custom-file-input"
                                                                       id="customFile2" name="file"
                                                                       accept=".jpg, .jpeg, .png">
                                                                <label class="custom-file-label custom-file-label-primary"
                                                                       for="customFile2">Banner Fotoğrafı <small>(Sadece
                                                                        .jpg/.jpeg/.png - İsteğe Bağlı)</small></label>
                                                            </div>
                                                        </div><!-- col-4 -->
                                                    </div>

                                                    <div class="form-layout-footer">
                                                        <button type="submit" class="btn btn-info">Kategori Güncelle
                                                        </button>
                                                    </div><!-- form-layout-footer -->
                                                </div>
                                            </form><!-- form-layout -->
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button"
                                                    class="btn btn-secondary tx-11 tx-uppercase pd-y-12 pd-x-25 tx-mont tx-medium"
                                                    data-dismiss="modal">Kapat
                                            </button>
                                        </div>
                                    </div>
                                </div><!-- modal-dialog -->
                            </div>
                        <?php } ?>
                    <?php } ?>
                    </tbody>
                </table>
                <hr>
            </div>
        </div><!-- table-wrapper -->
    </div><!-- br-section-wrapper -->
</div><!-- br-pagebody -->