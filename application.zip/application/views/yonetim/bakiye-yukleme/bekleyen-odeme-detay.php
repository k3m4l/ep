<div class="br-pageheader">
    <nav class="breadcrumb pd-0 mg-0 tx-12">
        <a class="breadcrumb-item" href="<?= base_url(admin_url()) ?>">Kontrol Paneli</a>
        <a class="breadcrumb-item" href="<?= base_url(admin_url() . 'bekleyen-bakiye-talepleri') ?>">Onay Bekleyen Havale Talepleri</a>
        <span class="breadcrumb-item active">Havale Detay</span>
    </nav>
</div><!-- br-pageheader -->
<div class="br-pagetitle">
    <i class="fas fa-lira-sign fa-4x"></i>
    <div>
        <h4>Havale Detay</h4>
    </div>
</div><!-- d-flex -->

<div class="br-pagebody">
    <div class="br-section-wrapper">
        <div class="card mb-5">
            <div class="card-body">
                <form action="<?= base_url(admin_url() . 'bakiye-yukleme-duzenle/' . $talep->id) ?>"
                      method="post">
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <h3 class="text-center">İşlem Durumu</h3>
                            <?php if ($talep->status == 0) { ?>
                                <span class="btn btn-warning rounded-pill btn-block">Onay Bekliyor..</span>
                            <?php } elseif ($talep->status == 1) { ?>
                                <span class="btn btn-success rounded-pill btn-block">Onaylandı</span>
                            <?php } elseif ($talep->status == 2) { ?>
                                <span class="btn btn-secondary rounded-pill btn-block">Onaylanmadı</span>
                            <?php } ?>
                        </div>
                        <div class="col-md-6">
                            <h3 class="text-center">Tarih</h3>
                            <span class="btn btn-primary rounded-pill btn-block"><?= date('d.m.Y H:i:s', strtotime($talep->date)) ?></span>
                        </div>
                    </div>
                    <div class="card mb-4">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="form-label">Üye</label>
                                        <input class="form-control" type="text" value="<?= $talep->user_name ?>"
                                               placeholder="IBAN No" disabled>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="form-label">Banka Hesabı</label>
                                        <input class="form-control" type="text" value="<?= $talep->bank_name ?>"
                                               placeholder="IBAN No" disabled>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="form-label">Yüklenecek Tutar</label>
                                        <input class="form-control" type="text" value="<?= $talep->amount ?>₺"
                                               placeholder="Çekilecek Tutar" disabled>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="form-label">Gönderen Ad Soyad</label>
                                        <input class="form-control" type="text" value="<?= $talep->name ?>"
                                               placeholder="Sipariş Numarası" disabled>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="form-label">Açıklama</label>
                                        <textarea class="form-control" disabled><?= $talep->name ?></textarea>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="form-label">Para Yükleme Talep Durumu </label>
                                        <select class="form-control" name="status" required>
                                            <option <?php if ($talep->status== 0) {
                                                echo 'selected';
                                            } ?> value="0">Onay Bekliyor..
                                            </option>
                                            <option <?php if ($talep->status == 1) {
                                                echo 'selected';
                                            } ?> value="1">Onaylandı
                                            </option>
                                            <option <?php if ($talep->status == 2) {
                                                echo 'selected';
                                            } ?> value="2">Onaylanmadı
                                            </option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <button type="submit" class="btn btn-primary">Para Yükleme Talebi Güncelle</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
