<?php $menuler = menuler(); ?>
<div class="br-pageheader">
	<nav class="breadcrumb pd-0 mg-0 tx-12">
		<a class="breadcrumb-item" href="<?=base_url(admin_url())?>">Kontrol Paneli</a>
		<a class="breadcrumb-item" href="<?=base_url(admin_url()."banka-hesaplari")?>">Bankalar</a>
		<span class="breadcrumb-item active"><?=$where->name?> - Düzenle</span>
	</nav>
</div><!-- br-pageheader -->
<div class="br-pagetitle">
	<i class="fas fa-edit fa-4x"></i>
	<div>
		<h4><?=$where->name?> - Düzenle</h4>
		<p class="mg-b-0">Banka bilgilerini güncelleyebilirsiniz.</p>
	</div>
</div><!-- d-flex -->

<div class="br-pagebody">
	<div class="br-section-wrapper">
		<form action="<?=base_url(admin_url()."bankahesabiduzenle/$where->id"); ?>" method="post" enctype="multipart/form-data">
			<div class="form-layout form-layout-1">
				<img width="150" src="<?=base_url($where->image)?>">
				<br>
				<br>
				<div class="row mg-b-25">
					<div class="col-lg-6">
						<div class="form-group">
							<label class="form-control-label">Banka Başlık <span class="tx-danger">*</span></label>
							<input class="form-control" type="text" name="name" placeholder="Banka Başlık" value="<?=$where->name?>">
							<?php if (isset($form_error)) { ?> <code class="pull-right"><?=form_error('name')?></code><?php } ?>
						</div>
					</div><!-- col-4 -->
					<div class="col-lg-6" style="margin-top: 29px;">
						<div class="form-group custom-file">
							<input type="file" class="custom-file-input" id="customFile2" name="file" accept=".jpg, .jpeg, .png">
							<label class="custom-file-label custom-file-label-primary" for="customFile2">Banka Fotoğrafı <small>(Sadece .jpg/.jpeg/.png - İsteğe Bağlı)</small></label>
						</div>
					</div><!-- col-4 -->
					<div class="col-lg-6">
						<div class="form-group">
							<label class="form-control-label">Banka Iban <span class="tx-danger">*</span></label>
							<input class="form-control" type="text" name="iban" placeholder="Banka Iban" required="" value="<?= $where->iban ?>">
						</div>
					</div><!-- col-4 -->
					<div class="col-lg-6">
						<div class="form-group">
							<label class="form-control-label">Banka Sıra No <span class="tx-danger">*</span></label>
							<input class="form-control" type="text" name="order_no" placeholder="Banka Sıra No" required="" value="<?= $where->order_no ?>">
						</div>
					</div><!-- col-4 -->
					<div class="col-lg-6">
						<div class="form-group">
							<label class="form-control-label">Banka Durum <span class="tx-danger">*</span></label>
							<select name="status" class="form-control">
								<option value="1" <?= $where->status == 1 ?'selected':'' ?>>Aktif</option>
								<option value="0" <?= $where->status == 0 ?'selected':'' ?>>Pasif</option>
							</select>
						</div>
					</div><!-- col-4 -->
					<div class="col-lg-12">
						<div class="form-group">
							<label class="form-control-label">Banka Detay</label>
							<textarea class="form-control" name="description" rows="8" placeholder="Banka Detay" required=""><?=$where->description?></textarea>
						</div>
					</div><!-- col-8 -->
				</div>

				<div class="form-layout-footer">
					<button type="submit" class="btn btn-info">Banka Güncelle</button>
				</div><!-- form-layout-footer -->
			</div>
		</form><!-- form-layout -->
	</div>
</div>

<script>
	$(document).ready(function(){
		CKEDITOR.replace( 'detay' );
	});
</script>