<div class="br-pageheader">
  <nav class="breadcrumb pd-0 mg-0 tx-12">
    <a class="breadcrumb-item" href="<?=base_url(admin_url())?>">Kontrol Paneli</a>
    <span class="breadcrumb-item active">Bankalar</span>
  </nav>
</div><!-- br-pageheader -->
<div class="br-pagetitle">
  <i class="fas fa-edit fa-4x"></i>
  <div>
    <h4>Bankalar</h4>
  </div>
</div><!-- d-flex -->

<div class="br-pagebody">
  <div class="br-section-wrapper">
    <div class="table-wrapper">
      <table id="datatable1" class="table display responsive nowrap">
        <thead>
          <tr>
            <th class="wd-15p text-center">Banka Sıra</th>
            <th class="wd-15p text-center">Banka FOTOĞRAF</th>
            <th class="wd-15p text-center">Banka BAŞLIK</th>
            <th class="wd-15p text-center">Banka Iban</th>
            <th class="wd-15p text-center">Banka Durum</th>
            <th class="wd-10p text-center">Banka İŞLEM</th>
          </tr>
        </thead>
        <tbody>
          <?php $bankalar = bankalar(); ?>
          <?php if ($bankalar) { ?>
            <?php foreach ($bankalar as $key) { ?>
              <tr>
                <td><?= $key->order_no ?></td>
                <td class="text-center"><img width="100" src="<?=base_url($key->image)?>"></td>
                <td><?=$key->name?></td>
                <td><?=$key->iban?></td>
                <td><?=$key->status == 0 ? 'Pasif':'Aktif'?></td>
                <td class="text-center">
                  <a href="<?php echo base_url(admin_url()."banka-hesabi-duzenle/$key->id"); ?>" class="btn btn-warning btn-with-icon">
                    <div class="ht-40">
                      <span class="icon fas fa-edit wd-40"><i class="fa fa-send"></i></span>
                      <span class="pd-x-15">Düzenle</span>
                    </div>
                  </a>
                  <a href="javascript:void(0)" data-url="<?=base_url(admin_url()."bankahesabisil/$key->id")?>" class="btn btn-danger btn-with-icon remove-btn">
                    <div class="ht-40">
                      <span class="icon far fa-trash-alt wd-40"><i class="fa fa-send"></i></span>
                      <span class="pd-x-15">Sil</span>
                    </div>
                  </a>
                </td>
              </tr>
            <?php } ?>
          <?php } ?>
        </tbody>
      </table>
    </div><!-- table-wrapper -->
  </div><!-- br-section-wrapper -->
</div><!-- br-pagebody -->