<div class="br-pageheader">
    <nav class="breadcrumb pd-0 mg-0 tx-12">
        <a class="breadcrumb-item" href="<?= base_url(admin_url()) ?>">Kontrol Paneli</a>
        <span class="breadcrumb-item active">Vitrinler</span>
    </nav>
</div><!-- br-pageheader -->
<div class="br-pagetitle">
    <i class="fas fa-store fa-4x"></i>
    <div>
        <h4>Vitrinler</h4>
        <p class="mg-b-0">Vitrin Listesi</p>
    </div>
</div><!-- d-flex -->

<div class="br-pagebody">
    <div class="br-section-wrapper">
        <div class="table-wrapper">
            <table id="datatable1" class="table display responsive nowrap">
                <thead>
                <tr>
                    <th class="text-center">#</th>
                    <th class="text-center">VİTRİN ADI</th>
                    <th class="text-center">VİTRİN TÜRÜ</th>
                    <th class="text-center">VİTRİN İCON</th>
                    <th class="text-center">VİTRİN SIRA</th>
                    <th class="text-center">VİTRİN İÇERİK TÜRÜ</th>
                    <th class="text-center">VİTRİN EKLENME TARİH</th>
                    <th class="text-center">VİTRİN İŞLEM</th>
                </tr>
                </thead>
                <tbody>
                <?php if ($vitrinler) { ?>
                    <?php $i = 0;
                    foreach ($vitrinler as $key) {
                        $i++; ?>
                        <tr>
                            <td class="text-center"><?= $i ?></td>
                            <td class="text-center"><?= $key->name ?></td>
                            <td class="text-center"><?= $key->type==0?'1.Vitrin':'2.Vitrin'; ?></td>
                            <td class="text-center"><img src="<?= base_url($key->icon); ?>"></td>
                            <td class="text-center"><?= $key->sira ?></td>
                            <td class="text-center"><?= $key->contents==1?'Ürünler':'İlanlar' ?></td>
                            <td class="text-center"><?= $key->tarih ?></td>
                            <td class="text-center">
                                <a href="<?php echo base_url(admin_url() . "vitrin-detay/$key->id"); ?>"
                                   class="btn btn-primary btn-with-icon">
                                    <div class="ht-40">
                                        <span class="icon fas fa-eye wd-40"><i class="fa fa-send"></i></span>
                                        <span class="pd-x-15">İçerik</span>
                                    </div>
                                </a>
                                <a href="<?php echo base_url(admin_url() . "vitrin-duzenle/$key->id"); ?>"
                                   class="btn btn-warning btn-with-icon">
                                    <div class="ht-40">
                                        <span class="icon fas fa-pencil-alt wd-40"><i class="fa fa-send"></i></span>
                                        <span class="pd-x-15">Düzenle</span>
                                    </div>
                                </a>
                                <a href="javascript:void(0)"
                                   data-url="<?= base_url(admin_url() . "vitrin-sil/$key->id") ?>"
                                   class="btn btn-danger btn-with-icon remove-btn">
                                    <div class="ht-40">
                                        <span class="icon far fa-trash-alt wd-40"><i class="fa fa-send"></i></span>
                                        <span class="pd-x-15">Sil</span>
                                    </div>
                                </a>
                            </td>
                        </tr>
                    <?php } ?>
                <?php } ?>
                </tbody>
            </table>
        </div><!-- table-wrapper -->
    </div><!-- br-section-wrapper -->
</div><!-- br-pagebody -->