<div class="br-pageheader">
    <nav class="breadcrumb pd-0 mg-0 tx-12">
        <a class="breadcrumb-item" href="<?= base_url(admin_url()) ?>">Kontrol Paneli</a>
        <a class="breadcrumb-item" href="<?= base_url(admin_url() . 'vitrinler') ?>">Vitrinler</a>
        <span class="breadcrumb-item active">Vitrin Düzenle</span>
    </nav>
</div><!-- br-pageheader -->
<div class="br-pagetitle">
    <i class="fas fa-store fa-4x"></i>
    <div>
        <h4><?= $vitrin->name ?> - Vitrin Düzenle</h4>
    </div>
</div><!-- d-flex -->

<div class="br-pagebody">
    <div class="br-section-wrapper">
        <form action="<?= base_url('yonetim_magaza_controller/vitrinduzenle/' . $vitrin->id) ?>" method="post"
              enctype="multipart/form-data">
            <!-- Form -->
            <div class="row">
                <div class="form-group col-md-12">
                    <!-- Title -->
                    <label for="postTitle" class="form-label">Vitrin Adı</label>
                    <input type="text" name="name" class="form-control text-dark"
                           placeholder="Vitrin Adı" value="<?= $vitrin->name ?>" required/>
                    <small>Lütfen özel karakter kullanmamaya çalışın ve yazım kurallarına göre
                        başlık yazın.</small>
                </div>

                <div class="form-group col-md-6">
                    <label class="form-label">Vitrin Türü</label>
                    <select class="form-control" data-width="100%" name="type"
                            required>
                        <option <?php if ($vitrin->type == 0) {
                            echo 'selected';
                        } ?> value="0">1.Vitrin
                        </option>
                        <option <?php if ($vitrin->type == 1) {
                            echo 'selected';
                        } ?> value="1">2.Vitrin
                        </option>
                    </select>
                </div>

                <div class="form-group col-md-6">
                    <label class="form-label">Vitrin Türü</label>
                    <select class="form-control" data-width="100%" name="contents"
                            required>
                        <option <?php if ($vitrin->contents == 1) {
                            echo 'selected';
                        } ?> value="1">Ürün
                        </option>
                        <option <?php if ($vitrin->contents == 2) {
                            echo 'selected';
                        } ?> value="2">İlan
                        </option>
                    </select>
                </div>

                <div class="form-group col-md-12 mt-3">
                    <!-- Title -->
                    <label for="postTitle" class="form-label">Vitrin Sırası</label>
                    <input type="number" name="sira" class="form-control text-dark" placeholder="Vitrin Sırası" value="<?= $vitrin->sira ?>" required />
                </div>


                <div class="form-group col-md-12  mb-5">
                    <label class="form-label">Varsayılan Vitrin Iconu</label>
                    <div>
                        <img width="32" src="<?= base_url($vitrin->icon) ?>"
                             alt="<?= $vitrin->name ?>">
                    </div>
                </div>

                <div class="form-group col-md-12  mb-5">
                    <label class="form-label">Vitrin Iconu</label>
                    <div class="custom-file">
                        <input type="file" class="custom-file-input" id="vitrin" name="file"
                               accept=".jpg, .jpeg, .png" onchange="getPhotoData(this);">
                        <label class="custom-file-label" for="vitrin">Vitrin
                            Iconu</label>
                        <small>Sadece <span class="badge badge-danger badge-pill badge-sm">.png/.jpg/.jpeg</span>
                            dosya türü
                            desteklenmektedir.</small>
                        <div class="card mt-2" id="resim_goster" style="display: none">
                            <div class="p-3 d-flex justify-content-between">
                                <div>
                                    <i class="fe fe-file"></i> <span class="resim_adi"></span> /
                                    <small
                                            class="resim_size"></small>
                                </div>
                                <div>
                                    <a href="javascript:void(0)" id="resim_sil"><i
                                                class="fe fe-x"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            
            <!-- button -->
            <button type="submit" class="btn btn-primary badge-pill"> Vitrin Düzenle</button>
        </form>
    </div>
</div>

<script>

    /**
     * Dosya Seçme işlemleri
     */
    var vt = document.getElementById('vitrin');

    

    function getPhotoData(myFile) {
        var file = myFile.files[0];
        if (file) {
            var filename = file.name;
            $('.resim_adi').html(filename);
            $('.resim_size').html(bytesToSize(file.size));
            $('#resim_goster').show();
        } else {
            $('.resim_adi').html('');
            $('.resim_size').html('');
            $('#resim_goster').hide();
        }
    }

    $(document).on('click', '#resim_sil', function () {
        clearInputPhoto(vt);
    });

    function clearInputPhoto(f) {
        if (f.value) {
            try {
                f.value = ''; //for IE11, latest Chrome/Firefox/Opera...
            } catch (err) {
            }
            if (f.value) { //for IE5 ~ IE10
                var form = document.createElement('form'), ref = f.nextSibling;
                form.appendChild(f);
                form.reset();
                ref.parentNode.insertBefore(f, ref);
            }
            getPhotoData(f);
        }
    }

    /**
     * Byte To MB Convert
     */
    function bytesToSize(bytes) {
        var sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
        if (bytes == 0) return '0 Byte';
        var i = parseInt(Math.floor(Math.log(bytes) / Math.log(1024)));
        return Math.round(bytes / Math.pow(1024, i), 2) + ' ' + sizes[i];
    }

</script>