<div class="br-pageheader">
   <nav class="breadcrumb pd-0 mg-0 tx-12">
      <a class="breadcrumb-item" href="<?= base_url(admin_url()) ?>">Kontrol Paneli</a>
      <span class="breadcrumb-item active">Sponsor Başvuruları</span>
   </nav>
</div><!-- br-pageheader -->
<div class="br-pagetitle">
   <i class="fas fa-store fa-4x"></i>
   <div>
      <h4>Sponsor Başvuru</h4>
      <p class="mg-b-0">Başvuru Listesi</p>
   </div>
</div><!-- d-flex -->

<div class="br-pagebody">
   <div class="br-section-wrapper">
      <div class="table-wrapper">
         <table id="datatable1" class="table display responsive nowrap">
            <thead>
               <tr>
                  <th class="text-center">#</th>
                  <th class="text-center">İsim Soyisim</th>
                  <th class="text-center">Durum</th>
                  <th class="text-center">Kategoriler</th>
                  <th class="text-center">İşlem</th>
               </tr>
            </thead>
            <tbody>
               <?php if ($sponsorlar) { ?>
                  <?php $i = 0;
                  foreach ($sponsorlar as $key) {
                     $i++; ?>
                     <tr>
                        <td class="text-center"><?= $i ?></td>

                        <td class="text-center"><?= $key->isim . " " . $key->soyisim ?></td>
                        <td class="text-center">
                           <?php if ($key->durum == 0) { ?>
                              <span class="badge badge-warning badge-pill">Onay Bekliyor..</span>
                           <?php } elseif ($key->durum == 1) { ?>
                              <span class="badge badge-success badge-pill">Onaylandı</span>
                           <?php } elseif ($key->durum == 2) { ?>
                              <span class="badge badge-danger badge-pill">Onaylanmadı</span>
                           <?php } ?>
                        </td>
                        <td class="text-center"><?php
                                                foreach ($key->kategoriler as $kx) {
                                                   echo '<span class="badge badge-info badge-pill"> ' . $kx . '</span> ';
                                                }
                                                ?></td>
                        <td class="text-center">
                           <a href="javascript:void(0)" data-url="<?= base_url(admin_url() . "sponsor-sil/$key->id") ?>" class="btn btn-danger btn-with-icon remove-btn">
                              <div class="ht-40">
                                 <span class="icon far fa-trash-alt wd-40"><i class="fa fa-send"></i></span>
                                 <span class="pd-x-15">Sil</span>
                              </div>
                           </a>
                        </td>
                     </tr>
                  <?php } ?>
               <?php } ?>
            </tbody>
         </table>
      </div><!-- table-wrapper -->
   </div><!-- br-section-wrapper -->
</div><!-- br-pagebody -->