<div class="br-pageheader">
    <nav class="breadcrumb pd-0 mg-0 tx-12">
        <a class="breadcrumb-item" href="<?= base_url(admin_url()) ?>">Kontrol Paneli</a>
        <span class="breadcrumb-item active">Çekilişler</span>
    </nav>
</div><!-- br-pageheader -->
<div class="br-pagetitle">
    <i class="fas fa-cart-plus fa-4x"></i>
    <div>
        <h4>Çekilişler</h4>
    </div>
</div><!-- d-flex -->

<div class="br-pagebody">
    <div class="br-section-wrapper">
        <div class="table-wrapper table-responsive">
            <div class="row">
                <div class="col-md-12">
                    <label for="">Çekiliş Başlığı</label>
                    <input type="text" class="form-control" value="<?= $cekilis->title ?>" disabled>
                </div>
                <div class="col-md-12 mt-2">
                    <label for="">Çekiliş Açıklaması</label>
                    <textarea name="" id="" cols="30" rows="10" class="form-control" disabled><?= $cekilis->aciklama ?></textarea>
                </div>
                <div class="col-md-12 mt-2">
                    <label for="">Çekiliş Bitiş Tarihi</label>
                    <input type="text" class="form-control" value="<?= $cekilis->end_date ?>" disabled>
                </div>
                <div class="col-md-12 mt-5">
                    <label for="">Çekiliş Ürünleri</label>
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th class="text-center">#</th>
                                <th class="text-center">Ürün Adı</th>
                                <th class="text-center">Ürün Resmi</th>
                                <th class="text-center">Ürün Fiyatı</th>
                                <th class="text-center">Ürün Linki</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($cekilis->esyalar) : ?>
                                <?php foreach ($cekilis->esyalar as $key) : ?>
                                    <tr>
                                        <td class="text-center"><?= $key->id ?></td>
                                        <td class="text-center"><?= $key->urun_ad ?></td>
                                        <td class="text-center">
                                            <?php if($key->bakiye > 1): ?>
                                                    <img src="<?= $key->urun_resim ?>" alt="" width="100">
                                                    
                                                <?php else: ?>
                                                    <img src="<?= base_url($key->urun_resim) ?>" alt="" width="100">
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-center"><?= $key->urun_fiyat ?></td>
                                        <td class="text-center"><?= $key->esyalar_link ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                </div>
                <div class="col-md-12 mt-5">
                    <table class="table table-bordered mt-5">
                        <span >Çekiliş Kazananları</span>

                        <thead>
                        <tr>
                            <th class="text-center">#</th>
                            <th class="text-center">Kullanıcı Adı</th>
                            <th class="text-center">Resmi</th>
                            <th class="text-center">İsim Soyisim</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php if ($cekilis->kazananlar) { ?>
                            <?php foreach ($cekilis->kazananlar as $key) : ?>
                                <tr>
                                    <td class="text-center"><?= $key->kullanici->kullanici_id ?></td>
                                    <td class="text-center"><?= $key->kullanici->kullanici_ad ?></td>
                                    <td class="text-center">
                                        <img src="<?= base_url($key->kullanici->kullanici_resim) ?>" alt="" width="100">
                                    </td>
                                    <td class="text-center"><?= $key->kullanici->kullanici_isim. ' '. $key->kullanici->kullanici_soyisim ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php } else { ?>
                            <td colspan="12" class="text-center">No Data</td>
                        <?php } ?>
                        </tbody>
                </div>
            </div>
        </div><!-- table-wrapper -->
    </div><!-- br-section-wrapper -->
</div><!-- br-pagebody -->