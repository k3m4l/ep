<div class="br-pageheader">
    <nav class="breadcrumb pd-0 mg-0 tx-12">
        <a class="breadcrumb-item" href="<?= base_url(admin_url()) ?>">Kontrol Paneli</a>
        <span class="breadcrumb-item active">Çekilişler</span>
    </nav>
</div><!-- br-pageheader -->
<div class="br-pagetitle">
    <i class="fas fa-cart-plus fa-4x"></i>
    <div>
        <h4>Çekilişler</h4>
    </div>
</div><!-- d-flex -->

<div class="br-pagebody">
    <div class="br-section-wrapper">
        <div class="table-wrapper table-responsive">
            <table id="datatable1" class="table display nowrap">
                <thead>
                    <tr>
                        <th class="text-center">#</th>
                        <th class="text-center">Çekiliş Başlığı</th>
                        <th class="text-center">Mağaza</th>
                        <th class="text-center">DURUM</th>
                        <th class="text-center">Bitiş Tarih</th>
                        <th class="text-center">İşlemler</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($cekilisler) : ?>
                        <?php foreach ($cekilisler as $key) : ?>
                            <tr>
                                <td class="text-center"><?= $key->id ?></td>
                                <td class="text-center"><?= $key->title ?></td>
                                <td class="text-center"><?= $key->magaza_ad ?></td>
                                <td class="text-center">
                                    <?php if ($key->onay == 0) { ?>
                                        <span class="badge badge-danger badge-pill">Onay Bekliyor</span>
                                    <?php } elseif ($key->onay == 1) { ?>
                                        <span class="badge badge-success badge-pill">Onaylandı</span>
                                    <?php } elseif ($key->onay == 2) { ?>
                                        <span class="badge badge-danger badge-pill">Reddedildi</span>
                                    <?php } ?>
                                </td>
                                <td class="text-center">
                                    <?php echo $key->end_date ?>
                                </td>
                                <td class="text-center">
                                    <div class="btn-grp">
                                        <a href="<?= base_url(admin_url() . 'cekilis/onay/' . $key->id) ?>" class="btn btn-success"><i class="fas fa-check"></i></a>
                                        <a href="<?= base_url(admin_url() . 'cekilis/iptal/' . $key->id) ?>" class="btn btn-warning"><i class="far fa-window-close"></i></a>
                                        <a href="<?= base_url(admin_url() . 'cekilis/sil/' . $key->id) ?>" class="btn btn-danger"><i class="fas fa-trash"></i></a>
                                        <a href="<?= base_url(admin_url() . 'cekilis/detay/' . $key->id) ?>" class="btn btn-info"><i class="fa fa-eye"></i></a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div><!-- table-wrapper -->
    </div><!-- br-section-wrapper -->
</div><!-- br-pagebody -->