<?php $menuler = menuler(); ?>
<div class="br-pageheader">
	<nav class="breadcrumb pd-0 mg-0 tx-12">
		<a class="breadcrumb-item" href="<?=base_url(admin_url())?>">Kontrol Paneli</a>
		<a class="breadcrumb-item" href="kategoriler">Bloglar</a>
		<span class="breadcrumb-item active">Yeni Blog Ekle</span>
	</nav>
</div><!-- br-pageheader -->
<div class="br-pagetitle">
	<i class="fas fa-edit fa-4x"></i>
	<div>
		<h4>Yeni Blog Ekle</h4>
		<p class="mg-b-0">Yeni Blog Yazıları Yazarak Daha Fazla Kitleye Ulaşın</p>
	</div>
</div><!-- d-flex -->

<div class="br-pagebody">
	<div class="br-section-wrapper">
		<form action="<?=base_url(admin_url()."blogekle"); ?>" method="post" enctype="multipart/form-data">
			<div class="form-layout form-layout-1">
				<div class="row mg-b-25">
					<div class="col-lg-6">
						<div class="form-group">
							<label class="form-control-label">Blog Başlık <span class="tx-danger">*</span></label>
							<input class="form-control" type="text" name="ad" placeholder="Blog Başlık" required="">
							<?php if (isset($form_error)) { ?> <code class="pull-right"><?=form_error('ad')?></code><?php } ?>
						</div>
					</div><!-- col-4 -->
					<div class="col-lg-6" style="margin-top: 29px;">
						<div class="form-group custom-file">
							<input type="file" class="custom-file-input" id="customFile2" name="file" accept=".jpg, .jpeg, .png">
							<label class="custom-file-label custom-file-label-primary" for="customFile2">Blog Fotoğrafı <small>(Sadece .jpg/.jpeg/.png - İsteğe Bağlı)</small></label>
						</div>
					</div><!-- col-4 -->
                    <div class="col-lg-12">
                        <div class="form-group mg-b-10-force">
                            <label class="form-control-label">Blog Kategori <span class="tx-danger">*</span></label>
                            <select class="form-control" name="kategori">
                                <option selected hidden disabled>Lütfen Kategori Seçin</option>
                                <?php foreach (blog_kategoriler_yonetim() as $kat) { ?>
                                    <option value="<?php echo $kat->id; ?>"><?php echo $kat->kategori_ad; ?></option>
                                <?php } ?>
                            </select>
                        </div>
                    </div>
					<div class="col-lg-12">
						<div class="form-group">
							<label class="form-control-label">Blog Detay</label>
							<textarea class="form-control" name="detay" rows="8" placeholder="Blog Detay" required=""></textarea>
						</div>
					</div><!-- col-8 -->
				</div>

				<div class="form-layout-footer">
					<button type="submit" class="btn btn-info">Blog Ekle</button>
				</div><!-- form-layout-footer -->
			</div>
		</form><!-- form-layout -->
	</div>
</div>

<script>
	$(document).ready(function(){
		CKEDITOR.replace( 'detay' );
	});
</script>