<div class="br-pageheader">
  <nav class="breadcrumb pd-0 mg-0 tx-12">
    <a class="breadcrumb-item" href="<?=base_url(admin_url())?>">Kontrol Paneli</a>
    <span class="breadcrumb-item active">Kupon Kayıtları</span>
  </nav>
</div><!-- br-pageheader -->
<div class="br-pagetitle">
  <i class="fas fa-tags fa-4x"></i>
  <div>
    <h4>Kupon Kayıtları</h4>
  </div>
</div><!-- d-flex -->

<div class="br-pagebody">
  <div class="br-section-wrapper">
    <div class="table-wrapper">
      <table id="datatable1" class="table display responsive nowrap">
        <thead>
          <tr>
            <th class="wd-15p text-center">#</th>
            <th class="wd-15p text-center">KULLANICI</th>
            <th class="wd-15p text-center">KUPON ADI</th>
            <th class="wd-15p text-center">KUPON KODU</th>
            <th class="wd-15p text-center">KUPON TUTARI</th>
            <th class="wd-15p text-center">KUPON KULLANIM TARİHİ</th>
            <th class="wd-10p text-center">KUPON İŞLEM</th>
          </tr>
        </thead>
        <tbody>
          <?php if ($kayitlar) { ?>
            <?php foreach ($kayitlar as $key=>$item) { ?>
              <tr>
                <td class="text-center"><?=$key?></td>
                <td class="text-center"><?=$item->kullanici_ad?></td>
                <td class="text-center"><?=$item->ad?></td>
                <td class="text-center"><?=$item->kod?></td>
                <td class="text-center"><?=$item->tutar?></td>
                <td class="text-center"><?=date('d.m.Y H:i:s',strtotime($item->tarih));?></td>
                <td>
                  <a href="javascript:void(0)" data-url="<?=base_url(admin_url()."kuponkayitsil/$item->id")?>" class="btn btn-danger btn-with-icon remove-btn">
                    <div class="ht-40">
                      <span class="icon far fa-trash-alt wd-40"><i class="fa fa-send"></i></span>
                      <span class="pd-x-15">Sil</span>
                    </div>
                  </a>
                </td>
              </tr>
            <?php } ?>
          <?php } ?>
        </tbody>
      </table>
    </div><!-- table-wrapper -->
  </div><!-- br-section-wrapper -->
</div><!-- br-pagebody -->