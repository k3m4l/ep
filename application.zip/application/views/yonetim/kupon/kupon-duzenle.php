<div class="br-pageheader">
	<nav class="breadcrumb pd-0 mg-0 tx-12">
		<a class="breadcrumb-item" href="<?=base_url(admin_url())?>">Kontrol Paneli</a>
		<a class="breadcrumb-item" href="<?=base_url(admin_url() . 'kuponlar')?>">Kuponlar</a>
		<span class="breadcrumb-item active">Kupon Düzenle</span>
	</nav>
</div><!-- br-pageheader -->
<div class="br-pagetitle">
	<i class="fas fa-tags fa-4x"></i>
	<div>
		<h4>Kupon Düzenle</h4>
	</div>
</div><!-- d-flex -->

<div class="br-pagebody">
	<div class="br-section-wrapper">
		<form action="<?=base_url(admin_url()."kuponduzenle/".$kupon->id); ?>" method="post" enctype="multipart/form-data">
			<div class="form-layout form-layout-1">
				<div class="row mg-b-25">
					<input type="hidden" name="id" value="<?= $kupon->id ?>">
					<div class="col-lg-4">
						<div class="form-group">
							<label class="form-control-label">Kupon Adı <span class="tx-danger">*</span></label>
							<input class="form-control" type="text" name="ad" placeholder="Kupon Adı" value="<?= $kupon->ad ?>">
							<?php if (isset($form_error)) { ?><small style="font-size: 10px; color: red;"><?=form_error('ad')?></small><?php } ?>
						</div>
					</div><!-- col-4 -->
					<div class="col-lg-4">
						<div class="form-group">
							<label class="form-control-label">Kupon Kodu <span class="tx-danger">*</span></label>
							<input class="form-control" id="buyuk" type="text" name="kod" placeholder="Kupon Kodu" value="<?= $kupon->kod ?>">
							<?php if (isset($form_error)) { ?><small style="font-size: 10px; color: red;"><?=form_error('kod')?></small><?php } ?>
						</div>
					</div><!-- col-4 -->
					<div class="col-lg-4">
						<div class="form-group">
							<label class="form-control-label">Kupon Tutarı <span class="tx-danger">*</span></label>
							<input class="form-control" type="text" name="tutar" placeholder="Kupon Tutarı" required value="<?= $kupon->tutar ?>">
							<?php if (isset($form_error)) { ?><small style="font-size: 10px; color: red;"><?=form_error('tutar')?></small><?php } ?>
						</div>
					</div><!-- col-4 -->
					<div class="col-lg-4">
						<div class="form-group">
							<label class="form-control-label">Kupon Adeti</label>
							<input class="form-control" type="number" name="stok" placeholder="Kupon Adeti" required=""  value="<?= $kupon->stok ?>">
							<?php if (isset($form_error)) { ?><small style="font-size: 10px; color: red;"><?=form_error('stok')?></small><?php } ?>
						</div>
					</div><!-- col-8 -->
					<div class="col-lg-4">
						<div class="form-group">
							<label class="form-control-label">Kupon Geçerlilik Tarihi</label>
							<input class="form-control fc-datepicker" type="text" name="bitis_tarihi" placeholder="Kupon Bitiş Tarihi" required=""  value="<?= date('d.m.Y',strtotime($kupon->bitis_tarihi)); ?>">
							<?php if (isset($form_error)) { ?><small style="font-size: 10px; color: red;"><?=form_error('bitis_tarihi')?></small><?php } ?>
						</div>
					</div><!-- col-8 -->
					<div class="col-lg-4">
						<div class="form-group">
							<label class="form-control-label">Kupon Durumu</label>
							<select name="durum" class="form-control">
								<option value="1" <?= $kupon->durum == 1?'selected':'' ?>>Aktif</option>
								<option value="0" <?= $kupon->durum == 0?'selected':'' ?>>Pasif</option>
							</select>
						</div>
					</div><!-- col-8 -->

				</div>

				<div class="form-layout-footer">
					<button type="submit" class="btn btn-info">Kupon Düzenle</button>
				</div><!-- form-layout-footer -->
			</div>
		</form><!-- form-layout -->
	</div>
</div>
<script type="text/javascript">
	$("#buyuk").keyup(function(){
		var string = this;
		var letters = { "i": "I", "ş": "S", "ğ": "G", "ü": "U", "ö": "O", "ç": "C", "ı": "I" };
		string = this.value.replace(/(([iışğüçö]))/g, function(letter){ return letters[letter]; })
		this.value = string.toUpperCase();
	});

</script>