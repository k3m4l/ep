<div class="br-pageheader">
  <nav class="breadcrumb pd-0 mg-0 tx-12">
    <a class="breadcrumb-item" href="<?=base_url(admin_url())?>">Kontrol Paneli</a>
    <span class="breadcrumb-item active">Kuponlar</span>
  </nav>
</div><!-- br-pageheader -->
<div class="br-pagetitle">
  <i class="fas fa-tags fa-4x"></i>
  <div>
    <h4>Kuponlar</h4>
  </div>
</div><!-- d-flex -->

<div class="br-pagebody">
  <div class="br-section-wrapper">
    <div class="table-wrapper">
      <table id="datatable1" class="table display responsive nowrap">
        <thead>
          <tr>
            <th class="wd-15p text-center">#</th>
            <th class="wd-15p text-center">KUPON ADI</th>
            <th class="wd-15p text-center">KUPON KODU</th>
            <th class="wd-15p text-center">KUPON ADET</th>
            <th class="wd-15p text-center">KUPON BİTİŞ</th>
            <th class="wd-15p text-center">KUPON TUTARI</th>
            <th class="wd-15p text-center">KUPON GEÇERLİLİK</th>
            <th class="wd-15p text-center">KUPON DURUM</th>
            <th class="wd-10p text-center">KUPON İŞLEM</th>
          </tr>
        </thead>
        <tbody>
          <?php if ($kuponlar) { ?>
            <?php foreach ($kuponlar as $key=>$item) { ?>
              <tr>
                <td class="text-center"><?=$key?></td>
                <td class="text-center"><?=$item->ad?></td>
                <td class="text-center"><?=$item->kod?></td>
                <td class="text-center"><?=$item->stok?></td>
                <td class="text-center"><?=date('d.m.Y',strtotime($item->bitis_tarihi));?></td>
                <td class="text-center"><?=$item->tutar?></td>
                <td class="text-center"><?=($item->stok == 0 || date('d.m.Y',strtotime($item->bitis_tarihi))<date('d.m.Y'))?'Geçersiz':'Geçerli'?></td>
                <td class="text-center"><?=$item->durum==1?'Aktif':'Pasif'?></td>
                <td class="text-center">
                  <a href="<?=base_url(admin_url()."kupon-duzenle/$item->id")?>" class="btn btn-primary btn-with-icon">
                    <div class="ht-40">
                      <span class="icon far fa-edit wd-40"><i class="fa fa-send"></i></span>
                      <span class="pd-x-15">Düzenle</span>
                    </div>
                  </a>
                  <a href="javascript:void(0)" data-url="<?=base_url(admin_url()."kuponsil/$item->id")?>" class="btn btn-danger btn-with-icon remove-btn">
                    <div class="ht-40">
                      <span class="icon far fa-trash-alt wd-40"><i class="fa fa-send"></i></span>
                      <span class="pd-x-15">Sil</span>
                    </div>
                  </a>
                </td>
              </tr>
            <?php } ?>
          <?php } ?>
        </tbody>
      </table>
    </div><!-- table-wrapper -->
  </div><!-- br-section-wrapper -->
</div><!-- br-pagebody -->