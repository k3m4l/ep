<div class="br-pageheader">
  <nav class="breadcrumb pd-0 mg-0 tx-12">
    <a class="breadcrumb-item" href="<?=base_url(admin_url())?>">Kontrol Paneli</a>
    <span class="breadcrumb-item active">Sayfalar</span>
  </nav>
</div><!-- br-pageheader -->
<div class="br-pagetitle">
  <i class="far fa-file-alt fa-4x"></i>
  <div>
    <h4>Sayfalar</h4>
  </div>
</div><!-- d-flex -->

<div class="br-pagebody">
  <div class="br-section-wrapper">
    <div class="table-wrapper">
      <table id="datatable1" class="table display responsive nowrap">
        <thead>
          <tr>
            <th class="wd-15p text-center">#</th>
            <th class="wd-15p text-center">SAYFA AD</th>
            <th class="wd-15p text-center">SAYFA SIRA</th>
            <th class="wd-15p text-center">SAYFA DURUM</th>
            <th class="wd-10p text-center">SAYFA İŞLEM</th>
          </tr>
        </thead>
        <tbody>
          <?php $sayfalar = sayfalar2(); ?>
          <?php if ($sayfalar) { ?>
            <?php $i=0; foreach ($sayfalar as $key) { $i++; ?>
              <tr>
                <td class="text-center"><?=$i?></td>
                <td class="text-center"><?=$key->sayfa_ad?></td>
                <td class="text-center"><?=$key->sayfa_sira?></td>
                <td class="text-center">
                  <label class="switch">
                    <input class="durum" data-url="<?=base_url(admin_url()."sayfadurum/$key->sayfa_id")?>" type="checkbox" <?php if ($key->sayfa_durum==1){ echo 'checked'; } ?>>
                    <span class="slider round"></span>
                  </label>
                </td>
                <td class="text-center">
                    <a href="<?=base_url("sayfa/".$key->sayfa_seo); ?>" target="_blank" class="btn btn-primary btn-with-icon">
                        <div class="ht-40">
                            <span class="icon fa fa-eye wd-40"></span>
                            <span class="pd-x-15">Göster</span>
                        </div>
                    </a>
                  <a href="<?php echo base_url(admin_url()."sayfa-duzenle/$key->sayfa_id"); ?>" class="btn btn-warning btn-with-icon">
                    <div class="ht-40">
                      <span class="icon fas fa-edit wd-40"><i class="fa fa-send"></i></span>
                      <span class="pd-x-15">Düzenle</span>
                    </div>
                  </a>
                  <a href="javascript:void(0)" data-url="<?=base_url(admin_url()."sayfasil/$key->sayfa_id")?>" class="btn btn-danger btn-with-icon remove-btn">
                    <div class="ht-40">
                      <span class="icon far fa-trash-alt wd-40"><i class="fa fa-send"></i></span>
                      <span class="pd-x-15">Sil</span>
                    </div>
                  </a>
                </td>
              </tr>
            <?php } ?>
          <?php } ?>
        </tbody>
      </table>
    </div><!-- table-wrapper -->
  </div><!-- br-section-wrapper -->
</div><!-- br-pagebody -->