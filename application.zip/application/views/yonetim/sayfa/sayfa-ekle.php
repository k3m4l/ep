<div class="br-pageheader">
	<nav class="breadcrumb pd-0 mg-0 tx-12">
		<a class="breadcrumb-item" href="<?=base_url(admin_url())?>">Kontrol Paneli</a>
		<span class="breadcrumb-item active">Yeni Sayfa Oluştur</span>
	</nav>
</div><!-- br-pageheader -->
<div class="br-pagetitle">
	<i class="far fa-file-alt fa-4x"></i>
	<div>
		<h4>Yeni Sayfa Oluştur</h4>
		<p class="mg-b-0">Sitenize Sayfalar Oluşturabilir, Müşterilerinizi Bilgilendirebilirsiniz.</p>
	</div>
</div><!-- d-flex -->

<div class="br-pagebody">
	<div class="br-section-wrapper">
		<form action="<?=base_url(admin_url()."sayfaekle"); ?>" method="post" enctype="multipart/form-data">
			<div class="form-layout form-layout-1">
				<div class="row mg-b-25">
					<div class="col-lg-4">
						<div class="form-group">
							<label class="form-control-label">Sayfa Adı <span class="tx-danger">*</span></label>
							<input class="form-control" type="text" name="ad" placeholder="Sayfa Adı" required="">
						</div>
					</div><!-- col-4 -->
					<div class="col-lg-4">
						<label class="form-control-label">Sayfa Konum <span class="tx-danger">*</span></label>
						<select class="form-control select2-show-search" data-placeholder="Lütfen Konum Seçin" name="konum" required="">
							<option value="1">Gizli Sayfa</option>
							<option value="0">Alt Menü</option>
                            <option value="2">Footer Hızlı Sayfalar</option>
                            <option value="3">Footer Sözleşmeler</option>
						</select>
					</div>

					<div class="col-lg-4">
						<div class="form-group">
							<label class="form-control-label">Sayfa Sırası</label>
							<input class="form-control" type="number" name="sira" placeholder="Sayfa Sırası" value="1">
						</div>
					</div><!-- col-8 -->


                    <div class="col-lg-12 mb-2">
                        <label class="form-control-label">Sayfa Türü <span class="tx-danger">*</span></label>
                        <select class="form-control select2-show-search" id="sayfa_tur" data-placeholder="Lütfen Tür Seçin" name="tur" required="">
                            <option hidden>Sayfa Türü Seçin</option>
                            <option value="1">Url Yönlendirme</option>
                            <option value="0">Normal Sayfa</option>
                        </select>
                    </div>


					<div class="col-lg-12 display-none" id="sayfa_detay">
						<div class="form-group">
							<label class="form-control-label">Sayfa Detay</label>
							<textarea class="form-control" rows="15" name="detay" placeholder="Sayfa Detay" required=""></textarea>
						</div>
					</div><!-- col-8 -->

                    <div class="col-lg-12 display-none" id="sayfa_url">
                        <div class="form-group">
                            <label class="form-control-label">Yönlendirilecek URL</label>
                            <input class="form-control" type="text" name="url" placeholder="Yönlendirilecek URL">
                        </div>
                    </div>


					<div class="col-lg-4">
						<div class="form-group">
							<label class="form-control-label">Sayfa Seo Başlık</label>
							<input class="form-control" type="text" name="title" placeholder="Sayfa Seo Başlık">
						</div>
					</div><!-- col-8 -->
					<div class="col-lg-4">
						<div class="form-group">
							<label class="form-control-label">Sayfa Seo Açıklama</label>
							<input class="form-control" type="text" name="desc" placeholder="Sayfa Seo Açıklama">
						</div>
					</div><!-- col-8 -->
					<div class="col-lg-4">
						<div class="form-group">
							<label class="form-control-label">Sayfa Seo Etiket</label>
							<input class="form-control" type="text" name="keyw" placeholder="Sayfa Seo Etiket">
						</div>
					</div><!-- col-8 -->

				</div>

				<div class="form-layout-footer">
					<button type="submit" class="btn btn-info">Sayfa Ekle</button>
				</div><!-- form-layout-footer -->
			</div>
		</form><!-- form-layout -->
	</div>
</div>
<script>
	$(document).ready(function(){
		CKEDITOR.replace( 'detay' );
	});

    $('#sayfa_tur').change(function(){
        if($('#sayfa_tur').val() == '1') {
            $('#sayfa_url').show();
            $('#sayfa_detay').hide();
        } else {
            $('#sayfa_url').hide();
            $('#sayfa_detay').show();
        }
    });
</script>