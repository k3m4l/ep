<?php
$siteayar = ayarlar();
if (!empty($siteayar->header1degisen)) {
    $birlestir = implode(",", json_decode($siteayar->header1degisen));
}
?>
<div class="br-pageheader">
    <nav class="breadcrumb pd-0 mg-0 tx-12">
        <a class="breadcrumb-item" href="<?= base_url(admin_url()) ?>">Kontrol Paneli</a>
        <span class="breadcrumb-item active">NetGSM Ayarları</span>
    </nav>
</div><!-- br-pageheader -->
<div class="br-pagetitle">
    <i class="fas fa-cogs fa-4x"></i>
    <div>
        <h4>NetGSM Ayarları</h4>
        <p class="mg-b-0">NetGSM Ayarlarını Buradan Yapabilirsiniz.</p>
    </div>
</div><!-- d-flex -->

<div class="br-pagebody">
    <div class="br-section-wrapper">
        <div class="tab-content">
            <div id="sms" class="tab-pane fade in active show">
                <form action="<?php echo base_url(admin_url() . "smsayar"); ?>" method="post">
                    <div class="form-layout form-layout-1">
                        <div class="row mg-b-25">
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label class="form-control-label">NETGSM Kullanıcı </label>
                                    <input class="form-control" type="text" name="username"
                                           placeholder="NETGSM Kullanıcı" value="<?= $siteayar->netgsm_user; ?>">
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label class="form-control-label">NETGSM Şifre </label>
                                    <input class="form-control" type="password" name="password"
                                           placeholder="NETGSM Şifre" value="<?= $siteayar->netgsm_pass; ?>">
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label class="form-control-label">NETGSM Başlık </label>
                                    <input class="form-control" type="text" name="header" placeholder="NETGSM Başlık"
                                           value="<?= $siteayar->netgsm_header; ?>">
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <label class="form-control-label">NETGSM Durum <span class="tx-danger">*</span></label>
                                <select class="form-control select2-show-search"
                                        data-placeholder="Lütfen NETGSM Durum Seçin" name="status" required="">
                                    <option <?php if ($siteayar->netgsm_durum == 1) {
                                        echo "selected";
                                    } ?> value="1">Aktif
                                    </option>
                                    <option <?php if ($siteayar->netgsm_durum == 0) {
                                        echo "selected";
                                    } ?> value="0">Pasif
                                    </option>
                                </select>
                            </div>
                            <div class="col-lg-12">
                                <div class="form-group">
                                    <label class="form-control-label">SMS Tutarı <small>Her Gönderimde Kullanıcıdan
                                            Kesilecek Tutar</small> </label>
                                    <input class="form-control" type="number" min="0.00" max="10000.00" step="0.01"
                                           name="tutar" placeholder="SMS Tutarı" value="<?= $siteayar->sms_tutar; ?>">
                                </div>
                            </div>
                        </div>

                        <div class="form-layout-footer">
                            <button type="submit" class="btn btn-success">Güncelle</button>
                        </div><!-- form-layout-footer -->
                    </div>
                </form>
            </div>
        </div>
    </div><!-- br-section-wrapper -->
</div><!-- br-pagebody -->