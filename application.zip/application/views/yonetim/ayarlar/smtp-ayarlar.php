<?php
$siteayar = ayarlar();
if (!empty($siteayar->header1degisen)) {
    $birlestir = implode(",", json_decode($siteayar->header1degisen));
}
?>
<div class="br-pageheader">
    <nav class="breadcrumb pd-0 mg-0 tx-12">
        <a class="breadcrumb-item" href="<?= base_url(admin_url()) ?>">Kontrol Paneli</a>
        <span class="breadcrumb-item active">SMTP Ayarları</span>
    </nav>
</div><!-- br-pageheader -->
<div class="br-pagetitle">
    <i class="fas fa-cogs fa-4x"></i>
    <div>
        <h4>SMTP Ayarları</h4>
        <p class="mg-b-0">SMTP Ayarlarını Buradan Yapabilirsiniz.</p>
    </div>
</div><!-- d-flex -->

<div class="br-pagebody">
    <div class="br-section-wrapper">
        <div class="tab-content">
            <div id="smtp" class="tab-pane fade in active show">
                <form action="<?php echo base_url(admin_url() . "smtpayar"); ?>" method="post">
                    <div class="form-layout form-layout-1">
                        <div class="row mg-b-25">
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label class="form-control-label">SMTP Host </label>
                                    <input class="form-control" type="text" name="host" placeholder="SMTP Host"
                                           value="<?= $siteayar->smtp_host; ?>">
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label class="form-control-label">SMTP Kullanıcı </label>
                                    <input class="form-control" type="mail" name="kullanici"
                                           placeholder="SMTP Kullanıcı" value="<?= $siteayar->smtp_mail; ?>">
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label class="form-control-label">SMTP Şifre </label>
                                    <input class="form-control" type="password" name="sifre" placeholder="SMTP Şifre"
                                           value="<?= $siteayar->smtp_sifre; ?>">
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label class="form-control-label">SMTP Port <small><code>Varsayılan :
                                                465</code></small></label>
                                    <input class="form-control" type="number" name="port" placeholder="SMTP Port"
                                           value="<?= $siteayar->smtp_port; ?>">
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="form-group">
                                    <label class="form-control-label">Alıcıya Görünecek E-Posta Adresi </label>
                                    <input class="form-control" type="mail" name="gomail"
                                           placeholder="Alıcıya Görünecek E-Posta Adresi"
                                           value="<?= $siteayar->smtp_gomail; ?>">
                                </div>
                            </div>

                        </div>

                        <div class="form-layout-footer">
                            <button type="submit" class="btn btn-success">Güncelle</button>
                        </div><!-- form-layout-footer -->
                    </div>
                </form>
            </div>
        </div>
    </div><!-- br-section-wrapper -->
</div><!-- br-pagebody -->