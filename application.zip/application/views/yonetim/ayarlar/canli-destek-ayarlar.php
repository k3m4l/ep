<?php
$siteayar = ayarlar();
if (!empty($siteayar->header1degisen)) {
    $birlestir = implode(",", json_decode($siteayar->header1degisen));
}
?>
<div class="br-pageheader">
    <nav class="breadcrumb pd-0 mg-0 tx-12">
        <a class="breadcrumb-item" href="<?= base_url(admin_url()) ?>">Kontrol Paneli</a>
        <span class="breadcrumb-item active">Canlı Destek Ayarları</span>
    </nav>
</div><!-- br-pageheader -->
<div class="br-pagetitle">
    <i class="fas fa-cogs fa-4x"></i>
    <div>
        <h4>Canlı Destek Ayarları</h4>
        <p class="mg-b-0">Canlı Destek Ayarlarını Buradan Yapabilirsiniz.</p>
    </div>
</div><!-- d-flex -->

<div class="br-pagebody">
    <div class="br-section-wrapper">
        <div class="tab-content">
            <div id="canlidestek" class="tab-pane fade in active show">
                <form action="<?php echo base_url("yonetim_controller/canlidestek"); ?>" method="post"
                      enctype="multipart/form-data">
                    <div class="form-layout form-layout-1">
                        <div class="row mg-b-25">
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label class="form-control-label">Jivo Canlı Destek</label>
                                    <textarea name="canli_destek_jivo"
                                              class="form-control"><?= $siteayar->canli_destek_jivo ?></textarea>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label class="form-control-label">Tawk.To Canlı Destek</label>
                                    <textarea name="canli_destek_tawk"
                                              class="form-control"><?= $siteayar->canli_destek_tawk ?></textarea>
                                </div>
                            </div>
                        </div>

                        <div class="form-layout-footer">
                            <button type="submit" class="btn btn-success">Güncelle</button>
                        </div><!-- form-layout-footer -->
                    </div>
                </form>
            </div>
        </div>
    </div><!-- br-section-wrapper -->
</div><!-- br-pagebody -->
<script>
    $(document).ready(function () {
        CKEDITOR.replace('bankano');
    });
</script>