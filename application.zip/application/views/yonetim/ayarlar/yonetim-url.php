<?php
$siteayar = ayarlar();
if (!empty($siteayar->header1degisen)) {
    $birlestir = implode(",", json_decode($siteayar->header1degisen));
}
?>
<div class="br-pageheader">
    <nav class="breadcrumb pd-0 mg-0 tx-12">
        <a class="breadcrumb-item" href="<?= base_url(admin_url()) ?>">Kontrol Paneli</a>
        <span class="breadcrumb-item active">Yönetim Paneli URL</span>
    </nav>
</div><!-- br-pageheader -->
<div class="br-pagetitle">
    <i class="fas fa-cogs fa-4x"></i>
    <div>
        <h4>Yönetim Paneli URL</h4>
        <p class="mg-b-0">Yönetim Paneli URL Ayarını Buradan Yapabilirsiniz.</p>
    </div>
</div><!-- d-flex -->

<div class="br-pagebody">
    <div class="br-section-wrapper">
        <div class="tab-content">
            <div id="yonetim" class="tab-pane fade in active show">
                <form action="<?php echo base_url(admin_url() . "yonetimurl"); ?>" method="post">
                    <div class="form-layout form-layout-1">
                        <div class="row mg-b-25">
                            <div class="col-lg-12">
                                <div class="form-group">
                                    <label class="form-control-label">Yönetim Paneli URL <span
                                            class="tx-danger">*</span> <small><code>Lütfen Özel Karakter
                                                Kullanmayın! Örnek : admin</code></small></label>
                                    <input class="form-control" type="text" name="yonetim"
                                           placeholder="Yönetim Paneli URL" value="<?= safadmin_url() ?>">
                                </div>
                            </div>
                        </div>

                        <div class="form-layout-footer">
                            <button type="submit" class="btn btn-success">Güncelle</button>
                        </div><!-- form-layout-footer -->
                    </div>
                </form>
            </div>
        </div>
    </div><!-- br-section-wrapper -->
</div><!-- br-pagebody -->
