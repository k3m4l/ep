<?php
$siteayar = ayarlar();
if (!empty($siteayar->header1degisen)) {
    $birlestir = implode(",", json_decode($siteayar->header1degisen));
}
?>
<div class="br-pageheader">
    <nav class="breadcrumb pd-0 mg-0 tx-12">
        <a class="breadcrumb-item" href="<?= base_url(admin_url()) ?>">Kontrol Paneli</a>
        <span class="breadcrumb-item active">Giriş Reklam Ayarları</span>
    </nav>
</div><!-- br-pageheader -->
<div class="br-pagetitle">
    <i class="fas fa-cogs fa-4x"></i>
    <div>
        <h4>Giriş Reklam Ayarları</h4>
        <p class="mg-b-0">Giriş Reklam Ayarlarını Buradan Yapabilirsiniz.</p>
    </div>
</div><!-- d-flex -->

<div class="br-pagebody">
    <div class="br-section-wrapper">
        <div class="tab-content">
            <div id="reklam" class="tab-pane fade in active show">
                <form action="<?php echo base_url(admin_url() . "reklamayar"); ?>" method="post">
                    <div class="form-layout form-layout-1">
                        <div class="row mg-b-25">
                            <div class="col-lg-12">
                                <div class="form-group">
                                    <label class="form-control-label">Reklam Başlığı </label>
                                    <input class="form-control" type="text" name="reklam_baslik"
                                           value="<?= $siteayar->reklam_baslik; ?>">
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="form-group">
                                    <label class="form-control-label">İçerik </label>
                                    <textarea class="form-control"
                                              name="reklam_icerik"><?= $siteayar->reklam_icerik; ?></textarea>
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <label class="form-control-label"> Durum <span class="tx-danger">*</span></label>
                                <select class="form-control select2-show-search" name="status" required="">
                                    <option <?php if ($siteayar->reklam_durum == 1) {
                                        echo "selected";
                                    } ?> value="1">Aktif
                                    </option>
                                    <option <?php if ($siteayar->reklam_durum == 0) {
                                        echo "selected";
                                    } ?> value="0">Pasif
                                    </option>
                                </select>
                            </div>
                        </div>

                        <div class="form-layout-footer">
                            <button type="submit" class="btn btn-success">Güncelle</button>
                        </div><!-- form-layout-footer -->
                    </div>
                </form>
            </div>
        </div>
    </div><!-- br-section-wrapper -->
</div><!-- br-pagebody -->
<script>
    $(document).ready(function () {
        CKEDITOR.replace('bankano');
    });
</script>