<?php
$siteayar = ayarlar();
if (!empty($siteayar->header1degisen)) {
    $birlestir = implode(",", json_decode($siteayar->header1degisen));
}
?>
<div class="br-pageheader">
    <nav class="breadcrumb pd-0 mg-0 tx-12">
        <a class="breadcrumb-item" href="<?= base_url(admin_url()) ?>">Kontrol Paneli</a>
        <span class="breadcrumb-item active">Sub Header Ayarları</span>
    </nav>
</div><!-- br-pageheader -->
<div class="br-pagetitle">
    <i class="fas fa-cogs fa-4x"></i>
    <div>
        <h4>Sub Header Ayarları</h4>
        <p class="mg-b-0">Sub Header Ayarlarını Buradan Yapabilirsiniz.</p>
    </div>
</div><!-- d-flex -->

<div class="br-pagebody">
    <div class="br-section-wrapper">
        <div class="tab-content">
            <script>
                function duzenlec(id) {
                    $.ajax({
                        type: "POST",
                        url: "<?=base_url("yonetim_controller/getsubhd")?>",
                        data: {id: id},
                        dataType: "json",
                        success: function (result) {
                            var res = result[0]; // İlk öğeyi alıyoruz
                            $("#duzenlebtn").removeClass("d-none");
                            $("#eklebtn").addClass("d-none");

                            $("#idu").val(res.id);
                            $("#baslik").val(res.baslik);
                            $("#link").val(res.link);
                            $("#subform").attr("action", "<?=base_url(admin_url() . "updsub")?>");
                        }
                    });
                }

                function silst(id) {
                    $.ajax({
                        type: "POST",
                        url: "<?=base_url("yonetim_controller/deletesubhd")?>",
                        data: {id: id},
                        success: function (result) {
                            console.log("Reloading");
                            window.location.reload();
                        }
                    });
                }
            </script>
            <div id="subheader" class="tab-pane fade in active show mb-3 mt-3">
                <div class="row justify-content-center align-items-center">
                    <div class="col-lg-4 col-md-12 col-12 mb-3 mt-3">
                        <form id="subform" action="<?php echo base_url(admin_url() . "addsub"); ?>" method="post">
                            <div class="form-layout form-layout-1">
                                <div class="">
                                    <input type="hidden" id="idu" name="subid" value="">
                                    <div class="col-lg-12">
                                        <div class="form-group">
                                            <label class="form-control-label">Başlık <span
                                                    class="tx-danger">*</span></label>
                                            <input class="form-control" type="text" id="baslik" name="baslik"
                                                   placeholder="Başlık giriniz." value="">
                                        </div>
                                    </div>
                                    <div class="col-lg-12">
                                        <div class="form-group">
                                            <label class="form-control-label">Link <span
                                                    class="tx-danger">*</span></label>
                                            <input class="form-control" type="text" id="link" name="link"
                                                   placeholder="Link giriniz." value="">
                                        </div>
                                    </div>
                                </div>

                                <div class="form-layout-footer">
                                    <button type="submit" id="eklebtn" class="btn btn-success">Ekle</button>
                                    <button type="submit" id="duzenlebtn" class="btn btn-secondary d-none">Düzenle
                                    </button>
                                </div><!-- form-layout-footer -->
                            </div>
                        </form>
                    </div>
                    <div class="col-lg-8 col-md-12 col-12 mb-3 mt-3">
                        <div class="table-warper">
                            <table class="table table-custom">
                                <thead class="table table-custom-thead">
                                <tr>
                                    <th>ID</th>
                                    <th>Başlık</th>
                                    <th>Link</th>
                                    <th>Aksiyonlar</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php
                                $subhd = getsubheader();
                                ?>
                                <?php foreach ($subhd as $rsa): ?>
                                    <tr>
                                        <td><?= $rsa->id; ?></td>
                                        <td><?= $rsa->baslik; ?></td>
                                        <td><?= $rsa->link; ?></td>
                                        <td>
                                            <button class="btn btn-rounded btn-secondary"
                                                    onclick="duzenlec('<?= $rsa->id; ?>')"><i class="fas fa-edit"></i>
                                            </button>
                                        </td>
                                        <td>
                                            <button class="btn btn-rounded btn-danger" onclick="silst('<?= $rsa->id; ?>')">
                                                <i class="fas fa-trash"></i></button>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div><!-- br-section-wrapper -->
</div><!-- br-pagebody -->