<div class="br-pageheader">
    <nav class="breadcrumb pd-0 mg-0 tx-12">
        <a class="breadcrumb-item" href="<?= base_url(admin_url()) ?>">Kontrol Paneli</a>
        <span class="breadcrumb-item active">Header Ayarları</span>
    </nav>
</div>
<script>
    function duzenleID(id){
    $.ajax({
        type: "POST",
        url: "<?=base_url("yonetim_controller/getheader")?>",
        data: {id: id},
        dataType: "json",
        success: function(result) {
            var res = result[0]; // İlk öğeyi alıyoruz
            $("#duzenle").removeClass("d-none");
            $("#addButton").addClass("d-none");
            
            $("#headerid").val(res.id);
            $("#heading").val(res.heading);
            $("#icon").val(res.icon);
            $("#dropdown").val(res.dropdown);
            $("#link").val(res.link);
            $("#sira").val(res.sort);
            $("#gold").val(res.pop);
            $("#preview").attr("src", 'https://kemalellidort.com.tr/'+res.pngicon);
            $("#foro").attr("action", "<?=base_url("yonetim_controller/updateheader")?>");
        }
    });
    }
</script>

<div class="br-pagetitle">
    <i class="fas fa-cogs fa-4x"></i>
    <div>
        <h4>Header Ayarları</h4>
        <p class="mg-b-0">Sitenizin Header Kontrollerini Buradan Yapabilirsiniz.</p>
    </div>
</div>

<div class="br-pagebody">
    <div class="br-section-wrapper">
        <div class="row">
            <div class="col-lg-4 col-md-5">
                <form action="<?php echo base_url("yonetim_controller/createheader"); ?>" id="foro" method="post" enctype="multipart/form-data">
                    <input type="hidden" name="id" id="headerid" value="">
                    <div class="form-group">
                        <label for="heading">Başlık : </label>
                        <input type="text" class="form-control" name="heading" id="heading" placeholder="Başlık Giriniz" />
                    </div>
                    <div class="form-group">
                        <label for="icon">Icon : </label>
                        <input type="text" class="form-control" name="icon" id="icon" placeholder="Icon Giriniz" />
                        <small class="form-text text-muted pt-2">İkonları Görüntülemek için <a target="_blank" href="https://fontawesome.com/v5/search">Tıklayınız</a></small>
                    </div>
                    <div class="col-lg-12 mb-4">
                        <div class="form-group custom-file">
                            <img width="25%" id="preview" src="">
                        </div>
                    </div>
                    <div class="col-lg-12" style="margin-top: 29px;">
                        <div class="form-group custom-file">
                            <input type="file" class="custom-file-input" id="customFile2" name="file" accept=".png">
                            <label class="custom-file-label custom-file-label-primary" for="customFile2">Veya resim
                                Fotoğrafı <small>(min. 16-32px önerilir.)</small></label>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="icon">Sıra Numarası : </label>
                        <input type="text" class="form-control" name="sort" id="sira" placeholder="Sıra Numarası Giriniz" />
                        <small class="form-text text-muted pt-2">Aynı sıra numarasını birden çok kullanmak karışıklığa neden olur. Lütfen dikkatli kullanın</small>
                    </div>
                    <div class="form-group">
                        <label for="dropdown">Dropdown Main: </label>
                        <select class="form-control" id="dropdown" name="drp">
                            <option value="1">Aktif</option>
                            <option value="0">Deaktif</option>
                        </select>
                        <small class="form-text text-muted pt-2">Aktif ederseniz bu element bir dropdown hizmeti görür.</small>
                    </div>
                    <div class="form-group">
                        <label for="dropdown">Özel Renk (Altın Rengi): </label>
                        <select class="form-control" id="gold" name="gold">
                            <option value="1">Aktif</option>
                            <option value="0">Deaktif</option>
                        </select>
                        <small class="form-text text-muted pt-2">Aktif ederseniz bu element turuncu şekilde parlar.</small>
                    </div>
                    <div class="form-group">
                        <label for="link">Link : </label>
                        <input name="link" type="text" class="form-control" id="link" placeholder="Link Giriniz" />
                    </div>
                    <div class="form-group mb-0 text-right">
                        <button id="duzenle" type="submit" name="duzenlebuton" class="btn btn-secondary d-none">Düzenle</button>
                        <button id="addButton" type="submit" name="eklebuton" class="btn btn-primary">Ekle</button>
                    </div>
                 </form>
            </div>
            <div class="col-lg-8 col-md-5">
                <table class="table">
                  <thead>
                    <tr>
                      <th>ID</th>
                      <th scope="col">Sıra Numarası</th>
                      <th scope="col">Başlık</th>
                      <th scope="col">Icon</th>
                      <th scope="col">Dropdown</th>
                      <th>Link</th>
                      <th></th>
                      <th></th>
                    </tr>
                  </thead>
                  <tbody>
                     <?php 
                        $headers = getheaders();
                     ?>
                    <?php foreach($headers as $rh):?>
                    <tr>
                        <form method="post" action="<?=base_url("yonetim_controller/removeheader")?>" enctype="multipart/form-data">

                      <?php
                        $drp = "Evet";
                        if($rh->dropdown == 0){
                            $drp = "Hayır";
                        }
                        
                      ?>
                      <input type="hidden" name="id" value="<?=$rh->id;?>">
                      <th><?=$rh->id;?></th>
                      <th scope="row"><?=$rh->sort;?></th>
                      <td><?=$rh->heading;?></td>
                            <?php if (empty($rh->pngicon)) { ?>
                                <td><i class="<?=$rh->icon;?>"></i></td>
                            <?php } else { ?>
                                <td><img src="<?php echo base_url($rh->pngicon) ?>" width="85%" alt=""></td>
                            <?php } ?>
                      <td><?=$drp;?></td>
                      <td><?=$rh->link;?></td>
                      <td><button type="button" class="btn btn-rounded btn-secondary" onclick="duzenleID('<?=$rh->id;?>')"><i class="fas fa-edit"></i></button></td>
                      <td><button type="submit" class="btn btn-rounded btn-danger" onclick="return confirm('Emin misin? Geri dönüşü olmaz.')"><i class="fas fa-trash"></i></button></td>
                      </form>
                    </tr>
                    <?php endforeach;?>
                  </tbody>
                </table>
            </div>
        </div>
        
    </div>
</div>