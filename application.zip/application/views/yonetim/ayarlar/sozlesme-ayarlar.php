<?php
$siteayar = ayarlar();
if (!empty($siteayar->header1degisen)) {
    $birlestir = implode(",", json_decode($siteayar->header1degisen));
}
?>
<div class="br-pageheader">
    <nav class="breadcrumb pd-0 mg-0 tx-12">
        <a class="breadcrumb-item" href="<?= base_url(admin_url()) ?>">Kontrol Paneli</a>
        <span class="breadcrumb-item active">Sözleşme Ayarları</span>
    </nav>
</div><!-- br-pageheader -->
<div class="br-pagetitle">
    <i class="fas fa-cogs fa-4x"></i>
    <div>
        <h4>Sözleşme Ayarları</h4>
        <p class="mg-b-0">Sözleşme Ayarlarını Buradan Yapabilirsiniz.</p>
    </div>
</div><!-- d-flex -->

<div class="br-pagebody">
    <div class="br-section-wrapper">
        <div class="tab-content">
            <div id="sozlesmeler" class="tab-pane fade in active show">
                <form action="<?php echo base_url("yonetim_controller/sozlesmeler"); ?>" method="post"
                      enctype="multipart/form-data">
                    <div class="form-layout form-layout-1">
                        <div class="row mg-b-25">

                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label class="form-control-label">Hesap Oluştur Hizmet Koşul Sayfa URL <span
                                            class="tx-danger">*</span></label>
                                    <input class="form-control" type="text" name="hizmet_kosulu"
                                           placeholder="Hesap Oluştur Hizmet Koşul Sayfa URL"
                                           value="<?= $siteayar->hizmet_kosulu; ?>">
                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label class="form-control-label">Hesap Oluştur Hizmet Politikası Sayfa URL <span
                                            class="tx-danger">*</span></label>
                                    <input class="form-control" type="text" name="hizmet_sozlesmesi"
                                           placeholder="Hesap Oluştur Hizmet Politikası Sayfa URL"
                                           value="<?= $siteayar->hizmet_sozlesmesi; ?>">
                                </div>
                            </div>
                            <?php if (1 == 2){ ?>
                            <div class="col-lg-12">
                                <div class="form-group">
                                    <label class="form-control-label">Başvuru Sözleşmesi Sayfa URL <span
                                            class="tx-danger">*</span></label>
                                    <input class="form-control" type="text" name="gizlilik_politikasi"
                                           placeholder="Başvuru Sözleşmesi Sayfa URL"
                                           value="<?= $siteayar->gizlilik_politikasi; ?>">
                                </div>
                            </div>
                            <?php } ?>

                        </div>

                        <div class="form-layout-footer">
                            <button type="submit" class="btn btn-success">Güncelle</button>
                        </div><!-- form-layout-footer -->
                    </div>
                </form>



            </div>
        </div>
    </div><!-- br-section-wrapper -->
</div><!-- br-pagebody -->