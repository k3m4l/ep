<?php
$siteayar = ayarlar();
if (!empty($siteayar->header1degisen)) {
    $birlestir = implode(",", json_decode($siteayar->header1degisen));
}
?>
<div class="br-pageheader">
    <nav class="breadcrumb pd-0 mg-0 tx-12">
        <a class="breadcrumb-item" href="<?= base_url(admin_url()) ?>">Kontrol Paneli</a>
        <span class="breadcrumb-item active">Footer Ayarları</span>
    </nav>
</div><!-- br-pageheader -->
<div class="br-pagetitle">
    <i class="fas fa-cogs fa-4x"></i>
    <div>
        <h4>Footer Ayarları</h4>
        <p class="mg-b-0">Footer Ayarlarını Buradan Yapabilirsiniz.</p>
    </div>
</div><!-- d-flex -->

<div class="br-pagebody">
    <div class="br-section-wrapper">
        <div class="tab-content">
            <div id="footer" class="tab-pane fade in active show">
                <form action="<?php echo base_url(admin_url() . "footerayar"); ?>" method="post">
                    <div class="form-layout form-layout-1">
                        <h5>Google Analytics</h5>
                        <div class="row mg-b-25">
                            <div class="col-lg-12">
                                <div class="form-group">
                                    <label class="form-control-label">Google Analytics Kodu <span
                                            class="tx-danger">*</span></label>
                                    <textarea class="form-control" name="analytics" placeholder="Google Analytics Kodu"
                                              rows="8"><?= $siteayar->analytics; ?></textarea>
                                </div>
                            </div>
                        </div>
                        <hr>
                        <h5>İletişim Ayarları <small><code>İletişim Sayfasında Geçerlidir!</code></small></h5>
                        <div class="row mg-b-25">
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label class="form-control-label">Telefon Numarası <span class="tx-danger">*</span></label>
                                    <input class="form-control" type="number" name="tel" placeholder="Telefon Numarası"
                                           value="<?= $siteayar->iletisim_tel; ?>">
                                </div>
                            </div>
                            <?php if (1 == 2) { ?>
                            <div class="col-lg-4">
                                <div class="form-group">
                                    <label class="form-control-label">Sabit Telefon <span
                                            class="tx-danger">*</span></label>
                                    <input class="form-control" type="number" name="sabittel"
                                           placeholder="Sabit Telefon" value="<?= $siteayar->iletisim_sabit; ?>">
                                </div>
                            </div>
                            <?php } ?>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label class="form-control-label">E-Posta Adresi <span
                                            class="tx-danger">*</span></label>
                                    <input class="form-control" type="mail" name="mail" placeholder="E-Posta Adresi"
                                           value="<?= $siteayar->iletisim_mail; ?>">
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="form-group">
                                    <label class="form-control-label">Adres <span class="tx-danger">*</span></label>
                                    <input class="form-control" type="text" name="adres" placeholder="Adres"
                                           value="<?= $siteayar->adres; ?>">
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="form-group">
                                    <label class="form-control-label">Harita <span class="tx-danger">*</span></label>
                                    <input class="form-control" type="text" name="harita" placeholder="Harita"
                                           value="<?= $siteayar->harita; ?>">
                                </div>
                            </div>
                        </div>
                        <h5>Sosyal Medya Ayarları</h5>
                        <div class="row mg-b-25">
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label class="form-control-label">Facebook</label>
                                    <input class="form-control" type="text" name="facebook" placeholder="Facebook"
                                           value="<?= $siteayar->facebook; ?>">
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label class="form-control-label">Twitter</label>
                                    <input class="form-control" type="text" name="twitter" placeholder="Twitter"
                                           value="<?= $siteayar->twitter; ?>">
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label class="form-control-label">Instagram</label>
                                    <input class="form-control" type="text" name="instagram" placeholder="Instagram"
                                           value="<?= $siteayar->instagram; ?>">
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label class="form-control-label">Discord</label>
                                    <input class="form-control" type="text" name="discord" placeholder="Discord"
                                           value="<?= $siteayar->discord; ?>">
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="form-group">
                                    <label class="form-control-label">Adres <span class="tx-danger">*</span></label>
                                    <input class="form-control" type="text" name="adres" placeholder="Adres"
                                           value="<?= $siteayar->adres; ?>">
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="form-group">
                                    <label class="form-control-label">Harita <span class="tx-danger">*</span></label>
                                    <input class="form-control" type="text" name="harita" placeholder="Harita"
                                           value="<?= $siteayar->harita; ?>">
                                </div>
                            </div>
                        </div>
                        <h5>Copyright Ayarı</h5>
                        <div class="row mg-b-25">
                            <div class="col-lg-12">
                                <div class="form-group">
                                    <label class="form-control-label">Copyright Yazısı <span class="tx-danger">*</span></label>
                                    <input class="form-control" type="text" name="copyright"
                                           placeholder="Copyright Yazısı" value="<?= $siteayar->copyright; ?>">
                                </div>
                            </div>
                        </div>
                        <h5>Footer Uyarı Mesajı</h5>
                        <div class="row mg-b-25">
                            <div class="col-lg-12">
                                <div class="form-group">
                                    <label class="form-control-label">Footer Uyarı Mesajı <span
                                            class="tx-danger">*</span></label>
                                    <input class="form-control" type="text" name="footer_uyari"
                                           placeholder="Footer Uyarı Mesajı" value="<?= $siteayar->footer_uyari; ?>">
                                </div>
                            </div>
                        </div>
                        <div class="form-layout-footer">
                            <button type="submit" class="btn btn-success">Güncelle</button>
                        </div><!-- form-layout-footer -->
                    </div>
                </form>
            </div>
        </div>
    </div><!-- br-section-wrapper -->
</div><!-- br-pagebody -->
<script>
    $(document).ready(function () {
        CKEDITOR.replace('bankano');
    });
</script>