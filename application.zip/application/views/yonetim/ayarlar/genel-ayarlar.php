<?php
$siteayar = ayarlar();
if (!empty($siteayar->header1degisen)) {
    $birlestir = implode(",", json_decode($siteayar->header1degisen));
}
?>
<div class="br-pageheader">
    <nav class="breadcrumb pd-0 mg-0 tx-12">
        <a class="breadcrumb-item" href="<?= base_url(admin_url()) ?>">Kontrol Paneli</a>
        <span class="breadcrumb-item active">Site Ayarları</span>
    </nav>
</div><!-- br-pageheader -->
<div class="br-pagetitle">
    <i class="fas fa-cogs fa-4x"></i>
    <div>
        <h4>Genel Ayarlar</h4>
        <p class="mg-b-0">Site Genel Ayarlarını Buradan Yapabilirsiniz.</p>
    </div>
</div><!-- d-flex -->

<div class="br-pagebody">
    <div class="br-section-wrapper">
        <div class="tab-content">
            <div id="anasayfa" class="tab-pane fade in active show">
                <form action="<?php echo base_url("yonetim_controller/site_foto"); ?>" method="post"
                      enctype="multipart/form-data">
                    <div class="form-layout form-layout-1">
                        <div class="row mg-b-25">
                            <?php if (1 == 2) { ?>
                            <div class="col-lg-12 mb-4">
                                <div class="form-group custom-file">
                                    <img width="250" src="<?= base_url($siteayar->site_foto) ?>">
                                </div>
                            </div>
                            <div class="col-lg-12" style="margin-top: 29px;">
                                <div class="form-group custom-file">
                                    <input type="file" class="custom-file-input" id="customFile2" name="file"
                                           accept=".png">
                                    <label class="custom-file-label custom-file-label-primary" for="customFile2">Site
                                        Fotoğrafı <small>(png)</small></label>
                                </div>
                            </div>
                            <?php } ?>

                            <div class="col-lg-12">
                                <div class="form-group">
                                    <label class="form-control-label">Header Başlık <small>(Maks. 500
                                            Karakter)</small><span class="tx-danger">*</span></label>
                                    <input class="form-control" type="text" name="header_baslik"
                                           placeholder="Header Başlık" value="<?= $siteayar->header_baslik; ?>">
                                </div>
                            </div>

                            <div class="col-lg-12">
                                <div class="form-group">
                                    <label class="form-control-label">Header Açıklama <small>(Maks. 500
                                            Karakter)</small><span class="tx-danger">*</span></label>
                                    <input class="form-control" type="text" name="header_aciklama"
                                           placeholder="Header Açıklama" value="<?= $siteayar->header_aciklama; ?>">
                                </div>
                            </div>
                            <?php if (1 == 2) { ?>
                                <div class="col-lg-12">
                                    <div class="form-group">
                                        <label class="form-control-label">Header Keyword <small>(Maks. 500
                                                Karakter)</small><span class="tx-danger">*</span></label>
                                        <input class="form-control" type="text" name="keyword"
                                               placeholder="Header Keyword"
                                               value="<?= $siteayar->site_keyw; ?>">
                                    </div>
                                </div>
                            <?php } ?>

                            <div class="col-lg-12">
                                <div class="form-group">
                                    <label class="form-control-label">Header Keyword<span
                                                class="tx-danger"> *</span></label>
                                    <input name="keyword" value="<?= $siteayar->site_keyw; ?>" autofocus>
                                </div>
                            </div>
                            <script>
                                // The DOM element you wish to replace with Tagify
                                var input = document.querySelector('input[name="keyword"]');

                                // initialize Tagify on the above input node reference
                                new Tagify(input)
                            </script>


                            <div class="col-lg-12">
                                <div class="form-group">
                                    <label class="form-control-label">Footer Açıklama <small>(Maks. 250
                                            Karakter)</small><span class="tx-danger">*</span></label>
                                    <input class="form-control" type="text" name="footer_aciklama"
                                           placeholder="Footer Açıklama" value="<?= $siteayar->footer_aciklama; ?>">
                                </div>
                            </div>
                            <?php if (1 == 2) { ?>
                            <div class="form-group col-md-12">
                                <label class="form-label">Ürün Kategorisi <small>(Anasayfa'da listelenecek ürün
                                        kategorileri)</small></label>
                                <select class="form-control sayfa_kategori" id="sayfa_kategori" data-width="100%"
                                        name="sayfa_kategori[]" multiple="multiple" required>
                                    <?php foreach (fetchCategoryTree() as $cl) { ?>
                                        <option value="<?php echo $cl["id"] ?>"><?php echo $cl["name"]; ?></option>
                                    <?php } ?>
                                </select>
                            </div>
                            <?php } ?>

                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label class="form-control-label">Havale SMS <span
                                                class="tx-danger">*</span></label>
                                    <select name="havale_sms" class="form-control">
                                        <option value="1" <?= $siteayar->havale_sms == 1 ? 'selected' : '' ?>>Aktif
                                        </option>
                                        <option value="0" <?= $siteayar->havale_sms == 0 ? 'selected' : '' ?>>Pasif
                                        </option>
                                    </select>
                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label class="form-control-label">Para Çekme Limiti<span class="tx-danger">*</span></label>
                                    <input class="form-control" type="number" name="para_cekme_limit"
                                           placeholder="Para Çekme Limiti" value="<?= $siteayar->para_cekme_limit; ?>">
                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label class="form-control-label">Ürün Anasayfa Reklam Ücreti <small>(Günlük
                                            Ücret)</small><span class="tx-danger">*</span></label>
                                    <input class="form-control" type="number" step="any" name="anasayfa_urun_reklam"
                                           placeholder="Ürün Anasayfa Reklam Ücreti"
                                           value="<?= $siteayar->anasayfa_urun_reklam; ?>">
                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label class="form-control-label">Ürün Kategori Reklam Ücreti <small>(Günlük
                                            Ücret)</small><span class="tx-danger">*</span></label>
                                    <input class="form-control" type="number" step="any" name="kategori_urun_reklam"
                                           placeholder="Ürün Kategori Reklam Ücreti"
                                           value="<?= $siteayar->kategori_urun_reklam; ?>">
                                </div>
                            </div>
                            <?php if (1 == 2) { ?>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label class="form-control-label">Renk Değişimi<span
                                                class="tx-danger">*</span></label>
                                    <select class="form-control" type="text" name="renk_durum">
                                        <option value="1" <?php if ("1" == $siteayar->renk_durum) {
                                            echo 'selected';
                                        } ?>>Aktif
                                        </option>
                                        <option value="2" <?php if ("2" == $siteayar->renk_durum) {
                                            echo 'selected';
                                        } ?>>Pasif
                                        </option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label class="form-control-label">Varsayılan Renk<span
                                                class="tx-danger">*</span></label>
                                    <select class="form-control" type="text" name="renk_varsayilan">
                                        <option value="1" <?php if ("1" == $siteayar->renk_varsayilan) {
                                            echo 'selected';
                                        } ?>>Açık Renk
                                        </option>
                                        <option value="2" <?php if ("2" == $siteayar->renk_varsayilan) {
                                            echo 'selected';
                                        } ?>>Koyu Renk
                                        </option>
                                    </select>
                                </div>
                            </div>
                            <?php } ?>
                            <?php if (1 == 2) { ?>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label class="form-control-label">Slider 1<span class="tx-danger">*</span></label>
                                        <select class="form-control" type="text" name="slider1">
                                            <option value="">Seçiniz</option>
                                            <?php $kategoriler = kategoriler_yonetim(); ?>
                                            <?php if ($kategoriler) { ?>
                                                <?php foreach ($kategoriler as $key) { ?>
                                                    <option value="<?= $key->kategori_id ?>" <?php if ($key->kategori_id == $siteayar->slider1) {
                                                        echo 'selected';
                                                    } ?>><?= $key->kategori_ad ?></option>
                                                <?php }
                                            } ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label class="form-control-label">Slider 2<span class="tx-danger">*</span></label>
                                        <select class="form-control" type="text" name="slider2">
                                            <option value="">Seçiniz</option>
                                            <?php $kategoriler = kategoriler_yonetim(); ?>
                                            <?php if ($kategoriler) { ?>
                                                <?php foreach ($kategoriler as $key) { ?>
                                                    <option value="<?= $key->kategori_id ?>" <?php if ($key->kategori_id == $siteayar->slider2) {
                                                        echo 'selected';
                                                    } ?>><?= $key->kategori_ad ?></option>
                                                <?php }
                                            } ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label class="form-control-label">Slider 3<span class="tx-danger">*</span></label>
                                        <select class="form-control" type="text" name="slider3">
                                            <option value="">Seçiniz</option>
                                            <?php $kategoriler = kategoriler_yonetim(); ?>
                                            <?php if ($kategoriler) { ?>
                                                <?php foreach ($kategoriler as $key) { ?>
                                                    <option value="<?= $key->kategori_id ?>" <?php if ($key->kategori_id == $siteayar->slider3) {
                                                        echo 'selected';
                                                    } ?>><?= $key->kategori_ad ?></option>
                                                <?php }
                                            } ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label class="form-control-label">Slider 4<span class="tx-danger">*</span></label>
                                        <select class="form-control" type="text" name="slider4">
                                            <option value="">Seçiniz</option>
                                            <?php $kategoriler = kategoriler_yonetim(); ?>
                                            <?php if ($kategoriler) { ?>
                                                <?php foreach ($kategoriler as $key) { ?>
                                                    <option value="<?= $key->kategori_id ?>" <?php if ($key->kategori_id == $siteayar->slider4) {
                                                        echo 'selected';
                                                    } ?>><?= $key->kategori_ad ?></option>
                                                <?php }
                                            } ?>
                                        </select>
                                    </div>
                                </div>
                            <?php } ?>
                            <div class="col-lg-12">
                                <div class="form-group">
                                    <label class="form-control-label">Mesaj Detay Kayan Yazı<span
                                                class="tx-danger">*</span></label>
                                    <input type="text" class="form-control" name="mesaj_detay_kayan_yazi"
                                           value="<?= $siteayar->mesaj_detay_kayan_yazi ?? '' ?>">
                                </div>
                            </div>
                        </div>

                        <div class="form-layout-footer">
                            <button type="submit" class="btn btn-success">Güncelle</button>
                        </div><!-- form-layout-footer -->
                    </div>
                </form>
            </div>
        </div>
    </div><!-- br-section-wrapper -->
</div><!-- br-pagebody -->