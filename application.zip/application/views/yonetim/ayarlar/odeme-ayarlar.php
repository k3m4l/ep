<?php
$siteayar = ayarlar();
if (!empty($siteayar->header1degisen)) {
    $birlestir = implode(",", json_decode($siteayar->header1degisen));
}
?>
<div class="br-pageheader">
    <nav class="breadcrumb pd-0 mg-0 tx-12">
        <a class="breadcrumb-item" href="<?= base_url(admin_url()) ?>">Kontrol Paneli</a>
        <span class="breadcrumb-item active">Ödeme Yöntemleri</span>
    </nav>
</div><!-- br-pageheader -->
<div class="br-pagetitle">
    <i class="fas fa-cogs fa-4x"></i>
    <div>
        <h4>Ödeme Yöntemleri</h4>
        <p class="mg-b-0">Ödeme Yöntemleri Ayarlarını Buradan Yapabilirsiniz.</p>
    </div>
</div><!-- d-flex -->

<div class="br-pagebody">
    <div class="br-section-wrapper">
        <div class="tab-content">
            <div id="odemeyontemleri" class="tab-pane fade in active show">
                <form action="<?php echo base_url("yonetim_controller/odeme_yontemleri"); ?>" method="post"
                      enctype="multipart/form-data">
                    <div class="form-layout form-layout-1">
                        <div class="row mg-b-25">
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label class="form-control-label">Iyzico API <span
                                            class="tx-danger">*</span></label>
                                    <input class="form-control" type="text" name="iyzico_api" placeholder="Iyzico API"
                                           value="<?= $siteayar->iyzico_api; ?>">
                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label class="form-control-label">Iyzico Secret <span
                                            class="tx-danger">*</span></label>
                                    <input class="form-control" type="text" name="iyzico_secret"
                                           placeholder="Iyzico Secret" value="<?= $siteayar->iyzico_secret; ?>">
                                </div>
                            </div>


                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label class="form-control-label">Iyzico Durum <span
                                            class="tx-danger">*</span></label>
                                    <input class="form-control" type="text" name="iyzico_durum"
                                           placeholder="Iyzico durum" value="<?= $siteayar->iyzico_durum; ?>">
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label class="form-control-label">Iyzico Komisyon <span class="text-danger">*</span></label>
                                    <input class="form-control" type="text" name="iyzico_komisyon"
                                           placeholder="Iyzico Komisyon" value="<?= $siteayar->iyzico_komisyon ?>">
                                </div>
                            </div>


                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label class="form-control-label">PayTR Merchant ID <span class="tx-danger">*</span></label>
                                    <input class="form-control" type="text" name="paytr_merchant_id"
                                           placeholder="paytr merchant id "
                                           value="<?= $siteayar->paytr_merchant_id; ?>">
                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label class="form-control-label">PayTR API <span class="tx-danger">*</span></label>
                                    <input class="form-control" type="text" name="paytr_api" placeholder="Paytr API"
                                           value="<?= $siteayar->paytr_api; ?>">
                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label class="form-control-label">PayTR Secret <span
                                            class="tx-danger">*</span></label>
                                    <input class="form-control" type="text" name="paytr_secret"
                                           placeholder="paytr Secret" value="<?= $siteayar->paytr_secret; ?>">
                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label class="form-control-label">PayTR Durum <span
                                            class="tx-danger">*</span></label>
                                    <input class="form-control" type="text" name="paytr_durum" placeholder="paytr durum"
                                           value="<?= $siteayar->paytr_durum; ?>">
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label class="form-control-label">PayTR Komisyon <span class="text-danger">*</span></label>
                                    <input class="form-control" type="text" name="paytr_komisyon"
                                           placeholder="PayTR Komisyon" value="<?= $siteayar->paytr_komisyon ?>">
                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label class="form-control-label">WeePay Bayi ID <span
                                            class="tx-danger">*</span></label>
                                    <input class="form-control" type="text" name="weepay_bayiId"
                                           placeholder="WeePay Bayi ID " value="<?= $siteayar->weepay_bayiId; ?>">
                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label class="form-control-label">WeePay API Key<span
                                            class="tx-danger">*</span></label>
                                    <input class="form-control" type="text" name="weepay_api"
                                           placeholder="WeePay API Key" value="<?= $siteayar->weepay_api; ?>">
                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label class="form-control-label">WeePay Secret <span
                                            class="tx-danger">*</span></label>
                                    <input class="form-control" type="text" name="weepay_secret"
                                           placeholder="WeePay Secret" value="<?= $siteayar->weepay_secret; ?>">
                                </div>
                            </div>


                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label class="form-control-label">WeePay Durum <span
                                            class="tx-danger">*</span></label>
                                    <input class="form-control" type="text" name="weepay_durum"
                                           placeholder="weepay durum" value="<?= $siteayar->weepay_durum; ?>">
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label class="form-control-label">WeePay Komisyon <span class="text-danger">*</span></label>
                                    <input class="form-control" type="text" name="weepay_komisyon"
                                           placeholder="Weepay Komisyon" value="<?= $siteayar->weepay_komisyon ?>">
                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label class="form-control-label">Stripe API Key<span
                                            class="tx-danger">*</span></label>
                                    <input class="form-control" type="text" name="stripe_api"
                                           placeholder="Stripe API Key" value="<?= $siteayar->stripe_api; ?>">
                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label class="form-control-label">Stripe Secret <span
                                            class="tx-danger">*</span></label>
                                    <input class="form-control" type="text" name="stripe_secret"
                                           placeholder="Stripe Secret" value="<?= $siteayar->stripe_secret; ?>">
                                </div>
                            </div>


                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label class="form-control-label">Stripe Durum <span
                                            class="tx-danger">*</span></label>
                                    <input class="form-control" type="text" name="stripe_durum"
                                           placeholder="Stripe durum" value="<?= $siteayar->stripe_durum; ?>">
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label class="form-control-label">Stripe Komisyon <span class="text-danger">*</span></label>
                                    <input class="form-control" type="text" name="stripe_komisyon"
                                           placeholder="Stripe Komisyon" value="<?= $siteayar->stripe_komisyon ?>">
                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label class="form-control-label">Vallet Username<span
                                            class="tx-danger">*</span></label>
                                    <input class="form-control" type="text" name="vallet_username"
                                           placeholder="Vallet Username" value="<?= $siteayar->vallet_username; ?>">
                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label class="form-control-label">Vallet Password <span
                                            class="tx-danger">*</span></label>
                                    <input class="form-control" type="text" name="vallet_password"
                                           placeholder="Vallet Password" value="<?= $siteayar->vallet_password; ?>">
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label class="form-control-label">Vallet ShopCode <span
                                            class="tx-danger">*</span></label>
                                    <input class="form-control" type="text" name="vallet_shopCode"
                                           placeholder="Vallet ShopCode" value="<?= $siteayar->vallet_shopCode; ?>">
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label class="form-control-label">Vallet Hash <span
                                            class="tx-danger">*</span></label>
                                    <input class="form-control" type="text" name="vallet_hash"
                                           placeholder="Vallet Hash" value="<?= $siteayar->vallet_hash; ?>">
                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label class="form-control-label">Vallet durum <span
                                            class="tx-danger">*</span></label>
                                    <input class="form-control" type="text" name="vallet_durum"
                                           placeholder="Vallet durum" value="<?= $siteayar->vallet_durum; ?>">
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label class="form-control-label">Vallet Komisyon <span class="text-danger">*</span></label>
                                    <input class="form-control" type="text" name="vallet_komisyon"
                                           placeholder="Vallet Komisyon" value="<?= $siteayar->vallet_komisyon ?>">
                                </div>
                            </div>

                        </div>

                        <div class="form-layout-footer">
                            <button type="submit" class="btn btn-success">Güncelle</button>
                        </div><!-- form-layout-footer -->
                    </div>
                </form>
            </div>
        </div>
    </div><!-- br-section-wrapper -->
</div><!-- br-pagebody -->