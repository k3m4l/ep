<div class="br-pageheader">
    <nav class="breadcrumb pd-0 mg-0 tx-12">
        <a class="breadcrumb-item" href="<?= base_url(admin_url()) ?>">Kontrol Paneli</a>
        <span class="breadcrumb-item active">Header(Dropdown) Ayarları</span>
    </nav>
</div>
<script>
    function duzenleID(id){
        $.ajax({
            type: "POST",
            url: "<?=base_url("yonetim_controller/getdropdown")?>",
            data: {id: id},
            dataType: "json",
            success: function(result) {
                var res = result[0]; // İlk öğeyi alıyoruz
                $("#updateForm").removeClass("d-none");
                $("#createForm").addClass("d-none");

                $("#drpidedit").val(res.id);
                $("#headingedit").val(res.heading);
                $("#hdredit").val(res.mainid);
                $("#linkedit").val(res.link);
                $("#siraedit").val(res.sort);
                $("#oldimg").val(res.img);
                $("#previewedit").attr('src', '<?=base_url();?>/uploads/img/' + res.img);
            }
        });
    }
</script>
<div class="br-pagetitle">
    <i class="fas fa-cogs fa-4x"></i>
    <div>
        <h4>Header(Dropdown) Ayarları</h4>
        <p class="mg-b-0">Sitenizin Header(Dropdown) Kontrollerini Buradan Yapabilirsiniz.</p>
    </div>
</div>

<div class="br-pagebody">
    <div class="br-section-wrapper">
        <div class="row">
            <div class="col-lg-4 col-md-5">
                <form action="<?php echo base_url("yonetim_controller/createdropdown"); ?>" class="" id="createForm" method="post" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="heading">Başlık : </label>
                        <input type="text" class="form-control" name="heading" id="heading" placeholder="Başlık Giriniz" />
                    </div>
                    <div class="form-group custom-file">
                        <img width="250" id="preview" src="">
                    </div>
                    <div class="form-group custom-file">
                        <input type="file" class="custom-file-input" id="customFile2" name="file" accept=".png">
                        <label class="custom-file-label custom-file-label-primary" for="customFile2">Resim Desteklenen format
                            <small>(png Minimum 250x250 Önerilir)</small></label>
                    </div>

                    <div class="form-group">
                        <label for="icon">Sıra Numarası : </label>
                        <input type="text" class="form-control" name="sort" id="sira" placeholder="Sıra Numarası Giriniz" />
                        <small class="form-text text-muted pt-2">Aynı sıra numarasını birden çok kullanmak karışıklığa neden olur. Lütfen dikkatli kullanın</small>
                    </div>
                    <div class="form-group">
                        <label for="hdr">Header: </label>
                        <select class="form-control" id="hdr" name="hdr">
                            <?php
                                $headers = getheaderswhere(1);
                            ?>
                            <?php foreach ($headers as $rheader):?>
                            <option value="<?=$rheader->id;?>"><?=$rheader->heading;?> #<?=$rheader->id;?></option>
                            <?php endforeach;?>
                        </select>
                        <small class="form-text text-muted pt-2">Seçilen header bir dropdown ailesinde ise özellik çalışır.</small>
                    </div>
                    <div class="form-group">
                        <label for="link">Link : </label>
                        <input name="link" type="text" class="form-control" id="link" placeholder="Link Giriniz" />
                    </div>
                    <div class="form-group mb-0 text-right">
                        <button id="addButton" type="submit" name="eklebuton" class="btn btn-primary">Ekle</button>
                    </div>
                </form>
                <!--Edit Form-->
                <form action="<?php echo base_url(admin_url() . "update-dropdown"); ?>" id="updateForm" method="post" enctype="multipart/form-data" class="d-none">
                    <input type="hidden" name="id" id="drpidedit" value="">
                    <div class="form-group">
                        <label for="heading">Başlık : </label>
                        <input type="text" class="form-control" name="heading" id="headingedit" placeholder="Başlık Giriniz" />
                    </div>
                    <div class="form-group custom-file">
                        <img width="64" id="previewedit" src="">
                    </div>
                    <div class="form-group custom-file">
                        <input type="file" class="custom-file-input" id="customFile2" name="file" accept=".png">
                        <label class="custom-file-label custom-file-label-primary" for="customFile2">Resim Desteklenen format
                            <small>(png Minimum 250x250 Önerilir)</small></label>
                        <input type="hidden" id="oldimg" name="oldimg" value="">
                    </div>

                    <div class="form-group">
                        <label for="icon">Sıra Numarası : </label>
                        <input type="text" class="form-control" name="sort" id="siraedit" placeholder="Sıra Numarası Giriniz" />
                        <small class="form-text text-muted pt-2">Aynı sıra numarasını birden çok kullanmak karışıklığa neden olur. Lütfen dikkatli kullanın</small>
                    </div>
                    <div class="form-group">
                        <label for="hdr">Header: </label>
                        <select class="form-control" id="hdredit" name="hdr">
                            <?php
                            $headers = getheaderswhere(1);
                            ?>
                            <?php foreach ($headers as $rheader):?>
                                <option value="<?=$rheader->id;?>"><?=$rheader->heading;?> #<?=$rheader->id;?></option>
                            <?php endforeach;?>
                        </select>
                        <small class="form-text text-muted pt-2">Seçilen header bir dropdown ailesinde ise özellik çalışır.</small>
                    </div>
                    <div class="form-group">
                        <label for="link">Link : </label>
                        <input name="link" type="text" class="form-control" id="linkedit" placeholder="Link Giriniz" />
                    </div>
                    <div class="form-group mb-0 text-right">
                        <button id="duzenle" type="submit" name="duzenlebuton" class="btn btn-secondary">Düzenle</button>
                    </div>
                </form>
            </div>
            <div class="col-lg-8 col-md-5">
                <script>
                    $(document).ready( function () {
                        $('#uwus').DataTable();
                    } );
                </script>
                <table id="uwus" class="table dataTable">
                    <thead>
                    <tr>
                        <th>ID</th>
                        <th scope="col">Sıra Numarası</th>
                        <th scope="col">Başlık</th>
                        <th scope="col">Resim</th>
                        <th scope="col">Header ID</th>
                        <th>Link</th>
                        <th></th>
                        <th></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    $drop = getdropdowns();
                    ?>
                    <?php foreach($drop as $rh):?>
                        <tr>
                            <th><?=$rh->id;?></th>
                            <th scope="row"><?=$rh->sort;?></th>
                            <td><?=$rh->heading;?></td>
                            <td><a href="<?=$rh->img;?>" target="_blank">Tıkla</a></td>
                            <td><?=$rh->mainid;?></td>
                            <td><?=$rh->link;?></td>
                            <td><button class="btn btn-rounded btn-secondary" onclick="duzenleID('<?=$rh->id;?>')"><i class="fas fa-edit"></i></button></td>
                            <td><button class="btn btn-rounded btn-danger" onclick="hdsil('<?=$rh->id;?>')"><i class="fas fa-trash"></i></button></td>
                        </tr>
                    <?php endforeach;?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>