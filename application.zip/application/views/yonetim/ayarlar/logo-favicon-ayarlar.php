<?php
$siteayar = ayarlar();
if (!empty($siteayar->header1degisen)) {
    $birlestir = implode(",", json_decode($siteayar->header1degisen));
}
?>
<div class="br-pageheader">
    <nav class="breadcrumb pd-0 mg-0 tx-12">
        <a class="breadcrumb-item" href="<?= base_url(admin_url()) ?>">Kontrol Paneli</a>
        <span class="breadcrumb-item active">Logo & Favicon Ayarları</span>
    </nav>
</div><!-- br-pageheader -->
<div class="br-pagetitle">
    <i class="fas fa-cogs fa-4x"></i>
    <div>
        <h4>Logo & Favicon Ayarları</h4>
        <p class="mg-b-0">Logo & Favicon Ayarlarını Buradan Yapabilirsiniz.</p>
    </div>
</div><!-- d-flex -->

<div class="br-pagebody">
    <div class="br-section-wrapper">
        <div class="tab-content">
            <div id="logo" class="tab-pane fade active show">
                <div class="form-layout form-layout-1">
                    <form action="<?php echo base_url(admin_url() . "ustlogo"); ?>" method="post" id="ustlogo"
                          enctype="multipart/form-data">
                        <div class="row mg-b-25">
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label class="form-control-label">Varsayılan Site Logosu <span
                                            class="tx-danger">*</span></label>
                                    <img width="150" src="<?= base_url($siteayar->site_logo) ?>">
                                </div>
                            </div>
                            <div class="col-lg-6" style="margin-top: 29px;">
                                <div class="form-group custom-file">
                                    <input type="file" class="custom-file-input" id="customFile2" name="file"
                                           accept=".png">
                                    <label class="custom-file-label custom-file-label-primary" for="customFile2">Site
                                        Üst Logo <small>(Sadece .png)</small></label>
                                </div>
                            </div><!-- col-4 -->
                        </div>

                        <div class="form-layout-footer">
                            <button type="submit" form="ustlogo" class="btn btn-success">Güncelle</button>
                        </div>
                    </form><!-- form-layout-footer -->
                    <br>
                    <form action="<?php echo base_url(admin_url() . "darklogo"); ?>" method="post" id="darklogo"
                          enctype="multipart/form-data">
                        <div class="row mg-b-25">
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label class="form-control-label">Varsayılan Dark Mod Site Logosu <span
                                            class="tx-danger">*</span></label>
                                    <img width="150" src="<?= base_url($siteayar->site_darklogo) ?>">
                                </div>
                            </div>
                            <div class="col-lg-6" style="margin-top: 29px;">
                                <div class="form-group custom-file">
                                    <input type="file" class="custom-file-input" id="customFile36" name="file"
                                           accept=".png">
                                    <label class="custom-file-label custom-file-label-primary" for="customFile36">Site
                                        Dark Logo <small>(Sadece .png)</small></label>
                                </div>
                            </div><!-- col-4 -->
                        </div>

                        <div class="form-layout-footer">
                            <button type="submit" form="darklogo" class="btn btn-success">Güncelle</button>
                        </div>
                    </form><!-- form-layout-footer -->
                    <br>
                    <form action="<?php echo base_url(admin_url() . "favicon"); ?>" method="post"
                          enctype="multipart/form-data">
                        <div class="row mg-b-25">
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label class="form-control-label">Varsayılan Favicon <span
                                            class="tx-danger">*</span></label>
                                    <img width="48" src="<?= base_url($siteayar->site_favicon) ?>">
                                </div>
                            </div>
                            <div class="col-lg-6" style="margin-top: 29px;">
                                <div class="form-group custom-file">
                                    <input type="file" class="custom-file-input" id="customFile2" name="file"
                                           accept=".png">
                                    <label class="custom-file-label custom-file-label-primary" for="customFile2">Site
                                        Favicon <small>(Sadece .png)</small></label>
                                </div>
                            </div><!-- col-4 -->
                        </div>

                        <div class="form-layout-footer">
                            <button type="submit" class="btn btn-success">Güncelle</button>
                        </div>
                    </form>

                    <br>
                    <form action="<?php echo base_url(admin_url() . "kategorilerarka"); ?>" method="post"
                          enctype="multipart/form-data">
                        <div class="row mg-b-25">
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label class="form-control-label">Kategoriler Arka Resim<span
                                            class="tx-danger">*</span></label>
                                    <img width="48" src="<?= base_url($siteayar->site_kategorilerarka) ?>">
                                </div>
                            </div>
                            <div class="col-lg-6" style="margin-top: 29px;">
                                <div class="form-group custom-file">
                                    <input type="file" class="custom-file-input" id="customFile2" name="file"
                                           accept=".png">
                                    <label class="custom-file-label custom-file-label-primary" for="customFile2">Site
                                        Kategoriler <small>(Sadece .png)</small></label>
                                </div>
                            </div><!-- col-4 -->
                        </div>

                        <div class="form-layout-footer">
                            <button type="submit" class="btn btn-success">Güncelle</button>
                        </div>
                    </form>
                    <br>
                    <form action="<?php echo base_url(admin_url() . "destekarkaplan"); ?>" method="post"
                          id="destekarkaplan" enctype="multipart/form-data">
                        <div class="row mg-b-25">
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label class="form-control-label">Varsayılan Destek Arkaplanı <span
                                            class="tx-danger">*</span></label>
                                    <img width="150" src="<?= base_url($siteayar->destek_bg) ?>">
                                </div>
                            </div>
                            <div class="col-lg-6" style="margin-top: 29px;">
                                <div class="form-group custom-file">
                                    <input type="file" class="custom-file-input" id="customFile2" name="file"
                                           accept=".png">
                                    <label class="custom-file-label custom-file-label-primary" for="customFile2">Varsayılan
                                        Destek Arkaplanı <small>(Sadece .png)</small></label>
                                </div>
                            </div><!-- col-4 -->
                        </div>

                        <div class="form-layout-footer">
                            <button type="submit" form="destekarkaplan" class="btn btn-success">Güncelle</button>
                        </div>
                    </form>
                    <br>
                    <form action="<?php echo base_url(admin_url() . "faqarkaplan"); ?>" method="post"
                          id="faqarkaplan" enctype="multipart/form-data">
                        <div class="row mg-b-25">
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label class="form-control-label">Varsayılan FAQ Arkaplanı <span
                                                class="tx-danger">*</span></label>
                                    <img width="150" src="<?= base_url($siteayar->faq_bg) ?>">
                                </div>
                            </div>
                            <div class="col-lg-6" style="margin-top: 29px;">
                                <div class="form-group custom-file">
                                    <input type="file" class="custom-file-input" id="customFile2" name="file"
                                           accept=".png">
                                    <label class="custom-file-label custom-file-label-primary" for="customFile2">Varsayılan
                                        FAQ Arkaplanı <small>(Sadece .png)</small></label>
                                </div>
                            </div><!-- col-4 -->
                        </div>

                        <div class="form-layout-footer">
                            <button type="submit" form="faqarkaplan" class="btn btn-success">Güncelle</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div><!-- br-section-wrapper -->
</div><!-- br-pagebody -->