<div class="br-pageheader">
    <nav class="breadcrumb pd-0 mg-0 tx-12">
        <a class="breadcrumb-item" href="<?= base_url(admin_url()) ?>">Kontrol Paneli</a>
        <span class="breadcrumb-item active">Bakiye Yükleme Geçmişleri</span>
    </nav>
</div><!-- br-pageheader -->
<div class="br-pagetitle">
    <i class="fas fa-cart-plus fa-4x"></i>
    <div>
        <h4>Bakiye Yükleme Geçmişleri</h4>
    </div>
</div><!-- d-flex -->

<div class="br-pagebody">
    <div class="br-section-wrapper">
        <div class="table-wrapper table-responsive">
            <table id="datatable1" class="table display nowrap">
                <thead>
                <tr>
                    <th class="text-center">SİPARİŞ NO</th>
                    <th class="text-center">KULLANICI</th>
                    <th class="text-center">YÜKLENEN TUTAR</th>
                    <th class="text-center">ÖDEME YÖNTEMİ</th>
                    <th class="text-center">ÖDEME TÜRÜ</th>
                    <th class="text-center">DURUM</th>
                    <th class="text-center">SİPARİŞ ZAMANI</th>
                </tr>
                </thead>
                <tbody>
                <?php if ($bakiyeler) { ?>
                    <?php foreach ($bakiyeler as $key) { ?>
                        <tr>
                            <td class="text-center"><?= $key->bakiye_no ?></td>
                            <td class="text-center"><?=$key->kullanici_ad?></td>
                            <td class="text-center"><?= $key->bakiye_tutar ?>₺</td>
                            <td class="text-center"><?= !empty($key->odeme_tur) ? $key->odeme_tur : '-' ?></td>
                            <td class="text-center"><?= !empty($key->tur) ? $key->tur : '-' ?></td>
                            <td class="text-center">
                                <?php if ($key->bakiye_durum == 0) { ?>
                                    <a href="javascript:void(0)" data-url="<?php echo base_url(admin_url() . "bakiye-iptal/$key->bakiye_id"); ?>"
                                       class="btn btn-warning btn-with-icon cancel-btn btn-rounded">
                                        <div class="ht-40">
                                            <span class="icon fas fa-ban wd-40"><i class="fa fa-send"></i></span>
                                            <span class="pd-x-15">İptal</span>
                                        </div>
                                    </a>
                                <?php } elseif ($key->bakiye_durum == 1) { ?>
                                    <span class="badge badge-success badge-pill">Ödeme Onaylandı</span>
                                <?php } elseif ($key->bakiye_durum == 2) { ?>
                                    <span class="badge badge-danger badge-pill">Ödeme İptal Edildi</span>
                                <?php } ?>
                            </td>
                            <td class="text-center">
                                <span class="badge badge-success badge-pill"><?=date('d.m.Y H:i', strtotime($key->bakiye_tarih))?></span>
                            </td>
                        </tr>
                    <?php } ?>
                <?php } ?>
                </tbody>
            </table>
        </div><!-- table-wrapper -->
    </div><!-- br-section-wrapper -->
</div><!-- br-pagebody -->