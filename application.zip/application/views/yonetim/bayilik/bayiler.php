<div class="br-pageheader">
   <nav class="breadcrumb pd-0 mg-0 tx-12">
      <a class="breadcrumb-item" href="<?= base_url(admin_url()) ?>">Kontrol Paneli</a>
      <span class="breadcrumb-item active">TıklaCard Bayilik Başvuruları</span>
   </nav>
</div><!-- br-pageheader -->
<div class="br-pagetitle">
   <i class="fas fa-store fa-4x"></i>
   <div>
      <h4>TıklaCard Bayilik Başvuru</h4>
      <p class="mg-b-0">Başvuru Listesi</p>
   </div>
</div><!-- d-flex -->

<div class="br-pagebody">
   <div class="br-section-wrapper">
      <div class="table-wrapper">
         <table id="datatable1" class="table display table-responsive nowrap" style="min-width:100%">
            <thead>
               <tr>
                  <th class="text-center">#</th>
                  <th class="text-center">Kullanıcı Adı</th>
                  <th class="text-center">E-Posta</th>
                  <th class="text-center">Telefon</th>
                  <th class="text-center">İsim Soyisim</th>
                  <th class="text-center">Firma Ünvanı</th>
                  <th class="text-center">Website Linki</th>
                  <th class="text-center">Oyun İsmi</th>
                  <th class="text-center">Durum</th>
                  <th class="text-center">İşlem</th>
               </tr>
            </thead>
            <tbody>
               <?php if ($bayiler) { ?>
                  <?php $i = 0;
                  foreach ($bayiler as $key) {
                     $i++; ?>
                     <tr>
                        <td class="text-center"><?= $i ?></td>
                        <td class="text-center"><?= $key->kullanici_ad ?></td>
                        <td class="text-center"><?= $key->kullanici_mail ?></td>
                        <td class="text-center"><?= empty($key->telefon)?$key->kullanici_tel:$key->telefon; ?></td>
                        <td class="text-center"><?= $key->kullanici_isim . " " . $key->kullanici_soyisim ?></td>
                        <td class="text-center"><?= $key->firma_unvani ?></td>
                        <td class="text-center"><?= $key->website_linki ?></td>
                        <td class="text-center"><?= $key->oyun_ismi ?></td>
                        <td class="text-center">
                           <?php if ($key->durum == 0) { ?>
                              <span class="badge badge-warning badge-pill">Onay Bekliyor..</span>
                           <?php } elseif ($key->durum == 1) { ?>
                              <span class="badge badge-success badge-pill">Onaylandı</span>
                           <?php } elseif ($key->durum == 2) { ?>
                              <span class="badge badge-danger badge-pill">Onaylanmadı</span>
                           <?php } ?>
                        </td>
                        <td class="text-center">
                           <a href="<?= base_url(admin_url() . "bayilik-basvuru-onay/$key->id") ?>" class="btn btn-success btn-with-icon" title="Onayla">
                              <div class="ht-40">
                                 <span class="icon fa fa-check wd-40"><i class="fa fa-send"></i></span>
                              </div>
                           </a>
                           <a href="<?= base_url(admin_url() . "bayilik-basvuru-red/$key->id") ?>" class="btn btn-secondary btn-with-icon">
                              <div class="ht-40">
                                 <span class="icon fa fa-ban wd-40"><i class="fa fa-send"></i></span>
                              </div>
                           </a>
                           <a href="<?= base_url(admin_url() . "bayilik-basvuru-sil/$key->id") ?>" class="btn btn-danger btn-with-icon">
                              <div class="ht-40">
                                 <span class="icon far fa-trash-alt wd-40"><i class="fa fa-send"></i></span>
                              </div>
                           </a>
                        </td>
                     </tr>
                  <?php } ?>
               <?php } ?>
            </tbody>
         </table>
      </div><!-- table-wrapper -->
   </div><!-- br-section-wrapper -->
</div><!-- br-pagebody -->