<link rel="stylesheet" href="<?=base_url('assets/')?>css/dropzone.css">
<script src='<?=base_url('assets/')?>js/dropzone.js'></script>
<div class="br-pageheader">
	<nav class="breadcrumb pd-0 mg-0 tx-12">
		<a class="breadcrumb-item" href="<?=base_url(admin_url())?>">Kontrol Paneli</a>
		<a class="breadcrumb-item" href="<?=base_url(admin_url()."firmalar")?>">Firmalar</a>
		<span class="breadcrumb-item active"><?=$where->firma_ad?> - Firma Galeri</span>
	</nav>
</div><!-- br-pageheader -->
<div class="br-pagetitle">
	<i class="fas fa-map-marker-alt fa-2x"></i>
	<div>
		<h4><?=$where->firma_ad?> - Firma Galeri</h4>
		<p class="mg-b-0">Firmaya Galeri Ekle</p>
	</div>
</div><!-- d-flex -->

<div class="br-pagebody">
	<div class="br-section-wrapper">
		<div class="final-info margin-bottom-10" style="display: none;">
			<input class="form-control" type="text" id="uploaded_files" disabled="">
		</div>
		<form method="post" action="<?=base_url(admin_url())."firmagaleri/$where->firma_uniq"?>" enctype="multipart/form-data" class="dropzone" id="myAwesomeDropzone">
		</form>
		<button style="margin-top: 10px; margin-bottom: 20px;" type="button" class="btn btn-success" id="submit_dropzone_form">Yükle</button>


		<div class="row">
			<div class="col-md-12 margin-top-45">
				<table class="table">
					<tbody>
						<tr>
							<th>Fotoğraf</th>
							<th>İşlem</th>
						</tr>
						<?php if ($where->firma_galeri!="[]" && !empty($where->firma_galeri)) {?>
							<?php $galeri = json_decode($where->firma_galeri); ?>
							<?php if ($galeri) {?>
								<?php foreach ($galeri as $key => $value) { ?>
									<tr>
										<td><img width="150" src="<?=base_url("uploads/firma/galeri/".$value)?>"></td>
										<td><a href="javascript:void()" data-url="<?=base_url("galerisila/$where->firma_uniq/$key")?>" class="btn btn-danger remove-btn">Sil</a></td>
									</tr>
								<?php } ?>
							<?php } ?>
						<?php }else{ ?>
							<tr>
								<td colspan="2" align="center">Gösterilecek Galeri Bulunamadı!</td>
							</tr>
						<?php } ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>

<script>
	Dropzone.options.myAwesomeDropzone = {
		autoProcessQueue: false,
		uploadMultiple: true,
		parallelUploads:10,
		successmultiple:function(data,response){
			$(".final-info").show( 500 );
			$("#uploaded_files").val(response);
		},
		init: function() {
		//Submitting the form on button click
		var submitButton = document.querySelector("#submit_dropzone_form");
			myDropzone = this; // closure
			submitButton.addEventListener("click", function() {
			myDropzone.processQueue(); // Tell Dropzone to process all queued files.
		});
		}
	};
</script>
