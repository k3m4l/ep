<div class="br-pageheader">
  <nav class="breadcrumb pd-0 mg-0 tx-12">
    <a class="breadcrumb-item" href="<?=base_url(admin_url())?>">Kontrol Paneli</a>
    <span class="breadcrumb-item active">Onay Bekleyen Yorumlar</span>
  </nav>
</div><!-- br-pageheader -->
<div class="br-pagetitle">
  <i class="far fa-comments fa-2x"></i>
  <div>
    <h4>Onay Bekleyen Yorumlar</h4>
  </div>
</div><!-- d-flex -->

<div class="br-pagebody">
  <div class="br-section-wrapper">
    <div class="table-wrapper">
      <table id="datatable1" class="table display responsive nowrap">
        <thead>
          <tr>
            <th class="wd-15p text-center">YORUM YAPAN</th>
            <th class="wd-15p text-center">YORUM YAPILAN FİRMA</th>
            <th class="wd-15p text-center">YORUM</th>
            <th class="wd-15p text-center">YORUM PUAN</th>
            <th class="wd-15p text-center">YORUM DURUM</th>
            <th class="wd-15p text-center">YORUM ÖNEÇIKAR</th>
            <th class="wd-10p text-center">YORUM İŞLEM</th>
          </tr>
        </thead>
        <tbody>
          <?php $yorumlar = firmabyorumlar(); ?>
          <?php if ($yorumlar) { ?>
            <?php foreach ($yorumlar as $key) { ?>
              <tr>
                <td class="text-center"><?=$key->kullanici_isim." ".$key->kullanici_soyisim?></td>
                <td class="text-center"><?=$key->firma_ad?></td>
                <td class="text-center"><?=$key->yorum_detay?></td>
                <td class="text-center"><?=$key->yorum_puan?></td>
                <td class="text-center">
                  <label class="switch">
                    <input class="durum" data-url="<?=base_url(admin_url()."yorumdurum/$key->yorum_id")?>" type="checkbox" <?php if ($key->yorum_durum==1){ echo 'checked'; } ?>>
                    <span class="slider round"></span>
                  </label>
                </td>
                <td class="text-center">
                  <label class="switch">
                    <input class="durum" data-url="<?=base_url(admin_url()."yorumonecikart/$key->yorum_id")?>" type="checkbox" <?php if ($key->yorum_onecikart==1){ echo 'checked'; } ?>>
                    <span class="slider round"></span>
                  </label>
                </td>
                <td class="text-center">
                  <a href="<?=base_url("firma/$key->firma_seo")?>" target="_blank" class="btn btn-success btn-with-icon">
                    <div class="ht-40">
                      <span class="icon fas fa-eye wd-40"></span>
                    </div>
                  </a>
                  <a href="javascript:void(0)" data-url="<?=base_url(admin_url()."yorumsil/$key->yorum_id")?>" class="btn btn-danger btn-with-icon remove-btn">
                    <div class="ht-40">
                      <span class="icon far fa-trash-alt wd-40"><i class="fa fa-send"></i></span>
                      <span class="pd-x-15">Sil</span>
                    </div>
                  </a>
                </td>
              </tr>
            <?php } ?>
          <?php } ?>
        </tbody>
      </table>
    </div><!-- table-wrapper -->
  </div><!-- br-section-wrapper -->
</div><!-- br-pagebody -->