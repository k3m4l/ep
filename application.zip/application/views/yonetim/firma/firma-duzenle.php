<?php 
$kategoriler = kategoricek();
?>
<style type="text/css">
	#maps {
    width: 100%;
    height: 400px;
	}
</style>
<div class="br-pageheader">
	<nav class="breadcrumb pd-0 mg-0 tx-12">
		<a class="breadcrumb-item" href="<?=base_url(admin_url())?>">Kontrol Paneli</a>
		<a class="breadcrumb-item" href="<?=base_url(admin_url()."firmalar")?>">Firmalar</a>
		<span class="breadcrumb-item active"><?=$where->firma_ad?> - Firma Düzenle</span>
	</nav>
</div><!-- br-pageheader -->
<div class="br-pagetitle">
	<i class="fas fa-map-marker-alt fa-2x"></i>
	<div>
		<h4><?=$where->firma_ad?> - Firma Düzenle</h4>
		<p class="mg-b-0">Eklenen firmaları güncelleyebilirsiniz.</p>
	</div>
</div><!-- d-flex -->

<div class="br-pagebody">
	<div class="br-section-wrapper">
		<form action="<?=base_url(admin_url()."firmaduzenle/$where->firma_uniq"); ?>" method="post" enctype="multipart/form-data">

			<div class="form-layout form-layout-1">
				<div class="row mg-b-25">
					<div class="col-lg-4">
						<div class="form-group mg-b-10-force">
							<label class="form-control-label">Firma Durum <span class="tx-danger">*</span></label>
							<select class="form-control" name="durum">
								<option <?php if ($where->firma_durum==1) { echo "selected";} ?> value="1">Aktif</option>
								<option <?php if ($where->firma_durum==0) { echo "selected";} ?> value="0">Pasif</option>
							</select>
						</div>
					</div>
					<div class="col-lg-4">
						<div class="form-group mg-b-10-force">
							<label class="form-control-label">Firma Doğrulama <span class="tx-danger">*</span></label>
							<select class="form-control" name="dogrulama">
								<option <?php if ($where->firma_dogrulama==1) { echo "selected";} ?> value="1">Doğrulanmış</option>
								<option <?php if ($where->firma_dogrulama==0) { echo "selected";} ?> value="0">Doğrulanmamış</option>
							</select>
						</div>
					</div>
					<div class="col-lg-4">
						<div class="form-group mg-b-10-force">
							<label class="form-control-label">Popüler Firma <span class="tx-danger">*</span></label>
							<select class="form-control" name="populer">
								<option <?php if ($where->firma_populer==1) { echo "selected";} ?> value="1">Evet</option>
								<option <?php if ($where->firma_populer==0) { echo "selected";} ?> value="0">Hayır</option>
							</select>
						</div>
					</div>
					<div class="col-md-12"><small class="tx-danger">Aşağıdaki Alanları Boş Bıraktığınızda Otomatik Oluşturulmaktadır!</small></div>
					<div class="col-lg-4">
						<div class="form-group">
							<label class="form-control-label">Firma Title </label>
							<input class="form-control" type="text" name="title" placeholder="Firma Title.." value="<?=$where->firma_title?>" />
						</div>
					</div><!-- col-4 -->
					<div class="col-lg-4">
						<div class="form-group">
							<label class="form-control-label">Firma Keyword </label>
							<input class="form-control" type="text" name="keyw" placeholder="Firma Keyword.." value="<?=$where->firma_keyw?>" />
						</div>
					</div><!-- col-4 -->
					<div class="col-lg-4">
						<div class="form-group">
							<label class="form-control-label">Firma Açıklama </label>
							<input class="form-control" type="text" name="desc" placeholder="Firma Açıklama.." value="<?=$where->firma_desc?>" />
						</div>
					</div><!-- col-4 -->

				</div>
			</div>
			<div class="form-layout form-layout-1">
				<div class="row mg-b-25">
					<div class="col-lg-4">
						<div class="form-group">
							<label class="form-control-label">Firma Adı <span class="tx-danger">*</span></label>
							<input class="form-control" type="text" name="firmaad" placeholder="Firma Adı.." value="<?=$where->firma_ad?>" required="" />
						</div>
					</div><!-- col-4 -->
					<div class="col-lg-4">
						<div class="form-group mg-b-10-force">
							<label class="form-control-label">Kategoriler <span class="tx-danger">*</span></label>
							<select class="form-control" name="kategori">
								<?php foreach ($kategoriler as $key) { ?>
									<option <?php if ($where->kategori_id==$key->kategori_id) { echo "selected";} ?> value="<?=$key->kategori_id?>"><?=$key->kategori_ad?></option>
								<?php } ?>
							</select>
						</div>
					</div>
					<div class="col-lg-4">
						<div class="form-group">
							<label class="form-control-label">Firma Anahtar Kelimeler<span class="tx-danger">*</span></label>
							<input class="form-control" type="text" name="anahtar" placeholder="En fazla 15 tane anahtar kelime ekleyiniz.." value="<?=$where->firma_anahtar?>">
						</div>
					</div><!-- col-4 -->
					<div class="col-lg-12">
						<div class="form-group">
							<label class="form-control-label">Adres & Harita</label>
							<input id="searchInput" class="form-control controls" type="text" placeholder="Haritada ara.." value="<?=$where->firma_adres?>">
						</div>
					</div><!-- col-8 -->
					<div class="col-md-12">
						<div class="map" id="maps"></div>
					</div>

					<div class="col-md-12" id="form_area">
						<input type="hidden" name="adres" id="location" value="<?=$where->firma_adres?>">
						<input type="hidden" name="lat" id="lat" value="<?=$where->firma_lat?>">
						<input type="hidden" name="lng" id="lng" value="<?=$where->firma_lon?>">
					</div>

					<div class="col-lg-12" style="margin-top: 29px;">
						<label class="form-control-label">Firma Kapak Fotoğrafı</label>
						<img width="200" src="<?=base_url($where->firma_resim)?>">
						<div class="form-group custom-file" style="margin-top: 10px;">
							<input type="file" class="custom-file-input" id="customFile2" name="file" accept=".jpg, .jpeg">
							<label class="custom-file-label custom-file-label-primary" for="customFile2">Firma Kapak Fotoğrafı <small>(Sadece .jpg/.jpeg - İsteğe Bağlı)</small></label>
						</div>
					</div>


					<div class="col-lg-12">
						<div class="form-group">
							<label class="form-control-label">Firma Detay<span class="tx-danger">*</span></label>
							<textarea class="WYSIWYG form-control" name="tanitim" cols="40" rows="8" spellcheck="true" placeholder="Firma Tanıtım Yazısı" ><?=$where->firma_aciklama?></textarea>
						</div>
					</div><!-- col-4 -->

					<div class="col-lg-4">
						<div class="form-group">
							<label class="form-control-label">Telefon Numarası <span class="tx-danger">*</span></label>
							<input class="form-control" type="number" name="tel" placeholder="Örn : 05xxxxxxxxx" value="<?=$where->firma_tel?>">
						</div>
					</div><!-- col-4 -->

					<div class="col-lg-4">
						<div class="form-group">
							<label class="form-control-label">Web Site <span class="tx-danger">*</span></label>
							<input class="form-control" type="text" name="website" placeholder="Örn : https://siteadresi.com.tr" value="<?=$where->firma_website?>">
						</div>
					</div><!-- col-4 -->

					<div class="col-lg-4">
						<div class="form-group">
							<label class="form-control-label">E-Posta Adresi <span class="tx-danger">*</span></label>
							<input class="form-control" type="text" name="mail" placeholder="Örn : info@siteadresi.com.tr" value="<?=$where->firma_mail?>">
						</div>
					</div><!-- col-4 -->


					<div class="col-lg-4">
						<div class="form-group">
							<label class="form-control-label">Facebook <span class="tx-danger">*</span></label>
							<input class="form-control" type="text" name="facebook" placeholder="https://www.facebook.com/" value="<?=$where->firma_facebook?>">
						</div>
					</div><!-- col-4 -->

					<div class="col-lg-4">
						<div class="form-group">
							<label class="form-control-label">Twitter <span class="tx-danger">*</span></label>
							<input class="form-control" type="text" name="twitter" placeholder="https://www.twitter.com/" value="<?=$where->firma_twitter?>">
						</div>
					</div><!-- col-4 -->

					<div class="col-lg-4">
						<div class="form-group">
							<label class="form-control-label">İnstagram <span class="tx-danger">*</span></label>
							<input class="form-control" type="text" name="instagram" placeholder="https://instagram.com/" value="<?=$where->firma_instagram?>">
						</div>
					</div><!-- col-4 -->


					<div class="col-lg-12">
						<label class="form-control-label">Hizmetler <span class="tx-danger">*</span></label>
						<div class="row" id="pricing-list-container">
							<?php if ($where->firma_hizmetler) { ?>
							<?php $hizmet = json_decode($where->firma_hizmetler); ?>
							    <?php foreach ($hizmet as $key) { ?>
								   <div class="col-lg-12 pricing-list-item pricing-submenu" style="margin-top: 3px; margin-bottom: 3px;">
									   	<div class="row">
									   		<div class="col-md-11">
									   			<input class="form-control" type="text" name="hizmet[]" value="<?=$key?>" placeholder="Hizmet Adı"></div>
									   		<div class="col-md-1"><a class="delete" href="#"><i class="far fa-trash-alt"></i></a></div>
									   	</div>
								   </div>
								<?php } ?>
							<?php } ?>
						</div>
						<a style="margin-top: 10px;" href="#" class="btn btn-success button add-pricing-submenu">Yeni Hizmet Ekle</a>
					</div>



					<div class="col-lg-6" style="margin-top: 10px;">
						<div class="form-group mg-b-10-force">
							<label class="form-control-label">Hafta İçi Sabah <span class="tx-danger">*</span></label>
							<select class="form-control" name="haftaicisabah">
								<option label="Açılış Saati"></option>
								<option <?php if ($where->firma_his=="Kapalı") { echo "selected"; }?> value="Kapalı">Kapalı</option>
								<option <?php if ($where->firma_his=="24 Saat Açık") { echo "selected"; }?> value="24 Saat Açık">24 Saat Açık</option>
								<option <?php if ($where->firma_his=="06:00") { echo "selected"; }?> value="06:00">06:00</option>
								<option <?php if ($where->firma_his=="07:00") { echo "selected"; }?> value="07:00">07:00</option>
								<option <?php if ($where->firma_his=="08:00") { echo "selected"; }?> value="08:00">08:00</option>
								<option <?php if ($where->firma_his=="09:00") { echo "selected"; }?> value="09:00">09:00</option>
								<option <?php if ($where->firma_his=="10:00") { echo "selected"; }?> value="10:00">10:00</option>
								<option <?php if ($where->firma_his=="11:00") { echo "selected"; }?> value="11:00">11:00</option>
								<option <?php if ($where->firma_his=="12:00") { echo "selected"; }?> value="12:00">12:00</option>
								<option <?php if ($where->firma_his=="13:00") { echo "selected"; }?> value="13:00">13:00</option>
								<option <?php if ($where->firma_his=="14:00") { echo "selected"; }?> value="14:00">14:00</option>
								<option <?php if ($where->firma_his=="15:00") { echo "selected"; }?> value="15:00">15:00</option>
								<option <?php if ($where->firma_his=="16:00") { echo "selected"; }?> value="16:00">16:00</option>
								<option <?php if ($where->firma_his=="17:00") { echo "selected"; }?> value="17:00">17:00</option>
							</select>
						</div>
					</div>

					<div class="col-lg-6" style="margin-top: 10px;">
						<div class="form-group mg-b-10-force">
							<label class="form-control-label">Hafta İçi Akşam <span class="tx-danger">*</span></label>
							<select class="form-control" name="haftaiciaksam">
								<option label="Kapanış Saati"></option>
								<option <?php if ($where->firma_hia=="Kapalı") { echo "selected"; }?> value="Kapalı">Kapalı</option>
								<option <?php if ($where->firma_hia=="24 Saat Açık") { echo "selected"; }?> value="24 Saat Açık">24 Saat Açık</option>
								<option <?php if ($where->firma_hia=="06:00") { echo "selected"; }?> value="06:00">06:00</option>
								<option <?php if ($where->firma_hia=="07:00") { echo "selected"; }?> value="07:00">07:00</option>
								<option <?php if ($where->firma_hia=="08:00") { echo "selected"; }?> value="08:00">08:00</option>
								<option <?php if ($where->firma_hia=="09:00") { echo "selected"; }?> value="09:00">09:00</option>
								<option <?php if ($where->firma_hia=="10:00") { echo "selected"; }?> value="10:00">10:00</option>
								<option <?php if ($where->firma_hia=="11:00") { echo "selected"; }?> value="11:00">11:00</option>
								<option <?php if ($where->firma_hia=="12:00") { echo "selected"; }?> value="12:00">12:00</option>
								<option <?php if ($where->firma_hia=="13:00") { echo "selected"; }?> value="13:00">13:00</option>
								<option <?php if ($where->firma_hia=="14:00") { echo "selected"; }?> value="14:00">14:00</option>
								<option <?php if ($where->firma_hia=="15:00") { echo "selected"; }?> value="15:00">15:00</option>
								<option <?php if ($where->firma_hia=="16:00") { echo "selected"; }?> value="16:00">16:00</option>
								<option <?php if ($where->firma_hia=="17:00") { echo "selected"; }?> value="17:00">17:00</option>
								<option <?php if ($where->firma_hia=="18:00") { echo "selected"; }?> value="18:00">18:00</option>
								<option <?php if ($where->firma_hia=="19:00") { echo "selected"; }?> value="19:00">19:00</option>
								<option <?php if ($where->firma_hia=="20:00") { echo "selected"; }?> value="20:00">20:00</option>
								<option <?php if ($where->firma_hia=="21:00") { echo "selected"; }?> value="21:00">21:00</option>
								<option <?php if ($where->firma_hia=="22:00") { echo "selected"; }?> value="22:00">22:00</option>
								<option <?php if ($where->firma_hia=="23:00") { echo "selected"; }?> value="23:00">23:00</option>
								<option <?php if ($where->firma_hia=="00:00") { echo "selected"; }?> value="00:00">00:00</option>
							</select>
						</div>
					</div>

					<div class="col-lg-6">
						<div class="form-group mg-b-10-force">
							<label class="form-control-label">Hafta Sonu Sabah <span class="tx-danger">*</span></label>
							<select class="form-control" name="haftasonusabah">
								<option label="Açılış Saati"></option>
								<option <?php if ($where->firma_hss=="Kapalı") { echo "selected"; }?> value="Kapalı">Kapalı</option>
								<option <?php if ($where->firma_hss=="24 Saat Açık") { echo "selected"; }?> value="24 Saat Açık">24 Saat Açık</option>
								<option <?php if ($where->firma_hss=="06:00") { echo "selected"; }?> value="06:00">06:00</option>
								<option <?php if ($where->firma_hss=="07:00") { echo "selected"; }?> value="07:00">07:00</option>
								<option <?php if ($where->firma_hss=="08:00") { echo "selected"; }?> value="08:00">08:00</option>
								<option <?php if ($where->firma_hss=="09:00") { echo "selected"; }?> value="09:00">09:00</option>
								<option <?php if ($where->firma_hss=="10:00") { echo "selected"; }?> value="10:00">10:00</option>
								<option <?php if ($where->firma_hss=="11:00") { echo "selected"; }?> value="11:00">11:00</option>
								<option <?php if ($where->firma_hss=="12:00") { echo "selected"; }?> value="12:00">12:00</option>
								<option <?php if ($where->firma_hss=="13:00") { echo "selected"; }?> value="13:00">13:00</option>
								<option <?php if ($where->firma_hss=="14:00") { echo "selected"; }?> value="14:00">14:00</option>
								<option <?php if ($where->firma_hss=="15:00") { echo "selected"; }?> value="15:00">15:00</option>
								<option <?php if ($where->firma_hss=="16:00") { echo "selected"; }?> value="16:00">16:00</option>
								<option <?php if ($where->firma_hss=="17:00") { echo "selected"; }?> value="17:00">17:00</option>
							</select>
						</div>
					</div>

					<div class="col-lg-6">
						<div class="form-group mg-b-10-force">
							<label class="form-control-label">Hafta Sonu Akşam <span class="tx-danger">*</span></label>
							<select class="form-control" name="haftasonuaksam">
								<option label="Kapanış Saati"></option>
								<option <?php if ($where->firma_hsa=="Kapalı") { echo "selected"; }?> value="Kapalı">Kapalı</option>
								<option <?php if ($where->firma_hsa=="24 Saat Açık") { echo "selected"; }?> value="24 Saat Açık">24 Saat Açık</option>
								<option <?php if ($where->firma_hsa=="06:00") { echo "selected"; }?> value="06:00">06:00</option>
								<option <?php if ($where->firma_hsa=="07:00") { echo "selected"; }?> value="07:00">07:00</option>
								<option <?php if ($where->firma_hsa=="08:00") { echo "selected"; }?> value="08:00">08:00</option>
								<option <?php if ($where->firma_hsa=="09:00") { echo "selected"; }?> value="09:00">09:00</option>
								<option <?php if ($where->firma_hsa=="10:00") { echo "selected"; }?> value="10:00">10:00</option>
								<option <?php if ($where->firma_hsa=="11:00") { echo "selected"; }?> value="11:00">11:00</option>
								<option <?php if ($where->firma_hsa=="12:00") { echo "selected"; }?> value="12:00">12:00</option>
								<option <?php if ($where->firma_hsa=="13:00") { echo "selected"; }?> value="13:00">13:00</option>
								<option <?php if ($where->firma_hsa=="14:00") { echo "selected"; }?> value="14:00">14:00</option>
								<option <?php if ($where->firma_hsa=="15:00") { echo "selected"; }?> value="15:00">15:00</option>
								<option <?php if ($where->firma_hsa=="16:00") { echo "selected"; }?> value="16:00">16:00</option>
								<option <?php if ($where->firma_hsa=="17:00") { echo "selected"; }?> value="17:00">17:00</option>
								<option <?php if ($where->firma_hsa=="18:00") { echo "selected"; }?> value="18:00">18:00</option>
								<option <?php if ($where->firma_hsa=="19:00") { echo "selected"; }?> value="19:00">19:00</option>
								<option <?php if ($where->firma_hsa=="20:00") { echo "selected"; }?> value="20:00">20:00</option>
								<option <?php if ($where->firma_hsa=="21:00") { echo "selected"; }?> value="21:00">21:00</option>
								<option <?php if ($where->firma_hsa=="22:00") { echo "selected"; }?> value="22:00">22:00</option>
								<option <?php if ($where->firma_hsa=="23:00") { echo "selected"; }?> value="23:00">23:00</option>
								<option <?php if ($where->firma_hsa=="00:00") { echo "selected"; }?> value="00:00">00:00</option>
							</select>
						</div>
					</div>

				</div>

				<div class="form-layout-footer">
					<button type="submit" class="btn btn-info">Firma Güncelle</button>
					<a href="<?=base_url("firma/$where->firma_seo")?>" target="_blank" class="btn btn-success">Firma Görüntüle</a>
				</div><!-- form-layout-footer -->
			</div>
		</form><!-- form-layout -->
	</div>
</div>

<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCCKWWLQs2S3C0q-Qqp7m2nP-c0flEjA64&sensor=false&libraries=places"></script>


<script type="text/javascript">
	
	        function newMenuItem() {
            var newElem = $('div.pricing-list-item.pattern').first().clone();
            newElem.find('input').val('');
            newElem.appendTo('div#pricing-list-container');
        }
        if ($("div#pricing-list-container").is('*')) {
            $('.add-pricing-list-item').on('click', function(e) {
                e.preventDefault();
                newMenuItem();
            });
            $(document).on("click", "#pricing-list-container .delete", function(e) {
                e.preventDefault();
                $(this).parent().parent().remove();
            });
            $('.add-pricing-submenu').on('click', function(e) {
                e.preventDefault();
                var newElem = $('' +
                    '<div class="col-lg-12 pricing-list-item pricing-submenu" style="margin-top: 3px; margin-bottom: 3px;">' +
									   	'<div class="row">' +
									   		'<div class="col-md-11">' +
									   			'<input class="form-control" type="text" name="hizmet[]" placeholder="Hizmet Adı"></div>' +
									   		'<div class="col-md-1"><a class="delete" href="#"><i class="far fa-trash-alt"></i></a></div>' +
									   	'</div>' +
								   '</div>');
                newElem.appendTo('div#pricing-list-container');
            });
            $('div#pricing-list-container tbody').sortable({
                forcePlaceholderSize: true,
                forceHelperSize: false,
                placeholder: 'sortableHelper',
                zIndex: 999990,
                opacity: 0.6,
                tolerance: "pointer",
                start: function(e, ui) {
                    ui.placeholder.height(ui.helper.outerHeight());
                }
            });
        }
        var fieldUnit = $('.pricing-price').children('input').attr('data-unit');
        $('.pricing-price').children('input').before('<i class="data-unit">' + fieldUnit + '</i>');
        $("a.close").removeAttr("href").on('click', function() {
            function slideFade(elem) {
                var fadeOut = {
                    opacity: 0,
                    transition: 'opacity 0.5s'
                };
                elem.css(fadeOut).slideUp();
            }
            slideFade($(this).parent());
        });
</script>


<script type="text/javascript">
	function initialize() {
   var latlng = new google.maps.LatLng(<?=$where->firma_lat?>,<?=$where->firma_lon?>);
    var map = new google.maps.Map(document.getElementById('maps'), {
      center: latlng,
      zoom: 18
    });
    var marker = new google.maps.Marker({
      map: map,
      position: latlng,
      draggable: true,
      anchorPoint: new google.maps.Point(0, -29)
   });
    var input = document.getElementById('searchInput');
    var geocoder = new google.maps.Geocoder();
    var autocomplete = new google.maps.places.Autocomplete(input);
    autocomplete.bindTo('bounds', map);
    var infowindow = new google.maps.InfoWindow();   
    autocomplete.addListener('place_changed', function() {
        infowindow.close();
        marker.setVisible(false);
        var place = autocomplete.getPlace();
        if (!place.geometry) {
            window.alert("Autocomplete's returned place contains no geometry");
            return;
        }
  
        // If the place has a geometry, then present it on a map.
        if (place.geometry.viewport) {
            map.fitBounds(place.geometry.viewport);
        } else {
            map.setCenter(place.geometry.location);
            map.setZoom(17);
        }
       
        marker.setPosition(place.geometry.location);
        marker.setVisible(true);          
    
        bindDataToForm(place.formatted_address,place.geometry.location.lat(),place.geometry.location.lng());
        infowindow.setContent(place.formatted_address);
        infowindow.open(map, marker);
       
    });
    // this function will work on marker move event into map 
    google.maps.event.addListener(marker, 'dragend', function() {
        geocoder.geocode({'latLng': marker.getPosition()}, function(results, status) {
        if (status == google.maps.GeocoderStatus.OK) {
          if (results[0]) {        
              bindDataToForm(results[0].formatted_address,marker.getPosition().lat(),marker.getPosition().lng());
              infowindow.setContent(results[0].formatted_address);
              infowindow.open(map, marker);
          }
        }
        });
    });
}
function bindDataToForm(address,lat,lng){
   document.getElementById('location').value = address;
   document.getElementById('lat').value = lat;
   document.getElementById('lng').value = lng;
}
google.maps.event.addDomListener(window, 'load', initialize);
</script>