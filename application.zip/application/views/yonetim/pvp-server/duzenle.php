<div class="br-pageheader">
    <nav class="breadcrumb pd-0 mg-0 tx-12">
        <a class="breadcrumb-item" href="<?= base_url(admin_url()) ?>">Kontrol Paneli</a>
        <span class="breadcrumb-item active">Pvp Server Düzenle</span>
    </nav>
</div><!-- br-pageheader -->
<div class="br-pagetitle">
    <i class="far fa-images fa-4x"></i>
    <div>
        <h4>Pvp Server Düzenle</h4>
    </div>
</div><!-- d-flex -->

<div class="br-pagebody">
    <div class="br-section-wrapper">
        <form action="<?= base_url(admin_url() . "serverduzenle/".$server->id); ?>" method="post" enctype="multipart/form-data">
            <div class="form-layout form-layout-1">
                <div class="row mg-b-25">
                    <div class="col-lg-10" style="margin-top: 29px;">
                        <div class="form-group custom-file">
                            <input type="file" class="custom-file-input" id="customFile2" name="file" accept=".jpg, .jpeg .png">
                            <label class="custom-file-label custom-file-label-primary" for="customFile2">Fotoğrafı Yükleyiniz</label>
                        </div>

                    </div><!-- col-4 -->
                    <div class="col-lg-2">
                        <div class="form-group">
                            <label class="form-control-label">Fotoğraf</label>
                            <img class="br-panelupdate-img" src="<?php echo base_url($server->image) ?>" alt="">
                        </div>
                    </div><!-- col-8 -->
                    <div class="col-lg-4">
                        <div class="form-group">
                            <label class="form-control-label">Sırası</label>
                            <input class="form-control" type="number" name="sira" placeholder="Server Sırası" value="<?php echo $server->sira ?>">
                        </div>
                    </div><!-- col-8 -->
                    <div class="col-lg-4">
                        <div class="form-group">
                            <label class="form-control-label">Link Url <span class="tx-danger">*</span></label>
                            <input class="form-control" type="text" name="link" placeholder="Link Url" value="<?php echo $server->link ?>" required="">
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="form-group">
                            <label class="form-control-label">Server Durum <span class="tx-danger">*</span></label>
                            <select class="form-control" type="text" name="server_status" required="">
                                <option value="1" <?php echo $server->server_status == 1 ? 'selected' : '' ?>>Online</option>
                                <option value="2"  <?php echo $server->server_status == 2 ? 'selected' : '' ?>>Yakında</option>
                            </select>
                        </div>
                    </div><!-- col-4 -->
                    <div class="col-lg-6">
                        <label for="">Server</label>
                        <input class="form-control" type="text" name="server" value="<?php echo $server->server ?>" placeholder="Server" required="">
                    </div>
                    <div class="col-lg-6">
                        <label for="">Beta Tarihi</label>
                        <input class="form-control" type="date" name="beta_tarih" value="<?php echo $server->beta_tarih ?>" placeholder="Güvenlik">
                    </div>
                    <div class="col-lg-6 mt-4">
                        <label for="">Official Tarihi</label>
                        <input class="form-control" type="date" name="offical_tarih" value="<?php echo $server->offical_tarih ?>" placeholder="Bitiş Tarihi" required="">
                    </div>
                    <div class="col-lg-6 mt-4">
                        <label for="">Oyun Türü</label>
                        <input class="form-control" type="text" name="oyun_turu" value="<?php echo $server->oyun_turu ?>" placeholder="Oyun Türü" required="">
                    </div>
                </div>

                <div class="form-layout-footer mt-5">
                    <button type="submit" class="btn btn-info">Düzenle</button>
                </div><!-- form-layout-footer -->
            </div>
        </form><!-- form-layout -->
    </div>
</div>