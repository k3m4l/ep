<div class="br-pageheader">
    <nav class="breadcrumb pd-0 mg-0 tx-12">
        <a class="breadcrumb-item" href="<?=base_url(admin_url())?>">Kontrol Paneli</a>
        <span class="breadcrumb-item active">Pvp Serverlar</span>
    </nav>
</div><!-- br-pageheader -->
<div class="br-pagetitle">
    <i class="far fa-images fa-4x"></i>
    <div>
        <h4>Pvp Serverlar</h4>
    </div>
</div><!-- d-flex -->

<div class="br-pagebody">
    <div class="br-section-wrapper">
        <div class="table-wrapper">
            <table id="datatable1" class="table display responsive nowrap">
                <thead>
                <tr>
                    <th class="wd-15p text-center">#</th>
                    <th class="wd-15p text-center">Server</th>
                    <th class="wd-15p text-center">Server Resim</th>
                    <th class="wd-15p text-center">Server SIRA</th>
                    <th class="wd-10p text-center">Server İŞLEM</th>
                </tr>
                </thead>
                <tbody>
                <?php // $slider = slider(); ?>
                <?php if ($servers) { ?>
                    <?php $i=0; foreach ($servers as $key) { $i++; ?>
                        <tr>
                            <td class="text-center"><?=$i?></td>
                            <td class="text-center"><?=$key->server?></td>
                            <td class="text-center"><img width="50px" style="width: 50px" src="<?=base_url($key->image)?>"></td>
                            <td class="text-center"><?=$key->sira?></td>
                            <td class="text-center">
                                <a href="<?php echo base_url(admin_url()."pvp-server-duzenle/$key->id"); ?>" class="btn btn-warning btn-with-icon">
                                    <div class="ht-40">
                                        <span class="icon fas fa-edit wd-40"><i class="fa fa-send"></i></span>
                                        <span class="pd-x-15">Düzenle</span>
                                    </div>
                                </a>
                                <a href="javascript:void(0)" data-url="<?=base_url(admin_url()."serversil/$key->id")?>" class="btn btn-danger btn-with-icon remove-btn">
                                    <div class="ht-40">
                                        <span class="icon far fa-trash-alt wd-40"><i class="fa fa-send"></i></span>
                                        <span class="pd-x-15">Sil</span>
                                    </div>
                                </a>
                            </td>
                        </tr>
                    <?php } ?>
                <?php } ?>
                </tbody>
            </table>
        </div><!-- table-wrapper -->
    </div><!-- br-section-wrapper -->
</div><!-- br-pagebody -->