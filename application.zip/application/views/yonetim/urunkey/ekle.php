<div class="br-pageheader">
    <nav class="breadcrumb pd-0 mg-0 tx-12">
        <a class="breadcrumb-item" href="<?= base_url(admin_url()) ?>">Kontrol Paneli</a>
        <a class="breadcrumb-item" href="<?= base_url(admin_url() . 'urunler') ?>">Mağazalar</a>
        <?php if ($stock->id): ?>
        <span class="breadcrumb-item active">Key Düzenle</span>
        <?php else: ?>
        <span class="breadcrumb-item active">Key Ekle</span>
        <?php endif; ?>
    </nav>
</div><!-- br-pageheader -->
<div class="br-pagetitle">
    <i class="fas fa-store fa-4x"></i>
    <div>
        <?php if ($stock->id) : ?>
            <h4>Key Düzenle</h4>
        <?php else : ?>
            <h4>Key Ekle</h4>
        <?php endif; ?>
    </div>
</div><!-- d-flex -->

<div class="br-pagebody">
    <div class="br-section-wrapper">
        <form action="<?= base_url(admin_url() . "urun-key-havuzu/ekle/kayit") ?>" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="id" value="<?= $stock->id ?>">
            <div class="row">
                <div class="col-md-12">
                    <strong>Ürün</strong>
                    <select name="urun_id" class="form-control">
                        <?php foreach ($urunler as $urun) : ?>
                            <?php if ($urun->urun_id == $stock->urun_id) : ?>
                                <option value="<?= $urun->urun_id ?>" selected><?= $urun->urun_ad ?></option>
                            <?php else : ?>
                                <option value="<?= $urun->urun_id ?>"><?= $urun->urun_ad ?></option>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-12 mt-2">
                    <strong>İlgili Alan (E-PIN kodu vb.)</strong>
                    <textarea name="urun_key" class="form-control" cols="30" rows="10"><?= $stock->key ?></textarea>
                </div>
            </div>
            <!-- button -->
            <?php if ($stock->id) : ?>
                <button type="submit" class="btn btn-primary mt-2"> Güncelle</button>
            <?php else : ?>
                <button type="submit" class="btn btn-primary mt-2"> Ürün Ekle</button>
            <?php endif; ?>
        </form>
    </div>
</div>

<script>
    $('.durum').on('change', function() {
        if (this.value == 2) {
            $('.urun_iptal').show();
            $(".iptal").prop('required', true);
        } else {
            $('.urun_iptal').hide();
            $(".iptal").prop('required', false);
        }
    });

    /**
     * Dosya Seçme işlemleri
     */
    var es = document.getElementById('dosya');
    var vt = document.getElementById('vitrin');

    function getFileData(myFile) {
        var file = myFile.files[0];
        if (file) {
            var filename = file.name;
            $('.dosya_adi').html(filename);
            $('.dosya_size').html(bytesToSize(file.size));
            $('#dosya_goster').show();
        } else {
            $('.dosya_adi').html('');
            $('.dosya_size').html('');
            $('#dosya_goster').hide();
        }
    }

    function getPhotoData(myFile) {
        var file = myFile.files[0];
        if (file) {
            var filename = file.name;
            $('.resim_adi').html(filename);
            $('.resim_size').html(bytesToSize(file.size));
            $('#resim_goster').show();
        } else {
            $('.resim_adi').html('');
            $('.resim_size').html('');
            $('#resim_goster').hide();
        }
    }

    $(document).on('click', '#dosya_sil', function() {
        clearInputFile(es);
    });

    $(document).on('click', '#resim_sil', function() {
        clearInputPhoto(vt);
    });

    function clearInputFile(f) {
        if (f.value) {
            try {
                f.value = ''; //for IE11, latest Chrome/Firefox/Opera...
            } catch (err) {}
            if (f.value) { //for IE5 ~ IE10
                var form = document.createElement('form'),
                    ref = f.nextSibling;
                form.appendChild(f);
                form.reset();
                ref.parentNode.insertBefore(f, ref);
            }
            getFileData(f);
        }
    }

    function clearInputPhoto(f) {
        if (f.value) {
            try {
                f.value = ''; //for IE11, latest Chrome/Firefox/Opera...
            } catch (err) {}
            if (f.value) { //for IE5 ~ IE10
                var form = document.createElement('form'),
                    ref = f.nextSibling;
                form.appendChild(f);
                form.reset();
                ref.parentNode.insertBefore(f, ref);
            }
            getPhotoData(f);
        }
    }

    /**
     * Byte To MB Convert
     */
    function bytesToSize(bytes) {
        var sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
        if (bytes == 0) return '0 Byte';
        var i = parseInt(Math.floor(Math.log(bytes) / Math.log(1024)));
        return Math.round(bytes / Math.pow(1024, i), 2) + ' ' + sizes[i];
    }

    /**
     * Ürün Türü Select Event
     */
    $('#urun_turu').on('change', function() {
        if (this.value == 1) {
            $('.sanal_urun_bilgileri').hide();
            $('.indirilebilir').hide();
            $('.fiziksel').show();
            $("#sanal_urun_bilgileri").prop('required', false);
            $("#dosya").prop('required', false);
        } else if (this.value == 2) {
            $('.sanal_urun_bilgileri').show();
            $("#sanal_urun_bilgileri").prop('required', true);
            $("#dosya").prop('required', false);
            $('.indirilebilir').hide();
            $('.fiziksel').hide();
        } else if (this.value == 3) {
            $('.sanal_urun_bilgileri').hide();
            $('.indirilebilir').show();
            $("#dosya").prop('required', true);
            $("#sanal_urun_bilgileri").prop('required', false);
            $('.fiziksel').hide();
        } else {
            $('.sanal_urun_bilgileri').hide();
            $('.indirilebilir').hide();
            $('.fiziksel').hide();
            $("#sanal_urun_bilgileri").prop('required', false);
            $("#dosya").prop('required', false);
        }
    });

    /**
     * Komisyon Hesaplama
     */
    $(document).on("input paste focus", "#fiyat", function() {
        /* var fiyat = parseFloat($(this).val());
         if (!fiyat || fiyat == 0) {
             $('#kazanc').html('0.00 ₺');
         } else {
             var komisyon_bol = parseFloat(<?= $ayarlar->komisyon ?>) / 100;
             var komisyon_carp = parseFloat(fiyat * komisyon_bol).toFixed(2);
             var komisyom_topla = parseFloat(fiyat - komisyon_carp).toFixed(2);
             $('#kazanc').html(komisyom_topla + ' ₺');
         }*/

    });
</script>