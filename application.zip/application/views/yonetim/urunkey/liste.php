<div class="br-pageheader">
    <nav class="breadcrumb pd-0 mg-0 tx-12">
        <a class="breadcrumb-item" href="<?= base_url(admin_url()) ?>">Kontrol Paneli</a>
        <span class="breadcrumb-item active">Stok Havuzu</span>
    </nav>
</div><!-- br-pageheader -->
<div class="br-pagetitle">
    <i class="fas fa-cart-plus fa-4x"></i>
    <div>
        <h4>Stok Havuzu</h4>
    </div>
</div><!-- d-flex -->

<div class="br-pagebody">
    <div class="br-section-wrapper">
        <div class="table-wrapper table-responsive">
            <table id="datatable1" class="table display nowrap">
                <thead>
                    <tr>
                        <th colspan="4" class="text-right">
                            <div class="btn-group">
                                <a href="<?= base_url(admin_url() . "urun-key-havuzu/ekle") ?>" class="btn btn-outline-primary btn-sm"><i class="fas fa-plus"></i> Ekle</a>
            
                            </div>
                        </th>
                    </tr>
                    <tr>
                        <th class="text-left">Ürün Adı</th>
                        <th class="text-center">Durum</th>
                        <th class="text-center">Oluşturulma Tarihi</th>
                        <th class="text-right">İşlemler</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($stocks as $row) : ?>
                        <tr>
                            <td class="text-left"><?= $row->urun_ad ?></td>
                            <td class="text-center">
                                <?php if ($row->status == 0) : ?>
                                    <span class="badge badge-success">Etkin</span>
                                <?php else : ?>
                                    <span class="badge badge-danger">Pasif</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-center"><?= $row->created_at ?></td>
                            <td class="text-right">
                                <div class="btn-group">
                                    <a href="<?= base_url(admin_url() . "urun-key-havuzu/duzenle/" . $row->id) ?>" class="btn btn-primary"><i class="far fa-edit"></i> Düzenle</a>
                                    <a href="<?= base_url(admin_url() . "urun-key-havuzu/sil/" . $row->id) ?>" class="btn btn-danger"><i class="fas fa-trash"></i> Sil</a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>

                </tbody>
            </table>
        </div><!-- table-wrapper -->
    </div><!-- br-section-wrapper -->
</div><!-- br-pagebody -->