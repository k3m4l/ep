<div class="br-pageheader">
    <nav class="breadcrumb pd-0 mg-0 tx-12">
        <a class="breadcrumb-item" href="<?= base_url(admin_url()) ?>">Kontrol Paneli</a>
        <span class="breadcrumb-item active">Siteye Satışlar</span>
    </nav>
</div><!-- br-pageheader -->
<div class="br-pagetitle">
    <i class="fas fa-cart-plus fa-4x"></i>
    <div>
        <h4>Tamamlanan Siteye Satışlar</h4>
    </div>
</div><!-- d-flex -->

<div class="br-pagebody">
    <div class="br-section-wrapper">
        <div class="table-wrapper table-responsive">
            <table id="datatable1" class="table display nowrap">
                <thead>
                <tr>
                    <th class="text-center">SİPARİŞ NO</th>
                    <th class="text-center">ÜRÜN ADI</th>
                    <th class="text-center">KULLANICI</th>
                    <th class="text-center">TUTAR</th>
                    <th class="text-center">MİKTAR</th>
                    <th class="text-center">DURUM</th>
                    <th class="text-center">SİPARİŞ ZAMANI</th>
                    <th class="text-center">TÜRÜ</th>
                    <th class="text-center">İŞLEM</th>
                </tr>
                </thead>
                <tbody>
                <?php if ($siteye_satislar) { ?>
                    <?php foreach ($siteye_satislar as $key) {?>
                        <tr>
                            <td class="text-center"><?= $key->siparis_no ?></td>
                            <td class="text-center"><?= $key->urun_ad ?></td>
                            <td class="text-center"><?=$key->kullanici_ad?></td>
                            <td class="text-center"><?= $key->price ?>₺</td>
                            <td class="text-center"><?= $key->quantity ?></td>
                            <td class="text-center">
                                <span class="badge badge-success badge-pill">Onaylandı</span>
                            </td>
                            <td class="text-center">
                                <span class="badge badge-success badge-pill"><?=date('d.m.Y H:i', strtotime($key->added_time))?></span>
                            </td>
                            <td class="text-center">
                                <span class="badge badge-info badge-pill">
                                   <?php if ($key->type == 1) { ?>
                                       SİTEYE SATIŞ
                                   <?php } else if ($key->type == 2) { ?>
                                       SİTEDEN ALIM
                                   <?php } ?>
                                </span>
                            </td>
                            <td class="text-center">
                                <a href="<?php echo base_url(admin_url()."siteye-satis-duzenle/$key->id"); ?>" class="btn btn-warning btn-with-icon">
                                    <div class="ht-40">
                                        <span class="icon fas fa-edit wd-40"><i class="fa fa-send"></i></span>
                                        <span class="pd-x-15">Düzenle</span>
                                    </div>
                                </a>
                                <a href="javascript:void(0)"
                                   data-url="<?= base_url(admin_url() . "bize-sat-sil/$key->id") ?>"
                                   class="btn btn-danger btn-with-icon remove-gold-btn" data-id="<?php echo $key->id ?>">
                                    <div class="ht-40">
                                        <span class="icon far fa-trash-alt wd-40"><i class="fa fa-send"></i></span>
                                        <span class="pd-x-15">İptal Et</span>
                                    </div>
                                </a>
                            </td>
                        </tr>
                    <?php } ?>
                <?php } ?>
                </tbody>
            </table>
        </div><!-- table-wrapper -->
    </div><!-- br-section-wrapper -->
</div><!-- br-pagebody -->

<script>
    $(document).on('click', '.remove-gold-btn', function () {
        var $data_url = $(this).data("url");
        var data_id = $(this).data('id');
        Swal.fire({
            title: 'Silmek İstediğinden Emin Misin?',
            text: "İptal Sebebini Giriniz",
            type: 'warning',
            input: "text",
            inputAttributes: {
                autocapitalize: "off",
                id: "cancel_text"
            },
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Evet, Sil',
            cancelButtonText: 'İptal'
        }).then((result) => {
            if (result.value) {

                $.ajax({
                    type: "POST",
                    url: "<?=base_url(admin_url()."bize-sat-sil")?>",
                    data: {
                        id: data_id,
                        text: $('#cancel_text').val()
                    },
                    dataType: "json",
                    success: function(result) {
                        if (result.status === true) {
                            Swal.fire(
                                'Başarılı',
                                result.message,
                                'success'
                            );
                            setTimeout(function () {
                                window.location.reload();
                            }, 2000);
                        } else {
                            Swal.fire(
                                'Hata',
                                result.message,
                                'error'
                            );
                        }
                    },
                    error: function () {
                        Swal.fire(
                            'Hata',
                            'Hata',
                            'error'
                        );
                    }
                });
            }
        })
    });
</script>