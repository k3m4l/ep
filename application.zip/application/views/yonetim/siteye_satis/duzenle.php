<div class="br-pageheader">
    <nav class="breadcrumb pd-0 mg-0 tx-12">
        <a class="breadcrumb-item" href="<?=base_url(admin_url())?>">Kontrol Paneli</a>
        <span class="breadcrumb-item active">Siteye Satış Düzenle</span>
    </nav>
</div><!-- br-pageheader -->
<div class="br-pagetitle">
    <i class="fas fa-cart-plus fa-4x"></i>
    <div>
        <h4>Siteye Satış Düzenle</h4>
        <p class="mg-b-0">Siteye Satışı Buradan Düzenliyebilirsiniz.</p>
    </div>
</div><!-- d-flex -->

<div class="br-pagebody">
    <div class="br-section-wrapper">
        <form action="<?=current_url() ?>" method="post" enctype="multipart/form-data">
            <div class="form-layout form-layout-1">
                <div class="row mg-b-25">
                    <div class="col-lg-6 mb-5">
                        <span class="btn btn-success rounded-pill btn-block">Durumu :
                            <?php if ($selected->status == 0) { ?>
                                <?php echo 'Teslimat Bekliyor...' ?>
                            <?php } else if ($selected->status == 1) { ?>
                                <?php echo 'Teslim Edildi' ?>
                            <?php } else if ($selected->status == 2) { ?>
                                <?php echo 'İptal Edildi' ?>
                            <?php } ?>
                        </span>
                    </div>
                    <div class="col-lg-3 mb-5">
                        <span class="btn btn-success rounded-pill btn-block">İşlem Tarihi : <?php echo $selected->added_time ?></span>
                    </div>
                    <div class="col-lg-3 mb-5">
                        <span class="btn btn-success rounded-pill btn-block">İşlem Türü :
                             <?php if ($selected->type == 1) { ?>
                                 SİTEYE SATIŞ
                             <?php } else if ($selected->type == 2) { ?>
                                 SİTEDEN ALIM
                             <?php } ?>
                        </span>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label class="form-control-label">Sipariş No</label>
                            <input class="form-control" type="text" disabled name="siparis_no" placeholder="Sipariş No" required="" value="<?php echo $selected->siparis_no ?>">
                        </div>
                    </div><!-- col-4 -->
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label class="form-control-label">Sipariş Tutar</label>
                            <input class="form-control" type="text" name="price" placeholder="Sipariş Tutar" value="<?php echo $selected->price . ' ₺' ?>">
                        </div>
                    </div><!-- col-8 -->

                    <div class="col-lg-3">
                        <div class="form-group">
                            <label class="form-control-label">Ürün Adı</label>
                            <input class="form-control" type="text" name="urun_adi" placeholder="Ürün Adı" disabled value="<?php echo $selected->urun_ad ?>">
                        </div>
                    </div><!-- col-8 -->

                    <div class="col-lg-3">
                        <div class="form-group">
                            <label class="form-control-label">Miktar</label>
                            <input class="form-control" type="number" name="miktar" placeholder="Miktar" value="<?php echo $selected->quantity ?>">
                        </div>
                    </div><!-- col-8 -->

                    <div class="col-lg-6">
                        <div class="form-group">
                            <label class="form-control-label">Kullanıcı</label>
                            <input class="form-control" type="text" name="kullanici" disabled placeholder="Kullanıcı" value="<?php echo $selected->kullanici_ad ?>">
                        </div>
                    </div><!-- col-8 -->

                    <div class="col-lg-6">
                        <div class="form-group">
                            <label class="form-control-label">Kullanıcı Karakter İsmi</label>
                            <input class="form-control" type="text" name="character_name" placeholder="Teslim Edilecek Karakter İsmi" value="<?php echo $selected->character_name ?>">
                        </div>
                    </div><!-- col-8 -->

                    <div class="col-lg-6">
                        <label class="form-control-label">Durum <span class="tx-danger">*</span></label>
                        <select class="form-control select2-show-search" data-placeholder="Lütfen Durum Seçin" name="status" required="">
                            <option value="0" <?php echo $selected->status == 0 ? 'selected' : '' ?>>Teslimat Bekliyor</option>
                            <option value="1" <?php echo $selected->status == 1 ? 'selected' : '' ?>>Tamamlandı</option>
                            <option value="2" <?php echo $selected->status == 2 ? 'selected' : '' ?>>İptal Edildi</option>
                        </select>
                    </div>

                    <div class="col-lg-12">
                        <div class="form-group">
                            <label class="form-control-label"><?php echo $selected->type == 1 ? 'Teslim Alıncak Karakter İsmi' : 'Teslim Edecek Karakter İsmi' ?></label>
                            <input class="form-control" type="text" name="delivery_character_name" placeholder="<?php echo $selected->type == 1 ? 'Teslim Alıncak Karakter İsmi' : 'Teslim Edecek Karakter İsmi' ?>" value="<?php echo $selected->delivery_character_name ?>">
                        </div>
                    </div><!-- col-8 -->

                    <div class="col-lg-12">
                        <div class="form-group">
                            <label class="form-control-label">İptal Sebebi <small>(Durumu İptal Edildi Olarak İşaretlerseniz Bu alanı Doldurunuz)</small></label>
                            <input class="form-control" type="text" name="reason_for_cancellation" placeholder="İptal Sebebi" value="<?php echo $selected->reason_for_cancellation ?>">
                        </div>
                    </div><!-- col-8 -->


                </div>

                <div class="form-layout-footer mt-5">
                    <button type="submit" class="btn btn-info">Düzenle</button>
                </div><!-- form-layout-footer -->
            </div>
        </form><!-- form-layout -->
    </div>
</div>
<?php

function generate_string($strength = 36)
{
    $permitted_chars = '0123456789abcdefghijklmnopqrstuvwxyzAB23456789CDEFGHIJKLMNOPQRSTUVWXYZ';
    $input_length = strlen($permitted_chars);
    $random_string = '';
    for ($i = 0; $i < $strength; $i++) {
        $random_character = $permitted_chars[mt_rand(0, $input_length - 1)];
        $random_string .= $random_character;
    }

    return str_shuffle($random_string);
}
?>