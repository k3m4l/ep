<div class="br-pageheader">
    <nav class="breadcrumb pd-0 mg-0 tx-12">
        <a class="breadcrumb-item" href="<?= base_url(admin_url()) ?>">Kontrol Paneli</a>
        <span class="breadcrumb-item active">Bekleyen Satışlar</span>
    </nav>
</div><!-- br-pageheader -->
<div class="br-pagetitle">
    <i class="fas fa-cart-plus fa-4x"></i>
    <div>
        <h4>Bekleyen Satışlar</h4>
        <p class="mg-b-0">Bekleyen Satış Listesi</p>
    </div>
</div><!-- d-flex -->

<div class="br-pagebody">
    <div class="br-section-wrapper">
        <div class="table-wrapper table-responsive">
            <table id="datatable1" class="table display nowrap">
                <thead>
                <tr>
                    <th class="text-center">#SİPARİŞ NO</th>
                    <th class="text-center">ÜRÜN ADI</th>
                    <th class="text-center">ÜRÜN ALICI</th>
                    <th class="text-center">ÜRÜN DURUM</th>
                    <th class="text-center">SİPARİŞ ZAMANI</th>
                    <th class="text-center">ÜRÜN İŞLEM</th>
                </tr>
                </thead>
                <tbody>
                <?php if ($siparisler) { ?>
                    <?php foreach ($siparisler as $key) {?>
                        <tr>
                            <td class="text-center"><?= $key->siparis_no ?></td>
                            <td class="text-center"><?= $key->urun_ad ?></td>
                            <td class="text-center"><?= $key->kullanici_isim." ".$key->kullanici_soyisim?></td>
                            <td class="text-center">
                                <?php if ($key->siparis_durum == 0) { ?>
                                    <span class="badge badge-warning badge-pill">Bekleniyor</span>
                                <?php } elseif ($key->siparis_durum == 1) { ?>
                                    <span class="badge badge-secondary badge-pill">Teslimat Onayı Bekliyor</span>
                                <?php } elseif ($key->siparis_durum == 2) { ?>
                                    <span class="badge badge-success badge-pill">Tamamlandı</span>
                                <?php } elseif ($key->siparis_durum == 3) { ?>
                                    <span class="badge badge-danger badge-pill">İptal Edildi</span>
                                <?php } ?>
                            </td>
                            <td class="text-center">
                                <span class="badge badge-success badge-pill"><?=date('d.m.Y H:i', strtotime($key->siparis_tarih))?></span>
                            </td>
                            <td class="text-center">
                                <a href="<?php echo base_url(admin_url() . "satis-detay/$key->siparis_no"); ?>"
                                   class="btn btn-warning btn-with-icon">
                                    <div class="ht-40">
                                        <span class="icon fas fa-eye wd-40"><i class="fa fa-send"></i></span>
                                        <span class="pd-x-15">Detay</span>
                                    </div>
                                </a>
                            </td>
                        </tr>
                    <?php } ?>
                <?php } ?>
                </tbody>
            </table>
        </div><!-- table-wrapper -->
    </div><!-- br-section-wrapper -->
</div><!-- br-pagebody -->