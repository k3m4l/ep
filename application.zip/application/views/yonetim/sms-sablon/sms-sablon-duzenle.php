<div class="br-pageheader">
	<nav class="breadcrumb pd-0 mg-0 tx-12">
		<a class="breadcrumb-item" href="<?=base_url(admin_url())?>">Kontrol Paneli</a>
		<span class="breadcrumb-item active">SMS Şablon Güncelle</span>
	</nav>
</div><!-- br-pageheader -->
<div class="br-pagetitle">
	<i class="far fa-file-alt fa-4x"></i>
	<div>
		<h4>SMS Şablon Güncelle</h4>
	</div>
</div><!-- d-flex -->

<div class="br-pagebody">
	<div class="br-section-wrapper">
		<form action="<?=base_url(admin_url()."smssablonduzenle/$where->sablon_id"); ?>" method="post" enctype="multipart/form-data">
			<div class="form-layout form-layout-1">

                <div class="row mg-b-25">
                    <div class="col-lg-8">
                        <div class="form-group">
                            <label class="form-control-label">Şablon Başlık <span class="tx-danger">*</span></label>
                            <input class="form-control" type="text" name="baslik" placeholder="Şablon Başlık" value="<?=$where->sablon_baslik?>"
                                   required="">
                        </div>
                    </div><!-- col-4 -->

                    <div class="col-lg-4">
                        <label class="form-control-label">Şablon Durumu <span class="tx-danger">*</span></label>
                        <select class="form-control select2-show-search" data-placeholder="Lütfen Şablon Durumu Seçin" name="durum" required="">
                            <option <?php if ($where->sablon_durum == 1){ echo 'selected'; } ?> value="1">Aktif</option>
                            <option <?php if ($where->sablon_durum == 0){ echo 'selected'; } ?> value="0">Pasif</option>
                        </select>
                    </div>

                    <div class="col-lg-12">
                        <div class="form-group">
                            <label class="form-control-label">Şablon <small><code>{{kullanici}}</code> ve <code>{{baslik}}</code> etketleri ile mesajınızı yazın.</small></label>
                            <textarea class="form-control" rows="5" name="sablon"
                                      placeholder="{{baslik}} adlı ilanınız için {{kullanici}} kullanıcısından yeni bir mesajınız var! İlanınız ile ilgileniyorum. Lütfen benimle site.com üzerinden iletişime geçin."
                                      required=""><?=$where->sablon_mesaj?></textarea>
                        </div>
                    </div><!-- col-8 -->

                </div>

				<div class="form-layout-footer">
					<button type="submit" class="btn btn-info">Şablon Güncelle</button>
				</div><!-- form-layout-footer -->
			</div>
		</form><!-- form-layout -->
	</div>
</div>
<script>
	$(document).ready(function(){
		CKEDITOR.replace( 'detay' );
	});

    $('#sayfa_tur').change(function(){
        if($('#sayfa_tur').val() == '1') {
            $('#sayfa_url').show();
            $('#sayfa_detay').hide();
        } else {
            $('#sayfa_url').hide();
            $('#sayfa_detay').show();
        }
    });
</script>