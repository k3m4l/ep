<div class="br-pageheader">
    <nav class="breadcrumb pd-0 mg-0 tx-12">
        <a class="breadcrumb-item" href="<?= base_url(admin_url()) ?>">Kontrol Paneli</a>
        <span class="breadcrumb-item active">Key Bekleyen Siparişler</span>
    </nav>
</div><!-- br-pageheader -->
<div class="br-pagetitle">
    <i class="fas fa-cart-plus fa-4x"></i>
    <div>
        <h4>Key bekleyen Siparişler</h4>
        <p class="mg-b-0">Key bekleyen Sipariş Listesi</p>
    </div>
</div><!-- d-flex -->

<div class="br-pagebody">
    <div class="br-section-wrapper">
        <div class="table-wrapper table-responsive">
            <table id="datatable1" class="table display nowrap">
                <thead>
                    <tr>
                        <th class="text-center">#SİPARİŞ NO</th>
                        <th class="text-center">SİPARİŞ SAHİBİ</th>
                        <th class="text-center">ÜRÜN ADI</th>
                        <th class="text-center">SİPARİŞ ZAMANI</th>
                        <th class="text-center">ÜRÜN İŞLEM</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($siparisler as $siparis) : ?>
                        <tr>
                            <td class="text-center"><?= $siparis->siparis_id ?></td>
                            <td class="text-center"><?= $siparis->kullanici->kullanici_ad ?></td>
                            <td class="text-center"><?= $siparis->urun->urun_ad ?></td>
                            <td class="text-center"><?= $siparis->siparis_tarih ?></td>
                            <td class="text-center">
                                <div class="btn-group">
                                    <a href="<?= base_url(admin_url() . "key-bekleyen-siparisler/duzenle/" . $siparis->siparis_id); ?>" class="btn btn-success btn-xs" title="Onayla"><i class="fas fa-eye"></i></a>

                                    <a href="javascript:void(0)" data-url="<?= base_url(admin_url() . "key-bekleyen-siparisler/sil/$siparis->siparis_id") ?>" class="btn btn-danger btn-xs remove-btn ml-2">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>

                </tbody>
            </table>
        </div><!-- table-wrapper -->
    </div><!-- br-section-wrapper -->
</div><!-- br-pagebody -->