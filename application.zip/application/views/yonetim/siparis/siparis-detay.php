<div class="br-pageheader">
    <nav class="breadcrumb pd-0 mg-0 tx-12">
        <a class="breadcrumb-item" href="<?= base_url(admin_url()) ?>">Kontrol Paneli</a>
        <a class="breadcrumb-item" href="<?= base_url(admin_url() . 'siparisler') ?>">Siparişler</a>
        <span class="breadcrumb-item active">Sipariş Detay</span>
    </nav>
</div><!-- br-pageheader -->
<div class="br-pagetitle">
    <i class="fas fa-cart-plus fa-4x"></i>
    <div>
        <h4>Sipariş Detay</h4>
    </div>
</div><!-- d-flex -->

<div class="br-pagebody">
    <div class="br-section-wrapper">
        <div class="card mb-4">
            <div class="row no-gutters">
                <div class="col-md-12 text-center d-flex">
                    <div class="card-body">
                        <span>Ürün İsim</span>
                        <h3 class="mb-2 text-truncate-line-2 ">
                            <a target="_blank" href="<?= base_url($siparis->urun_seo) ?>"
                               class="text-inherit"><?= $siparis->urun_ad ?></a>
                        </h3>
                        <!-- Row -->
                    </div>
                    <div class="card-body">
                        <span>Sipariş Tutarı</span>
                        <div class="d-flex justify-content-center">
                            <div class="font-weight-bold text-primary"
                                 style="font-size: 27px;"><?= $siparis->siparis_tutar . ' ₺' ?></div>
                        </div>
                    </div>
                </div>
            </div>

            
            <div class="card-body">
                <div class="row">
                    <?php if ($siparis->siparis_durum == 1 || $siparis->siparis_durum == 2) { ?>
                        <?php if ($siparis->urun_turu == 1) { ?>
                            <?php if ($siparis->urun_marka) { ?>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="form-label">Ürün Markası</label>
                                        <input class="form-control" type="text" placeholder="Ürün Markası"
                                               value="<?= $siparis->urun_marka ?>" disabled>
                                    </div>
                                </div>
                            <?php } ?>
                            <?php if ($siparis->siparis_key) { ?>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="form-label">Teslim Edilen Key</label>
                                        <input class="form-control" type="text" placeholder="Ürün Markası"
                                               value="<?= $siparis->siparis_key ?>" disabled>
                                    </div>
                                </div>
                            <?php } ?>
                        <?php } elseif ($siparis->urun_turu == 2) { ?>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label class="form-label">Sanal Ürün Bilgisi</label>
                                    <textarea class="form-control" type="text" placeholder="Sanal Ürün Bilgisi"
                                              disabled><?= $siparis->urun_sanal_bilgi ?></textarea>
                                </div>
                            </div>
                        <?php } elseif ($siparis->urun_turu == 3) { ?>
                            <?php if ($siparis->urun_indir) {
                                $dosya = explode('/', $siparis->urun_indir); ?>
                                <div class="col-md-12 mb-3">
                                    <label class="input-label">Varsayılan Dosya</label>
                                    <div class="card">
                                        <div class="card-body d-flex justify-content-between align-items-center text-center">
                                            <div class="d-flex flex-column">
                                                        <span class="badge badge-secondary mb-1">Dosya Adı : <i
                                                                    class="fe fe-file"></i> <?= $dosya[3] ?></span>
                                                <span class="badge badge-secondary">Dosya Boyutu : <?= filesize_formatted($siparis->urun_indir) ?></span>
                                            </div>
                                            <div class="d-none d-sm-block">
                                                <a class="badge badge-primary badge-pill"
                                                   href="javascript:void(0)"><i
                                                            class="fe fe-download"></i> İndirilebilir Dosya</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php } ?>
                        <?php } ?>
                    <?php } ?>
                    <?php if (1 == 2) { ?>
                        <div class="col-md-12">
                            <div class="form-group">
                                <label class="form-label">Sipariş İptal</label>
                                <textarea class="form-control" type="text" placeholder="Sipariş İptal"
                                          disabled><?= $siparis->siparis_iptal ?></textarea>
                            </div>
                        </div>
                    <?php } ?>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label">Sipariş No</label>
                            <input class="form-control" type="text" placeholder="Sipariş No"
                                   value="<?= $siparis->siparis_no ?>" disabled>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label">Sipariş Tarihi</label>
                            <input class="form-control" type="text" placeholder="Sipariş Tarihi"
                                   value="<?= date('d.m.Y H:m', strtotime($siparis->siparis_tarih)) ?>"
                                   disabled>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label">Ad</label>
                            <input class="form-control" type="text" placeholder="Ad"
                                   value="<?= $siparis->siparis_ad ?>" disabled>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label">Soyad</label>
                            <input class="form-control" type="text" placeholder="Soyad"
                                   value="<?= $siparis->siparis_soyad ?>" disabled>
                        </div>
                    </div>
                    <form class="col-lg-12"
                          action="<?= base_url('yonetim_magaza_controller/siparis_duzenle/' . $siparis->siparis_no) ?>"
                          method="post">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="form-group mg-b-10-force">
                                    <label class="form-control-label">Sipariş Durumu <span
                                                class="tx-danger">*</span></label>
                                    <select class="form-control durum" name="siparis_durum" required>
                                        <option <?php if ($siparis->siparis_durum == 0) {
                                            echo 'selected';
                                        } ?> value="0">Ödeme Yapılmadı..
                                        </option>
                                        <option <?php if ($siparis->siparis_durum == 1) {
                                            echo 'selected';
                                        } ?> value="1">Teslimatı Onaylayın
                                        </option>
                                        <option <?php if ($siparis->siparis_durum == 2) {
                                            echo 'selected';
                                        } ?> value="2">Ödeme Yapıldı
                                        </option>
                                        <option <?php if ($siparis->siparis_durum == 3) {
                                            echo 'selected';
                                        } ?> value="3">Sipariş İptal Edildi
                                        </option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-12 siparis_iptal" <?php if ($siparis->siparis_durum != 3) { echo 'style="display: none"'; } ?>>
                                <div class="form-group">
                                    <label class="form-control-label">Sipariş İptal Notu <span
                                                class="tx-danger">*</span></label>
                                    <textarea class="form-control iptal_input" name="siparis_iptal" rows="3" placeholder="Sipariş İptal Notu.."><?= $siparis->siparis_iptal ?></textarea>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <button type="submit" class="btn btn-success btn-block">Sipariş Durumunu Güncelle</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

        </div>
    </div>
</div>

<script>
    $('.durum').on('change', function () {
        if (this.value == 3) {
            $('.siparis_iptal').show();
            $(".iptal_input").prop('required', true);
        } else {
            $('.siparis_iptal').hide();
            $(".iptal_input").prop('required', false);
        }
    });
</script>