<div class="br-pageheader">
    <nav class="breadcrumb pd-0 mg-0 tx-12">
        <a class="breadcrumb-item" href="<?= base_url(admin_url()) ?>">Kontrol Paneli</a>
        <a class="breadcrumb-item" href="<?= base_url(admin_url() . 'reklam-siparisler') ?>">Reklam Siparişler</a>
        <span class="breadcrumb-item active">Sipariş Detay</span>
    </nav>
</div><!-- br-pageheader -->
<div class="br-pagetitle">
    <i class="fas fa-cart-plus fa-4x"></i>
    <div>
        <h4>Sipariş Detay</h4>
    </div>
</div><!-- d-flex -->

<div class="br-pagebody">
    <div class="br-section-wrapper">
        <div class="card mb-4">
            <div class="card-body">
                <ul class="list-group list-group-flush">
                    <?php if ($reklam) { ?>
                        <li class="list-group-item px-0 pt-0 p-0">
                            <div class="row">
                                <div class="col-md-3 text-center">
                                                <span class="h4">
                                                    <?php if ($reklam->reklam_turu == 'anasayfa') {
                                                        echo 'Anasayfa Reklamı';
                                                    } elseif ($reklam->reklam_turu == 'kategori') {
                                                        echo 'Kategori Reklamı';
                                                    } ?>
                                                </span>
                                    <span class="d-block">
                                                    <?= date('d.m.Y H:i', strtotime($reklam->reklam_baslangic)) ?>
                                                </span>
                                </div>
                                <div class="col-md-3 text-center">
                                    <span class="h4"><?= $reklam->reklam_tutar ?>₺</span>
                                    <span class="d-block"><?= $reklam->reklam_gun ?> Gün</span>
                                </div>
                                <div class="col-md-6 text-center">
                                    <?php if ($reklam->reklam_durum == 0) { ?>
                                        <a href="javascript:void(0)"
                                           class="btn btn-outline-warning btn-sm rounded-pill">Ödeme
                                            Bekleniyor..</a>
                                    <?php } elseif ($reklam->reklam_durum == 1) { ?>
                                        <?php if (!gunHesapla($reklam->reklam_bitis)) { ?>
                                            <a href="javascript:void(0)"
                                               class="btn btn-success btn-sm rounded-pill">Reklam Aktif</a>
                                            <a href="javascript:void(0)"
                                               class="btn btn-primary btn-sm rounded-pill"><?= zamanHesapla($reklam->reklam_bitis) ?></a>
                                        <?php } else { ?>
                                            <a href="javascript:void(0)"
                                               class="btn btn-danger btn-sm rounded-pill">Reklam Süresi
                                                Doldu</a>
                                        <?php } ?>
                                    <?php } ?>
                                </div>
                            </div>
                        </li>
                    <?php } ?>
                </ul>
            </div>
        </div>
        <div class="row">
            <form class="col-lg-12"
                  action="<?= base_url('yonetim_magaza_controller/reklam_duzenle/' . $reklam->reklam_no) ?>"
                  method="post">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="form-group mg-b-10-force">
                            <label class="form-control-label">Sipariş Durumu <span
                                        class="tx-danger">*</span></label>
                            <select class="form-control durum" name="siparis_durum" required>
                                <option <?php if ($reklam->reklam_durum == 0) {
                                    echo 'selected';
                                } ?> value="0">Ödeme Yapılmadı..
                                </option>
                                <option <?php if ($reklam->reklam_durum == 1) {
                                    echo 'selected';
                                } ?> value="1">Onaylandı
                                </option>
                            </select>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group mg-b-10-force">
                            <label class="form-control-label">Reklam Bitiş Tarihi <span
                                        class="tx-danger">*</span></label>
                            <input type="text" name="reklam_bitis" class="form-control daterangepicker" placeholder="Reklam Süresi" value="<?=$reklam->reklam_bitis?>">
                        </div>
                    </div>
                    <div class="col-md-12">
                        <button type="submit" class="btn btn-success btn-block">Sipariş Durumunu Güncelle</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>