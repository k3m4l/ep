<div class="br-pageheader">
    <nav class="breadcrumb pd-0 mg-0 tx-12">
        <a class="breadcrumb-item" href="<?= base_url(admin_url()) ?>">Kontrol Paneli</a>
        <span class="breadcrumb-item active">Key Bekleyen Düzenle</span>
    </nav>
</div><!-- br-pageheader -->
<div class="br-pagetitle">
    <i class="fas fa-cart-plus fa-4x"></i>
    <div>
        <h4>Key bekleyen Düzenle</h4>
        <p class="mg-b-0">Key bekleyen Sipariş Düzenle</p>
    </div>
</div><!-- d-flex -->

<div class="br-pagebody">
    <div class="br-section-wrapper">
        <form action="<?= base_url(admin_url() . 'key-bekleyen-siparisler/kayit') ?>" method="POST">
            <div class="row">
                <div class="col-md-6">
                    <label for="">Ürün Adı</label>
                    <input type="text" class="form-control" value="<?= $siparis->urun->urun_ad ?>" disabled>
                </div>
                <div class="col-md-6">
                    <label for="">Sipariş Sahibi</label>
                    <input type="text" class="form-control" value="<?= $siparis->kullanici->kullanici_ad ?>" disabled>
                </div>
                <div class="col-md-12 mt-2">
                    <label for="">Sipariş Tarihi</label>
                    <input type="text" class="form-control" value="<?= $siparis->siparis_tarih ?>" disabled>
                </div>
                <input type="hidden" name="siparis_id" value="<?= $siparis->siparis_id ?>">
                <div class="col-md-12 mt-2">
                    <label for="">Sipariş Durumu</label>
                    <select name="siparis_epin" id="siparis_epin" class="form-control">
                        <option value="0" <?= $siparis->siparis_epin == 0 ? "selected" : null ?>>Epin değil</option>
                        <option value="1" <?= $siparis->siparis_epin == 1 ? "selected" : null ?>>Onaylandı</option>
                        <option value="2" <?= $siparis->siparis_epin == 2 ? "selected" : null ?>>Key bekliyor</option>
                        <option value="3">İptal Et</option>
                    </select>
                    <script>
                        $('#siparis_epin').on('change', function () {
                            var val = $(this).val();

                            if (val == 3) {
                                $('.iptal-siparis').removeClass('d-none');
                                $('.siparis-key').addClass('d-none');
                            } else {
                                $('.siparis-key').removeClass('d-none');
                                $('.iptal-siparis').addClass('d-none');
                            }
                        })
                    </script>
                </div>
                <div class="col-md-12 mt-2 siparis-key">
                    <label for="">Sipariş Key</label>
                    <input type="text" class="form-control" name="siparis_key" value="<?= $siparis->siparis_key ?>">
                </div>
                <div class="col-md-12 mt-2 iptal-siparis d-none">
                    <label for="">İptal Sebebi</label>
                    <input type="text" class="form-control" name="siparis_iptal">
                </div>
                <div class="col-md-12">
                    <button type="submit" class="btn btn-success btn-block mt-2">Güncelle</button>
                </div>
            </div><!-- br-section-wrapper -->
        </form>
    </div><!-- br-pagebody -->