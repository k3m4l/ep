<div class="br-pageheader">
	<nav class="breadcrumb pd-0 mg-0 tx-12">
		<a class="breadcrumb-item" href="<?=base_url(admin_url())?>">Kontrol Paneli</a>
		<a class="breadcrumb-item" href="one-cikan-kategoriler">Öne Çıkan Kategoriler</a>
		<span class="breadcrumb-item active">Yeni Öne Çıkan Kategori Ekle</span>
	</nav>
</div><!-- br-pageheader -->
<div class="br-pagetitle">
	<i class="fas fa-grip-horizontal fa-4x"></i>
	<div>
		<h4>Yeni Öne Çıkan Kategori Ekle</h4>
	</div>
</div><!-- d-flex -->

<div class="br-pagebody">
	<div class="br-section-wrapper">
		<form action="<?=base_url(admin_url()."onecikankategoriekle"); ?>" method="post" enctype="multipart/form-data">
			<div class="form-layout form-layout-1">
                <div class="row mg-b-25">
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label class="form-control-label">Kategori Adı <span class="tx-danger">*</span></label>
                            <input class="form-control" type="text" name="name" placeholder="Kategori Adı">
                            <?php if (isset($form_error)) { ?> <code class="pull-right"><?=form_error('ad')?></code><?php } ?>
                        </div>
                    </div>
                    <div class="col-lg-6" style="margin-top: 29px;">
                        <div class="form-group custom-file">
                            <input type="file" class="custom-file-input" id="customFile" name="file" accept=".jpg, .jpeg, .png">
                            <label class="custom-file-label custom-file-label-primary" for="customFile">Kategori Icon <small>(Sadece .jpg/.jpeg/.png - İsteğe Bağlı)</small></label>
                        </div>
                    </div><!-- col-4 -->
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label class="form-control-label">Kategori Sıra</label>
                            <input class="form-control" type="number" name="order_no" placeholder="Kategori Sıralama">
                        </div>
                    </div>
                </div>

				<div class="form-layout-footer">
					<button type="submit" class="btn btn-info">Kategori Ekle</button>
				</div><!-- form-layout-footer -->
			</div>
		</form><!-- form-layout -->
	</div>
</div>