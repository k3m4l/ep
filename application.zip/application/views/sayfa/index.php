<div class="py-4 py-lg-6 bg-primary">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-12">
                <div>
                    <h1 class="text-white mb-1 display-4"><?=$where->sayfa_ad?></h1>
                </div>
            </div>
        </div>
    </div>
</div>
<section class="py-6">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <p><?=$where->sayfa_detay?></p>
            </div>
        </div>
    </div>
</section>