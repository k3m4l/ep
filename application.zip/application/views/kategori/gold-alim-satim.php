<style>
    .hover-color:hover {
        color: #ffffff !important;
    }
</style>
<div class="breadcrumb">
    <div class="container">
        <ul>
            <li>
                <a title="Anasayfa" href="<?= base_url(); ?>">Anasayfa</a>
            </li>
            <li>
                <a title="Kategoriler" href="<?= base_url('kategoriler') ?>">Kategoriler</a>
            </li>
            <?php if (!empty($ust_kategori)): ?>
                <li>
                    <a title="<?= $ust_kategori->kategori_ad ?>" href="<?= base_url('kategoriler/' . $ust_kategori->kategori_seo) ?>"><?= $ust_kategori->kategori_ad ?></a>
                </li>
            <?php endif; ?>
            <li>
                <a title="<?= $kategori->kategori_ad ?>" href="<?= base_url('kategori/' . $kategori->kategori_seo); ?>"><?= $kategori->kategori_ad ?></a>
            </li>
        </ul>
    </div>
</div>
<div class="bg-primary py-15"
     style="background:linear-gradient(0deg, rgb(0 0 0 / 40%), rgb(0 0 0 / 40%)), url(<?= base_url($ayarlar->site_kategorilerarka) ?>);background-size:cover; background-position: center;">
    <div class="siyahlik"></div>
    <div class="container">
        <div class="row align-items-center">
            <div class="col-xl-12 col-lg-12 col-md-12 col-12">
                <div></div>
            </div>
        </div>
    </div>
</div>
<div class="pb-6">
    <div class="container">
        <div class="row">
            <div class="col-xl-12 col-lg-12 col-md-12 col-12">
                <div class="tab-content">
                    <div class="Products-Logo">
                        <img src="<?= base_url($kategori->kategori_resim) ?>" alt="<?= $kategori->kategori_ad; ?>"
                             width="220" height="300">
                        <?php if (!empty($kategori->kategori_logo_resim)) { ?>
                            <div class="cat-img-sec-holder">
                                <img src="<?= base_url($kategori->kategori_logo_resim); ?>" alt="<?php echo $kategori->kategori_ad ?>">
                            </div>
                        <?php } ?>
                    </div>
                    <div class="product-head-group">
                        <div class="product-head-inner-group">
                            <h1 class="products-head-title"><?= $where->ust_baslik; ?></h1>
                            <p class="products-head-description"><?= $where->ust_baslik_altyazi; ?></p>
                        </div>
                    </div>
                    <div class="product-panels">
                        <div class="panel-products">
                            <?php if ($urunler) {
                                foreach ($urunler as $urun) {
                                    ?>
                                    <div class="col-lg-12 col-md-12 col-12">
                                        
                                        <div class="card mb-4 card-hover">
                                            <div class="row no-gutters payment-container">
                                                <!-- Card Image -->
                                                <div class="product-g-warper">
                                                    <div class="prdocut-left-warper">
                                                        <div class="product-img-dsc-warper">
                                                            <div class="products-image"
                                                                 style="background:url(<?= base_url($urun->urun_resim) ?>)"><?php if (!kategori_reklam_kontrol($urun->urun_id) && 1 == 0) { ?>
                                                                    <span class="fas fa-bolt onecikan"
                                                                          data-toggle="tooltip"
                                                                          data-placement="top"
                                                                          data-original-title="Öne Çıkan"></span>
                                                                <?php } ?>

                                                            </div>
                                                            <div class="products-title">
                                                                <?= $urun->urun_ad; ?>
                                                                <div class="products-desc">
                                                                    <?= $urun->urun_aciklama; ?>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                   
                                                    
                                                    <div class="product-right-warper">
                                                        <div class="conut-price-warper ws-m swk">
                                                            <div class="stockCountBox cs-stock-count-box">
                                                                <button type="button" class="btn btn-purchase-count btn-minus-al-sat" data-urun="<?php echo $urun->urun_id ?>">-</button>
                                                                <input type="text" id="PurchaseCount<?php echo $urun->urun_id ?>" data-urun="<?php echo $urun->urun_id ?>" name="PurchaseCountAlimSatim" class="form-control bize_sat_al_sat_qt" min="1" max="10" value="1" onkeyup="if (!window.__cfRLUnblockHandlers) return false; if (/\D/g.test(this.value)) this.value = this.value.replace(/\D/g,'')" data-price="180">
                                                                <button type="button" class="btn btn-purchase-count btn-plus-al-sat" data-urun="<?php echo $urun->urun_id ?>">+</button>
                                                            </div>
                                                        </div>
                                                        <div class="btn-sc-warper">
                                                            <?php if ($urun->admin) : ?>
                                                                <div class="sale-take-btns-warper">
                                                                    <?php if ($urun->urun_alim == 1) { ?>
                                                                        <div class="psr-1">
                                                                            <div class="psr-area">
                                                                                <strong class="caret-up satis-fiyat-<?php echo $urun->urun_id ?>" data-price="<?php echo $urun->urun_alimfiyat ?>"><?php echo $urun->urun_alimfiyat ?> ₺</strong>
                                                                            </div>
                                                                            <a role="button"
                                                                               data-urun_id="<?= $urun->urun_id ?>"
                                                                               class="products-buy-2 cs-sl-btn hover-color bize-sat-button"
                                                                               data-toggle="modal"
                                                                               data-target="#bize_sat"> Bize Sat</a>
                                                                        </div>
                                                                    <?php } ?>
                                                                    <div class="psr-1">
                                                                        <div class="psr-area">
                                                                            <strong class="caret-up alim-fiyat-<?php echo $urun->urun_id ?>" data-price="<?php echo $urun->urun_fiyat ?>"><?php echo $urun->urun_fiyat ?> ₺</strong>
                                                                        </div>
                                                                        <a role="button"
                                                                        data-urun_id="<?= $urun->urun_id ?>" data-toggle="modal" data-target="#bize_sat_satin_al"
                                                                        class="products-buy cs-sl-btn hover-color bize-sat-button-satin-al">
                                                                            Satın Al</a>
                                                                    </div>
                                                                </div>
                                                            <?php else : ?>
                                                                <a role="button" href="<?= base_url($urun->urun_seo) ?>"
                                                                   class=" buy-btn"> Satın Al</a>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php }
                            } else { ?>
                                <div class="col-md-12">
                                    <div class="alert alert-warning text-center alert-custom"> Kategoriye Ait Ürün
                                        Bulunamadı
                                    </div>
                                </div>
                            <?php } ?>
                        </div>
                    </div>
                    <!-- Tab pane -->
                    <div class="tab-pane fade show active pb-4 " id="tabPaneGrid" role="tabpanel"
                         aria-labelledby="tabPaneGrid">
                        <div class="row"></div>
                        <?= $links ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="bize_sat" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
     aria-hidden="true">
    <div class="modal-dialog  modal-dialog-centered" role="document">
        <div class="modal-content sms">
            <div class="modal-header">
                <h4 class="modal-title text-center" id="exampleModalCenterTitle">Bize Sat</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body ">
                <div class="teslimat-tt">
                    <span class="mr-2 bize_sat_text"></span>
                </div>
                <img src="" class="bize_sat_img mb-2 mt-2" alt="">
                <form action="">
                    <input type="text" name="character" class="form-control" placeholder="Karakter Adınızı Giriniz...">
                </form>
                <div class="conut-price-warper">
                    <div class="stockCountBox cs-stock-count-box">
                        <button type="button" class="btn btn-purchase-count btn-minus-sat">-</button>
                        <input type="text" id="PurchaseCount_bizesat" name="PurchaseCountBizeSat"
                               class="form-control bize_sat_qt" min="1" max="10" value="1"
                               onkeyup="if (!window.__cfRLUnblockHandlers) return false; if (/\D/g.test(this.value)) this.value = this.value.replace(/\D/g,'')">
                        <button type="button" class="btn btn-purchase-count btn-plus-sat">+</button>
                    </div>
                    <div class="price-area">
                        <div class="price-total">
                            <span>Toplam</span>
                        </div>
                        <div class="price-value">
                            <span class="bize_sat_price"></span>
                        </div>
                    </div>

                    <div class="price-area">
                        <div class="price-total">
                            <span>Adet Fiyatı</span>
                        </div>
                        <div class="price-value">
                            <span class="bize_sat_price"></span>
                        </div>
                    </div>
                </div>
                <div class="notifications danger">
                    <div class="d-flex flex-column">
                        <p><strong>UYARILARI DIKKATLICE OKUYUN!</strong></p>
                        <p class="bize_sat_uyari"></p>
                    </div>
                </div>
                <div class="sold-btn-area">
                    <button type="button" role="button"
                            class="products-buy btn sold-it hover-color cancel-btn bize-sat-form-button">İptal
                    </button>
                    <button type="button" role="button"
                            class="products-buy btn sold-it hover-color bize-sat-form-button">Tamamla
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="bize_sat_satin_al" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
     aria-hidden="true">
    <div class="modal-dialog  modal-dialog-centered" role="document">
        <div class="modal-content sms">
            <div class="modal-header">
                <h4 class="modal-title text-center" id="exampleModalCenterTitle">Satın Al</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body ">
                <div class="teslimat-tt">
                    <span class="mr-2 bize_sat_al_text"></span>
                </div>
                <img src=""
                     class="bize_sat_al_img mb-2 mt-2" alt="">
                <form action="">
                    <input type="text" name="character_alim" class="form-control" placeholder="Karakter Adınızı Giriniz...">
                </form>
                <div class="conut-price-warper">
                    <div class="stockCountBox cs-stock-count-box">
                        <button type="button" class="btn btn-purchase-count btn-minus-al">-</button>
                        <input type="text" id="PurchaseCount_bizesat_alim" name="PurchaseCountBizeSatAlim"
                               class="form-control bize_sat_al_qt" min="1" max="10" value="1"
                               onkeyup="if (!window.__cfRLUnblockHandlers) return false; if (/\D/g.test(this.value)) this.value = this.value.replace(/\D/g,'')">
                        <button type="button" class="btn btn-purchase-count btn-plus-al">+</button>
                    </div>
                    <div class="price-area">
                        <div class="price-total">
                            <span>Toplam</span>
                        </div>
                        <div class="price-value">
                            <span class="bize_sat_al_price"></span>
                        </div>
                    </div>
                </div>
                <div class="notifications danger">
                    <div class="d-flex flex-column">
                        <p><strong>UYARILARI DIKKATLICE OKUYUN!</strong></p>
                        <p class="bize_sat_al_uyari"></p>
                    </div>
                </div>
                <div class="sold-btn-area">
                    <button type="button" role="button"
                            class="products-buy btn sold-it hover-color bize-sat-satin-al-form-button">Satın Al
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Footer -->
<script>
    $('.bize-sat-form-button').on('click', function () {
        var urun_id = $('.bize_sat_price').data('urun');
        var character = $('input[name="character"]').val();
        var qty = $('input[name="PurchaseCountBizeSat"]').val();
        <?php if (aktif_kullanici()) : ?>
        $.post({
            url: "<?= base_url('bize-sat-ekle/1') . '/' ?>" + urun_id,
            type: 'POST',
            data: {
                urun_id: urun_id,
                character: character,
                qty: qty
            },
            success: function (response) {
                var data = JSON.parse(response);
                if (data.status === true) {
                    Swal.fire({
                        title: 'Başarılı',
                        text: data.message,
                        icon: 'success',
                    })
                    setTimeout(
                        function () {
                            window.location.href = data.url
                        }, 2000);
                } else {
                    Swal.fire({
                        title: 'Hata',
                        text: data.message,
                        icon: 'warning',
                    })
                }
            },
            error: function (response) {
                console.log(response);
            }
        });
        <?php else : ?>
        Swal.fire({
            title: 'Giriş Yap',
            text: "Ürünü Bize Satmak İçin Giriş Yapmalısınız.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Giriş Yap',
            cancelButtonText: 'Hayır, İptal Et',
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = "<?= base_url('giris-yap') ?>";
            }
        })
        <?php endif; ?>
    });

    $('.bize-sat-satin-al-form-button').on('click', function () {
        var urun_id = $('.bize_sat_al_price').data('urun');
        var character = $('input[name="character_alim"]').val();
        var qty = $('input[name="PurchaseCountBizeSatAlim"]').val();
        <?php if (aktif_kullanici()) : ?>
        $.post({
            url: "<?= base_url('bize-sat-ekle/2') . '/' ?>" + urun_id,
            type: 'POST',
            data: {
                urun_id: urun_id,
                character: character,
                qty: qty
            },
            success: function (response) {
                var data = JSON.parse(response);
                if (data.status === true) {
                    Swal.fire({
                        title: 'Başarılı',
                        text: data.message,
                        icon: 'success',
                    })
                    setTimeout(
                        function () {
                            window.location.href = data.url
                        }, 2000);
                } else {
                    Swal.fire({
                        title: 'Hata',
                        text: data.message,
                        icon: 'warning',
                    })
                }
            },
            error: function (response) {
                console.log(response);
            }
        });
        <?php else : ?>
        Swal.fire({
            title: 'Giriş Yap',
            text: "İşlem Yapmak İçin Giriş Yapmalısınız.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Giriş Yap',
            cancelButtonText: 'Hayır, İptal Et',
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = "<?= base_url('giris-yap') ?>";
            }
        })
        <?php endif; ?>
    });

    $('.bize-sat-button').on('click', function () {
        var urun_id = $(this).data('urun_id');
        var pcount = $('#PurchaseCount'+urun_id).val();
        <?php if (aktif_kullanici()) : ?>
        $.post({
            url: "<?= base_url('bize-sat-urun-kontrol') . '/' ?>" + urun_id,
            type: 'POST',
            data: {
                urun_id: urun_id
            },
            success: function (response) {
                var data = JSON.parse(response);
                $('.bize_sat_img').attr('src', 'https://kemalellidort.com.tr/' + data.urun.urun_alimimg);
                $('.bize_sat_text').html(data.urun.urun_alimbaslik);
                $('.bize_sat_price').html((data.urun.urun_alimfiyat * pcount) + '₺');
                $('.bize_sat_qt').attr('data-price', data.urun.urun_alimfiyat);
                $('.bize_sat_qt').val(pcount);
                $('.bize_sat_price').attr('data-price', data.urun.urun_alimfiyat);
                $('.bize_sat_price').attr('data-urun', data.urun.urun_id);
                $('.bize_sat_uyari').html(data.urun.urun_alim_uyari);
            },
            error: function (response) {
                console.log(response);
            }
        });
        <?php else : ?>
        Swal.fire({
            title: 'Giriş Yap',
            text: "İşlem Yapmak İçin Giriş Yapmalısınız.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Giriş Yap',
            cancelButtonText: 'Hayır, İptal Et',
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = "<?= base_url('giris-yap') ?>";
            }
        })
        <?php endif; ?>
    });

    $('.bize-sat-button-satin-al').on('click', function () {
        var urun_id = $(this).data('urun_id');
        var pcount = $('#PurchaseCount'+urun_id).val();
        <?php if (aktif_kullanici()) : ?>
        $.post({
            url: "<?= base_url('bize-sat-urun-kontrol') . '/' ?>" + urun_id,
            type: 'POST',
            data: {
                urun_id: urun_id
            },
            success: function (response) {
                var data = JSON.parse(response);
                $('.bize_sat_al_img').attr('src', 'https://kemalellidort.com.tr/' + data.urun.urun_alimimg);
                $('.bize_sat_al_text').html(data.urun.urun_alimbaslik);
                $('.bize_sat_al_price').html((data.urun.urun_fiyat * pcount) + '₺');
                $('.bize_sat_al_qt').attr('data-price', data.urun.urun_fiyat);
                $('.bize_sat_al_qt').val(pcount);
                $('.btn-plus-al').attr('data-price', data.urun.urun_fiyat);
                $('.bize_sat_al_price').attr('data-price', data.urun.urun_fiyat);
                $('.bize_sat_al_price').attr('data-urun', data.urun.urun_id);
                $('.bize_sat_al_uyari').html(data.urun.urun_alim_uyari);
            },
            error: function (response) {
                console.log(response);
            }
        });
        <?php else : ?>
        Swal.fire({
            title: 'Giriş Yap',
            text: "İşlem Yapmak İçin Giriş Yapmalısınız.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Giriş Yap',
            cancelButtonText: 'Hayır, İptal Et',
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = "<?= base_url('giris-yap') ?>";
            }
        })
        <?php endif; ?>
    });


    const minusBtn = document.querySelectorAll('.btn-minus-al');
    const plusBtn = document.querySelectorAll('.btn-plus-al');

    for (let i = 0; i < minusBtn.length; i++) {
        minusBtn[i].addEventListener('click', function () {
            let pr = $('.bize_sat_al_qt').attr('data-price');
            var countInput = document.getElementById('PurchaseCount_bizesat_alim');
            let count = parseInt(countInput.value);
            if (isNaN(count)) {
                count = 1;
            } else {
                count = count - 1 < 1 ? 1 : count - 1;
            }
            countInput.value = count;
            $('.bize_sat_al_price').html((pr * count) + '₺');
            $('.bize_sat_al_price').attr('data-price', pr * count);

        });
    }
    for (let i = 0; i < plusBtn.length; i++) {
        plusBtn[i].addEventListener('click', function () {
            let pr = $('.bize_sat_al_qt').attr('data-price');
            var countInput = document.getElementById('PurchaseCount_bizesat_alim');
            let count = parseInt(countInput.value);
            if (isNaN(count)) {
                count = 1;
            } else {
                count = count + 1 > 10 ? 10 : count + 1;
            }

            countInput.value = count;
            $('.bize_sat_al_price').html((pr * count) + '₺');
            $('.bize_sat_al_price').attr('data-price', pr * count);
        });
    }

    const minusBtnSat = document.querySelectorAll('.btn-minus-sat');
    const plusBtnSat = document.querySelectorAll('.btn-plus-sat');

    for (let i = 0; i < minusBtnSat.length; i++) {
        minusBtnSat[i].addEventListener('click', function () {
            var pr = $('.bize_sat_qt').attr('data-price');
            var countInput = document.getElementById('PurchaseCount_bizesat');
            let count = parseInt(countInput.value);
            if (isNaN(count)) {
                count = 1;
            } else {
                count = count - 1 < 1 ? 1 : count - 1;
            }
            countInput.value = count;
            $('.bize_sat_price').html((pr * count) + '₺');
            $('.bize_sat_price').attr('data-price', pr * count);

        });
    }
    for (let i = 0; i < plusBtnSat.length; i++) {
        plusBtnSat[i].addEventListener('click', function () {
            var pr = $('.bize_sat_qt').attr('data-price');
            var countInput = document.getElementById('PurchaseCount_bizesat');
            let count = parseInt(countInput.value);
            if (isNaN(count)) {
                count = 1;
            } else {
                count = count + 1 > 10 ? 10 : count + 1;
            }

            countInput.value = count;
            $('.bize_sat_price').html((pr * count) + '₺');
            $('.bize_sat_price').attr('data-price', pr * count);

        });
    }

    const minusBtnAlSat = document.querySelectorAll('.btn-minus-al-sat');
    const plusBtnAlSat = document.querySelectorAll('.btn-plus-al-sat');

    for (let i = 0; i < minusBtnAlSat.length; i++) {
        minusBtnAlSat[i].addEventListener('click', function () {
            var pr = $(this).attr('data-urun');
            var countInput = document.getElementById('PurchaseCount'+pr);
            let count = parseInt(countInput.value);
            if (isNaN(count)) {
                count = 1;
            } else {
                count = count - 1 < 1 ? 1 : count - 1;
            }
            countInput.value = count;

            var alim_fiyat = $('.alim-fiyat-'+pr).attr('data-price');
            var satis_fiyat = $('.satis-fiyat-'+pr).attr('data-price');
            if (satis_fiyat) {
                $('.satis-fiyat-'+pr).html((satis_fiyat * count) + '₺');
            }
            if (alim_fiyat) {
                $('.alim-fiyat-'+pr).html((alim_fiyat * count) + '₺');
            }

            //$('.alim-fiyat-'+pr).html((pr * count) + '₺');

        });
    }
    for (let i = 0; i < plusBtnAlSat.length; i++) {
        plusBtnAlSat[i].addEventListener('click', function () {
            var pr = $(this).attr('data-urun');
            var countInput = document.getElementById('PurchaseCount'+pr);
            let count = parseInt(countInput.value);
            if (isNaN(count)) {
                count = 1;
            } else {
                count = count + 1 > 10 ? 10 : count + 1;
            }

            countInput.value = count;

            var alim_fiyat = $('.alim-fiyat-'+pr).attr('data-price');
            var satis_fiyat = $('.satis-fiyat-'+pr).attr('data-price');
            if (satis_fiyat) {
                $('.satis-fiyat-'+pr).html((satis_fiyat * count) + '₺');
            }
            if (alim_fiyat) {
                $('.alim-fiyat-'+pr).html((alim_fiyat * count) + '₺');
            }

            //$('.bize_sat_al_price').html((pr * count) + '₺');
            //$('.bize_sat_al_price').attr('data-price', pr * count);

        });
    }
</script>
<style>
    body {
        color: white !important;
    }
</style>