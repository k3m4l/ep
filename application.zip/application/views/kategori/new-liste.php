<div class="breadcrumb">
    <div class="container">
        <ul>
            <li>
                <a title="Anasayfa" href="<?= base_url(); ?>">Anasayfa</a>
            </li>
            <li>
                <a title="Kategoriler" href="<?= base_url('kategoriler') ?>">Kategoriler</a>
            </li>
            <li>
                <a title="<?= $ust_kategori->kategori_ad ?>" href="<?= base_url('kategoriler/' . $ust_kategori->kategori_seo); ?>"><?= $ust_kategori->kategori_ad ?></a>
            </li>
            <li>
                <a title="<?= $kategori->kategori_ad ?>" href="<?= base_url('kategori/' . $kategori->kategori_seo); ?>"><?= $kategori->kategori_ad ?></a>
            </li>
        </ul>
    </div>
</div>

<style>
    .dark-theme .panel.panel-default {
        background: #323448;
    }

    .panel {
        margin-bottom: 20px;
    }

    .panel.panel-default.panel-search-bar {
        position: relative;
        height: 45px;
    }

    .panel.panel-default {
        border: none;
        border-radius: 4px;
        box-shadow: 0 5px 5px 0 rgba(85, 85, 85, .06);
    }

    .quicksearch-allcategory {
        width: 100%;
        height: 45px;
        border: none;
        border-radius: 3px;
        padding: 0 13px;
        padding-left: 50px;
        position: absolute;
        top: 0;
        background: #323448;
        color: #d7d8e6;
        left: 0;
    }

    .panel-body {
        display: flex;
        align-items: center;
        padding: 0 15px;
        height: 100%;
    }

    .panel.panel-default.panel-search-bar i.fab.fa-searchengin {
        position: absolute;
        top: 0;
        pointer-events: none;
        left: 0;
        background: 0 0;
        z-index: 1;
        width: 35px;
        line-height: 45px;
        text-align: right;
        font-size: 22px;
        color: #d7d8e6;
    }


    .panel-title {
        color: #e2e4fd;
        font-weight: 600;
        font-size: 22px;
        margin-bottom: 20px;
    }

    .panel-card {
        background: rgba(255, 255, 255, 0.05);
        margin: 1rem 0;
        border-radius: 4px;
        padding: 15px;
    }


    .panel-card-description strong {
        font-weight: 700;
    }

    .makale-body-height {
        max-height: 200px;
        overflow: auto;
    }

    body ::-webkit-scrollbar {
        -webkit-appearance: none;
        width: 10px;
        height: 10px
    }

    body ::-webkit-scrollbar-track {
        background: rgba(0, 0, 0, .1);
        border-radius: 0
    }

    body ::-webkit-scrollbar-thumb {
        cursor: pointer;
        border-radius: 5px;
        background: rgba(0, 0, 0, .25);
        -webkit-transition: color .2s ease;
        transition: color .2s ease
    }

    body ::-webkit-scrollbar-thumb:window-inactive {
        background: rgba(0, 0, 0, .15)
    }

    body ::-webkit-scrollbar-thumb:hover {
        background: rgba(128, 135, 139, .8)
    }

    body .ui.inverted::-webkit-scrollbar-track {
        background: rgba(255, 255, 255, .1)
    }

    body .ui.inverted::-webkit-scrollbar-thumb {
        background: rgba(255, 255, 255, .25)
    }

    body .ui.inverted::-webkit-scrollbar-thumb:window-inactive {
        background: rgba(255, 255, 255, .15)
    }

    body .ui.inverted::-webkit-scrollbar-thumb:hover {
        background: rgba(255, 255, 255, .35)
    }


    .filter-col {
        background: rgb(26 33 51);
        border: 1px solid rgb(32 43 68);
        border-radius: 5px;
        padding: 15px;
    }

    .form-group {
        position: relative;
    }

    .filter-advert-type-list {
        padding: 0;
        list-style: none;
        margin: 0 0 15px;
        background: #252a43;
        border-radius: 3px;
    }

    .filter-advert-type-list li:hover, .filter-advert-type-list li.active {
        background: #4a5a90;
        color: #d6d8e9;
    }

    .filter-advert-type-list li {
        background: 0 0;
        padding: 5px 15px;
        line-height: 35px;
        font-size: 14px;
        border-bottom: 2px solid #252a43;
        position: relative;
    }

    .filter-advert-type-list li a {
        display: block;
        color: inherit;
        text-decoration: none !important;
    }

    .filter-advert-type-list li img {
        max-height: 30px;
        max-width: 30px;
        margin-right: 10px;
    }

    .ui.selection.dropdown, .ui.form textarea {
        background: #2a3147 !important;
        color: #fff !important;
        border-color: transparent;
        min-height: 35px;
    }

    .ui.multiple.dropdown {
        padding: 0.22619048em 2.1em 0.22619048em 0.35714286em;
    }

    .ui.dropdown > input:not(.search):first-child, .ui.dropdown > select {
        display: none !important;
    }

    .ui.selection.dropdown {
        cursor: pointer;
        word-wrap: break-word;
        line-height: 1em;
        white-space: normal;
        outline: 0;
        -webkit-transform: rotateZ(0);
        transform: rotateZ(0);
        min-width: 14em;
        min-height: 2.71428571em;
        background: #fff;
        display: inline-block;
        padding: 0.78571429em 2.1em 0.78571429em 1em;
        color: rgba(0, 0, 0, .87);
        -webkit-box-shadow: none;
        box-shadow: none;
        border: 1px solid rgba(34, 36, 38, .15);
        border-radius: 0.28571429rem;
        -webkit-transition: width .1s ease, -webkit-box-shadow .1s ease;
        transition: width .1s ease, -webkit-box-shadow .1s ease;
        transition: box-shadow .1s ease, width .1s ease;
        transition: box-shadow .1s ease, width .1s ease, -webkit-box-shadow .1s ease;
    }

    .no-padding {
        padding: 0 !important;
    }

    .PostBox.AuthorPost {
        padding-bottom: 45px;
        position: relative;
    }

    .PostBox {
        padding: 10px;
        display: block;
        height: calc(100% - 10px);
        margin: 5px 5px 10px;
        border-radius: 4px;
        background: #1c2231;
        position: relative;
        border: 1px solid transparent;
    }

    .PostBox .PostImage, .PostBox .PostTitle, .PostBox .PostDescription, .PostBox .PostPrice, .PostBox .post-button-groups {
        z-index: 1;
        position: relative;
    }

    .PostImage {
        position: relative;
        overflow: hidden;
        border-radius: 4px;
        background: rgb(59 68 92);
        padding: 1px;
    }

    .PostBox a {
        color: rgb(164 176 203);
    }

    .AuthorPost .PostAuthor {
        border-top: 1px solid rgb(41 48 68);
        margin: -10px;
        margin-top: 10px;
        margin-bottom: 0;
        padding: 7px 10px;
        position: absolute;
        width: calc(100% - 0px);
        bottom: 0;
        background: linear-gradient(45deg, rgb(37 42 80), rgb(0 0 0/0%));
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    .PostBox .PostImage img {
        width: 100%;
        height: 120px;
        object-fit: cover;
        border-radius: 5px;
        transition: .1s linear;
    }

    .PostBox .PostTitle {
        margin-top: 10px;
    }

    .PostBox .PostTitle {
        font-size: 14px;
        color: rgb(219 225 255);
        display: -webkit-box;
        max-width: 100%;
        -webkit-line-clamp: 1;
        -webkit-box-orient: vertical;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: normal;
        line-height: 16px;
        word-break: break-all;
    }

    .PostDescription {
        margin-top: 5px;
        font-size: 13px;
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: normal;
        line-height: 14px;
        word-break: break-all;
        height: 28px;
    }

    .AuthorPost .PostAuthor img {
        width: 25px;
        height: 25px;
        border-radius: 4px;
        margin-right: 5px;
    }

    @media only screen and (max-width: 425px) {
        .ui.selection.dropdown {
            min-width: unset !important;
            max-width: 100% !important;
            width: 100% !important
        }

        .ui.label.transition {
            font-size: 11px !important;
            white-space: nowrap !important;
            position: relative;
            z-index: 5
        }
    }

    @media only screen and (max-width: 768px) {
        .advert-types ul {
            display: block;
            width: max-content
        }

        .col-12.advert-types {
            overflow-x: auto
        }

        .advert-types::-webkit-scrollbar {
            height: 5px
        }

        .advert-types ul li {
            min-width: 100px
        }

        .advert-types ul li:last-child {
            border-right: none
        }

        .input-group.filter-search-group {
            margin-top: 10px
        }

        .input-group.filter-search-group form {
            width: 100%
        }

        .row.filterButtons {
            margin-left: 0 !important;
            margin-right: 0 !important
        }

        .filterButtons > .col-3 {
            padding: 0
        }

        .btn-group > a {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 50px;
            line-height: 15px
        }

        .category-banner-background > h1 {
            line-height: 25px !important;
            font-size: 24px !important
        }

        .category-banner-background h2 {
            font-size: 14px
        }
    }

    @media only screen and (max-width: 960px) {
        .col-lg-2.col-md-filter {
            width: 33.33333333%;
            max-width: 33.33333333%;
            flex: 0 0 33.33333333%
        }

        .col-lg-9.col-md-post-list {
            width: 66.66666667%;
            max-width: 66.66666667%;
            flex: 0 0 66.66666667%
        }
    }

    @media screen and (min-width: 960px) and (max-width: 1024px) {
        .col-lg-2.col-md-filter {
            width: 25%;
            max-width: 25%;
            flex: 0 0 25%
        }

        .col-lg-9.col-md-post-list {
            width: 75%;
            max-width: 75%;
            flex: 0 0 75%
        }
    }

    @media only screen and (min-width: 1024px) {
        .col-lg-2.col-md-filter {
            width: 20%;
            max-width: 20%;
            flex: 0 0 20%
        }

        .col-lg-9.col-md-post-list {
            width: 80%;
            max-width: 80%;
            flex: 0 0 80%
        }
    }

    .ui.active.selection.dropdown {
        border-bottom-left-radius: 0 !important;
        border-bottom-right-radius: 0 !important;
    }

    .ui.selection.active.dropdown {
        border-color: #96c8da;
        -webkit-box-shadow: 0 2px 3px 0 rgba(34, 36, 38, .15);
        box-shadow: 0 2px 3px 0 rgba(34, 36, 38, .15);
    }

    .ui.selection.dropdown.active, .ui.selection.dropdown.visible {
        z-index: 10;
    }

    .ui.selection.active.dropdown .menu {
        border-color: #96c8da;
        -webkit-box-shadow: 0 2px 3px 0 rgba(34, 36, 38, .15);
        box-shadow: 0 2px 3px 0 rgba(34, 36, 38, .15);
    }

    .ui.multiple.dropdown .menu {
        cursor: auto;
    }

    .ui.selection.dropdown .menu > .message {
        padding: .78571429rem 1.14285714rem
    }

    @media only screen and (min-width: 992px) {
        .ui.selection.dropdown .menu {
            max-height: 16.02857143rem
        }
    }

    @media only screen and (min-width: 1920px) {
        .ui.selection.dropdown .menu {
            max-height: 21.37142857rem
        }
    }

    @media only screen and (max-width: 767px) {
        .ui.selection.dropdown .menu {
            max-height: 8.01428571rem
        }
    }

    @media only screen and (min-width: 768px) {
        .ui.selection.dropdown .menu {
            max-height: 10.68571429rem
        }
    }

    ul.pagination.new-style-pagination {
        display: flex;
        justify-content: center;
        gap: 3px;
    }

    .pagination {
        display: -ms-flexbox;
        display: flex;
        padding-left: 0;
        list-style: none;
        border-radius: 0.25rem;
    }

    .new-style-pagination .active a.page-link {
        background-color: #799efb;
        border-color: #799efb;
    }

    .page-item.active .page-link {
        z-index: 3;
        color: #fff;
        background-color: #007bff;
        border-color: #007bff;
    }

    .new-style-pagination a.page-link {
        border-radius: 100% !important;
        width: 30px;
        line-height: 28px;
        padding: 0;
        margin: 0 2px;
        color: #a4b2d5;
        border: 1px solid #2b354e;
        background-color: #2b354e;
    }

    .page-link {
        position: relative;
        display: block;
        padding: 0.5rem 0.75rem;
        margin-left: -1px;
        line-height: 1.25;
        color: #007bff;
        background-color: #fff;
        border: 1px solid #dee2e6;
    }

    .page-item.disabled .page-link {
        color: #7d87a3;
        background-color: #0f121a;
        border-color: #0f121a;
    }

    .page-item.disabled .page-link {
        color: #6c757d;
        pointer-events: none;
        cursor: auto;
        background-color: #fff;
        border-color: #dee2e6;
    }

    .page-item:first-child .page-link {
        margin-left: 0;
        border-top-left-radius: 0.25rem;
        border-bottom-left-radius: 0.25rem;
    }
</style>


<section style="margin: 20px 0;">
    <div class="container">
        <div class="row">
            <div class="col col-12 pr-0">
            </div>
            <div class="col col-12 col-md-4 col-lg-2 col-xs-12 col-md-filter mb-4 md-mb-0">
                <form action="<?php echo current_url() ?>" method="GET" class="filter-col">
                    <div class="row">
                        <div class="form-group col col-12">
                            <label for="CategoryType">İlan Tipi</label>
                            <ul class="filter-advert-type-list">
                                <li class="<?php echo isset($_GET['type']) ? '' : 'active' ?>"">
                                    <a href="<?php echo base_url('kategori/'.$kategori->kategori_seo) ?>">
                                        <img src="https://cdn.itemsatis.com/uploads/admin/CJjQYcgTOA4yXkepNRtSBLHFq.png"
                                             data-src="https://cdn.itemsatis.com/uploads/admin/CJjQYcgTOA4yXkepNRtSBLHFq.png"
                                             alt="Alım İlanları" title="Alım İlanları" class="lazyload AdvertType">
                                        <span>Tüm İlanlar</span>
                                    </a>
                                </li>
                                <?php foreach (!empty($filtreler) ? $filtreler : [] as $key => $val) { ?>
                                    <li class="<?php echo isset($_GET['type']) ? $_GET['type'] == $val->filtre_id ? 'active' : '' : '' ?>">
                                        <a href="<?php echo base_url('kategori/'.$kategori->kategori_seo.'?type='.$val->filtre_id) ?>">
                                            <img src="<?php echo base_url($val->filtre_resim) ?>"
                                                 data-src="<?php echo base_url($val->filtre_resim) ?>"
                                                 alt="<?php echo $val->filtre_adi ?>" title="<?php echo $val->filtre_adi ?>" class="lazyload AdvertType">
                                            <span><?php echo $val->filtre_adi ?></span>
                                        </a>
                                    </li>
                                <?php } ?>
                            </ul>
                        </div>

                        <?php if (!empty($_GET['type'])) { ?>
                        <input type="hidden" name="type" value="<?php echo $_GET['type'] ?>">
                        <?php } ?>
                        <div class="form-group col col-12">
                            <label>Açıklamada Ara</label>
                            <input type="text" name="desc" class="form-control" placeholder="Arama yapın..." value="<?php echo !empty($_GET['desc']) ? $_GET['desc'] : '' ?>">
                        </div>
                        <div class="form-group col col-12">
                            <label>Başlıkta Ara</label>
                            <input type="text" name="title" class="form-control" placeholder="Arama yapın..." value="<?php echo !empty($_GET['title']) ? $_GET['title'] : ''?>">
                        </div>
                        <?php foreach (!empty($sub_filters) ? $sub_filters : [] as $key => $val) { ?>
                            <?php if ($val->type == 1) { ?>
                                <div class="form-group col col-12">
                                    <label><?php echo $val->filtre_adi ?></label>
                                    <select name="<?php echo $val->slug ?>" class="form-control" id="">
                                        <option value="0">Lütfen Seçim Yapınız</option>
                                        <?php foreach (!empty($val->ozellikler) ? $val->ozellikler : [] as $_key => $_val) { ?>
                                            <option value="<?php echo $_val->name ?>"><?php echo $_val->name ?></option>
                                        <?php } ?>
                                    </select>
                                </div>
                            <?php } else if ($val->type == 2) { ?>
                                <div class="form-group col col-12">
                                    <label><?php echo $val->filtre_adi ?></label>
                                    <input type="text" name="<?php echo $val->slug ?>" class="form-control" placeholder="<?php echo $val->filtre_adi ?>">
                                </div>
                            <?php } ?>
                        <?php } ?>
                        <div class="form-group col col-12">
                            <label>Minimum Fiyat</label>
                            <input type="text" name="min" class="form-control" placeholder="Min. ₺" value="<?php echo !empty($_GET['min']) ? $_GET['min'] : ''?>">
                        </div>
                        <div class="form-group col col-12">
                            <label>Maksimum Fiyat</label>
                            <input type="text" name="maks" class="form-control" placeholder="Maks. ₺" value="<?php echo !empty($_GET['maks']) ? $_GET['maks'] : ''?>">
                        </div>

                        <div class="col col-12 mt-2">
                            <button type="submit" class="btn btn-primary btn-block btn-filter">Filtrele</button>
                        </div>
                    </div>
                </form>
            </div>
            <div class="col col-12 col-md-8 col-lg-9 col-xs-12 col-md-post-list">
                <div class="row">
                    <?php if ($urunler) { ?>
                        <?php foreach ($urunler as $urun) {
                                $magaza = magaza($urun->kullanici_id);
                                $kullanici = kullanici_bilgi($urun->kullanici_id);
                            ?>
                            <div class="col-xl-2 col-lg-3 col-md-4" style="width: 100%; display: inline-block;padding-left:0;">
                                <div class="product-item">
                                    <div class="pimg-base">
                                        <a href="<?= base_url($magaza ? $urun->urun_seo : ('kategori/' . $urun_kategori->kategori_seo)) ?>" aria-label="<?= $urun->urun_ad ?>" tabindex="0">
                                            <?php if (!$magaza && $urun->urun_eski_fiyat > $urun->urun_fiyat):
                                                $oran = 100 - ceil($urun->urun_fiyat * 100 / $urun->urun_eski_fiyat);
                                                ?>
                                                <div class="DiscountBox">
                                                        <span>
                                                            <b><?= $oran ?>%</b>
                                                            <small>İndirim</small>
                                                        </span>
                                                </div>
                                            <?php endif; ?>
                                            <img class="product-image lazy entered loaded" alt="<?= $urun->urun_ad ?>" data-src="<?= base_url($magaza ? $urun->urun_resim_min : $urun->urun_resim); ?>" data-ll-status="loaded" src="<?= base_url($magaza ? $urun->urun_resim_min : $urun->urun_resim); ?>">
                                        </a>
                                    </div>
                                    <div class="product-detail">
                                        <a href="<?= base_url($magaza ? $urun->urun_seo : ('kategori/' . $urun_kategori->kategori_seo)) ?>" tabindex="0">
                                            <span class="product-name d-block threedots"><?= $urun->urun_ad ?></span>
                                            <div class="d-flex justify-content-space-between">
                                                <div class="product-price">
                                                    <div class="sales-price fw-600 fs-18">
                                                        <?= $urun->urun_fiyat ?>
                                                        ₺
                                                    </div>
                                                    <?php if ($urun->urun_eski_fiyat != '0.00') { ?>
                                                        <div class="list-price">
                                                            <?= $urun->urun_eski_fiyat ?>
                                                            ₺
                                                        </div>
                                                    <?php } ?>
                                                </div>
                                                <?php if ($magaza) { ?>
                                                    <div class="inline-platform-list">
                                                        <?php if(strpos($kullanici->kullanici_resim, "/.jpg") !== false){ ?>
                                                            <img src="https://ui-avatars.com/api/?name=<?=$kullanici->kullanici_ad ?>&background=0D8ABC&color=fff" alt="<?= $magaza->magaza_ad; ?>" width="24" height="24"/>
                                                        <?php }else{ ?>
                                                            <img src="<?= base_url($kullanici->kullanici_resim) ?>" title="<?= $magaza->magaza_ad; ?>" alt="<?= $magaza->magaza_ad; ?>" width="24" height="24">
                                                        <?php } ?>
                                                    </div>
                                                <?php } ?>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <?php if (1 == 2) { ?>
                            <div class="col-12 col-md-4 col-lg-2 col-xs-6 no-padding">
                                <div class="PostBox AuthorPost ">
                                    <div class="PostImage">
                                        <a href="<?php echo base_url($urun->urun_seo) ?>"
                                           title="<?php echo $urun->urun_ad ?>" class="imageLink">
                                            <img src="<?php echo base_url($urun->urun_resim_min) ?>"
                                                 data-src="<?php echo base_url($urun->urun_resim_min) ?>"
                                                 class="lazyload" alt="<?php echo $urun->urun_ad ?>">
                                        </a>
                                    </div>
                                    <a href="<?php echo base_url($urun->urun_seo) ?>"
                                       title="<?php echo $urun->urun_ad ?>">
                                        <div class="PostTitle"><?php echo $urun->urun_ad ?></div>
                                        <div class="PostDescription "><?php echo $urun->urun_aciklama ?></div>
                                        <div class="PostPrice"><?php echo $urun->urun_fiyat ?> ₺</div>
                                    </a>
                                    <div class="PostAuthor">
                                        <a href="<?= base_url('m/'.$magaza->magaza_seo); ?>" title="<?= $magaza->magaza_ad; ?>">
                                            <?php if(strpos($kullanici->kullanici_resim, "/.jpg") !== false){ ?>
                                                <img src="https://ui-avatars.com/api/?name=<?=$kullanici->kullanici_ad ?>&background=0D8ABC&color=fff" alt="<?= $magaza->magaza_ad; ?>"/>
                                            <?php }else{ ?>
                                                <img src="<?= base_url($kullanici->kullanici_resim) ?>" title="<?= $magaza->magaza_ad; ?>" alt="<?= $magaza->magaza_ad; ?>">
                                            <?php } ?>
                                            <?= $magaza->magaza_ad; ?>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <?php } ?>
                        <?php } ?>
                    <?php } ?>
                    <!--<div class="col-12 text-center" style="padding-top: 10px">
                        <ul class="pagination new-style-pagination">
                            <li class="page-item disabled"><a class="page-link" href="#">«</a></li>
                            <li class="page-item active"><a class="page-link" href="#">1</a></li>
                            <li class="page-item disabled"><a class="page-link" href="#">»</a></li>
                        </ul>
                    </div>-->
                </div>
            </div>
        </div>
    </div>
</section>