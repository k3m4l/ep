<div class="breadcrumb">
    <div class="container">
        <ul>
            <li>
                <a title="Anasayfa" href="<?= base_url(); ?>">Anasayfa</a>
            </li>
            <li>
                <a title="Kategoriler" href="<?= base_url('kategoriler') ?>">Kategoriler</a>
            </li>
            <li>
                <a title="<?= $kategori->kategori_ad ?>"
                   href="<?= base_url('kategoriler/' . $kategori->kategori_seo); ?>"><?= $kategori->kategori_ad ?></a>
            </li>
        </ul>
    </div>
</div>


<div class="py-4">
    <div class="container-fluid">
        <div class="container">
            <div class="panel panel-default panel-search-bar">
                <div class="panel-body no-padding">
                    <i class="fab fa-searchengin" href="afawf"></i>
                    <input type="text" id="quicksearch" class="quicksearch-allcategory" placeholder="Buradan kategorileri filtreleyebilirsiniz.">
                </div>
            </div>
            <div class="row">
                <?php foreach ($kategoriler as $kategori) : ?>
                    <div class="col-xl-2 col-lg-3 col-md-6 col-sm-6 col-12 mb-xl-4 mb-3 CategoryDiv no-padding">
                        <div class="product-cat-warper">
                            <div class="cat-product catergory-zoom">
                                <a title="<?= $kategori->kategori_ad ?>"
                                   href="<?= base_url('kategori' . (($kategori->parent == 0) ? 'ler/' : '/') . $kategori->kategori_seo); ?>"
                                   class="pc-img">
                                    <div class="cat-img-holders">
                                        <img src="<?= base_url($kategori->kategori_resim ?? 'assets/images/prev.jpg'); ?>" height="293" width="220"
                                             alt="<?= $kategori->kategori_ad ?>">
                                        <?php if (!empty($kategori->kategori_logo_resim)) { ?>
                                            <div class="cat-img-sec-holder">
                                                <img src="<?= base_url($kategori->kategori_logo_resim); ?>"
                                                     alt="<?php echo $kategori->kategori_ad ?>">
                                            </div>
                                        <?php } ?>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <div class="pc-name">
                            <a title="<?= $kategori->kategori_ad ?>"
                               href="<?= base_url('kategori' . (($kategori->parent == 0) ? 'ler/' : '/') . $kategori->kategori_seo); ?>"><?= $kategori->kategori_ad ?></a>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</div>