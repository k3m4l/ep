<style>
    .hover-color:hover {
        color: #ffffff !important;
    }
</style>
<div class="breadcrumb">
    <div class="container">
        <ul>
            <li>
                <a title="Anasayfa" href="<?= base_url(); ?>">Anasayfa</a>
            </li>
            <li>
                <a title="Kategoriler" href="<?= base_url('kategoriler') ?>">Kategoriler</a>
            </li>
            <?php if (!empty($ust_kategori)): ?>
                <li>
                    <a title="<?= $ust_kategori->kategori_ad ?>" href="<?= base_url('kategoriler/' . $ust_kategori->kategori_seo) ?>"><?= $ust_kategori->kategori_ad ?></a>
                </li>
            <?php endif; ?>
            <?php if (!empty($kategori)) { ?>
                <li>
                    <a title="<?= $kategori->kategori_ad ?>" href="<?= base_url('kategori/' . $kategori->kategori_seo); ?>"><?= $kategori->kategori_ad ?></a>
                </li>
            <?php } ?>
        </ul>
    </div>
</div>
<?php if ($where->kategori_tur == 0): ?><!-- Page header -->
<div class="bg-primary py-15"
     style="background:linear-gradient(0deg, rgb(0 0 0 / 40%), rgb(0 0 0 / 40%)), url(<?= base_url($ayarlar->site_kategorilerarka) ?>);background-size:cover; background-position: center;">
    <div class="siyahlik"></div>
    <div class="container">
        <div class="row align-items-center">
            <div class="col-xl-12 col-lg-12 col-md-12 col-12">
                <div></div>
            </div>
        </div>
    </div>
</div>
<div class="pb-6">
    <div class="container">
        <div class="row">
            <div class="col-xl-12 col-lg-12 col-md-12 col-12">
                <div class="tab-content">
                    <div class="Products-Logo">
                        <img src="<?= base_url($kategori->kategori_resim) ?>" alt="<?= $where->ust_baslik; ?>"
                             width="220" height="300">
                        <?php if (!empty($kategori->kategori_logo_resim)) { ?>
                            <div class="cat-img-sec-holder">
                                <img src="<?= base_url($kategori->kategori_logo_resim); ?>" alt="<?php echo $kategori->kategori_ad ?>">
                            </div>
                        <?php } ?>
                    </div>
                    <div class="product-head-group">
                        <div class="product-head-inner-group">
                            <h1 class="products-head-title"><?= $where->ust_baslik; ?></h1>
                            <p class="products-head-description"><?= $where->ust_baslik_altyazi; ?></p>
                        </div>
                    </div>
                    <div class="product-panels">
                        <div class="panel-products">
                            <?php if ($urunler) {
                                foreach ($urunler as $urun) {
                                    ?>
                                    <div class="col-lg-12 col-md-12 col-12">
                                        <div class="card mb-4 card-hover">
                                            <div class="row no-gutters payment-container">
                                                <div class="product-g-warper">
                                                    <div class="prdocut-left-warper">
                                                        <div class="product-img-dsc-warper">
                                                            <div class="products-image" width="80" height="80"
                                                                 style="background:url(<?= base_url($urun->urun_resim) ?>)"><?php if (!kategori_reklam_kontrol($urun->urun_id) && 1 == 0) { ?>
                                                                    <span class="fas fa-bolt onecikan"
                                                                          data-toggle="tooltip"
                                                                          data-placement="top"
                                                                          data-original-title="Öne Çıkan"></span>
                                                                <?php } ?>

                                                            </div>
                                                            <div class="products-title">
                                                                <?= $urun->urun_ad; ?>
                                                                <div class="products-desc">
                                                                    <?= $urun->urun_aciklama; ?>
                                                                </div>
                                                                <div class="price-item-warper-sc">
                                                                    <?php
                                                                    $oran = 0;
                                                                    if ($urun->urun_eski_fiyat > $urun->urun_fiyat):
                                                                        $oran = 100 - ceil($urun->urun_fiyat * 100 / $urun->urun_eski_fiyat);
                                                                        ?>
                                                                        <div class="discountBubble"><b>%<?= $oran ?></b>İNDİRİM
                                                                        </div>
                                                                    <?php endif; ?>
                                                                    <div class="products-price <?= $oran > 0 ? 'on-discount' : ''; ?>">
                                                                        <div class="h3-price">
                                                                            <div class="mb-2">
                                                                                <div>
                                                                                        <span style="font-size: 21px;" class="sft-smaller urun-<?php  echo $urun->urun_id ?>"><?= $urun->urun_fiyat ?>
                                                                                            <small style="font-size: 21px;">₺</small></span>

                                                                                    <?php if ($urun->urun_eski_fiyat > $urun->urun_fiyat): ?>
                                                                                        <s style="font-size: 16px;color:#979aae!important;margin-left:10px"><?= $urun->urun_eski_fiyat ?>
                                                                                            ₺</s>
                                                                                    <?php endif; ?>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="product-right-warper">
                                                        <div class="stockCountBox cs-count-box-warper">
                                                            <button type="button"
                                                                    class="btn btn-purchase-count btn-minus"
                                                                    data-id="<?= $urun->urun_id ?>" data-price="<?php echo $urun->urun_fiyat ?>">-
                                                            </button>
                                                            <input type="text" id="PurchaseCount_<?= $urun->urun_id ?>"
                                                                   data-id="<?= $urun->urun_id ?>" name="PurchaseCount"
                                                                   class="form-control" min="1" max="10" value="1"
                                                                   onkeyup="if (!window.__cfRLUnblockHandlers) return false; if (/\D/g.test(this.value)) this.value = this.value.replace(/\D/g,'')">
                                                            <button type="button"
                                                                    class="btn btn-purchase-count btn-plus"
                                                                    data-id="<?= $urun->urun_id ?>" data-price="<?php echo $urun->urun_fiyat ?>">+
                                                            </button>
                                                        </div>
                                                        <div class="btn-sc-warper">
                                                            <?php if ($urun->admin) : ?>
                                                                <div class="sale-take-btns-warper">
                                                                    <a role="button"
                                                                       data-urun_id="<?= $urun->urun_id ?>"
                                                                       class="products-buy cs-sl-btn hover-color product_fonk_<?= $urun->urun_id ?>">
                                                                        Satın Al</a>
                                                                </div>
                                                                <script>
                                                                    $('.products-buy.product_fonk_<?= $urun->urun_id ?>').on('click', function () {
                                                                        // swal.fire
                                                                        Swal.fire({
                                                                            title: 'Satın alma onayı',
                                                                            text: "Bu ürünü satın almak istediğinize emin misiniz? Sanal ürünlerin geri iadesi bulunmamaktadır.",
                                                                            icon: 'warning',
                                                                            showCancelButton: true,
                                                                            confirmButtonText: 'Evet, Satın Al',
                                                                            cancelButtonText: 'Hayır, İptal Et',
                                                                        }).then((result) => {
                                                                            /* Read more about isConfirmed, isDenied below */
                                                                            if (result.isConfirmed) {
                                                                                var urun_id = $(this).data('urun_id');
                                                                                <?php if (aktif_kullanici()) : ?>
                                                                                var kullanici_bakiye = <?= $kullanici->bakiye ?>;
                                                                                var urun_fiyat = <?= $urun->urun_fiyat ?>;
                                                                                var urun_stok = <?= $urun->urun_stok ?>;
                                                                                var qty = $('#PurchaseCount_' + urun_id).val();
                                                                                if (urun_stok <= 0) {
                                                                                    Swal.fire({
                                                                                        title: 'Stokta Yok',
                                                                                        text: "Bu ürün stokta bulunmamaktadır.",
                                                                                        icon: 'error',
                                                                                        showCancelButton: true,
                                                                                        confirmButtonText: 'Tamam',
                                                                                    }).then((result) => {
                                                                                    });
                                                                                    return false;
                                                                                }
                                                                                if (qty > urun_stok) {
                                                                                    Swal.fire({
                                                                                        title: 'Stokta Yetersiz',
                                                                                        text: "Bu üründen " + urun_stok + " adet kaldı.",
                                                                                        icon: 'error',
                                                                                        showCancelButton: true,
                                                                                        confirmButtonText: 'Tamam',
                                                                                    }).then((result) => {
                                                                                    });
                                                                                    return false;
                                                                                }
                                                                                if (urun_fiyat > kullanici_bakiye) {
                                                                                    Swal.fire({
                                                                                        title: 'Bakiye Yetersiz',
                                                                                        text: "Bu ürünü satın almak için bakiyeniz yetersiz.",
                                                                                        icon: 'error',
                                                                                        showCancelButton: true,
                                                                                        confirmButtonText: 'Bakiye Yükle',
                                                                                        cancelButtonText: 'Hayır, İptal Et',
                                                                                    }).then((result) => {
                                                                                        if (result.isConfirmed) {
                                                                                            window.location.href = "<?= base_url('bakiye') ?>";
                                                                                        }
                                                                                    });
                                                                                    return false;
                                                                                }
                                                                                $.post({
                                                                                    url: "<?= base_url('odeme-yap') . '/' ?>" + urun_id,
                                                                                    type: 'POST',
                                                                                    data: {
                                                                                        urun_id: urun_id,
                                                                                        qty: qty,
                                                                                    },
                                                                                    success: function (response) {
                                                                                        if (response.status === 'success') {
                                                                                            Swal.fire({
                                                                                                title: 'Satın alma işlemi başarılı',
                                                                                                text: response.message,
                                                                                                icon: 'success',
                                                                                                showCancelButton: true,
                                                                                                confirmButtonText: 'Siparişlerim Sayfasına Git',
                                                                                                cancelButtonText: 'Geri Dön',
                                                                                            }).then((result) => {
                                                                                                if (result.isConfirmed) {
                                                                                                    window.location.href = "<?= base_url('siparislerim') ?>";
                                                                                                }
                                                                                            })
                                                                                        } else {
                                                                                            Swal.fire({
                                                                                                title: 'Satın alma işlemi başarısız',
                                                                                                text: response.message,
                                                                                                icon: 'error',
                                                                                                showCancelButton: true,
                                                                                                confirmButtonText: 'Tamam',
                                                                                                cancelButtonText: 'Kapat',
                                                                                            }).then((result) => {
                                                                                            });
                                                                                        }
                                                                                    },
                                                                                    error: function (response) {
                                                                                        console.log(response);
                                                                                    }
                                                                                });
                                                                                <?php else : ?>
                                                                                Swal.fire({
                                                                                    title: 'Giriş Yap',
                                                                                    text: "Ürünü satın almak için giriş yapmalısınız.",
                                                                                    icon: 'warning',
                                                                                    showCancelButton: true,
                                                                                    confirmButtonText: 'Giriş Yap',
                                                                                    cancelButtonText: 'Hayır, İptal Et',
                                                                                }).then((result) => {
                                                                                    if (result.isConfirmed) {
                                                                                        window.location.href = "<?= base_url('giris-yap') ?>";
                                                                                    }
                                                                                })
                                                                                <?php endif; ?>
                                                                            }
                                                                        })
                                                                    });
                                                                </script>
                                                            <?php else : ?>
                                                                <a role="button" href="<?= base_url($urun->urun_seo) ?>"
                                                                   class=" buy-btn"> Satın Al</a>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php }
                            } else { ?>
                                <div class="col-md-12">
                                    <div class="alert alert-warning text-center alert-custom"> Kategoriye Ait Ürün
                                        Bulunamadı
                                    </div>
                                </div>
                            <?php } ?>
                            <div class="col-12">
                                <div class="gl-tab">
                                    <ul class="nav nav-tabs">
                                        <li class="active" data-index="0"><a data-toggle="tab"
                                                                             href="#aciklama">Açıklama</a></li>
                                    </ul>
                                </div>
                                    <div class="panel-bg-custom">
                                        <div class="tab-content">
                                            <div id="aciklama" class="tab-pane active"><?= $kategori->aciklama; ?></div>
                                        </div>
                                    </div>
                            </div>
                            <div class="col-lg-12 col-md-12">
                                <div class="dashboard-list-box  margin-top-0">
                                    <div class="comrew-tt">
                                        Yorumlar
                                    </div>
                                    <ul class="dw-item-list">
                                        <?php if (!empty($yorumlar)) { ?>
                                        <?php foreach ($yorumlar as $key => $val) { ?>
                                        <li class="dw-item mb-3">
                                            <div class="comments listing-reviews">
                                                <ul class="dw-item-sub-list">
                                                    <li class="dw-item-sub-list-item">
                                                        <div class="avatar">
                                                            <img src="<?php echo !empty($val->kullanici_resim) ? base_url($val->kullanici_resim) : '' ?>" alt="Avatar">
                                                        </div>
                                                        <div class="comment-content">
                                                            <div class="arrow-comment">
                                                            </div>
                                                            <div class="comment-by">
                                                                <?php echo $val->kullanici_ad ?>
                                                                <div class="comment-by-listing">
                                                                    - <?php echo $val->urun_ad ?>
                                                                </div>
                                                                <span class="date"><?php echo zamanCevir($val->yorum_zaman) ?></span>
                                                                <div class="star-rating-dsw" data-rating="5">
                                                                    <ul class="star-rating mn-value pt-0">
                                                                        <?php if ($val->yorum_puan == 0) { ?>
                                                                            <li>
                                                                                <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                            </li>
                                                                            <li>
                                                                                <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                            </li>
                                                                            <li>
                                                                                <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                            </li>
                                                                            <li>
                                                                                <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                            </li>
                                                                            <li>
                                                                                <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                            </li>
                                                                        <?php } else if ($val->yorum_puan >= 1 && $val->yorum_puan < 2) { ?>
                                                                            <li>
                                                                                <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star">
                                                                            </li>
                                                                            <li>
                                                                                <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                            </li>
                                                                            <li>
                                                                                <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                            </li>
                                                                            <li>
                                                                                <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                            </li>
                                                                            <li>
                                                                                <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                            </li>
                                                                        <?php } else if ($val->yorum_puan >= 2 && $val->yorum_puan < 3) { ?>
                                                                            <li>
                                                                                <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star">
                                                                            </li>
                                                                            <li>
                                                                                <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star">
                                                                            </li>
                                                                            <li>
                                                                                <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                            </li>
                                                                            <li>
                                                                                <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                            </li>
                                                                            <li>
                                                                                <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                            </li>
                                                                        <?php } else if ($val->yorum_puan >= 3 && $val->yorum_puan < 4) { ?>
                                                                            <li>
                                                                                <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star">
                                                                            </li>
                                                                            <li>
                                                                                <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star">
                                                                            </li>
                                                                            <li>
                                                                                <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star">
                                                                            </li>
                                                                            <li>
                                                                                <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                            </li>
                                                                            <li>
                                                                                <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                            </li>
                                                                        <?php } else if ($val->yorum_puan >= 4 && $val->yorum_puan < 5) { ?>
                                                                            <li>
                                                                                <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star">
                                                                            </li>
                                                                            <li>
                                                                                <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star">
                                                                            </li>
                                                                            <li>
                                                                                <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star">
                                                                            </li>
                                                                            <li>
                                                                                <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star">
                                                                            </li>
                                                                            <li>
                                                                                <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                            </li>
                                                                        <?php } else if ($val->yorum_puan == 5 && $val->yorum_puan > 5) { ?>
                                                                            <li>
                                                                                <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star">
                                                                            </li>
                                                                            <li>
                                                                                <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star">
                                                                            </li>
                                                                            <li>
                                                                                <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star">
                                                                            </li>
                                                                            <li>
                                                                                <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star">
                                                                            </li>
                                                                            <li>
                                                                                <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star">
                                                                            </li>
                                                                        <?php } else { ?>
                                                                            <li>
                                                                                <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                            </li>
                                                                            <li>
                                                                                <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                            </li>
                                                                            <li>
                                                                                <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                            </li>
                                                                            <li>
                                                                                <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                            </li>
                                                                            <li>
                                                                                <img width="12" height="12" loading="lazy" src="<?= base_url('assets/front/images/star/rating_star.webp'); ?>" alt="star gray">
                                                                            </li>
                                                                        <?php } ?>
                                                                        <li>
                                                                            <span style="margin-left: 5px"> (<?php echo count($yorumlar) ?>)</span>
                                                                        </li>
                                                                    </ul>
                                                                </div>
                                                            </div>
                                                            <p><?php echo $val->yorum_detay ?></p>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </div>
                                        </li>
                                        <?php } ?>
                                        <?php } else { ?>
                                            <div class="alert alert-warning" role="alert">
                                                Yorum Bulunmamaktadır!
                                            </div>
                                        <?php } ?>

                                    </ul>
                                </div>
                            </div>
                            <?php if (!empty($yorum_pagi)) { ?>
                            <div class="col-12 mb-3">
                                <div class="pegination">
                                    <ul class="pegi-list">
                                       <?php echo $yorum_pagi ?>
                                    </ul>
                                </div>
                            </div>
                            <?php } ?>
                        </div>
                        <div class="product-review">
                            <button class="btn btn-nasil-kullanilir" data-toggle="modal"
                                    data-target="#nasil_kullanilir"><i class="fas fa-book"></i>&nbsp;Nasıl Kullanılır?
                            </button>
                        </div>
                    </div>
                    <!-- Tab pane -->
                    <div class="tab-pane fade show active pb-4 " id="tabPaneGrid" role="tabpanel"
                         aria-labelledby="tabPaneGrid">
                        <div class="row"></div>
                        <?= $links ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php elseif ($where->kategori_tur == 1): ?>
    <div class="py-6">
        <div class="container">
            <div class="row">
                <div class="header--area">
                    <div class="header--inner--content">
                        <div class="header--inner--content--top">
                            <div class="content--image">
                                <img width="230" height="140" style="object-fit: none;"
                                     src="<?= base_url($kategori->kategori_resim) ?>" alt="">
                            </div>
                            <div class="content--text">
                                <h1><?= $kategori->ust_baslik ?></h1>
                                <p><?= $kategori->ust_baslik_altyazi ?></p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-12 col-lg-12 col-md-12 col-12 px-0 mt-5">
                    <?php if ($vitrin_urunler) { ?>
                        <div class="tab-content">
                            <!-- Tab pane -->
                            <div class="tab-pane fade show active pb-4 " id="tabPaneGrid" role="tabpanel"
                                 aria-labelledby="tabPaneGrid">
                                <div class="item--list">
                                    <?php foreach ($vitrin_urunler as $urun) {
                                        $magaza = magaza($urun->kullanici_id);
                                        ?>
                                        <div class="item">
                                            <div class="featured--area">
                                                <span class="icon"></span>
                                                <span class="text"> İLAN </span>
                                            </div>
                                            <div class="item--image">
                                                <a href="<?= base_url($urun->urun_seo); ?>">
                                                    <img class="hoverimg border-"
                                                         style="object-fit: cover; border-radius: 5px;" width="160"
                                                         height="160" src="<?= base_url($urun->urun_resim); ?>" alt="">
                                                </a>
                                            </div>
                                            <div class="item--info">
                                                <a href="<?= base_url($urun->urun_seo); ?>"
                                                   class="product--name"><?= $urun->urun_ad ?></a>
                                                <p class="product--exp"><?= strip_tags($urun->urun_aciklama); ?></p>
                                                <div class="item--bottom">
                                                    <?php if ($urun->urun_turu == 2): ?>
                                                        <span>Otomatik Teslimat </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="item--price">
                                                <strong><?= $urun->urun_fiyat ?> ₺</strong>
                                                <a href="<?= base_url($urun->urun_seo) ?>">İlanı Görüntüle</a>
                                            </div>
                                            <div class="item--user">
                                                <div class="user--image">
                                                    <a href="<?= base_url('m/' . $magaza->magaza_seo); ?>">
                                                        <img width="85" height="85"
                                                             src="<?= base_url($magaza->magaza_resim) ?>" alt=""
                                                             style="">
                                                    </a>
                                                </div>
                                                <span class="triangle"></span>
                                                <div class="user--info">
                                                    <a href="<?= base_url('m/' . $magaza->magaza_seo) ?>"><?= $magaza->magaza_ad; ?></a>
                                                </div>
                                            </div>
                                        </div>
                                    <?php } ?>
                                </div>
                            </div>
                        </div>
                    <?php } ?>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>
<div class="modal fade" id="nasil_kullanilir" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
     aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content sms">
            <div class="modal-header">
                <h4 class="modal-title text-center" id="exampleModalCenterTitle">Nasıl Kullanılır ?</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <?= $kategori->nasil_kullanilir ?>
            </div>
        </div>
    </div>
</div>

<!-- Footer -->
<script>

    const minusBtn = document.querySelectorAll('.btn-minus');
    const plusBtn = document.querySelectorAll('.btn-plus');

    for (let i = 0; i < minusBtn.length; i++) {
        minusBtn[i].addEventListener('click', function () {
            var prodId = this.getAttribute('data-id');
            var countInput = document.getElementById('PurchaseCount_' + prodId);
            let count = parseInt(countInput.value);
            if (isNaN(count)) {
                count = 1;
            } else {
                count = count - 1 < 1 ? 1 : count - 1;
            }
            countInput.value = count;

            var price = $(this).data('price');
            $('.urun-'+prodId).html(formatNumber(count * price) + ' <small style="font-size: 21px;">₺</small>');

        });
    }
    for (let i = 0; i < plusBtn.length; i++) {
        plusBtn[i].addEventListener('click', function () {
            var prodId = this.getAttribute('data-id');
            var countInput = document.getElementById('PurchaseCount_' + prodId);
            let count = parseInt(countInput.value);
            if (isNaN(count)) {
                count = 1;
            } else {
                count = count + 1 > 10 ? 10 : count + 1;
            }

            countInput.value = count;

            var price = $(this).data('price');
            $('.urun-'+prodId).html(formatNumber(count * price) + ' <small style="font-size: 21px;">₺</small>');
        });
    }

    function formatNumber(num) {
        // Sayıyı istenen formata göre biçimlendirme
        return num.toLocaleString('en-US', {
            minimumFractionDigits: 2,  // En az 2 ondalık basamak göster
            maximumFractionDigits: 2   // En fazla 2 ondalık basamak göster
        });
    }
</script>
<style>
    body {
        color: white !important;
    }
</style>