<div class="py-lg-6 py-4 bg-primary">
    <div class="container">
        <div class="row">
            <div class="col-xl-12 col-lg-12 col-md-12 col-12">
                <div>
                    <h1 class="text-white display-4 mb-0">Sipariş Oluştur</h1>
                </div>
            </div>
        </div>
    </div>
</div>
<?php if(isset($_SESSION["kullanici"])){
  
  $udata=kullanicicek();

}
?>

<form class="form-row" id="bilgiler" method="post"
                              action="<?= base_url('siparis-olustur/' . $urun->urun_uniq) ?>">
                        </form>
<div class="py-6">
    <div class="container">
        <div class="row">
        
            <div class="col-lg-12 col-md-12 col-12">
                
                <div class="card  border-0 mb-3">
                    
                    <div class="p-5 text-center">
                        <img class="img-fluid border-radius-20" src="<?= base_url($urun->urun_resim) ?>"
                             alt="<?= $urun->urun_ad ?>">
                        <div class="mb-5 mt-3">
                            <h4 class="font-weight-bold"><?= $urun->urun_ad ?></h4>
                        </div>
                        <!-- hr -->
                        <hr class="m-0 mb-4">
                        <h6 class="m-0">Toplam Tutar</h6>
                        <div class="d-flex justify-content-center">
                            <div class="display-4 font-weight-bold text-primary"><?= $urun->urun_fiyat ?></div>
                            <span class="h3 mb-0 font-weight-bold text-primary">₺</span>
                        </div>
                        <hr class="m-0 mb-4 mt-3">
                        <?php $site = ayarlar();
                        $o = $site->paytr_durum;
                        $s = $site->iyzico_durum;

                        if ($s == 1) { ?>

                            <button type="submit" form="bilgiler" name="odeme" value="iyzico"
                                    class="btn btn-outline-primary btn-block rounded-pill">
                                <img src="https://media.iyzico.com/b/2021/10/brand-1-logo-3-subbrands-1-pwi-1-tr-1-colored.png" style="height:20px;"> Iyzico ile Ödeme Yap
                            </button>
                            <?php
                        }
                        if ($o == 1) { ?>

                            <button type="submit" form="bilgiler" name="odeme" value="paytr"
                                    class="btn btn-outline-primary btn-block rounded-pill">
                               <img src="https://www.paytr.com/img/general/PayTR-Odeme-Kurulusu.svg?v01" style="height:10px;">  PayTr ile Ödeme Yap
                            </button>

                        <?php }
                        ?>

                        <button type="submit" form="bilgiler" name="odeme" value="bakiye"
                                class="btn btn-outline-primary btn-block rounded-pill">
                            Bakiye ile Ödeme Yap
                        </button>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>