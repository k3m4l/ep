
<?php


$site =ayarlar();

$tat =  explode("/", $_SERVER['REQUEST_URI']);

if ($tat[3] == "iyzico" and $site->iyzico_durum == 1) {


$request = new \Iyzipay\Request\CreateCheckoutFormInitializeRequest();
$request->setLocale(\Iyzipay\Model\Locale::TR);
$request->setConversationId('123456789');
$request->setPrice($siparis->siparis_tutar);
$request->setPaidPrice($siparis->siparis_tutar);
$request->setCurrency(\Iyzipay\Model\Currency::TL);
$request->setBasketId($siparis->siparis_no);
$request->setPaymentGroup(\Iyzipay\Model\PaymentGroup::PRODUCT);
$request->setCallbackUrl(base_url('home_controller/odeme_onay'));
$request->setEnabledInstallments(array(2, 3, 6, 9));

$buyer = new \Iyzipay\Model\Buyer();
$buyer->setId($kullanici->kullanici_id);
$buyer->setName($siparis->siparis_ad);
$buyer->setSurname($siparis->siparis_soyad);
$buyer->setGsmNumber($siparis->siparis_tel);
$buyer->setEmail($kullanici->kullanici_mail);
$buyer->setIdentityNumber("74300864791");
$buyer->setLastLoginDate($kullanici->kullanici_sonzaman);
$buyer->setRegistrationDate($kullanici->kullanici_zaman);
$buyer->setRegistrationAddress($siparis->siparis_adres);
$buyer->setIp(getIPAddress());
$buyer->setCity(sehir_ad($siparis->siparis_il));
$buyer->setCountry("Turkey");
$buyer->setZipCode($siparis->siparis_posta);

$request->setBuyer($buyer);
$shippingAddress = new \Iyzipay\Model\Address();
$shippingAddress->setContactName($siparis->siparis_ad." ".$siparis->siparis_soyad);
$shippingAddress->setCity(sehir_ad($siparis->siparis_il));
$shippingAddress->setCountry("Turkey");
$shippingAddress->setAddress($siparis->siparis_adres);
$shippingAddress->setZipCode($siparis->siparis_posta);
$request->setShippingAddress($shippingAddress);

$billingAddress = new \Iyzipay\Model\Address();
$billingAddress->setContactName($siparis->siparis_ad." ".$siparis->siparis_soyad);
$billingAddress->setCity(sehir_ad($siparis->siparis_il));
$billingAddress->setCountry("Turkey");
$billingAddress->setAddress($siparis->siparis_adres);
$billingAddress->setZipCode($siparis->siparis_posta);
$request->setBillingAddress($billingAddress);

$basketItems = array();
$firstBasketItem = new \Iyzipay\Model\BasketItem();
$firstBasketItem->setId($siparis->siparis_no);
$firstBasketItem->setName($siparis->urun_ad);
$firstBasketItem->setCategory1($siparis->urun_ad);
$firstBasketItem->setCategory2($siparis->urun_ad);
$firstBasketItem->setItemType(\Iyzipay\Model\BasketItemType::PHYSICAL);
$firstBasketItem->setPrice($siparis->siparis_tutar);
$basketItems[0] = $firstBasketItem;

$request->setBasketItems($basketItems);

$checkoutFormInitialize = \Iyzipay\Model\CheckoutFormInitialize::create($request, $options);
//print_r($checkoutFormInitialize->getStatus());
//print_r($checkoutFormInitialize->getErrorMessage());
print_r($checkoutFormInitialize->getCheckoutFormContent());
   ?>

<div class="py-lg-6 py-4 bg-primary">
    <div class="container">
        <div class="row">
            <div class="col-xl-12 col-lg-12 col-md-12 col-12">
                <div>
                    <h1 class="text-white display-4 mb-0">Ödeme Yap</h1>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="py-6">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                
                <div class="card  mb-4">
                    
                    <div class="card-header">
                        <h3 class="mb-0">3D Güvenli Ödeme</h3>
                    </div>
                    
                    <div class="card-body">
                        <div id="iyzipay-checkout-form" class="responsive"></div>
                        <div id="ucs-cards"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
   <?php
}else{
   // redirect(base_url());
}

if ($tat[3] == "paytr" and $site->paytr_durum == 1) {
error_reporting(0);
    ## API Entegrasyon Bilgileri - Mağaza paneline giriş yaparak BİLGİ sayfasından alabilirsiniz.
    $merchant_id    = $site->paytr_merchant_id;
    $merchant_key   = $site->paytr_api;
    $merchant_salt  = $site->paytr_secret;
    #
    ## Müşterinizin sitenizde kayıtlı veya form vasıtasıyla aldığınız eposta adresi
    $email =$kullanici->kullanici_mail;
    #
    ## Tahsil edilecek tutar.
    $payment_amount = $siparis->siparis_tutar*100; //9.99 için 9.99 * 100 = 999 gönderilmelidir.
    #
    ## Sipariş numarası: Her işlemde benzersiz olmalıdır!! Bu bilgi bildirim sayfanıza yapılacak bildirimde geri gönderilir.
    $merchant_oid = $siparis->siparis_no;
    #
    ## Müşterinizin sitenizde kayıtlı veya form aracılığıyla aldığınız ad ve soyad bilgisi
    $user_name = $siparis->siparis_ad." ".$siparis->siparis_soyad;
    #
    ## Müşterinizin sitenizde kayıtlı veya form aracılığıyla aldığınız adres bilgisi
    $user_address = $siparis->siparis_adres;
    #
    ## Müşterinizin sitenizde kayıtlı veya form aracılığıyla aldığınız telefon bilgisi
    $user_phone =$siparis->siparis_tel;
    #
    ## Başarılı ödeme sonrası müşterinizin yönlendirileceği sayfa
    ## !!! Bu sayfa siparişi onaylayacağınız sayfa değildir! Yalnızca müşterinizi bilgilendireceğiniz sayfadır!
    ## !!! Siparişi onaylayacağız sayfa "Bildirim URL" sayfasıdır (Bakınız: 2.ADIM Klasörü).
    $merchant_ok_url = base_url('home_controller/odeme_onay_paytr');
    #
    ## Ödeme sürecinde beklenmedik bir hata oluşması durumunda müşterinizin yönlendirileceği sayfa
    ## !!! Bu sayfa siparişi iptal edeceğiniz sayfa değildir! Yalnızca müşterinizi bilgilendireceğiniz sayfadır!
    ## !!! Siparişi iptal edeceğiniz sayfa "Bildirim URL" sayfasıdır (Bakınız: 2.ADIM Klasörü).
    $merchant_fail_url = base_url('home_controller/odeme_onay_paytr');
    #
    ## Müşterinin sepet/sipariş içeriği
    $user_basket = array($siparis->urun_ad,$siparis->siparis_tutar);;
    #
    /* ÖRNEK $user_basket oluşturma - Ürün adedine göre array'leri çoğaltabilirsiniz
    $user_basket = base64_encode(json_encode(array(
        array("Örnek ürün 1", "18.00", 1), // 1. ürün (Ürün Ad - Birim Fiyat - Adet )
        array("Örnek ürün 2", "33.25", 2), // 2. ürün (Ürün Ad - Birim Fiyat - Adet )
        array("Örnek ürün 3", "45.42", 1)  // 3. ürün (Ürün Ad - Birim Fiyat - Adet )
    )));
    */
    ############################################################################################

    ## Kullanıcının IP adresi
    if( isset( $_SERVER["HTTP_CLIENT_IP"] ) ) {
        $ip = $_SERVER["HTTP_CLIENT_IP"];
    } elseif( isset( $_SERVER["HTTP_X_FORWARDED_FOR"] ) ) {
        $ip = $_SERVER["HTTP_X_FORWARDED_FOR"];
    } else {
        $ip = $_SERVER["REMOTE_ADDR"];
    }

    ## !!! Eğer bu örnek kodu sunucuda değil local makinanızda çalıştırıyorsanız
    ## buraya dış ip adresinizi (https://www.whatismyip.com/) yazmalısınız. Aksi halde geçersiz paytr_token hatası alırsınız.
    $user_ip=$ip;
    ##

    ## İşlem zaman aşımı süresi - dakika cinsinden
    $timeout_limit = "30";

    ## Hata mesajlarının ekrana basılması için entegrasyon ve test sürecinde 1 olarak bırakın. Daha sonra 0 yapabilirsiniz.
    $debug_on = 0;

    ## Mağaza canlı modda iken test işlem yapmak için 1 olarak gönderilebilir.
    $test_mode = 0;

    $no_installment = 0; // Taksit yapılmasını istemiyorsanız, sadece tek çekim sunacaksanız 1 yapın

    ## Sayfada görüntülenecek taksit adedini sınırlamak istiyorsanız uygun şekilde değiştirin.
    ## Sıfır (0) gönderilmesi durumunda yürürlükteki en fazla izin verilen taksit geçerli olur.
    $max_installment = 0;

    $currency = "TL";
    
    ####### Bu kısımda herhangi bir değişiklik yapmanıza gerek yoktur. #######
    $hash_str = $merchant_id .$user_ip .$merchant_oid .$email .$payment_amount .$user_basket.$no_installment.$max_installment.$currency.$test_mode;
    $paytr_token=base64_encode(hash_hmac('sha256',$hash_str.$merchant_salt,$merchant_key,true));
    $post_vals=array(
            'merchant_id'=>$merchant_id,
            'user_ip'=>$user_ip,
            'merchant_oid'=>$merchant_oid,
            'email'=>$email,
            'payment_amount'=>$payment_amount,
            'paytr_token'=>$paytr_token,
            'user_basket'=>$user_basket,
            'debug_on'=>$debug_on,
            'no_installment'=>$no_installment,
            'max_installment'=>$max_installment,
            'user_name'=>$user_name,
            'user_address'=>$user_address,
            'user_phone'=>$user_phone,
            'merchant_ok_url'=>$merchant_ok_url,
            'merchant_fail_url'=>$merchant_fail_url,
            'timeout_limit'=>$timeout_limit,
            'currency'=>$currency,
            'test_mode'=>$test_mode
        );
    
    $ch=curl_init();
    curl_setopt($ch, CURLOPT_URL, "https://www.paytr.com/odeme/api/get-token");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, 1) ;
    curl_setopt($ch, CURLOPT_POSTFIELDS, $post_vals);
    curl_setopt($ch, CURLOPT_FRESH_CONNECT, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 20);
    
     // XXX: DİKKAT: lokal makinanızda "SSL certificate problem: unable to get local issuer certificate" uyarısı alırsanız eğer
     // aşağıdaki kodu açıp deneyebilirsiniz. ANCAK, güvenlik nedeniyle sunucunuzda (gerçek ortamınızda) bu kodun kapalı kalması çok önemlidir!
     // curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
     
    $result = @curl_exec($ch);

    if(curl_errno($ch))
        die("PAYTR IFRAME connection error. err:".curl_error($ch));

    curl_close($ch);
    
    $result=json_decode($result,1);
        
    if($result['status']=='success')
        $token=$result['token'];
    else
        die("PAYTR IFRAME failed. reason:".$result['reason']);
    #########################################################################

?>

<!-- Ödeme formunun açılması için gereken HTML kodlar / Başlangıç -->
    <script src="https://www.paytr.com/js/iframeResizer.min.js"></script>
    <iframe src="https://www.paytr.com/odeme/guvenli/<?php echo $token;?>" id="paytriframe" frameborder="0" scrolling="no" style="width: 100%;"></iframe>
    <script>iFrameResize({},'#paytriframe');</script>
    <!-- Ödeme formunun açılması için gereken HTML kodlar / Bitiş -->



<?php 

}else{
    //redirect(base_url());
}

?>