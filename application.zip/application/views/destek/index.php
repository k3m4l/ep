<section class="pt-3 pb-3 page-info section-padding border-bottom bg-white">
   <div class="container">
      <div class="row">
         <div class="col-md-12">
            <a href="<?=base_url()?>">
               <strong><span class="mdi mdi-home"></span> Anasayfa</strong>
            </a> 
            <span class="mdi mdi-chevron-right"></span> 
            <a href="<?=base_url("destek-sistemi")?>">Destek Sistemi</a>
         </div>
      </div>
   </div>
</section>
<section class="cart-page section-padding">
   <div class="container">
      <div class="row">
         <div class="col-md-12">
            <div class="card mt-2">
               <h5 class="card-header">Destek Sistemi</h5>
               <form method="post" action="<?=base_url("destek-sistemi/gonder")?>" id="form1">
                  <div class="card-footer cart-sidebar-footer">
                     <div class="cart-store-details">
                        <small><code>DİKKAT! E-Posta adresinizin doğru olduğuna emin olun. Destek cevabı e-posta adresinize gönderilecektir.</code></small>
                        <input type="text" name="ad" class="form-control" placeholder="Ad Soyadınız" required="" style="margin-bottom: 10px;">
                        <?php if (isset($form_error)) { ?> <small style="color: red;"><code class="pull-right"><?=form_error('ad')?></code></small><?php } ?>
                        <input type="mail" name="mail" class="form-control" placeholder="E-Posta Adresiniz" required="" style="margin-bottom: 10px;">
                        <?php if (isset($form_error)) { ?> <small style="color: red;"><code class="pull-right"><?=form_error('mail')?></code></small><?php } ?>
                        <input type="number" name="tel" onKeyDown="if(this.value.length==11) return false;" class="form-control" placeholder="Telefon Numaranız" required="" style="margin-bottom: 10px;">
                        <?php if (isset($form_error)) { ?> <small style="color: red;"><code class="pull-right"><?=form_error('tel')?></code></small><?php } ?>
                        <select class="form-control" name="konu">
                           <?php if (konular()) {  $konular = konular(); ?>
                             <?php foreach ($konular as $key) { ?>
                              <option value="<?=$key->konu_id?>"><?=$key->konu_ad?></option>
                           <?php } ?>
                        <?php } ?>
                     </select>
                     <textarea class="form-control" rows="5" name="mesaj" style="margin-top: 10px;" placeholder="Lütfen Mesajınızı Girin.." required=""></textarea>
                     <small><code>Siparişiniz İle Alakalı Sorun Yaşıyorsanız Lütfen Sipariş Numarasını Eklemeyi Unutmayın!</code></small>
                     <?php if (isset($form_error)) { ?> <small style="color: red;"><code class="pull-right"><?=form_error('mesaj')?></code></small><?php } ?>
                     <div class="g-recaptcha" style="margin-top: 10px; margin-bottom: 10px" data-sitekey="<?php print_r($google_key); ?>"></div>
                  </div>

                  <a href="javascript:void()" onclick="document.getElementById('form1').submit();">
                     <button class="btn btn-secondary btn-lg btn-block text-left" type="button">
                        <span class="float-left"><i class="mdi mdi-comment-alert-outline"></i> Yeni Destek Talebi </span>
                        <span class="float-right"><strong>Oluştur</strong> 
                           <span class="mdi mdi-chevron-right"></span></span>
                        </button>
                     </a>
                  </div>
               </form>
            </div>
         </div>
      </div>
   </div>
</section>