<?php 

$kategoriler = kategoricek();
$ayarlar = ayarlar();

?>
<style type="text/css">
	#maps {
    width: 100%;
    height: 400px;
	}
</style>
<div id="dashboard">

	<!-- Navigation
	================================================== -->

	<!-- Responsive Navigation Trigger -->
	<a href="#" class="dashboard-responsive-nav-trigger"><i class="fa fa-reorder"></i> Navigation</a>

	<?php $this->load->view("kpanel/inc/menu"); ?>
	<!-- Navigation / End -->


	<!-- Content
	================================================== -->
	<div class="dashboard-content">

		<!-- Titlebar -->
		<div id="titlebar">
			<div class="row">
				<div class="col-md-12">
					<h2><?=$where->firma_ad?> - Düzenle</h2>
					<!-- Breadcrumbs -->
					<nav id="breadcrumbs">
						<ul>
							<li><a href="<?=base_url()?>">Anasayfa</a></li>
							<li><a href="<?=base_url("kullanici-paneli")?>">Kullanıcı Paneli</a></li>
							<li><?=$where->firma_ad?> - Düzenle</li>
						</ul>
					</nav>
				</div>
			</div>
		</div>

		<div class="row">

			<form method="post" action="<?=base_url("firmaduzenle/").$where->firma_uniq?>" enctype="multipart/form-data">

					<div id="add-listing" class="separated-form">

						<!-- Section -->
						<div class="add-listing-section">

							<!-- Headline -->
							<div class="add-listing-headline">
								<h3><i class="sl sl-icon-doc"></i> Firma Bilgileri</h3>
							</div>

							<!-- Title -->
							<div class="row with-forms">
								<div class="col-md-12">
									<h5>Firma Adı <i class="tip" data-tip-content="Firmanızın adını girerek daha fazla kişiye ulaşın."></i></h5>
									<input class="search-field" type="text" name="firmaad" placeholder="Firma Adı.." value="<?=$where->firma_ad?>" required="" />
								</div>
							</div>

							<!-- Row -->
							<div class="row with-forms">

								<!-- Status -->
								<div class="col-md-6">
									<h5>Kategoriler</h5>
									<select class="chosen-select-no-single" name="kategori" required="">
										<option label="blank" value="">Kategori Seçin</option>
										<?php foreach ($kategoriler as $key) { ?>
											<option <?php if ($where->kategori_id==$key->kategori_id) { echo "selected";} ?> value="<?=$key->kategori_id?>"><?=$key->kategori_ad?></option>
										<?php } ?>
									</select>
								</div>

								<!-- Type -->
								<div class="col-md-6">
									<h5>Firma Anahtar Kelimeler <i class="tip" data-tip-content="Firmanıza ait anahtar kelimeler eklemeniz daha fazla kişiye ulaşmanızı sağlar. Örn : rota bisiklet, bisikletçi, bisiklet tamiri"></i></h5>
									<input type="text" name="anahtar" placeholder="En fazla 15 tane anahtar kelime ekleyiniz.." value="<?=$where->firma_anahtar?>">
								</div>

							</div>
							<!-- Row / End -->

						</div>
						<!-- Section / End -->

						<!-- Section -->
						<div class="add-listing-section margin-top-45">

							<!-- Headline -->
							<div class="add-listing-headline">
								<h3><i class="sl sl-icon-location"></i> Adres ve Harita</h3>
							</div>

							<div class="submit-section">

								<!-- Row -->
								<div class="row with-forms">
									<div class="col-md-12">
										<small><code>Haritada seçtiğiniz nokta otomatik olarak adresi almaktadır.</code></small>
									</div>
									<div class="col-md-12">
										<h5>Haritada Ara</h5>
										<input id="searchInput" class="controls" type="text" placeholder="Haritada ara.." value="<?=$where->firma_adres?>">
									</div>

									<div class="col-md-12">
										<div class="map" id="maps"></div>
									</div>

									<div class="col-md-12" id="form_area">
										<input type="hidden" name="adres" id="location" value="<?=$where->firma_adres?>">
										<input type="hidden" name="lat" id="lat" value="<?=$where->firma_lat?>">
										<input type="hidden" name="lng" id="lng" value="<?=$where->firma_lon?>">
									</div>

								</div>
								<!-- Row / End -->

							</div>
						</div>
						<!-- Section / End -->


						<!-- Section -->
						<div class="add-listing-section margin-top-45">

							<!-- Headline -->
							<div class="add-listing-headline">
								<h3><i class="sl sl-icon-picture"></i> Firma Kapak Fotoğrafı</h3>
							</div>

							<div class="row with-forms">
								<div class="col-md-12">
									<h5>Varsayılan Kapak Fotoğrafı <i class="tip" data-tip-content="Sistemde Yüklü Olan Görsel"></i></h5>
									<img width="200" src="<?=base_url($where->firma_resim)?>">
								</div>
								<div class="col-md-12">
									<h5>Kapak Fotoğrafı <i class="tip" data-tip-content="Firma listelemesinde nasıl görünmek istersin?"></i></h5>
									<input class="search-field" type="file" name="file" accept=".jpg, .png, .jpeg" placeholder="Firma Kapak Fotoğrafı.."/>
								</div>
							</div>

						</div>
						<!-- Section / End -->


						<!-- Section -->
						<div class="add-listing-section margin-top-45">

							<!-- Headline -->
							<div class="add-listing-headline">
								<h3><i class="sl sl-icon-docs"></i> Detaylar</h3>
							</div>

							<!-- Description -->
							<div class="form">
								<h5>Tanıtım Yazısı</h5>
								<textarea class="WYSIWYG" name="tanitim" cols="40" rows="3" spellcheck="true" placeholder="Firma Tanıtım Yazısı" ><?=$where->firma_aciklama?></textarea>
							</div>

							<!-- Row -->
							<div class="row with-forms">

								<!-- Phone -->
								<div class="col-md-4">
									<h5>Telefon Numarası <span>(isteğe bağlı)</span></h5>
									<input type="number" name="tel" placeholder="Örn : 05xxxxxxxxx" value="<?=$where->firma_tel?>">
								</div>

								<!-- Website -->
								<div class="col-md-4">
									<h5>Web Site <span>(isteğe bağlı)</span></h5>
									<input type="text" name="website" placeholder="Örn : https://siteadresi.com.tr" value="<?=$where->firma_website?>">
								</div>

								<!-- Email Address -->
								<div class="col-md-4">
									<h5>E-Posta <span>(isteğe bağlı)</span></h5>
									<input type="text" name="mail" placeholder="Örn : info@siteadresi.com.tr" value="<?=$where->firma_mail?>">
								</div>

							</div>
							<!-- Row / End -->


							<!-- Row -->
							<div class="row with-forms">

								<!-- Phone -->
								<div class="col-md-4">
									<h5 class="fb-input"><i class="fa fa-facebook-square"></i> Facebook <span>(isteğe bağlı)</span></h5>
									<input type="text" name="facebook" placeholder="https://www.facebook.com/" value="<?=$where->firma_facebook?>">
								</div>

								<!-- Website -->
								<div class="col-md-4">
									<h5 class="twitter-input"><i class="fa fa-twitter"></i> Twitter <span>(isteğe bağlı)</span></h5>
									<input type="text" name="twitter" placeholder="https://www.twitter.com/" value="<?=$where->firma_twitter?>">
								</div>

								<!-- Email Address -->
								<div class="col-md-4">
									<h5 class="gplus-input"><i class="fa fa-instagram"></i> İnstagram <span>(isteğe bağlı)</span></h5>
									<input type="text" name="instagram" placeholder="https://instagram.com/" value="<?=$where->firma_instagram?>">
								</div>

							</div>
							<!-- Row / End -->


							<!-- Checkboxes -->
							<h5 class="margin-top-30 margin-bottom-10">Firma Hizmetleri <span>(isteğe bağlı)</span></h5>
							<div class="row with-forms">


								<div class="row">
									<div class="col-md-12">
										<table id="pricing-list-container">
										    <?php $hizmet = json_decode($where->firma_hizmetler); ?>
										    <?php foreach ($hizmet as $key) { ?>
											   <tr class="pricing-list-item pricing-submenu">
											      <td>
											         <div class="fm-move"><i class="sl sl-icon-cursor-move"></i></div>
											         <div class="fm-input"><input type="text" name="hizmet[]" value="<?=$key?>" placeholder="Hizmet Adı"></div>
											         <div class="fm-close"><a class="delete" href="#"><i class="fa fa-remove"></i></a></div>
											      </td>
											   </tr>
											<?php } ?>
										</table>
										<a href="#" class="button add-pricing-submenu">Yeni Hizmet Ekle</a>
									</div>
								</div>

							</div>

						</div>
						<!-- Section / End -->


						<!-- Section -->
						<div class="add-listing-section margin-top-45">
							
							<!-- Headline -->
							<div class="add-listing-headline">
								<h3><i class="sl sl-icon-clock"></i> Çalışma Saatleri</h3>
							</div>

								<!-- Day -->
								<div class="row opening-day">
									<div class="col-md-2"><h5>Hafta İçi</h5></div>
									<div class="col-md-5">
										<select class="chosen-select" name="haftaicisabah" data-placeholder="Açılış Saati">
											<option label="Açılış Saati"></option>
											<option <?php if ($where->firma_his=="Kapalı") { echo "selected"; }?> value="Kapalı">Kapalı</option>
											<option <?php if ($where->firma_his=="24 Saat Açık") { echo "selected"; }?> value="24 Saat Açık">24 Saat Açık</option>
											<option <?php if ($where->firma_his=="06:00") { echo "selected"; }?> value="06:00">06:00</option>
											<option <?php if ($where->firma_his=="07:00") { echo "selected"; }?> value="07:00">07:00</option>
											<option <?php if ($where->firma_his=="08:00") { echo "selected"; }?> value="08:00">08:00</option>
											<option <?php if ($where->firma_his=="09:00") { echo "selected"; }?> value="09:00">09:00</option>
											<option <?php if ($where->firma_his=="10:00") { echo "selected"; }?> value="10:00">10:00</option>
											<option <?php if ($where->firma_his=="11:00") { echo "selected"; }?> value="11:00">11:00</option>
											<option <?php if ($where->firma_his=="12:00") { echo "selected"; }?> value="12:00">12:00</option>
											<option <?php if ($where->firma_his=="13:00") { echo "selected"; }?> value="13:00">13:00</option>
											<option <?php if ($where->firma_his=="14:00") { echo "selected"; }?> value="14:00">14:00</option>
											<option <?php if ($where->firma_his=="15:00") { echo "selected"; }?> value="15:00">15:00</option>
											<option <?php if ($where->firma_his=="16:00") { echo "selected"; }?> value="16:00">16:00</option>
											<option <?php if ($where->firma_his=="17:00") { echo "selected"; }?> value="17:00">17:00</option>
										</select>
									</div>
									<div class="col-md-5">
										<select class="chosen-select" name="haftaiciaksam" data-placeholder="Kapanış Saati">
											<option label="Kapanış Saati"></option>
											<option <?php if ($where->firma_hia=="Kapalı") { echo "selected"; }?> value="Kapalı">Kapalı</option>
											<option <?php if ($where->firma_hia=="24 Saat Açık") { echo "selected"; }?> value="24 Saat Açık">24 Saat Açık</option>
											<option <?php if ($where->firma_hia=="06:00") { echo "selected"; }?> value="06:00">06:00</option>
											<option <?php if ($where->firma_hia=="07:00") { echo "selected"; }?> value="07:00">07:00</option>
											<option <?php if ($where->firma_hia=="08:00") { echo "selected"; }?> value="08:00">08:00</option>
											<option <?php if ($where->firma_hia=="09:00") { echo "selected"; }?> value="09:00">09:00</option>
											<option <?php if ($where->firma_hia=="10:00") { echo "selected"; }?> value="10:00">10:00</option>
											<option <?php if ($where->firma_hia=="11:00") { echo "selected"; }?> value="11:00">11:00</option>
											<option <?php if ($where->firma_hia=="12:00") { echo "selected"; }?> value="12:00">12:00</option>
											<option <?php if ($where->firma_hia=="13:00") { echo "selected"; }?> value="13:00">13:00</option>
											<option <?php if ($where->firma_hia=="14:00") { echo "selected"; }?> value="14:00">14:00</option>
											<option <?php if ($where->firma_hia=="15:00") { echo "selected"; }?> value="15:00">15:00</option>
											<option <?php if ($where->firma_hia=="16:00") { echo "selected"; }?> value="16:00">16:00</option>
											<option <?php if ($where->firma_hia=="17:00") { echo "selected"; }?> value="17:00">17:00</option>
											<option <?php if ($where->firma_hia=="18:00") { echo "selected"; }?> value="18:00">18:00</option>
											<option <?php if ($where->firma_hia=="19:00") { echo "selected"; }?> value="19:00">19:00</option>
											<option <?php if ($where->firma_hia=="20:00") { echo "selected"; }?> value="20:00">20:00</option>
											<option <?php if ($where->firma_hia=="21:00") { echo "selected"; }?> value="21:00">21:00</option>
											<option <?php if ($where->firma_hia=="22:00") { echo "selected"; }?> value="22:00">22:00</option>
											<option <?php if ($where->firma_hia=="23:00") { echo "selected"; }?> value="23:00">23:00</option>
											<option <?php if ($where->firma_hia=="00:00") { echo "selected"; }?> value="00:00">00:00</option>
										</select>
									</div>
								</div>

								<div class="row opening-day">
									<div class="col-md-2"><h5>Hafta Sonu</h5></div>
									<div class="col-md-5">
										<select class="chosen-select" name="haftasonusabah" data-placeholder="Açılış Saati">
											<option label="Açılış Saati"></option>
											<option <?php if ($where->firma_hss=="Kapalı") { echo "selected"; }?> value="Kapalı">Kapalı</option>
											<option <?php if ($where->firma_hss=="24 Saat Açık") { echo "selected"; }?> value="24 Saat Açık">24 Saat Açık</option>
											<option <?php if ($where->firma_hss=="06:00") { echo "selected"; }?> value="06:00">06:00</option>
											<option <?php if ($where->firma_hss=="07:00") { echo "selected"; }?> value="07:00">07:00</option>
											<option <?php if ($where->firma_hss=="08:00") { echo "selected"; }?> value="08:00">08:00</option>
											<option <?php if ($where->firma_hss=="09:00") { echo "selected"; }?> value="09:00">09:00</option>
											<option <?php if ($where->firma_hss=="10:00") { echo "selected"; }?> value="10:00">10:00</option>
											<option <?php if ($where->firma_hss=="11:00") { echo "selected"; }?> value="11:00">11:00</option>
											<option <?php if ($where->firma_hss=="12:00") { echo "selected"; }?> value="12:00">12:00</option>
											<option <?php if ($where->firma_hss=="13:00") { echo "selected"; }?> value="13:00">13:00</option>
											<option <?php if ($where->firma_hss=="14:00") { echo "selected"; }?> value="14:00">14:00</option>
											<option <?php if ($where->firma_hss=="15:00") { echo "selected"; }?> value="15:00">15:00</option>
											<option <?php if ($where->firma_hss=="16:00") { echo "selected"; }?> value="16:00">16:00</option>
											<option <?php if ($where->firma_hss=="17:00") { echo "selected"; }?> value="17:00">17:00</option>
										</select>
									</div>
									<div class="col-md-5">
										<select class="chosen-select" name="haftasonuaksam" data-placeholder="Kapanış Saati">
											<option label="Kapanış Saati"></option>
											<option <?php if ($where->firma_hsa=="Kapalı") { echo "selected"; }?> value="Kapalı">Kapalı</option>
											<option <?php if ($where->firma_hsa=="24 Saat Açık") { echo "selected"; }?> value="24 Saat Açık">24 Saat Açık</option>
											<option <?php if ($where->firma_hsa=="06:00") { echo "selected"; }?> value="06:00">06:00</option>
											<option <?php if ($where->firma_hsa=="07:00") { echo "selected"; }?> value="07:00">07:00</option>
											<option <?php if ($where->firma_hsa=="08:00") { echo "selected"; }?> value="08:00">08:00</option>
											<option <?php if ($where->firma_hsa=="09:00") { echo "selected"; }?> value="09:00">09:00</option>
											<option <?php if ($where->firma_hsa=="10:00") { echo "selected"; }?> value="10:00">10:00</option>
											<option <?php if ($where->firma_hsa=="11:00") { echo "selected"; }?> value="11:00">11:00</option>
											<option <?php if ($where->firma_hsa=="12:00") { echo "selected"; }?> value="12:00">12:00</option>
											<option <?php if ($where->firma_hsa=="13:00") { echo "selected"; }?> value="13:00">13:00</option>
											<option <?php if ($where->firma_hsa=="14:00") { echo "selected"; }?> value="14:00">14:00</option>
											<option <?php if ($where->firma_hsa=="15:00") { echo "selected"; }?> value="15:00">15:00</option>
											<option <?php if ($where->firma_hsa=="16:00") { echo "selected"; }?> value="16:00">16:00</option>
											<option <?php if ($where->firma_hsa=="17:00") { echo "selected"; }?> value="17:00">17:00</option>
											<option <?php if ($where->firma_hsa=="18:00") { echo "selected"; }?> value="18:00">18:00</option>
											<option <?php if ($where->firma_hsa=="19:00") { echo "selected"; }?> value="19:00">19:00</option>
											<option <?php if ($where->firma_hsa=="20:00") { echo "selected"; }?> value="20:00">20:00</option>
											<option <?php if ($where->firma_hsa=="21:00") { echo "selected"; }?> value="21:00">21:00</option>
											<option <?php if ($where->firma_hsa=="22:00") { echo "selected"; }?> value="22:00">22:00</option>
											<option <?php if ($where->firma_hsa=="23:00") { echo "selected"; }?> value="23:00">23:00</option>
											<option <?php if ($where->firma_hsa=="00:00") { echo "selected"; }?> value="00:00">00:00</option>
										</select>
									</div>
								</div>
								<!-- Day / End -->

						</div>
						<!-- Section / End -->

						<button type="submit" class="button preview">Firma Güncelle <i class="fa fa-arrow-circle-right"></i></button>

					</div>

			</form>

			<?php $this->load->view("kpanel/inc/footer"); ?>
			<div class="margin-top-45"></div>
		</div>

	</div>
	<!-- Content / End -->


</div>
<!-- Dashboard / End -->


</div>

<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCCKWWLQs2S3C0q-Qqp7m2nP-c0flEjA64&sensor=false&libraries=places"></script>


<script type="text/javascript">
	function initialize() {
   var latlng = new google.maps.LatLng(<?=$where->firma_lat?>,<?=$where->firma_lon?>);
    var map = new google.maps.Map(document.getElementById('maps'), {
      center: latlng,
      zoom: 18
    });
    var marker = new google.maps.Marker({
      map: map,
      position: latlng,
      draggable: true,
      anchorPoint: new google.maps.Point(0, -29)
   });
    var input = document.getElementById('searchInput');
    var geocoder = new google.maps.Geocoder();
    var autocomplete = new google.maps.places.Autocomplete(input);
    autocomplete.bindTo('bounds', map);
    var infowindow = new google.maps.InfoWindow();   
    autocomplete.addListener('place_changed', function() {
        infowindow.close();
        marker.setVisible(false);
        var place = autocomplete.getPlace();
        if (!place.geometry) {
            window.alert("Autocomplete's returned place contains no geometry");
            return;
        }
  
        // If the place has a geometry, then present it on a map.
        if (place.geometry.viewport) {
            map.fitBounds(place.geometry.viewport);
        } else {
            map.setCenter(place.geometry.location);
            map.setZoom(17);
        }
       
        marker.setPosition(place.geometry.location);
        marker.setVisible(true);          
    
        bindDataToForm(place.formatted_address,place.geometry.location.lat(),place.geometry.location.lng());
        infowindow.setContent(place.formatted_address);
        infowindow.open(map, marker);
       
    });
    // this function will work on marker move event into map 
    google.maps.event.addListener(marker, 'dragend', function() {
        geocoder.geocode({'latLng': marker.getPosition()}, function(results, status) {
        if (status == google.maps.GeocoderStatus.OK) {
          if (results[0]) {        
              bindDataToForm(results[0].formatted_address,marker.getPosition().lat(),marker.getPosition().lng());
              infowindow.setContent(results[0].formatted_address);
              infowindow.open(map, marker);
          }
        }
        });
    });
}
function bindDataToForm(address,lat,lng){
   document.getElementById('location').value = address;
   document.getElementById('lat').value = lat;
   document.getElementById('lng').value = lng;
}
google.maps.event.addDomListener(window, 'load', initialize);
</script>