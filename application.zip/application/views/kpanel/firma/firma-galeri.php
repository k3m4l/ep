<link rel="stylesheet" href="<?=base_url('assets/')?>css/dropzone.css">
<script src='<?=base_url('assets/')?>js/dropzone.js'></script>
<div id="dashboard">

	<!-- Navigation
		================================================== -->

		<!-- Responsive Navigation Trigger -->
		<a href="#" class="dashboard-responsive-nav-trigger"><i class="fa fa-reorder"></i> Navigation</a>

		<?php $this->load->view("kpanel/inc/menu"); ?>
		<!-- Navigation / End -->


	<!-- Content
		================================================== -->
		<div class="dashboard-content">

			<!-- Titlebar -->
			<div id="titlebar">
				<div class="row">
					<div class="col-md-12">
						<h2><?=$where->firma_ad?> - Galeri</h2>
						<!-- Breadcrumbs -->
						<nav id="breadcrumbs">
							<ul>
								<li><a href="<?=base_url()?>">Anasayfa</a></li>
								<li><a href="<?=base_url("kullanici-paneli")?>">Kullanıcı Paneli</a></li>
								<li><?=$where->firma_ad?> - Galeri</li>
							</ul>
						</nav>
					</div>
				</div>
			</div>

			<div class="row">

				<div class="col-md-12">
					<div class="final-info margin-bottom-10" style="display: none;">
						<input type="text" id="uploaded_files" disabled="">
					</div>
					<form method="post" action="<?php echo base_url("galeri-yukle/").$where->firma_uniq; ?>" enctype="multipart/form-data" class="dropzone" id="myAwesomeDropzone">
					</form>
					<button type="button" class="button border" id="submit_dropzone_form">Yükle</button>
				</div>

				<div class="margin-top-45"></div>

				<div class="col-md-12 margin-top-45">
					<table class="basic-table">
						<tbody>
							<tr>
								<th>Fotoğraf</th>
								<th>İşlem</th>
							</tr>

							<?php $galeri = json_decode($where->firma_galeri); ?>
							<?php if ($galeri) {?>
								<?php foreach ($galeri as $key => $value) { ?>
									<tr>
										<td><img width="150" src="<?=base_url("uploads/firma/galeri/".$value)?>"></td>
										<td><a data-url="<?=base_url("galerisil/$where->firma_uniq/$key")?>" class="button remove-btn">Sil</a></td>
									</tr>
								<?php } ?>
							<?php }else{ ?>
								<tr>
									<td colspan="2" align="center"><div class="notification warning closeable"><p>Gösterilecek Galeri Bulunamadı!</p></div></td>
								</tr>
							<?php } ?>
						</tbody>
					</table>
				</div>
				<?php $this->load->view("kpanel/inc/footer"); ?>
			</div>

		</div>
		<!-- Content / End -->


	</div>
	<!-- Dashboard / End -->


</div>
<script>
	Dropzone.options.myAwesomeDropzone = {
		autoProcessQueue: false,
		uploadMultiple: true,
		parallelUploads:10,
		successmultiple:function(data,response){
			$(".final-info").show( 500 );
			$("#uploaded_files").val(response);
		},
		init: function() {
		//Submitting the form on button click
		var submitButton = document.querySelector("#submit_dropzone_form");
			myDropzone = this; // closure
			submitButton.addEventListener("click", function() {
			myDropzone.processQueue(); // Tell Dropzone to process all queued files.
		});
		}
	};
</script>
