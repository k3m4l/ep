<section class="profileMainCard mt-5 mb-3">
    <div class="container">
        <div class="panel">
            <div class="panel-body"
                 style="background-position: center;background-image: url('<?php echo !empty($magaza->magaza_banner) ? base_url($magaza->magaza_banner) : 'https://kemalellidort.com.tr/uploads/logo/654fdd26a3671_invite-bg.png' ?>') !important">
                <div class="flexCard align-items-center justify-content-space-between">
                    <div class="s-avater">
                        <div class="userAvatar">
                            <img src="<?= base_url($magaza->magaza_resim) ?>" title="<?= $magaza->magaza_ad ?>"
                                 alt="<?= $magaza->magaza_ad ?>">
                        </div>

                        <div class="userDetails">
                            <small>@<?= $magaza->magaza_seo ?> / <?= ucwords(strtolower($magaza->magaza_tur)) ?>
                                Mağaza</small>
                            <h1><?= $magaza->magaza_ad ?>
                                <?php if ($magaza->magaza_dogrulama == 1) { ?>
                                    <a href="javascript:void(0)" class="top-0 right-0" data-toggle="tooltip"
                                       data-placement="top" title="Doğrulanmış Mağaza"
                                       data-original-title="Doğrulanmış Mağaza">
                                        <img src="<?= base_url('assets/front/') ?>images/checked-mark.svg"
                                             alt="Doğrulanmış" height="30" width="30"/>
                                    </a>
                                <?php } ?></h1>
                            <?php if (1 == 2) { ?>
                                <div class="userMedals">
                                    <?php if ($magaza->youtube) { ?>
                                        <a href="<?= $magaza->youtube ?>" target="_blank"
                                           class="mdi mdi-youtube text-muted mr-2 yt"></a>
                                    <?php } ?>
                                    <?php if ($magaza->web_site) { ?>
                                        <a href="<?= $magaza->web_site ?>" target="_blank"
                                           class="mdi mdi-link-variant text-muted mr-2 web"></a>
                                    <?php } ?>
                                    <?php if ($magaza->instagram) { ?>
                                        <a href="<?= $magaza->instagram ?>" target="_blank"
                                           class="mdi mdi-instagram text-muted mr-2 insta"></a>
                                    <?php } ?>
                                    <?php if ($magaza->facebook) { ?>
                                        <a href="<?= $magaza->facebook ?>" target="_blank"
                                           class="mdi mdi-facebook text-muted mr-2 face"></a>
                                    <?php } ?>
                                    <?php if ($magaza->twitter) { ?>
                                        <a href="<?= $magaza->twitter ?>" target="_blank"
                                           class="mdi mdi-twitter text-muted twitter"></a>
                                    <?php } ?>
                                </div>
                            <?php } ?>
                            <div class="profileBtns">
                                <?php if ($kullanici) { ?>
                                    <?php if ($kullanici->kullanici_id != $magaza->kullanici_id) { ?>
                                        <a href="<?= base_url('yeni-mesaj/' . $magaza->magaza_uniq); ?>"
                                           class="btn header-button btn-message"><i class="mdi mdi-message"></i> Mesaj
                                            Gönder
                                        </a>
                                    <?php } ?>
                                <?php } else { ?>
                                    <button class="btn header-button btn-message" id="notLogin"><i
                                                class="mdi mdi-message"></i>
                                        Mesaj Gönder
                                    </button>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                    <?php if (magaza_check()) { ?>
                        <div class="gt-store">
                            <a href="<?php echo base_url('m/' . magaza($kullanici->kullanici_id)->magaza_seo) ?>"
                               target="_blank" class="btn btn-primary settings-btn mb-3 w-100">Mağzaya Git</a>
                        </div>
                    <?php } ?>
                </div>
            </div>
        </div>
    </div>
</section>

<div class="pb-5">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="card mb-4">
                    <div class="card-header border-0">
                        <h4 class="mb-0">Yeni İlan Ekle</h4>
                    </div>
                    <div class="card-body soq">
                        <div class="mt-4">
                            <form method="post" id="infoAddAdvert" class="ui form">
                                <section class="add-post-odd page-main">
                                    <div class="containerx">
                                        <div class="row">
                                            <div class="col-12">
                                                <div class="page-header">
                                                    <h3 class="page-title">Kategori Seçimi</h3>
                                                    <p>İlanınızın yayınlanacağı ilan kategorisi ve tipinin seçimini
                                                        yapınız.</p>
                                                </div>
                                                <input type="hidden" name="PostToken"
                                                       value="31844169240828864e019e0afa9f5.47398951">
                                                <div class="field category-layer category-selector category-first"
                                                     data-category-layer="1">
                                                    <div class="ui vertical menu">
                                                        <div class="ui mini icon input">
                                                            <input type="text" placeholder="Filtreleme yapın..."
                                                                   class="category-search-input" data-layer="1">
                                                            <i class="search icons fas fa-search"></i>
                                                        </div>
                                                        <input type="hidden" class="category-layer-input"
                                                               name="category_1" data-layer="1"
                                                               onchange="if (!window.__cfRLUnblockHandlers) return false; layerCategoryChange(this)">
                                                        <input type="hidden" class="category-layer-input"
                                                               name="category_2" data-layer="2"
                                                               onchange="if (!window.__cfRLUnblockHandlers) return false; layerCategoryChange(this)">

                                                        <div class="list-categories-scroll layer-items-1 ">

                                                            <?php

                                                            foreach ($kategoriler as $kategori) {

                                                                $kategori_id = $kategori['kategori_id'];
                                                                $kategori_ad = $kategori['kategori_ad'];
                                                                $kategori_resim = $kategori['kategori_resim'];

                                                                if ($_POST['category_id'] == $kategori_id) {
                                                                    $active_class = 'active';
                                                                } else {
                                                                    $active_class = '';
                                                                }

                                                                ?>
                                                                <div class="item category-item cat_link <?= $active_class; ?>"
                                                                     data-layer-value="1"
                                                                     data-value="<?= $kategori_id; ?>"
                                                                     data-id='cat_link_<?= $kategori_id; ?>'
                                                                     id='cat_link_<?= $kategori_id; ?>'>
                                                                    <img src="https://kemalellidort.com.tr/<?= $kategori_resim; ?>"><?= $kategori_ad; ?>
                                                                </div>
                                                            <?php } ?>
                                                        </div>
                                                    </div>
                                                    <?php echo form_error('category_2', '<div class="error_input">', '</div>'); ?>

                                                </div>
                                                <div style="clear: both;"></div>
                                            </div>
                                        </div>
                                    </div>
                                </section>
                                <section class="add-post-even page-main">
                                    <div class="container">
                                        <div class="containerx">
                                            <div class="row">
                                                <div class="col-12">
                                                    <div class="page-header">
                                                        <h3 class="page-title">İlan Bilgileri</h3>
                                                        <p>İlanınızın detaylarını girin.</p>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-12">
                                                            <div class="field">
                                                                <label class="form-label">Filtre Seçenekleri</label>
                                                                <select class="form-control" id="filtre-select"
                                                                        data-width="100%" name="filtre">
                                                                    <option value="0">Lütfen Filtre Seçiniz</option>
                                                                </select>
                                                            </div>

                                                            <div class="field" id="sub-filter-area">

                                                            </div>

                                                            <div class="field">
                                                                <label class="form-label">Teslim Türü</label>
                                                                <div class="field">
                                                                    <select class="form-control" id="urun_turu"
                                                                            data-width="100%" name="urun_turu"
                                                                            >
                                                                        <option hidden="" value="">Teslim Türü Seçin..
                                                                        </option>
                                                                        <option value="1" <?php if (isset($_POST['urun_turu']) && ($_POST['urun_turu'] == 1)) {
                                                                            echo 'selected';
                                                                        } ?>>Fiziksel Ürün
                                                                        </option>
                                                                        <option value="2" <?php if (isset($_POST['urun_turu']) && ($_POST['urun_turu'] == 2)) {
                                                                            echo 'selected';
                                                                        } ?>>Sanal Ürün
                                                                        </option>
                                                                        <option value="3" <?php if (isset($_POST['urun_turu']) && ($_POST['urun_turu'] == 3)) {
                                                                            echo 'selected';
                                                                        } ?>>İndirilebilir Ürün
                                                                        </option>
                                                                    </select>
                                                                    <?php echo form_error('urun_turu', '<div class="error_input">', '</div>'); ?>

                                                                    <div class="alimIlaniType">
                                                                        <div class="ui radio checkbox mr-2"
                                                                             style="margin-right:10px">
                                                                            <input type="radio" name="postType"
                                                                                   value="REQUEST" tabindex="0"
                                                                                   class="hidden">
                                                                            <label>Alım İlanı</label>
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                            </div>

                                                            <div class="form-group col-md-12 sanal_urun_bilgileri"
                                                                 style="display: none;">
                                                                <!-- Title -->
                                                                <label class="form-label">Sanal Teslim Türü İlan
                                                                    Bilgilerini Giriniz Lütfen</label>
                                                                <textarea type="text" name="sanal_urun_bilgileri"
                                                                          class="form-control" id="sanal_urun_bilgileri"
                                                                          placeholder="Sanal Teslim Türü İlan Bilgilerini Giriniz Lütfen"></textarea>
                                                                <small>İlan bilgileri ödeme yapıldıktan sonra otomatik
                                                                    olarak kişiye
                                                                    görünecektir.</small>
                                                            </div>

                                                            <div class="form-group col-md-12 indirilebilir"
                                                                 style="display: none;">
                                                                <label class="input-label">İndirilecek İlan Teslim
                                                                    Dosyası</label>
                                                                <div action="<?php echo base_url('image/Add_images/add_product_file'); ?>"
                                                                     class="dropzone dropzone-area"
                                                                     id="dpz-single-files">
                                                                    <div class="dz-message">
                                                                        <span class="m-dropzone__msg-desc">
                                                                            Bir Adet Dosya Yükleyiniz.
                                                                            <br>
                                                                            <br>
                                                                            <small style="font-size: 15px">
                                                                                İlan bilgileri ödeme yapıldıktan sonra otomatik
                                                                                olarak kişiye
                                                                                görünecektir. Sadece <span class="badge badge-danger badge-pill badge-sm">.zip</span>
                                                                                dosya türü desteklenmektedir.</small>
                                                                        </span>
                                                                    </div>
                                                                </div>
                                                            </div>

                                                            <div class="field stokluIlan">
                                                                <div class="field">
                                                                    <a href="/yardim/65/stoklu-ilan-nasil-eklenir"
                                                                       target="_blank">
                                                                        <div class="message-alert message-alert-secondary"
                                                                             role="alert">
                                                                            <div class="message-alert-icon"><i
                                                                                        class="fa fa-info"></i></div>
                                                                            <div class="message-alert-text">
                                                                                <b>Stoklu İlan Sistemi</b><br>Stoklu
                                                                                ilan sistemi hakkında detaylı bilgiye
                                                                                ulaşmak için tıklayınız.
                                                                            </div>
                                                                        </div>
                                                                    </a>
                                                                </div>
                                                            </div>

                                                            <div class="field">
                                                                <label>İlan Başlığı</label>
                                                                <div class="field">
                                                                    <input type="text" name="urun_ad"
                                                                           class="form-control"
                                                                           value="<?php echo isset($form_error) ? set_value('urun_ad') : ''; ?>"
                                                                           />
                                                                    <small>Lütfen özel karakter kullanmamaya çalışın ve
                                                                        yazım kurallarına göre başlık yazın.</small>
                                                                    <?php echo form_error('urun_ad', '<div class="error_input">', '</div>'); ?>
                                                                </div>
                                                            </div>
                                                            <div class="row">
                                                                <div class="col-6">
                                                                    <div class="field">
                                                                        <label>Kısa Açıklama <small>(Lütfen İlan
                                                                                Hakkında Kısa Bir Açıklama
                                                                                Giriniz.)</small></label>
                                                                        <div class="field">
                                                                            <textarea class="ckeditor"
                                                                                      name="urun_short_aciklama"
                                                                                      id="urun_detay"><?= set_value('urun_detay'); ?></textarea>
                                                                            <?php echo form_error('urun_short_aciklama', '<div class="error_input">', '</div>'); ?>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-6">
                                                                    <div class="field">
                                                                        <label>Açıklama</label>
                                                                        <div class="field">
                                                                            <textarea class="ckeditor"
                                                                                      name="urun_aciklama"
                                                                                      id="urun_detay"
                                                                                      ><?= set_value('urun_detay'); ?></textarea>
                                                                            <?php echo form_error('urun_aciklama', '<div class="error_input">', '</div>'); ?>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="form-group col-md-12  mb-5" style="margin-top:10px">
                                                            <label class="form-label">İlan Vitrin Fotoğrafı</label>
                                                            <div class="form-group">
                                                                <div action="<?php echo base_url('image/Add_images/add_image_ilan'); ?>"
                                                                     class="dropzone dropzone-area"
                                                                     id="dpz-single-files">
                                                                    <div class="dz-message">
                                                                        <span class="m-dropzone__msg-desc">
                                                                            Bir Adet Vitrin Resim Yükleyiniz.
                                                                            <br>
                                                                            <br>
                                                                            <small style="font-size: 15px">Sadece <span
                                                                                        class="badge badge-danger badge-pill badge-sm">.png/.jpg/.jpeg</span>
                                                                                dosya türü
                                                                                desteklenmektedir.
                                                                            </small>
                                                                        </span>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="form-group col-md-12">
                                                            <label for="" class="form-label">İlan Bitiş Tarihi *</label>
                                                            <input type="datetime-local" name="urun_bitis_tarihi"
                                                                   onfocus="this.showPicker()"
                                                                   min="<?php echo date('Y-m-d H:i:s') ?>"
                                                                   class="form-control" id="urun_bitis_tarihi"
                                                                   value="<?= date('Y-m-d H:i:s', strtotime('+30 days')); ?>">
                                                        </div>
                                                        <div class="form-group col-md-6">
                                                            <label for="postTitle" class="form-label">İlan Stok
                                                                *</label>
                                                            <input name="urun_stok" type="number"
                                                                   class="form-control"
                                                                   value="<?= set_value('urun_stok'); ?>"
                                                                   placeholder="İlan Stok" />
                                                            <?php echo form_error('urun_stok', '<div class="error_input">', '</div>'); ?>
                                                        </div>
                                                        <div class="form-group col-md-6">
                                                            <label class="form-label" for="currency">İlan Fiyatı</label>
                                                            <input class="form-control text-left" type="number"
                                                                   name="fiyat" step="any"
                                                                   value="<?= set_value('fiyat'); ?>"
                                                                   placeholder="İlan Fiyatı" id="fiyat2" >
                                                            <?php echo form_error('fiyat', '<div class="error_input">', '</div>'); ?>
                                                            <div class="mt-2 text-center">
                                                                <span class="badge badge-success d-flex flex-column">
                                                                    <div class="d-flex justify-content-between align-items-center text-center">
                                                                        <span class="font-size-md">Hesabınıza Geçecek Kazanç :</span>
                                                                        <span class="font-size-md font-weight-bold" id="kazanc">
                                                                            0.00 ₺
                                                                        </span>
                                                                    </div>
                                                                    <div class="d-flex justify-content-between align-items-center text-center mt-1">
                                                                        <span>Komisyon Oranı :</span>
                                                                        <span class="komyaz">%<?= $ayarlar->komisyon ?></span>
                                                                    </div>
                                                                </span>
                                                            </div>
                                                        </div>
                                                        <script>

                                                            var site_komisyon2 = <?php echo $ayarlar->komisyon ?>;

                                                            function komisyonchange(val) {
                                                                <?php foreach (fetchCategoryTree() as $cl) { ?>
                                                                if (val == "<?php echo $cl["id"] ?>") {
                                                                    $(".komyaz").html('%<?php if ($cl["komisyon"] == "") {
                                                                        $cl["komisyon"] = "0";
                                                                    } echo $cl["komisyon"]; ?>');
                                                                    site_komisyon2 = '<?=$cl["komisyon"];?>';
                                                                }       <?php } ?>
                                                            }
                                                        </script>
                                                        <div class=" form-group col-md-12">
                                                            <label class="form-control-label">İlan Görselleri</label>
                                                            <div action="<?php echo base_url('image/Add_images/add_gallery'); ?>"
                                                            class="dropzone dropzone-area"
                                                            id="dpz-single-files">
                                                            <div class="dz-message">
                                                                <span class="m-dropzone__msg-desc">
                                                                    İlan Görsellerini Yükleyiniz.
                                                                </span>
                                                            </div>
                                                        </div>
                                                        </div>
                                                        <div style="clear: both;"></div>
                                                        <div class="stokluIlan">
                                                            <input type="file" id="fileToLoad" accept=".txt"
                                                                   style="display: none;">
                                                            <div style="clear: both"></div>
                                                            <hr>
                                                            <div class="field">
                                                                <div class="field">
                                                                    <div class="message-alert message-alert-secondary"
                                                                         role="alert">
                                                                        <div class="message-alert-icon"><i
                                                                                    class="fa fa-info"></i></div>
                                                                        <div class="message-alert-text">Stoklu ilan
                                                                            sisteminde ilanınız satıldığında stoklarınız
                                                                            arasından otomatik teslimat
                                                                            yapılmaktadır.<br>Belirleyecek olduğunuz
                                                                            özel teslimat mesajı ile müşterilerinize
                                                                            otomatik teslimat sonrası sizi
                                                                            değerlendirmeleri veya siparişi teslim
                                                                            aldığını onaylamaları hakkında otomatik
                                                                            mesaj gönderebilirsiniz.
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="field">
                                                                <label>Otomatik Teslimat Mesajı (Opsiyonel)</label>
                                                                <div class="field">
                                                                    <textarea rows="2" type="text"
                                                                              name="otomatikTeslimatMesaji"></textarea>
                                                                </div>
                                                            </div>
                                                            <div class="field">
                                                                <label>İlan Stokları</label>
                                                                <div class="field">
                                                                    <div class="well">
                                                                        <button class="btn btn-primary newOneStock"><i
                                                                                    class="fa fa-plus"></i> Yeni Stok
                                                                            Ekle
                                                                        </button>
                                                                        <button class="btn btn-secondary pull-right topluStokEklemeBilgi"
                                                                                style="margin-left:4px;"><i
                                                                                    class="fa fa-question"></i></button>
                                                                        <button class="btn btn-secondary pull-right topluStokEkle">
                                                                            <i class="fa fa-list-alt"></i> Toplu Stok
                                                                            Ekle
                                                                        </button>
                                                                        <div class="postStocksDiv">
                                                                            <div class="postStockElement"
                                                                                 data-id="asdqwe">
                                                                                <button class="btn btn-danger btn-sm stockDelete"
                                                                                        data-id="asdqwe"><i
                                                                                            class="fa fa-trash"></i>
                                                                                </button>
                                                                                <textarea name="postStocks[]"
                                                                                          class="form-control" rows="3"
                                                                                          placeholder="Stok içeriğini buraya yazınız."
                                                                                          data-id="asdqwe"></textarea>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <br><br>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </section>
                                <?php if (1 == 2) { ?>
                            <section class="add-post-odd page-main">
                                <div class="container">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-12">
                                                <div class="page-header">
                                                    <h3 class="page-title">Doping</h3>
                                                    <p>İlanınızı doping kullanarak daha hızlı satın.</p>
                                                </div>
                                                <div class="row step-area-3">
                                                    <div class="col-md-12">
                                                        <div class="well onecikan-well alimIlani">
                                                            <img src="<?= base_url('assets/images/Q48DGHPNpRkMzITyXjZufsYab.png'); ?>">
                                                            <h3>Alım İlanı Vitrini</h3>
                                                            <p>Alım ilanı vitrini sayesinde ilanınız alım ilanları
                                                                sayfasında ve kategori ilan listeleme sayfasında en üste
                                                                sabitlemiş olarak gözükecektir, Bu ilanınızın daha fazla
                                                                görüntülenmesine ve alım talebinizin karşılanmasına
                                                                sebep olacaktır.</p>
                                                            <div class="radio-boost-btns">
                                                                <div class="row">
                                                                    <label class="col-lg col-sm-12 col-md-12">
                                                                        <input type="radio" name="RequestPinned"
                                                                               value="0" checked="">
                                                                        <span>Öne çıkartmak istemiyorum</span>
                                                                    </label>
                                                                    <label class="col-lg col-sm-12 col-md-12">
                                                                        <input type="radio" name="RequestPinned"
                                                                               value="12">
                                                                        <span>12 saat (3.00₺)</span>
                                                                    </label>
                                                                    <label class="col-lg col-sm-12 col-md-12">
                                                                        <input type="radio" name="RequestPinned"
                                                                               value="24">
                                                                        <span>1 gün (5.00₺)</span>
                                                                    </label>
                                                                    <label class="col-lg col-sm-12 col-md-12">
                                                                        <input type="radio" name="RequestPinned"
                                                                               value="48">
                                                                        <span>2 gün (8.00₺)</span>
                                                                    </label>
                                                                    <label class="col-lg col-sm-12 col-md-12">
                                                                        <input type="radio" name="RequestPinned"
                                                                               value="72">
                                                                        <span>3 gün (12.00₺)</span>
                                                                    </label>
                                                                    <label class="col-lg col-sm-12 col-md-12">
                                                                        <input type="radio" name="RequestPinned"
                                                                               value="168">
                                                                        <span>7 gün (20.00₺)</span>
                                                                    </label>
                                                                    <label class="col-lg col-sm-12 col-md-12">
                                                                        <input type="radio" name="RequestPinned"
                                                                               value="720">
                                                                        <span>30 gün (60.00₺)</span>
                                                                    </label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="well pinned-well alimIlaniGizle"
                                                             style="position:relative;">
                                                            <a class="ui red ribbon label"
                                                               style="position: absolute;left: -15px;top: 5px;">Tercih
                                                                Edilen</a>
                                                            <img src="<?= base_url('assets/images/startup.svg'); ?>">
                                                            <h3>Anasayfa Vitrin ilanı</h3>
                                                            <p><b>Vitrin İlanlar Ana Sayfa ve İlan Kategorisinde en
                                                                    üstte sabitlenmiş olarak görünmektedir. Vitrin İlan
                                                                    dopingi sayesinde ilanınız normal ilanlara göre %85
                                                                    daha fazla görüntülenme almaktadır ve daha hızlı
                                                                    satılmaktadır.</b></p>
                                                            <div class="radio-boost-btns">
                                                                <div class="row">
                                                                    <label class="col-lg col-sm-12 col-md-12">
                                                                        <input type="radio" name="Vitrin" value="0"
                                                                               checked="">
                                                                        <span>Vitrin ilanı istemiyorum</span>
                                                                    </label>
                                                                    <label class="col-lg col-sm-12 col-md-12">
                                                                        <input type="radio" name="Vitrin" value="12">
                                                                        <span>12 saat (5.00₺)</span>
                                                                    </label>
                                                                    <label class="col-lg col-sm-12 col-md-12">
                                                                        <input type="radio" name="Vitrin" value="24">
                                                                        <span>1 gün (8.00₺)</span>
                                                                    </label>
                                                                    <label class="col-lg col-sm-12 col-md-12">
                                                                        <input type="radio" name="Vitrin" value="48">
                                                                        <span>2 gün (14.00₺)</span>
                                                                    </label>
                                                                    <label class="col-lg col-sm-12 col-md-12">
                                                                        <input type="radio" name="Vitrin" value="72">
                                                                        <span>3 gün (20.00₺)</span>
                                                                    </label>
                                                                    <label class="col-lg col-sm-12 col-md-12">
                                                                        <input type="radio" name="Vitrin" value="168">
                                                                        <span>7 gün (35.00₺)</span>
                                                                    </label>
                                                                    <label class="col-lg col-sm-12 col-md-12">
                                                                        <input type="radio" name="Vitrin" value="720">
                                                                        <span>30 gün (100.00₺)</span>
                                                                    </label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="well boost-well alimIlaniGizle"
                                                             style="position:relative;">
                                                            <img src="<?= base_url('assets/images/8tg6hrKqCNw3D2AJ7HocVpu1y.png'); ?>">
                                                            <h3>Pazar Vitrini</h3>
                                                            <p>Bu dopingi satın alarak ilanınızı "İlan Pazarı"
                                                                sayfasında en üstte sergileyebilirsiniz. Pazar vitrini
                                                                sayesinde ilanınız, normal ilanlara göre %70 daha fazla
                                                                görüntülenme alacaktır. Bu sayede de satış hızınız ve
                                                                sayınız artacak.<br>*Sitemizde sayfalarda uzun süre
                                                                işlem yapmayan kullanıcılar otomatik olarak Oyuncu
                                                                Pazarı sayfasına yönlendirilmektedir, bu sebeple
                                                                ilanınızın daha fazla görüntülenmesine ve daha hızlı
                                                                satılmasına sebep olabilir.</p>
                                                            <div class="radio-boost-btns">
                                                                <div class="row">
                                                                    <label class="col-lg col-sm-12 col-md-12">
                                                                        <input type="radio" name="MarketBoost" value="0"
                                                                               checked="">
                                                                        <span>Vitrin ilanı istemiyorum</span>
                                                                    </label>
                                                                    <label class="col-lg col-sm-12 col-md-12">
                                                                        <input type="radio" name="MarketBoost"
                                                                               value="12">
                                                                        <span>12 saat (3.00₺)</span>
                                                                    </label>
                                                                    <label class="col-lg col-sm-12 col-md-12">
                                                                        <input type="radio" name="MarketBoost"
                                                                               value="24">
                                                                        <span>1 gün (5.00₺)</span>
                                                                    </label>
                                                                    <label class="col-lg col-sm-12 col-md-12">
                                                                        <input type="radio" name="MarketBoost"
                                                                               value="48">
                                                                        <span>2 gün (8.00₺)</span>
                                                                    </label>
                                                                    <label class="col-lg col-sm-12 col-md-12">
                                                                        <input type="radio" name="MarketBoost"
                                                                               value="72">
                                                                        <span>3 gün (12.00₺)</span>
                                                                    </label>
                                                                    <label class="col-lg col-sm-12 col-md-12">
                                                                        <input type="radio" name="MarketBoost"
                                                                               value="168">
                                                                        <span>7 gün (20.00₺)</span>
                                                                    </label>
                                                                    <label class="col-lg col-sm-12 col-md-12">
                                                                        <input type="radio" name="MarketBoost"
                                                                               value="720">
                                                                        <span>30 gün (60.00₺)</span>
                                                                    </label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="well onecikan-well alimIlaniGizle">
                                                            <img src="<?= base_url('assets/images/popularity.svg'); ?>">
                                                            <h3>İlanını öne çıkar</h3>
                                                            <p>Öne çıkarılan ilanlar diğer ilanlardan daha fazla ilgi
                                                                çekmektedir ve %80 oranında diğer ilanlardan daha hızlı
                                                                satılmaktadır. İlanınızı öne çıkarttığınızda ilan
                                                                listeleme sayfalarında organik sıralarınızda
                                                                bulunacaksınız fakat diğer ilanlardan daha belirgin
                                                                olmanız için başlık kalınlığı arkaplan rengi vs. gibi
                                                                bazı özel stiller uygulanacaktır bu sebeple diğer
                                                                ilanlardan daha belirgin olacaktır.</p>
                                                            <div class="radio-boost-btns">
                                                                <div class="row">
                                                                    <label class="col-lg col-sm-12 col-md-12">
                                                                        <input type="radio" name="OneCikarilan"
                                                                               value="0" checked="">
                                                                        <span>Öne çıkartmak istemiyorum</span>
                                                                    </label>
                                                                    <label class="col-lg col-sm-12 col-md-12">
                                                                        <input type="radio" name="OneCikarilan"
                                                                               value="12">
                                                                        <span>12 saat (3.00₺)</span>
                                                                    </label>
                                                                    <label class="col-lg col-sm-12 col-md-12">
                                                                        <input type="radio" name="OneCikarilan"
                                                                               value="24">
                                                                        <span>1 gün (5.00₺)</span>
                                                                    </label>
                                                                    <label class="col-lg col-sm-12 col-md-12">
                                                                        <input type="radio" name="OneCikarilan"
                                                                               value="48">
                                                                        <span>2 gün (8.00₺)</span>
                                                                    </label>
                                                                    <label class="col-lg col-sm-12 col-md-12">
                                                                        <input type="radio" name="OneCikarilan"
                                                                               value="72">
                                                                        <span>3 gün (12.00₺)</span>
                                                                    </label>
                                                                    <label class="col-lg col-sm-12 col-md-12">
                                                                        <input type="radio" name="OneCikarilan"
                                                                               value="168">
                                                                        <span>7 gün (20.00₺)</span>
                                                                    </label>
                                                                    <label class="col-lg col-sm-12 col-md-12">
                                                                        <input type="radio" name="OneCikarilan"
                                                                               value="720">
                                                                        <span>30 gün (60.00₺)</span>
                                                                    </label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="well sosyal-well alimIlaniGizle">
                                                            <a class="ui blue ribbon label"
                                                               style="position: absolute;left: -15px;top: 5px;">Yeni
                                                                Doping</a>
                                                            <img src="<?= base_url('assets/images/BuMWJH7qf4TtiCNjXxyRrA8vP.png'); ?>">
                                                            <h3>Sohbet &amp; Bildirim Dopingi</h3>
                                                            <p>Kullanıcıların en çok zaman geçirdiği ve ziyaret ettiği
                                                                sayfalarda ilanlarınızı sergilemek ister misiniz? Sohbet
                                                                &amp; Bildirim dopingi ile Sohbet ve Bildirim sayfasında
                                                                yer alan vitrin ilanları arasında yerinizi alın ve
                                                                satışlarınızı arttırın.</p>
                                                            <div class="radio-boost-btns">
                                                                <div class="row">
                                                                    <label class="col-lg col-sm-12 col-md-12">
                                                                        <input type="radio" name="SocialPinned"
                                                                               value="0" checked="">
                                                                        <span>Sohbet &amp; Bildirim Doping'i istemiyorum</span>
                                                                    </label>
                                                                    <label class="col-lg col-sm-12 col-md-12">
                                                                        <input type="radio" name="SocialPinned"
                                                                               value="12">
                                                                        <span>12 saat (3.00₺)</span>
                                                                    </label>
                                                                    <label class="col-lg col-sm-12 col-md-12">
                                                                        <input type="radio" name="SocialPinned"
                                                                               value="24">
                                                                        <span>1 gün (5.00₺)</span>
                                                                    </label>
                                                                    <label class="col-lg col-sm-12 col-md-12">
                                                                        <input type="radio" name="SocialPinned"
                                                                               value="48">
                                                                        <span>2 gün (8.00₺)</span>
                                                                    </label>
                                                                    <label class="col-lg col-sm-12 col-md-12">
                                                                        <input type="radio" name="SocialPinned"
                                                                               value="72">
                                                                        <span>3 gün (12.00₺)</span>
                                                                    </label>
                                                                    <label class="col-lg col-sm-12 col-md-12">
                                                                        <input type="radio" name="SocialPinned"
                                                                               value="168">
                                                                        <span>7 gün (20.00₺)</span>
                                                                    </label>
                                                                    <label class="col-lg col-sm-12 col-md-12">
                                                                        <input type="radio" name="SocialPinned"
                                                                               value="720">
                                                                        <span>30 gün (60.00₺)</span>
                                                                    </label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </section>
                        <?php } ?>
                                <section class="add-post-even page-main">
                            <div class="container">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-12">
                                            <div class="page-header">
                                                <h3 class="page-title">Sözleşme &amp; Kurallar</h3>
                                                <p>İlanınızı oluşturmadan önce sözleşme ve kuralları okuyun.</p>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <div class="ilan-kurallari-text">
                                                        <p><span style="color:#ffffff"><strong>HERSEYOYUN İLAN VERME KURALLARI</strong></span>
                                                        </p>
                                                        <p>Aşağıda yazan ilan verme kuralları bireysel ve kurumsal
                                                            üyeler dahil ve tüm kategori tipleri için geçerlidir. İlan
                                                            girişinde bulunan Üye, ilan verme kurallarına, üyelik ve
                                                            kullanıcı sözleşmeleri ile bu belgenin devamında belirtilen
                                                            Yasak Ürünler Listesi’nde belirtilen kurallara uymayı kabul
                                                            ve taahhüt etmiş sayılır.</p>
                                                        <p>
                                                            <span style="color:#ffffff"><strong>1. TANIMLAR</strong></span>
                                                        </p>
                                                        <p>İNTERNET SİTESİ : Tüm hakları Şirket’e ait olan,
                                                            www.kemalellidort.com.tr alan adını ve bu alan adına bağlı alt
                                                            alan adlarından oluşan internet sitesidir.</p>
                                                        <p>MOBİL UYGULAMA : Tüm hakları Şirket’e ait olan, cep telefonu,
                                                            tablet ve benzeri taşınabilir cihazlarda çalışan herseyoyun
                                                            adlı yazılımdır. Bu yazılım Apple App Store veya Google Play
                                                            gibi mağazalardan elde edilir. Bu mağazalardaki herseyoyun
                                                            adlı ve ALFATEK YAZILIM DANISMANLIK LİMİTED ŞİRKETİ adına
                                                            yüklü yazılım, gerekli güvenlik şartlarını sağlamaktadır.
                                                            Bunun haricinde başka bir yolla edilen yazılımın cihazlara
                                                            kurulmasından kaynaklı güvenlik dair her türlü hatadan
                                                            Şirket sorumlu değildir.</p>
                                                        <p><strong>HERSEYOYUN</strong>: İnternet Sitesi ve Mobil
                                                            Uygulama ile birlikte “herseyoyun” olarak anılmaktadır.</p>
                                                        <p><strong>ÜYE </strong>: Herseyoyun üzerinde, oluşturduğu ve
                                                            onaylanan kullanıcı hesabı ile; listelediği ürünler ve/veya
                                                            hizmetler ile içeriklerini kendileri oluşturarak Ürünü
                                                            satışa sunan ve Üyelik Sözleşmesi’nde belirtilen koşullar
                                                            dâhilinde Herseyoyun'a üye olmuş ve Herseyoyun'un sunduğu
                                                            diğer hizmetlerden faydalanan gerçek veya tüzel kişileri
                                                            ifade eder. Üyelik için gerekli şartlar Üyelik Sözleşmesinde
                                                            açıklanmıştır. Herseyoyun'a üyelik tipi bireysel veya
                                                            kurumsal olabilir.</p>
                                                        <p><strong>SATICI</strong>: Herseyoyun'a bireysel veya kurumsal
                                                            üye olarak kendisine ait Ürün’ü Alıcıya satan gerçek veya
                                                            tüzel kişidir. Satıcı olmak için Herseyoyun'a üyelik
                                                            şarttır. İşbu sözleşme gereği KULLANICI 18 yaşından büyük ve
                                                            T.C ilgili kanunlarına göre reşid sayıldığını kabul eder.
                                                            Gerekli üyelik şartları Üyelik Sözleşmesi’nde açıklanmıştır.
                                                        </p>
                                                        <p><strong>ALICI</strong>: Herseyoyun'a bireysel veya kurumsal
                                                            üye olarak, Herseyoyun'un veya Satıcı’nın ürününü alan
                                                            gerçek veya tüzel kişidir. Alıcı olabilmek için Herseyoyun'a
                                                            üyelik şarttır. İşbu sözleşme gereği KULLANICI 18 yaşından
                                                            büyük ve T.C ilgili kanunlarına göre reşid sayıldığını kabul
                                                            eder. Gerekli üyelik şartları Üyelik Sözleşmesi’nde
                                                            açıklanmıştır.</p>
                                                        <p><strong>ÜRÜN </strong>: Herseyoyun üzerinden, Herseyoyun'un
                                                            bayilik anlaşması olan 3. taraf firmalardan sağlanan
                                                            ürünleri, Satıcılar tarafından başta Yasaklı Ürünler listesi
                                                            olmak üzere; işbu sözleşme, Kullanım Koşulları, Üyelik
                                                            Sözleşmesi, Mesafeli Satış Sözleşmesi ve diğer eklere uygun
                                                            olarak satışa sunulan ürün ve hizmetleri ifade eder. Bu
                                                            ürünler fiziki değildir. Anında tüketilen sayısal bir kod ve
                                                            oyun parasından oluşan ve genel adı itibariyle E-PIN /
                                                            Elektronik Pin’dir. Bundan sonra Ürün, E-PIN olarak da
                                                            anılabilecektir.</p>
                                                        <p><strong>VİTRİN ve DOPİNG</strong>: İlgili ilanın daha fazla
                                                            kullanıcıya ulaşabilmesi için, ilave bir ücret ile yalnız
                                                            ilgili ilan için satın alınan, ilan öne çıkarma hizmetidir.
                                                        </p>
                                                        <p>
                                                            <span style="color:#ffffff"><strong>2. GENEL HÜKÜMLER</strong></span>
                                                        </p>
                                                        <p>2.1.&nbsp;Herseyoyun ve bu kapsamda Şirket, 6502 sayılı
                                                            Tüketicinin Korunması Hakkında Kanun ve 6563 sayılı
                                                            Elektronik Ticaret Düzenlenmesi Hakkında Kanun kapsamında
                                                            Satıcı ve Alıcı arasında HİZMETLER tanımının c maddesinde
                                                            belirtilen alt hizmet için mesafeli sözleşme kurulmasına
                                                            aracılık eden ve “Aracı Hizmet Sağlayıcı” sıfatını haizdir.
                                                            Herseyoyun'un satıcıların ürünleri hakkında hiçbir
                                                            sorumluluğu bulunmamaktadır.</p>
                                                        <p>2.2. Herseyoyun'a üye olmayanlar ilan veremez.</p>
                                                        <p>2.3. Herseyoyun'da ilan vermek ücretsizdir. Fakat ilgili ilan
                                                            için kullanılacak Vitrin ve Doping hizmetleri ilave ücrete
                                                            tabidir.</p>
                                                        <p>2.4. Satıcı, ilan vermeden önce işbu İlan Verme Kurallarını
                                                            ve içerisinde bulunan Yasaklı Ürünler Listesini okuduğunu ve
                                                            anladığını, oluşturmak istediği ilanın işbu kurallara aykırı
                                                            olmadığını peşine kabul ve beyan eder.</p>
                                                        <p>2.5. Satıcı, ilanının hiçbir şekilde fikri mülkiyet haklarını
                                                            ihlal etmediğini, ilanını verdiği ürünün kendisine ait
                                                            olduğunu, ilan içeriğinin Yasaklı Ürünler Listesi’nde yer
                                                            almadığını, genel ahlak kurallarına aykırı olmadığını, ilanı
                                                            verilen ürünün satışa hazır olduğunu, ilan için kullanılan
                                                            içeriğin satılmak istenen ürünle ilgili olduğunu, ürünün
                                                            çalışır durumda ve sürekli güncel olduğunu peşinen kabul ve
                                                            beyan eder.</p>
                                                        <p>2.6. İlan ile ilgili tüm sorumluluk Satıcı’ya ait olup,
                                                            Herseyoyun hiçbir şekilde sorumluluk kabul etmemektedir.
                                                            Herseyoyun, ilanda yer alan ürün için garanti
                                                            vermemektedir.</p>
                                                        <p>2.7. İlan içeriği gerekli görüldüğü durumlarda, Satıcı’ya
                                                            haber verilmeden Herseyoyun tarafından değiştirilebilir.</p>
                                                        <p>2.8. Piyasa fiyatlarının çok altında veya çok üstünde olan
                                                            ilanlar, piyasa rekabetini koruma ve haksız kazanç edinimini
                                                            önleme adına Herseyoyun tarafından yayından kaldırılabilir,
                                                            yayını belirsiz süre durdurulabilir. Satıcı’dan ilanı
                                                            düzeltmesi istenebilir.</p>
                                                        <p>2.9. Herseyoyun ilanı yayınlamak için Satıcı’ya ait kimlik
                                                            fotokopisi, yerleşim yeri belgesi, vergi levhası gibi ilave
                                                            bilgiler isteyebilir.</p>
                                                        <p>2.10. Aynı ürüne ait ikinci bir ilan girilemez. Bu tür
                                                            ilanlar mükerrer sayılır ve sistemden Satıcı’ya bilgi
                                                            verilmeden kaldırılır. Satıcı, mükerrer ilanın yayından
                                                            kaldırılmasından dolayı hak kaybına uğradığını iddia edemez.
                                                            Mükerrer ilanlar için Satıcı tarafından öncesinde yapılan
                                                            ödemelerin iadesi yapılmaz.</p>
                                                        <p>2.11. İlan içeriğinde Alıcı’yı başka bir platforma yöneltmek
                                                            veya başka bir firma veya ürünün reklamını yapmak için;
                                                            başka bir web adresi veya&nbsp;başka bir platformda yer alan
                                                            ürün linki eklemek yasaktır. Satıcı, ilan içerisinde
                                                            kendisine ait cep telefonu, e-mail adresi ve bununla sınırlı
                                                            kalmayacak şekilde kişisel iletişim bilgisi paylaşamaz.</p>
                                                        <p>2.12. Herseyoyun'da yer alan ilave ilan hizmetlerinin fiyat
                                                            bilgisi Türk Lirası’dır. Yabancı para biriminde ilan girişi
                                                            yapılamaz. Fiyatlara KDV dahildir.</p>
                                                        <p>2.13. İlan için ilave ücret ile kullanılan Vitrin ve Doping
                                                            hizmetleri yalnız ilgili ilan için geçerlidir. Başka bir
                                                            ilan için kullanılamaz.</p>
                                                        <p>2.14. İlanın yayında kalma süresi dolmadan ilanda yer alan
                                                            ürün satılırsa, ilgili ilandan kalan yayın süresi, Vitrin ve
                                                            Doping hizmeti başka bir ilan için kullanılamaz veya
                                                            devredilemez.</p>
                                                        <p>2.15. İlan için ödenen Vitrin ve Doping ücretleri, ilgili
                                                            ilan Herseyoyun üzerinde yayına başladıktan sonra hiçbir
                                                            şekilde geri iade edilmez.</p>
                                                        <p>2.16. Vitrin ve Doping hizmetleri ücretleri
                                                            www.kemalellidort.com.tr adresinde yayınlanmış olup, Satıcı bu
                                                            fiyatları bildiğini peşinen kabul ve beyan eder. Herseyoyun
                                                            ilan hizmetleri hakkındaki ücretlendirmeyi dilediği zaman ve
                                                            herhangi bir bildirimde bulunmadan değiştirebilir.
                                                            Değişiklikler www.kemalellidort.com.tr adresinde yayınlandığı anda
                                                            yürürlüğe girmiş kabul edilir.</p>
                                                        <p>2.17. İlanlarda; reklam, haksız rekabet, terör, kara para
                                                            aklama, cumhuriyet, devlet, din, ırkçılık, uyuşturucu,
                                                            politikacılar ya da diğer tüzel hakkında yazışmalar,
                                                            pornografik içerik, argo kelimelerin kullanımı veya diğer
                                                            oyuncuları tacize yönelik davranışlar içeren yahut
                                                            Atatürk’ün manevi hatırasına hakaret teşkil eden kullanımlar
                                                            dahil olmak fakat bunlarla sınırlı olmamak üzere mer’i
                                                            mevzuat kapsamında suç teşkil eden başkaca her türlü işlem,
                                                            eylem ve tasarruflar yasak ve işbu İlan Verme Kurallarına
                                                            aykırıdır.</p>
                                                        <p>2.18. İşbu ilan kurallarına ve Yasaklı Ürünler Listesi’ne
                                                            aykırı olduğu tespit edilen ilanlar Herseyoyun tarafından
                                                            Satıcı’ya haber verilmeden yayından kaldırılabilir, belirli
                                                            veya belirsiz süre yayını durdurulabilir. Bu durumda Satıcı,
                                                            ilanı oluşturduktan sonra ödediği ilave Vitrin ve Doping
                                                            ücretlerini hiçbir şekilde iade edilmesini talep
                                                            edemeyeceğini peşinen kabul ve beyan eder.</p>
                                                        <p>2.19. İlanı yayından kaldırılan veya durdurulan Satıcı’ya
                                                            gerekli açıklama, Satıcı talep ederse Herseyoyun tarafından
                                                            48 saat içerisinde yapılır. İlan ile ilgili tüm itirazlar
                                                            Satıcı tarafından Destek Sistemi üzerinden talep
                                                            oluşturularak başlatılır. Destek Sistemi haricinde
                                                            başlatılan itirazlar hiçbir şekilde işleme alınmaz.</p>
                                                        <p>2.20. Alıcı ve Satıcı arasındaki işlemlerin kayıt altına
                                                            alınabilmesi ve gerektiğinde adli makamlara delil olarak
                                                            sunulabilmesi için Alıcı ve Satıcı, aralarındaki anlık
                                                            mesajlaşma dahil ve bununla da sınırlı kalmayacak tüm
                                                            işlemlerini Herseyoyun üzerinde yapacaklarını peşinen kabul
                                                            ve beyan eder. Alıcı ve Satıcı’nın, Herseyoyun haricinde
                                                            kendi aralarında yapacakları ticaretten Herseyoyun sorumlu
                                                            tutulamaz ve Herseyoyun'dan delil talebinde bulunulamaz.</p>
                                                        <p>2.21. Satıcı, ilgili ilanda yer alan ürün satışından elde
                                                            edilen gelirden; Herseyoyun'un internet sitesi veya mobil
                                                            uygulaması ve bununla sınırlı kalmayacak şekilde farklı
                                                            alanlarda belirttiği; Hizmet Bedeli, banka transfer ve
                                                            bununla sınırlı kalmayacak şekilde oluşabilecek ilave
                                                            ücretlendirmelerin düşülerek geri kalan tutarın kendi
                                                            hesabına, bakiye olarak yükleneceğini kabul ve beyan
                                                            eder.</p>
                                                        <p>2.22. Satıcı’nın ürünü teslim etme süresi ilan oluştururken
                                                            belirttiği süreyi geçemez. Zamanında teslim edilmeyen Satıcı
                                                            ilanı yayından kaldırılır. Satıcı’ya olumsuz ticaret puanı
                                                            verilir. Satıcı tarafından teslimatı yapılmamış ürün satış
                                                            işlemlerinde, Alıcı bakiyesinden yapılan ürün bedeli
                                                            kesintisi Alıcı’ya iade edilir. Satıcı yayından kaldırılan
                                                            ilanını tekrar yayına alabilir fakat bu ilan için alınan öne
                                                            çıkarma hizmet süresine, yayında olmadığı süre ilave
                                                            edilmez.</p>
                                                        <p><span style="color:#ffffff"><strong>3. YASAKLI ÜRÜNLER LİSTESİ</strong></span>
                                                        </p>
                                                        <ul>
                                                            <li>Sağlık Beyanlı Ürünler ve Cihazlar</li>
                                                            <li>Kültür ve Tabiat Varlıkları</li>
                                                            <li>Ateşli Silah ve Kesici Alet Satışı</li>
                                                            <li>Yanıcı ve Patlayıcı Malzemeler</li>
                                                            <li>Bandrolsüz Ürün Satışı</li>
                                                            <li>Alkollü İçecek ve Tütün Mamülleri</li>
                                                            <li>Cinsel İçerik ve Pornografik Ürünler</li>
                                                            <li>Taklit Ürün Satışı</li>
                                                            <li>Resmi Belge Satışı</li>
                                                            <li>Trafik Aygıtları ve Plaka</li>
                                                            <li>Fon ve Hisse Senedi</li>
                                                            <li>Organ</li>
                                                            <li>Evcil Hayvan ve Yasalarca Yasaklanmış Hayvanlar</li>
                                                            <li>Şans Oyunu Biletleri ve Makineleri</li>
                                                            <li>Tarım İlaçları ve İlaçlama Makineleri</li>
                                                            <li>Kişilik Hakları İhlaline Sebep Olabilecekler</li>
                                                            <li>Telsiz Ürünleri</li>
                                                            <li>Etkinlik Biletleri</li>
                                                            <li>İlaç Satışı</li>
                                                            <li>Ortak veya Hissedar Arama</li>
                                                            <li>Siyasi İçerikli Ürünler</li>
                                                            <li>Resmi Kıyafet &amp; Askeri Malzemeler</li>
                                                            <li>Her Türlü Uyuşturucu Madde</li>
                                                            <li>Hack Yazılımları</li>
                                                            <li>Sosyal Medya Pazarlama Hizmetleri</li>
                                                            <li>SEO vb. Hizmetler</li>
                                                            <li>Her Türlü Gıda</li>
                                                            <li>Sanal Para Satışı</li>
                                                            <li>Kayıt Dışı yada IMEI numarası kopyalanmış Telefonlar
                                                            </li>
                                                            <li>Çalıntı Ürünler</li>
                                                            <li>Emlak ve Arsa Satışı</li>
                                                            <li>Her Türlü Vasıta Satışı</li>
                                                            <li>Mailsiz hesap satışı</li>
                                                            <li>Kozmetik ve Sağlık Ürünleri</li>
                                                            <li>İç Giyim</li>
                                                            <li>Her Türlü Pornografik veya Genel Ahlak Kurallarına
                                                                Aykırı Ürünler
                                                            </li>
                                                            <li>Her Türlü İş İlanı, Eleman İlanı</li>
                                                            <li>Her Türlü Ön Sipariş İlanları</li>
                                                            <li>Riot Points, Valorant Points, EJDERHA PARASI ve diğer
                                                                tüm Epin ürünleri
                                                            </li>
                                                        </ul>
                                                    </div>
                                                    <div class="ui checkbox">
                                                        <input type="checkbox" name="kurallar" id="kurallar" value="1"
                                                               >
                                                        <label for="kurallar"><b>İlan verme kurallarını</b> okudum,
                                                            kabul ediyorum.</label>
                                                    </div>
                                                    <br><br>
                                                    <div style="clear: both;"></div>

                                                    <button type="submit" class="btn btn-primary pull-right finish-btn">
                                                        İlanı Oluştur!
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<script>
    $(document).ready(function () {
        $(document).on("submit", "#infoAddAdvert", function (event) {
            event.preventDefault();
            var serialized = $(this).serializeArray();
            $.ajax({
                method: 'post',
                dataType: 'json',
                data: serialized,
                url: 'ilanekle',
                success: function (result) {
                    if (result.status === true) {
                        iziToast.success({
                            title: 'Başarılı!!',
                            message: result.message,
                            position: 'topCenter'
                        });
                        setTimeout(function () {
                            window.location.href = result.url;
                        }, 2000);
                    } else {
                        iziToast.warning({
                            title: 'Uyarı!!',
                            message: result.message,
                            position: 'topCenter'
                        });
                    }

                },
                error: function () {
                    iziToast.error({
                        title: 'Hata!!',
                        message: 'Bağlantı Hatası Tekrar Deneyin',
                        position: 'topCenter'
                    });
                }
            });
        });

    });
</script>
