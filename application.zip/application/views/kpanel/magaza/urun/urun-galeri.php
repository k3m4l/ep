<?php $urun_json = json_decode($urun->urun_galeri); ?>
<section class="profileMainCard fsb">
<div class="container">
    <div class="panel m-0">
        <div class="panel-body pa-dys" style="background-position: center;background-image: url('<?php echo !empty($magaza->magaza_banner) ? base_url($magaza->magaza_banner) : 'https://kemalellidort.com.tr/uploads/logo/654fdd26a3671_invite-bg.png' ?>') !important">
            <div class="flexCard">
                <div class="userAvatar">
                    <img src="<?= !empty($magaza->magaza_resim) ? base_url($magaza->magaza_resim) : 'https://ui-avatars.com/api/?name='. $magaza_kullanici_bilgi->kullanici_ad .'&background=0D8ABC&color=fff' ?>" title="<?= $magaza->magaza_ad ?>"
                         alt="<?= $magaza->magaza_ad ?>">
                </div>

                <div class="userDetails">
                    <small>@<?= $magaza->magaza_seo ?> / <?= ucwords(strtolower($magaza->magaza_tur)) ?>
                        Mağaza</small>
                    <h1><?= $magaza->magaza_ad ?>
                        <?php if ($magaza->magaza_dogrulama == 1) { ?>
                            <a href="javascript:void(0)" class="top-0 right-0" data-toggle="tooltip"
                               data-placement="top" title="" data-original-title="Doğrulanmış Mağaza">
                                <img src="<?= base_url('assets/front/') ?>images/checked-mark.svg" alt=""
                                     height="30"
                                     width="30"/>
                            </a>
                        <?php } ?></h1>
                    <div class="profileBtns">
                        <?php if ($kullanici) { ?>
                            <?php if ($kullanici->kullanici_id != $magaza->kullanici_id) { ?>
                                <a href="<?= base_url('yeni-mesaj/' . $magaza->magaza_uniq); ?>"
                                   class="btn header-button btn-message"><i class="mdi mdi-message"></i> Mesaj
                                    Gönder
                                </a>
                            <?php } ?>
                        <?php } else { ?>
                            <button class="btn header-button btn-message" id="notLogin"><i
                                        class="mdi mdi-message"></i>
                                Mesaj Gönder
                            </button>
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row justify-content-center">
        <div class="col-12">
            <div class="card border-0 mb-4">
                <div class="card-header">
                    <h4 class="mb-0">Ürün Galeri Düzenle - <?= $urun->urun_ad ?></h4>
                </div>
                <div class="card-body">
                    <div class="mt-4">
                        <div class="table-responsive border-0 overflow-y-hidden">
                            <table class="table mb-0 text-nowrap">
                                <thead>
                                <tr>
                                    <th scope="col" class="border-0">Fotoğraf</th>
                                    <th scope="col" class="border-0">İşlem</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php if ($urun_json) {
                                    foreach ($urun_json as $key => $value) { ?>
                                        <tr>
                                            <td class="border-top-0">
                                                <a href="javascript:void(0)">
                                                    <img src="<?= base_url('uploads/img/' . $value) ?>"
                                                            class="rounded img-4by3-xxl"/></a>
                                            </td>
                                            <td class="border-top-0">
                                                <button type="button"
                                                    data-url="<?= base_url("urun-galeri-sil/$urun->urun_uniq/$key") ?>"
                                                    class="btn btn-danger btn-sm rounded-pill remove-btn">Sil</button>
                                            </td>
                                        </tr>
                                    <?php }
                                } else { ?>
                                    <tr>
                                        <td colspan="2" align="center">
                                            <div class="notification warning closeable"><p>Gösterilecek Fotoğraf
                                                    Bulunamadı!</p></div>
                                        </td>
                                    </tr>
                                <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
