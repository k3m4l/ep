
    <?php $this->load->view('kpanel/inc/magaza_nav', array('magaza' => $magaza)); ?>
    <section class="col-lg-8 control-panel">
        <div class="account-area">
        
        <div class="container p-0">
            <div class="row">
                <div class="col-lg-3 col-md-4 col-12 p-0">
                    <div class="user-img-left-area">
                        <img src="<?= base_url($kullanici->kullanici_resim) ?>" alt=""/>
                        <div>
                            <?= $kullanici->kullanici_ad ?>
                        </div>
                    </div>
                    
                    <?php $this->load->view('kpanel/inc/menu'); ?>
                </div>
                <div class="col-lg-9 col-md-8 col-12 pr-0">
                    
                    <a href="<?= base_url('ilan-ekle') ?>" target="_blank"
                       class="btn btn-primary btn-block badge-pill d-block d-sm-none mb-3">
                        <i class="fe fe-plus"></i> İlan Ekle
                    </a>
                    <div class="card mb-4">
                        
                        <div class="card-header d-flex justify-content-between align-items-center b-0">
                            <div>
                                <h3 class="mb-0">İlanlarım</h3>
                                <span>İlanlarınızın kontrolünü buradan sağlayabilirsiniz</span>
                            </div>
                            <div>
                                <a href="<?= base_url('ilan-ekle') ?>" target="_blank"
                                   class="btn btn-outline-primary badge-pill btn-sm d-none d-md-block">
                                    <i class="fe fe-plus"></i> İlan Ekle
                                </a>
                            </div>
                        </div>
                        
                        <div class="table-responsive border-0 overflow-y-hidden">
                            <table class="table mb-0 text-nowrap  dark-table light-table">
                                <thead>
                                <tr>
                                    <th scope="col" class="border-0">İlan</th>
                                    <th scope="col" class="border-0">Fiyat</th>
                                    <th scope="col" class="border-0">Kazanç</th>
                                    <th scope="col" class="border-0">Durum</th>
                                    <th scope="col" class="border-0"></th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php if ($urunler) {
                                    foreach ($urunler as $urun) { ?>
                                        <tr>
                                            <td class="border-top-0">
                                                <div class="d-lg-flex">
                                                    <div>
                                                        <a target="_blank" href="<?= base_url($urun->urun_seo) ?>">
                                                            <img src="<?= base_url($urun->urun_resim) ?>"
                                                                 alt="" class="rounded img-4by3-lg product-table-img"/></a>
                                                    </div>
                                                    <div class="ml-lg-3 mt-2 mt-lg-0">
                                                        <h4 class="mb-1 h5">
                                                            <a target="_blank" href="<?= base_url($urun->urun_seo) ?>"
                                                               class="text-inherit"><?= $urun->urun_ad ?></a>
                                                        </h4>
                                                        <ul class="list-inline font-size-xs mb-0">
                                                            <li class="list-inline-item">
                                                                <i class="far fa-clock mr-1"></i> <?= tarihCevir($urun->urun_zaman) ?>
                                                            </li>
                                                            <?php if (!reklam_kontrol2($urun->urun_id)) { ?>
                                                                <li class="list-inline-item text-warning">
                                                                    <i class="text-warning fas fa-bolt mr-1"></i>Öne
                                                                    Çıkarılan
                                                                </li>
                                                            <?php } ?>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </td>
                                            <td class="border-top-0"><?= $urun->urun_fiyat ?>₺</td>
                                            <td class="border-top-0"><?= $urun->urun_kfiyat ?>₺</td>
                                            <td class="border-top-0">
                                                <?php if ($urun->urun_durum == 0) { ?>
                                                    <span class="badge badge-warning">Yayınlanmayı Bekliyor..</span>
                                                <?php } elseif ($urun->urun_durum == 1) { ?>
                                                    <span class="badge badge-success">Yayınlandı</span>
                                                <?php } elseif ($urun->urun_durum == 2) { ?>
                                                    <span class="badge badge-danger" data-toggle="tooltip"
                                                          data-placement="top" title="<?= $urun->urun_iptal ?>">Yayınlanamadı</span>
                                                <?php } ?>
                                            </td>
                                            <td class="text-muted border-top-0">
											<span class="dropdown">
												<a class="text-muted text-decoration-none" href="#!" role="button"
                                                   id="courseDropdown"
                                                   data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
													<i class="fe fe-more-vertical"></i>
												</a>
												<span class="dropdown-menu" aria-labelledby="courseDropdown">
													<span class="dropdown-header">İşlemler </span>
													<a class="dropdown-item"
                                                       href="<?= base_url('ilan-duzenle/' . $urun->urun_uniq) ?>"><i
                                                            class="fe fe-edit dropdown-item-icon"></i><span
                                                            class="text-white">İlanı Düzenle</span></a>
                                                    <a class="dropdown-item"
                                                       href="<?= base_url('ilan-galeri/' . $urun->urun_uniq) ?>"><i
                                                            class="fe fe-image dropdown-item-icon"></i><span
                                                            class="text-white">Galeri Düzenle</span></a>
                                                    <?php if ($urun->urun_turu == 3) { ?>
                                                        <a class="dropdown-item"
                                                           href="<?= base_url('ilan-dosya/' . $urun->urun_uniq) ?>"><i
                                                                class="fe fe-file dropdown-item-icon"></i><span
                                                                class="text-white">Dosya Düzenle</span></a>
                                                    <?php } ?>
                                                    <?php if ($urun->urun_durum == 1) { ?>
                                                        <a class="dropdown-item"
                                                           href="<?= base_url('urun-reklam/' . $urun->urun_uniq) ?>"><i
                                                                class="fe fe-trending-up dropdown-item-icon"></i><span
                                                                class="text-white">Reklam</span></a>
                                                    <?php } ?>
													<a class="dropdown-item remove-btn" href="javascript:void(0)"
                                                       data-url="<?= base_url('urun-sil/' . $urun->urun_uniq) ?>"><i
                                                            class="fe fe-trash dropdown-item-icon"></i><span
                                                            class="text-white">Sil</span></a>
												</span>
											</span>
                                            </td>
                                        </tr>
                                    <?php }
                                } else { ?>
                                    <tr>
                                        <td colspan="5" align="center">
                                            <div class="notification warning closeable">
                                                <p>İlan Bulunamadı!</p>
                                            </div>
                                        </td>
                                    </tr>
                                <?php } ?>
                                </tbody>
                            </table>
                        </div>
                        <?= $links ?>
                    </div>
                </div>
            </div>
        </div>
        </div>
</section>