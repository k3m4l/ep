<?php
$this->load->view('kpanel/inc/magaza_nav', array('magaza' => $magaza));
?>

<div class="pb-5 py-md-5">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-4 col-12">
                
                <?php $this->load->view('kpanel/inc/menu'); ?>
            </div>
            <div class="col-lg-9 col-md-8 col-12">
                
                <div class="card border-0 mb-4">
                    
                    <div class="card-header">
                        <h4 class="mb-0">Ürün Galeri Düzenle - <?= $urun->urun_ad ?></h4>
                    </div>
                    
                    <div class="card-body">
                        <div class="alert alert-warning rounded-pill text-center">
                            <strong>Dikkat!</strong> Yeni dosya eklediğinizde eski dosyanız sistemden tamamen silir.
                        </div>
                        <form class="mb-5" action="<?=base_url('ilan-dosya-ekle/'.$urun->urun_uniq)?>" method="post" enctype="multipart/form-data">
                            <div class="form-group">
                                <label class="input-label">İndirilecek Ürün</label>
                                <div class="custom-file">
                                    <input type="file" name="dosya" id="dosya" class="custom-file-input"
                                           accept=".zip" onchange="getFileData(this);">
                                    <label class="custom-file-label" for="dosya">Dosya Seç</label>
                                </div>
                                <small>Ürün bilgileri ödeme yapıldıktan sonra otomatik olarak kişiye
                                    görünecektir. Sadece <span class="badge badge-danger badge-pill badge-sm">.zip</span> dosya türü desteklenmektedir.</small>
                                <div class="card mt-2" id="dosya_goster" style="display: none">
                                    <div class="p-3 d-flex justify-content-between">
                                        <div>
                                            <i class="fe fe-file"></i> <span class="dosya_adi"></span> / <small
                                                    class="dosya_size"></small>
                                        </div>
                                        <div>
                                            <a href="javascript:void(0)" id="dosya_sil"><i class="fe fe-x"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-success btn-sm rounded-pill">Dosya Güncelle</button>
                        </form>
                        <?php if ($urun->urun_indir){ $dosya = explode('/', $urun->urun_indir); ?>
                            <label class="input-label">Varsayılan Dosya</label>
                            <div class="card">
                                <div class="card-body d-flex justify-content-between align-items-center text-center">
                                    <div class="d-flex flex-column">
                                        <span class="badge badge-secondary mb-1">Dosya Adı : <i class="fe fe-file"></i> <?= $dosya[3] ?></span>
                                        <span class="badge badge-secondary">Dosya Boyutu : <?=filesize_formatted($urun->urun_indir)?></span>
                                    </div>
                                    <div>
                                        <a class="badge badge-primary" href="<?=base_url('dosya-indir/'.$urun->urun_uniq)?>"><i class="fe fe-download"></i> İndir</a>
                                        <a class="badge badge-danger remove-btn" href="javascript:void(0)"
                                           data-url="<?= base_url("dosya-sil/$urun->urun_uniq") ?>"><i class="fe fe-x"></i> Sil</a>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>