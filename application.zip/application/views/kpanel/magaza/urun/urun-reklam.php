<?php $this->load->view('kpanel/inc/magaza_nav', array('magaza' => $magaza)); ?>

<div class="pb-5 py-md-5">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-4 col-12">
                
                <?php $this->load->view('kpanel/inc/menu'); ?>
            </div>
            <div class="col-lg-9 col-md-8 col-12">
                <?php if ($reklamlar) { ?>
                    <div class="card mb-4">
                        <div class="card-body">
                            <ul class="list-group list-group-flush">
                                <?php foreach ($reklamlar as $reklam) { ?>
                                    <li class="list-group-item px-0 pt-0 p-0 mb-4">
                                        <div class="row">
                                            <div class="col-md-3 text-center mb-2">
                                                <span class="h4">
                                                    <?php if ($reklam->reklam_turu == 'anasayfa') {
                                                        echo 'Anasayfa Reklamı';
                                                    } elseif ($reklam->reklam_turu == 'kategori') {
                                                        echo 'Kategori Reklamı';
                                                    } ?>
                                                </span>
                                                <span class="d-block">
                                                    <?= date('d.m.Y H:i', strtotime($reklam->reklam_baslangic)) ?>
                                                </span>
                                            </div>
                                            <div class="col-md-3 text-center mb-2">
                                                <span class="h4"><?= $reklam->reklam_tutar ?>₺</span>
                                                <span class="d-block"><?= $reklam->reklam_gun ?> Gün</span>
                                            </div>
                                            <div class="col-md-6 text-center mb-2">
                                                <?php if ($reklam->reklam_durum == 0) { ?>
                                                    <a href="javascript:void(0)"
                                                       class="btn btn-outline-warning btn-sm rounded-pill">Ödeme
                                                        Bekleniyor..</a>
                                                    <a href="<?= base_url('reklam-odeme/' . $reklam->reklam_uniq) ?>"
                                                       class="btn btn-outline-white btn-sm rounded-pill">Ödeme Yap</a>
                                                    <a href="javascript:void(0)"
                                                       data-url="<?= base_url('reklam-odeme-iptal/' . $reklam->reklam_uniq) ?>"
                                                       class="btn btn-outline-danger btn-sm rounded-pill iptal-btn">İptal
                                                        Et</a>
                                                <?php } elseif ($reklam->reklam_durum == 1) { ?>
                                                    <?php if (!gunHesapla($reklam->reklam_bitis)) { ?>
                                                        <a href="javascript:void(0)"
                                                           class="btn btn-success btn-sm rounded-pill">Reklam Aktif</a>
                                                        <a href="javascript:void(0)"
                                                           class="btn btn-primary btn-sm rounded-pill"><?= zamanHesapla($reklam->reklam_bitis) ?></a>
                                                    <?php } else { ?>
                                                        <a href="javascript:void(0)"
                                                           class="btn btn-danger btn-sm rounded-pill">Reklam Süresi
                                                            Doldu</a>
                                                    <?php } ?>
                                                <?php } ?>
                                            </div>
                                        </div>
                                    </li>
                                <?php } ?>
                            </ul>
                        </div>
                    </div>
                <?php } ?>

                <div class="card border-0 mb-4">
                    
                    <div class="card-header">
                        <h4 class="mb-0">Ürün Reklam - <?= $urun->urun_ad ?></h4>
                    </div>
                    <div class="card-body">
                        <div>
                            <form action="<?= base_url('reklam-olustur/' . $urun->urun_uniq) ?>" method="post">
                                <div class="row">
                                    <div class="col-md-6 col-12 mb-1">
                                        <div class="border p-4 rounded-lg">
                                            <div class="custom-control custom-radio">
                                                <input type="radio" id="anasayfa_reklam" name="reklam_tur"
                                                       value="anasayfa"
                                                       class="custom-control-input">
                                                <label class="custom-control-label pl-1 h4" for="anasayfa_reklam">
                                                    Anasayfa Reklamı <i class="fe fe-info" data-toggle="tooltip"
                                                                        data-placement="top"
                                                                        title="Anasayfa'da Ürünü Öne Çıkart"></i>
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12 mb-1">
                                        <div class="border p-4 rounded-lg">
                                            <div class="custom-control custom-radio">
                                                <input type="radio" id="kategori_reklam" name="reklam_tur"
                                                       value="kategori"
                                                       class="custom-control-input">
                                                <label class="custom-control-label pl-1 h4" for="kategori_reklam">
                                                    Kategori Reklamı <i class="fe fe-info" data-toggle="tooltip"
                                                                        data-placement="top"
                                                                        title="Kategoriler'de Ürünü Öne Çıkart"></i>
                                                </label>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-md-12 mt-2 reklam_gun" style="display: none">
                                        <div class="form-group">
                                            <label class="form-label" for="currency">Reklam Gün Sayısı</label>
                                            <input class="form-control text-left" type="number" name="gun_sayisi"
                                                   placeholder="Reklam Gün Sayısı" id="gun_sayisi" required="">
                                            <div class="mt-2 text-center">
                                            <span class="badge badge-success d-flex flex-column">
                                                <div class="d-flex justify-content-between align-items-center text-center">
                                                    <span class="font-size-md">Ödenecek Tutar :</span>
                                                    <span class="font-size-md font-weight-bold"
                                                          id="reklam_tutar">0.00 ₺</span>
                                                </div>
                                                 <div class="d-flex justify-content-between align-items-center text-center mt-1">
                                                    <span>1 Günlük Fiyat :</span>
                                                    <span id="gunluk_fiyat">0.00 ₺</span>
                                                </div>
                                            </span>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <button type="submit" class="btn btn-primary badge-pill mt-3"> Reklam Siparişi Oluştur
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    $('input[type=radio][name=reklam_tur]').change(function () {
        if (this.value == 'anasayfa') {
            $('#gun_sayisi').val('');
            $('#reklam_tutar').html('0.00 ₺');
            $('#gun_sayisi').keyup(function () {
                var gun_sayisi = parseFloat($(this).val());

                if (!gun_sayisi || gun_sayisi == 0) {
                    $('#reklam_tutar').html('0.00 ₺');
                } else {
                    var reklam_toplam = parseFloat(gun_sayisi * anasayfa_reklam_fiyat).toFixed(2);
                    $('#reklam_tutar').html(reklam_toplam + ' ₺');
                }
            });
            $('#gunluk_fiyat').html(anasayfa_reklam_fiyat + ' ₺');
            $('.reklam_gun').show();
        } else if (this.value == 'kategori') {
            $('#gun_sayisi').val('');
            $('#reklam_tutar').html('0.00 ₺');
            $('#gun_sayisi').keyup(function () {
                var gun_sayisi = parseFloat($(this).val());

                if (!gun_sayisi || gun_sayisi == 0) {
                    $('#reklam_tutar').html('0.00 ₺');
                } else {
                    var reklam_toplam = parseFloat(gun_sayisi * kategori_reklam_fiyat).toFixed(2);
                    $('#reklam_tutar').html(reklam_toplam + ' ₺');
                }
            });
            $('#gunluk_fiyat').html(kategori_reklam_fiyat + ' ₺');
            $('.reklam_gun').show();
        }
    });
</script>