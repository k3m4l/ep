<?php
$request = new \Iyzipay\Request\CreateCheckoutFormInitializeRequest();
$request->setLocale(\Iyzipay\Model\Locale::TR);
$request->setConversationId('123456789');
$request->setPrice($reklam->reklam_tutar);
$request->setPaidPrice($reklam->reklam_tutar);
$request->setCurrency(\Iyzipay\Model\Currency::TL);
$request->setBasketId($reklam->reklam_no);
$request->setPaymentGroup(\Iyzipay\Model\PaymentGroup::PRODUCT);
$request->setCallbackUrl(base_url('kpanel_controller/reklam_odeme_onay'));
$request->setEnabledInstallments(array(2, 3, 6, 9));

$buyer = new \Iyzipay\Model\Buyer();
$buyer->setId($kullanici->kullanici_id);
$buyer->setName($magaza->isim);
$buyer->setSurname($magaza->soyisim);
$buyer->setGsmNumber('05555555555');
$buyer->setEmail($kullanici->kullanici_mail);
$buyer->setIdentityNumber($magaza->tc);
$buyer->setLastLoginDate($kullanici->kullanici_sonzaman);
$buyer->setRegistrationDate($kullanici->kullanici_zaman);
$buyer->setRegistrationAddress($magaza->fatura_adres);
$buyer->setIp(getIPAddress());
$buyer->setCity(sehir_ad($magaza->sehir));
$buyer->setCountry("Turkey");
$buyer->setZipCode('06100');

$request->setBuyer($buyer);
$shippingAddress = new \Iyzipay\Model\Address();
$shippingAddress->setContactName($magaza->isim." ".$magaza->soyisim);
$shippingAddress->setCity(sehir_ad($magaza->sehir));
$shippingAddress->setCountry("Turkey");
$shippingAddress->setAddress($magaza->fatura_adres);
$shippingAddress->setZipCode('06100');
$request->setShippingAddress($shippingAddress);

$billingAddress = new \Iyzipay\Model\Address();
$billingAddress->setContactName($magaza->isim." ".$magaza->soyisim);
$billingAddress->setCity(sehir_ad($magaza->sehir));
$billingAddress->setCountry("Turkey");
$billingAddress->setAddress($magaza->fatura_adres);
$billingAddress->setZipCode('06100');
$request->setBillingAddress($billingAddress);

if ($reklam->reklam_turu == 'anasayfa') {$reklam_ad = 'Anasayfa Reklamı';} elseif ($reklam->reklam_turu == 'kategori') {$reklam_ad = 'Kategori Reklamı';}

$basketItems = array();
$firstBasketItem = new \Iyzipay\Model\BasketItem();
$firstBasketItem->setId($reklam->reklam_no);
$firstBasketItem->setName($reklam_ad);
$firstBasketItem->setCategory1($reklam_ad);
$firstBasketItem->setCategory2($reklam_ad);
$firstBasketItem->setItemType(\Iyzipay\Model\BasketItemType::VIRTUAL);
$firstBasketItem->setPrice($reklam->reklam_tutar);
$basketItems[0] = $firstBasketItem;

$request->setBasketItems($basketItems);

$checkoutFormInitialize = \Iyzipay\Model\CheckoutFormInitialize::create($request, $options);
//print_r($checkoutFormInitialize->getStatus());
//print_r($checkoutFormInitialize->getErrorMessage());
print_r($checkoutFormInitialize->getCheckoutFormContent());
?>
<?php $this->load->view('kpanel/inc/magaza_nav', array('magaza' => $magaza)); ?>

<div class="pb-5 py-md-5">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-4 col-12">
                
                <?php $this->load->view('kpanel/inc/menu'); ?>
            </div>
            <div class="col-lg-9 col-md-8 col-12">
                <div class="card mb-4">
                    <div class="card-body">
                        <ul class="list-group list-group-flush">
                            <?php if ($reklam) { ?>
                                <li class="list-group-item px-0 pt-0 p-0">
                                    <div class="row">
                                        <div class="col-md-3 text-center">
                                                <span class="h4">
                                                    <?php if ($reklam->reklam_turu == 'anasayfa') {
                                                        echo 'Anasayfa Reklamı';
                                                    } elseif ($reklam->reklam_turu == 'kategori') {
                                                        echo 'Kategori Reklamı';
                                                    } ?>
                                                </span>
                                            <span class="d-block">
                                                    <?= date('d.m.Y H:i', strtotime($reklam->reklam_baslangic)) ?>
                                                </span>
                                        </div>
                                        <div class="col-md-3 text-center">
                                            <span class="h4"><?= $reklam->reklam_tutar ?>₺</span>
                                            <span class="d-block"><?= $reklam->reklam_gun ?> Gün</span>
                                        </div>
                                        <div class="col-md-6 text-center">
                                            <?php if ($reklam->reklam_durum == 0) { ?>
                                                <a href="javascript:void(0)"
                                                   class="btn btn-outline-warning btn-sm rounded-pill">Ödeme
                                                    Bekleniyor..</a>
                                            <?php } elseif ($reklam->reklam_durum == 1) { ?>
                                                <?php if (!gunHesapla($reklam->reklam_bitis)) { ?>
                                                    <a href="javascript:void(0)"
                                                       class="btn btn-success btn-sm rounded-pill">Reklam Aktif</a>
                                                    <a href="javascript:void(0)"
                                                       class="btn btn-primary btn-sm rounded-pill"><?= zamanHesapla($reklam->reklam_bitis) ?></a>
                                                <?php } else { ?>
                                                    <a href="javascript:void(0)"
                                                       class="btn btn-danger btn-sm rounded-pill">Reklam Süresi
                                                        Doldu</a>
                                                <?php } ?>
                                            <?php } ?>
                                        </div>
                                    </div>
                                </li>
                            <?php } ?>
                        </ul>
                    </div>
                </div>

                <div class="card border-0 mb-4">
                    
                    <div class="card-header">
                        <h4 class="mb-0">Reklam Ödeme - <?= $reklam->urun_ad ?></h4>
                    </div>
                    <div class="card-body">
                        <div id="iyzipay-checkout-form" class="responsive"></div>
                        <div id="ucs-cards"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>