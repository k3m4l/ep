
<?php $this->load->view('kpanel/inc/magaza_nav', array('magaza' => $magaza)); ?>
<section class="col-lg-8 control-panel">
    <div class="account-area">


    <div class="container p-0">
        <div class="row">
            <div class="col-lg-3 col-md-4 col-12 p-0">
                <div class="user-img-left-area">
                    <img src="<?= base_url($kullanici->kullanici_resim) ?>" alt=""/>
                    <div>
                        <?= $kullanici->kullanici_ad ?>
                    </div>
                </div>
                
                <?php $this->load->view('kpanel/inc/menu'); ?>
            </div>
            <div class="col-lg-9 col-md-8 col-12 pr-0">
                <div class="card mb-4">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-lg-12 col-md-12">
                                <div class="dashboard-list-box margin-top-0">
                                    <h4 class="gray">Mağaza Bilgileri</h4>
                                    <div class="dashboard-list-box-static">
                                        <ul class="nav nav-line-bottom" role="tablist">
                                            <li class="nav-item">
                                                <a class="nav-link active" id="hesap-bilgileri-tab" data-toggle="pill"
                                                   href="#hesap-bilgileri" role="tab"
                                                   aria-controls="hesap-bilgileri" aria-selected="true">Mağaza
                                                    Bilgileri</a>
                                            </li>
                                            <?php if ($magaza->magaza_sosyal_onay == 1) { ?>
                                                <li class="nav-item">
                                                    <a class="nav-link" id="sosyal-medya-tab" data-toggle="pill"
                                                       href="#sosyal-medya" role="tab"
                                                       aria-controls="sosyal-medya" aria-selected="true">Sosyal Medya
                                                        Ayarları</a>
                                                </li>
                                            <?php } ?>

                                        </ul>
                                        <div class="tab-content p-4">
                                            <div class="tab-pane tab-example-design fade show active"
                                                 id="hesap-bilgileri" role="tabpanel"
                                                 aria-labelledby="hesap-bilgileri-tab">

                                                <form method="post" action="<?= base_url("magaza-foto") ?>"
                                                      enctype="multipart/form-data">
                                                    <label>Mağaza Kapak Fotoğrafı</label>
                                                    <style>
                                                        .avatar-upload {
                                                            max-width: 100%;
                                                        }
                                                        .avatar-upload .avatar-preview {
                                                            width: 100%;
                                                            height: 120px;
                                                            position: relative;
                                                            border-radius: %0;
                                                            border: none;
                                                            box-shadow: 0px 2px 4px 0px rgba(0, 0, 0, 0.1);
                                                        }
                                                        .avatar-upload .avatar-edit {
                                                            position: absolute;
                                                            right: 10px;
                                                            z-index: 1;
                                                            top: 10px;
                                                        }
                                                        .avatar-upload .avatar-preview > div {
                                                            width: 100%;
                                                            height: 100%;
                                                            border-radius: 0px;
                                                            background-size: cover;
                                                            background-repeat: no-repeat;
                                                            background-position: center;
                                                        }
                                                    </style>
                                                    <!-- Avatar -->
                                                    <div class="avatar-upload">
                                                        <div class="avatar-edit">
                                                            <input type='file' id="imageUpload" name="file"
                                                                   accept=".png, .jpg, .jpeg"/>
                                                            <label for="imageUpload"></label>
                                                        </div>
                                                        <div class="avatar-preview">
                                                            <div id="imagePreview"
                                                                 style="background-image: url(<?= base_url($magaza->magaza_resim) ?>);">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="form-group col-12 col-md-6">
                                                            <label class="form-label">Mağaza Adı</label>
                                                            <input type="text" class="form-control"
                                                                   placeholder="Mağaza Adı"
                                                                   value="<?= $magaza->magaza_ad ?>" disabled>
                                                        </div>

                                                        <div class="form-group col-12 col-md-6">
                                                            <label class="form-label">Mağaza Türü</label>
                                                            <input type="text" class="form-control"
                                                                   placeholder="Mağaza Türü"
                                                                   value="<?= ucwords(strtolower($magaza->magaza_tur)) ?>"
                                                                   disabled>
                                                        </div>

                                                        <div class="col-md-12" <?php if ($magaza->magaza_tur != 'kurumsal') {
                                                            echo 'style="display:none"';
                                                        } ?>>
                                                            <div class="row">
                                                                <div class="form-group col-md-12">
                                                                    <label class="form-label">Firma Adı</label>
                                                                    <input type="text" class="form-control"
                                                                           placeholder="Mağaza Türü"
                                                                           value="<?= $magaza->firma_ad ?>" disabled>
                                                                </div>

                                                                <div class="form-group col-12 col-md-6">
                                                                    <label class="form-label">Vergi Dairesi</label>
                                                                    <input type="text" class="form-control"
                                                                           placeholder="Vergi Dairesi"
                                                                           value="<?= $magaza->vergi_dairesi ?>"
                                                                           disabled>
                                                                </div>

                                                                <div class="form-group col-12 col-md-6">
                                                                    <label class="form-label">Vergi Numarası</label>
                                                                    <input type="text" class="form-control"
                                                                           placeholder="Vergi Numarası"
                                                                           value="<?= $magaza->vergi_numarasi ?>"
                                                                           disabled>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div class="form-group col-12 col-md-6">
                                                            <label class="form-label">Adınız</label>
                                                            <input type="text" class="form-control" placeholder="Adınız"
                                                                   value="<?= $magaza->isim ?>" disabled>
                                                        </div>

                                                        <div class="form-group col-12 col-md-6">
                                                            <label class="form-label">Soyadınız</label>
                                                            <input type="text" class="form-control"
                                                                   placeholder="Soyadınız"
                                                                   value="<?= $magaza->soyisim ?>" disabled>
                                                        </div>

                                                        <div class="form-group col-12 col-md-6">
                                                            <label class="form-label">TC Kimlik Numarası</label>
                                                            <input type="text" class="form-control"
                                                                   placeholder="TC Kimlik Numarası"
                                                                   value="<?= $magaza->tc ?>" disabled>
                                                        </div>

                                                        <div class="form-group col-12 col-md-6">
                                                            <label class="form-label">Doğum Tarihi</label>
                                                            <input type="text" class="form-control"
                                                                   placeholder="Doğum Tarihi"
                                                                   value="<?= $magaza->dogum_tarihi ?>" disabled>
                                                        </div>

                                                        <div class="form-group col-12 col-md-6">
                                                            <label class="form-label">Şehir</label>
                                                            <input type="text" class="form-control" placeholder="Şehir"
                                                                   value="<?= sehir_ad($magaza->sehir) ?>" disabled>
                                                        </div>

                                                        <div class="form-group col-12 col-md-6">
                                                            <label class="form-label">İlçe</label>
                                                            <input type="text" class="form-control" placeholder="İlçe"
                                                                   value="<?= ilce_ad($magaza->ilce) ?>" disabled>
                                                        </div>

                                                        <div class="form-group col-12 col-md-12">
                                                            <label class="form-label">Fatura Adresi</label>
                                                            <textarea class="form-control" rows="4"
                                                                      disabled><?= $magaza->fatura_adres ?></textarea>
                                                        </div>


                                                    </div>

                                                    <button type="submit" class="btn btn-primary rounded-pill mt-3">
                                                        Fotoğraf Güncelle
                                                    </button>
                                                </form>


                                            </div>
                                            <?php if ($magaza->magaza_sosyal_onay == 1) { ?>
                                                <div class="tab-pane tab-example-html fade" id="sosyal-medya"
                                                     role="tabpanel" aria-labelledby="sosyal-medya-tab">
                                                    <form action="<?= base_url('sosyal-ayar') ?>" method="post">
                                                        <!-- Facebook -->
                                                        <div class="form-group mb-4">
                                                            <label for="facebookPage" class="form-label">Facebook
                                                                <small class="text-muted">
                                                                    (örn. https://www.facebook.com/magaza_adi)</small>
                                                            </label>
                                                            <input class="form-control" name="facebook"
                                                                   placeholder="örn. https://www.facebook.com/magaza_adi"
                                                                   value="<?= $magaza->facebook ?>" type="text"/>
                                                        </div>
                                                        <!-- Twitter -->
                                                        <div class="form-group mb-4">
                                                            <label for="twitterPage" class="form-label">Twitter
                                                                <small class="text-muted">
                                                                    (örn. https://www.twitter.com/magaza_adi)</small>
                                                            </label>
                                                            <input class="form-control" name="twitter"
                                                                   placeholder="örn. https://www.twitter.com/magaza_adi"
                                                                   type="text" value="<?= $magaza->twitter ?>"/>
                                                        </div>
                                                        <!-- Youtube -->
                                                        <div class="form-group mb-4">
                                                            <label for="youtubePage" class="form-label">YouTube
                                                                Kanalı<small
                                                                        class="text-muted">
                                                                    (örn. https://www.youtube.com/magaza_adi)</small>
                                                            </label>
                                                            <input class="form-control" name="youtube"
                                                                   placeholder="örn. https://www.youtube.com/magaza_adi "
                                                                   type="text" value="<?= $magaza->youtube ?>"/>
                                                        </div>
                                                        <!-- Instagram -->
                                                        <div class="form-group mb-4">
                                                            <label for="instaPage" class="form-label">Instagram<small
                                                                        class="text-muted">
                                                                    (örn. https://www.instagram.com/magaza_adi)</small>
                                                            </label>
                                                            <input class="form-control" name="instagram"
                                                                   placeholder="örn. https://www.instagram.com/magaza_adi "
                                                                   type="text" value="<?= $magaza->instagram ?>"/>
                                                        </div>

                                                        <div class="form-group mb-4">
                                                            <label for="instaPage" class="form-label">Web Sitesi<small
                                                                        class="text-muted">
                                                                    (örn. https://siteadresi.com)</small>
                                                            </label>
                                                            <input class="form-control" name="web_site"
                                                                   placeholder="örn. https://siteadresi.com "
                                                                   type="text"
                                                                   value="<?= $magaza->web_site ?>"/>
                                                        </div>
                                                        <!-- Button -->
                                                        <button type="submit" class="btn btn-primary">Bilgileri Güncelle
                                                        </button>
                                                    </form>
                                                </div>
                                            <?php } ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
</section>