<!-- Page header-->
<div class="py-4 py-lg-6 bg-primary">
    <div class="container">
        <div class="row">
            <div class="offset-lg-1 col-lg-10 col-md-12 col-12">
                <div class="d-lg-flex align-items-center justify-content-between">
                    
                    <div class="mb-4 mb-lg-0">
                        <h1 class="text-white mb-1">Mağaza Başvurusu Yap</h1>
                        <p class="mb-0 text-white lead">
                            Bireysel veya Kurumsal olarak mağaza başvurusu yapabilirsiniz.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Page Content -->
<div class="pb-12">
    <div class="container">
        <div class="bs-stepper">
            <div class="row">
                <div class="offset-lg-1 col-lg-10 col-md-12 col-12">
                    <div class="bs-stepper-content mt-5">
                        <script>
                            $(document).ready(function () {
                                $(".code-button").on("click", function () {
                                    Swal.fire({
                                        html: $(".telno .grid").html(),
                                        showCancelButton: false,
                                        showConfirmButton: false,
                                        showCloseButton: true,
                                        allowOutsideClick: true,
                                        allowEscapeKey: false,
                                        focusConfirm: false,
                                        customClass: {
                                            container: "telefon-dogrulama"
                                        }
                                    });
                                });
                            });
                        </script>

                        <form class="<?php echo !empty($magaza) ? 'magaza_guncelle' : 'magaza_olustur' ?>">
                            
                            <div class="alert alert-secondary mb-4 text-center input-radius">
                                Başvurular için <b>TC Kimlik</b> doğrulama işlemi yapılmaktadır. Dolandırıcılığın
                                önüne geçmek için uygulanan bir güvenlik tedbiridir.
                            </div>
                            <?php if (isset($magaza)) { ?>
                                <?php if ($magaza->magaza_durum == 2) { ?>
                                    <div class="alert alert-danger mb-4 text-center input-radius">
                                        <b>Mağaza Başvurunuz Reddedilmiştir!</b> Lütfen bilgilerinizi kontrol ederek
                                        tekrar başvuru yapınız.
                                        <br>
                                        <b>İptal Sebebei : </b> <?= $magaza->magaza_iptal ?>
                                    </div>
                                <?php } ?>
                            <?php } ?>

                            <div class="card mb-3 ">
                                <div class="card-header border-bottom px-4 py-3">
                                    <h4 class="mb-0">Mağaza & Kişisel Bilgiler</h4>
                                </div>
                                
                                <div class="card-body">
                                    <div class="form-group">
                                        <label class="form-label">Mağaza Adı</label>
                                        <input class="form-control input-radius" type="text" name="magaza_ad" required
                                               placeholder="Mağaza Adı"
                                               value="<?php echo !empty($magaza) ? $magaza->magaza_ad : '' ?>"/>
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label">Mağaza Kullanıcı Adı <small><?= base_url('m/') ?>
                                                <code class="url_ad"><?php echo !empty($magaza) ? $magaza->magaza_seo : 'magaza-adi' ?></code></small></label>
                                        <input onblur="checkUsername()" required
                                               class="form-control input-radius magaza_kullanici" type="text"
                                               name="magaza_seo" placeholder="Mağaza Kullanıcı Adı"
                                               value="<?php echo !empty($magaza) ? $magaza->magaza_seo : '' ?>"/>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="form-label">Adınız</label>
                                                <input class="form-control input-radius" name="ad" type="text"
                                                       placeholder="Adınız.." required
                                                       value="<?php echo !empty($magaza) ? $magaza->isim : '' ?>"/>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="form-label">Soyadınız</label>
                                                <input class="form-control input-radius" name="soyad" type="text"
                                                       placeholder="Soyadınız.." required
                                                       value="<?php echo !empty($magaza) ? $magaza->soyisim : '' ?>"/>
                                            </div>
                                        </div>
                                        <div class="<?php echo !empty($magaza) ? 'col-md-10' : ($_SESSION['magazadog'] == 1 ? 'col-md-12' : 'col-md-10') ?>">
                                            <div class="form-group">
                                                <label class="form-label">Telefon Numaranız <?php echo !empty($magaza) ? '<small>(Telefon Numarasınız Değiştireceksiniz Yeni Telefon Numaranızı Lütfen Onaylarınız.)</small>' : '' ?></label>
                                                <input class="form-control input-radius <?php echo $_SESSION['magazadog'] == 1 ? '' : 'is-invalid' ?> tel-input"
                                                       id="accountPhone" name="phone" type="number"
                                                       value="<?php echo !empty($magaza) ? $magaza->telefon : (!empty($_SESSION['magazatel']) ? $_SESSION['magazatel'] : '') ?>"
                                                       placeholder="05XXXXXXXXX"
                                                       required <?php echo !empty($magaza) ? '' : ($_SESSION['magazadog'] == 1 ? 'disabled' : '') ?>/>
                                            </div>
                                        </div>
                                        <?php if (!empty($magaza)) { ?>
                                            <div class="col-md-2 code-button-area">
                                                <button type="button"
                                                        class="btn btn-primary btn-block badge-pill code-button"
                                                        style="margin-top: 26px">
                                                    Kod Gönder
                                                </button>
                                            </div>
                                        <?php } else { ?>
                                            <?php if ($_SESSION['magazadog'] != 1) { ?>
                                                <div class="col-md-2 code-button-area">
                                                    <button type="button"
                                                            class="btn btn-primary btn-block badge-pill code-button"
                                                            style="margin-top: 26px">
                                                        Kod Gönder
                                                    </button>
                                                </div>
                                            <?php } ?>
                                        <?php } ?>

                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="form-label">TC Kimlik Numarası</label>
                                                <input class="form-control input-radius" name="tc" type="number"
                                                       ng-model="number" required
                                                       onKeyPress="if(this.value.length==11) return false;" min="0"
                                                       placeholder="TC Kimlik Numarası" value="<?php echo !empty($magaza) ? $magaza->tc : '' ?>"/>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="form-label">Doğum Tarihi <small>(Sadece Doğum Yılını Giriniz.)</small></label>
                                                <input class="form-control input-radius" name="dogum_tarihi"
                                                       type="number" ng-model="number" required
                                                       onKeyPress="if(this.value.length==4) return false;" min="0"
                                                       placeholder="Doğum Tarihi" value="<?php echo !empty($magaza) ? $magaza->dogum_tarihi : '' ?>"/>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <p class="font-size-11 text-center">Kimlik doğrulama işlemi <b>T.C.
                                                    İçişleri
                                                    Bakanlığı Nüfus ve
                                                    Vatandaşlık İşleri Genel Müdürlüğü</b> Servis Alt Yapısı
                                                Sayesinde
                                                Yapılmaktadır.</p>
                                        </div>
                                    </div>

                                    <div class="row justify-content-center">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label class="form-label">Mağaza Türü</label> <br>
                                                <div class="custom-control custom-radio custom-control-inline">
                                                    <input type="radio" id="magaza-1" name="magaza_tur"
                                                           class="custom-control-input" value="bireysel" checked="">
                                                    <label class="custom-control-label " for="magaza-1">
                                                        <span class="text-darky">Bireysel</span>
                                                    </label>
                                                </div>
                                                <div class="custom-control custom-radio custom-control-inline">
                                                    <input type="radio" id="magaza-2" name="magaza_tur"
                                                           class="custom-control-input" value="kurumsal">
                                                    <label class="custom-control-label" for="magaza-2">
                                                        <span class="text-darky">Kurumsal</span>
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div id="kurumsal" style="display: none;">
                                        <div class="form-group">
                                            <label class="form-label">Firma Adı</label>
                                            <input class="form-control input-radius" name="firma_ad" type="text"
                                                   placeholder="Firma Adı" value="<?php echo !empty($magaza) ? $magaza->firma_ad : '' ?>"/>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label class="form-label">Vergi Dairesi</label>
                                                    <input class="form-control input-radius" name="vergi_dairesi"
                                                           type="text" placeholder="Vergi Dairesi" value="<?php echo !empty($magaza) ? $magaza->vergi_dairesi : '' ?>"/>
                                                </div>
                                            </div>
                                            <div class="col-md-8">
                                                <div class="form-group">
                                                    <label class="form-label">Vergi Numarası</label>
                                                    <input class="form-control input-radius" name="vergi_numarasi"
                                                           type="number" placeholder="Vergi Numarası" value="<?php echo !empty($magaza) ? $magaza->vergi_numarasi : '' ?>"/>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="form-label">Fatura Adresi</label>
                                        <textarea class="form-control input-radius" name="fatura_adres" rows="5"
                                                  placeholder="Fatura Adresi"><?php echo !empty($magaza) ? $magaza->fatura_adres : '' ?></textarea>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="form-label">Şehir</label>
                                                <select id="ilsec" name="sehir" class="form-control input-radius"
                                                        data-width="100%" required>
                                                    <option value="">Lütfen Seçiniz...</option>
                                                    <?php if ($iller) {
                                                        foreach ($iller as $il) { ?>
                                                            <option value="<?= $il->id ?>" <?php echo !empty($magaza) ? ($magaza->sehir == $il->id ? 'selected' : '') : '' ?>><?= $il->il_adi ?></option>
                                                        <?php }
                                                    } ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="form-label">İlçe</label>
                                                <select id="ilcesec" name="ilce" class="form-control input-radius"
                                                        data-width="100%" required>
                                                    <option>Lütfen Şehir Seçiniz..</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label">Mağazanızda ne satacaksınız?</label>
                                        <textarea class="form-control input-radius" name="magaza_bilgi" rows="5"
                                                  placeholder="Mağaza Hakkında Bilgi Verin.."><?php echo !empty($magaza) ? $magaza->magaza_hakkinda : '' ?></textarea>
                                    </div>
                                    <a href="<?= $ayarlar->gizlilik_politikasi; ?>">Başvuru Sözleşmesini</a> okudum,
                                    anladım kabul ediyorum.
                                </div>
                            </div>

                            <!-- Button -->
                            <button type="submit" class="btn btn-primary btn-block badge-pill magaza_olustur"
                                    id="magaza_btn"><?php echo !empty($magaza) ? 'Mağaza Başvurusu Güncelle' : 'Mağaza Oluştur' ?>
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="ui coupled telno modal">
    <div class="ui grid" style="margin:0;">
        <script>
            function sendCode(uw) {
                phone = $('.tel-input').val();

                if (phone.length < 11) {
                    alert("Telefon Numaranızı Eksik Girdiniz.");
                    return false;
                }

                $.ajax({
                    type: "POST",
                    url: "<?=base_url("sendmgz")?>",
                    data: {id: uw, phone: phone},
                    success: function (result) {
                        alert("Telefonunuza gönderilen doğrulama kodunu giriniz.");
                    }
                });
            }
        </script>
        <div class="eight wide column modal-login-left">
            <h4>İşlemlerin tamamlanması için telefon numaranızı doğrulamanız
                gerekiyor.</h4>
            <button id="gonderbt" onclick="sendCode('<?= uniqid(); ?>');"
                    class="btn btn-primary btn-m mb-5">SMS Gönder
            </button>
            <div id="alertimiz" class="alert alert-info font-size-11">SMS Gönder
                Butonuna Tıklayın!
            </div>
            <form method="post" id="islem-dogrulama">
                <div class="card mb-3" style="background: transparent!important;">
                    
                    <div class="card-body">
                        <div class="form-group">
                            <label class="form-label">Doğrulama Kodu</label>
                            <input class="form-control input-radius" type="text" name="kod"/>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary btn-block badge-pill">
                        Doğrula
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    $(document).ready(function () {
        $('#accountPhone').on('input',
            function () {
                var value =
                    $(this).val();
                value = value.replace(/\D/g, ''); // Sadece sayıları al
                if (value.charAt(0) !== '0') {
                    // Başında 0 yoksa otomatik ekle
                    value = '0' + value;
                }
                // 11 karakteri geçmemesi için kontrol
                if (value.length > 11) {
                    // 11 karakterden fazla ise son eklenen karakteri kaldır
                    value = value.slice(0, 11);
                }
                // Telefon numarasını formatla
                var formattedValue =
                    value.replace(/(\d{4})(\d{3})(\d{4})/, '$1 $2 $3');
                $(this).val(value);
            }
        );

        $(document).on("submit", "#islem-dogrulama", function (event) {
            event.preventDefault();
            var serialized = $(this).serializeArray();
            $.ajax({
                type: "POST",
                url: "<?=base_url("telefon-onay")?>",
                data: serialized,
                success: function (result) {
                    var data = JSON.parse(result);
                    if (data.status.status == 'success') {
                        $('.telefon-dogrulama').modal('hide');
                        $('.telefon-dogrulama').remove();
                        $('.tel-input').attr('disabled', 'disabled');
                        $('.tel-input').removeClass('is-invalid');
                        $('.code-button-area').remove();
                        Swal.fire(
                            'Başarılı',
                            data.status.message,
                            data.status.status,
                        );
                    } else {
                        Swal.fire(
                            'Hata!',
                            data.status.message,
                            data.status.status,
                        );
                    }
                }
            });
        });
    });

    /**
     * Mağaza Oluştur Submit Ajax İşlemi
     */
    $('.magaza_olustur').submit(function (event) {
        document.getElementById("magaza_btn").innerHTML = '<span class="spinner-border spinner-border-sm mr-2" role="status" aria-hidden="true"></span><span class="saving">Mağaza Başvurusu Yapılıyor<span>.</span><span>.</span><span>.</span></span>';
        document.getElementById("magaza_btn").disabled = true;

        var formData = {
            'magaza_ad': $('input[name=magaza_ad]').val(),
            'ad': $('input[name=ad]').val(),
            'soyad': $('input[name=soyad]').val(),
            'tc': $('input[name=tc]').val(),
            'dogum_tarihi': $('input[name=dogum_tarihi]').val(),
            'firma_ad': $('input[name=firma_ad]').val(),
            'vergi_dairesi': $('input[name=vergi_dairesi]').val(),
            'vergi_numarasi': $('input[name=vergi_numarasi]').val(),
            'magaza_tur': $('input[name=magaza_tur]').val(),
            'sehir': $('select[name=sehir]').val(),
            'ilce': $('select[name=ilce]').val(),
            'fatura_adres': $('textarea[name=fatura_adres]').val(),
            'magaza_bilgi': $('textarea[name=magaza_bilgi]').val(),
            'magaza_seo': $('input[name=magaza_seo]').val(),
        };

        $.ajax({
            type: 'POST',
            url: base_url + 'ajax_controller/magaza_olustur',
            data: formData,
            dataType: 'json',
            encode: true
        }).done(function (data) {

            if (data.durum == 'success') {
                iziToast.success({
                    title: 'Başarılı!',
                    message: data.s_baslik,
                    position: 'topRight',
                });
                document.getElementById("magaza_btn").innerHTML = 'Mağaza Oluştur';
                document.getElementById("magaza_btn").disabled = false;
            }

            if (data.durum == 'error') {
                iziToast.error({
                    title: 'Hata!',
                    message: data.s_baslik,
                    position: 'topRight',
                });
                document.getElementById("magaza_btn").innerHTML = 'Mağaza Oluştur';
                document.getElementById("magaza_btn").disabled = false;
            }

            if (data.redirect == true) {
                setTimeout(function () {
                    window.location.href = base_url + data.redirect_url;
                }, 2500);
            }


        });
        event.preventDefault();
    });

    /**
     * Mağaza Kullanıcı Adı Kontrol
     */
    function checkUsername() {
        var seo = $(".magaza_kullanici").val();
        $.ajax({
            type: 'post',
            url: 'ajax_controller/username_check',
            data: {
                seo: ToSeoUrl(seo)
            },
            dataType: 'json',
            success: function (response) {
                //alert(response.durum);
                if (response.durum == "success") {
                    $('.magaza_kullanici').removeClass('is-invalid');
                    $('.magaza_kullanici').addClass('is-valid');
                } else if (response.durum == "error") {
                    $('.magaza_kullanici').removeClass('is-valid');
                    $('.magaza_kullanici').addClass('is-invalid');
                }
            }
        });
    }

    $('.magaza_kullanici').keyup(function () {
        if (!$('.url_ad').html()) {
            $('.url_ad').html("firma-adi");
        } else {
            $('.url_ad').html(ToSeoUrl($(this).val()));
        }
    });

    /**
     * Yazılan Kelimeyi Seo Çevirme
     */
    function ToSeoUrl(textString) {

        textString = textString.replace(/ /g, "-");
        textString = textString.replace(/</g, "");
        textString = textString.replace(/>/g, "");
        textString = textString.replace(/"/g, "");
        textString = textString.replace(/é/g, "");
        textString = textString.replace(/!/g, "");
        textString = textString.replace(/’/, "");
        textString = textString.replace(/£/, "");
        textString = textString.replace(/^/, "");
        textString = textString.replace(/#/, "");
        textString = textString.replace(/$/, "");
        textString = textString.replace(/\+/g, "");
        textString = textString.replace(/%/g, "");
        textString = textString.replace(/½/g, "");
        textString = textString.replace(/&/g, "");
        textString = textString.replace(/\//g, "");
        textString = textString.replace(/{/g, "");
        textString = textString.replace(/\(/g, "");
        textString = textString.replace(/\[/g, "");
        textString = textString.replace(/\)/g, "");
        textString = textString.replace(/]/g, "");
        textString = textString.replace(/=/g, "");
        textString = textString.replace(/}/g, "");
        textString = textString.replace(/\?/g, "");
        textString = textString.replace(/\*/g, "");
        textString = textString.replace(/@/g, "");
        textString = textString.replace(/€/g, "");
        textString = textString.replace(/~/g, "");
        textString = textString.replace(/æ/g, "");
        textString = textString.replace(/ß/g, "");
        textString = textString.replace(/;/g, "");
        textString = textString.replace(/,/g, "");
        textString = textString.replace(/`/g, "");
        textString = textString.replace(/|/g, "");
        textString = textString.replace(/\./g, "");
        textString = textString.replace(/:/g, "");
        textString = textString.replace(/İ/g, "i");
        textString = textString.replace(/I/g, "i");
        textString = textString.replace(/ı/g, "i");
        textString = textString.replace(/ğ/g, "g");
        textString = textString.replace(/Ğ/g, "g");
        textString = textString.replace(/ü/g, "u");
        textString = textString.replace(/Ü/g, "u");
        textString = textString.replace(/ş/g, "s");
        textString = textString.replace(/Ş/g, "s");
        textString = textString.replace(/ö/g, "o");
        textString = textString.replace(/Ö/g, "o");
        textString = textString.replace(/ç/g, "c");
        textString = textString.replace(/Ç/g, "c");
        textString = textString.replace(/–/g, "-");
        textString = textString.replace(/—/g, "-");
        textString = textString.replace(/—-/g, "-");
        textString = textString.replace(/—-/g, "-");

        return textString.toLowerCase();
    }

</script>
