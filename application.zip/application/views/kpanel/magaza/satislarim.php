<?php $this->load->view('kpanel/inc/magaza_nav', array('magaza' => $magaza)); ?>
<section class="col-lg-8 control-panel">
    <div class="account-area">
        <div class="container p-0">
            <div class="row">
                <div class="col-lg-3 col-md-4 col-12 p-0">
                    <div class="user-img-left-area">
                        <img src="<?= base_url($kullanici->kullanici_resim) ?>" alt=""/>
                        <div>
                            <?= $kullanici->kullanici_ad ?>
                        </div>
                    </div>
                    <?php $this->load->view('kpanel/inc/menu'); ?>
                </div>
                <div class="col-lg-9 col-md-8 col-12 pr-0">
                    <div class="card mb-4">
                        
                        <div class="card-header border-bottom-0">
                            <h3 class="h4 mb-3">Satışlarım</h3>
                        </div>
                        
                        <div class="table-responsive border-0">
                            <table class="table mb-0 text-nowrap">
                                <thead>
                                <tr>
                                    <th class="border-0">Sipariş No</th>
                                    <th class="border-0">Durum</th>
                                    <th class="border-0">Tutar</th>
                                    <th class="border-0">Tarih</th>
                                    <th class="border-0"></th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php if ($siparislerim) {
                                    foreach ($siparislerim as $siparis) { ?>
                                        <tr>
                                            <td class="align-middle border-top-0">
                                                <a data-toggle="tooltip" data-placement="top" title="Sipariş Detayı"
                                                   href="<?= base_url('satis-detay/' . $siparis->siparis_no) ?>">#<?= $siparis->siparis_no ?></a>
                                            </td>
                                            <td class="align-middle border-top-0">
                                                <?php if ($siparis->siparis_durum == 1) { ?>
                                                    <a href="javascript:void(0)" class="badge badge-secondary">Teslimatı
                                                        Onay Bekliyor
                                                    </a>
                                                <?php } elseif ($siparis->siparis_durum == 2) { ?>
                                                    <span class="badge badge-success">Ödeme Yapıldı</span>
                                                <?php } elseif ($siparis->siparis_durum == 3) { ?>
                                                    <span data-toggle="tooltip" data-placement="top"
                                                          title="<?= $siparis->siparis_iptal ?>"
                                                          class="badge badge-danger">Sipariş İptal Edildi</span>
                                                <?php } ?>
                                            </td>
                                            <td class="align-middle border-top-0"><?= $siparis->siparis_tutar ?>₺</td>
                                            <td class="align-middle border-top-0"><?= date('d.m.Y H:m', strtotime($siparis->siparis_tarih)) ?></td>
                                            <td class="align-middle border-top-0">
                                                <a href="<?= base_url('satis-detay/' . $siparis->siparis_no) ?>"
                                                   class="btn btn-primary btn-sm" data-toggle="tooltip"
                                                   data-placement="top" title="Görüntüle">
                                                    <i class="fe fe-eye"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php }
                                } else { ?>
                                    <tr>
                                        <td colspan="6" align="center">
                                            <div class="notification warning closeable"><p>Sipariş Bulunamadı</p></div>
                                        </td>
                                    </tr>
                                <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <?= $links ?>
                </div>
            </div>
        </div>
    </div>
</section>