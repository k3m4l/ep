
<?php
$this->load->view('kpanel/inc/magaza_nav', array('magaza' => $magaza));
?>
<section class="col-lg-8 control-panel">
    <div class="account-area">
    <div class="container p-0">
        <div class="row">
            <div class="col-lg-3 col-md-4 col-12 p-0">
                <div class="user-img-left-area">
                    <img src="<?= base_url($kullanici->kullanici_resim) ?>" alt=""/>
                    <div>
                        <?= $kullanici->kullanici_ad ?>
                    </div>
                </div>
                <?php $this->load->view('kpanel/inc/menu'); ?>
            </div>
            <div class="col-lg-9 col-md-8 col-12 pr-0">
                
                <div class="card mb-4">
                    
                    <div class="card-body">
                        <h3 class="mb-0">Kazançlarım</h3>
                        <p class="mb-0">
                            Kesinleşmiş kazançlarınızı görebilirsiniz
                        </p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-4 col-md-12 col-12">
                        
                        <div class="card mb-4">
                            
                            <div class="p-4">
                                <span class="icon-shape icon-sm bg-light-primary text-dark-primary rounded-lg">₺</span>
                                <h2 class="h1 font-weight-bold mb-0 mt-4 lh-1">
                                    <?= $odenen_kazanclar ?>₺
                                </h2>
                                <p>Toplam Ödenen Kazanç</p>
                                <div class="progress bg-light-primary" style="height: 2px">
                                    <div class="progress-bar" role="progressbar" style="width: 100%" aria-valuenow="100"
                                         aria-valuemin="0"
                                         aria-valuemax="100"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-12 col-12">
                        
                        <div class="card mb-4">
                            
                            <div class="p-4">
                                <span class="icon-shape icon-sm bg-light-danger text-dark-danger rounded-lg">₺</span>
                                <h2 class="h1 font-weight-bold mb-0 mt-4 lh-1">
                                    <?= $odenebilir_kazanclar ?>₺
                                </h2>
                                <p>Ödenebilir Kazanç</p>
                                <div class="progress bg-light-danger" style="height: 2px">
                                    <div class="progress-bar bg-danger" role="progressbar" style="width: 100%"
                                         aria-valuenow="100"
                                         aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-12 col-12">
                        
                        <div class="card mb-4">
                            
                            <div class="p-4">
                                <span class="icon-shape icon-sm bg-light-warning text-dark-warning rounded-lg">₺</span>
                                <h2 class="h1 font-weight-bold mb-0 mt-4 lh-1">
                                    <?= $toplam_kazanclar ?>₺
                                </h2>
                                <p>Şimdiye Kadarki Kazanç</p>
                                <div class="progress bg-light-warning" style="height: 2px">
                                    <div class="progress-bar bg-warning" role="progressbar" style="width: 100%"
                                         aria-valuenow="100"
                                         aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="card mb-4">
                    
                    <div class="card-header d-flex justify-content-between">
                        <h4 class="mb-0">Kazançlarım</h4>
                    </div>
                    
                    <div class="card-body">
                        <div class="row">
                            <div class="col-xl-3 col-lg-4 col-md-12 col-12 mb-3 mb-lg-0">
                                <div>
                                    <i class="fe fe-shopping-cart icon-shape icon-sm rounded-lg bg-light-success text-dark-success mt-2"></i>
                                    <h3 class="display-4 font-weight-bold mt-3 mb-0">
                                        <?= $aylik_kazanc ?>₺
                                    </h3>
                                    <span>Bu Ay Toplam Kazancınız</span>
                                    <hr class="my-4"/>
                                    <div class="row">
                                        <div class="col-auto">
                                            <h3 class="display-4 font-weight-bold mt-3 mb-0">
                                                <?= $gunluk_kazanc ?>₺
                                            </h3>
                                            <span>Bugün Toplam Kazancınız</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- Earning chart -->
                            <div class="col-xl-9 col-lg-8 col-md-12 col-12">
                                <div id="earning" class="apex-charts"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
<script>
    var aylar = <?=$aylar?>;
    var veriler = <?=$veriler?>;
</script>
</section>