<?php $this->load->view('kpanel/inc/magaza_nav', array('magaza' => $magaza)); ?>
<section class="col-lg-8 control-panel">
    <div class="account-area">
        
        <div class="container p-0">
            <div class="row">
                <div class="col-lg-3 col-md-4 col-12 p-0">
                    <div class="user-img-left-area">
                        <img src="<?= base_url($kullanici->kullanici_resim) ?>" alt=""/>
                        <div>
                            <?= $kullanici->kullanici_ad ?>
                        </div>
                    </div>
                    
                    <?php $this->load->view('kpanel/inc/menu'); ?>
                </div>
                <div class="col-lg-9 col-md-8 col-12 pr-0">
                    <div class="card mb-4">
                        
                        <div class="card-header d-lg-flex align-items-center justify-content-between">
                            <div class="mb-3 mb-lg-0">
                                <h3 class="mb-0">Yorumlar</h3>
                                <span>Ürünlerinize yapılan yorum değerlendirmelerini görebilirsiniz.</span>
                            </div>
                        </div>
                        
                        <div class="card-body">
                            <ul class="list-group list-group-flush">
                                <?php if ($yorumlar) {
                                    foreach ($yorumlar as $yorum) { ?>
                                        <li class="list-group-item px-0 py-4">
                                            <div class="media">
                                                <img src="<?= base_url($yorum->kullanici_resim) ?>"
                                                     alt="<?= $yorum->kullanici_isim . " " . $yorum->kullanici_soyisim ?>"
                                                     class="rounded-circle avatar-lg"/>
                                                <div class="ml-3 mt-2 media-body">
                                                    <div class="d-flex align-items-center justify-content-between">
                                                        <div>
                                                            <h4 class="mb-0"><?= $yorum->kullanici_isim . " " . $yorum->kullanici_soyisim ?>
                                                                -
                                                                <span
                                                                    class="text-muted font-size-xs mb-0"><?= $yorum->kullanici_mail ?></span>
                                                            </h4>
                                                            <span
                                                                class="text-muted font-size-xs"><?= date('d.m.Y H:i', strtotime($yorum->yorum_zaman)) ?></span>
                                                        </div>
                                                        <div>
                                                            <a href="javascript:void(0)" data-toggle="modal"
                                                               data-target="#yorum_<?= $yorum->yorum_id ?>"
                                                               data-toggle="tooltip" data-placement="top"
                                                               title="Yorumu Raporla"><i
                                                                    class="fe fe-flag"></i></a>
                                                        </div>
                                                    </div>
                                                    <?php if ($yorum->yorum_durum == 2) { ?>
                                                        <span class="font-size-xs text-danger"><i class="fe fe-x"></i> Yayından Kaldırıldı</span>
                                                    <?php } ?>
                                                    <div class="mt-2">
												<span class="mr-1">
													<?= yorum_yildiz($yorum->yorum_puan) ?>
												</span>
                                                        <span class="h5"><a target="_blank"
                                                                            href="<?= base_url($yorum->urun_seo) ?>"><?= $yorum->urun_ad ?></a></span>
                                                        <p class="mt-2"><?= $yorum->yorum_detay ?></p>
                                                    </div>
                                                </div>
                                            </div>
                                        </li>
                                        <?php if ($yorum->yorum_durum != 0) { ?>
                                            <div class="modal fade" id="yorum_<?= $yorum->yorum_id ?>"
                                                 tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
                                                 aria-hidden="true">
                                                <div class="modal-dialog modal-dialog-centered" role="document">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="exampleModalLabel">Yorum
                                                                Raporla</h5>
                                                            <button type="button" class="close" data-dismiss="modal"
                                                                    aria-label="Close">
                                                                <span aria-hidden="true">&times;</span>
                                                            </button>
                                                        </div>
                                                        <div class="modal-body text-center">
                                                            <p class="text-muted font-size-xs">Spam veya Saldırı olarak
                                                                düşündüğünüz yorumları raporlayabilirsiniz.</p>
                                                            <?php if (!yorum_itiraz_say($yorum->yorum_id)) { ?>
                                                                <form
                                                                    action="<?= base_url('yorum-itiraz/' . $yorum->yorum_id) ?>"
                                                                    method="post">
                                                                    <div class="form-group">
                                                                <textarea name="itiraz" class="form-control" rows="5"
                                                                          placeholder="Açıklama Yazın.."
                                                                          required></textarea>
                                                                    </div>
                                                                    <button type="submit"
                                                                            class="btn btn-danger btn-block input-radius">
                                                                        <i class="fe fe-comment"></i> Yorumu Raporla
                                                                    </button>
                                                                </form>
                                                            <?php } else {
                                                                $yorum_itiraz = yorum_itiraz($yorum->yorum_id); ?>
                                                                <?php if ($yorum_itiraz->itiraz_durum == 0) { ?>
                                                                    <button
                                                                        class="btn btn-outline-warning rounded-pill btn-block mb-2">
                                                                        İnceleniyor..
                                                                    </button>
                                                                <?php } elseif ($yorum_itiraz->itiraz_durum == 1) { ?>
                                                                    <button
                                                                        class="btn btn-success rounded-pill btn-block mb-2">
                                                                        İtirazınız Onaylandı
                                                                    </button>
                                                                <?php } elseif ($yorum_itiraz->itiraz_durum == 2) { ?>
                                                                    <button
                                                                        class="btn btn-danger rounded-pill btn-block mb-2">
                                                                        İtirazınız Onaylanmadı
                                                                    </button>
                                                                <?php } ?>
                                                                <div class="form-group">
                                                                <textarea class="form-control" rows="5"
                                                                          placeholder="Açıklama Yazın.."
                                                                          disabled><?= $yorum_itiraz->itiraz ?></textarea>
                                                                </div>
                                                            <?php } ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php } ?>
                                    <?php }
                                } else { ?>
                                    <li class="list-group-item px-0 py-4 text-center" style="color:black !important">
                                        Ürünlerinize ait yorum değerlendirmesi bulunamadı!
                                    </li>
                                <?php } ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>