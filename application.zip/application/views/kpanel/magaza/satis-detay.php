<?php $this->load->view('kpanel/inc/magaza_nav', array('magaza' => $magaza)); ?>

<div class="pb-5 py-md-5">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-4 col-12">
                
                <div class="user-img-left-area">
                    <img src="<?= base_url($kullanici->kullanici_resim) ?>" alt=""/>
                    <div>
                        <?= $kullanici->kullanici_ad ?>
                    </div>
                </div>
                <?php $this->load->view('kpanel/inc/menu'); ?>
            </div>
            <div class="col-lg-9 col-md-8 col-12">
                <div class="card mb-4">
                    <div class="row no-gutters">
                        <div class="col-md-8">
                            
                            <div class="card-body">
                                <h3 class="mb-2 text-truncate-line-2 ">
                                    <a target="_blank" href="<?= base_url($siparis->urun_seo) ?>"
                                       class="text-inherit"><?= $siparis->urun_ad ?></a>
                                </h3>
                                <!-- Row -->
                                <div class="row align-items-center no-gutters">
                                    <div class="col-auto">
                                        <img src="<?= base_url($siparis->magaza_resim) ?>"
                                             class="rounded-circle avatar-xs" alt="<?= $siparis->urun_ad ?>">
                                    </div>
                                    <div class="col ml-2">
                                        <a target="_blank"
                                           href="<?= base_url('m/' . $siparis->magaza_seo) ?>"><?= $siparis->magaza_ad ?></a>
                                    </div>
                                </div>
                                <div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 text-center">
                            <div class="card-body">
                                <span>Sipariş Tutarı</span>
                                <div class="d-flex justify-content-center">
                                    <div class="font-size-27 font-weight-bold text-primary"><?= $siparis->siparis_tutar ?></div>
                                    <span class="h3 mb-0 font-weight-bold text-primary">₺</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    
                    <div class="card-body">
                        <div class="row">
                            <?php if ($siparis->siparis_durum == 1 || $siparis->siparis_durum == 2) { ?>
                                <?php if ($siparis->urun_turu == 1) { ?>
                                    <?php if ($siparis->urun_marka) { ?>
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label class="form-label">Ürün Markası</label>
                                                <input class="form-control" type="text" placeholder="Ürün Markası"
                                                       value="<?= $siparis->urun_marka ?>" disabled>
                                            </div>
                                        </div>
                                    <?php } ?>
                                <?php } elseif ($siparis->urun_turu == 2) { ?>
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label class="form-label">Sanal Ürün Bilgisi</label>
                                            <textarea class="form-control" type="text" placeholder="Sanal Ürün Bilgisi"
                                                      disabled><?= $siparis->urun_sanal_bilgi ?></textarea>
                                        </div>
                                    </div>
                                <?php } elseif ($siparis->urun_turu == 3) { ?>
                                    <?php if ($siparis->urun_indir) {
                                        $dosya = explode('/', $siparis->urun_indir); ?>
                                        <div class="col-md-12 mb-3">
                                            <label class="input-label">Varsayılan Dosya</label>
                                            <div class="card">
                                                <div class="card-body d-flex justify-content-between align-items-center text-center">
                                                    <div class="d-flex flex-column">
                                                        <span class="badge badge-secondary mb-1">Dosya Adı : <i
                                                                    class="fe fe-file"></i> <?= $dosya[3] ?></span>
                                                        <span class="badge badge-secondary">Dosya Boyutu : <?= filesize_formatted($siparis->urun_indir) ?></span>
                                                    </div>
                                                    <div>
                                                        <a class="badge badge-primary"
                                                           href="<?= base_url('dosya-indir/' . $siparis->urun_uniq) ?>"><i
                                                                    class="fe fe-download"></i> İndir</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php } ?>
                                <?php } ?>
                            <?php } ?>
                            <?php if ($siparis->siparis_durum == 3) { ?>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="form-label">Sipariş İptal</label>
                                        <textarea class="form-control" type="text" placeholder="Sipariş İptal"
                                                  disabled><?= $siparis->siparis_iptal ?></textarea>
                                    </div>
                                </div>
                            <?php } ?>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label">Sipariş No</label>
                                    <input class="form-control" type="text" placeholder="Sipariş No"
                                           value="<?= $siparis->siparis_no ?>" disabled>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label">Sipariş Tarihi</label>
                                    <input class="form-control" type="text" placeholder="Sipariş Tarihi"
                                           value="<?= date('d.m.Y H:m', strtotime($siparis->siparis_tarih)) ?>"
                                           disabled>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label">Ad</label>
                                    <input class="form-control" type="text" placeholder="Ad"
                                           value="<?= $siparis->siparis_ad ?>" disabled>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label">Soyad</label>
                                    <input class="form-control" type="text" placeholder="Soyad"
                                           value="<?= $siparis->siparis_soyad ?>" disabled>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label class="form-label">Telefon</label>
                                    <input class="form-control" type="text" placeholder="Telefon"
                                           value="<?= $siparis->siparis_tel ?>" disabled>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label class="form-label">Şehir</label>
                                    <input class="form-control" type="text" placeholder="Şehir"
                                           value="<?= sehir_ad($siparis->siparis_il) ?>" disabled>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label class="form-label">İlçe</label>
                                    <input class="form-control" type="text" placeholder="İlçe"
                                           value="<?= ilce_ad($siparis->siparis_ilce) ?>" disabled>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label class="form-label">Posta Kodu</label>
                                    <input class="form-control" type="text" placeholder="Posta Kodu"
                                           value="<?= $siparis->siparis_posta ?>" disabled>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label class="form-label">Adres</label>
                                    <textarea class="form-control" type="text" placeholder="Adres"
                                              disabled><?= $siparis->siparis_adres ?></textarea>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>