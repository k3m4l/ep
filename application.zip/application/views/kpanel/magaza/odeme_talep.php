<section class="col-lg-8 control-panel">
    <div class="account-area">

        <div class="pb-5 py-md-5">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-md-4 col-12">
                        <div class="user-img-left-area">
                            <img src="<?= base_url($kullanici->kullanici_resim) ?>" alt=""/>
                            <div>
                                <?= $kullanici->kullanici_ad ?>
                            </div>
                        </div>
                        <?php $this->load->view('kpanel/inc/menu'); ?>
                    </div>
                    <div class="col-lg-9 col-md-8 col-12">
                        
                        <div class="card mb-5">
                            
                            <div class="card-header">
                                <h3 class="mb-0">Para Çekme Talebi</h3>
                                <p class="mb-0">
                                    Kesinleşmiş ödemelerinizi çekme talebinde bulunabilirsiniz
                                </p>
                            </div>
                            <div class="card-body">
                                <div class="col-12 page-header">
                                    <h3 class="page-title">Lütfen çekim yapmak istediğiniz hesap türünü seçin.</h3>
                                </div>
                                <script>
                                    $(document).ready(function () {
                                        $('.cekimTipiSecimi li').click(function () {
                                            var tabId = $(this).attr('id');
                                            $('.cekimTipiSecimi li').removeClass('active');
                                            $(this).addClass('active');
                                            $('.odeme-section .content').addClass('d-none');
                                            $('#banks-names').val(tabId);
                                            $('#' + tabId + '-content').removeClass('d-none');
                                        });
                                    });
                                </script>
                                <style>
                                    ul.cekimTipiSecimi {
                                        margin: 0;
                                        padding: 0;
                                        list-style: none;
                                        margin-top: 10px;
                                    }

                                    ul.cekimTipiSecimi li.active, ul.cekimTipiSecimi li:hover {
                                        border-bottom: 3px solid rgb(141 174 255);
                                        background: rgb(57 73 112);
                                    }

                                    ul.cekimTipiSecimi li {
                                        float: left;
                                        width: 140px;
                                        height: 50px;
                                        padding: 0 15px;
                                        background: rgb(49 61 90);
                                        margin-right: 10px;
                                        text-align: center;
                                        cursor: pointer;
                                        border-radius: 3px;
                                    }

                                    ul.cekimTipiSecimi li img {
                                        width: 80px;
                                        height: 50px;
                                        padding: 10px;
                                        object-fit: contain;
                                    }

                                    [data-inverted][data-position~=top][data-tooltip]:before {
                                        background: #1b1c1d;
                                    }

                                    [data-position~=top][data-tooltip]:before {
                                        background: #fff;
                                    }

                                    [data-position="top center"][data-tooltip]:before {
                                        top: auto;
                                        right: auto;
                                        bottom: 100%;
                                        left: 50%;
                                        background: #fff;
                                        margin-left: -0.07142857rem;
                                        margin-bottom: 0.14285714rem;
                                    }
                                </style>
                                <?php $yontemler = $this->magaza_model->get_para_cekme_yontemler() ?>
                                <div class="row mt-6">
                                    <div class="col-md-12 mb-5">
                                        <ul class="cekimTipiSecimi">
                                            <?php foreach (!empty($yontemler) ? $yontemler : [] as $key => $val) { ?>
                                            <li data-tab="banka-cekim" id="<?php echo $val->row_div_id ?>" class="<?php echo $key == 0 ? 'active' : '' ?>" data-inverted=""
                                                data-tooltip="<?php echo $val->row_title ?>" data-position="top center"><img
                                                    src="<?php echo base_url($val->row_image) ?>"></li>
                                            <?php } ?>
                                        </ul>
                                    </div>
                                    <div class="col-xl-4 col-lg-4 col-md-8 col-8 mb-3 mb-lg-0">
                                        <div class="text-center">
                                            <!-- PayOut chart -->
                                            <div id="payoutChart" class="apex-charts"></div>
                                            <h4 class="mb-1">Çekilebilir Kazanç</h4>
                                            <h5 class="mb-0 display-4 font-weight-bold"><?= $odenebilir_kazanclar ?>
                                                ₺</h5>
                                            <form action="<?= base_url('para-cek') ?>" method="post">
                                                <input type="hidden" id="banks-names" value="banka" name="bankname">
                                                <button class="btn btn-success btn-block rounded-pill mt-5"
                                                        type="submit">
                                                    Para Çekme Talebi Oluştur
                                                </button>
                                            </form>
                                        </div>
                                    </div>
                                    <div class="col-xl-8 col-lg-8 col-md-12 col-12">
                                        <div class="odeme-section">
                                            <div class="content border p-4 rounded-lg mb-3 d-none" id="ininal-content">
                                                <div class="custom-control custom-radio">
                                                    <form class="form-row" action="<?= base_url('ininal-bilgi') ?>"
                                                          method="post">
                                                        <!-- First name -->
                                                        <div class="form-group col-md-12">
                                                            <label class="form-label">Ininal No</label>
                                                            <input type="text" name="iban" class="form-control"
                                                                   placeholder="Ininal No"
                                                                   value="<?= $kullanici->ininal_no ?>">
                                                        </div>
                                                        <!-- Last name -->
                                                        <div class="form-group col-md-12">
                                                            <label class="form-label">Alıcı Adı Soyadı</label>
                                                            <input type="text" name="alici" class="form-control"
                                                                   placeholder="Alıcı Adı Soyadı"
                                                                   value="<?= $kullanici->alici_ininal ?>">
                                                        </div>
                                                        <!-- Phone -->
                                                        <div class="form-group col-md-12">
                                                            <label class="form-label">Alıcı Telefon Numarası</label>
                                                            <input type="number" name="telefon" class="form-control"
                                                                   placeholder="Alıcı Telefon Numarası"
                                                                   value="<?= $kullanici->tel_ininal ?>">
                                                        </div>
                                                        <div class="col-12">
                                                            <!-- Button -->
                                                            <button class="btn btn-primary rounded-pill" type="submit">
                                                                Bilgilerimi Güncelle
                                                            </button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                            <div class="content border p-4 rounded-lg mb-3 d-none" id="papara-content">
                                                <div class="custom-control custom-radio">
                                                    <form class="form-row" action="<?= base_url('papara-bilgi') ?>"
                                                          method="post">
                                                        <!-- First name -->
                                                        <div class="form-group col-md-12">
                                                            <label class="form-label">Papara No</label>
                                                            <input type="text" name="iban" class="form-control"
                                                                   placeholder="Papara No"
                                                                   value="<?= $kullanici->papara_no ?>">
                                                        </div>
                                                        <!-- Last name -->
                                                        <div class="form-group col-md-12">
                                                            <label class="form-label">Alıcı Adı Soyadı</label>
                                                            <input type="text" name="alici" class="form-control"
                                                                   placeholder="Alıcı Adı Soyadı"
                                                                   value="<?= $kullanici->alici_papara ?>">
                                                        </div>
                                                        <!-- Phone -->
                                                        <div class="form-group col-md-12">
                                                            <label class="form-label">Alıcı Telefon Numarası</label>
                                                            <input type="number" name="telefon" class="form-control"
                                                                   placeholder="Alıcı Telefon Numarası"
                                                                   value="<?= $kullanici->tel_papara ?>">
                                                        </div>
                                                        <div class="col-12">
                                                            <!-- Button -->
                                                            <button class="btn btn-primary rounded-pill" type="submit">
                                                                Bilgilerimi Güncelle
                                                            </button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                            <div class="content border p-4 rounded-lg mb-3 content" id="banka-content">
                                                <div class="custom-control custom-radio">
                                                    <form class="form-row" action="<?= base_url('iban-bilgi') ?>"
                                                          method="post">
                                                        <!-- First name -->
                                                        <div class="form-group col-md-12">
                                                            <label class="form-label">IBAN No</label>
                                                            <input type="text" name="iban" class="form-control"
                                                                   placeholder="IBAN No"
                                                                   value="<?= $kullanici->kullanici_iban ?>">
                                                        </div>
                                                        <!-- Last name -->
                                                        <div class="form-group col-md-12">
                                                            <label class="form-label">Alıcı Adı Soyadı</label>
                                                            <input type="text" name="alici" class="form-control"
                                                                   placeholder="Alıcı Adı Soyadı"
                                                                   value="<?= $kullanici->kullanici_alici ?>">
                                                        </div>
                                                        <!-- Phone -->
                                                        <div class="form-group col-md-12">
                                                            <label class="form-label">Alıcı Telefon Numarası</label>
                                                            <input type="number" name="telefon" class="form-control"
                                                                   placeholder="Alıcı Telefon Numarası"
                                                                   value="<?= $kullanici->kullanici_alici_tel ?>">
                                                        </div>
                                                        <div class="col-12">
                                                            <!-- Button -->
                                                            <button class="btn btn-primary rounded-pill" type="submit">
                                                                Bilgilerimi Güncelle
                                                            </button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- Check box -->

                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="card mb-4">
                            
                            <div class="card-header border-bottom-0">
                                <h3 class="h4 mb-3">Ödeme Taleplerim</h3>
                            </div>
                            
                            <div class="table-responsive border-0">
                                <table class="table mb-0 text-nowrap">
                                    <thead>
                                    <tr>
                                        <th class="border-0">Talep No</th>
                                        <th class="border-0">Ödeme Yolu</th>
                                        <th class="border-0">Durum</th>
                                        <th class="border-0">Çekilen Tutar</th>
                                        <th class="border-0">Tarih</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php if ($odeme_taleplerim) {
                                        foreach ($odeme_taleplerim as $talep) { ?>
                                            <tr>
                                                <td class="align-middle border-top-0">#<?= $talep->paracek_no ?></td>
                                                <td class="align-middle border-top-0">Banka EFT</td>
                                                <td class="align-middle border-top-0">
                                                    <?php if ($talep->paracek_durum == 0) { ?>
                                                        <span
                                                            class="badge badge-warning badge-pill">Onay Bekliyor</span>
                                                    <?php } elseif ($talep->paracek_durum == 1) { ?>
                                                        <span class="badge badge-success badge-pill">Onaylandı</span>
                                                    <?php } elseif ($talep->paracek_durum == 2) { ?>
                                                        <span class="badge badge-danger badge-pill">Onaylanmadı</span>
                                                    <?php } ?>
                                                </td>
                                                <td class="align-middle border-top-0"><?= $talep->paracek_tutar ?>₺</td>
                                                <td class="align-middle border-top-0"><?= date('d.m.Y H:i', strtotime($talep->paracek_tarih)) ?></td>
                                            </tr>
                                        <?php }
                                    } ?>
                                    </tbody>
                                </table>
                                <div class="pt-4 pb-4 border-top">
                                    <?= $links ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>