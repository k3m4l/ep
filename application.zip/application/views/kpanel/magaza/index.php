<?php $this->load->view('kpanel/inc/magaza_nav', array('magaza' => $magaza)); ?>
<section class="col-lg-8 account-billing-cart-area">
    <div class="billing">

        <div class="row <?php if ($magaza->magaza_durum != 1) {
            echo ' filter-blur-10 ';
        } ?>">
            <div class="col-md-4">
                <div class="bg-info rounded overflow-hidden">
                    <div class="pd-x-20 pd-t-20 d-flex align-items-center">
                        <i class="fas fa-star tx-60 lh-0 tx-white op-7"></i>
                        <div class="mg-l-20">
                            <p class="tx-15 tx-spacing-1 tx-mont tx-semibold tx-uppercase tx-white-8 mg-b-10">Mağaza Puanı</p>
                            <p class="tx-24 tx-white tx-lato tx-bold mg-b-0 lh-1"><?= $toplam_yorum_ortalamasi; ?></p>
                        </div>
                    </div>
                    <div id="ch1" class="ht-50 tr-y-1 rickshaw_graph">
                        <img src="<?php echo base_url('assets/images/cart_img.svg') ?>" alt="">
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="bg-purple rounded overflow-hidden">
                    <div class="pd-x-20 pd-t-20 d-flex align-items-center">
                        <i class="fas fa-store tx-60 lh-0 tx-white op-7"></i>
                        <div class="mg-l-20">
                            <p class="tx-15 tx-spacing-1 tx-mont tx-semibold tx-uppercase tx-white-8 mg-b-10">Aylık Toplam Sipariş</p>
                            <p class="tx-24 tx-white tx-lato tx-bold mg-b-0 lh-1"><?= $aylik_siparis_adet ?></p>
                        </div>
                    </div>
                    <div id="ch1" class="ht-50 tr-y-1 rickshaw_graph">
                        <img src="<?php echo base_url('assets/images/cart_img.svg') ?>" alt="">
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="bg-warning rounded overflow-hidden">
                    <div class="pd-x-20 pd-t-20 d-flex align-items-center">
                        <i class="fas fa-coins tx-60 lh-0 tx-white op-7"></i>
                        <div class="mg-l-20">
                            <p class="tx-15 tx-spacing-1 tx-mont tx-semibold tx-uppercase tx-white-8 mg-b-10">Aylık Kazanç</p>
                            <p class="tx-24 tx-white tx-lato tx-bold mg-b-0 lh-1"><?= $aylik_kazanc ?> ₺</p>
                        </div>
                    </div>
                    <div id="ch1" class="ht-50 tr-y-1 rickshaw_graph">
                        <img src="<?php echo base_url('assets/images/cart_img.svg') ?>" alt="">
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="col-lg-8 control-panel">

    <div class="account-area">
        <div class="container m-0">
            <div class="row">
                <div class="col-lg-3 col-md-4 col-12 p-0">
                    <div class="user-img-left-area">
                        <img src="<?= base_url($kullanici->kullanici_resim) ?>" alt=""/>
                        <div>
                            <?= $kullanici->kullanici_ad ?>
                        </div>
                    </div>
                    
                    <?php $this->load->view('kpanel/inc/menu'); ?>
                </div>
                <div class="col-lg-9 col-md-8 col-12">
                    <?php if ($magaza->magaza_durum != 1) { ?>
                        <div class="overblur d-flex justify-content-center">
                            <div class="align-self-center text-center">
                                <span style="font-size: 27px;font-weight: 900;">MAĞAZANIZ AKTİF DEĞİL </span>
                                <p>Mağazanız aktif olduğunda mağaza paneli bölümünü görebileceksiniz.</p>
                            </div>

                        </div>
                    <?php } ?>
                </div>
            </div>
        </div>
    </div>
</section>