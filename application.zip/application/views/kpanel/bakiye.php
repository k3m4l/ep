<style>

</style>
<script>
    $(document).ready(function () {
        // İlk sekme ve içeriği aktif hale getirme
        // Sekme tıklama olayı
        $('.PaymentTypes li').click(function () {
            var tabId = $(this).attr('id');

            // Aktif sekmeleri değiştirme
            $('.PaymentTypes li').removeClass('active');
            $(this).addClass('active');
            $('#intro').addClass("d-none");
            // Tüm içerikleri gizleme
            $('.tab-content .content').addClass('d-none');

            // İlgili içeriği gösterme
            $('#' + tabId + '-content').removeClass('d-none');
        });
    });
</script>
<img src="<?php echo base_url('assets/images/donut-image.png') ?>" alt="" class="balance-bcg-2">
<img src="<?php echo base_url('assets/images/donut-image.png') ?>" alt="" class="balance-bcg-3">

<img src="<?php echo base_url('assets/images/gradient-bg.png') ?>" alt="" class="balance-bcg">
<section class="col-12 control-panel">
    <div class="pb-5 py-md-5">
        <div class="container">
            <div class="row">
                <div class="col-md-5 col-lg-3" style="border-right: 1px solid #283044;">
                    <!-- <h4 class="title mb-5">Bakiye Yükleyin</h4> -->
                    <ul class="nav nav-pills balance-tab mb-3" id="pills-tab" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active" id="pills-home-tab" data-bs-toggle="pill"
                                    data-bs-target="#payment-1" type="button" role="tab" aria-controls="payment-1"
                                    aria-selected="true"><i class="fas fa-bars"></i></button>
                            <div class="title-filter-tab-link">Tüm Ödeme Yöntemleri</div>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="pills-profile-tab" data-bs-toggle="pill"
                                    data-bs-target="#payment-2" type="button" role="tab"
                                    aria-controls="payment-2" aria-selected="false"><i
                                    class="far fa-credit-card"></i></button>
                            <div class="title-filter-tab-link">Kradi Kartı</div>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="pills-contact-tab" data-bs-toggle="pill"
                                    data-bs-target="#payment-3" type="button" role="tab"
                                    aria-controls="payment-3" aria-selected="false"><i
                                    class="fas fa-globe-americas"></i></button>
                            <div class="title-filter-tab-link">Yurt Dışı Kredi veya Banka</div>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="pills-contact-tab" data-bs-toggle="pill"
                                    data-bs-target="#payment-4" type="button" role="tab"
                                    aria-controls="payment-4" aria-selected="false"><i
                                    class="fas fa-university"></i></button>
                            <div class="title-filter-tab-link">Banka ve Havale</div>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="pills-contact-tab" data-bs-toggle="pill"
                                    data-bs-target="#payment-5" type="button" role="tab"
                                    aria-controls="payment-5" aria-selected="false"><i class="fas fa-wallet"></i>
                            </button>
                            <div class="title-filter-tab-link">Cüzdan ve Hediye</div>
                        </li>
                    </ul>
                    <div class="tab-content" id="pills-tabContent">
                        <div class="tab-pane fade show active" id="payment-1" role="tabpanel"
                             aria-labelledby="pills-home-tab">
                            <ul class="PaymentTypes" id="paymentTypes">
                                <?php if ($ayarlar->paytr_durum == '1'): ?>
                                    <li id="paytr">
                                        <tip>Kredi</tip>
                                        <div class="paymentImage">
                                            <img src="<?php echo base_url('assets/images/stripe.png') ?>">
                                        </div>
                                        <b>Kredi Kartı & Banka Kartı (PayTR)</b>
                                        <span class="badge badge-info  font-weight-bold">Anında Onay</span>
                                        <span
                                            class="badge badge-warning font-weight-bold"><?= $ayarlar->paytr_komisyon ?>% Komisyon</span>
                                    </li>
                                <?php endif; ?>
                                <?php if ($ayarlar->iyzico_durum == '1'): ?>
                                    <li id="iyzico">
                                        <tip>Kredi</tip>
                                        <div class="paymentImage">
                                            <img src="<?php echo base_url('assets/images/stripe.png') ?>">
                                        </div>
                                        <b>Kredi Kartı & Banka Kartı (Iyzico)</b>
                                        <span class="badge badge-info  font-weight-bold">Anında Onay</span>
                                        <span
                                            class="badge badge-warning font-weight-bold"><?= $ayarlar->iyzico_komisyon ?>% Komisyon</span>
                                    </li>
                                <?php endif; ?>
                                <?php if ($ayarlar->weepay_durum == '1'): ?>
                                    <li id="weepay">
                                        <tip>Kredi</tip>
                                        <div class="paymentImage">
                                            <img src="<?php echo base_url('assets/images/unnamed.png') ?>">
                                        </div>
                                        <b>Kredi Kartı & Banka Kartı (Weepay)</b>
                                        <span class="badge badge-info  font-weight-bold">Anında Onay</span>
                                        <span
                                            class="badge badge-warning font-weight-bold"><?= $ayarlar->weepay_komisyon ?>% Komisyon</span>
                                    </li>
                                <?php endif; ?>
                                <?php if ($ayarlar->stripe_durum == '1'): ?>
                                    <li id="stripe">
                                        <tip>Kredi</tip>
                                        <div class="paymentImage">
                                            <img src="<?php echo base_url('assets/images/stripe.png') ?>">
                                        </div>
                                        <b>Kredi Kartı & Banka Kartı (Stripe)</b>
                                        <span class="badge badge-info  font-weight-bold">Anında Onay</span>
                                        <span
                                            class="badge badge-warning font-weight-bold"><?= $ayarlar->stripe_komisyon ?> TL Komisyon</span>
                                    </li>
                                <?php endif; ?>
                                <?php if ($ayarlar->vallet_durum == '1'): ?>
                                    <li id="vallet">
                                        <tip>Kredi</tip>
                                        <div class="paymentImage">
                                            <img src="<?php echo base_url('assets/images/vallet.png') ?>">
                                        </div>
                                        <b>Kredi Kartı & Banka Kartı (Vallet)</b>
                                        <span class="badge badge-info  font-weight-bold">Anında Onay</span>
                                        <span
                                            class="badge badge-warning font-weight-bold"><?= $ayarlar->vallet_komisyon ?>% Komisyon</span>
                                    </li>
                                <?php endif; ?>
                                <?php
                                $bankalar = bankalar(['status' => 1]);
                                if ($bankalar) { ?>
                                    <li id="banks">
                                        <tip>Havale/EFT</tip>
                                        <div class="paymentImage">
                                            <img
                                                src="<?php echo base_url('assets/images/atm.png') ?>">
                                        </div>
                                        <b>Havale/EFT</b>
                                        <span class="badge badge-info  font-weight-bold">Süreli Onay</span>
                                        <span
                                            class="badge badge-warning font-weight-bold"><?= $ayarlar->havale_komisyon ?>% Komisyon</span>
                                    </li>
                                    <?php
                                }
                                ?>
                                <li id="gift">
                                    <tip>Kredi</tip>
                                    <div class="paymentImage">
                                        <img src="<?php echo base_url('assets/images/2438193.svg') ?>">
                                    </div>
                                    <b>Bakiye Kuponu</b>
                                    <span class="badge badge-info  font-weight-bold">Komisyonsuz</span>
                                </li>
                                <!--<li id="papara">
                                    <tip>Papara</tip>
                                    <div class="paymentImage">
                                        <img src="https://cdn.itempazar.com/global/icons/payments/papara.svg">
                                    </div>
                                    <b>Papara Ödeme</b>
                                    <span class="badge badge-warning  font-weight-bold">%1.9 Komisyon</span>
                                </li>
                                <li id="gpay">
                                    <tip>G-Pay</tip>
                                    <div class="paymentImage">
                                        <img src="https://cdn.itempazar.com/global/icons/credit-card.svg">
                                    </div>
                                    <b>G-Pay Kredi Kartı & Banka Kartı</b>
                                    <span class="badge badge-danger  font-weight-bold">%1.xx Komisyon</span>
                                </li>-->
                            </ul>
                        </div>
                        <div class="tab-pane fade" id="payment-2" role="tabpanel"
                             aria-labelledby="pills-profile-tab">

                            <ul class="PaymentTypes" id="paymentTypes">
                                <?php if ($ayarlar->paytr_durum == '1'): ?>
                                    <li id="paytr">
                                        <tip>Kredi</tip>
                                        <div class="paymentImage">
                                            <img src="<?php echo base_url('assets/images/stripe.png') ?>">
                                        </div>
                                        <b>Kredi Kartı & Banka Kartı (PayTR)</b>
                                        <span class="badge badge-info  font-weight-bold">Anında Onay</span>
                                        <span
                                            class="badge badge-warning font-weight-bold"><?= $ayarlar->paytr_komisyon ?>% Komisyon</span>
                                    </li>
                                <?php endif; ?>
                                <?php if ($ayarlar->iyzico_durum == '1'): ?>
                                    <li id="iyzico">
                                        <tip>Kredi</tip>
                                        <div class="paymentImage">
                                            <img src="<?php echo base_url('assets/images/stripe.png') ?>">
                                        </div>
                                        <b>Kredi Kartı & Banka Kartı (Iyzico)</b>
                                        <span class="badge badge-info  font-weight-bold">Anında Onay</span>
                                        <span
                                            class="badge badge-warning font-weight-bold"><?= $ayarlar->iyzico_komisyon ?>% Komisyon</span>
                                    </li>
                                <?php endif; ?>
                                <?php if ($ayarlar->weepay_durum == '1'): ?>
                                    <li id="weepay">
                                        <tip>Kredi</tip>
                                        <div class="paymentImage">
                                            <img src="<?php echo base_url('assets/images/unnamed.png') ?>">
                                        </div>
                                        <b>Kredi Kartı & Banka Kartı (Weepay)</b>
                                        <span class="badge badge-info  font-weight-bold">Anında Onay</span>
                                        <span
                                            class="badge badge-warning font-weight-bold"><?= $ayarlar->weepay_komisyon ?>% Komisyon</span>
                                    </li>
                                <?php endif; ?>
                                <?php if ($ayarlar->stripe_durum == '1'): ?>
                                    <li id="stripe">
                                        <tip>Kredi</tip>
                                        <div class="paymentImage">
                                            <img src="<?php echo base_url('assets/images/stripe.png') ?>">
                                        </div>
                                        <b>Kredi Kartı & Banka Kartı (Stripe)</b>
                                        <span class="badge badge-info  font-weight-bold">Anında Onay</span>
                                        <span
                                            class="badge badge-warning font-weight-bold"><?= $ayarlar->stripe_komisyon ?> TL Komisyon</span>
                                    </li>
                                <?php endif; ?>
                                <?php if ($ayarlar->vallet_durum == '1'): ?>
                                    <li id="vallet">
                                        <tip>Kredi</tip>
                                        <div class="paymentImage">
                                            <img src="<?php echo base_url('assets/images/vallet.png') ?>">
                                        </div>
                                        <b>Kredi Kartı & Banka Kartı (Vallet)</b>
                                        <span class="badge badge-info  font-weight-bold">Anında Onay</span>
                                        <span
                                            class="badge badge-warning font-weight-bold"><?= $ayarlar->vallet_komisyon ?>% Komisyon</span>
                                    </li>
                                <?php endif; ?>

                                <!--<li id="papara">
                                    <tip>Papara</tip>
                                    <div class="paymentImage">
                                        <img src="https://cdn.itempazar.com/global/icons/payments/papara.svg">
                                    </div>
                                    <b>Papara Ödeme</b>
                                    <span class="badge badge-warning  font-weight-bold">%1.9 Komisyon</span>
                                </li>
                                <li id="gpay">
                                    <tip>G-Pay</tip>
                                    <div class="paymentImage">
                                        <img src="https://cdn.itempazar.com/global/icons/credit-card.svg">
                                    </div>
                                    <b>G-Pay Kredi Kartı & Banka Kartı</b>
                                    <span class="badge badge-danger  font-weight-bold">%1.xx Komisyon</span>
                                </li>-->
                            </ul>
                        </div>
                        <div class="tab-pane fade" id="payment-3" role="tabpanel"
                             aria-labelledby="pills-contact-tab">

                            <ul class="PaymentTypes" id="paymentTypes">
                                <?php if ($ayarlar->stripe_durum == '1'): ?>
                                    <li id="stripe">
                                        <tip>Kredi</tip>
                                        <div class="paymentImage">
                                            <img src="<?php echo base_url('assets/images/stripe.png') ?>">
                                        </div>
                                        <b>Kredi Kartı & Banka Kartı (Stripe)</b>
                                        <span class="badge badge-info  font-weight-bold">Anında Onay</span>
                                        <span
                                            class="badge badge-warning font-weight-bold"><?= $ayarlar->stripe_komisyon ?> TL Komisyon</span>
                                    </li>
                                <?php endif; ?>
                                <!--<li id="papara">
                                    <tip>Papara</tip>
                                    <div class="paymentImage">
                                        <img src="https://cdn.itempazar.com/global/icons/payments/papara.svg">
                                    </div>
                                    <b>Papara Ödeme</b>
                                    <span class="badge badge-warning  font-weight-bold">%1.9 Komisyon</span>
                                </li>
                                <li id="gpay">
                                    <tip>G-Pay</tip>
                                    <div class="paymentImage">
                                        <img src="https://cdn.itempazar.com/global/icons/credit-card.svg">
                                    </div>
                                    <b>G-Pay Kredi Kartı & Banka Kartı</b>
                                    <span class="badge badge-danger  font-weight-bold">%1.xx Komisyon</span>
                                </li>-->
                            </ul>
                        </div>
                        <div class="tab-pane fade" id="payment-4" role="tabpanel"
                             aria-labelledby="pills-contact-tab">

                            <ul class="PaymentTypes" id="paymentTypes">
                                <?php
                                $bankalar = bankalar(['status' => 1]);
                                if ($bankalar) { ?>
                                    <li id="banks">
                                        <tip>Havale/EFT</tip>
                                        <div class="paymentImage">
                                            <img
                                                src="<?php echo base_url('assets/images/atm.png') ?>">
                                        </div>
                                        <b>Havale/EFT</b>
                                        <span class="badge badge-info  font-weight-bold">Süreli Onay</span>
                                        <span
                                            class="badge badge-warning font-weight-bold"><?= $ayarlar->havale_komisyon ?>% Komisyon</span>
                                    </li>
                                    <?php
                                }
                                ?>
                                <!--<li id="papara">
                                    <tip>Papara</tip>
                                    <div class="paymentImage">
                                        <img src="https://cdn.itempazar.com/global/icons/payments/papara.svg">
                                    </div>
                                    <b>Papara Ödeme</b>
                                    <span class="badge badge-warning  font-weight-bold">%1.9 Komisyon</span>
                                </li>
                                <li id="gpay">
                                    <tip>G-Pay</tip>
                                    <div class="paymentImage">
                                        <img src="https://cdn.itempazar.com/global/icons/credit-card.svg">
                                    </div>
                                    <b>G-Pay Kredi Kartı & Banka Kartı</b>
                                    <span class="badge badge-danger  font-weight-bold">%1.xx Komisyon</span>
                                </li>-->
                            </ul>
                        </div>
                        <div class="tab-pane fade" id="payment-5" role="tabpanel"
                             aria-labelledby="pills-contact-tab">
                            <ul class="PaymentTypes" id="paymentTypes">
                                <li id="gift">
                                    <tip>Kredi</tip>
                                    <div class="paymentImage">
                                        <img src="<?php echo base_url('assets/images/2438193.svg') ?>">
                                    </div>
                                    <b>Bakiye Kuponu</b>
                                    <span class="badge badge-info  font-weight-bold">Komisyonsuz</span>
                                </li>
                                <!--<li id="papara">
                                    <tip>Papara</tip>
                                    <div class="paymentImage">
                                        <img src="https://cdn.itempazar.com/global/icons/payments/papara.svg">
                                    </div>
                                    <b>Papara Ödeme</b>
                                    <span class="badge badge-warning  font-weight-bold">%1.9 Komisyon</span>
                                </li>
                                <li id="gpay">
                                    <tip>G-Pay</tip>
                                    <div class="paymentImage">
                                        <img src="https://cdn.itempazar.com/global/icons/credit-card.svg">
                                    </div>
                                    <b>G-Pay Kredi Kartı & Banka Kartı</b>
                                    <span class="badge badge-danger  font-weight-bold">%1.xx Komisyon</span>
                                </li>-->
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-7 col-lg-9 ">
                    <div id="intro">
                        <div class="text-center">
                            <div>
                                <img src="https://cdn.itempazar.com/global/illustrations/undraw_wallet_aym5.svg"
                                     width="180">
                                <h3 class="c-custom" style="margin-bottom: 0px">Bakiye Yükleme Merkezi</h3>
                                <span>Sol menüde bulunan ödeme yöntemlerinden size en uygun olanı seçin ve hesabınıza anında bakiye yükleyin.<br> Yaptığınız işlemler ödeme sağlayıcılarımız tarafından 7/24 kontrol edilip onaylanmaktadır.</span>
                            </div>
                        </div>
                    </div>
                    <div class="tab-content">
                        <div id="paytr-content" class="content d-none">
                            <h3 class="c-custom">PayTR - Kredi / Banka Kartı ile ödeme</h3>
                            <p>Kredi veya banka kartınız ile yapacağınız ödemelerin tümü 3D güvenliği ile
                                gerçekleştirilmektedir.</p>
                            <div class="col-md-8 col-md-offset-2 odeme-paneli">
                                <?php if ($ayarlar->paytr_durum == '1'): ?>
                                    <form action="<?= base_url('bakiye-yukle') ?>" method="POST">
                                        <div class="align-items-center">
                                            <input type="hidden" id="komisyon_oran"
                                                   value="<?= $ayarlar->paytr_komisyon ?>">
                                            <div class="form-group">
                                                <label>Yüklemek istediğiniz tutar</label>
                                                <input type="text" name="tutar" id="tutar" class="form-control"
                                                       inputmode="text">
                                            </div>
                                            <div class="form-group">
                                                <label>Ödenecek Tutar</label>
                                                <div class="form-control" id="odenecek_tutar"></div>
                                            </div>
                                            <button class="btn btn-primary" type="submit" name="odeme" value="paytr">
                                                Ödeme Yap
                                            </button>
                                        </div>

                                    </form>
                                <?php else: ?>
                                    <div class="alert alert-danger">
                                        PayTR Bulunamadı
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div style="clear:both;"></div>
                        </div>
                        <div id="weepay-content" class="content d-none">
                            <h3 class="c-custom">WeePay - Kredi / Banka Kartı ile ödeme</h3>
                            <p>Kredi veya banka kartınız ile yapacağınız ödemelerin tümü 3D güvenliği ile
                                gerçekleştirilmektedir.</p>
                            <div class="col-md-8 col-md-offset-2 odeme-paneli">
                                <?php if ($ayarlar->weepay_durum == '1'): ?>
                                    <form action="<?= base_url('bakiye-yukle') ?>" method="POST">
                                        <div class="align-items-center">
                                            <input type="hidden" id="weepay_komisyon_oran"
                                                   value="<?= $ayarlar->weepay_komisyon ?>">
                                            <div class="form-group">
                                                <label>Yüklemek istediğiniz tutar</label>
                                                <input type="text" name="tutar" id="weepay_tutar" class="form-control"
                                                       inputmode="text">
                                            </div>
                                            <div class="form-group">
                                                <label>Ödenecek Tutar</label>
                                                <div class="form-control" id="weepay_odenecek_tutar"></div>
                                            </div>
                                            <button class="btn btn-primary" type="submit" name="odeme" value="weepay">
                                                Ödeme Yap
                                            </button>
                                        </div>

                                    </form>
                                <?php else: ?>
                                    <div class="alert alert-danger">
                                        WeePay Bulunamadı
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div style="clear:both;"></div>
                        </div>
                        <div id="vallet-content" class="content d-none">
                            <h3 class="c-custom">Vallet - Kredi / Banka Kartı ile ödeme</h3>
                            <p>Kredi veya banka kartınız ile yapacağınız ödemelerin tümü 3D güvenliği ile
                                gerçekleştirilmektedir.</p>
                            <div class="col-md-8 col-md-offset-2 odeme-paneli">
                                <?php if ($ayarlar->vallet_durum == '1'): ?>
                                    <form action="<?= base_url('bakiye-yukle') ?>" method="POST">
                                        <div class="align-items-center">
                                            <input type="hidden" id="vallet_komisyon_oran"
                                                   value="<?= $ayarlar->vallet_komisyon ?>">
                                            <div class="form-group">
                                                <label>Yüklemek istediğiniz tutar</label>
                                                <input type="text" name="tutar" id="vallet_tutar" class="form-control"
                                                       inputmode="text">
                                            </div>
                                            <div class="form-group">
                                                <label>Ödenecek Tutar</label>
                                                <div class="form-control" id="vallet_odenecek_tutar"></div>
                                            </div>
                                            <button class="btn btn-primary" type="submit" name="odeme" value="vallet">
                                                Ödeme Yap
                                            </button>
                                        </div>

                                    </form>
                                <?php else: ?>
                                    <div class="alert alert-danger">
                                        WeePay Bulunamadı
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div style="clear:both;"></div>
                        </div>
                        <div id="stripe-content" class="content d-none">
                            <h3 class="c-custom">Stripe - Kredi / Banka Kartı ile ödeme</h3>
                            <p>Kredi veya banka kartınız ile yapacağınız ödemelerin tümü 3D güvenliği ile
                                gerçekleştirilmektedir.</p>
                            <span class="badge badge-warning font-weight-bold" style="font-size:13px ">Minimum Yükleme Tutarı : <strong>100 TL</strong></span>
                            <span class="badge badge-warning font-weight-bold"
                                  style="font-size:13px ">İşlem Ücreti : <strong><?= $ayarlar->stripe_komisyon ?> TL</strong></span>
                            <div class="col-md-8 col-md-offset-2 odeme-paneli">
                                <?php if ($ayarlar->stripe_durum == '1'): ?>
                                    <form action="<?= base_url('bakiye-yukle') ?>" method="POST">
                                        <div class="align-items-center">
                                            <input type="hidden" id="stripe_komisyon_oran"
                                                   value="<?= $ayarlar->stripe_komisyon ?>">
                                            <div class="form-group">
                                                <label>Yüklemek istediğiniz tutar</label>
                                                <input type="text" name="tutar" id="stripe_tutar" class="form-control"
                                                       inputmode="text">
                                            </div>
                                            <div class="form-group">
                                                <label>Ödenecek Tutar</label>
                                                <div class="form-control" id="stripe_odenecek_tutar"></div>
                                            </div>
                                            <button class="btn btn-primary" type="submit" name="odeme" value="stripe">
                                                Ödeme Yap
                                            </button>
                                        </div>

                                    </form>
                                <?php else: ?>
                                    <div class="alert alert-danger">
                                        Stripe Bulunamadı
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div style="clear:both;"></div>
                        </div>
                        <div id="banks-content" class="content d-none">
                            <h3 class="c-custom">Havale / EFT ile ödeme</h3>
                            <p>Havale eft ile yapacağınız ödemeler için ödeme bildirimi oluşturmalısınız ve kontrol
                                sonrası onaylanacaktır.</p>
                            <?php if ($bankalar): ?>
                                <div class="row">
                                    <div class="col-12 text-center">
                                        <div class="bank-transfer">
                                            <?php foreach ($bankalar as $banka): ?>
                                                <div class="bank-img-area" data-id="<?php echo $banka->id ?>"
                                                     onclick="paymentInfoPanel()">
                                                    <img src="<?= base_url($banka->image); ?>" height="100"
                                                         width="auto">
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                    </div>
                                </div>
                            <?php else: ?>
                                <div class="alert alert-danger">
                                    Banka Bulunamadı
                                </div>
                            <?php endif; ?>
                            <div style="clear:both;"></div>
                        </div>
                        <div id="iyzico-content" class="content d-none">
                            <h3 class="c-custom">Iyzico - Kredi / Banka Kartı ile ödeme</h3>
                            <p>Kredi veya banka kartınız ile yapacağınız ödemelerin tümü 3D güvenliği ile
                                gerçekleştirilmektedir.</p>
                            <div class="col-md-8 col-md-offset-2 odeme-paneli">
                                <?php if ($ayarlar->iyzico_durum == '1'): ?>
                                    <form action="<?= base_url('bakiye-yukle') ?>" method="POST">
                                        <div class="align-items-center">
                                            <input type="hidden" id="iyzico_komisyon_oran"
                                                   value="<?= $ayarlar->iyzico_komisyon ?>">
                                            <div class="form-group">
                                                <label>Yüklemek istediğiniz tutar</label>
                                                <input type="text" name="tutar" id="iyzico_tutar" class="form-control"
                                                       inputmode="text">
                                            </div>
                                            <div class="form-group">
                                                <label>Ödenecek Tutar</label>
                                                <div class="form-control" id="iyzico_odenecek_tutar"></div>
                                            </div>
                                            <button class="btn btn-primary" type="submit" name="odeme" value="iyzico">
                                                Ödeme Yap
                                            </button>
                                        </div>

                                    </form>
                                <?php else: ?>
                                    <div class="alert alert-danger">
                                        Iyzico Bulunamadı
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div id="papara-content" class="content d-none">
                            <div class="col-lg-4">
                                <div class="alert alert-danger">
                                    null
                                </div>
                            </div>

                        </div>
                        <div id="gpay-content" class="content d-none">
                            <div class="col-lg-4">
                                <div class="alert alert-danger">
                                    null
                                </div>
                            </div>
                        </div>
                        <div id="gift-content" class="content d-none">
                            <h3 class="c-custom">Bakiye Kuponu Kullan</h3>
                            <p>Diğer kullanıcılar tarafından size hediye olarak gönderilen bakiye kuponlarını bu alanda
                                bozdurabilirsiniz. Unutmayın 24 saat içerisinde kullanılmayan bakiye kuponları iptal
                                olmaktadır.</p>
                            <br>
                            <form id="bakiyeKuponuForm" action="" method="POST" class="ui form">
                                <div class="field">
                                    <label class="light-text-black" style="font-size: 16px">Kupon Kodunuz</label>
                                    <input type="text" name="kod" placeholder="XXXXX-XXXXX-XXXXX-XXXXX">
                                </div>
                                <button class="ui button btn-block btn-primary kuponBozdur" type="submit">Kuponu Bozdur
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>



<div class="modal fade" id="teldogrula_step_1" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
     aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content sms">
            <div class="modal-header">
                <h4 class="modal-title text-center" id="exampleModalCenterTitle">Telefon Doğrulama</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="tel-dogrula-alert">
                <div class="alert alert-danger alert-dismissible text-left alert-grid" role="alert">
                    <i class="fas fa-check"></i>
                    <div><strong>Doğrulama Gerekiyor</strong><br>
                        Ödeme bildirimi oluşturabilmek için telefon numaranızı doğrulamanız gerekmektedir.
                    </div>
                </div>
            </div>
            <div class="p-2">
                <div class="row">
                    <div class="col-12">
                        <label class="form-label">Telefon No</label>
                        <input type="text" class="form-control" name="telefon" id="telefon" value="0" maxlength="11">
                    </div>
                </div>
                <div class="py-2">
                    <button type="button" class="btn btn-primary rounded-pill tel-dogrula-button w-100" data-id="<?php echo $kullanici->kullanici_id ?>">SMS Gönder</button>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="teldogrula" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
     aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content sms">
            <div class="modal-header">
                <h4 class="modal-title text-center" id="exampleModalCenterTitle">Telefon Doğrulama</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="tel-dogrula-alert">
                <div class="alert alert-success alert-dismissible text-left alert-grid" role="alert">
                    <i class="fas fa-check"></i>
                    <div><strong>Başarılı</strong><br>
                        Doğrulama Kodunuz Başarılı Şekilde Gönderilmiştir. Lütfen Aşağıda ki alana kodu giriniz.
                    </div>
                </div>
            </div>
            <style>
                #countdown {
                    display: none;
                    font-size: 15px;
                    margin-left: 5px;
                    margin-top: 7px;
                }
                .countdown-area {
                    display: flex;
                    margin-top: 5px;
                    margin-bottom: 10px;
                }
            </style>
            <form class="p-2 tel-dogrulama-form" method="post">
                <div class="row">
                    <div class="col-12">
                        <label class="form-label">Doğrulama Kodu</label>
                        <input type="text" class="form-control" name="tel_dogrulama">
                    </div>
                </div>
                <div class="py-2">
                    <div class="countdown-area">
                        <button id="sendSMS" type="button" data-id="<?php echo $kullanici->kullanici_id ?>" class="btn btn-warning rounded-pill">SMS Gönder</button>
                        <div id="countdown"></div>
                    </div>
                    <button type="submit" class="btn btn-primary rounded-pill soru-sor-btn w-100">Doğrula</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
        var countdownTimer;
        var countdownDuration = 60; // 60 saniye

        function startCountdown() {
            $("#sendSMS").prop("disabled", true);
            $("#countdown").show();

            countdownTimer = setInterval(function () {
                $("#countdown").text("Kalan süre: " + countdownDuration + " saniye");

                if (countdownDuration === 0) {
                    clearInterval(countdownTimer);
                    $("#sendSMS").prop("disabled", false);
                    $("#countdown").hide();
                } else {
                    countdownDuration--;
                }
            }, 1000);
        }

        function resetCountdown() {
            clearInterval(countdownTimer);
            countdownDuration = 60;
            $("#sendSMS").prop("disabled", true);
            startCountdown();
        }

        // Sayfa yüklendiğinde otomatik geri sayım başlat
        //startCountdown();

        $("#sendSMS").click(function () {
            // Eğer geri sayım başlamamışsa başlat
            if (countdownDuration === 60) {
                startCountdown();
                var user = $(this).data('id');
                $.ajax({
                    type: "POST",
                    url: base_url + "ajax_controller/tel_dogrulama_resend",
                    data: {
                        kullanici: user,
                        telefon: $("#telefon").val()
                    },
                    success: function (data) {
                        var d = JSON.parse(data);
                        if (d.status.status == 'success') {
                            startCountdown();
                            $(".tel-dogrula-alert").html(d.status.alert_html);
                        } else {
                            $(".tel-dogrula-alert").html(d.status.alert_html);
                        }
                    }
                });
            } else {
                // Eğer geri sayım başlamışsa sıfırla ve tekrar başlat
                resetCountdown();
                var user = $(this).data('id');
                $.ajax({
                    type: "POST",
                    url: base_url + "ajax_controller/tel_dogrulama_resend",
                    data: {
                        kullanici: user,
                        telefon: $("#telefon").val()
                    },
                    success: function (data) {
                        var d = JSON.parse(data);
                        if (d.status.status == 'success') {
                            startCountdown();
                            $(".tel-dogrula-alert").html(d.status.alert_html);
                        } else {
                            $(".tel-dogrula-alert").html(d.status.alert_html);
                        }
                    }
                });
            }

            // Burada SMS gönderme işlemlerini gerçekleştirebilirsiniz.
        });


        $('.tel-dogrula-button').on('click', function () {
            var user = $(this).data('id');
            $.ajax({
                type: "POST",
                url: base_url + "ajax_controller/tel_dogrulama",
                data: {
                    kullanici: user,
                    telefon: $("#telefon").val()
                },
                success: function (data) {
                    var d = JSON.parse(data);
                    $("#teldogrula_step_1").modal("hide");
                    $("#teldogrula").modal("show");
                   if (d.status.status == 'success') {
                       startCountdown();
                       $(".tel-dogrula-alert").html(d.status.alert_html);
                   } else {
                       $(".tel-dogrula-alert").html(d.status.alert_html);
                   }
                }
            });

        });

        $('.tel-dogrulama-form').on('submit', function () {
            var kod = $('input[name="tel_dogrulama"]').val();
            $.ajax({
                type: "POST",
                url: base_url + "ajax_controller/tel_kod_dogrulama",
                data: {
                    code: kod,
                },
                success: function (data) {
                    var d = JSON.parse(data);
                    if (d.status.status == 'success') {
                        Swal.fire(
                            'Başarılı!',
                            d.status.message,
                            d.status.status,
                        );
                        setTimeout(
                            function(){
                                window.location.reload();
                            } , 2000);
                    } else {
                        Swal.fire(
                            'Hata!',
                            d.status.message,
                            d.status.status,
                        );
                    }
                }
            });

        });
    </script>
<script>
    
    function getFormData($form) {
        var unindexed_array = $form.serializeArray();
        var indexed_array = {};

        $.map(unindexed_array, function (n, i) {
            indexed_array[n['name']] = n['value'];
        });

        return indexed_array;
    }

    function paymentInfoPanel() {
        Swal.fire({
            html: $(".payment-info-modal .grid").html(),
            showCancelButton: false,
            showConfirmButton: false,
            showCloseButton: true,
            allowOutsideClick: false,
            allowEscapeKey: true,
            focusConfirm: false,
            customClass: {
                container: "login-special-container"
            }
        });
        $(".swal2-html-container #odemeBildirimForm #havale_tutar").on('input', function () {
            var tutar = parseFloat($(this).val());
            var komisyon = parseFloat(<?= $ayarlar->havale_komisyon ?>);
            var odenecek = (tutar / (100 + komisyon)) * 100;
            $(".swal2-html-container #odemeBildirimForm #havale_odenecek_tutar").html(odenecek.toFixed(2));
        });
        moment.updateLocale('tr', {
            meridiem : function (hour, minute, isLowercase) {
                if (hour < 12) {
                    return 'ÖÖ';
                } else {
                    return 'ÖS';
                }
            }
        });

        moment.updateLocale('tr', {
            meridiem : function (hour, minute, isLowercase) {
                if (hour < 12) {
                    return 'öö';
                } else {
                    return 'ös';
                }
            }
        });

        $('.swal2-html-container #odemeBildirimForm #odeme_bildirim_date').daterangepicker({
            "singleDatePicker": true,
            "timePicker": true,
            "startDate": "<?= date('d.m.Y H:i:s') ?>",
            "minDate": "<?= date('d.m.Y H:i:s',strtotime("-31 days")) ?>",
            "maxDate": "<?= date('d.m.Y H:i:s') ?>",
            "locale": {
                "format": "DD.MM.YYYY HH:mm:ss",
                "separator": " - ",
                "applyLabel": "Uygula",
                "cancelLabel": "Vazgeç",
                "fromLabel": "Dan",
                "toLabel": "a",
                "customRangeLabel": "Seç",
                "daysOfWeek": [
                    "Pt",
                    "Sl",
                    "Çr",
                    "Pr",
                    "Cm",
                    "Ct",
                    "Pz"
                ],
                "monthNames": [
                    "Ocak",
                    "Şubat",
                    "Mart",
                    "Nisan",
                    "Mayıs",
                    "Haziran",
                    "Temmuz",
                    "Ağustos",
                    "Eylül",
                    "Ekim",
                    "Kasım",
                    "Aralık"
                ],
                "firstDay": 1
            },
        }, function(start, end, label) {

        });
        $(".swal2-html-container #odemeBildirimForm").submit((e) => {
            e.preventDefault();
            var form = $(".swal2-html-container #odemeBildirimForm");
            $.ajax({
                type: "POST",
                url: "<?= base_url("odemebildirimiolustur") ?>",
                data: getFormData(form),
                success: function (res) {
                    res = JSON.parse(res);
                    if (res.status) {
                        Swal.fire({
                            icon: 'success',
                            title: 'Ödeme Bildirimi Alındı',
                            text: 'Ödeme bildiriminiz tarafımıza ulaştı. En kısa süre içerisinde bakiyeniz hesabınıza yüklenecektir.',
                        })
                    } else {
                        if(res.tel_verify) {
                            Swal.close();
                            $("#teldogrula_step_1").modal("show");
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Ödeme Bildirimi Oluşturulamadı.',
                                text: res.message?res.message:'Girmiş olduğunuz bilgileri tekrar kontrol ediniz. Sorun hala devam ediyorsa yönetici ile iletişime geçiniz.',
                            })
                        }
                    }
                }
            })
        })
    }

    $(".bank-img-area").on('click', function () {
        var id = $(this).data('id');
        $.ajax({
            type: "POST",
            url: "<?= base_url("Home_controller/banka_getir") ?>",
            data: {
                banka: id
            },
            success: function (res) {
                res = JSON.parse(res);
                if (res.status) {
                    $('.modal-bank-img').attr('src', 'https://kemalellidort.com.tr/' + res.banka.image);
                    $('.modal-transfer-bank-name').html(res.banka.name);
                    $('.modal-iban-area').html(res.banka.iban);
                    $('.modal-bank-desc').html(res.banka.description);
                    $('.modal-bank-select').html('<option value="' + res.banka.id + '">' + res.banka.name + '</option>');
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Hata',
                        text: 'Yapmaya Çalıştığınız İşlem Geçerli Değil',
                    })
                }
            }
        })
    });

    $(document).ready(function () {
        $("#bakiyeKuponuForm").submit((e)=>{
            e.preventDefault();
            var form = $("#bakiyeKuponuForm");
            $.ajax({
                type: "POST",
                url: "<?= base_url("kuponkullan") ?>",
                data: getFormData(form),
                success: function (res) {
                    res = JSON.parse(res);
                    if (res.status) {
                        Swal.fire({
                            icon: 'success',
                            title: 'Kupon Kullanıldı',
                            text: res.message?res.message:'Kupon bakiyesi hesabınıza aktarıldı.',
                        })
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Kupon Kullanılamadı.',
                            text: res.message?res.message:'Yönetici ile iletişime geçiniz.',
                        })
                    }
                }
            })
        })
        $("#tutar").on('input', function () {
            var tutar = parseFloat($(this).val());
            var komisyon = parseFloat($("#komisyon_oran").val());
            var odenecek = tutar + (tutar * komisyon / 100);
            $("#odenecek_tutar").html(odenecek);
        });
        $("#iyzico_tutar").on('input', function () {
            var tutar = parseFloat($(this).val());
            var komisyon = parseFloat($("#iyzico_komisyon_oran").val());
            var odenecek = tutar + (tutar * komisyon / 100);
            $("#iyzico_odenecek_tutar").html(odenecek);
        });
        $("#weepay_tutar").on('input', function () {
            var tutar = parseFloat($(this).val());
            var komisyon = parseFloat($("#weepay_komisyon_oran").val());
            var odenecek = tutar + (tutar * komisyon / 100);
            $("#weepay_odenecek_tutar").html(odenecek);
        });
        $("#vallet_tutar").on('input', function () {
            var tutar = parseFloat($(this).val());
            var komisyon = parseFloat($("#vallet_komisyon_oran").val());
            var odenecek = tutar + (tutar * komisyon / 100);
            $("#vallet_odenecek_tutar").html(odenecek);
        });
        $("#stripe_tutar").on('input', function () {
            var tutar = parseFloat($(this).val());
            var komisyon = parseFloat($("#stripe_komisyon_oran").val());
            var odenecek = tutar + komisyon;
            $("#stripe_odenecek_tutar").html(odenecek);
        });
    })
</script>