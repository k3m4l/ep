<?php $kullanici = kullanicicek(); ?>
<?php $firmajson = json_decode($kullanici->ozellik_firma); ?>
<div id="dashboard">

	<!-- Navigation
	================================================== -->

	<!-- Responsive Navigation Trigger -->
	<a href="#" class="dashboard-responsive-nav-trigger"><i class="fa fa-reorder"></i> Navigation</a>

	<?php $this->load->view("kpanel/inc/menu"); ?>
	<!-- Navigation / End -->


	<div class="dashboard-content">

		<!-- Titlebar -->
		<div id="titlebar">
			<div class="row">
				<div class="col-md-12">
					<h2>Genel Ayarlar</h2>
					<!-- Breadcrumbs -->
					<nav id="breadcrumbs">
						<ul>
							<li><a href="<?=base_url()?>">Anasayfa</a></li>
							<li><a href="<?=base_url("kullanici-paneli")?>">Kullanıcı Paneli</a></li>
							<li>Genel Ayarlar</li>
						</ul>
					</nav>
				</div>
			</div>
		</div>

		<div class="row">

			<!-- Profile -->
			<div class="col-lg-12 col-md-12">
				<div class="dashboard-list-box margin-top-0">
					<h4 class="gray">Kullanıcı Genel Ayarları</h4>
					<div class="dashboard-list-box-static">
						<form method="post" action="<?=base_url("ozellikduzenle/").$kullanici->kullanici_uniq?>">
							<div class="my-profile">
								<div class="row">
									<!--<div class="col-md-12">
										<label>Özelliklerin Uygulanacağı Firmaları Seçin</label>
										<select data-placeholder="Firma Seçin" name="firma[]" class="chosen-select" multiple>
											<?php foreach ($firmalar as $key) { ?>
												<option 

												value="<?=$key->firma_id?>"><?=$key->firma_ad?></option>
											<?php } ?>
										</select>
									</div>-->
									<div class="col-md-6">
										<label>Rezervasyon Sistemi Görünümü</label>
										<select name="rezervasyon">
											<option <?php if ($kullanici->ozellik_rezervasyon==1) { echo "selected"; } ?> value="1">Aktif</option>
											<option <?php if ($kullanici->ozellik_rezervasyon==0) { echo "selected"; } ?> value="0">Pasif</option>
										</select>
									</div>
									<div class="col-md-6">
										<label>Yorum Sistemi Görünümü</label>
										<select name="yorum">
											<option <?php if ($kullanici->ozellik_yorum==1) { echo "selected"; } ?> value="1">Aktif</option>
											<option <?php if ($kullanici->ozellik_yorum==0) { echo "selected"; } ?> value="0">Pasif</option>
										</select>
									</div>
									<div class="col-md-6">
										<label>Çalışma Saatleri Görünümü</label>
										<select name="saat">
											<option <?php if ($kullanici->ozellik_saat==1) { echo "selected"; } ?> value="1">Aktif</option>
											<option <?php if ($kullanici->ozellik_saat==0) { echo "selected"; } ?> value="0">Pasif</option>
										</select>
									</div>
									<div class="col-md-6">
										<label>Firma Yetkili Görünümü</label>
										<select name="yetkili">
											<option <?php if ($kullanici->ozellik_yetkili==1) { echo "selected"; } ?> value="1">Aktif</option>
											<option <?php if ($kullanici->ozellik_yetkili==0) { echo "selected"; } ?> value="0">Pasif</option>
										</select>
									</div>
									<div class="col-md-6">
										<label>Galeri Görünümü</label>
										<select name="galeri">
											<option <?php if ($kullanici->ozellik_galeri==1) { echo "selected"; } ?> value="1">Aktif</option>
											<option <?php if ($kullanici->ozellik_galeri==0) { echo "selected"; } ?> value="0">Pasif</option>
										</select>
									</div>
									<div class="col-md-6">
										<label>Hizmetlerimiz Görünümü</label>
										<select name="hizmet">
											<option <?php if ($kullanici->ozellik_hizmet==1) { echo "selected"; } ?> value="1">Aktif</option>
											<option <?php if ($kullanici->ozellik_hizmet==0) { echo "selected"; } ?> value="0">Pasif</option>
										</select>
									</div>
									<div class="col-md-12">
										<label>Rezervasyon Gönderilecek E-Posta Adresi <small><code style="color: red;">Rezervasyon Sistemi Aktif Olması İçin Gereklidir!</code></small></label>
										<input placeholder="rezervasyon@siteadresi.com" type="text" name="rezmail" value="<?=$kullanici->ozellik_rezmail?>">
									</div>
								</div>
							</div>
		
							<button type="submit" class="button margin-top-15">Değişiklikleri Kaydet</button>
						</form>
					</div>
				</div>
			</div>

			<!-- Copyrights -->
			<?php $this->load->view("kpanel/inc/footer"); ?>

		</div>

	</div>


</div>
<!-- Dashboard / End -->


</div>