<link rel="stylesheet" href="<?= base_url('assets/css/theme.min.css') ?>">
<?php if ($_SESSION["theme"] == "1") : ?> <!-- Light -->
    <link rel="stylesheet" href="<?= base_url("assets") ?>/css/light.css">
<?php endif; ?>
<?php if ($_SESSION["theme"] == "2") : ?>
    <link rel="stylesheet" href="<?= base_url("assets") ?>/css/dark.css">
<?php endif; ?>

<div class="pb-5 py-md-5">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-12">
                <div class="card mb-4">
                    <div class="card-body">
                        <div class="d-flex align-items-end justify-content-between px-4 pt-2 pb-4">
                            <div class="d-flex align-items-center">
                                <div class="form-group">
                                    <label>Mağaza Seç</label>
                                    <select class="form-control" id="magazaSec">
                                        <option value=""></option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>