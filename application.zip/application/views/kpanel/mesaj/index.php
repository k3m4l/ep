<!--<link rel="stylesheet" href="<?= base_url('assets/css/theme.min.css') ?>">-->
<section class="col-lg-8 control-panel">
<div class="pb-5 py-md-5">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-4 col-12 nv">
                <nav class="navbar navbar-expand-md navbar-light shadow-sm mb-4 mb-lg-0 small-sidenav">
                    <!-- Menu -->
                    <a class="d-xl-none d-lg-none d-md-none text-inherit font-weight-bold" href="#">Mesajlar</a>
                    <!-- Button -->
                    <button class="navbar-toggler d-md-none icon-shape icon-sm rounded bg-primary text-light"
                            type="button"
                            data-toggle="collapse" data-target="#smallSidenav" aria-controls="smallSidenav"
                            aria-expanded="false"
                            aria-label="Toggle navigation">
                        <span class="fe fe-menu"></span>
                    </button>
                    <!-- Collapse -->
                    <div class="collapse navbar-collapse" id="smallSidenav">
                        <?php $this->load->view('kpanel/inc/mesaj_nav', ['mesaj' => $mesaj, 'amesaj' => (object)['uniq' => 'null']]); ?>
                    </div>
            </div>
            <div class="col-lg-9 col-md-8 col-12">
                <div class="card mb-4">
                    <style>
                        .notShowingChat img {
                            width: 200px;
                            margin-bottom: 30px;
                        }
                        .notShowingChat .chatText h4 {
                            margin-bottom: 5px;
                        }
                        .chatText {
                            display: block;
                            font-size: 13px;
                        }
                    </style>
                    <div class="card-body">
                        <div class="notShowingChat m-auto" style="text-align: center;">
                            <br> <br>
                            <img src="https://cdn.itempazar.com/global/illustrations/undraw_messages1_9ah2.svg">
                            <div class="chatText">
                                <h4>Görünüşe göre hiç sohbetiniz yok.</h4>
                                <span>Bir ilan detayına giderek "Sohbet Et" butonu aracılığı ile sohbet oluşturabilirsin.</span>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</section>
