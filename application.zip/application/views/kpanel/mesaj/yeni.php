<link rel="stylesheet" href="<?= base_url('assets/css/theme.min.css') ?>">
<?php if ($_SESSION["theme"] == "1") : ?> <!-- Light -->
    <link rel="stylesheet" href="<?= base_url("assets") ?>/css/light.css">
<?php endif; ?>
<?php if ($_SESSION["theme"] == "2") : ?>
    <link rel="stylesheet" href="<?= base_url("assets") ?>/css/dark.css">
<?php endif; ?>

<div class="pb-5 py-md-5">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-12">
                <div class="card mb-4">
                    <div class="card-body">
                        <div class="d-flex align-items-end justify-content-between px-4 pt-2 pb-4">
                            <div class="d-flex align-items-center">
                                <div class="mr-2 position-relative d-flex justify-content-end align-items-end">
                                    <img src="<?= base_url($alici->magaza_resim) ?>" class="avatar-xl rounded-circle border-width-4 border-white position-relative" alt="<?= $alici->magaza_ad ?>">
                                    <?php if ($alici->magaza_dogrulama == 1) { ?>
                                        <a href="javascript:void(0)" class="position-absolute top-0 right-0" data-toggle="tooltip" data-placement="top" title="" data-original-title="Doğrulanmış Mağaza">
                                            <img src="<?= base_url('assets/front/') ?>images/checked-mark.svg" alt="" height="30" width="30" />
                                        </a>
                                    <?php } ?>
                                </div>
                                <div class="lh-1">
                                    <h2 class="mb-0"><?= $alici->magaza_ad ?></h2>
                                    <p class="mb-0 d-block">@<?= $alici->magaza_seo ?></p>
                                </div>
                            </div>
                        </div>
                        <div class="bg-white p-2 rounded-3 shadow-sm">
                            <form action="<?= base_url('yeni-mesaj-post/' . $alici->magaza_uniq); ?>" method="post">
                                <div class="position-relative">
                                    <textarea class="form-control border-0 form-control-simple no-resize" name="mesaj" placeholder="Mağazaya iletmek istediğiniz mesajı yazın.." rows="5"></textarea>
                                </div>
                                <div class="position-absolute end-0 mt-n7 me-4">
                                    <button type="submit" class="fs-3 btn text-primary btn-focus-none">
                                        <i class="fe fe-send"></i>
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>