<main class="main-content pt-xl-4 pt-3 pb-xl-4 pb-3">
    <div class="container">
        <div class="row align-items-center no-gutters justify-content-between">
        </div>
        <div class="row mt-4 mb-4">
            <div class="col-xl-3 col-lg-3 col-12 mb-xl-0 mb-3">
                <div class="bg-color message-users" id="box_list">
                    <div id="asagial"></div>
                    <div class="">
                        <a class="newmessage" data-toggle="modal" data-target="#sohbet"><i>+</i> YENİ SOHBET</a>
                    </div>
                    <div class="chat-search">
                        <input type="text" name="s"
                               class="cat-search" onkeyup="var value = $(this).val().toLowerCase();
                            $(&quot;.isim&quot;).filter(function() {
                                $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
                            });" placeholder="Aradığınız Kullanıcıyı Yazın...">
                    </div>
                    <div class="d-flex align-items-center">
                    </div>
                    <ul id="yenimesaj" class="chat-list-name">
                        <?php if ($mesaj || $giden_mesaj) { ?>
                            <?php foreach ($mesaj as $key => $val) { ?>
                                <?php $user = kullanici_bilgi($val->gonderen_id); ?>
                                <li class="messageus menu-left-area" data-target="<?php echo $val->uniq ?>">
                                    <div style="cursor:pointer;"
                                         onclick="$(document).scrollTop($('div#asagial').offset().top);"><a
                                                class="row no-gutters align-items-center isim">
                                        <span class="col-3">
                                            <span class="mu-image">
                                                <?php if (strpos($user->kullanici_resim, "/.jpg") !== false) { ?>
                                                    <img src="https://ui-avatars.com/api/?name=<?= $user->kullanici_isim ?>+<?= $user->kullanici_soyisim ?>&background=0D8ABC&color=fff"
                                                         alt="">
                                                <?php } else { ?>
                                                    <img src="<?= base_url($user->kullanici_resim) ?>" alt="">
                                                <?php } ?>
                                            </span>
                                        </span>
                                            <span class="col-9">
                                            <span class="row justify-content-between"></span>
                                            <span class="col-auto">
                                            <span class="mu-name"><?= $user->kullanici_ad ?> </span>
                                            <br><span class="col-auto">
                                            <span id="" class="mu-date">
                                            <?php echo $val->tarih ?>
                                            </span>
                                            </span>
                                        </span>
                                        </span>
                                        </a>
                                    </div>
                                </li>
                            <?php } ?>
                            <?php foreach ($giden_mesaj as $key => $val) { ?>
                                <?php $user = kullanici_bilgi($val->alan_id); ?>
                                <li class="messageus menu-left-area" data-target="<?php echo $val->uniq ?>">
                                    <div style="cursor:pointer;"
                                         onclick="$(document).scrollTop($('div#asagial').offset().top);"><a
                                                class="row no-gutters align-items-center isim">
                                        <span class="col-3">
                                            <span class="mu-image">
                                                <?php if (strpos($user->kullanici_resim, "/.jpg") !== false) { ?>
                                                    <img src="https://ui-avatars.com/api/?name=<?= $user->kullanici_isim ?>+<?= $user->kullanici_soyisim ?>&background=0D8ABC&color=fff"
                                                         alt="">
                                                <?php } else { ?>
                                                    <img src="<?= base_url($user->kullanici_resim) ?>" alt="">
                                                <?php } ?>
                                            </span>
                                        </span>
                                            <span class="col-9">
                                            <span class="row justify-content-between"></span>
                                            <span class="col-auto">
                                            <span class="mu-name"><?= $user->kullanici_ad ?> </span>
                                            <br><span class="col-auto">
                                            <span id="" class="mu-date">
                                            <?php echo $val->tarih ?>
                                            </span>
                                            </span>
                                        </span>
                                        </span>
                                        </a>
                                    </div>
                                </li>
                            <?php } ?>
                        <?php } else { ?>
                            <li class="messageus" data-target="0">
                                <div style="cursor:pointer;"
                                     onclick="$(document).scrollTop($('div#asagial').offset().top);"><a
                                            class="row no-gutters align-items-center isim">
                                        <span class="col-12" style="text-align: center;margin-top:15px">
                                        <span class="row justify-content-between"></span>
                                        <span class="col-auto">
                                            <span class="mu-name">Mesaj Bulunmamaktadır. </span>
                                            <br><span class="col-auto">
                                            </span>
                                        </span>
                                    </span>
                                    </a>
                                </div>
                            </li>
                        <?php } ?>
                    </ul>
                </div>
            </div>
            <div class="col-xl-9 col-lg-9 col-12" id="n">
                <div class="bg-color mu-message-area pl-3 pb-3 pr-3">
                    <div class="empty-chat">
                        <div class="mma-top border-bottom">
                            <div class="row mma-row justify-content-between align-items-center">
                            </div>
                        </div>
                        <div class="mma-content" id="mma-content">
                            <div id="mma-red" style="text-align: center;padding: 15px; display: block;">
                                <img height="300" src="<?php echo base_url('assets/images/chats-1.png') ?>">
                            </div>
                            <div id="mma-red-text" class="mma-chat-text" style="text-align: center;">
                                <h4>Anlık sohbet sistemine hoşgeldin</h4>
                                <span>Buradan anlık olarak sitemiz üzerindeki kullanıcılar ile mesajlaşabilir ve Yeni sohbet oluştur butonuna tıklayarak yeni bir sohbet başlatabilirsin.</span>
                            </div>
                        </div>
                    </div>
                    <?php if ($mesaj || $giden_mesaj) { ?>
                        <?php foreach ($mesaj as $key => $val) { ?>
                            <?php $user = kullanici_bilgi($val->gonderen_id); ?>
                            <div class="chat-area" id="select-chat-<?php echo $val->uniq ?>">
                                <div class="row mma-row justify-content-between align-items-center">
                                    <div style="display: block;" id="mma-ustbar" class="col-xl-auto col-12">
                                        <div class="row align-items-center">
                                            <div class="col-auto">
                                                <div class="mma-image">
                                                    <a id="profilegit"
                                                       href="javascript:void(0)">
                                                        <?php if (strpos($user->kullanici_resim, "/.jpg") !== false) { ?>
                                                            <img src="https://ui-avatars.com/api/?name=<?= $user->kullanici_isim ?>+<?= $user->kullanici_soyisim ?>&background=0D8ABC&color=fff"
                                                                 alt="" id="pp">
                                                        <?php } else { ?>
                                                            <img id="pp" alt=""
                                                                 src="<?= base_url($user->kullanici_resim) ?>">
                                                        <?php } ?>
                                                    </a>
                                                </div>
                                            </div>
                                            <div class="col-auto">
                                                <div class="mma-name"
                                                     id="mma-name"><?php echo $user->kullanici_ad ?></div>
                                            </div>
                                            <marquee class="duyurutext">
                                                <?php echo $ayarlar->mesaj_detay_kayan_yazi ?>
                                            </marquee>
                                        </div>
                                    </div>
                                </div>
                                <div class="chat-bar">

                                </div>

                                <div class="mm-chat-sender">
                                    <div class="row no-gutters chat-container">
                                        <div class="col-xl-11 col-10">
                                            <input style="display: block;" type="text"
                                                   data-target="<?php echo $val->uniq ?>"
                                                   class="chat-input sendmessage" name="remessage"
                                                   placeholder="Bir şeyler yazın...">
                                        </div>
                                        <div class="col-xl-1 col-2">
                                            <button style="display: block;" id="sendmessagebutton"
                                                    data-target="<?php echo $val->uniq ?>"
                                                    class="chat-button sendReMessage"></button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                        <?php foreach ($giden_mesaj as $key => $val) { ?>
                            <?php $user = kullanici_bilgi($val->alan_id); ?>
                            <div class="chat-area" id="select-chat-<?php echo $val->uniq ?>">
                                <div class="row mma-row justify-content-between align-items-center">
                                    <div style="display: block;" id="mma-ustbar" class="col-xl-auto col-12">
                                        <div class="row align-items-center">
                                            <div class="col-auto">
                                                <div class="mma-image">
                                                    <a id="profilegit" alt="" href="javascript:void(0)">
                                                        <?php if (strpos($user->kullanici_resim, "/.jpg") !== false) { ?>
                                                            <img src="https://ui-avatars.com/api/?name=<?= $user->kullanici_isim ?>+<?= $user->kullanici_soyisim ?>&background=0D8ABC&color=fff"
                                                                 alt="" id="pp">
                                                        <?php } else { ?>
                                                            <img id="pp" alt=""
                                                                 src="<?= base_url($user->kullanici_resim) ?>">
                                                        <?php } ?>
                                                    </a>
                                                </div>
                                            </div>
                                            <div class="col-auto">
                                                <div class="mma-name"
                                                     id="mma-name"><?php echo $user->kullanici_ad ?></div>
                                            </div>
                                            <marquee class="duyurutext">
                                                <?php echo $ayarlar->mesaj_detay_kayan_yazi ?>
                                            </marquee>
                                        </div>
                                    </div>
                                </div>
                                <div class="chat-bar">

                                </div>
                                <div class="mm-chat-sender">
                                    <div class="row no-gutters chat-container">
                                        <div class="col-xl-11 col-10">
                                            <input style="display: block;" type="text"
                                                   data-target="<?php echo $val->uniq ?>"
                                                   class="chat-input sendmessage" name="remessage"
                                                   placeholder="Bir şeyler yazın...">
                                        </div>
                                        <div class="col-xl-1 col-2">
                                            <button style="display: block;" id="sendmessagebutton"
                                                    data-target="<?php echo $val->uniq ?>"
                                                    class="chat-button sendReMessage"></button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                    <?php } ?>

                </div>
            </div>
        </div>
    </div>
</main>
<div class="modal fade" id="sohbet" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
     aria-hidden="true">
    <form action="" method="post" id="infoSohbet">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="form-group">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                        <label for="recipient-name" class="col-form-label">Sohbet'i başlatmak istediğiniz üyenin
                            kullanıcı adını
                            yazın</label>
                        <input name="username" type="text" class="form-control" id="recipient-name"
                               placeholder="Üyenin Kullanıcı Adı">
                        <label for="message-text" class="col-form-label">Mesajınız:</label>
                        <textarea rows="4" cols="50" class="form-control" name="gidicekmesaj" id="mesaj"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-info btn-lg btn-block">Sohbeti Başlat</button>
                </div>
            </div>
        </div>
    </form>
</div>
<script>
    $('.chat-list-name li').click(function () {
        var select_chat = $(this).attr('data-target');
        if ($('.chat-area').hasClass('open')) {
            $('.chat-area').removeClass('open')
            $('#select-chat-' + select_chat).addClass('open')
        } else {
            $('#select-chat-' + select_chat).addClass('open')
        }
    })

    $('.sendmessage').keypress(function (e) {
        if (e.which === 13) {
            var inputValue = $(this).val();
            var inputDataTarget = $(this).data('target');

            <?php if (aktif_kullanici()) : ?>
            $.ajax({
                type: "POST",
                url: base_url + "ajax_controller/send_re_message",
                data: {
                    uniq: inputDataTarget,
                    kullanici_id: <?= $kullanici->kullanici_id ?>,
                    message: inputValue
                },
                success: function (data) {
                    var d = JSON.parse(data);
                    if (d.status == 'error') {
                        Swal.fire(
                            'Hata!',
                            d.message,
                            d.status,
                        );
                    } else if (d.status == 'success') {
                        var targetDiv = $('#select-chat-' + inputDataTarget).find('.chat-bar');
                        targetDiv.append(d.html); // İçerik kısmını kendi isteğinize göre güncelleyin
                        $('.sendmessage').val(' ');
                        $('.chat-bar').scrollTop($('.chat-bar')[0].scrollHeight)
                    }

                }
            });
            <?php else : ?>
            Swal.fire({
                title: 'Giriş Yap',
                text: "Mesajlaşmak için giriş yapmalısınız.",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Giriş Yap',
                cancelButtonText: 'Hayır, İptal Et',
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = "<?= base_url('giris-yap') ?>";
                }
            })
            <?php endif; ?>

        }
    })

    $(document).on("submit", "#infoSohbet", function (event) {
        <?php if (aktif_kullanici()) : ?>
        $.ajax({
            type: "POST",
            url: base_url + "ajax_controller/sohbet_add_mesaj",
            data: {
                mesaj: $('textarea[name="gidicekmesaj"]').val(),
                username: $('input[name="username"]').val(),
                kullanici_id: <?= $kullanici->kullanici_id ?>
            },
            success: function (data) {
                var d = JSON.parse(data);
                if (d.status.status == 'error') {
                    Swal.fire(
                        'Hata!',
                        d.status.message,
                        d.status.status,
                    );
                } else if (d.status.status == 'success') {
                    Swal.fire(
                        'Başarılı!',
                        d.status.message,
                        d.status.status,
                    ).then((result) => {
                        location.reload();
                    })
                }

            }
        });
        event.preventDefault();
        <?php else : ?>
        Swal.fire({
            title: 'Giriş Yap',
            text: "Mesajlaşmak için giriş yapmalısınız.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Giriş Yap',
            cancelButtonText: 'Hayır, İptal Et',
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = "<?= base_url('giris-yap') ?>";
            }
        })
        <?php endif; ?>
    });

    $(document).on("click", ".menu-left-area", function (event) {
        <?php if (aktif_kullanici()) : ?>
        var uniq = $(this).data('target');
        $.ajax({
            type: "POST",
            url: base_url + "ajax_controller/sohbet_getir",
            data: {
                uniq: uniq,
                kullanici_id: <?= $kullanici->kullanici_id ?>
            },
            success: function (data) {
                var d = JSON.parse(data);
                if (d.status == 'error') {
                    Swal.fire(
                        'Hata!',
                        d.message,
                        d.status,
                    );
                } else if (d.status == 'success') {
                    var targetDiv = $('#select-chat-' + uniq).find('.chat-bar');
                    targetDiv.html(d.html); // İçerik kısmını kendi isteğinize göre güncelleyin
                    $('.chat-bar').scrollTop($('.chat-bar')[0].scrollHeight)
                }

            }
        });
        event.preventDefault();
        <?php else : ?>
        Swal.fire({
            title: 'Giriş Yap',
            text: "Mesajlaşmak için giriş yapmalısınız.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Giriş Yap',
            cancelButtonText: 'Hayır, İptal Et',
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = "<?= base_url('giris-yap') ?>";
            }
        })
        <?php endif; ?>
    });

    $(document).on("click", ".sendReMessage", function (event) {
        <?php if (aktif_kullanici()) : ?>
        var inputValue = $(this).closest('.chat-container').find('input[name="remessage"]').val();
        var uniq = $(this).data('target');
        $.ajax({
            type: "POST",
            url: base_url + "ajax_controller/send_re_message",
            data: {
                uniq: uniq,
                kullanici_id: <?= $kullanici->kullanici_id ?>,
                message: inputValue
            },
            success: function (data) {
                var d = JSON.parse(data);
                if (d.status == 'error') {
                    Swal.fire(
                        'Hata!',
                        d.message,
                        d.status,
                    );
                } else if (d.status == 'success') {
                    var targetDiv = $('#select-chat-' + uniq).find('.chat-bar');
                    targetDiv.append(d.html); // İçerik kısmını kendi isteğinize göre güncelleyin
                    $('.sendmessage').val(' ');
                    $('.chat-bar').scrollTop($('.chat-bar')[0].scrollHeight)
                }

            }
        });
        event.preventDefault();
        <?php else : ?>
        Swal.fire({
            title: 'Giriş Yap',
            text: "Mesajlaşmak için giriş yapmalısınız.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Giriş Yap',
            cancelButtonText: 'Hayır, İptal Et',
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = "<?= base_url('giris-yap') ?>";
            }
        })
        <?php endif; ?>
    });


</script>
