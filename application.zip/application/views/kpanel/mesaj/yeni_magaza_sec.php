<link rel="stylesheet" href="<?= base_url('assets/css/theme.min.css') ?>">
<?php if ($_SESSION["theme"] == "1") : ?> <!-- Light -->
    <link rel="stylesheet" href="<?= base_url("assets") ?>/css/light.css">
<?php endif; ?>
<?php if ($_SESSION["theme"] == "2") : ?>
    <link rel="stylesheet" href="<?= base_url("assets") ?>/css/dark.css">
<?php endif; ?>

<div class="pb-5 py-md-5">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-12">
                <div class="card mb-4">
                    <div class="card-body">
                        <div class="d-flex align-items-end justify-content-between px-4 pt-2 pb-4">
                            <div class="d-flex align-items-center w-100">
                                <div class="form-group w-100">
                                    <label>Mağaza Seç</label>
                                    <select class="form-control h-100" id="magazaSec">
                                        <option value="" disabled selected>Lütfen mağaza seçiniz.</option>
                                        <?php 
                                        foreach($magazalar as $magaza) { ?>
                                            <option value="<?= $magaza->magaza_uniq ?>"><?= $magaza->magaza_ad; ?></option>
                                        <?php } ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    $(document).ready(function() {
        $("#magazaSec").on('change',function() {
            var uniq = $(this).val();
            location.href = '<?= base_url('yeni-mesaj') ?>/' + uniq;
        })
    });
</script>