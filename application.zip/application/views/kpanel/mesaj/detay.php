<section class="col-lg-8 control-panel">
    <div class="pb-5 py-md-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-4 col-12 nv">
                    <nav class="navbar navbar-expand-md navbar-light shadow-sm mb-4 mb-lg-0 small-sidenav">
                        <!-- Menu -->
                        <a class="d-xl-none d-lg-none d-md-none text-inherit font-weight-bold" href="#!">Mesajlar</a>
                        <!-- Button -->
                        <button class="navbar-toggler d-md-none icon-shape icon-sm rounded bg-primary text-light"
                                type="button"
                                data-toggle="collapse" data-target="#smallSidenav" aria-controls="smallSidenav"
                                aria-expanded="false"
                                aria-label="Toggle navigation">
                            <span class="fe fe-menu"></span>
                        </button>
                        <!-- Collapse -->
                        <div class="collapse navbar-collapse" id="smallSidenav">
                            <?php $this->load->view('kpanel/inc/mesaj_nav', ['mesaj' => $mesaj, 'amesaj' => $amesaj]); ?>
                        </div>
                </div>
                <div class="col-lg-9 col-md-8 col-12">
                    <div class="card mb-4">
                        <div class="card-body">
                            <?php
                            $profile_id = $amesaj->gonderen_id;
                            if ($kullanici->kullanici_id == $amesaj->gonderen_id) {
                                $profile_id = $amesaj->alan_id;
                            }
                            $profile = kullanici_bilgi($profile_id);
                            if (!empty($profile)):?>
                                <?php if (magaza_check_id($profile_id)) { ?>
                                    <?php $magazaCekPrf = magaza_kbilgi($profile_id); ?>
                                    <div class="d-flex align-items-center mb-2">
                                        <a href="#" class="me-2 d-xl-none d-block"><i class="fe fe-arrow-left"></i></a>
                                        <div class="avatar avatar-md">
                                            <img src="<?= base_url($magazaCekPrf->magaza_resim) ?>" alt=""
                                                class="rounded-circle"/>
                                        </div>
                                        <!-- media body -->
                                        <div class=" ms-2">
                                            <h4 class="mb-0"><?= $magazaCekPrf->magaza_ad?></h4>
                                            <p class="mb-0 text-muted">@<?= $magazaCekPrf->magaza_seo ?></p>
                                        </div>
                                    </div>
                                    <hr>
                                <?php } else { ?>
                                    <div class="d-flex align-items-center mb-2">
                                        <a href="#" class="me-2 d-xl-none d-block"><i class="fe fe-arrow-left"></i></a>
                                        <div class="avatar avatar-md">
                                            <img src="<?= base_url($profile->kullanici_resim) ?>" alt=""
                                                class="rounded-circle"/>
                                        </div>
                                        <!-- media body -->
                                        <div class=" ms-2">
                                            <h4 class="mb-0"><?= $profile->kullanici_isim . " " . $profile->kullanici_soyisim ?></h4>
                                            <p class="mb-0 text-muted">@<?= $profile->kullanici_ad ?></p>
                                        </div>
                                    </div>
                                    <hr>
                                <?php } ?>
                            <?php endif; ?>
                            <div class="scroll-down messageBody" id="style-3">
                                <?php foreach ($mesajlar as $item): ?>
                                    <?php if ($kullanici->kullanici_id == $item->alan_id): ?>
                                        <?php if (magaza_check_id($item->gonderen_id)) { ?>
                                            <?php $magazaCek = magaza_kbilgi($item->gonderen_id); ?>
                                            <div class="d-flex w-lg-40 mb-4">
                                                <img src="<?= base_url($magazaCek->magaza_resim) ?>"
                                                    alt="<?= $magazaCek->magaza_ad ?>"
                                                    class="rounded-circle avatar avatar-md"
                                                />
                                                <!-- media body -->
                                                <div class=" ms-3">
                                                    <small><?= $magazaCek->magaza_ad ?>
                                                        , <?= zamanCevir($item->tarih) ?></small>
                                                    <div class="d-flex">
                                                        <div class="card mt-2 rounded-top-md-left-0 ">
                                                            <div class="card-body p-3">
                                                                <p class="mb-0 text-dark"><?= $item->mesaj ?></p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php } else { ?>
                                            <div class="d-flex w-lg-40 mb-4">
                                                <img src="<?= base_url(kullanici_resim($item->gonderen_id)) ?>"
                                                    alt="<?= kullanici_isim_soyisim($item->gonderen_id) ?>"
                                                    class="rounded-circle avatar avatar-md"
                                                />
                                                <!-- media body -->
                                                <div class=" ms-3">
                                                    <small><?= kullanici_isim_soyisim($item->gonderen_id) ?>
                                                        , <?= zamanCevir($item->tarih) ?></small>
                                                    <div class="d-flex">
                                                        <div class="card mt-2 rounded-top-md-left-0">
                                                            <div class="card-body p-3">
                                                                <p class="mb-0 text-dark"><?= $item->mesaj ?></p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php } ?>
                                    <?php else: ?>
                                        <?php if (magaza_check_id($item->gonderen_id)) { ?>
                                            <?php $magazaCek = magaza_kbilgi($item->gonderen_id); ?>
                                            <div class="d-flex justify-content-end mb-4">
                                                <!-- media -->
                                                <div class="d-flex w-lg-40">

                                                    <img src="<?= base_url($magazaCek->magaza_resim) ?>"
                                                        alt="<?= $magazaCek->magaza_ad ?>"
                                                        class="rounded-circle avatar avatar-md"
                                                    />
                                                    <!-- media body -->
                                                    <div class=" ms-3">
                                                        <small><?= $magazaCek->magaza_ad ?>
                                                            , <?= zamanCevir($item->tarih) ?></small>
                                                        <div class="d-flex">
                                                            <div class="card mt-2 rounded-top-md-end-0 bg-primary text-white">
                                                                <div class="card-body p-3">
                                                                    <p class="mb-0"><?= $item->mesaj ?></p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!-- img -->
                                                </div>
                                            </div>
                                        <?php } else { ?>
                                            <div class="d-flex justify-content-end mb-4">
                                                <!-- media -->
                                                <div class="d-flex w-lg-40">
                                                    <!-- media body -->
                                                    <div class=" ms-3">
                                                        <small><?= kullanici_isim_soyisim($item->gonderen_id) ?>
                                                            , <?= zamanCevir($item->tarih) ?></small>
                                                        <div class="d-flex">
                                                            <div class="card mt-2 rounded-top-md-end-0 bg-primary text-white">
                                                                <div class="card-body p-3">
                                                                    <p class="mb-0 text-white"><?= $item->mesaj ?></p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!-- img -->
                                                    <?php if (strpos(kullanici_resim($item->gonderen_id), "/.jpg") !== false) { ?>
                                                        <img src="https://ui-avatars.com/api/?name=<?= kullanici_username($item->gonderen_id) ?>&background=0D8ABC&color=fff"
                                                             alt="<?= base_url(kullanici_isim_soyisim($item->gonderen_id)) ?>"
                                                             class="rounded-circle avatar avatar-md"
                                                        />
                                                    <?php } else { ?>
                                                        <img src="<?= base_url(kullanici_resim($item->gonderen_id)) ?>"
                                                            alt="<?= base_url(kullanici_isim_soyisim($item->gonderen_id)) ?>"
                                                            class="rounded-circle avatar avatar-md"
                                                        />
                                                    <?php } ?>
                                                </div>
                                            </div>
                                        <?php } ?>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </div>
                            <div class="bg-white p-2 rounded-3 shadow-sm">
                                <form action="<?= base_url('cevap-mesaj-post/' . $amesaj->uniq) ?>" method="post">
                                    <div class="position-relative">
                                        <textarea class="form-control border-0 form-control-simple no-resize" name="mesaj"
                                                placeholder="Bu mesajı yanıtlayın"
                                                rows="2"></textarea>
                                    </div>
                                    <div class="position-absolute mt-n7 me-4" style="right: 30px;bottom: 30px;">
                                        <button type="submit" class="fs-3 btn text-primary btn-focus-none">
                                            <i class="fe fe-send"></i>
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>