<!--<link rel="stylesheet" href="<?= base_url('assets/css/theme.min.css') ?>">-->
<div class="pb-5 py-md-5">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-4 col-12">
                <a class="btn btn-success btn-block btn-xs mb-2 mt-2" href="<?=base_url('giden-mesajlar')?>">Giden Mesajlar</a>
                <nav class="navbar navbar-expand-md navbar-light shadow-sm mb-4 mb-lg-0 small-sidenav">
                    <!-- Menu -->
                    <a class="d-xl-none d-lg-none d-md-none text-inherit font-weight-bold" href="#!">Mesajlar</a>
                    <!-- Button -->
                    <button class="navbar-toggler d-md-none icon-shape icon-sm rounded bg-primary text-light"
                            type="button"
                            data-toggle="collapse" data-target="#smallSidenav" aria-controls="smallSidenav"
                            aria-expanded="false"
                            aria-label="Toggle navigation">
                        <span class="fe fe-menu"></span>
                    </button>
                    <!-- Collapse -->
                    <div class="collapse navbar-collapse" id="smallSidenav">
                        <?php $this->load->view('kpanel/inc/giden_mesaj_nav', ['mesaj' => $mesaj, 'amesaj' => (object)['uniq' => 'null']]); ?>
                    </div>
            </div>
            <div class="col-lg-9 col-md-8 col-12">
                <div class="card mb-4">
                    <div class="card-body message-text">
                        <div class="mdi mdi-message"></div>
                        <span class="font-size-27">Mesaj Kutusu</span>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
