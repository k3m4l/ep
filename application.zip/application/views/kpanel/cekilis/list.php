<section class="col-lg-8 account-profile-element">
    <div class="account-profile-photo-area"
         style="background-image: url('<?php echo base_url($kullanici->kullanici_banner) ?>')">
        <div class="user-photo-area">
            <?php if (strpos($kullanici->kullanici_resim, "/.jpg") !== false) { ?>
                <img src="https://ui-avatars.com/api/?name=<?= $kullanici->kullanici_ad ?>&background=0D8ABC&color=fff"
                     alt=""/>
            <?php } else { ?>
                <img src="<?= base_url($kullanici->kullanici_resim) ?>" alt=""/>
            <?php } ?>
        </div>
    </div>
</section>
<section class="col-lg-8 control-panel">
    <div class="account-area">
        
        <div class="container-fluid">

            <div class="row">
                <div class="col-lg-3 col-md-4 col-12 p-0">
                    <div class="user-img-left-area">
                        <img src="<?= base_url($kullanici->kullanici_resim) ?>" alt=""/>
                        <div>
                            <?= $kullanici->kullanici_ad ?>
                        </div>
                    </div>
                    
                    <?php $this->load->view('kpanel/inc/menu'); ?>
                </div>

                <div class="col-lg-9 col-md-8 col-12 pr-0">
                    <h2 class="title">Çekilişlerim</h2>
                    <?php

                    if (!isset($_SESSION["sistembildir"])) {
                        $_SESSION["sistembildir"] = "0";
                    }

                    //  $this->db->select('COUNT(talep_id) as toplam');
                    $this->db->where("kullanici_id='" . $kullanici->kullanici_id . "' and talep_durum='0'");
                    $aylik_siparis_adet = $this->db->get('talep')->result();
                    $data = [];
                    $say = "0";
                    $yaz = "";
                    foreach ($aylik_siparis_adet as $row) {
                        $say++;
                        $yaz .= $say . " - <a style='color:#376d85' href='/destek-detay/" . $row->talep_no . "' target='_blank'>" . $row->talep . "</a><br>";
                    }
                    if ($say != "0") {
                        echo '<div class="alert alert-info tex-">' . $yaz . $say . ' adet talep yanıtlanmayı bekliyor.</div>';
                    }

                    if ($say != $_SESSION["sistembildir"]) {
                        if ($say > $_SESSION["sistembildir"]) {
                            echo '  

<audio autoplay="autoplay">
  <source src="https://soundbible.com/grab.php?id=2155&type=mp3" type="audio/mpeg" />
  Tarayıcınız audio etiketini desteklemiyor.
</audio>';
                        }
                        $_SESSION["sistembildir"] = $say;
                    }
                    ?>
                    <div class="card mb-4">
                        
                        <div class="card-header border-bottom-0">
                            <h3 class="h4 mb-3">Son Oluşturduğum Çekilişler</h3>
                        </div>
                        
                        <div class="table-responsive border-0">
                            <table class="table mb-0 text-nowrap dark-table light-table">
                                <thead>
                                <tr>
                                    <th class="border-0">#</th>
                                    <th class="border-0">İsim</th>
                                    <th class="border-0">Bitis Tarih</th>
                                    <th class="border-0">Durum</th>
                                    <th class="border-0">Türü</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php if ($cekilislerim) {
                                    foreach ($cekilislerim as $val) { ?>
                                        <tr>
                                            <td class="align-middle border-top-0">
                                                <?php echo $val->id ?>
                                            </td>
                                            <td class="align-middle border-top-0">
                                                <?php echo $val->title ?>
                                            </td>
                                            <td class="align-middle border-top-0">
                                                <?php echo $val->end_date ?>
                                            </td>
                                            <td class="align-middle border-top-0">
                                                <?php if ($val->onay == 0) { ?>
                                                    <span class="badge badge-warning">Onay Bekliyor...</span>
                                                <?php } elseif ($val->onay == 1) { ?>
                                                    <span class="badge badge-success">Onaylandı</span>
                                                <?php } else if ($val->onay == 2) { ?>
                                                    <span class="badge badge-danger">İptal Edildi</span>
                                                <?php } ?>
                                            </td>
                                            <td class="align-middle border-top-0">
                                                <?php if ($val->turu == 1) { ?>
                                                    <span class="badge badge-info">Ürün Çekilişi</span>
                                                <?php } elseif ($val->turu == 2) { ?>
                                                    <span class="badge badge-info">Bakiye Çekilişi</span>
                                                <?php } ?>
                                            </td>
                                        </tr>
                                    <?php }
                                } else { ?>
                                    <tr>
                                        <td colspan="6" align="center">
                                            <div class="notification warning closeable"><p>Çekiliş Bulunamadı</p></div>
                                        </td>
                                    </tr>
                                <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
