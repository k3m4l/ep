<div class="main-sr">
    <div class="container">
        <div class="row justify-content-center align-items-center">
            <div class="col-xl-9 col-lg-9 col-md-12 col-sm-12">
                <div class="go-to-back mt-3 mb-3">
                    <a href="<?php echo base_url('destek-taleplerim') ?>"><i class="fa-solid fa-angles-left"></i> Destek Taleplerime Dön</a>
                </div>
                <div class="card mb-4">
                    <div class="card-body">
                        <form action="<?php echo base_url('destekolustur') ?>" method="post">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="form-label">Talep Başlığı</label>
                                        <input class="form-control" name="baslik" type="text"
                                            placeholder="Talep Başlığı">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="form-label">Sipariş Numarası <small>(İsteğe Bağlı)</small></label>
                                        <input class="form-control" name="siparis_no" type="text"
                                            placeholder="Sipariş Numarası">
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="form-label">Talep Detayı</label>
                                        <textarea class="form-control" name="detay" rows="10" type="text"
                                            placeholder="Talep Detayı"></textarea>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <button class="btn btn-success rounded-pill">Destek Talebi Oluştur</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>