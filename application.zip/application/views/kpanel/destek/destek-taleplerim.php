
<section class="page-background">
    <style>
        .pageBackdrop{
            background: url(<?= base_url($ayarlar->destek_bg) ?>);
        }
    </style>
    <div class="pageBackdrop"></div>
    <div class="container">
        <div>
            <img src="<?= base_url($ayarlar->destek_bg) ?>" class="sHeader">
        </div>
    </div>
</section>
    
<style>
    .page-header h3.page-title {
        font-size: 18px;
        font-weight: 700;
        margin-bottom: 0;
        color: #fff;
    }
    .page-header p {
        margin-bottom: 0;
    }
    .talep-ekle {
        position: absolute;
        right: 15px;
        top: 0;
        font-size: 14px;
    }
</style>


<div class="pb-5 py-md-5">
    <div class="container">
        <div class="row mb-5">
            <div class="col-12 page-header d-flex align-items-center justify-content-between flex-wrap">
                <div>
                <h3 class="page-title">Destek Sistemi</h3>
                <p>Oluşturduğunuz destek talepleri aşağıda listelenmektedir.</p>
                </div>
                <a href="<?= base_url('destek-olustur') ?>" class="btn btn-primary settings-btn"><i class="fas fa-plus" aria-hidden="true"></i> Yeni Talep Oluştur</a>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12 col-md-8 col-12">
                
                <?php if ($destek) {?>
                <div class="card mb-4">
                    
                    
                    <div class="table-responsive border-0 overflow-y-hidden">
                        <table class="table mb-0 text-nowrap">
                            <thead>
                            <tr>
                                <th scope="col" class="border-0">Talep No</th>
                                <th scope="col" class="border-0">Talep Zaman</th>
                                <th scope="col" class="border-0">Talep Durum</th>
                                <th scope="col" class="border-0"></th>
                            </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($destek as $key) { ?>
                                    <tr>
                                        <td class="border-top-0">#<?= $key->talep_no ?></td>
                                        <td class="border-top-0"><?= date('d.m.Y H:i', strtotime($key->talep_zaman)) ?></td>
                                        <td class="border-top-0">
                                            <?php if ($key->talep_durum == 0) { ?>
                                                <span class="badge badge-warning">Cevap Bekleniyor..</span>
                                            <?php } elseif ($key->talep_durum == 1) { ?>
                                                <span class="badge badge-success">Cevaplandı</span>
                                            <?php } elseif ($key->talep_durum == 2) { ?>
                                                <span class="badge badge-secondary">Kapatıldı</span>
                                            <?php } ?>
                                        </td>
                                        <td class="text-muted border-top-0">
                                            <a class="badge badge-primary badge-pill" href="<?=base_url('destek-detay/'.$key->talep_no)?>">Talep Detay</a>
                                        </td>
                                    </tr>
                                <?php }?>

                            </tbody>
                        </table>
                    </div>

                </div>
                <?php } else { ?>
                    <div class="col-lg-12">
                        <div class="alert alert-warning">
                            <p>Henüz bir destek talebiniz yok. Destek sistemi üzerinde problemlerinize çözüm bulabilirsiniz.</p>
                        </div>
                    </div>
                <?php } ?>
            </div>
        </div>
    </div>
</div>

