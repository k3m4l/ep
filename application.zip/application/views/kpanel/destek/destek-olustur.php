<section class="page-background">
    <style>
        .pageBackdrop{
            background: url(<?= base_url($ayarlar->destek_bg) ?>);
        }
    </style>
    <div class="pageBackdrop"></div>
    <div class="container">
        <div>
            <img src="<?= base_url($ayarlar->destek_bg) ?>" class="sHeader">
        </div>
    </div>
</section>

<div class="pb-5 py-md-5">
    <div class="container">

        <div class="row">
            <div class="col-lg-12 col-md-8 col-12">
                <div class="card mb-4">
                    <div class="card-body">
                        <form action="<?=base_url('destekolustur')?>" method="post">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="form-label">Talep Başlığı</label>
                                        <input class="form-control" name="baslik" type="text"
                                               placeholder="Talep Başlığı">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="form-label">Sipariş Numarası <small>(İsteğe Bağlı)</small></label>
                                        <input class="form-control" name="siparis_no" type="text" placeholder="Sipariş Numarası">
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="form-label">Talep Detayı</label>
                                        <textarea class="form-control" name="detay" rows="10" type="text"
                                                  placeholder="Talep Detayı"></textarea>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <button class="btn btn-success rounded-pill">Destek Talebi Oluştur</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
