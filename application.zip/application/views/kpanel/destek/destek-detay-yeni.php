<div class="main-sr">
    <div class="container">
         <div class="row justify-content-center align-items-center">
            <div class="col-xl-9 col-lg-9 col-md-12 col-sm-12">
                <div class="go-to-back mt-3 mb-3">
                    <a href="<?php echo base_url('destek-taleplerim') ?>"><i class="fa-solid fa-angles-left"></i> Destek Taleplerime Dön</a>
                </div>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <?php if ($destek->talep_durum == 0) { ?>
                            <span class="btn btn-warning rounded-pill btn-block">Cevap Bekleniyor..</span>
                        <?php } elseif ($destek->talep_durum == 1) { ?>
                            <span class="btn btn-success rounded-pill btn-block">Cevaplandı</span>
                        <?php } elseif ($destek->talep_durum == 2) { ?>
                            <span class="btn btn-secondary rounded-pill btn-block">Kapatıldı</span>
                        <?php } ?>
                    </div>
                    <div class="col-md-6">
                        <button type="submit" class="btn btn-primary rounded-pill btn-block">
                            <?= date('d.m.Y H:i', strtotime($destek->talep_zaman)) ?>
                        </button>
                    </div>
                </div>
                <div class="card mb-4">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-<?php if (!empty($destek->siparis_no)) {
                                echo '6';
                            } else {
                                echo '12';
                            } ?>">
                                <div class="form-group">
                                    <label class="form-label">Talep Başlığı</label>
                                    <input class="form-control" type="text" value="<?= $destek->talep ?>"
                                           placeholder="Talep Başlığı" disabled>
                                </div>
                            </div>
                            <?php if (!empty($destek->siparis_no)) { ?>
                                <div class="col-md-<?php if (!empty($destek->siparis_no)) {
                                    echo '6';
                                } else {
                                    echo '12';
                                } ?>">
                                    <div class="form-group">
                                        <label class="form-label">Sipariş Numarası <small>(İsteğe
                                                Bağlı)</small></label>
                                        <input class="form-control" type="text" value="<?= $destek->siparis_no ?>"
                                               placeholder="Sipariş Numarası" disabled>
                                    </div>
                                </div>
                            <?php } ?>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label class="form-label">Talep Detayı</label>
                                    <textarea class="form-control" rows="3" type="text"
                                              placeholder="Talep Detayı"
                                              disabled><?= $destek->talep_aciklama ?></textarea>
                                </div>
                            </div>
                            <?php $this->db->where("cevap_ticket='" . $destek->talep_id . "'");
                            $this->db->order_by("cevap_id", "asc");
                            $aylik_siparis_adet = $this->db->get('talep_cevap')->result();
                            foreach ($aylik_siparis_adet as $row) {

                                ?>
                                <div class="col-md-12">
                                    <hr>
                                    <div class="form-group">
                                        <label class="form-label"><?php if ($row->cevap_user != $destek->kullanici_id) {
                                                echo "Yetkili";
                                            } else {
                                                echo 'Siz';
                                            } ?> (<?= $row->cevap_tarih ?>)</label>
                                        <textarea class="form-control" rows="3" type="text"
                                                  placeholder="Talep Cevabı"
                                                  disabled><?= $row->cevap ?></textarea>
                                    </div>
                                </div>
                            <?php } ?>

                            <div class="col-md-12">
                                <hr>
                                <form method="post">
                                    <div class="form-group">
                                        <label class="form-label">Cevap Gönder</label>
                                        <textarea class="form-control" rows="5" type="text"
                                                  placeholder="Cevap"
                                                  name="cevap"></textarea>
                                        <button type="submit" class="btn btn-block btn-primary mt-3">Cevapla
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>