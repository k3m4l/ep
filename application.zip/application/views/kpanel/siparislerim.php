<section class="col-lg-12 control-panel">

    <?php $this->load->view('kpanel/inc/kullanici_nav', array('kullanici' => $kullanici)); ?>
    
    <div class="pb-5 py-md-5">
        <div class="container">
            <div class="account-area">
                <div class="row">
                    <div class="col-lg-3 col-md-4 col-12">
                        <div class="user-img-left-area">
                            <img src="<?= base_url($kullanici->kullanici_resim) ?>" alt=""/>
                            <div>
                                <?= $kullanici->kullanici_ad ?>
                            </div>
                        </div>
                        
                        <?php $this->load->view('kpanel/inc/menu'); ?>
                    </div>
                    <div class="col-lg-9 col-md-8 col-12">

                        <section class="my-purchases">
                            <div class="container">
                                <div class="panel">
                                    <div class="panel-body">
                                        <h3 style="margin-bottom: 10px;">Siparişlerim</h3>
                                        <p>Aşağıda bulunan menüden sipariş türü seçimi yapınız. Seçim yaptıktan sonra
                                            siparişleriniz listelenecektir.<br>Detayını görmek istediğiniz siparişin
                                            üstüne
                                            tıklayınız.</p>

                                        <div class="alfa-tabs">
                                            <ul class="nav nav-tabs">
                                                <li class="nav-item active " tabindex="1" data-tab="aldigim-ilanlar"
                                                    onclick="if (!window.__cfRLUnblockHandlers) return false; updateQueryForTab('aldigim-ilanlar');onTabChange('aldigim-ilanlar');">
                                                    <a class="nav-link  active" data-toggle="tab" href="#aldiklarim">Aldığım
                                                        İlanlar </a>
                                                </li>
                                                <li class="nav-item " id="sattigim-ilanlar" tabindex="2"
                                                    data-tab="sattigim-ilanlar"
                                                    onclick="if (!window.__cfRLUnblockHandlers) return false; updateQueryForTab('sattigim-ilanlar');onTabChange('sattigim-ilanlar');">
                                                    <a class="nav-link  " data-toggle="tab" href="#sattiklarim">Sattığım
                                                        İlanlar</a>
                                                </li>
                                                <li class="nav-item " tabindex="3" data-tab="aldigim-urunler"
                                                    onclick="if (!window.__cfRLUnblockHandlers) return false; updateQueryForTab('aldigim-urunler');onTabChange('aldigim-urunler');">
                                                    <a class="nav-link  " data-toggle="tab" href="#aldigimurunler">Satın
                                                        Aldığım Ürünler</a>
                                                </li>
                                            </ul>
                                        </div>

                                        <div class="tab-content">
                                            <div id="aldiklarim" data-tab="aldigim-ilanlar"
                                                 class="tab-pane ui tab active"
                                                 style="padding:0"><br>
                                                <div class="well" id="buy-well">
                                                    <p>*Yapacağınız kelime arama <b>Sipariş
                                                            Numarası</b> , <b>İlan Başlığı</b>
                                                        üzerinde filtrelenecektir.</p>
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <p>Kelime Arama</p>
                                                            <input type="search" name="searchText"
                                                                   class="searchText form-control"
                                                                   style="margin-bottom: 10px;"
                                                                   placeholder="Filtrelenecek kelimeyi buraya yazınız.">
                                                        </div>
                                                        <div class="col-md-5">
                                                            <p>Sipariş Tarihi</p>
                                                            <input type="date" class="form-control"
                                                                   onfocus="this.showPicker()"
                                                                   name="startDate" value="">
                                                        </div>
                                                    </div>
                                                    <button type="button" class="btn btn-block btn-primary buy-filter"
                                                            data-type="buy">Filtrele
                                                    </button>
                                                </div>

                                                <div class="aldiklarimIcerik">
                                                    <div class="col-md-12 text-center" style="margin:40px 0;">
                                                        <div class="spinner-border text-light" role="status"><span
                                                                class="sr-only">Loading...</span></div>
                                                        <br><br>
                                                        <p>İçerik yükleniyor.<br>Lütfen bekleyiniz..</p>
                                                    </div>
                                                </div>
                                                <div class="ButtonArea text-center"></div>
                                            </div>

                                            <div id="sattiklarim" data-tab="sattigim-ilanlar" class="ui tab tab-pane "
                                                 style="padding:0"><br>
                                                <div class="sattiklarimIcerik">
                                                    <div class="col-md-12 text-center" style="margin:40px 0;">
                                                        <div class="spinner-border text-light" role="status"><span
                                                                class="sr-only">Loading...</span></div>
                                                        <br><br>
                                                        <p>İçerik yükleniyor.<br>Lütfen bekleyiniz..</p>
                                                    </div>
                                                </div>
                                                <div class="ButtonArea text-center"></div>
                                            </div>
                                            <div id="aldigimurunler" data-tab="aldigim-urunler"
                                                 class="container tab-pane ui tab  " style="padding:0;    width: 100%;">
                                                <br>
                                                <div class="urunlerIcerik" style="justify-content: center">
                                                    <div class="col-md-12 text-center" style="margin:40px 0;">
                                                        <div class="spinner-border text-light" role="status"><span
                                                                class="sr-only">Loading...</span></div>
                                                        <br><br>
                                                        <p>İçerik yükleniyor.<br>Lütfen bekleyiniz..</p>
                                                    </div>
                                                </div>
                                                <div class="ButtonArea text-center"></div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="modal fade" id="degerlendirmeModal" tabindex="-1" role="dialog"
                                         aria-labelledby="myModalLabel">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close"
                                                            onclick="document.getElementById('degerlendirmeModal').style.display='none'">
                                                        <span aria-hidden="true">×</span></button>
                                                    <h4 class="modal-title" id="myModalLabel">Ürün Değerlendirme</h4>
                                                </div>
                                                <form action="" method="POST" id="" class="DegerlendirmeFormNotify">
                                                    <div class="modal-body NotifyPanel">
                                                        <input type="hidden" name="urun-degerlendir-urun-id">
                                                        <input type="hidden" name="urun-degerlendir-siparis-no">
                                                        <input type="hidden" name="urun-degerlendir-magaza-id">
                                                        <p>Gerçekleştirmiş olduğunuz bu satın alma işlemini diğer
                                                            kullanıcılara tavsiye edermisiniz? Bu satın alma işleminden
                                                            ne
                                                            kadar memnun kaldınız?</p>
                                                        <p class="pull-left">Memnuniyet:</p>
                                                        <p class="pull-right" id="Memnuniyet_Puan"><b
                                                                id="Puan_' . $Data->Id . '">5</b><small> / 5</small>
                                                        </p>
                                                        <input type="range" min="1" max="5" value="5" class="slider"
                                                               name="Memnuniyet" data-id="' . $Data->Id . '">
                                                        <div style="clear:both;"></div>
                                                        <br>
                                                        <p class="pull-left">Yorumunuz:</p>
                                                        <textarea name="yorum" class="form-control" rows="4"
                                                                  maxlength="150"
                                                                  minlength="5"
                                                                  placeholder="Lütfen ürün satın alma deneyiminizi açıklayın. (Örn: Hızlı teslim edildi teşekkürler.)"
                                                                  required=""></textarea>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="submit" class="btn btn-primary btn-block">
                                                            Değerlendirmeyi Gönder
                                                        </button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php if (1 == 2) { ?>
    <div class="card mb-4">
        
        <div class="card-header border-bottom-0">
            <h3 class="h4 mb-3">Siparişlerim</h3>
        </div>

        <div class="alfa-tabs">
            <ul class="nav nav-tabs">
                <li class="nav-item active" tabindex="1" data-tab="aldigim-ilanlar"
                    onclick="if (!window.__cfRLUnblockHandlers) return false; updateQueryForTab('aldigim-ilanlar');onTabChange('aldigim-ilanlar');">
                    <a class="nav-link fetched active" data-toggle="tab" href="#aldiklarim">Aldığım İlanlar </a>
                </li>
                <li class="nav-item " tabindex="2" data-tab="sattigim-ilanlar"
                    onclick="if (!window.__cfRLUnblockHandlers) return false; updateQueryForTab('sattigim-ilanlar');onTabChange('sattigim-ilanlar');">
                    <a class="nav-link  fetched" data-toggle="tab" href="#sattiklarim">Sattığım İlanlar</a>
                </li>
                <li class="nav-item " tabindex="3" data-tab="aldigim-urunler"
                    onclick="if (!window.__cfRLUnblockHandlers) return false; updateQueryForTab('aldigim-urunler');onTabChange('aldigim-urunler');">
                    <a class="nav-link  fetched" data-toggle="tab" href="#aldigimurunler">Satın Aldığım Ürünler</a>
                </li>
            </ul>
        </div>

        
        <div class="table-responsive border-0">

            <table class="table mb-0 text-nowrap">
                <thead>
                <tr>
                    <th class="border-0">Sipariş No</th>
                    <th class="border-0">Durum</th>
                    <th class="border-0">Tutar</th>
                    <th class="border-0">Tarih</th>
                    <th class="border-0"></th>
                </tr>
                </thead>
                <tbody>
                <?php if ($siparislerim) {
                    foreach ($siparislerim as $siparis) { ?>
                        <tr>
                            <td class="align-middle border-top-0">
                                <a data-toggle="tooltip" data-placement="top" title="Sipariş Detayı"
                                   href="<?= base_url('siparis-detay/' . $siparis->siparis_no) ?>">#<?= $siparis->siparis_no ?></a>
                            </td>
                            <td class="align-middle border-top-0">
                                <?php if ($siparis->siparis_epin == 1) : ?>
                                    <span class="badge badge-success">Sipariş Teslim Edildi</span>
                                <?php elseif ($siparis->siparis_epin == 2) : ?>
                                    <span class="badge badge-danger">Sipariş Bekleniyor</span>
                                <?php else : ?>
                                    <?php if ($siparis->siparis_durum == 0) { ?>
                                        <?php if ($ayarlar->iyzico_durum == '1') { ?>
                                            <a target="_blank"
                                               href="<?= base_url('odeme/iyzico/' . $siparis->siparis_no) ?>"
                                               class="badge badge-warning btn-iyzico">İyzico İle Öde</a>
                                        <?php } ?>
                                        <?php if ($ayarlar->paytr_durum == '1') { ?>
                                            <a target="_blank"
                                               href="<?= base_url('odeme/paytr/' . $siparis->siparis_no) ?>"
                                               class="badge badge-warning btn-paytr">Paytr İle Öde</a>
                                        <?php } ?>
                                        <a data-url="<?= base_url('siparis-bakiye-odeme/' . $siparis->siparis_no) ?>"
                                           href="javascript:void(0)" class="badge badge-secondary ode-btn">Bakiye İle
                                            Öde</a>
                                    <?php } elseif ($siparis->siparis_durum == 1) { ?>
                                        <a href="javascript:void(0)" class="badge badge-secondary" data-toggle="modal"
                                           data-target="#odeme_onay_<?= $siparis->siparis_id ?>">Teslimatı
                                            Onaylayın
                                        </a>
                                    <?php } elseif ($siparis->siparis_durum == 2) { ?>
                                        <span class="badge badge-success">Ödeme Yapıldı</span>
                                    <?php } elseif ($siparis->siparis_durum == 3) { ?>
                                        <span data-toggle="tooltip" data-placement="top"
                                              title="<?= $siparis->siparis_iptal ?>" class="badge badge-danger">Sipariş İptal Edildi</span>
                                    <?php } ?>
                                <?php endif; ?>
                            </td>
                            <td class="align-middle border-top-0"><?= $siparis->siparis_tutar ?>₺</td>
                            <td class="align-middle border-top-0"><?= date('d.m.Y H:m', strtotime($siparis->siparis_tarih)) ?></td>
                            <td class="align-middle border-top-0">
                                <?php if ($siparis->siparis_epin == 1) : ?>
                                    <a href="<?= base_url('siparis-detay/' . $siparis->siparis_no) ?>"
                                       class="btn btn-primary btn-sm" data-toggle="tooltip" data-placement="top"
                                       title="Görüntüle">
                                        <i class="fe fe-eye"></i>
                                    </a>
                                <?php elseif ($siparis->siparis_epin == 2) : ?>
                                    <a href="<?= base_url('siparis-detay/' . $siparis->siparis_no) ?>"
                                       class="btn btn-primary btn-sm" data-toggle="tooltip" data-placement="top"
                                       title="Görüntüle">
                                        <i class="fe fe-eye"></i>
                                    </a>
                                <?php else : ?>
                                    <a href="<?= base_url('siparis-detay/' . $siparis->siparis_no) ?>"
                                       class="btn btn-primary btn-sm" data-toggle="tooltip" data-placement="top"
                                       title="Görüntüle">
                                        <i class="fe fe-eye"></i>
                                    </a>
                                <?php endif; ?>
                                <?php if ($siparis->siparis_durum == 2) { ?>
                                    <a href="<?= base_url('fatura/' . $siparis->siparis_no) ?>"
                                       class="btn btn-secondary btn-sm" data-toggle="tooltip" data-placement="top"
                                       title="Fatura">
                                        <i class="fe fe-file-text"></i>
                                    </a>
                                    <a href="javascript:void(0)" data-toggle="modal"
                                       data-target="#yorum_<?= $siparis->siparis_id ?>" class="btn btn-warning btn-sm"
                                       data-toggle="tooltip" data-placement="top" title="Değerlendir">
                                        <i class="text-light fe fe-star"></i>
                                    </a>
                                <?php } ?>
                                <?php if ($siparis->urun_turu == 3) {
                                    if ($siparis->siparis_durum == 1 || $siparis->siparis_durum == 2) { ?>
                                        <a href="<?= base_url('indir/' . $siparis->siparis_no) ?>"
                                           class="btn btn-success btn-sm" data-toggle="tooltip" data-placement="top"
                                           title="İndir">
                                            <i class="fe fe-download-cloud"></i>
                                        </a>
                                    <?php }
                                }
                                if ($siparis->ticket != "") { ?>
                                    <a href="<?= base_url('destek-detay/' . $siparis->ticket) ?>"
                                       class="btn btn-info btn-sm" data-toggle="tooltip" data-placement="top"
                                       title="Destek">
                                        <i class="fa fa-life-ring"></i>
                                    </a>
                                <?php } ?>

                            </td>
                        </tr>
                        <?php if ($siparis->siparis_durum == 1) { ?>
                            <div class="modal fade" id="odeme_onay_<?= $siparis->siparis_id ?>" tabindex="-1"
                                 role="dialog"
                                 aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog modal-dialog-centered" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="exampleModalLabel">Teslimat Onay
                                                Bilgilendirme</h5>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <div class="modal-body text-center">
                                            <span
                                                class="badge badge-warning mb-2">SİPARİŞ NO : <?= $siparis->siparis_no ?></span>
                                            <p class="text-center">Teslimatta her hangi bir sıkıntı
                                                yaşamadıysanız satıcının ödemesini onaylamanız
                                                gerekmektedir!
                                                Onaylamadığınız taktirde sistem otomatik olarak <span
                                                    class="badge badge-success badge-pill">1 gün</span>
                                                sonra onaylayacaktır. Teslimatı onaylamak için sipariş
                                                detayına gidin.</p>
                                            <a href="<?= base_url('siparis-detay/' . $siparis->siparis_no) ?>"
                                               class="btn btn-outline-primary btn-block input-radius"><i
                                                    class="fe fe-eye"></i> Sipariş Detayı</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                        <?php if ($siparis->siparis_durum == 2) { ?>
                            <div class="modal fade" id="yorum_<?= $siparis->siparis_id ?>" tabindex="-1" role="dialog"
                                 aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog modal-dialog-centered" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="exampleModalLabel">Siparişi
                                                Değerlendirin</h5>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <div class="modal-body text-center">
                                            <?php if (yorum_kontrol($kullanici->kullanici_id, $siparis->siparis_no) != 0) {
                                                $yorum = yorum($kullanici->kullanici_id, $siparis->siparis_no); ?>
                                                <?php if ($yorum->yorum_durum == 0) { ?>
                                                    <button class="btn btn-outline-warning btn-block rounded-pill">
                                                        Onay
                                                        Bekleniyor..
                                                    </button>
                                                <?php } elseif ($yorum->yorum_durum == 1) { ?>
                                                    <button class="btn btn-success btn-block rounded-pill">
                                                        Değerlendirme Yayınlandı
                                                    </button>
                                                <?php } elseif ($yorum->yorum_durum == 2) { ?>
                                                    <button class="btn btn-danger btn-block rounded-pill">
                                                        Onaylanmadı
                                                    </button>
                                                <?php } ?>
                                                <div id="full-stars-example-two">
                                                    <div class="rating-group">
                                                        <input class="rating__input rating__input--none" name="puan"
                                                               id="rating3-none" value="0"
                                                               type="radio" <?php if ($yorum->yorum_durum == 0) {
                                                            echo 'checked';
                                                        } ?> disabled>
                                                        <label aria-label="1 star" class="rating__label"
                                                               for="rating3-1"><i
                                                                class="rating__icon rating__icon--star fa fa-star"></i></label>
                                                        <input class="rating__input" name="puan" id="rating3-1"
                                                               value="1"
                                                               type="radio" <?php if ($yorum->yorum_puan == 1) {
                                                            echo 'checked';
                                                        } ?> disabled>
                                                        <label aria-label="2 stars" class="rating__label"
                                                               for="rating3-2"><i
                                                                class="rating__icon rating__icon--star fa fa-star"></i></label>
                                                        <input class="rating__input" name="puan" id="rating3-2"
                                                               value="2"
                                                               type="radio" <?php if ($yorum->yorum_puan == 2) {
                                                            echo 'checked';
                                                        } ?> disabled>
                                                        <label aria-label="3 stars" class="rating__label"
                                                               for="rating3-3"><i
                                                                class="rating__icon rating__icon--star fa fa-star"></i></label>
                                                        <input class="rating__input" name="puan" id="rating3-3"
                                                               value="3"
                                                               type="radio" <?php if ($yorum->yorum_puan == 3) {
                                                            echo 'checked';
                                                        } ?> disabled>
                                                        <label aria-label="4 stars" class="rating__label"
                                                               for="rating3-4"><i
                                                                class="rating__icon rating__icon--star fa fa-star"></i></label>
                                                        <input class="rating__input" name="puan" id="rating3-4"
                                                               value="4"
                                                               type="radio" <?php if ($yorum->yorum_puan == 4) {
                                                            echo 'checked';
                                                        } ?> disabled>
                                                        <label aria-label="5 stars" class="rating__label"
                                                               for="rating3-5"><i
                                                                class="rating__icon rating__icon--star fa fa-star"></i></label>
                                                        <input class="rating__input" name="puan" id="rating3-5"
                                                               value="5"
                                                               type="radio" <?php if ($yorum->yorum_puan == 5) {
                                                            echo 'checked';
                                                        } ?> disabled>
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label>Yorumunuz <small>(İsteğe Bağlı)</small></label>
                                                    <textarea class="form-control" rows="5" placeholder="Yorumunuz.."
                                                              disabled><?= $yorum->yorum_detay ?></textarea>
                                                </div>

                                            <?php } else { ?>
                                                <form action="<?= base_url('yorum-yap/' . $siparis->siparis_no) ?>"
                                                      method="post">
                                                    <div id="full-stars-example-two">
                                                        <div class="rating-group">
                                                            <input checked class="rating__input rating__input--none"
                                                                   name="puan" id="rating3-none" value="0" type="radio">
                                                            <label aria-label="1 star" class="rating__label"
                                                                   for="rating3-1-<?= $siparis->siparis_id ?>"><i
                                                                    class="rating__icon rating__icon--star fa fa-star"></i></label>
                                                            <input class="rating__input" name="puan"
                                                                   id="rating3-1-<?= $siparis->siparis_id ?>" value="1"
                                                                   type="radio">
                                                            <label aria-label="2 stars" class="rating__label"
                                                                   for="rating3-2-<?= $siparis->siparis_id ?>"><i
                                                                    class="rating__icon rating__icon--star fa fa-star"></i></label>
                                                            <input class="rating__input" name="puan"
                                                                   id="rating3-2-<?= $siparis->siparis_id ?>" value="2"
                                                                   type="radio">
                                                            <label aria-label="3 stars" class="rating__label"
                                                                   for="rating3-3-<?= $siparis->siparis_id ?>"><i
                                                                    class="rating__icon rating__icon--star fa fa-star"></i></label>
                                                            <input class="rating__input" name="puan"
                                                                   id="rating3-3-<?= $siparis->siparis_id ?>" value="3"
                                                                   type="radio">
                                                            <label aria-label="4 stars" class="rating__label"
                                                                   for="rating3-4-<?= $siparis->siparis_id ?>"><i
                                                                    class="rating__icon rating__icon--star fa fa-star"></i></label>
                                                            <input class="rating__input" name="puan"
                                                                   id="rating3-4-<?= $siparis->siparis_id ?>" value="4"
                                                                   type="radio">
                                                            <label aria-label="5 stars" class="rating__label"
                                                                   for="rating3-5-<?= $siparis->siparis_id ?>"><i
                                                                    class="rating__icon rating__icon--star fa fa-star"></i></label>
                                                            <input class="rating__input" name="puan"
                                                                   id="rating3-5-<?= $siparis->siparis_id ?>" value="5"
                                                                   type="radio">
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label>Yorumunuz <small>(İsteğe
                                                                Bağlı)</small></label>
                                                        <textarea name="yorum" class="form-control" rows="5"
                                                                  placeholder="Yorumunuz.."></textarea>
                                                    </div>
                                                    <button type="submit"
                                                            class="btn btn-outline-primary btn-block input-radius">
                                                        <i class="fe fe-comment"></i> Yorumu Paylaş
                                                    </button>
                                                </form>
                                            <?php } ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                    <?php }
                } else { ?>
                    <tr>
                        <td colspan="6" align="center">
                            <div class="notification warning closeable">
                                <p>Sipariş Bulunamadı</p>
                            </div>
                        </td>
                    </tr>
                <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
    <?= $links ?>

<?php } ?>

</div>
</div>
</div>
</div>
</section>
<script type="text/javascript">
    var BreadcrumbInitialList = [{"name": "Ana Sayfa", "link": "\/"}, {
        "name": "Sipari\u015flerim",
        "link": "\/siparislerim"
    }];
    var BreadcrumbNames = {
        "aldigim-ilanlar": "Ald\u0131\u011f\u0131m \u0130lanlar",
        "sattigim-ilanlar": "Satt\u0131\u011f\u0131m \u0130lanlar",
        "aldigim-urunler": "Ald\u0131\u011f\u0131m \u00dcr\u00fcnler"
    };
    var ActiveTab = "aldigim-ilanlar";
</script>
