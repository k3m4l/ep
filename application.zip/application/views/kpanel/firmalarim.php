<?php $kullanici = aktif_kullanici(); ?>
<?php $firmalar = firmalar(100,$kullanici->kullanici_id); ?>
<div id="dashboard">

	<!-- Navigation
	================================================== -->

	<!-- Responsive Navigation Trigger -->
	<a href="#" class="dashboard-responsive-nav-trigger"><i class="fa fa-reorder"></i> Navigation</a>

	<?php $this->load->view("kpanel/inc/menu"); ?>
	<!-- Navigation / End -->


	<!-- Content
	================================================== -->
	<div class="dashboard-content">

		<!-- Titlebar -->
		<div id="titlebar">
			<div class="row">
				<div class="col-md-12">
					<h2>Firmalarım</h2>
					<!-- Breadcrumbs -->
					<nav id="breadcrumbs">
						<ul>
							<li><a href="<?=base_url()?>">Anasayfa</a></li>
							<li><a href="<?=base_url("kullanici-paneli")?>">Kullanıcı Paneli</a></li>
							<li>Firmalarım</li>
						</ul>
					</nav>
				</div>
			</div>
		</div>

		<div class="row">
			
			<!-- Listings -->
				<div class="col-lg-12 col-md-12">
					<div class="notification warning closeable text-center">
					<p><span>DİKKAT!</span> Firma silme işlemi için site yönetimine mesaj gönderin.</p>
				</div>
				<div class="dashboard-list-box margin-top-0">
					<ul>

						<?php foreach ($firmalar as $key) { ?>
							<?php $yorumpuan = yorumpsay($key->firma_id); ?>
							<li>
								<div class="list-box-listing">
									<div class="list-box-listing-img"><a href="<?=base_url("firma/").$key->firma_seo?>"><img src="<?=base_url($key->firma_resim)?>" alt="<?=$key->firma_ad?>"></a></div>
									<div class="list-box-listing-content">
										<div class="inner">
											<h3><?=$key->firma_ad?></h3>
											<span><?=$key->firma_adres?></span>
											<div class="star-rating" data-rating="<?=$yorumpuan->yorum_puan?>">
												<div class="rating-counter">(<?php echo yorumsaydir($key->firma_id); ?> yorum)</div>
											</div>
										</div>
									</div>
								</div>
								<div class="buttons-to-right">
									<a href="<?=base_url("firma-duzenle/").$key->firma_uniq?>" class="button gray"><i class="sl sl-icon-note"></i> Düzenle</a>
									<a href="<?=base_url("firma-galeri/").$key->firma_uniq?>" class="button"><i class="im im-icon-Photos"></i> Galeri</a>
								</div>
							</li>
						<?php } ?>
					</ul>
				</div>
			</div>

		</div>

		<?php $this->load->view("kpanel/inc/footer"); ?>

	</div>
	<!-- Content / End -->


</div>
<!-- Dashboard / End -->


</div>