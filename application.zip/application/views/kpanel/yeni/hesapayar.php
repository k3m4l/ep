<main class="k-panel-warper">
    <div class="sec-warper mb-4">
        <div class="container normal-container p-0">
            <div class="k-panel-g-warper">
                <div class="row">
                    <div class="col-xl-3 col-lg-3 col-md-12 col-sm-12 wd-none mt-3 p-0 ">
                        <div class="accordion accordion-flush acc-kpc-menu" id="accordionFlushExample">
                            <div class="accordion-item acc-kpc-menu-item">
                                <h2 class="accordion-header acc-kpc-menu-header" id="flush-headingOne">
                                    <button class="accordion-button collapsed acc-kpc-menu-btn" type="button"
                                            data-bs-toggle="collapse" data-bs-target="#flush-collapseOne"
                                            aria-expanded="false" aria-controls="flush-collapseOne">
                                        Hızlı Menü
                                    </button>
                                </h2>
                                <div id="flush-collapseOne" class="accordion-collapse collapse"
                                     aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
                                    <div class="accordion-body acc-kpc-menu-body">
                                        <div class="k-panel-left-navbar-warper">
                                            <div class="k-panel-left-navbar-area">
                                                <div class="nav flex-column nav-pills bg-custom-none " id="v-pills-tab" role="tablist"
                                                    aria-orientation="vertical">
                                                <?php if (magaza_check()) { ?>
                                                        <div class="gt-store">
                                                            <a href="<?php echo base_url('m/'.magaza($kullanici->kullanici_id)->magaza_seo) ?>" class="btn btn-primary settings-btn mb-3 w-100">Mağzaya Git</a>
                                                        </div>
                                                    <?php } ?>
                                                    <a href="<?php echo base_url('hesabim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100">Profilim</a>
                                                    <a href="<?php echo base_url('siparislerim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100">Siparişlerim</a>
                                                    <a href="<?php echo base_url('satislar') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100">Gold Al - Sat</a>
                                                    <a href="<?php echo base_url('sorularim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100">Sorularım</a>
                                                    <a href="<?php echo base_url('bakiye') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100">Bakiye</a>
                                                    <a href="<?php echo base_url('odeme-talep') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100">Para Çek</a>
                                                    <a href="<?php echo base_url('destek-taleplerim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100">Destek Taleplerim</a>
                                                    <a href="<?php echo base_url('itirazlarim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100">İtirazlarım</a>
                                                    <a href="<?php echo base_url('hesap-ayarlari') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100 active">Profil Ayarlarım</a>
                                                    <a class="nav-link kpc-nav-btn w-spacial w-100" href="<?php echo base_url('cikis') ?>">Çıkış</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-3 col-md-12 col-sm-12 md-none pr-0">
                        <div class="k-panel-left-navbar-warper m-bg2">
                            <div class="k-panel-left-navbar-area">
                                <div class="nav flex-column nav-pills bg-custom-none " id="v-pills-tab" role="tablist"
                                     aria-orientation="vertical">
                                   <?php if (magaza_check()) { ?>
                                        <div class="gt-store">
                                            <a href="<?php echo base_url('m/'.magaza($kullanici->kullanici_id)->magaza_seo) ?>" class="btn btn-primary settings-btn mb-3 w-100">Mağzaya Git</a>
                                        </div>
                                    <?php } ?>
                                    <a href="<?php echo base_url('hesabim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"> <img class="sw-icon-item" src="<?php echo base_url('assets/front/images/uzer.webp') ?>" alt="" loading="lazy">Profilim</a>
                                    <a href="<?php echo base_url('siparislerim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"><img class="sw-icon-item" src="<?php echo base_url('assets/front/images/shopping-list.webp') ?>" alt="" loading="lazy">Siparişlerim</a>
                                    <a href="<?php echo base_url('satislar') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"><img class="sw-icon-item" src="<?php echo base_url('assets/front/images/gold.webp') ?>" alt="" loading="lazy">Gold Al - Sat</a>
                                    <a href="<?php echo base_url('sorularim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"><img class="sw-icon-item" src="<?php echo base_url('assets/front/images/s4.png') ?>" alt="" loading="lazy">Sorularım</a>
                                    <a href="<?php echo base_url('bakiye') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"><img class="sw-icon-item" src="<?php echo base_url('assets/front/images/salary.webp') ?>" alt="" loading="lazy">Bakiye</a>
                                    <a href="<?php echo base_url('odeme-talep') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"><img class="sw-icon-item" src="<?php echo base_url('assets/front/images/transfer.webp') ?>" alt="" loading="lazy">Para Çek</a>
                                    <a href="<?php echo base_url('destek-taleplerim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"><img class="sw-icon-item" src="<?php echo base_url('assets/front/images/customer-service.webp') ?>" alt="" loading="lazy">Destek Sistemi</a>
                                    <a href="<?php echo base_url('itirazlarim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"><img class="sw-icon-item" src="<?php echo base_url('assets/front/images/error.webp') ?>" alt="" loading="lazy">İtirazlarım</a>
                                    <a href="<?php echo base_url('hesap-ayarlari') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100 active"><img class="sw-icon-item" src="<?php echo base_url('assets/front/images/s1.png') ?>" alt="" loading="lazy">Profil Ayarlarım</a>
                                    <a class="nav-link kpc-nav-btn w-spacial w-100" href="<?php echo base_url('cikis') ?>"><img class="sw-icon-item" src="<?php echo base_url('assets/front/images/logout.webp') ?>" alt="" loading="lazy">Çıkış</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-9 col-lg-9 col-md-12 col-sm-12 m-bg m-br">
                        <div class="k-panel-content-right">
                            <div class="tab-content" id="v-pills-tabContent">
                                <div class="tab-pane fade show active" id="account-settings" role="tabpanel"
                                     aria-labelledby="account-settings-tab" tabindex="0">
                                    <div class="container-fluid">
                                        <div class="k-panel-content-box">
                                            <div class="row">
                                                <div class="col-12">
                                                    <div class=" bg-none mb-4">
                                                        <div class="card-body pt-0">
                                                            <div class="row align-items-center">
                                                                <div class="col-lg-6 col-md-12">
                                                                    <div class="dashboard-list-box margin-top-0">
                                                                        <div class="dashboard-list-box-static">
                                                                            <form method="post"
                                                                                  action="<?= base_url("kullanicibilgi") ?>"
                                                                                  enctype="multipart/form-data">
                                                                                <!-- Avatar -->
                                                                                <div class="d-flex flex-wrap">
                                                                                    <div class="avatar-upload">
                                                                                            <span class="upload-setting-span">Profil
                                                                                                Fotoğrafı</span>
                                                                                        <div class="avatar-edit">
                                                                                            <input type='file'
                                                                                                   id="imageUpload"
                                                                                                   name="file"
                                                                                                   accept=".png, .jpg, .jpeg"/>
                                                                                            <label
                                                                                                    for="imageUpload"></label>
                                                                                        </div>
                                                                                        <div class="avatar-preview">

                                                                                            <?php if (strpos($kullanici->kullanici_resim, "/.jpg") !== false) { ?>
                                                                                                <div id="imagePreview"
                                                                                                     style="background-image: url(https://ui-avatars.com/api/?name=<?= $kullanici->kullanici_isim ?>+<?= $kullanici->kullanici_soyisim ?>&background=0D8ABC&color=fff">
                                                                                                </div>
                                                                                            <?php } else { ?>
                                                                                                <div id="imagePreview"
                                                                                                     style="background-image: url(<?= base_url($kullanici->kullanici_resim) ?>);">
                                                                                                </div>
                                                                                            <?php } ?>

                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="row">
                                                                                    <div
                                                                                            class="form-group col-12 col-md-12">
                                                                                        <label
                                                                                                class="form-label">Kullanıcı
                                                                                            Adı</label>
                                                                                        <input type="text"
                                                                                               class="form-control"
                                                                                               placeholder="Adınız"
                                                                                               value="<?= $kullanici->kullanici_ad ?>"
                                                                                               required="" readonly>
                                                                                    </div>
                                                                                    <div
                                                                                            class="form-group col-12 col-md-6">
                                                                                        <label
                                                                                                class="form-label">Adınız</label>
                                                                                        <input type="text" name="ad"
                                                                                               class="form-control"
                                                                                               placeholder="Adınız"
                                                                                               value="<?= $kullanici->kullanici_isim ?>"
                                                                                               required="">
                                                                                    </div>

                                                                                    <div
                                                                                            class="form-group col-12 col-md-6">
                                                                                        <label
                                                                                                class="form-label">Soyadınız</label>
                                                                                        <input type="text"
                                                                                               name="soyad"
                                                                                               class="form-control"
                                                                                               placeholder="Soyadınız"
                                                                                               value="<?= $kullanici->kullanici_soyisim ?>"
                                                                                               required="">
                                                                                    </div>

                                                                                    <div
                                                                                            class="form-group col-12 col-md-12">
                                                                                        <label
                                                                                                class="form-label">E-Posta
                                                                                            Adresi</label>
                                                                                        <input type="text"
                                                                                               class="form-control"
                                                                                               placeholder="E-Posta Adresi"
                                                                                               value="<?= $kullanici->kullanici_mail ?>"
                                                                                               disabled>
                                                                                    </div>
                                                                                    <div
                                                                                            class="form-group col-9 col-md-9">
                                                                                        <label
                                                                                                class="form-label">Telefon</label>
                                                                                        <input type="number"
                                                                                               id="accountPhone"
                                                                                               name="telefon"
                                                                                               class="form-control"
                                                                                               placeholder="05XXXXXXXXX"
                                                                                               value="<?= $kullanici->kullanici_tel ?>"
                                                                                               required="">
                                                                                    </div>
                                                                                    <script>
                                                                                        $(document).ready(
                                                                                            function () {
                                                                                                $('#accountPhone').on('input', function () {
                                                                                                        var value = $(this).val();
                                                                                                            value = value.replace(/\D/g, ''); // Sadece sayıları al
                                                                                                            if (value.charAt(0) !== '0') {
                                                                                                                // Başında 0 yoksa otomatik ekle
                                                                                                                value = '0' + value;
                                                                                                            }
                                                                                                            // 11 karakteri geçmemesi için kontrol
                                                                                                            if (value.length > 11) {
                                                                                                                // 11 karakterden fazla ise son eklenen karakteri kaldır
                                                                                                                value = value.slice(0, 11);
                                                                                                            }
                                                                                                            // Telefon numarasını formatla
                                                                                                            var formattedValue = value.replace(/(\d{4})(\d{3})(\d{4})/, '$1 $2 $3');
                                                                                                            $(this).val(value);
                                                                                                        }
                                                                                                    );
                                                                                            });
                                                                                    </script>
                                                                                    <?php if ($kullanici->tel_dogrulama == 0) { ?>
                                                                                        <div class="form-group col-3 col-md-3 mt-3">
                                                                                            <button type="button"
                                                                                                    class="btn btn-danger mt-3 tel-dogrula-button"
                                                                                                    data-toggle="modal"
                                                                                                    data-target="#teldogrula"
                                                                                                    data-id="<?php echo $kullanici->kullanici_id ?>">
                                                                                                Doğrula
                                                                                            </button>
                                                                                        </div>
                                                                                    <?php } else { ?>
                                                                                        <div class="form-group col-3 col-md-3 mt-3">
                                                                                            <button type="button" class="btn btn-success mt-3">
                                                                                                Doğrulandı
                                                                                            </button>
                                                                                        </div>
                                                                                    <?php } ?>
                                                                                    <?php if (1 == 2) { ?>
                                                                                        <hr>
                                                                                        <h4>Fatura Bilgileri
                                                                                        </h4>
                                                                                        <div class="form-group col-12 col-md-12">
                                                                                            <label class="form-label">Adres</label>
                                                                                            <textarea class="form-control"
                                                                                                    name="adres"
                                                                                                    id="adres"
                                                                                                    rows="5"
                                                                                                    placeholder="Adres"
                                                                                                    required><?= $kullanici->kullanici_adres ?></textarea>
                                                                                        </div>

                                                                                        <div class="form-group col-12 col-md-6">
                                                                                            <label class="form-label">Şehir</label>
                                                                                            <select id="ilsec"
                                                                                                    name="sehir"
                                                                                                    class="form-control input-radius"
                                                                                                    data-width="100%"
                                                                                                    required>
                                                                                                <option value="">
                                                                                                    Lütfen
                                                                                                    Seçiniz...
                                                                                                </option>
                                                                                                <?php if ($iller) {
                                                                                                    foreach ($iller as $il) { ?>
                                                                                                        <option
                                                                                                            <?= $kullanici->kullanici_sehir === $il->id ? 'selected' : '' ?>
                                                                                                                value="<?= $il->id ?>">
                                                                                                            <?= $il->il_adi ?>
                                                                                                        </option>
                                                                                                    <?php }
                                                                                                } ?>
                                                                                            </select>
                                                                                        </div>
                                                                                        <!-- Country  -->
                                                                                        <div class="form-group col-12 col-md-6">
                                                                                            <label class="form-label">İlçe</label>
                                                                                            <select id="ilsechesap"
                                                                                                    name="ilce"
                                                                                                    class="form-control input-radius"
                                                                                                    data-width="100%"
                                                                                                    required>
                                                                                                <option>Lütfen
                                                                                                    Şehir
                                                                                                    Seçiniz..
                                                                                                </option>
                                                                                            </select>
                                                                                        </div>
                                                                                    <?php } ?>
                                                                                </div>
                                                                                <button type="submit"
                                                                                        class="btn btn-primary rounded-pill mt-3">
                                                                                    Bilgileri Güncelle
                                                                                </button>
                                                                            </form>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-lg-6 col-md-12">
                                                                    <div class="dashboard-list-box c-stand">
                                                                        <h4 class="gray">Şifre Değiştir</h4>
                                                                        <div class="dashboard-list-box-static">
                                                                            <form method="post"
                                                                                  action="<?= base_url("sifre-degistir") ?>">
                                                                                <div class="row">
                                                                                    <div class="form-group col-12 col-md-12">
                                                                                        <label class="form-label">Eski
                                                                                            Şifre</label>
                                                                                        <input type="text"
                                                                                               name="eski"
                                                                                               class="form-control"
                                                                                               placeholder="Eski Şifre"
                                                                                               required="">
                                                                                    </div>
                                                                                    <div class="form-group col-12 col-md-12">
                                                                                        <label class="form-label">Yeni
                                                                                            Şifre</label>
                                                                                        <input type="text"
                                                                                               name="yeni"
                                                                                               class="form-control"
                                                                                               placeholder="Yeni Şifre"
                                                                                               required="">
                                                                                    </div>
                                                                                    <div class="form-group col-12 col-md-12">
                                                                                        <label class="form-label">Eski
                                                                                            Şifre</label>
                                                                                        <input type="text"
                                                                                               name="tekrar"
                                                                                               class="form-control"
                                                                                               placeholder="Yeni Şifre Tekrar"
                                                                                               required="">
                                                                                    </div>
                                                                                </div>
                                                                                <button type="submit"
                                                                                        class="btn btn-primary rounded-pill mt-3">
                                                                                    Şifre
                                                                                    Değiştir
                                                                                </button>
                                                                            </form>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<div class="modal fade" id="teldogrula_step_1" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
     aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content sms">
            <div class="modal-header">
                <h4 class="modal-title text-center" id="exampleModalCenterTitle">Telefon Doğrulama</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="tel-dogrula-alert">
                <div class="alert alert-danger alert-dismissible text-left alert-grid" role="alert">
                    <i class="fas fa-check"></i>
                    <div><strong>Doğrulama Gerekiyor</strong><br>
                        Ödeme bildirimi oluşturabilmek için telefon numaranızı doğrulamanız gerekmektedir.
                    </div>
                </div>
            </div>
            <div class="p-2">
                <div class="row">
                    <div class="col-12">
                        <label class="form-label">Telefon No</label>
                        <input type="text" class="form-control" name="telefon" id="telefon" value="0" maxlength="11">
                    </div>
                </div>
                <div class="py-2">
                    <button type="button" class="btn btn-primary rounded-pill tel-dogrula-button w-100"
                            data-id="<?php echo $kullanici->kullanici_id ?>">SMS Gönder
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="teldogrula" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
     aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content sms">
            <div class="modal-header">
                <h4 class="modal-title text-center" id="exampleModalCenterTitle">Telefon Doğrulama</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="tel-dogrula-alert">
                <div class="alert alert-success alert-dismissible text-left alert-grid" role="alert">
                    <i class="fas fa-check"></i>
                    <div><strong>Başarılı</strong><br>
                        Doğrulama Kodunuz Başarılı Şekilde Gönderilmiştir. Lütfen Aşağıda ki alana kodu giriniz.
                    </div>
                </div>
            </div>
            <style>
                #countdown {
                    display: none;
                    font-size: 15px;
                    margin-left: 5px;
                    margin-top: 7px;
                }

                .countdown-area {
                    display: flex;
                    margin-top: 5px;
                    margin-bottom: 10px;
                }
            </style>
            <form class="p-2 tel-dogrulama-form" method="post">
                <div class="row">
                    <div class="col-12">
                        <label class="form-label">Doğrulama Kodu</label>
                        <input type="text" class="form-control" name="tel_dogrulama">
                    </div>
                </div>
                <div class="py-2">
                    <div class="countdown-area">
                        <button id="sendSMS" type="button" data-id="<?php echo $kullanici->kullanici_id ?>"
                                class="btn btn-warning rounded-pill">SMS Gönder
                        </button>
                        <div id="countdown"></div>
                    </div>
                    <button type="submit" class="btn btn-primary rounded-pill soru-sor-btn w-100">Doğrula</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    var countdownTimer;
    var countdownDuration = 60; // 60 saniye

    function startCountdown() {
        $("#sendSMS").prop("disabled", true);
        $("#countdown").show();

        countdownTimer = setInterval(function () {
            $("#countdown").text("Kalan süre: " + countdownDuration + " saniye");

            if (countdownDuration === 0) {
                clearInterval(countdownTimer);
                $("#sendSMS").prop("disabled", false);
                $("#countdown").hide();
            } else {
                countdownDuration--;
            }
        }, 1000);
    }

    function resetCountdown() {
        clearInterval(countdownTimer);
        countdownDuration = 60;
        $("#sendSMS").prop("disabled", true);
        startCountdown();
    }

    // Sayfa yüklendiğinde otomatik geri sayım başlat
    //startCountdown();

    $("#sendSMS").click(function () {
        // Eğer geri sayım başlamamışsa başlat
        if (countdownDuration === 60) {
            startCountdown();
            var user = $(this).data('id');
            $.ajax({
                type: "POST",
                url: base_url + "ajax_controller/tel_dogrulama_resend",
                data: {
                    kullanici: user,
                    telefon: $("#telefon").val()
                },
                success: function (data) {
                    var d = JSON.parse(data);
                    if (d.status.status == 'success') {
                        startCountdown();
                        $(".tel-dogrula-alert").html(d.status.alert_html);
                    } else {
                        $(".tel-dogrula-alert").html(d.status.alert_html);
                    }
                }
            });
        } else {
            // Eğer geri sayım başlamışsa sıfırla ve tekrar başlat
            resetCountdown();
            var user = $(this).data('id');
            $.ajax({
                type: "POST",
                url: base_url + "ajax_controller/tel_dogrulama_resend",
                data: {
                    kullanici: user,
                    telefon: $("#telefon").val()
                },
                success: function (data) {
                    var d = JSON.parse(data);
                    if (d.status.status == 'success') {
                        startCountdown();
                        $(".tel-dogrula-alert").html(d.status.alert_html);
                    } else {
                        $(".tel-dogrula-alert").html(d.status.alert_html);
                    }
                }
            });
        }

        // Burada SMS gönderme işlemlerini gerçekleştirebilirsiniz.
    });


    $('.tel-dogrula-button').on('click', function () {
        var user = $(this).data('id');
        $.ajax({
            type: "POST",
            url: base_url + "ajax_controller/tel_dogrulama",
            data: {
                kullanici: user,
                telefon: $("#telefon").val()
            },
            success: function (data) {
                var d = JSON.parse(data);
                $("#teldogrula_step_1").modal("hide");
                $("#teldogrula").modal("show");
                if (d.status.status == 'success') {
                    startCountdown();
                    $(".tel-dogrula-alert").html(d.status.alert_html);
                } else {
                    $(".tel-dogrula-alert").html(d.status.alert_html);
                }
            }
        });

    });

    $('.tel-dogrulama-form').on('submit', function () {
        var kod = $('input[name="tel_dogrulama"]').val();
        $.ajax({
            type: "POST",
            url: base_url + "ajax_controller/tel_kod_dogrulama",
            data: {
                code: kod,
            },
            success: function (data) {
                var d = JSON.parse(data);
                if (d.status.status == 'success') {
                    Swal.fire(
                        'Başarılı!',
                        d.status.message,
                        d.status.status,
                    );
                    setTimeout(
                        function () {
                            window.location.reload();
                        }, 2000);
                } else {
                    Swal.fire(
                        'Hata!',
                        d.status.message,
                        d.status.status,
                    );
                }
            }
        });

    });
</script>
<div class="modal fade" id="teldogrula" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
     aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content sms">
            <div class="modal-header">
                <h4 class="modal-title text-center" id="exampleModalCenterTitle">Satıcıya Soru Sor</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="tel-dogrula-alert">
                <div class="alert alert-success alert-dismissible text-left alert-grid" role="alert">
                    <i class="fas fa-check"></i>
                    <div><strong>Başarılı</strong><br>
                        Doğrulama Kodunuz Başarılı Şekilde Gönderilmiştir. Lütfen Aşağıda ki alana kodu giriniz.
                    </div>
                </div>
            </div>
            <style>
                #countdown {
                    display: none;
                    font-size: 15px;
                    margin-left: 5px;
                    margin-top: 7px;
                }

                .countdown-area {
                    display: flex;
                    margin-top: 5px;
                    margin-bottom: 10px;
                }
            </style>
            <form class="p-2 tel-dogrulama-form" method="post">
                <div class="row">
                    <div class="col-12">
                        <label class="form-label">Doğrulama Kodu</label>
                        <input type="text" class="form-control" name="tel_dogrulama">
                    </div>
                </div>
                <div class="py-2">
                    <div class="countdown-area">
                        <button id="sendSMS" type="button" data-id="<?php echo $kullanici->kullanici_id ?>"
                                class="btn btn-warning rounded-pill">SMS Gönder
                        </button>
                        <div id="countdown"></div>
                    </div>
                    <button type="submit" class="btn btn-primary rounded-pill soru-sor-btn w-100">Doğrula</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="<?= base_url('assets/front/') ?>libs/jquery/dist/jquery.min.js"></script>
<script>
    var il_id = "<?= $kullanici->kullanici_sehir ?>";
    var ilce_id = "<?= $kullanici->kullanici_ilce ?>";
    var base_url = "<?= base_url() ?>";
    if (il_id !== "") {
        var il_id = $("#ilsec option:selected").val();
        $.ajax({
            type: "POST",
            url: base_url + "ajax_controller/il_ajax_hesap",
            data: {
                il_id: il_id,
                ilce_id: ilce_id
            },
            success: function (data) {
                $("#ilsechesap").html(data);
            }
        });
    }

    $('#ilsec').on('change', function () {
        var il_ids = $("#ilsec option:selected").val();
        $.ajax({
            type: "POST",
            url: base_url + "ajax_controller/il_ajax",
            data: {
                il_id: il_ids,
            },
            success: function (data) {
                $("#ilsechesap").html(data);
            }
        });

    });
</script>
<?php if ($kullanici->tel_dogrula == 0) { ?>
    <script>
        var countdownTimer;
        var countdownDuration = 60; // 60 saniye

        function startCountdown() {
            $("#sendSMS").prop("disabled", true);
            $("#countdown").show();

            countdownTimer = setInterval(function () {
                $("#countdown").text("Kalan süre: " + countdownDuration + " saniye");

                if (countdownDuration === 0) {
                    clearInterval(countdownTimer);
                    $("#sendSMS").prop("disabled", false);
                    $("#countdown").hide();
                } else {
                    countdownDuration--;
                }
            }, 1000);
        }

        function resetCountdown() {
            clearInterval(countdownTimer);
            countdownDuration = 60;
            $("#sendSMS").prop("disabled", true);
            startCountdown();
        }

        // Sayfa yüklendiğinde otomatik geri sayım başlat
        //startCountdown();

        $("#sendSMS").click(function () {
            // Eğer geri sayım başlamamışsa başlat
            if (countdownDuration === 60) {
                startCountdown();
                var user = $(this).data('id');
                $.ajax({
                    type: "POST",
                    url: base_url + "ajax_controller/tel_dogrulama_resend",
                    data: {
                        kullanici: user,
                        telefon: $("#accountPhone").val()
                    },
                    success: function (data) {
                        var d = JSON.parse(data);
                        if (d.status.status == 'success') {
                            startCountdown();
                            $(".tel-dogrula-alert").html(d.status.alert_html);
                        } else {
                            $(".tel-dogrula-alert").html(d.status.alert_html);
                        }
                    }
                });
            } else {
                // Eğer geri sayım başlamışsa sıfırla ve tekrar başlat
                resetCountdown();
                var user = $(this).data('id');
                $.ajax({
                    type: "POST",
                    url: base_url + "ajax_controller/tel_dogrulama_resend",
                    data: {
                        kullanici: user,
                        telefon: $("#accountPhone").val()
                    },
                    success: function (data) {
                        var d = JSON.parse(data);
                        if (d.status.status == 'success') {
                            startCountdown();
                            $(".tel-dogrula-alert").html(d.status.alert_html);
                        } else {
                            $(".tel-dogrula-alert").html(d.status.alert_html);
                        }
                    }
                });
            }

            // Burada SMS gönderme işlemlerini gerçekleştirebilirsiniz.
        });

        $('.tel-dogrula-button').on('click', function () {
            var user = $(this).data('id');
            $.ajax({
                type: "POST",
                url: base_url + "ajax_controller/tel_dogrulama",
                data: {
                    kullanici: user,
                    telefon: $("#accountPhone").val()
                },
                success: function (data) {
                    var d = JSON.parse(data);
                    if (d.status.status == 'success') {
                        startCountdown();
                        $(".tel-dogrula-alert").html(d.status.alert_html);
                    } else {
                        $(".tel-dogrula-alert").html(d.status.alert_html);
                    }
                }
            });

        });

        $('.tel-dogrulama-form').on('submit', function () {
            var kod = $('input[name="tel_dogrulama"]').val();
            $.ajax({
                type: "POST",
                url: base_url + "ajax_controller/tel_kod_dogrulama",
                data: {
                    code: kod,
                },
                success: function (data) {
                    var d = JSON.parse(data);
                    if (d.status.status == 'success') {
                        Swal.fire(
                            'Başarılı!',
                            d.status.message,
                            d.status.status,
                        );
                        setTimeout(
                            function () {
                                window.location.reload();
                            }, 2000);
                    } else {
                        Swal.fire(
                            'Hata!',
                            d.status.message,
                            d.status.status,
                        );
                    }
                }
            });

        });
    </script>

<?php } ?>