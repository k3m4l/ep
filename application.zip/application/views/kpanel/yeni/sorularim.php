<main class="k-panel-warper">
    <div class="sec-warper mb-4">
        <div class="container normal-container p-0">
            <div class="k-panel-g-warper">
                <div class="row">
                    <div class="col-xl-3 col-lg-3 col-md-12 col-sm-12 wd-none mt-3 p-0 ">
                        <div class="accordion accordion-flush acc-kpc-menu" id="accordionFlushExample">
                            <div class="accordion-item acc-kpc-menu-item">
                                <h2 class="accordion-header acc-kpc-menu-header" id="flush-headingOne">
                                    <button class="accordion-button collapsed acc-kpc-menu-btn" type="button"
                                            data-bs-toggle="collapse" data-bs-target="#flush-collapseOne"
                                            aria-expanded="false" aria-controls="flush-collapseOne">
                                        Hızlı Menü
                                    </button>
                                </h2>
                                <div id="flush-collapseOne" class="accordion-collapse collapse"
                                     aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
                                    <div class="accordion-body acc-kpc-menu-body">
                                        <div class="k-panel-left-navbar-warper">
                                            <div class="k-panel-left-navbar-area">
                                                <div class="nav flex-column nav-pills bg-custom-none " id="v-pills-tab" role="tablist"
                                                    aria-orientation="vertical">
                                                <?php if (magaza_check()) { ?>
                                                        <div class="gt-store">
                                                            <a href="<?php echo base_url('m/'.magaza($kullanici->kullanici_id)->magaza_seo) ?>" class="btn btn-primary settings-btn mb-3 w-100">Mağzaya Git</a>
                                                        </div>
                                                    <?php } ?>
                                                    <a href="<?php echo base_url('hesabim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100">Profilim</a>
                                                    <a href="<?php echo base_url('siparislerim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100">Siparişlerim</a>
                                                    <a href="<?php echo base_url('satislar') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100">Gold Al - Sat</a>
                                                    <a href="<?php echo base_url('sorularim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100 active">Sorularım</a>
                                                    <a href="<?php echo base_url('bakiye') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100">Bakiye</a>
                                                    <a href="<?php echo base_url('odeme-talep') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100">Para Çek</a>
                                                    <a href="<?php echo base_url('destek-taleplerim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100">Destek Taleplerim</a>
                                                    <a href="<?php echo base_url('itirazlarim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100">İtirazlarım</a>
                                                    <a href="<?php echo base_url('hesap-ayarlari') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100">Profil Ayarlarım</a>
                                                    <a class="nav-link kpc-nav-btn w-spacial w-100" href="<?php echo base_url('cikis') ?>">Çıkış</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-3 col-md-12 col-sm-12 md-none pr-0">
                        <div class="k-panel-left-navbar-warper m-bg2">
                            <div class="k-panel-left-navbar-area">
                                <div class="nav flex-column nav-pills bg-custom-none " id="v-pills-tab" role="tablist"
                                     aria-orientation="vertical">
                                   <?php if (magaza_check()) { ?>
                                        <div class="gt-store">
                                            <a href="<?php echo base_url('m/'.magaza($kullanici->kullanici_id)->magaza_seo) ?>" class="btn btn-primary settings-btn mb-3 w-100">Mağzaya Git</a>
                                        </div>
                                    <?php } ?>
                                    <a href="<?php echo base_url('hesabim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"> <img class="sw-icon-item" src="<?php echo base_url('assets/front/images/uzer.webp') ?>" alt="" loading="lazy">Profilim</a>
                                    <a href="<?php echo base_url('siparislerim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"><img class="sw-icon-item" src="<?php echo base_url('assets/front/images/shopping-list.webp') ?>" alt="" loading="lazy">Siparişlerim</a>
                                    <a href="<?php echo base_url('satislar') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"><img class="sw-icon-item" src="<?php echo base_url('assets/front/images/gold.webp') ?>" alt="" loading="lazy">Gold Al - Sat</a>
                                    <a href="<?php echo base_url('sorularim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100 active"><img class="sw-icon-item" src="<?php echo base_url('assets/front/images/s4.png') ?>" alt="" loading="lazy">Sorularım</a>
                                    <a href="<?php echo base_url('bakiye') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"><img class="sw-icon-item" src="<?php echo base_url('assets/front/images/salary.webp') ?>" alt="" loading="lazy">Bakiye</a>
                                    <a href="<?php echo base_url('odeme-talep') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"><img class="sw-icon-item" src="<?php echo base_url('assets/front/images/transfer.webp') ?>" alt="" loading="lazy">Para Çek</a>
                                                                       <a href="<?php echo base_url('destek-taleplerim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"><img class="sw-icon-item" src="<?php echo base_url('assets/front/images/customer-service.webp') ?>" alt="" loading="lazy">Destek Sistemi</a>
                                    <a href="<?php echo base_url('itirazlarim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"><img class="sw-icon-item" src="<?php echo base_url('assets/front/images/error.webp') ?>" alt="" loading="lazy">İtirazlarım</a>
                                    <a href="<?php echo base_url('hesap-ayarlari') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"><img class="sw-icon-item" src="<?php echo base_url('assets/front/images/s1.png') ?>" alt="" loading="lazy">Profil Ayarlarım</a>
                                    <a class="nav-link kpc-nav-btn w-spacial w-100" href="<?php echo base_url('cikis') ?>"><img class="sw-icon-item" src="<?php echo base_url('assets/front/images/logout.webp') ?>" alt="" loading="lazy">Çıkış</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-9 col-lg-9 col-md-12 col-sm-12 m-bg m-br">
                        <div class="k-panel-content-right">
                            <div class="tab-content" id="v-pills-tabContent">
                                <div class="tab-pane fade show active" id="atq" role="tabpanel" aria-labelledby="atq-tab"
                                     tabindex="0">
                                    <div class="container-fluid">
                                        <div class="k-panel-content-box">
                                            <div class="row">
                                                <div class="col-12">
                                                    <?php if (!empty($sorular)) { ?>
                                                        <?php foreach ($sorular as $key => $val) { ?>
                                                            <div class="kpc-item">
                                                                <div class="kpc-border">
                                                                    <a target="_blank"
                                                                       href="<?php echo base_url($val->urun_seo) ?>">
                                                                        <img src="<?php echo base_url($val->urun_resim_min) ?>"
                                                                             alt="<?php echo $val->urun_ad ?>"
                                                                             class="rounded img-4by3-lg product-table-img"></a>

                                                                    <div class="product-name-panel">
                                                                        <h4 class="custom-text-area">
                                                                            <a target="_blank" href=""
                                                                               class="custom-text"><?php echo $val->urun_ad ?></a>
                                                                        </h4>
                                                                    </div>
                                                                    <ul class="list-inline font-size-xs mb-0">
                                                                        <li class="list-inline-item">
                                                                            <i class="far fa-clock mr-1"></i>
                                                                            <?php echo $val->tarih ?>
                                                                        </li>
                                                                    </ul>
                                                                    <div class="align-middle border-top-0">
                                                                        <?php if (empty($val->soru_cevap)) { ?>
                                                                            <span class="badge badge-warning">Cevap Bekliyor..</span>
                                                                        <?php } else { ?>
                                                                            <span class="badge badge-success">Cevap Verildi</span>
                                                                        <?php } ?>
                                                                    </div>
                                                                    <div class="atq-modal-btn">
                                                                        <button type="button" class="btn btn-primary"
                                                                                data-toggle="modal"
                                                                                data-target="#sorucevap-<?php echo $val->soru_id ?>">
                                                                            <i class="far fa-eye"></i></button>
                                                                        <button type="button"
                                                                                onclick="window.location.href='<?php echo base_url($val->urun_seo) ?>'"
                                                                                class="btn btn-info"><i
                                                                                    class="fas fa-external-link-alt"></i>
                                                                        </button>
                                                                    </div>
                                                                </div>
                                                                <div class="atq-dsc">
                                                                    <p><?php echo $val->soru ?></p>
                                                                </div>
                                                            </div>
                                                            <div class="modal fade"
                                                                 id="sorucevap-<?php echo $val->soru_id ?>"
                                                                 tabindex="-1" role="dialog"
                                                                 aria-labelledby="exampleModalCenterTitle"
                                                                 aria-hidden="true">
                                                                <div class="modal-dialog modal-dialog-centered"
                                                                     role="document">
                                                                    <div class="modal-content sms">
                                                                        <div class="modal-header">
                                                                            <h4 class="modal-title text-center"
                                                                                id="exampleModalCenterTitle"><?php echo $val->urun_ad ?>
                                                                                İlanınızın Sorusu</h4>
                                                                            <button type="button" class="close"
                                                                                    data-dismiss="modal"
                                                                                    aria-label="Close">
                                                                                <span aria-hidden="true">&times;</span>
                                                                            </button>
                                                                        </div>
                                                                        <div class="alert alert-info alert-dismissible text-left alert-grid"
                                                                             role="alert">
                                                                            <i class="fas fa-question"></i>
                                                                            <div>
                                                                                <strong>Soru:</strong><br><?php echo $val->soru ?>
                                                                            </div>
                                                                        </div>
                                                                        <?php if (!empty($val->soru_cevap)) { ?>
                                                                            <div class="alert alert-info alert-dismissible text-left alert-grid"
                                                                                 role="alert">
                                                                                <div>
                                                                                    <strong>Cevap:</strong><br><?php echo $val->soru_cevap->soru ?>
                                                                                </div>
                                                                            </div>
                                                                        <?php } ?>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        <?php } ?>
                                                    <?php } else { ?>
                                                        <div class="alert alert-info mt-2 text-center" role="alert">
                                                            Sorunuz Bulunmamaktadır!!
                                                        </div>
                                                    <?php } ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<div class="modal fade" id="sohbet" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
     aria-hidden="true">
    <form action="" method="post" id="infoSohbet">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="form-group">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                        <label for="recipient-name" class="col-form-label">Sohbet'i başlatmak istediğiniz üyenin
                            kullanıcı adını
                            yazın</label>
                        <input name="username" type="text" class="form-control" id="recipient-name"
                               placeholder="Üyenin Kullanıcı Adı">
                        <label for="message-text" class="col-form-label">Mesajınız:</label>
                        <textarea rows="4" cols="50" class="form-control" name="gidicekmesaj" id="mesaj"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-info btn-lg btn-block">Sohbeti Başlat</button>
                </div>
            </div>
        </div>
    </form>
</div>
<script>
    $('.chat-list-name li').click(function () {
        var select_chat = $(this).attr('data-target');
        if ($('.chat-area').hasClass('open')) {
            $('.chat-area').removeClass('open')
            $('#select-chat-' + select_chat).addClass('open')
        } else {
            $('#select-chat-' + select_chat).addClass('open')
        }
    })

    $('#sendmessage').keypress(function (e) {
        if (e.which === 13) {
            $('.sendReMessage').click()
        }
    })

    $(document).on("submit", "#infoSohbet", function (event) {
        <?php if (aktif_kullanici()) : ?>
        $.ajax({
            type: "POST",
            url: base_url + "ajax_controller/sohbet_add_mesaj",
            data: {
                mesaj: $('textarea[name="gidicekmesaj"]').val(),
                username: $('input[name="username"]').val(),
                kullanici_id: <?= $kullanici->kullanici_id ?>
            },
            success: function (data) {
                var d = JSON.parse(data);
                if (d.status.status == 'error') {
                    Swal.fire(
                        'Hata!',
                        d.status.message,
                        d.status.status,
                    );
                } else if (d.status.status == 'success') {
                    Swal.fire(
                        'Başarılı!',
                        d.status.message,
                        d.status.status,
                    ).then((result) => {
                        location.reload();
                    })
                }

            }
        });
        event.preventDefault();
        <?php else : ?>
        Swal.fire({
            title: 'Giriş Yap',
            text: "Mesajlaşmak için giriş yapmalısınız.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Giriş Yap',
            cancelButtonText: 'Hayır, İptal Et',
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = "<?= base_url('giris-yap') ?>";
            }
        })
        <?php endif; ?>
    });

    $(document).on("click", ".menu-left-area", function (event) {
        <?php if (aktif_kullanici()) : ?>
        var uniq = $(this).data('target');
        $.ajax({
            type: "POST",
            url: base_url + "ajax_controller/sohbet_getir",
            data: {
                uniq: uniq,
                kullanici_id: <?= $kullanici->kullanici_id ?>
            },
            success: function (data) {
                var d = JSON.parse(data);
                if (d.status == 'error') {
                    Swal.fire(
                        'Hata!',
                        d.message,
                        d.status,
                    );
                } else if (d.status == 'success') {
                    var targetDiv = $('#select-chat-' + uniq).find('.chat-bar');
                    targetDiv.html(d.html); // İçerik kısmını kendi isteğinize göre güncelleyin
                    $('.chat-bar').scrollTop($('.chat-bar')[0].scrollHeight)
                }

            }
        });
        event.preventDefault();
        <?php else : ?>
        Swal.fire({
            title: 'Giriş Yap',
            text: "Mesajlaşmak için giriş yapmalısınız.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Giriş Yap',
            cancelButtonText: 'Hayır, İptal Et',
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = "<?= base_url('giris-yap') ?>";
            }
        })
        <?php endif; ?>
    });

    $(document).on("click", ".sendReMessage", function (event) {
        <?php if (aktif_kullanici()) : ?>
        var inputValue = $(this).closest('.chat-container').find('input[name="remessage"]').val();
        var uniq = $(this).data('target');
        $.ajax({
            type: "POST",
            url: base_url + "ajax_controller/send_re_message",
            data: {
                uniq: uniq,
                kullanici_id: <?= $kullanici->kullanici_id ?>,
                message: inputValue
            },
            success: function (data) {
                var d = JSON.parse(data);
                if (d.status == 'error') {
                    Swal.fire(
                        'Hata!',
                        d.message,
                        d.status,
                    );
                } else if (d.status == 'success') {
                    var targetDiv = $('#select-chat-' + uniq).find('.chat-bar');
                    targetDiv.append(d.html); // İçerik kısmını kendi isteğinize göre güncelleyin
                    $('#sendmessage').val(' ');
                    $('.chat-bar').scrollTop($('.chat-bar')[0].scrollHeight)
                }

            }
        });
        event.preventDefault();
        <?php else : ?>
        Swal.fire({
            title: 'Giriş Yap',
            text: "Mesajlaşmak için giriş yapmalısınız.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Giriş Yap',
            cancelButtonText: 'Hayır, İptal Et',
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = "<?= base_url('giris-yap') ?>";
            }
        })
        <?php endif; ?>
    });


</script>


<div class="modal fade" id="teldogrula_step_1" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
     aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content sms">
            <div class="modal-header">
                <h4 class="modal-title text-center" id="exampleModalCenterTitle">Telefon Doğrulama</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="tel-dogrula-alert">
                <div class="alert alert-danger alert-dismissible text-left alert-grid" role="alert">
                    <i class="fas fa-check"></i>
                    <div><strong>Doğrulama Gerekiyor</strong><br>
                        Ödeme bildirimi oluşturabilmek için telefon numaranızı doğrulamanız gerekmektedir.
                    </div>
                </div>
            </div>
            <div class="p-2">
                <div class="row">
                    <div class="col-12">
                        <label class="form-label">Telefon No</label>
                        <input type="text" class="form-control" name="telefon" id="telefon" value="0" maxlength="11">
                    </div>
                </div>
                <div class="py-2">
                    <button type="button" class="btn btn-primary rounded-pill tel-dogrula-button w-100"
                            data-id="<?php echo $kullanici->kullanici_id ?>">SMS Gönder
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="teldogrula" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
     aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content sms">
            <div class="modal-header">
                <h4 class="modal-title text-center" id="exampleModalCenterTitle">Telefon Doğrulama</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="tel-dogrula-alert">
                <div class="alert alert-success alert-dismissible text-left alert-grid" role="alert">
                    <i class="fas fa-check"></i>
                    <div><strong>Başarılı</strong><br>
                        Doğrulama Kodunuz Başarılı Şekilde Gönderilmiştir. Lütfen Aşağıda ki alana kodu giriniz.
                    </div>
                </div>
            </div>
            <style>
                #countdown {
                    display: none;
                    font-size: 15px;
                    margin-left: 5px;
                    margin-top: 7px;
                }

                .countdown-area {
                    display: flex;
                    margin-top: 5px;
                    margin-bottom: 10px;
                }
            </style>
            <form class="p-2 tel-dogrulama-form" method="post">
                <div class="row">
                    <div class="col-12">
                        <label class="form-label">Doğrulama Kodu</label>
                        <input type="text" class="form-control" name="tel_dogrulama">
                    </div>
                </div>
                <div class="py-2">
                    <div class="countdown-area">
                        <button id="sendSMS" type="button" data-id="<?php echo $kullanici->kullanici_id ?>"
                                class="btn btn-warning rounded-pill">SMS Gönder
                        </button>
                        <div id="countdown"></div>
                    </div>
                    <button type="submit" class="btn btn-primary rounded-pill soru-sor-btn w-100">Doğrula</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    var countdownTimer;
    var countdownDuration = 60; // 60 saniye

    function startCountdown() {
        $("#sendSMS").prop("disabled", true);
        $("#countdown").show();

        countdownTimer = setInterval(function () {
            $("#countdown").text("Kalan süre: " + countdownDuration + " saniye");

            if (countdownDuration === 0) {
                clearInterval(countdownTimer);
                $("#sendSMS").prop("disabled", false);
                $("#countdown").hide();
            } else {
                countdownDuration--;
            }
        }, 1000);
    }

    function resetCountdown() {
        clearInterval(countdownTimer);
        countdownDuration = 60;
        $("#sendSMS").prop("disabled", true);
        startCountdown();
    }

    // Sayfa yüklendiğinde otomatik geri sayım başlat
    //startCountdown();

    $("#sendSMS").click(function () {
        // Eğer geri sayım başlamamışsa başlat
        if (countdownDuration === 60) {
            startCountdown();
            var user = $(this).data('id');
            $.ajax({
                type: "POST",
                url: base_url + "ajax_controller/tel_dogrulama_resend",
                data: {
                    kullanici: user,
                    telefon: $("#telefon").val()
                },
                success: function (data) {
                    var d = JSON.parse(data);
                    if (d.status.status == 'success') {
                        startCountdown();
                        $(".tel-dogrula-alert").html(d.status.alert_html);
                    } else {
                        $(".tel-dogrula-alert").html(d.status.alert_html);
                    }
                }
            });
        } else {
            // Eğer geri sayım başlamışsa sıfırla ve tekrar başlat
            resetCountdown();
            var user = $(this).data('id');
            $.ajax({
                type: "POST",
                url: base_url + "ajax_controller/tel_dogrulama_resend",
                data: {
                    kullanici: user,
                    telefon: $("#telefon").val()
                },
                success: function (data) {
                    var d = JSON.parse(data);
                    if (d.status.status == 'success') {
                        startCountdown();
                        $(".tel-dogrula-alert").html(d.status.alert_html);
                    } else {
                        $(".tel-dogrula-alert").html(d.status.alert_html);
                    }
                }
            });
        }

        // Burada SMS gönderme işlemlerini gerçekleştirebilirsiniz.
    });


    $('.tel-dogrula-button').on('click', function () {
        var user = $(this).data('id');
        $.ajax({
            type: "POST",
            url: base_url + "ajax_controller/tel_dogrulama",
            data: {
                kullanici: user,
                telefon: $("#telefon").val()
            },
            success: function (data) {
                var d = JSON.parse(data);
                $("#teldogrula_step_1").modal("hide");
                $("#teldogrula").modal("show");
                if (d.status.status == 'success') {
                    startCountdown();
                    $(".tel-dogrula-alert").html(d.status.alert_html);
                } else {
                    $(".tel-dogrula-alert").html(d.status.alert_html);
                }
            }
        });

    });

    $('.tel-dogrulama-form').on('submit', function () {
        var kod = $('input[name="tel_dogrulama"]').val();
        $.ajax({
            type: "POST",
            url: base_url + "ajax_controller/tel_kod_dogrulama",
            data: {
                code: kod,
            },
            success: function (data) {
                var d = JSON.parse(data);
                if (d.status.status == 'success') {
                    Swal.fire(
                        'Başarılı!',
                        d.status.message,
                        d.status.status,
                    );
                    setTimeout(
                        function () {
                            window.location.reload();
                        }, 2000);
                } else {
                    Swal.fire(
                        'Hata!',
                        d.status.message,
                        d.status.status,
                    );
                }
            }
        });

    });
</script>
<script>
    function getFormData($form) {
        var unindexed_array = $form.serializeArray();
        var indexed_array = {};

        $.map(unindexed_array, function (n, i) {
            indexed_array[n['name']] = n['value'];
        });

        return indexed_array;
    }

    function paymentInfoPanel() {
        Swal.fire({
            html: $(".payment-info-modal .grid").html(),
            showCancelButton: false,
            showConfirmButton: false,
            showCloseButton: true,
            allowOutsideClick: false,
            allowEscapeKey: true,
            focusConfirm: false,
            customClass: {
                container: "login-special-container"
            }
        });
        $(".swal2-html-container #odemeBildirimForm #havale_tutar").on('input', function () {
            var tutar = parseFloat($(this).val());
            var komisyon = parseFloat(<?= $ayarlar->havale_komisyon ?>);
            var odenecek = (tutar / (100 + komisyon)) * 100;
            $(".swal2-html-container #odemeBildirimForm #havale_odenecek_tutar").html(odenecek.toFixed(2));
        });
        moment.updateLocale('tr', {
            meridiem: function (hour, minute, isLowercase) {
                if (hour < 12) {
                    return 'ÖÖ';
                } else {
                    return 'ÖS';
                }
            }
        });

        moment.updateLocale('tr', {
            meridiem: function (hour, minute, isLowercase) {
                if (hour < 12) {
                    return 'öö';
                } else {
                    return 'ös';
                }
            }
        });

        $('.swal2-html-container #odemeBildirimForm #odeme_bildirim_date').daterangepicker({
            "singleDatePicker": true,
            "timePicker": true,
            "startDate": "<?= date('d.m.Y H:i:s') ?>",
            "minDate": "<?= date('d.m.Y H:i:s', strtotime("-31 days")) ?>",
            "maxDate": "<?= date('d.m.Y H:i:s') ?>",
            "locale": {
                "format": "DD.MM.YYYY HH:mm:ss",
                "separator": " - ",
                "applyLabel": "Uygula",
                "cancelLabel": "Vazgeç",
                "fromLabel": "Dan",
                "toLabel": "a",
                "customRangeLabel": "Seç",
                "daysOfWeek": [
                    "Pt",
                    "Sl",
                    "Çr",
                    "Pr",
                    "Cm",
                    "Ct",
                    "Pz"
                ],
                "monthNames": [
                    "Ocak",
                    "Şubat",
                    "Mart",
                    "Nisan",
                    "Mayıs",
                    "Haziran",
                    "Temmuz",
                    "Ağustos",
                    "Eylül",
                    "Ekim",
                    "Kasım",
                    "Aralık"
                ],
                "firstDay": 1
            },
        }, function (start, end, label) {

        });
        $(".swal2-html-container #odemeBildirimForm").submit((e) => {
            e.preventDefault();
            var form = $(".swal2-html-container #odemeBildirimForm");
            $.ajax({
                type: "POST",
                url: "<?= base_url("odemebildirimiolustur") ?>",
                data: getFormData(form),
                success: function (res) {
                    res = JSON.parse(res);
                    if (res.status) {
                        Swal.fire({
                            icon: 'success',
                            title: 'Ödeme Bildirimi Alındı',
                            text: 'Ödeme bildiriminiz tarafımıza ulaştı. En kısa süre içerisinde bakiyeniz hesabınıza yüklenecektir.',
                        })
                    } else {
                        if (res.tel_verify) {
                            Swal.close();
                            $("#teldogrula_step_1").modal("show");
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Ödeme Bildirimi Oluşturulamadı.',
                                text: res.message ? res.message : 'Girmiş olduğunuz bilgileri tekrar kontrol ediniz. Sorun hala devam ediyorsa yönetici ile iletişime geçiniz.',
                            })
                        }
                    }
                }
            })
        })
    }

    $(".bank-img-area").on('click', function () {
        var id = $(this).data('id');
        $.ajax({
            type: "POST",
            url: "<?= base_url("Home_controller/banka_getir") ?>",
            data: {
                banka: id
            },
            success: function (res) {
                res = JSON.parse(res);
                if (res.status) {
                    $('.modal-bank-img').attr('src', 'https://kemalellidort.com.tr/' + res.banka.image);
                    $('.modal-transfer-bank-name').html(res.banka.name);
                    $('.modal-iban-area').html(res.banka.iban);
                    $('.modal-bank-desc').html(res.banka.description);
                    $('.modal-bank-select').html('<option value="' + res.banka.id + '">' + res.banka.name + '</option>');
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Hata',
                        text: 'Yapmaya Çalıştığınız İşlem Geçerli Değil',
                    })
                }
            }
        })
    });


    $(document).ready(function () {
        $("#bakiyeKuponuForm").submit((e) => {
            e.preventDefault();
            var form = $("#bakiyeKuponuForm");
            $.ajax({
                type: "POST",
                url: "<?= base_url("kuponkullan") ?>",
                data: getFormData(form),
                success: function (res) {
                    res = JSON.parse(res);
                    if (res.status) {
                        Swal.fire({
                            icon: 'success',
                            title: 'Kupon Kullanıldı',
                            text: res.message ? res.message : 'Kupon bakiyesi hesabınıza aktarıldı.',
                        })
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Kupon Kullanılamadı.',
                            text: res.message ? res.message : 'Yönetici ile iletişime geçiniz.',
                        })
                    }
                }
            })
        })
        $("#tutar").on('input', function () {
            var tutar = parseFloat($(this).val());
            var komisyon = parseFloat($("#komisyon_oran").val());
            var odenecek = tutar + (tutar * komisyon / 100);
            $("#odenecek_tutar").html(odenecek);
        });
        $("#iyzico_tutar").on('input', function () {
            var tutar = parseFloat($(this).val());
            var komisyon = parseFloat($("#iyzico_komisyon_oran").val());
            var odenecek = tutar + (tutar * komisyon / 100);
            $("#iyzico_odenecek_tutar").html(odenecek);
        });
        $("#weepay_tutar").on('input', function () {
            var tutar = parseFloat($(this).val());
            var komisyon = parseFloat($("#weepay_komisyon_oran").val());
            var odenecek = tutar + (tutar * komisyon / 100);
            $("#weepay_odenecek_tutar").html(odenecek);
        });
        $("#vallet_tutar").on('input', function () {
            var tutar = parseFloat($(this).val());
            var komisyon = parseFloat($("#vallet_komisyon_oran").val());
            var odenecek = tutar + (tutar * komisyon / 100);
            $("#vallet_odenecek_tutar").html(odenecek);
        });
        $("#stripe_tutar").on('input', function () {
            var tutar = parseFloat($(this).val());
            var komisyon = parseFloat($("#stripe_komisyon_oran").val());
            var odenecek = tutar + komisyon;
            $("#stripe_odenecek_tutar").html(odenecek);
        });
    })
</script>

<div class="modal fade" id="teldogrula" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
     aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content sms">
            <div class="modal-header">
                <h4 class="modal-title text-center" id="exampleModalCenterTitle">Satıcıya Soru Sor</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="tel-dogrula-alert">
                <div class="alert alert-success alert-dismissible text-left alert-grid" role="alert">
                    <i class="fas fa-check"></i>
                    <div><strong>Başarılı</strong><br>
                        Doğrulama Kodunuz Başarılı Şekilde Gönderilmiştir. Lütfen Aşağıda ki alana kodu giriniz.
                    </div>
                </div>
            </div>
            <style>
                #countdown {
                    display: none;
                    font-size: 15px;
                    margin-left: 5px;
                    margin-top: 7px;
                }

                .countdown-area {
                    display: flex;
                    margin-top: 5px;
                    margin-bottom: 10px;
                }
            </style>
            <form class="p-2 tel-dogrulama-form" method="post">
                <div class="row">
                    <div class="col-12">
                        <label class="form-label">Doğrulama Kodu</label>
                        <input type="text" class="form-control" name="tel_dogrulama">
                    </div>
                </div>
                <div class="py-2">
                    <div class="countdown-area">
                        <button id="sendSMS" type="button" data-id="<?php echo $kullanici->kullanici_id ?>"
                                class="btn btn-warning rounded-pill">SMS Gönder
                        </button>
                        <div id="countdown"></div>
                    </div>
                    <button type="submit" class="btn btn-primary rounded-pill soru-sor-btn w-100">Doğrula</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="<?= base_url('assets/front/') ?>libs/jquery/dist/jquery.min.js"></script>
<script>
    var il_id = "<?= $kullanici->kullanici_sehir ?>";
    var ilce_id = "<?= $kullanici->kullanici_ilce ?>";
    var base_url = "<?= base_url() ?>";
    if (il_id !== "") {
        var il_id = $("#ilsec option:selected").val();
        $.ajax({
            type: "POST",
            url: base_url + "ajax_controller/il_ajax_hesap",
            data: {
                il_id: il_id,
                ilce_id: ilce_id
            },
            success: function (data) {
                $("#ilsechesap").html(data);
            }
        });
    }

    $('#ilsec').on('change', function () {
        var il_ids = $("#ilsec option:selected").val();

        $.ajax({
            type: "POST",
            url: base_url + "ajax_controller/il_ajax",
            data: {
                il_id: il_ids,
            },
            success: function (data) {
                $("#ilsechesap").html(data);
            }
        });

    });
</script>
<?php if ($kullanici->tel_dogrula == 0) { ?>
    <script>
        var countdownTimer;
        var countdownDuration = 60; // 60 saniye

        function startCountdown() {
            $("#sendSMS").prop("disabled", true);
            $("#countdown").show();

            countdownTimer = setInterval(function () {
                $("#countdown").text("Kalan süre: " + countdownDuration + " saniye");

                if (countdownDuration === 0) {
                    clearInterval(countdownTimer);
                    $("#sendSMS").prop("disabled", false);
                    $("#countdown").hide();
                } else {
                    countdownDuration--;
                }
            }, 1000);
        }

        function resetCountdown() {
            clearInterval(countdownTimer);
            countdownDuration = 60;
            $("#sendSMS").prop("disabled", true);
            startCountdown();
        }

        // Sayfa yüklendiğinde otomatik geri sayım başlat
        //startCountdown();

        $("#sendSMS").click(function () {
            // Eğer geri sayım başlamamışsa başlat
            if (countdownDuration === 60) {
                startCountdown();
                var user = $(this).data('id');
                $.ajax({
                    type: "POST",
                    url: base_url + "ajax_controller/tel_dogrulama_resend",
                    data: {
                        kullanici: user,
                        telefon: $("#accountPhone").val()
                    },
                    success: function (data) {
                        var d = JSON.parse(data);
                        if (d.status.status == 'success') {
                            startCountdown();
                            $(".tel-dogrula-alert").html(d.status.alert_html);
                        } else {
                            $(".tel-dogrula-alert").html(d.status.alert_html);
                        }
                    }
                });
            } else {
                // Eğer geri sayım başlamışsa sıfırla ve tekrar başlat
                resetCountdown();
                var user = $(this).data('id');
                $.ajax({
                    type: "POST",
                    url: base_url + "ajax_controller/tel_dogrulama_resend",
                    data: {
                        kullanici: user,
                        telefon: $("#accountPhone").val()
                    },
                    success: function (data) {
                        var d = JSON.parse(data);
                        if (d.status.status == 'success') {
                            startCountdown();
                            $(".tel-dogrula-alert").html(d.status.alert_html);
                        } else {
                            $(".tel-dogrula-alert").html(d.status.alert_html);
                        }
                    }
                });
            }

            // Burada SMS gönderme işlemlerini gerçekleştirebilirsiniz.
        });

        $('.tel-dogrula-button').on('click', function () {
            var user = $(this).data('id');
            $.ajax({
                type: "POST",
                url: base_url + "ajax_controller/tel_dogrulama",
                data: {
                    kullanici: user,
                    telefon: $("#accountPhone").val()
                },
                success: function (data) {
                    var d = JSON.parse(data);
                    if (d.status.status == 'success') {
                        startCountdown();
                        $(".tel-dogrula-alert").html(d.status.alert_html);
                    } else {
                        $(".tel-dogrula-alert").html(d.status.alert_html);
                    }
                }
            });

        });

        $('.tel-dogrulama-form').on('submit', function () {
            var kod = $('input[name="tel_dogrulama"]').val();
            $.ajax({
                type: "POST",
                url: base_url + "ajax_controller/tel_kod_dogrulama",
                data: {
                    code: kod,
                },
                success: function (data) {
                    var d = JSON.parse(data);
                    if (d.status.status == 'success') {
                        Swal.fire(
                            'Başarılı!',
                            d.status.message,
                            d.status.status,
                        );
                        setTimeout(
                            function () {
                                window.location.reload();
                            }, 2000);
                    } else {
                        Swal.fire(
                            'Hata!',
                            d.status.message,
                            d.status.status,
                        );
                    }
                }
            });

        });
    </script>


    <script>
        $(document).ready(function () {
            // İlk sekme ve içeriği aktif hale getirme
            // Sekme tıklama olayı
            $('.PaymentTypes li').click(function () {
                var tabId = $(this).attr('id');

                // Aktif sekmeleri değiştirme
                $('.PaymentTypes li').removeClass('active');
                $(this).addClass('active');
                $('#intro').addClass("d-none");
                // Tüm içerikleri gizleme
                $('.tab-content .content').addClass('d-none');

                // İlgili içeriği gösterme
                $('#' + tabId + '-content').removeClass('d-none');
            });
        });

        var BreadcrumbInitialList = [{"name": "Ana Sayfa", "link": "\/"}, {
            "name": "Sipari\u015flerim",
            "link": "\/siparislerim"
        }];
        var BreadcrumbNames = {
            "aldigim-ilanlar": "Ald\u0131\u011f\u0131m \u0130lanlar",
            "sattigim-ilanlar": "Satt\u0131\u011f\u0131m \u0130lanlar",
            "aldigim-urunler": "Ald\u0131\u011f\u0131m \u00dcr\u00fcnler"
        };
        var ActiveTab = "aldigim-ilanlar";
    </script>
<?php } ?>

<script>
    setInterval(sendBekleyenAjaxRequest, 20000);
    setInterval(sendOnaylananAjaxRequest, 20000);
    setInterval(sendIptalAjaxRequest, 20000);

    setInterval(sendAlimBekleyenAjaxRequest, 20000);
    setInterval(sendAlimOnaylananAjaxRequest, 20000);
    setInterval(sendAlimIptalAjaxRequest, 20000);

    function sendBekleyenAjaxRequest() {
        <?php if (aktif_kullanici()) : ?>
        $.post({
            url: "<?= base_url('onay-bekleyen-satislar')?>",
            type: 'POST',
            success: function (response) {
                var data = JSON.parse(response);
                if (data.status === true) {
                    var html = '';
                    $.each(data.data, function (index, val) {
                        html += '<div class="sale-cards"><div class="sale-container"><div class="sale-card"><div class="product-detail"><div class="sale-img">';
                        html += '<a href="javascript:void(0)"><img src="https://kemalellidort.com.tr/' + val.urun_resim_min + '"></a></div>';
                        html += '<div class="product-info"><div class="p-name"><a href="javascript:void(0)">' + val.urun_ad + '</a></div> <div class="p-price">Fiyat: <span>' + val.urun_alimfiyat + ' TL</span></div><div class="p-price">Toplam Kazanç:<span>' + val.price + ' TL</span></div><div class="p-quantity">Adet:<span>' + val.quantity + '</span></div></div></div>';
                        html += '<div class="sale-status status-0"><i class="fa-solid fa-gauge-high"></i> Teslimat bekliyor <button class="btn btn-primary btn-sm sale-detail-button align-self-end" data-bs-toggle="modal" data-bs-target="#info-satim-modal-' + val.id + '"> İletilen Bilgiler </button></div>';
                        html += '<div class="sale-info"><div class="s-date"> <i class="fa-regular fa-clock"></i>' + val.added_time + '</div><div class="s-delivery">Satıcı: <a class="p-seller" href="">' + val.kullanici_ad + '</a></div></div></div><div class="sale-alerts "><div>' + val.urun_alimbaslik + '</div></div></div></div></div>';
                        html += '<div class="modal fade" id="info-satim-modal-' + val.id + '" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true"><div class="modal-dialog"><div class="modal-content"><div class="modal-header"><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div><div class="modal-body"><div class="detail-data-rows"><div class="detail-data-row"><span class="detail-data-name">Oyundaki Karakter Adınız :</span><span class="detail-data-val">' + val.character_name + '</span></div></div></div><div class="modal-footer boder-0"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Kapat</button></div></div></div></div>';
                    });
                    $('#pills-waiting-5').html(html);
                } else {
                    Swal.fire({
                        title: 'Hata',
                        text: data.message,
                        icon: 'warning',
                    })
                }
            },
            error: function (response) {
                console.log(response);
            }
        });
        <?php else : ?>
        Swal.fire({
            title: 'Giriş Yap',
            text: "İşlem Yapabilmek İçin Giriş Yapmalısınız.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Giriş Yap',
            cancelButtonText: 'Hayır, İptal Et',
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = "<?= base_url('giris-yap') ?>";
            }
        })
        <?php endif; ?>
    }

    function sendOnaylananAjaxRequest() {
        <?php if (aktif_kullanici()) : ?>
        $.post({
            url: "<?= base_url('tamamlanan-satislar')?>",
            type: 'POST',
            success: function (response) {
                var data = JSON.parse(response);
                if (data.status === true) {
                    var html = '';
                    $.each(data.data, function (index, val) {
                        html += '<div class="sale-cards"><div class="sale-container"><div class="sale-card"><div class="product-detail"><div class="sale-img">';
                        html += '<a href="javascript:void(0)"><img src="https://kemalellidort.com.tr/' + val.urun_resim_min + '"> </a></div>';
                        html += '<div class="product-info"><div class="p-name"><a href="javascript:void(0)">' + val.urun_ad + '</a></div><div class="p-price">Fiyat: <span>' + val.urun_alimfiyat + ' TL</span></div><div class="p-price">Toplam Kazanç: <span>' + val.price + ' TL</span></div><div class="p-quantity">Adet: <span>' + val.quantity + '</span></div></div></div>';
                        html += '<div class="sale-info"><div class="s-date"><i class="fa-regular fa-clock"></i> ' + val.added_time + '</div><div class="s-delivery">Teslimat Tarihi: <span>' + val.delivery_date + '</span></div><div class="s-delivery">Satıcı: <a class="p-seller" href="">' + val.kullanici_ad + '</a></div></div></div>';
                        html += '<div class="sale-status-g"><div class="sale-status status-1"><i class="fa-solid fa-circle-check"></i> Teslim edildi</div><div class="s-name">Teslim edilecek karakter adı: <span>*******</span></div><button class="btn btn-primary btn-sm sale-detail-button align-self-end" data-bs-toggle="modal" data-bs-target="#info-satim-comp-modal-' + val.id + '">İletilen Bilgiler</button></div></div><div class="sale-alerts "><div>' + val.urun_alimbaslik + '</div></div></div>';
                        html += '<div class="modal fade" id="info-satim-comp-modal-' + val.id + '" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true"><div class="modal-dialog"><div class="modal-content"><div class="modal-header"><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div><div class="modal-body"><div class="detail-data-rows"><div class="detail-data-row"><span class="detail-data-name">Oyundaki Karakter Adınız :</span><span class="detail-data-val">' + val.character_name + '</span></div></div></div><div class="modal-footer boder-0"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Kapat</button></div></div></div></div>';
                    });
                    $('#pills-complate-5').html(html);
                } else {
                    Swal.fire({
                        title: 'Hata',
                        text: data.message,
                        icon: 'warning',
                    })
                }
            },
            error: function (response) {
                console.log(response);
            }
        });
        <?php else : ?>
        Swal.fire({
            title: 'Giriş Yap',
            text: "İşlem Yapabilmek İçin Giriş Yapmalısınız.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Giriş Yap',
            cancelButtonText: 'Hayır, İptal Et',
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = "<?= base_url('giris-yap') ?>";
            }
        })
        <?php endif; ?>
    }

    function sendIptalAjaxRequest() {
        <?php if (aktif_kullanici()) : ?>
        $.post({
            url: "<?= base_url('iptal-edilen-satislar')?>",
            type: 'POST',
            success: function (response) {
                var data = JSON.parse(response);
                if (data.status === true) {
                    var html = '';
                    $.each(data.data, function (index, val) {
                        html += '<div class="sale-cards"><div class="sale-container"><div class="sale-card"><div class="product-detail"><div class="sale-img">';
                        html += '<a href="javascript:void(0)"><img src="https://kemalellidort.com.tr/' + val.urun_resim_min + '"> </a></div>';
                        html += '<div class="product-info"><div class="p-name"><a href="javascript:void(0)">' + val.urun_ad + '</a></div><div class="p-price">Fiyat: <span>' + val.urun_alimfiyat + ' TL</span></div><div class="p-price">Toplam Kazanç: <span>' + val.price + ' TL</span></div><div class="p-quantity">Adet: <span>' + val.quantity + '</span></div></div></div>';
                        html += '<div class="sale-status status-2"><i class="fad fa-window-close"></i> İptal edildi <button class="btn btn-primary btn-sm sale-detail-button align-self-end" data-bs-toggle="modal" data-bs-target="#info-satim-cancel-modal-' + val.id + '">İletilen Bilgiler</button></div><div class="sale-info"><div class="s-date"><i class="fad fa-clock"></i> ' + val.added_time + '</div><div class="s-delivery">Satıcı: <a class="p-seller" href="javascript:void(0)">' + val.kullanici_ad + '</a></div></div></div>';
                        html += '<div class="sale-alerts red">Satışınız iptal edilmiştir.' + val.reason_for_cancellation + '</div></div></div>';
                        html += '<div class="modal fade" id="info-satim-cancel-modal-' + val.id + '" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true"><div class="modal-dialog"><div class="modal-content"><div class="modal-header"><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div><div class="modal-body"><div class="detail-data-rows"><div class="detail-data-row"><span class="detail-data-name">Oyundaki Karakter Adınız :</span><span class="detail-data-val">' + val.character_name + '</span></div></div></div><div class="modal-footer boder-0"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Kapat</button></div></div></div></div>'
                    });
                    $('#pills-canseled-5').html(html);
                } else {
                    Swal.fire({
                        title: 'Hata',
                        text: data.message,
                        icon: 'warning',
                    })
                }
            },
            error: function (response) {
                console.log(response);
            }
        });
        <?php else : ?>
        Swal.fire({
            title: 'Giriş Yap',
            text: "İşlem Yapabilmek İçin Giriş Yapmalısınız.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Giriş Yap',
            cancelButtonText: 'Hayır, İptal Et',
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = "<?= base_url('giris-yap') ?>";
            }
        })
        <?php endif; ?>
    }

    // Alimlar

    function sendAlimBekleyenAjaxRequest() {
        <?php if (aktif_kullanici()) : ?>
        $.post({
            url: "<?= base_url('onay-bekleyen-alimlar')?>",
            type: 'POST',
            success: function (response) {
                var data = JSON.parse(response);
                if (data.status === true) {
                    var html = '';
                    $.each(data.data, function (index, val) {
                        html += '<div class="sale-cards"><div class="sale-container"><div class="sale-card"><div class="product-detail"><div class="sale-img">';
                        html += '<a href="javascript:void(0)"><img src="https://kemalellidort.com.tr/' + val.urun_resim_min + '"></a></div>';
                        html += '<div class="product-info"><div class="p-name"><a href="javascript:void(0)">' + val.urun_ad + '</a></div> <div class="p-price">Fiyat: <span>' + val.urun_alimfiyat + ' TL</span></div><div class="p-price">Toplam Kazanç:<span>' + val.price + ' TL</span></div><div class="p-quantity">Adet:<span>' + val.quantity + '</span></div></div></div>';
                        html += '<div class="sale-status status-0"><i class="fa-solid fa-gauge-high"></i> Teslimat bekliyor <button class="btn btn-primary btn-sm sale-detail-button align-self-end" data-bs-toggle="modal" data-bs-target="#info-alis-w-modal' + val.id + '"> İletilen Bilgiler </button></div>';
                        html += '<div class="sale-info"><div class="s-date"> <i class="fa-regular fa-clock"></i>' + val.added_time + '</div><div class="s-delivery">Satıcı: <a class="p-seller" href="">' + val.kullanici_ad + '</a></div></div></div><div class="sale-alerts "><div>' + val.urun_alimbaslik + '</div></div></div></div></div>';
                        html += '<div class="modal fade" id="info-alis-w-modal' + val.id + '" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true"><div class="modal-dialog"><div class="modal-content"><div class="modal-header"><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div><div class="modal-body"><div class="detail-data-rows"><div class="detail-data-row"><span class="detail-data-name">Oyundaki Karakter Adınız :</span><span class="detail-data-val">' + val.character_name + '</span></div></div></div><div class="modal-footer boder-0"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Kapat</button></div></div></div></div>';
                    });
                    $('#pills-waiting-6').html(html);
                } else {
                    Swal.fire({
                        title: 'Hata',
                        text: data.message,
                        icon: 'warning',
                    })
                }
            },
            error: function (response) {
                console.log(response);
            }
        });
        <?php else : ?>
        Swal.fire({
            title: 'Giriş Yap',
            text: "İşlem Yapabilmek İçin Giriş Yapmalısınız.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Giriş Yap',
            cancelButtonText: 'Hayır, İptal Et',
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = "<?= base_url('giris-yap') ?>";
            }
        })
        <?php endif; ?>
    }

    function sendAlimOnaylananAjaxRequest() {
        <?php if (aktif_kullanici()) : ?>
        $.post({
            url: "<?= base_url('tamamlanan-alimlar')?>",
            type: 'POST',
            success: function (response) {
                var data = JSON.parse(response);
                if (data.status === true) {
                    var html = '';
                    $.each(data.data, function (index, val) {
                        html += '<div class="sale-cards"><div class="sale-container"><div class="sale-card"><div class="product-detail"><div class="sale-img">';
                        html += '<a href="javascript:void(0)"><img src="https://kemalellidort.com.tr/' + val.urun_resim_min + '"> </a></div>';
                        html += '<div class="product-info"><div class="p-name"><a href="javascript:void(0)">' + val.urun_ad + '</a></div><div class="p-price">Fiyat: <span>' + val.urun_alimfiyat + ' TL</span></div><div class="p-price">Toplam Kazanç: <span>' + val.price + ' TL</span></div><div class="p-quantity">Adet: <span>' + val.quantity + '</span></div></div></div>';
                        html += '<div class="sale-info"><div class="s-date"><i class="fa-regular fa-clock"></i> ' + val.added_time + '</div><div class="s-delivery">Teslimat Tarihi: <span>' + val.delivery_date + '</span></div><div class="s-delivery">Satıcı: <a class="p-seller" href="">' + val.kullanici_ad + '</a></div></div></div>';
                        html += '<div class="sale-status-g"><div class="sale-status status-1"><i class="fa-solid fa-circle-check"></i> Teslim edildi</div><div class="s-name">Teslim edilecek karakter adı: <span>*******</span></div><button class="btn btn-primary btn-sm sale-detail-button align-self-end" data-bs-toggle="modal" data-bs-target="#info-alim-comp-modal-' + val.id + '">İletilen Bilgiler</button></div></div><div class="sale-alerts "><div>' + val.urun_alimbaslik + '</div></div></div>';
                        html += '<div class="modal fade" id="info-alim-comp-modal-' + val.id + '" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true"><div class="modal-dialog"><div class="modal-content"><div class="modal-header"><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div><div class="modal-body"><div class="detail-data-rows"><div class="detail-data-row"><span class="detail-data-name">Oyundaki Karakter Adınız :</span><span class="detail-data-val">' + val.character_name + '</span></div></div></div><div class="modal-footer boder-0"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Kapat</button></div></div></div></div>';
                    });
                    $('#pills-complate-6').html(html);
                } else {
                    Swal.fire({
                        title: 'Hata',
                        text: data.message,
                        icon: 'warning',
                    })
                }
            },
            error: function (response) {
                console.log(response);
            }
        });
        <?php else : ?>
        Swal.fire({
            title: 'Giriş Yap',
            text: "İşlem Yapabilmek İçin Giriş Yapmalısınız.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Giriş Yap',
            cancelButtonText: 'Hayır, İptal Et',
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = "<?= base_url('giris-yap') ?>";
            }
        })
        <?php endif; ?>
    }

    function sendAlimIptalAjaxRequest() {
        <?php if (aktif_kullanici()) : ?>
        $.post({
            url: "<?= base_url('iptal-edilen-alimlar')?>",
            type: 'POST',
            success: function (response) {
                var data = JSON.parse(response);
                if (data.status === true) {
                    var html = '';
                    $.each(data.data, function (index, val) {
                        html += '<div class="sale-cards"><div class="sale-container"><div class="sale-card"><div class="product-detail"><div class="sale-img">';
                        html += '<a href="javascript:void(0)"><img src="https://kemalellidort.com.tr/' + val.urun_resim_min + '"> </a></div>';
                        html += '<div class="product-info"><div class="p-name"><a href="javascript:void(0)">' + val.urun_ad + '</a></div><div class="p-price">Fiyat: <span>' + val.urun_alimfiyat + ' TL</span></div><div class="p-price">Toplam Kazanç: <span>' + val.price + ' TL</span></div><div class="p-quantity">Adet: <span>' + val.quantity + '</span></div></div></div>';
                        html += '<div class="sale-status status-2"><i class="fad fa-window-close"></i> İptal edildi <button class="btn btn-primary btn-sm sale-detail-button align-self-end" data-bs-toggle="modal" data-bs-target="#info-alim-cancel-modal-' + val.id + '">İletilen Bilgiler</button></div><div class="sale-info"><div class="s-date"><i class="fad fa-clock"></i> ' + val.added_time + '</div><div class="s-delivery">Satıcı: <a class="p-seller" href="javascript:void(0)">' + val.kullanici_ad + '</a></div></div></div>';
                        html += '<div class="sale-alerts red">Satışınız iptal edilmiştir.' + val.reason_for_cancellation + '</div></div></div>';
                        html += '<div class="modal fade" id="info-alim-cancel-modal-' + val.id + '" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true"><div class="modal-dialog"><div class="modal-content"><div class="modal-header"><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div><div class="modal-body"><div class="detail-data-rows"><div class="detail-data-row"><span class="detail-data-name">Oyundaki Karakter Adınız :</span><span class="detail-data-val">' + val.character_name + '</span></div></div></div><div class="modal-footer boder-0"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Kapat</button></div></div></div></div>'
                    });
                    $('#pills-canseled-6').html(html);
                } else {
                    Swal.fire({
                        title: 'Hata',
                        text: data.message,
                        icon: 'warning',
                    })
                }
            },
            error: function (response) {
                console.log(response);
            }
        });
        <?php else : ?>
        Swal.fire({
            title: 'Giriş Yap',
            text: "İşlem Yapabilmek İçin Giriş Yapmalısınız.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Giriş Yap',
            cancelButtonText: 'Hayır, İptal Et',
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = "<?= base_url('giris-yap') ?>";
            }
        })
        <?php endif; ?>
    }

</script>