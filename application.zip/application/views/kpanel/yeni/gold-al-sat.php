<main class="k-panel-warper">
    <div class="sec-warper mb-4">
        <div class="container normal-container p-0">
            <div class="k-panel-g-warper">
                <div class="row">
                    <div class="col-xl-3 col-lg-3 col-md-12 col-sm-12 wd-none mt-3 p-0 ">
                        <div class="accordion accordion-flush acc-kpc-menu" id="accordionFlushExample">
                            <div class="accordion-item acc-kpc-menu-item">
                                <h2 class="accordion-header acc-kpc-menu-header" id="flush-headingOne">
                                    <button class="accordion-button collapsed acc-kpc-menu-btn" type="button"
                                            data-bs-toggle="collapse" data-bs-target="#flush-collapseOne"
                                            aria-expanded="false" aria-controls="flush-collapseOne">
                                        Hızlı Menü
                                    </button>
                                </h2>
                                <div id="flush-collapseOne" class="accordion-collapse collapse"
                                     aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
                                    <div class="accordion-body acc-kpc-menu-body">
                                        <div class="k-panel-left-navbar-warper">
                                            <div class="k-panel-left-navbar-area">
                                                <div class="nav flex-column nav-pills bg-custom-none " id="v-pills-tab" role="tablist"
                                                     aria-orientation="vertical">
                                                    <?php if (magaza_check()) { ?>
                                                        <div class="gt-store">
                                                            <a href="<?php echo base_url('m/' . magaza($kullanici->kullanici_id)->magaza_seo) ?>"
                                                               class="btn btn-primary settings-btn mb-3 w-100">Mağzaya Git</a>
                                                        </div>
                                                    <?php } ?>
                                                    <a href="<?php echo base_url('hesabim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100">
                                                        <img class="panel-icon-img" src="<?php echo base_url('assets/front/images/') ?>" alt=""
                                                             loading="lazy"> Profilim</a>
                                                    <a href="<?php echo base_url('siparislerim') ?>" title=""
                                                       class="nav-link kpc-nav-btn w-spacial w-100">Siparişlerim</a>
                                                    <a href="<?php echo base_url('satislar') ?>" title=""
                                                       class="nav-link kpc-nav-btn w-spacial w-100 active">Gold Al - Sat</a>
                                                    <a href="<?php echo base_url('sorularim') ?>" title=""
                                                       class="nav-link kpc-nav-btn w-spacial w-100">Sorularım</a>
                                                    <a href="<?php echo base_url('bakiye') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100">Bakiye</a>
                                                    <a href="<?php echo base_url('odeme-talep') ?>" title=""
                                                       class="nav-link kpc-nav-btn w-spacial w-100">Para Çek</a>
                                                    <a href="<?php echo base_url('destek-taleplerim') ?>" title=""
                                                       class="nav-link kpc-nav-btn w-spacial w-100">Destek Taleplerim</a>
                                                    <a href="<?php echo base_url('itirazlarim') ?>" title=""
                                                       class="nav-link kpc-nav-btn w-spacial w-100">İtirazlarım</a>
                                                    <a href="<?php echo base_url('hesap-ayarlari') ?>" title=""
                                                       class="nav-link kpc-nav-btn w-spacial w-100">Profil Ayarlarım</a>
                                                    <a class="nav-link kpc-nav-btn w-spacial w-100" href="<?php echo base_url('cikis') ?>">Çıkış</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-3 col-md-12 col-sm-12 md-none pr-0">
                        <div class="k-panel-left-navbar-warper m-bg2">
                            <div class="k-panel-left-navbar-area">
                                <div class="nav flex-column nav-pills bg-custom-none " id="v-pills-tab" role="tablist"
                                     aria-orientation="vertical">
                                    <?php if (magaza_check()) { ?>
                                        <div class="gt-store">
                                            <a href="<?php echo base_url('m/' . magaza($kullanici->kullanici_id)->magaza_seo) ?>"
                                               class="btn btn-primary settings-btn mb-3 w-100">Mağzaya Git</a>
                                        </div>
                                    <?php } ?>
                                    <a href="<?php echo base_url('hesabim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"> <img
                                                class="sw-icon-item" src="<?php echo base_url('assets/front/images/uzer.webp') ?>" alt=""
                                                loading="lazy">Profilim</a>
                                    <a href="<?php echo base_url('siparislerim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"><img
                                                class="sw-icon-item" src="<?php echo base_url('assets/front/images/shopping-list.webp') ?>" alt=""
                                                loading="lazy">Siparişlerim</a>
                                    <a href="<?php echo base_url('satislar') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100 active"><img
                                                class="sw-icon-item" src="<?php echo base_url('assets/front/images/gold.webp') ?>" alt=""
                                                loading="lazy">Gold Al - Sat</a>
                                    <a href="<?php echo base_url('sorularim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"><img
                                                class="sw-icon-item" src="<?php echo base_url('assets/front/images/s4.png') ?>" alt="" loading="lazy">Sorularım</a>
                                    <a href="<?php echo base_url('bakiye') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"><img
                                                class="sw-icon-item" src="<?php echo base_url('assets/front/images/salary.webp') ?>" alt=""
                                                loading="lazy">Bakiye</a>
                                    <a href="<?php echo base_url('odeme-talep') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"><img
                                                class="sw-icon-item" src="<?php echo base_url('assets/front/images/transfer.webp') ?>" alt=""
                                                loading="lazy">Para Çekim</a>
                                    <a href="<?php echo base_url('destek-taleplerim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"><img
                                                class="sw-icon-item" src="<?php echo base_url('assets/front/images/customer-service.webp') ?>" alt=""
                                                loading="lazy">Destek Sistemi</a>
                                    <a href="<?php echo base_url('itirazlarim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"><img
                                                class="sw-icon-item" src="<?php echo base_url('assets/front/images/error.webp') ?>" alt=""
                                                loading="lazy">İtirazlarım</a>
                                    <a href="<?php echo base_url('hesap-ayarlari') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"><img
                                                class="sw-icon-item" src="<?php echo base_url('assets/front/images/s1.png') ?>" alt="" loading="lazy">Profil
                                        Ayarlarım</a>
                                    <a class="nav-link kpc-nav-btn w-spacial w-100" href="<?php echo base_url('cikis') ?>"><img class="sw-icon-item"
                                                                                                                                src="<?php echo base_url('assets/front/images/logout.webp') ?>"
                                                                                                                                alt="" loading="lazy">Çıkış</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-9 col-lg-9 col-md-12 col-sm-12 m-bg m-br">
                        <div class="bgs">
                            <div class="k-panel-content-right">
                                <div class="min-dsc">


                                <p>Aşağıda bulunan menüden sipariş türü
                                    seçimi
                                    yapınız. Seçim yaptıktan sonra
                                    siparişleriniz
                                    listelenecektir.<br>Detayını
                                    görmek istediğiniz siparişin
                                    üstüne
                                    tıklayınız.</p>
                                </div>
                                <div class="tab-content" id="v-pills-tabContent">
                                    <div class="tab-pane fade show active" id="gold-orders" role="tabpanel"
                                         aria-labelledby="gold-orders-tab" tabindex="0">
                                        <ul class="nav nav-pills mb-3 mt-3" id="pills-tab" role="tablist">
                                            <li class="nav-item" role="presentation">
                                                <button class="nav-link active" id="gold-purchased-tab"
                                                        data-bs-toggle="pill" data-bs-target="#gold-purchased" type="button"
                                                        role="tab" aria-controls="gold-purchased" aria-selected="true">Satın
                                                    Alınan Gold
                                                </button>
                                            </li>
                                            <li class="nav-item" role="presentation">
                                                <button class="nav-link" id="gold-sold-tab" data-bs-toggle="pill"
                                                        data-bs-target="#gold-sold" type="button" role="tab"
                                                        aria-controls="gold-sold" aria-selected="false">Satılan
                                                    Gold
                                                </button>
                                            </li>
                                        </ul>
                                        <div class="tab-content" id="pills-tabContent">
                                            <div class="tab-pane fade show active" id="gold-purchased" role="tabpanel"
                                                 aria-labelledby="gold-purchased-tab">
                                                <div class="container-fluid">
                                                    <div class="k-panel-content-box">
                                                        <div class="row">
                                                            <div class="col-12">
                                                                <div class="kpc-tt">
                                                                    Satın Aldığınız Gold'lar
                                                                </div>
                                                                <div class="mb-4">
                                                                    <div class="my-sales-tabs">
                                                                        <ul class="nav nav-pills mb-3 mt-3" id="pills-tab"
                                                                            role="tablist">
                                                                            <li class="nav-item" role="presentation">
                                                                                <button class="nav-link active"
                                                                                        id="pills-waiting-6-tab"
                                                                                        data-bs-toggle="pill"
                                                                                        data-bs-target="#pills-waiting-6"
                                                                                        type="button" role="tab"
                                                                                        aria-controls="pills-waiting-6"
                                                                                        aria-selected="true">Bekleyen
                                                                                </button>
                                                                            </li>
                                                                            <li class="nav-item" role="presentation">
                                                                                <button class="nav-link"
                                                                                        id="pills-complate-6-tab"
                                                                                        data-bs-toggle="pill"
                                                                                        data-bs-target="#pills-complate-6"
                                                                                        type="button" role="tab"
                                                                                        aria-controls="pills-complate-6"
                                                                                        aria-selected="false">Tamamlanan
                                                                                </button>
                                                                            </li>
                                                                            <li class="nav-item" role="presentation">
                                                                                <button class="nav-link"
                                                                                        id="pills-canseled-6-tab"
                                                                                        data-bs-toggle="pill"
                                                                                        data-bs-target="#pills-canseled-6"
                                                                                        type="button" role="tab"
                                                                                        aria-controls="pills-canseled-6"
                                                                                        aria-selected="false">İptal
                                                                                    Edilenler
                                                                                </button>
                                                                            </li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="tab-content" id="pills-tabContent">
                                                            <div class="tab-pane fade show active" id="pills-waiting-6"
                                                                 role="tabpanel" aria-labelledby="pills-waiting-6-tab">
                                                                <?php if (!empty($bekleyen_alislarim)) { ?>
                                                                    <?php foreach ($bekleyen_alislarim

                                                                                   as $key => $val) { ?>
                                                                        <div class="sale-cards">
                                                                            <div class="sale-container">
                                                                                <div class="sale-card <?php echo empty($val->delivery_character_name) ? 'sblur' : '' ?>">
                                                                                    <div class="product-detail">
                                                                                        <div class="sale-img"><a href="javascript:void(0)"><img
                                                                                                        src="<?php echo base_url($val->urun_resim_min) ?>"></a>
                                                                                        </div>
                                                                                        <div class="product-info">
                                                                                            <div class="p-name">
                                                                                                <a href="javascript:void(0)"><?php echo $val->urun_ad ?></a>
                                                                                            </div>
                                                                                            <div class="p-price">Fiyat :
                                                                                                <span><?php echo $val->urun_alimfiyat ?> TL</span>
                                                                                            </div>

                                                                                            <div class="p-quantity">
                                                                                                Adet :
                                                                                                <span><?php echo $val->quantity ?></span>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="sale-status status-0">
                                                                                        <div class="asdf"></div> <?php echo !empty($val->delivery_character_name) ? 'Teslimat bekliyor ' : 'İşlem Bekliyor' ?>
                                                                                        <button class="btn btn-primary btn-sm sale-detail-button align-self-end"
                                                                                                data-bs-toggle="modal"
                                                                                                data-bs-target="#info-alis-w-modal<?php echo $val->id ?>">
                                                                                            İletilen Bilgiler
                                                                                        </button>
                                                                                    </div>
                                                                                    <div class="sale-info">
                                                                                        <div class="s-date">
                                                                                            <?php echo $val->added_time ?>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="sale-alerts <?php echo empty($val->delivery_character_name) ? 'sposition' : '' ?>">
                                                                                    <div class="char-name-area">
                                                                                        <div class="charvs"> Teslim Edecek
                                                                                            Karakter Adı
                                                                                            : <?php echo !empty($val->delivery_character_name) ? $val->delivery_character_name : '<div class="loader"></div>' ?>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="modal fade"
                                                                             id="info-alis-w-modal<?php echo $val->id ?>"
                                                                             tabindex="-1"
                                                                             aria-labelledby="exampleModalLabel"
                                                                             aria-hidden="true">
                                                                            <div class="modal-dialog">
                                                                                <div class="modal-content">
                                                                                    <div class="modal-header">
                                                                                        <button type="button"
                                                                                                class="btn-close"
                                                                                                data-bs-dismiss="modal"
                                                                                                aria-label="Close"></button>
                                                                                    </div>
                                                                                    <div class="modal-body">
                                                                                        <div class="detail-data-rows">
                                                                                            <div class="detail-data-row">
                                                                                                <span class="detail-data-name">
                                                                                                    Oyundaki Karakter Adınız :
                                                                                                </span>
                                                                                                <span class="detail-data-val">
                                                                                                <?php echo $val->character_name ?>
                                                                                            </span>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="modal-footer boder-0">
                                                                                        <button type="button"
                                                                                                class="btn btn-secondary"
                                                                                                data-bs-dismiss="modal">
                                                                                            Kapat
                                                                                        </button>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    <?php } ?>
                                                                <?php } else { ?>
                                                                    <div class="sale-cards border-n"><h4
                                                                                class="inside-warning"> Herhangi bir geçmiş
                                                                            bekleyen alımınız bulunmuyor.</h4></div>
                                                                <?php } ?>
                                                            </div>
                                                            <div class="tab-pane fade" id="pills-complate-6"
                                                                 role="tabpanel" aria-labelledby="pills-complate-6-tab">
                                                                <?php if (!empty($tamamlanan_alislarim)) { ?>
                                                                    <?php foreach ($tamamlanan_alislarim as $key => $val) { ?>
                                                                        <div class="sale-cards">
                                                                            <div class="sale-container">
                                                                                <div class="sale-card">
                                                                                    <div class="product-detail">
                                                                                        <div class="sale-img">
                                                                                            <a href="javascript:void(0)">
                                                                                                <img src="<?php echo base_url($val->urun_resim_min) ?>">
                                                                                            </a>
                                                                                        </div>
                                                                                        <div class="product-info">
                                                                                            <div class="p-name">
                                                                                                <a href="javascript:void(0)"><?php echo $val->urun_ad ?></a>
                                                                                            </div>
                                                                                            <div class="p-price">
                                                                                                Fiyat :
                                                                                                <span><?php echo $val->urun_alimfiyat ?> TL</span>
                                                                                            </div>

                                                                                            <div class="p-quantity">
                                                                                                Adet :
                                                                                                <span><?php echo $val->quantity ?></span>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="sale-info">
                                                                                        <div class="s-delivery">
                                                                                            Teslimat Tarihi :
                                                                                            <span><?php echo $val->delivery_date ?></span>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="sale-gybf red">
                                                                                    <div class="sale-ybf">
                                                                                        <div class="sale-status status-1 dflx">
                                                                                            <div class="te-ip">
                                                                                                Teslim edilmiştir
                                                                                            </div>
                                                                                            <div class="s-name">
                                                                                                Teslim edilecek karakter adı:
                                                                                                <span>*******</span>
                                                                                            </div>
                                                                                            <button class="btn btn-primary btn-sm sale-detail-button align-self-end"
                                                                                                    data-bs-toggle="modal"
                                                                                                    data-bs-target="#info-alim-comp-modal-<?php echo $val->id ?>">
                                                                                                İletilen Bilgiler
                                                                                            </button>

                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="sale-alerts">
                                                                                        <div>
                                                                                            <?php echo $val->urun_alimbaslik ?>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="modal fade"
                                                                             id="info-alim-comp-modal-<?php echo $val->id ?>"
                                                                             tabindex="-1"
                                                                             aria-labelledby="exampleModalLabel"
                                                                             aria-hidden="true">
                                                                            <div class="modal-dialog">
                                                                                <div class="modal-content">
                                                                                    <div class="modal-header">
                                                                                        <button type="button"
                                                                                                class="btn-close"
                                                                                                data-bs-dismiss="modal"
                                                                                                aria-label="Close"></button>
                                                                                    </div>
                                                                                    <div class="modal-body">
                                                                                        <div class="detail-data-rows">
                                                                                            <div class="detail-data-row">
                                                                        <span class="detail-data-name">
                                                                            Oyundaki Karakter Adınız :
                                                                        </span>
                                                                                                <span class="detail-data-val">
                                                                            <?php echo $val->character_name ?>
                                                                        </span>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="modal-footer boder-0">
                                                                                        <button type="button"
                                                                                                class="btn btn-secondary"
                                                                                                data-bs-dismiss="modal">
                                                                                            Kapat
                                                                                        </button>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    <?php } ?>
                                                                <?php } else { ?>
                                                                    <div class="sale-cards border-n"><h4
                                                                                class="inside-warning"> Herhangi bir geçmiş
                                                                            tamamlanan alımınız bulunmuyor.</h4></div>
                                                                <?php } ?>
                                                            </div>
                                                            <div class="tab-pane fade" id="pills-canseled-6"
                                                                 role="tabpanel" aria-labelledby="pills-canseled-6-tab">
                                                                <?php if (!empty($iptal_edilen_alislarim)) { ?>
                                                                    <?php foreach ($iptal_edilen_alislarim as $key => $val) { ?>
                                                                        <div class="sale-cards">
                                                                            <div class="sale-container">
                                                                                <div class="sale-card">
                                                                                    <div class="product-detail">
                                                                                        <div class="sale-img">
                                                                                            <a href="javascript:void(0)">
                                                                                                <img src="<?php echo base_url($val->urun_resim_min) ?>">
                                                                                            </a>
                                                                                        </div>
                                                                                        <div class="product-info">
                                                                                            <div class="p-name">
                                                                                                <a href="javascript:vodi(0)"><?php echo $val->urun_ad ?></a>
                                                                                            </div>
                                                                                            <div class="p-price">
                                                                                                Fiyat :
                                                                                                <span><?php echo $val->urun_alimfiyat ?> TL</span>
                                                                                            </div>
                                                                                            <div class="p-quantity">
                                                                                                Adet :
                                                                                                <span><?php echo $val->quantity ?></span>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="sale-status status-2">
                                                                                        <img src="<?php echo base_url('assets/front/images/close.webp') ?>"
                                                                                             alt="">
                                                                                        İptal edildi
                                                                                        <button class="btn btn-primary btn-sm sale-detail-button align-self-end mt-3"
                                                                                                data-bs-toggle="modal"
                                                                                                data-bs-target="#info-alim-cancel-modal-<?php echo $val->id ?>">
                                                                                            İletilen Bilgiler
                                                                                        </button>
                                                                                    </div>
                                                                                    <div class="sale-info">
                                                                                        <div class="s-date">
                                                                                            <?php echo $val->added_time ?>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="sale-alerts red">
                                                                                    <?php echo 'İptal Sebebi : ' . $val->reason_for_cancellation ?>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="modal fade"
                                                                             id="info-alim-cancel-modal-<?php echo $val->id ?>"
                                                                             tabindex="-1"
                                                                             aria-labelledby="exampleModalLabel"
                                                                             aria-hidden="true">
                                                                            <div class="modal-dialog">
                                                                                <div class="modal-content">
                                                                                    <div class="modal-header">
                                                                                        <button type="button"
                                                                                                class="btn-close"
                                                                                                data-bs-dismiss="modal"
                                                                                                aria-label="Close"></button>
                                                                                    </div>
                                                                                    <div class="modal-body">
                                                                                        <div class="detail-data-rows">
                                                                                            <div class="detail-data-row">
                                                                        <span class="detail-data-name">
                                                                            Oyundaki Karakter Adınız :
                                                                        </span>
                                                                                                <span class="detail-data-val">
                                                                            <?php echo $val->character_name ?>
                                                                        </span>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="modal-footer boder-0">
                                                                                        <button type="button"
                                                                                                class="btn btn-secondary"
                                                                                                data-bs-dismiss="modal">
                                                                                            Kapat
                                                                                        </button>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    <?php } ?>
                                                                <?php } else { ?>
                                                                    <div class="sale-cards border-n"><h4
                                                                                class="inside-warning"> Herhangi bir geçmiş
                                                                            iptal edilen alımınız bulunmuyor.</h4></div>
                                                                <?php } ?>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="tab-pane fade" id="gold-sold" role="tabpanel"
                                                 aria-labelledby="gold-sold-tab">
                                                <div class="container-fluid">
                                                    <div class="k-panel-content-box">
                                                        <div class="row">
                                                            <div class="col-12">
                                                                <div class="mb-4">
                                                                    <div class="kpc-tt">
                                                                        Satmış Olduğunuz Gold'lar
                                                                    </div>
                                                                    <div class="getgold-area">
                                                                        <ul class="nav nav-pills mb-3 mt-3" id="pills-tab"
                                                                            role="tablist">
                                                                            <li class="nav-item" role="presentation">
                                                                                <button class="nav-link active"
                                                                                        id="pills-waiting-5-tab"
                                                                                        data-bs-toggle="pill"
                                                                                        data-bs-target="#pills-waiting-5"
                                                                                        type="button" role="tab"
                                                                                        aria-controls="pills-waiting-5"
                                                                                        aria-selected="true">Bekleyen
                                                                                </button>
                                                                            </li>
                                                                            <li class="nav-item" role="presentation">
                                                                                <button class="nav-link"
                                                                                        id="pills-complate-5-tab"
                                                                                        data-bs-toggle="pill"
                                                                                        data-bs-target="#pills-complate-5"
                                                                                        type="button" role="tab"
                                                                                        aria-controls="pills-complate-5"
                                                                                        aria-selected="false">Teslim Edilen
                                                                                </button>
                                                                            </li>
                                                                            <li class="nav-item" role="presentation">
                                                                                <button class="nav-link"
                                                                                        id="pills-canseled-5-tab"
                                                                                        data-bs-toggle="pill"
                                                                                        data-bs-target="#pills-canseled-5"
                                                                                        type="button" role="tab"
                                                                                        aria-controls="pills-canseled-5"
                                                                                        aria-selected="false">İptal Edilen
                                                                                </button>
                                                                            </li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="tab-content" id="pills-tabContent">
                                                            <div class="tab-pane fade show active" id="pills-waiting-5"
                                                                 role="tabpanel" aria-labelledby="pills-waiting-5-tab">
                                                                <?php if (!empty($bekleyen_satislarim)) { ?>
                                                                    <?php foreach ($bekleyen_satislarim as $key => $val) { ?>
                                                                        <div class="sale-blr">
                                                                            <div class="sale-cards">
                                                                                <div class="sale-container">
                                                                                    <div class="sale-card <?php echo empty($val->delivery_character_name) ? 'sblur' : '' ?>">
                                                                                        <div class="product-detail">
                                                                                            <div class="sale-img">
                                                                                                <a href="javascript:void(0)">
                                                                                                    <img src="<?php echo base_url($val->urun_resim_min) ?>">
                                                                                                </a>
                                                                                            </div>
                                                                                            <div class="product-info">
                                                                                                <div class="p-name">
                                                                                                    <a href="javascript:void(0)">
                                                                                                        <?php echo $val->urun_ad ?>
                                                                                                    </a>
                                                                                                </div>
                                                                                                <div class="p-price">Fiyat :
                                                                                                    <span><?php echo $val->urun_alimfiyat ?> TL</span>
                                                                                                </div>
                                                                                                <div class="p-price">Toplam
                                                                                                    Kazanç:
                                                                                                    <span><?php echo $val->price ?> TL</span>
                                                                                                </div>
                                                                                                <div class="p-quantity">
                                                                                                    Adet :
                                                                                                    <span><?php echo $val->quantity ?></span>
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div class="sale-status status-0">
                                                                                            <?php echo !empty($val->delivery_character_name) ? 'Teslimat bekliyor' : 'İşlem Bekliyor' ?>
                                                                                            <button class="btn btn-primary btn-sm sale-detail-button align-self-end"
                                                                                                    data-bs-toggle="modal"
                                                                                                    data-bs-target="#info-satim-modal-<?php echo $val->id ?>">
                                                                                                İletilen Bilgiler
                                                                                            </button>
                                                                                        </div>
                                                                                        <div class="sale-info">
                                                                                            <div class="s-date">
                                                                                                <?php echo $val->added_time ?>
                                                                                            </div>

                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="sale-alerts <?php echo empty($val->delivery_character_name) ? 'sposition' : '' ?>">
                                                                                        <div class="char-name-area">
                                                                                            <div class="charvs">
                                                                                                Teslim Alacak Karakter Adı
                                                                                                : <?php echo !empty($val->delivery_character_name) ? $val->delivery_character_name : '<div class="loader"></div>' ?>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="modal fade"
                                                                             id="info-satim-modal-<?php echo $val->id ?>"
                                                                             tabindex="-1"
                                                                             aria-labelledby="exampleModalLabel"
                                                                             aria-hidden="true">
                                                                            <div class="modal-dialog">
                                                                                <div class="modal-content">
                                                                                    <div class="modal-header">
                                                                                        <button type="button"
                                                                                                class="btn-close"
                                                                                                data-bs-dismiss="modal"
                                                                                                aria-label="Close"></button>
                                                                                    </div>
                                                                                    <div class="modal-body">
                                                                                        <div class="detail-data-rows">
                                                                                            <div class="detail-data-row">
                                                                        <span class="detail-data-name">
                                                                            Oyundaki Karakter Adınız :
                                                                        </span>
                                                                                                <span class="detail-data-val">
                                                                            <?php echo $val->character_name ?>
                                                                        </span>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="modal-footer boder-0">
                                                                                        <button type="button"
                                                                                                class="btn btn-secondary"
                                                                                                data-bs-dismiss="modal">
                                                                                            Kapat
                                                                                        </button>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    <?php } ?>
                                                                <?php } else { ?>
                                                                    <div class="sale-cards border-n"><h4
                                                                                class="inside-warning"> Herhangi bir geçmiş
                                                                            bekleyen satışınız bulunmuyor.</h4></div>
                                                                <?php } ?>
                                                            </div>
                                                            <div class="tab-pane fade" id="pills-complate-5" role="tabpanel"
                                                                 aria-labelledby="pills-complate-5-tab">
                                                                <?php if (!empty($tamamlanan_satislarim)) { ?>
                                                                    <?php foreach ($tamamlanan_satislarim as $key => $val) { ?>
                                                                        <div class="sale-cards">
                                                                            <div class="sale-container">
                                                                                <div class="sale-card">
                                                                                    <div class="product-detail">
                                                                                        <div class="sale-img">
                                                                                            <a href="javascript:void(0)">
                                                                                                <img src="<?php echo base_url($val->urun_resim_min) ?>">
                                                                                            </a>
                                                                                        </div>
                                                                                        <div class="product-info">
                                                                                            <div class="p-name">
                                                                                                <a href="javascript:void(0)">
                                                                                                    <?php echo $val->urun_ad ?>
                                                                                                </a>
                                                                                            </div>
                                                                                            <div class="p-price">
                                                                                                Fiyat :
                                                                                                <span><?php echo $val->urun_alimfiyat ?> TL</span>
                                                                                            </div>
                                                                                            <div class="p-price">
                                                                                                Toplam Kazanç :
                                                                                                <span><?php echo $val->price ?> TL</span>
                                                                                            </div>
                                                                                            <div class="p-quantity">
                                                                                                Adet :
                                                                                                <span><?php echo $val->quantity ?></span>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="sale-info">
                                                                                        <div class="s-delivery">
                                                                                            Teslimat Tarihi :
                                                                                            <span><?php echo $val->delivery_date ?></span>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="sale-gybf red">
                                                                                    <div class="sale-ybf">
                                                                                        <div class="sale-status status-1 dflx">
                                                                                            <div class="te-ip">
                                                                                                Teslim edilmiştir
                                                                                            </div>
                                                                                            <div class="s-name">
                                                                                                Teslim edilecek karakter adı:
                                                                                                <span>*******</span>
                                                                                            </div>
                                                                                            <button class="btn btn-primary btn-sm sale-detail-button align-self-end"
                                                                                                    data-bs-toggle="modal"
                                                                                                    data-bs-target="#info-satim-comp-modal-<?php echo $val->id ?>">
                                                                                                İletilen Bilgiler
                                                                                            </button>

                                                                                        </div>
                                                                                        <div class="sale-alerts ">
                                                                                            <div>
                                                                                                <?php echo $val->urun_alimbaslik ?>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="modal fade"
                                                                             id="info-satim-comp-modal-<?php echo $val->id ?>"
                                                                             tabindex="-1"
                                                                             aria-labelledby="exampleModalLabel"
                                                                             aria-hidden="true">
                                                                            <div class="modal-dialog">
                                                                                <div class="modal-content">
                                                                                    <div class="modal-header">
                                                                                        <button type="button"
                                                                                                class="btn-close"
                                                                                                data-bs-dismiss="modal"
                                                                                                aria-label="Close"></button>
                                                                                    </div>
                                                                                    <div class="modal-body">
                                                                                        <div class="detail-data-rows">
                                                                                            <div class="detail-data-row">
                                                                                            <span class="detail-data-name">
                                                                                                Oyundaki Karakter Adınız :
                                                                                            </span>
                                                                                                <span class="detail-data-val">
                                                                                                <?php echo $val->character_name ?>
                                                                                            </span>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="modal-footer boder-0">
                                                                                        <button type="button"
                                                                                                class="btn btn-secondary"
                                                                                                data-bs-dismiss="modal">
                                                                                            Kapat
                                                                                        </button>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    <?php } ?>
                                                                <?php } else { ?>
                                                                    <div class="sale-cards border-n"><h4
                                                                                class="inside-warning"> Herhangi bir geçmiş
                                                                            tamamlanan satışınız bulunmuyor.</h4></div>
                                                                <?php } ?>
                                                            </div>
                                                            <div class="tab-pane fade" id="pills-canseled-5"
                                                                 role="tabpanel" aria-labelledby="pills-canseled-5-tab">
                                                                <?php if (!empty($iptal_edilen_satislarim)) { ?>
                                                                    <?php foreach ($iptal_edilen_satislarim as $key => $val) { ?>
                                                                        <div class="sale-cards">
                                                                            <div class="sale-container">
                                                                                <div class="sale-card">
                                                                                    <div class="product-detail">
                                                                                        <div class="sale-img">
                                                                                            <a href="javascript:void(0)">
                                                                                                <img src="<?php echo base_url($val->urun_resim_min) ?>">
                                                                                            </a>
                                                                                        </div>
                                                                                        <div class="product-info">
                                                                                            <div class="p-name">
                                                                                                <a href="javascript:void(0)">
                                                                                                    <?php echo $val->urun_ad ?>
                                                                                                </a>
                                                                                            </div>
                                                                                            <div class="p-price">
                                                                                                Fiyat :
                                                                                                <span><?php echo $val->urun_alimfiyat ?> TL</span>
                                                                                            </div>
                                                                                            <div class="p-price">
                                                                                                Toplam Kazanç :
                                                                                                <span><?php echo $val->price ?> TL</span>
                                                                                            </div>
                                                                                            <div class="p-quantity">
                                                                                                Adet :
                                                                                                <span><?php echo $val->quantity ?></span>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="sale-status status-2">
                                                                                        <img src="<?php echo base_url('assets/front/images/close.webp') ?>"
                                                                                             alt="">
                                                                                        İptal edildi
                                                                                        <button class="btn btn-primary btn-sm sale-detail-button align-self-end mt-3"
                                                                                                data-bs-toggle="modal"
                                                                                                data-bs-target="#info-satim-cancel-modal-<?php echo $val->id ?>">
                                                                                            İletilen Bilgiler
                                                                                        </button>
                                                                                    </div>
                                                                                    <div class="sale-info">
                                                                                        <div class="s-date">

                                                                                            <?php echo $val->added_time ?>
                                                                                        </div>

                                                                                    </div>
                                                                                </div>
                                                                                <div class="sale-alerts red">
                                                                                    İptal Sebebi: <?php echo $val->reason_for_cancellation ?>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="modal fade"
                                                                             id="info-satim-cancel-modal-<?php echo $val->id ?>"
                                                                             tabindex="-1"
                                                                             aria-labelledby="exampleModalLabel"
                                                                             aria-hidden="true">
                                                                            <div class="modal-dialog">
                                                                                <div class="modal-content">
                                                                                    <div class="modal-header">
                                                                                        <button type="button"
                                                                                                class="btn-close"
                                                                                                data-bs-dismiss="modal"
                                                                                                aria-label="Close"></button>
                                                                                    </div>
                                                                                    <div class="modal-body">
                                                                                        <div class="detail-data-rows">
                                                                                            <div class="detail-data-row">
                                                                        <span class="detail-data-name">
                                                                            Oyundaki Karakter Adınız :
                                                                        </span>
                                                                                                <span class="detail-data-val">
                                                                            <?php echo $val->character_name ?>
                                                                        </span>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="modal-footer boder-0">
                                                                                        <button type="button"
                                                                                                class="btn btn-secondary"
                                                                                                data-bs-dismiss="modal">
                                                                                            Kapat
                                                                                        </button>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    <?php } ?>
                                                                <?php } else { ?>
                                                                    <div class="sale-cards border-n"><h4
                                                                                class="inside-warning"> Herhangi bir geçmiş
                                                                            iptal edilen satışınız bulunmuyor.</h4></div>
                                                                <?php } ?>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<script>
    setInterval(sendBekleyenAjaxRequest, 20000);
    setInterval(sendOnaylananAjaxRequest, 20000);
    setInterval(sendIptalAjaxRequest, 20000);

    setInterval(sendAlimBekleyenAjaxRequest, 20000);
    setInterval(sendAlimOnaylananAjaxRequest, 20000);
    setInterval(sendAlimIptalAjaxRequest, 20000);

    //Satışlar

    function sendBekleyenAjaxRequest() {
        <?php if (aktif_kullanici()) : ?>
        $.post({
            url: "<?= base_url('onay-bekleyen-satislar')?>",
            type: 'POST',
            success: function (response) {
                var data = JSON.parse(response);
                if (data.status === true) {
                    var html = '';
                    if (data.data.length === 0) {
                        html += '<div class="sale-cards border-n"><h4 class="inside-warning"> Herhangi bir geçmiş bekleyen satışınız bulunmuyor</h4></div>';
                    } else {
                        $.each(data.data, function (index, val) {
                            if (val.delivery_character_name == null || val.delivery_character_name == '') {
                                var type_text_satis = 'İşlem Bekliyor';
                                var delivery_character_name_text_satis = '<div class="loader"></div>';
                                var blur_class_satis = 'sblur';
                                var blur_position_satis = 'sposition';
                            } else {
                                var type_text_satis = 'Teslimat Bekliyor';
                                var delivery_character_name_text_satis = val.delivery_character_name;
                                var blur_class_satis = '';
                                var blur_position_satis = '';
                            }
                            html += '<div class="sale-cards"><div class="sale-container"><div class="sale-card ' + blur_class_satis + '"><div class="product-detail"><div class="sale-img">';
                            html += '<a href="javascript:void(0)"><img src="https://kemalellidort.com.tr/' + val.urun_resim_min + '"></a></div>';
                            html += '<div class="product-info"><div class="p-name"><a href="javascript:void(0)">' + val.urun_ad + '</a></div> <div class="p-price">Fiyat : <span>' + val.urun_alimfiyat + ' TL</span></div><div class="p-quantity">Adet :<span>' + val.quantity + '</span></div></div></div>';
                            html += '<div class="sale-status status-0"> ' + type_text_satis + ' <button class="btn btn-primary btn-sm sale-detail-button align-self-end" data-bs-toggle="modal" data-bs-target="#info-satim-modal-' + val.id + '"> İletilen Bilgiler </button></div>';
                            html += '<div class="sale-info"></div></div><div class="sale-alerts ' + blur_position_satis + '"><div class="char-name-area"><div class="charvs">Teslim Alacak Karakter Adı : ' + delivery_character_name_text_satis + '</div></div></div></div></div></div>';
                            html += '<div class="modal fade" id="info-satim-modal-' + val.id + '" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true"><div class="modal-dialog"><div class="modal-content"><div class="modal-header"><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div><div class="modal-body"><div class="detail-data-rows"><div class="detail-data-row"><span class="detail-data-name">Oyundaki Karakter Adınız :</span><span class="detail-data-val">' + val.character_name + '</span></div></div></div><div class="modal-footer boder-0"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Kapat</button></div></div></div></div>';
                        });
                    }

                    $('#pills-waiting-5').html(html);
                } else {
                    Swal.fire({
                        title: 'Hata',
                        text: data.message,
                        icon: 'warning',
                    })
                }
            },
            error: function (response) {
                console.log(response);
            }
        });
        <?php else : ?>
        Swal.fire({
            title: 'Giriş Yap',
            text: "İşlem Yapabilmek İçin Giriş Yapmalısınız.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Giriş Yap',
            cancelButtonText: 'Hayır, İptal Et',
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = "<?= base_url('giris-yap') ?>";
            }
        })
        <?php endif; ?>
    }

    function sendOnaylananAjaxRequest() {
        <?php if (aktif_kullanici()) : ?>
        $.post({
            url: "<?= base_url('tamamlanan-satislar')?>",
            type: 'POST',
            success: function (response) {
                var data = JSON.parse(response);
                if (data.status === true) {
                    var html = '';
                    if (data.data.length === 0) {
                        html += '<div class="sale-cards border-n"><h4 class="inside-warning"> Herhangi bir geçmiş tamamlanan satışınız bulunmuyor</h4></div>';
                    } else {
                        $.each(data.data, function (index, val) {
                            html += '<div class="sale-cards"><div class="sale-container"><div class="sale-card"><div class="product-detail"><div class="sale-img">';
                            html += '<a href="javascript:void(0)"><img src="https://kemalellidort.com.tr/' + val.urun_resim_min + '"> </a></div>';
                            html += '<div class="product-info"><div class="p-name"><a href="javascript:void(0)">' + val.urun_ad + '</a></div><div class="p-price">Fiyat : <span>' + val.urun_alimfiyat + ' TL</span></div><div class="p-quantity">Adet : <span>' + val.quantity + '</span></div></div></div>';
                            html += '<div class="sale-info"><div class="s-delivery">Teslimat Tarihi : <span>' + val.delivery_date + '</span></div><div class="s-delivery">Satıcı: <a class="p-seller" href="">' + val.kullanici_ad + '</a></div></div></div>';
                            html += '<div class="sale-status-g"><div class="sale-status status-1"> Teslim edilmiştir</div><div class="s-name">Teslim edilecek karakter adı: <span>*******</span></div><button class="btn btn-primary btn-sm sale-detail-button align-self-end" data-bs-toggle="modal" data-bs-target="#info-satim-comp-modal-' + val.id + '">İletilen Bilgiler</button></div></div><div class="sale-alerts "><div>' + val.urun_alimbaslik + '</div></div></div>';
                            html += '<div class="modal fade" id="info-satim-comp-modal-' + val.id + '" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true"><div class="modal-dialog"><div class="modal-content"><div class="modal-header"><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div><div class="modal-body"><div class="detail-data-rows"><div class="detail-data-row"><span class="detail-data-name">Oyundaki Karakter Adınız :</span><span class="detail-data-val">' + val.character_name + '</span></div></div></div><div class="modal-footer boder-0"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Kapat</button></div></div></div></div>';
                        });
                    }
                    $('#pills-complate-5').html(html);
                } else {
                    Swal.fire({
                        title: 'Hata',
                        text: data.message,
                        icon: 'warning',
                    })
                }
            },
            error: function (response) {
                console.log(response);
            }
        });
        <?php else : ?>
        Swal.fire({
            title: 'Giriş Yap',
            text: "İşlem Yapabilmek İçin Giriş Yapmalısınız.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Giriş Yap',
            cancelButtonText: 'Hayır, İptal Et',
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = "<?= base_url('giris-yap') ?>";
            }
        })
        <?php endif; ?>
    }

    function sendIptalAjaxRequest() {
        <?php if (aktif_kullanici()) : ?>
        $.post({
            url: "<?= base_url('iptal-edilen-satislar')?>",
            type: 'POST',
            success: function (response) {
                var data = JSON.parse(response);
                if (data.status === true) {
                    var html = '';
                    if (data.data.length === 0) {
                        html += '<div class="sale-cards border-n"><h4 class="inside-warning"> Herhangi bir geçmiş iptal edilen satışınız bulunmuyor</h4></div>';
                    } else {
                        $.each(data.data, function (index, val) {
                            html += '<div class="sale-cards"><div class="sale-container"><div class="sale-card"><div class="product-detail"><div class="sale-img">';
                            html += '<a href="javascript:void(0)"><img src="https://kemalellidort.com.tr/' + val.urun_resim_min + '"> </a></div>';
                            html += '<div class="product-info"><div class="p-name"><a href="javascript:void(0)">' + val.urun_ad + '</a></div><div class="p-price">Fiyat : <span>' + val.urun_alimfiyat + ' TL</span></div><div class="p-price">Toplam Kazanç : <span>' + val.price + ' TL</span></div><div class="p-quantity">Adet : <span>' + val.quantity + '</span></div></div></div>';
                            html += '<div class="sale-status status-2"><img src="<?php echo base_url('assets/front/images/close.webp') ?>" alt=""> İptal edildi <button class="btn btn-primary btn-sm sale-detail-button align-self-end" data-bs-toggle="modal" data-bs-target="#info-satim-cancel-modal-' + val.id + '">İletilen Bilgiler</button></div><div class="sale-info"><div class="s-date"> <img src="<?php echo base_url('assets/front/images/clock.png') ?>" alt=""> ' + val.added_time + '</div></div></div>';
                            html += '<div class="sale-alerts red">Satışınız iptal edilmiştir.' + val.reason_for_cancellation + '</div></div></div>';
                            html += '<div class="modal fade" id="info-satim-cancel-modal-' + val.id + '" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true"><div class="modal-dialog"><div class="modal-content"><div class="modal-header"><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div><div class="modal-body"><div class="detail-data-rows"><div class="detail-data-row"><span class="detail-data-name">Oyundaki Karakter Adınız :</span><span class="detail-data-val">' + val.character_name + '</span></div></div></div><div class="modal-footer boder-0"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Kapat</button></div></div></div></div>'
                        });
                    }
                    $('#pills-canseled-5').html(html);
                } else {
                    Swal.fire({
                        title: 'Hata',
                        text: data.message,
                        icon: 'warning',
                    })
                }
            },
            error: function (response) {
                console.log(response);
            }
        });
        <?php else : ?>
        Swal.fire({
            title: 'Giriş Yap',
            text: "İşlem Yapabilmek İçin Giriş Yapmalısınız.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Giriş Yap',
            cancelButtonText: 'Hayır, İptal Et',
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = "<?= base_url('giris-yap') ?>";
            }
        })
        <?php endif; ?>
    }

    // Alimlar

    function sendAlimBekleyenAjaxRequest() {
        <?php if (aktif_kullanici()) : ?>
        $.post({
            url: "<?= base_url('onay-bekleyen-alimlar')?>",
            type: 'POST',
            success: function (response) {
                var data = JSON.parse(response);
                if (data.status === true) {
                    var html = '';
                    if (data.data.length === 0) {
                        html += '<div class="sale-cards border-n"><h4 class="inside-warning"> Herhangi bir geçmiş bekleyen alımınız bulunmuyor</h4></div>';
                    } else {
                        $.each(data.data, function (index, val) {
                            if (val.delivery_character_name == null || val.delivery_character_name == '') {
                                var type_text = 'İşlem Bekliyor';
                                var delivery_character_name_text = '<div class="loader"></div>';
                                var blur_class = 'sblur';
                                var blur_position = 'sposition';
                            } else {
                                var type_text = 'Teslimat Bekliyor';
                                var delivery_character_name_text = val.delivery_character_name;
                                var blur_class = '';
                                var blur_position = '';
                            }


                            html += '<div class="sale-cards"><div class="sale-container"><div class="sale-card ' + blur_class + '"><div class="product-detail"><div class="sale-img">';
                            html += '<a href="javascript:void(0)"><img src="https://kemalellidort.com.tr/' + val.urun_resim_min + '"></a></div>';
                            html += '<div class="product-info"><div class="p-name"><a href="javascript:void(0)">' + val.urun_ad + '</a></div> <div class="p-price">Fiyat : <span>' + val.urun_alimfiyat + ' TL</span></div><div class="p-quantity">Adet :<span>' + val.quantity + '</span></div></div></div>';
                            html += '<div class="sale-status status-0"> ' + type_text + ' <button class="btn btn-primary btn-sm sale-detail-button align-self-end" data-bs-toggle="modal" data-bs-target="#info-alis-w-modal' + val.id + '"> İletilen Bilgiler </button></div>';
                            html += '<div class="sale-info"></div></div><div class="sale-alerts ' + blur_position + '"><div class="char-name-area""><div class="charvs">Teslim Edecek Karakter İsmi : ' + delivery_character_name_text + '</div></div></div></div></div></div>';
                            html += '<div class="modal fade" id="info-alis-w-modal' + val.id + '" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true"><div class="modal-dialog"><div class="modal-content"><div class="modal-header"><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div><div class="modal-body"><div class="detail-data-rows"><div class="detail-data-row"><span class="detail-data-name">Oyundaki Karakter Adınız :</span><span class="detail-data-val">' + val.character_name + '</span></div></div></div><div class="modal-footer boder-0"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Kapat</button></div></div></div></div>';
                        });
                    }
                    $('#pills-waiting-6').html(html);
                } else {
                    Swal.fire({
                        title: 'Hata',
                        text: data.message,
                        icon: 'warning',
                    })
                }
            },
            error: function (response) {
                console.log(response);
            }
        });
        <?php else : ?>
        Swal.fire({
            title: 'Giriş Yap',
            text: "İşlem Yapabilmek İçin Giriş Yapmalısınız.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Giriş Yap',
            cancelButtonText: 'Hayır, İptal Et',
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = "<?= base_url('giris-yap') ?>";
            }
        })
        <?php endif; ?>
    }

    function sendAlimOnaylananAjaxRequest() {
        <?php if (aktif_kullanici()) : ?>
        $.post({
            url: "<?= base_url('tamamlanan-alimlar')?>",
            type: 'POST',
            success: function (response) {
                var data = JSON.parse(response);
                if (data.status === true) {
                    var html = '';
                    if (data.data.length === 0) {
                        html += '<div class="sale-cards border-n"><h4 class="inside-warning"> Herhangi bir geçmiş tamamlanan alımınız bulunmuyor</h4></div>';
                    } else {
                        $.each(data.data, function (index, val) {
                            html += '<div class="sale-cards"><div class="sale-container"><div class="sale-card"><div class="product-detail"><div class="sale-img">';
                            html += '<a href="javascript:void(0)"><img src="https://kemalellidort.com.tr/' + val.urun_resim_min + '"> </a></div>';
                            html += '<div class="product-info"><div class="p-name"><a href="javascript:void(0)">' + val.urun_ad + '</a></div><div class="p-price">Fiyat : <span>' + val.urun_alimfiyat + ' TL</span></div><div class="p-price">Toplam Kazanç : <span>' + val.price + ' TL</span></div><div class="p-quantity">Adet : <span>' + val.quantity + '</span></div></div></div>';
                            html += '<div class="sale-info"><div class="s-delivery">Teslimat Tarihi : <span>' + val.delivery_date + '</span></div></div>';

                            html += '</div> <div class="sale-gybf red"><div class="sale-ybf"><div class="sale-status status-1 dflx"><div class="te-ip">  Teslim edilmiştir </div><div class="s-name">Teslim edilecek karakter adı:<span>*******</span></div><button class="btn btn-primary btn-sm sale-detail-button align-self-end" data-bs-toggle="modal" data-bs-target="#info-alim-comp-modal-' + val.id + '">İletilen Bilgiler</button></div></div><div class="sale-alerts"><div>' + val.urun_alimbaslik + '</div></div></div> ';

                            html += '<div class="modal fade" id="info-alim-comp-modal-' + val.id + '" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true"><div class="modal-dialog"><div class="modal-content"><div class="modal-header"><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div><div class="modal-body"><div class="detail-data-rows"><div class="detail-data-row"><span class="detail-data-name">Oyundaki Karakter Adınız :</span><span class="detail-data-val">' + val.character_name + '</span></div></div></div><div class="modal-footer boder-0"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Kapat</button></div></div></div></div>';
                        });
                    }
                    $('#pills-complate-6').html(html);
                } else {
                    Swal.fire({
                        title: 'Hata',
                        text: data.message,
                        icon: 'warning',
                    })
                }
            },
            error: function (response) {
                console.log(response);
            }
        });
        <?php else : ?>
        Swal.fire({
            title: 'Giriş Yap',
            text: "İşlem Yapabilmek İçin Giriş Yapmalısınız.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Giriş Yap',
            cancelButtonText: 'Hayır, İptal Et',
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = "<?= base_url('giris-yap') ?>";
            }
        })
        <?php endif; ?>
    }

    function sendAlimIptalAjaxRequest() {
        <?php if (aktif_kullanici()) : ?>
        $.post({
            url: "<?= base_url('iptal-edilen-alimlar')?>",
            type: 'POST',
            success: function (response) {
                var data = JSON.parse(response);
                if (data.status === true) {
                    var html = '';
                    if (data.data.length === 0) {
                        html += '<div class="sale-cards border-n"><h4 class="inside-warning"> Herhangi bir geçmiş iptal edilen alımınız bulunmuyor</h4></div>';
                    } else {
                        $.each(data.data, function (index, val) {
                            html += '<div class="sale-cards"><div class="sale-container"><div class="sale-card"><div class="product-detail"><div class="sale-img">';
                            html += '<a href="javascript:void(0)"><img src="https://kemalellidort.com.tr/' + val.urun_resim_min + '"> </a></div>';
                            html += '<div class="product-info"><div class="p-name"><a href="javascript:void(0)">' + val.urun_ad + '</a></div><div class="p-price">Fiyat : <span>' + val.urun_alimfiyat + ' TL</span></div><div class="p-price">Toplam Kazanç : <span>' + val.price + ' TL</span></div><div class="p-quantity">Adet : <span>' + val.quantity + '</span></div></div></div>';
                            html += ' <div class="sale-status status-2"> <img src="https://kemalellidort.com.tr/assets/front/images/close.webp" alt=""> İptal edildi <button class="btn btn-primary btn-sm sale-detail-button align-self-end mt-3" data-bs-toggle="modal" data-bs-target="#info-alim-cancel-modal-' + val.id + '"> İletilen Bilgiler </button></div><div class="sale-info"> <div class="s-date"> ' + val.added_time + ' </div></div>';

                            html += '</div><div class="sale-alerts red">İptal Sebebi: ' + val.reason_for_cancellation + '</div>';
                            html += '<div class="modal fade" id="info-alim-cancel-modal-' + val.id + '" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true"><div class="modal-dialog"><div class="modal-content"><div class="modal-header"><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div><div class="modal-body"><div class="detail-data-rows"><div class="detail-data-row"><span class="detail-data-name">Oyundaki Karakter Adınız :</span><span class="detail-data-val">' + val.character_name + '</span></div></div></div><div class="modal-footer boder-0"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Kapat</button></div></div></div></div>'
                        });
                    }
                    $('#pills-canseled-6').html(html);
                } else {
                    Swal.fire({
                        title: 'Hata',
                        text: data.message,
                        icon: 'warning',
                    })
                }
            },
            error: function (response) {
                console.log(response);
            }
        });
        <?php else : ?>
        Swal.fire({
            title: 'Giriş Yap',
            text: "İşlem Yapabilmek İçin Giriş Yapmalısınız.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Giriş Yap',
            cancelButtonText: 'Hayır, İptal Et',
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = "<?= base_url('giris-yap') ?>";
            }
        })
        <?php endif; ?>
    }

</script>