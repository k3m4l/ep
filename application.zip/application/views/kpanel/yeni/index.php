<main class="k-panel-warper">
    <div class="sec-warper mb-4">
        <div class="container normal-container p-0">
            <div class="k-panel-g-warper">
                <div class="row">
                    <div class="col-xl-3 col-lg-3 col-md-12 col-sm-12 wd-none mt-3 p-0 ">
                        <div class="accordion accordion-flush acc-kpc-menu" id="accordionFlushExample">
                            <div class="accordion-item acc-kpc-menu-item">
                                <h2 class="accordion-header acc-kpc-menu-header" id="flush-headingOne">
                                    <button class="accordion-button collapsed acc-kpc-menu-btn" type="button"
                                            data-bs-toggle="collapse" data-bs-target="#flush-collapseOne"
                                            aria-expanded="false" aria-controls="flush-collapseOne">
                                        Hızlı Menü
                                    </button>
                                </h2>
                                <div id="flush-collapseOne" class="accordion-collapse collapse"
                                     aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
                                    <div class="accordion-body acc-kpc-menu-body">
                                        <div class="k-panel-left-navbar-warper">
                                            <div class="k-panel-left-navbar-area">
                                                <div class="nav flex-column nav-pills bg-custom-none " id="v-pills-tab" role="tablist"
                                                    aria-orientation="vertical">
                                                <?php if (magaza_check()) { ?>
                                                        <div class="gt-store">
                                                            <a href="<?php echo base_url('m/'.magaza($kullanici->kullanici_id)->magaza_seo) ?>" class="btn btn-primary settings-btn mb-3 w-100">Mağzaya Git</a>
                                                        </div>
                                                    <?php } ?>
                                                    <a href="<?php echo base_url('hesabim') ?>" title="" class="nav-link kpc-nav-btn active"> Profilim</a>
                                                    <a href="<?php echo base_url('siparislerim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100">Siparişlerim</a>
                                                    <a href="<?php echo base_url('satislar') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100">Gold Al - Sat</a>
                                                    <a href="<?php echo base_url('sorularim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100">Sorularım</a>
                                                    <a href="<?php echo base_url('bakiye') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100">Bakiye</a>
                                                    <a href="<?php echo base_url('odeme-talep') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100">Para Çek</a>
                                                    <a href="<?php echo base_url('destek-taleplerim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100">Destek Taleplerim</a>
                                                    <a href="<?php echo base_url('itirazlarim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100">İtirazlarım</a>
                                                    <a href="<?php echo base_url('hesap-ayarlari') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100">Profil Ayarlarım</a>
                                                    <a class="nav-link kpc-nav-btn w-spacial w-100" href="<?php echo base_url('cikis') ?>">Çıkış</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-3 col-md-12 col-sm-12 md-none pr-0">
                        <div class="k-panel-left-navbar-warper m-bg2">
                            <div class="k-panel-left-navbar-area">
                                <div class="nav flex-column nav-pills bg-custom-none " id="v-pills-tab" role="tablist"
                                     aria-orientation="vertical">
                                   <?php if (magaza_check()) { ?>
                                        <div class="gt-store">
                                            <a href="<?php echo base_url('m/'.magaza($kullanici->kullanici_id)->magaza_seo) ?>" class="btn btn-primary settings-btn mb-3 w-100">Mağzaya Git</a>
                                        </div>
                                    <?php } ?>
                                    <a href="<?php echo base_url('hesabim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100 active"> <img class="sw-icon-item" src="<?php echo base_url('assets/front/images/uzer.webp') ?>" alt="" loading="lazy">Profilim</a>
                                    <a href="<?php echo base_url('siparislerim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"><img class="sw-icon-item" src="<?php echo base_url('assets/front/images/shopping-list.webp') ?>" alt="" loading="lazy">Siparişlerim</a>
                                    <a href="<?php echo base_url('satislar') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"><img class="sw-icon-item" src="<?php echo base_url('assets/front/images/gold.webp') ?>" alt="" loading="lazy">Gold Al - Sat</a>
                                    <a href="<?php echo base_url('sorularim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"><img class="sw-icon-item" src="<?php echo base_url('assets/front/images/s4.png') ?>" alt="" loading="lazy">Sorularım</a>
                                    <a href="<?php echo base_url('bakiye') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"><img class="sw-icon-item" src="<?php echo base_url('assets/front/images/salary.webp') ?>" alt="" loading="lazy">Bakiye</a>
                                    <a href="<?php echo base_url('odeme-talep') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"><img class="sw-icon-item" src="<?php echo base_url('assets/front/images/transfer.webp') ?>" alt="" loading="lazy">Para Çek</a>
                                    <a href="<?php echo base_url('destek-taleplerim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"><img class="sw-icon-item" src="<?php echo base_url('assets/front/images/customer-service.webp') ?>" alt="" loading="lazy">Destek Sistemi</a>
                                    <a href="<?php echo base_url('itirazlarim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"><img class="sw-icon-item" src="<?php echo base_url('assets/front/images/error.webp') ?>" alt="" loading="lazy">İtirazlarım</a>
                                    <a href="<?php echo base_url('hesap-ayarlari') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"><img class="sw-icon-item" src="<?php echo base_url('assets/front/images/s1.png') ?>" alt="" loading="lazy">Profil Ayarlarım</a>
                                    <a class="nav-link kpc-nav-btn w-spacial w-100" href="<?php echo base_url('cikis') ?>"><img class="sw-icon-item" src="<?php echo base_url('assets/front/images/logout.webp') ?>" alt="" loading="lazy">Çıkış</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-9 col-lg-9 col-md-12 col-sm-12 m-bg m-br">
                        <div class="k-panel-content-right no-bg">
                            <div class="tab-content" id="v-pills-tabContent">
                                <div class="tab-pane fade show active" id="my-account" role="tabpanel"
                                     aria-labelledby="my-account-tab" tabindex="0">
                                    <div class="container-fluid">
                                        <div class="k-panel-content-box ">
                                            <div class="row">
                                                <div class="col-12">
                                                    <div class="pts-area">
                                                        <div class="panel-body ">
                                                            <div class="flexCard k-panel-content-box">
                                                                <div class="userAvatar kpc-user-avatar">
                                                                    <?php if (strpos($kullanici->kullanici_resim, "/.jpg") !== false) { ?>
                                                                        <img class="kpc-user-avatar-item" src="https://ui-avatars.com/api/?name=<?= $kullanici->kullanici_isim ?>+<?= $kullanici->kullanici_soyisim ?>&background=0D8ABC&color=fff" title="<?php echo $kullanici->kullanici_isim ?>" alt="<?php echo $kullanici->kullanici_isim ?>">
                                                                    <?php } else { ?>
                                                                        <img class="kpc-user-avatar-item" src="<?php echo base_url($kullanici->kullanici_resim) ?>" title="<?php echo $kullanici->kullanici_isim ?>" alt="<?php echo $kullanici->kullanici_isim ?>">
                                                                    <?php } ?>
                                                                </div>
                                                                <div class="userDetails userDetails-kpc">
                                                                    <h1><?php echo $kullanici->kullanici_ad ?>
                                                                       <?php if (magaza_check()) { ?>
                                                                        <a href="javascript:void(0)"
                                                                           class="top-0 right-0" data-toggle="tooltip"
                                                                           data-placement="top" title=""
                                                                           data-original-title="Doğrulanmış Mağaza">
                                                                            <img src="https://kemalellidort.com.tr/assets/front/images/checked-mark.svg"
                                                                                 alt="" height="30" width="30">
                                                                        </a>
                                                                       <?php } ?>
                                                                    </h1>
                                                                    <div class="email-area-pfb">
                                                                        <span><?php echo $kullanici->kullanici_mail ?></span>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="k-panel-content-box">
                                                                <div class="row">
                                                                    <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 mb-3">
                                                                        <div class="card">
                                                                            <div class="card-content">
                                                                                <div class="card-body mh-85 bc-22">
                                                                                    <div class="card-img-body">
                                                                                        <div class="media  ">
                                                                                            <div class="card-img-body-warper">
                                                                                                <img class="card-img-body-icon"
                                                                                                     src="https://kemalellidort.com.tr/assets/images/money-bag.png "
                                                                                                     alt="">
                                                                                            </div>
                                                                                            <div class="media-body text-right-c">
                                                                                                <h3><?php echo $siparis_say ?></h3>
                                                                                                <span>Siparişlerim</span>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 mb-3">
                                                                        <div class="card">
                                                                            <div class="card-content">
                                                                                <div class="card-body mh-85 bc-22">
                                                                                    <div class="card-img-body">
                                                                                        <div class="media  ">
                                                                                            <div class="card-img-body-warper">
                                                                                                <img class="card-img-body-icon"
                                                                                                     src="https://kemalellidort.com.tr/assets/images/ty6.png "
                                                                                                     alt="">
                                                                                            </div>
                                                                                            <div class="media-body text-right-c">
                                                                                                <h3><?php echo $aldigim_gold_count ?></h3>
                                                                                                <span>Satın Aldığım Gold</span>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 mb-3">
                                                                        <div class="card">
                                                                            <div class="card-content">
                                                                                <div class="card-body mh-85 bc-22">
                                                                                    <div class="card-img-body">
                                                                                        <div class="media  ">
                                                                                            <div class="card-img-body-warper">
                                                                                                <img class="card-img-body-icon"
                                                                                                     src="https://kemalellidort.com.tr/assets/images/ty7.png "
                                                                                                     alt="">
                                                                                            </div>
                                                                                            <div class="media-body text-right-c">
                                                                                                <h3><?php echo $sattigim_gold_count ?></h3>
                                                                                                <span>Sattığım Gold</span>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 mb-3">
                                                                        <div class="card">
                                                                            <div class="card-content">
                                                                                <div class="card-body mh-85 bc-22">
                                                                                    <div class="card-img-body">
                                                                                        <div class="media  ">
                                                                                            <div class="card-img-body-warper">
                                                                                                <img class="card-img-body-icon"
                                                                                                     src="https://kemalellidort.com.tr/assets/images/reconciliation.png "
                                                                                                     alt="">
                                                                                            </div>
                                                                                            <div class="media-body text-right-c">
                                                                                                <h3><?php echo $odenebilir_kazanclar ?></h3>
                                                                                                <span>Çekilebilir Kazanç</span>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 mb-3">
                                                                        <div class="card">
                                                                            <div class="card-content">
                                                                                <div class="card-body mh-85 bc-22">
                                                                                    <div class="card-img-body">
                                                                                        <div class="media  ">
                                                                                            <div class="card-img-body-warper">
                                                                                                <img class="card-img-body-icon"
                                                                                                     src="https://kemalellidort.com.tr/assets/images/ty1.png "
                                                                                                     alt="">
                                                                                            </div>
                                                                                            <div class="media-body text-right-c">
                                                                                                <h3><?php echo $kullanici->bakiye ?></h3>
                                                                                                <span>Bakiye</span>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 mb-3">
                                                                        <div class="card">
                                                                            <div class="card-content">
                                                                                <div class="card-body mh-85 bc-22">
                                                                                    <div class="card-img-body">
                                                                                        <div class="media  ">
                                                                                            <div class="card-img-body-warper">
                                                                                                <img class="card-img-body-icon"
                                                                                                     src="https://kemalellidort.com.tr/assets/images/ty2.png "
                                                                                                     alt="">
                                                                                            </div>
                                                                                            <div class="media-body text-right-c">
                                                                                                <h3><?php echo $destek_talep_count ?></h3>
                                                                                                <span>Destek Taleplerim</span>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>