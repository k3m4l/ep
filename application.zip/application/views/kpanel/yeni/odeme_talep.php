<main class="k-panel-warper">
    <div class="sec-warper mb-4">
        <div class="container normal-container p-0">
            <div class="k-panel-g-warper">
                <div class="row">
                    <div class="col-xl-3 col-lg-3 col-md-12 col-sm-12 wd-none mt-3 p-0  ">
                        <div class="accordion accordion-flush acc-kpc-menu" id="accordionFlushExample">
                            <div class="accordion-item acc-kpc-menu-item">
                                <h2 class="accordion-header acc-kpc-menu-header" id="flush-headingOne">
                                    <button class="accordion-button collapsed acc-kpc-menu-btn" type="button"
                                            data-bs-toggle="collapse" data-bs-target="#flush-collapseOne"
                                            aria-expanded="false" aria-controls="flush-collapseOne">
                                        Hızlı Menü
                                    </button>
                                </h2>
                                <div id="flush-collapseOne" class="accordion-collapse collapse"
                                     aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
                                    <div class="accordion-body acc-kpc-menu-body">
                                        <div class="k-panel-left-navbar-warper">
                                            <div class="k-panel-left-navbar-area">
                                                <div class="nav flex-column nav-pills bg-custom-none " id="v-pills-tab" role="tablist"
                                                     aria-orientation="vertical">
                                                    <?php if (magaza_check()) { ?>
                                                        <div class="gt-store">
                                                            <a href="<?php echo base_url('m/' . magaza($kullanici->kullanici_id)->magaza_seo) ?>"
                                                               class="btn btn-primary settings-btn mb-3 w-100">Mağzaya Git</a>
                                                        </div>
                                                    <?php } ?>
                                                    <a href="<?php echo base_url('hesabim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100">Profilim</a>
                                                    <a href="<?php echo base_url('siparislerim') ?>" title=""
                                                       class="nav-link kpc-nav-btn w-spacial w-100">Siparişlerim</a>
                                                    <a href="<?php echo base_url('satislar') ?>" title=""
                                                       class="nav-link kpc-nav-btn w-spacial w-100">Gold Al - Sat</a>
                                                    <a href="<?php echo base_url('sorularim') ?>" title=""
                                                       class="nav-link kpc-nav-btn w-spacial w-100">Sorularım</a>
                                                    <a href="<?php echo base_url('bakiye') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100">Bakiye</a>
                                                    <a href="<?php echo base_url('odeme-talep') ?>" title=""
                                                       class="nav-link kpc-nav-btn w-spacial w-100 active">Para Çek</a>
                                                    <a href="<?php echo base_url('destek-taleplerim') ?>" title=""
                                                       class="nav-link kpc-nav-btn w-spacial w-100">Destek Taleplerim</a>
                                                    <a href="<?php echo base_url('itirazlarim') ?>" title=""
                                                       class="nav-link kpc-nav-btn w-spacial w-100">İtirazlarım</a>
                                                    <a href="<?php echo base_url('hesap-ayarlari') ?>" title=""
                                                       class="nav-link kpc-nav-btn w-spacial w-100">Profil Ayarlarım</a>
                                                    <a class="nav-link kpc-nav-btn w-spacial w-100" href="<?php echo base_url('cikis') ?>">Çıkış</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-3 col-md-12 col-sm-12 md-none pr-0">
                        <div class="k-panel-left-navbar-warper m-bg2">
                            <div class="k-panel-left-navbar-area">
                                <div class="nav flex-column nav-pills bg-custom-none " id="v-pills-tab" role="tablist"
                                     aria-orientation="vertical">
                                    <?php if (magaza_check()) { ?>
                                        <div class="gt-store">
                                            <a href="<?php echo base_url('m/' . magaza($kullanici->kullanici_id)->magaza_seo) ?>"
                                               class="btn btn-primary settings-btn mb-3 w-100">Mağzaya Git</a>
                                        </div>
                                    <?php } ?>
                                    <a href="<?php echo base_url('hesabim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"> <img
                                                class="sw-icon-item" src="<?php echo base_url('assets/front/images/uzer.webp') ?>" alt=""
                                                loading="lazy">Profilim</a>
                                    <a href="<?php echo base_url('siparislerim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"><img
                                                class="sw-icon-item" src="<?php echo base_url('assets/front/images/shopping-list.webp') ?>" alt=""
                                                loading="lazy">Siparişlerim</a>
                                    <a href="<?php echo base_url('satislar') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"><img
                                                class="sw-icon-item" src="<?php echo base_url('assets/front/images/gold.webp') ?>" alt=""
                                                loading="lazy">Gold Al - Sat</a>
                                    <a href="<?php echo base_url('sorularim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"><img
                                                class="sw-icon-item" src="<?php echo base_url('assets/front/images/s4.png') ?>" alt="" loading="lazy">Sorularım</a>
                                    <a href="<?php echo base_url('bakiye') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"><img
                                                class="sw-icon-item" src="<?php echo base_url('assets/front/images/salary.webp') ?>" alt=""
                                                loading="lazy">Bakiye</a>
                                    <a href="<?php echo base_url('odeme-talep') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100 active"><img
                                                class="sw-icon-item" src="<?php echo base_url('assets/front/images/transfer.webp') ?>" alt=""
                                                loading="lazy">Para Çek</a>
                                    <a href="<?php echo base_url('destek-taleplerim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"><img
                                                class="sw-icon-item" src="<?php echo base_url('assets/front/images/customer-service.webp') ?>" alt=""
                                                loading="lazy">Destek Sistemi</a>
                                    <a href="<?php echo base_url('itirazlarim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"><img
                                                class="sw-icon-item" src="<?php echo base_url('assets/front/images/error.webp') ?>" alt=""
                                                loading="lazy">İtirazlarım</a>
                                    <a href="<?php echo base_url('hesap-ayarlari') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"><img
                                                class="sw-icon-item" src="<?php echo base_url('assets/front/images/s1.png') ?>" alt="" loading="lazy">Profil
                                        Ayarlarım</a>
                                    <a class="nav-link kpc-nav-btn w-spacial w-100" href="<?php echo base_url('cikis') ?>"><img class="sw-icon-item"
                                                                                                                                src="<?php echo base_url('assets/front/images/logout.webp') ?>"
                                                                                                                                alt="" loading="lazy">Çıkış</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-9 col-lg-9 col-md-12 col-sm-12 m-bg">
                        <div class="k-panel-content-right">
                            <div class="tab-content" id="v-pills-tabContent">
                                <div class="tab-pane fade show active" id="take-money" role="tabpanel"
                                     aria-labelledby="take-money-tab" tabindex="0">
                                    <div class="container-fluid">
                                        <div class="k-panel-content-box">
                                            <div class="row">
                                                <div class="col-12">
                                                    <div class="account-area  m-bg">
                                                        <div class="pb-5">
                                                            <div class="">
                                                                <div class="card mb-5">
                                                                    <div class="card-body pt-0">
                                                                        <div class="col-12 page-header">

                                                                        </div>
                                                                        <script>
                                                                            $(document).ready(function () {
                                                                                // İlk sekme ve içeriği aktif hale getirme
                                                                                // Sekme tıklama olayı
                                                                                $('.cekimTipiSecimi li').click(function () {
                                                                                    var tabId = $(this).attr('id');
                                                                                    // Aktif sekmeleri değiştirme
                                                                                    $('.cekimTipiSecimi li').removeClass('active');
                                                                                    $(this).addClass('active');
                                                                                    //$('#intro').addClass("d-none");
                                                                                    // Tüm içerikleri gizleme
                                                                                    $('.odeme-section .content').addClass('d-none');
                                                                                    $('#banks-names').val(tabId);
                                                                                    // İlgili içeriği gösterme
                                                                                    $('#' + tabId + '-content').removeClass('d-none');
                                                                                });
                                                                            });
                                                                        </script>
                                                                        <style>
                                                                            ul.cekimTipiSecimi {
                                                                                margin: 0;
                                                                                padding: 0;
                                                                                list-style: none;
                                                                                margin-top: 10px;
                                                                            }

                                                                            ul.cekimTipiSecimi li.active,
                                                                            ul.cekimTipiSecimi li:hover {
                                                                                border-bottom: 3px solid rgb(141 174 255);
                                                                                background: rgb(57 73 112);
                                                                            }

                                                                            ul.cekimTipiSecimi li {
                                                                                float: left;
                                                                                width: 140px;
                                                                                height: 50px;
                                                                                padding: 0 15px;
                                                                                background: rgb(49 61 90);
                                                                                margin-right: 10px;
                                                                                text-align: center;
                                                                                cursor: pointer;
                                                                                border-radius: 3px;
                                                                            }

                                                                            ul.cekimTipiSecimi li img {
                                                                                width: 80px;
                                                                                height: 50px;
                                                                                padding: 10px;
                                                                                object-fit: contain;
                                                                            }

                                                                            [data-inverted][data-position~=top][data-tooltip]:before {
                                                                                background: #1b1c1d;
                                                                            }

                                                                            [data-position~=top][data-tooltip]:before {
                                                                                background: #fff;
                                                                            }

                                                                            [data-position="top center"][data-tooltip]:before {
                                                                                top: auto;
                                                                                right: auto;
                                                                                bottom: 100%;
                                                                                left: 50%;
                                                                                background: #fff;
                                                                                margin-left: -0.07142857rem;
                                                                                margin-bottom: 0.14285714rem;
                                                                            }
                                                                        </style>
                                                                        <?php $yontemler = $this->magaza_model->get_para_cekme_yontemler() ?>
                                                                        <div class="row align-items-center justify-content-space-between">
                                                                            <div class="col-xl-4 col-lg-4 col-md-12 col-sm-12 ">
                                                                                <div class="card vcards">
                                                                                    <div class="card-content">
                                                                                        <div class="card-body mh-85 bc-22">
                                                                                            <div class="card-img-body">
                                                                                                <div class="media  ">
                                                                                                    <div class="card-img-body-warper">
                                                                                                        <img class="card-img-body-icon"
                                                                                                             src="https://kemalellidort.com.tr/assets/yonetim/img/wallet.png"
                                                                                                             alt="">
                                                                                                    </div>
                                                                                                    <div class="media-body text-right-c">
                                                                                                        <h5 class="mb-0 display-4 font-weight-bold">
                                                                                                            <?= $kullanici->bakiye ?>
                                                                                                            ₺
                                                                                                        </h5>
                                                                                                        <span>Çekilebilir Kazanç</span>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="col-xl-8 col-lg-8 col-md-12 col-sm-12 ">
                                                                                <div class="payment-selectableop">
                                                                                    <div class="top-dsc-payment mb-3">
                                                                                        <h3 class="page-title">Lütfen
                                                                                            çekim yapmak
                                                                                            istediğiniz hesap türünü
                                                                                            seçin.</h3>
                                                                                        <div class="card-seles">
                                                                                        </div>

                                                                                        <ul class="cekimTipiSecimi">
                                                                                            <?php foreach (!empty($yontemler) ? $yontemler : [] as $key => $val) { ?>
                                                                                                <li data-tab="banka-cekim"
                                                                                                    id="<?php echo $val->row_div_id ?>"
                                                                                                    class="<?php echo $key == 0 ? 'active' : '' ?>"
                                                                                                    data-inverted=""
                                                                                                    data-tooltip="<?php echo $val->row_title ?>"
                                                                                                    data-position="top center">
                                                                                                    <img src="<?php echo base_url($val->row_image) ?>">
                                                                                                </li>
                                                                                            <?php } ?>
                                                                                        </ul>
                                                                                    </div>
                                                                                    <div class="payment-pic mt-3">


                                                                                        <form class="h-100 w-100" action="<?= base_url('para-cek') ?>"
                                                                                              method="post">
                                                                                            <input type="hidden"
                                                                                                   id="banks-names"
                                                                                                   value="banka"
                                                                                                   name="bankname">
                                                                                            <button class="btn btn-primary btn-block rounded-pill mt-5 "
                                                                                                    type="submit">
                                                                                                Para Çekme
                                                                                                Talebi
                                                                                                Oluştur
                                                                                            </button>
                                                                                        </form>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="col-12 mt-5">

                                                                                <div class="odeme-section">
                                                                                    <div class="content p-4 rounded-lg mb-3 d-none"
                                                                                         id="ininal-content">
                                                                                        <div class="custom-control custom-radio">
                                                                                            <form class="form-row"
                                                                                                  action="<?= base_url('ininal-bilgi') ?>"
                                                                                                  method="post">
                                                                                                <!-- First name -->
                                                                                                <div class="form-group col-md-12">
                                                                                                    <label class="form-label">Ininal
                                                                                                        No</label>
                                                                                                    <input type="text"
                                                                                                           name="iban"
                                                                                                           class="form-control"
                                                                                                           placeholder="Ininal No"
                                                                                                           value="<?= $kullanici->ininal_no ?>">
                                                                                                </div>
                                                                                                <!-- Last name -->
                                                                                                <div class="form-group col-md-12">
                                                                                                    <label class="form-label">Alıcı
                                                                                                        Adı
                                                                                                        Soyadı</label>
                                                                                                    <input type="text"
                                                                                                           name="alici"
                                                                                                           class="form-control"
                                                                                                           placeholder="Alıcı Adı Soyadı"
                                                                                                           value="<?= $kullanici->alici_ininal ?>">
                                                                                                </div>
                                                                                                <!-- Phone -->
                                                                                                <div class="form-group col-md-12">
                                                                                                    <label class="form-label">Alıcı
                                                                                                        Telefon
                                                                                                        Numarası</label>
                                                                                                    <input type="number"
                                                                                                           name="telefon"
                                                                                                           class="form-control"
                                                                                                           placeholder="Alıcı Telefon Numarası"
                                                                                                           value="<?= $kullanici->tel_ininal ?>">
                                                                                                </div>
                                                                                                <div class="col-12">
                                                                                                    <!-- Button -->
                                                                                                    <button class="btn btn-primary rounded-pill"
                                                                                                            type="submit">
                                                                                                        Bilgilerimi
                                                                                                        Güncelle
                                                                                                    </button>
                                                                                                </div>
                                                                                            </form>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="content p-4 rounded-lg mb-3 d-none"
                                                                                         id="papara-content">
                                                                                        <div class="custom-control custom-radio">
                                                                                            <form class="form-row"
                                                                                                  action="<?= base_url('papara-bilgi') ?>"
                                                                                                  method="post">
                                                                                                <!-- First name -->
                                                                                                <div class="form-group col-md-12">
                                                                                                    <label class="form-label">Papara
                                                                                                        No</label>
                                                                                                    <input type="text"
                                                                                                           name="iban"
                                                                                                           class="form-control"
                                                                                                           placeholder="Papara No"
                                                                                                           value="<?= $kullanici->papara_no ?>">
                                                                                                </div>
                                                                                                <!-- Last name -->
                                                                                                <div class="form-group col-md-12">
                                                                                                    <label class="form-label">Alıcı
                                                                                                        Adı
                                                                                                        Soyadı</label>
                                                                                                    <input type="text"
                                                                                                           name="alici"
                                                                                                           class="form-control"
                                                                                                           placeholder="Alıcı Adı Soyadı"
                                                                                                           value="<?= $kullanici->alici_papara ?>">
                                                                                                </div>
                                                                                                <!-- Phone -->
                                                                                                <div class="form-group col-md-12">
                                                                                                    <label class="form-label">Alıcı
                                                                                                        Telefon
                                                                                                        Numarası</label>
                                                                                                    <input type="number"
                                                                                                           name="telefon"
                                                                                                           class="form-control"
                                                                                                           placeholder="Alıcı Telefon Numarası"
                                                                                                           value="<?= $kullanici->tel_papara ?>">
                                                                                                </div>
                                                                                                <div class="col-12">
                                                                                                    <!-- Button -->
                                                                                                    <button class="btn btn-primary rounded-pill"
                                                                                                            type="submit">
                                                                                                        Bilgilerimi
                                                                                                        Güncelle
                                                                                                    </button>
                                                                                                </div>
                                                                                            </form>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="content p-4 rounded-lg mb-3" id="banka-content">
                                                                                        <div class="custom-control custom-radio">
                                                                                            <form class="form-row"
                                                                                                  action="<?= base_url('iban-bilgi') ?>"
                                                                                                  method="post">
                                                                                                <!-- First name -->
                                                                                                <div class="form-group col-md-12">
                                                                                                    <label class="form-label">IBAN
                                                                                                        No</label>
                                                                                                    <input type="text"
                                                                                                           name="iban"
                                                                                                           class="form-control iban-input"
                                                                                                           placeholder="IBAN No"
                                                                                                           value="<?= $kullanici->kullanici_iban ?>">
                                                                                                </div>
                                                                                                <!-- Last name -->
                                                                                                <div class="form-group col-md-12">
                                                                                                    <label class="form-label">Alıcı
                                                                                                        Adı
                                                                                                        Soyadı</label>
                                                                                                    <input type="text"
                                                                                                           name="alici"
                                                                                                           class="form-control"
                                                                                                           placeholder="Alıcı Adı Soyadı"
                                                                                                           value="<?= $kullanici->kullanici_alici ?>">
                                                                                                </div>
                                                                                                <!-- Phone -->
                                                                                                <div class="form-group col-md-12">
                                                                                                    <label class="form-label">Alıcı
                                                                                                        Telefon
                                                                                                        Numarası</label>
                                                                                                    <input type="number"
                                                                                                           name="telefon"
                                                                                                           class="form-control"
                                                                                                           placeholder="Alıcı Telefon Numarası"
                                                                                                           value="<?= $kullanici->kullanici_alici_tel ?>">
                                                                                                </div>
                                                                                                <div class="col-12">
                                                                                                    <!-- Button -->
                                                                                                    <button class="btn btn-primary rounded-pill"
                                                                                                            type="submit">
                                                                                                        Bilgilerimi
                                                                                                        Güncelle
                                                                                                    </button>
                                                                                                </div>
                                                                                            </form>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <!-- Check box -->
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>