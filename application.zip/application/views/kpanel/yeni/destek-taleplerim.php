<main class="k-panel-warper">
    <div class="sec-warper mb-4">
        <div class="container normal-container p-0">
            <div class="k-panel-g-warper">
                <div class="row">
                    <div class="col-xl-3 col-lg-3 col-md-12 col-sm-12 wd-none mt-3 p-0 ">
                        <div class="accordion accordion-flush acc-kpc-menu" id="accordionFlushExample">
                            <div class="accordion-item acc-kpc-menu-item">
                                <h2 class="accordion-header acc-kpc-menu-header" id="flush-headingOne">
                                    <button class="accordion-button collapsed acc-kpc-menu-btn" type="button"
                                            data-bs-toggle="collapse" data-bs-target="#flush-collapseOne"
                                            aria-expanded="false" aria-controls="flush-collapseOne">
                                        Hızlı Menü
                                    </button>
                                </h2>
                                <div id="flush-collapseOne" class="accordion-collapse collapse"
                                     aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
                                    <div class="accordion-body acc-kpc-menu-body">
                                        <div class="k-panel-left-navbar-warper">
                                            <div class="k-panel-left-navbar-area">
                                                <div class="nav flex-column nav-pills bg-custom-none " id="v-pills-tab" role="tablist"
                                                    aria-orientation="vertical">
                                                <?php if (magaza_check()) { ?>
                                                        <div class="gt-store">
                                                            <a href="<?php echo base_url('m/'.magaza($kullanici->kullanici_id)->magaza_seo) ?>" class="btn btn-primary settings-btn mb-3 w-100">Mağzaya Git</a>
                                                        </div>
                                                    <?php } ?>
                                                    <a href="<?php echo base_url('hesabim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"> <img class="panel-icon-img" src="<?php echo base_url('assets/front/images/') ?>" alt="" loading="lazy"> Profilim</a>
                                                          <a href="<?php echo base_url('siparislerim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"><img class="" src="<?php echo base_url('assets/front/images/') ?>" alt="" loading="lazy">Siparişlerim</a>
                                                    <a href="<?php echo base_url('satislar') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"><img class="" src="<?php echo base_url('assets/front/images/') ?>" alt="" loading="lazy">Gold Al - Sat</a>
                                                    <a href="<?php echo base_url('sorularim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"><img class="" src="<?php echo base_url('assets/front/images/') ?>" alt="" loading="lazy">Sorularım</a>
                                                    <a href="<?php echo base_url('bakiye') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"><img class="" src="<?php echo base_url('assets/front/images/') ?>" alt="" loading="lazy">Bakiye</a>
                                                    <a href="<?php echo base_url('odeme-talep') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"><img class="" src="<?php echo base_url('assets/front/images/') ?>" alt="" loading="lazy">Bakiye Çekim</a>
                                                    <a href="<?php echo base_url('destek-taleplerim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100 active"><img class="" src="<?php echo base_url('assets/front/images/') ?>" alt="" loading="lazy">Destek Taleplerim</a>
                                                    <a href="<?php echo base_url('itirazlarim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"><img class="" src="<?php echo base_url('assets/front/images/') ?>" alt="" loading="lazy">İtirazlarım</a>
                                                    <a href="<?php echo base_url('hesap-ayarlari') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"><img class="" src="<?php echo base_url('assets/front/images/') ?>" alt="" loading="lazy">Profil Ayarlarım</a>
                                                    <a class="nav-link kpc-nav-btn w-spacial w-100" href="<?php echo base_url('cikis') ?>"><img class="" src="<?php echo base_url('assets/front/images/') ?>" alt="" loading="lazy">Çıkış</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-3 col-md-12 col-sm-12 md-none pr-0">
                        <div class="k-panel-left-navbar-warper m-bg2">
                            <div class="k-panel-left-navbar-area">
                                <div class="nav flex-column nav-pills bg-custom-none " id="v-pills-tab" role="tablist"
                                     aria-orientation="vertical">
                                   <?php if (magaza_check()) { ?>
                                        <div class="gt-store">
                                            <a href="<?php echo base_url('m/'.magaza($kullanici->kullanici_id)->magaza_seo) ?>" class="btn btn-primary settings-btn mb-3 w-100">Mağzaya Git</a>
                                        </div>
                                    <?php } ?>
                                    <a href="<?php echo base_url('hesabim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"> <img class="sw-icon-item" src="<?php echo base_url('assets/front/images/uzer.webp') ?>" alt="" loading="lazy">Profilim</a>
                                    <a href="<?php echo base_url('siparislerim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"><img class="sw-icon-item" src="<?php echo base_url('assets/front/images/shopping-list.webp') ?>" alt="" loading="lazy">Siparişlerim</a>
                                    <a href="<?php echo base_url('satislar') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"><img class="sw-icon-item" src="<?php echo base_url('assets/front/images/gold.webp') ?>" alt="" loading="lazy">Gold Al - Sat</a>
                                    <a href="<?php echo base_url('sorularim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"><img class="sw-icon-item" src="<?php echo base_url('assets/front/images/s4.png') ?>" alt="" loading="lazy">Sorularım</a>
                                    <a href="<?php echo base_url('bakiye') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"><img class="sw-icon-item" src="<?php echo base_url('assets/front/images/salary.webp') ?>" alt="" loading="lazy">Bakiye</a>
                                    <a href="<?php echo base_url('odeme-talep') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"><img class="sw-icon-item" src="<?php echo base_url('assets/front/images/transfer.webp') ?>" alt="" loading="lazy">Para Çek</a>
                                    <a href="<?php echo base_url('destek-taleplerim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100 active"><img class="sw-icon-item" src="<?php echo base_url('assets/front/images/customer-service.webp') ?>" alt="" loading="lazy">Destek Taleplerim</a>
                                    <a href="<?php echo base_url('itirazlarim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"><img class="sw-icon-item" src="<?php echo base_url('assets/front/images/error.webp') ?>" alt="" loading="lazy">İtirazlarım</a>
                                    <a href="<?php echo base_url('hesap-ayarlari') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"><img class="sw-icon-item" src="<?php echo base_url('assets/front/images/s1.png') ?>" alt="" loading="lazy">Profil Ayarlarım</a>
                                    <a class="nav-link kpc-nav-btn w-spacial w-100" href="<?php echo base_url('cikis') ?>"><img class="sw-icon-item" src="<?php echo base_url('assets/front/images/logout.webp') ?>" alt="" loading="lazy">Çıkış</a>
                                </div>
                            </div>
                        </div>
                    </div>
                <div class="col-xl-9 col-lg-9 col-md-12 col-sm-12 m-bg m-br">
                    <div class="k-panel-content-right">
                        <div class="tab-content" id="v-pills-tabContent">
                            <div class="tab-pane fade show active" id="support-request" role="tabpanel"
                                 aria-labelledby="support-request-tab" tabindex="0">
                                <div class="container-fluid">
                                    <div class="k-panel-content-box">
                                        <div class="row">
                                            <div class="col-12">
                                                <div class="dwr">
                                                    <a href="<?php echo base_url('destek-olustur') ?>"
                                                       class="btn btn-primary settings-btn"><i class="fas fa-plus"
                                                                                               aria-hidden="true"></i>
                                                        Yeni Talep Oluştur</a>
                                                </div>
                                            </div>
                                            <div class="col-12">
                                                <div class="request-warper">
                                                    <?php if (!empty($taleplerim)) { ?>
                                                        <?php foreach ($taleplerim as $key => $val) { ?>
                                                            <div class="kpc-item">
                                                                <div class="kpc-border">
                                                                    <div class="raffle-id">
                                                                        <span># <?php echo $val->talep_id ?></span>
                                                                    </div>
                                                                    <div class="product-name-panel">
                                                                        <h4 class="custom-text-area">
                                                                            <a href="<?= base_url('destek-detay/' . $val->talep_no) ?>"
                                                                               class="custom-text"><?php echo $val->talep ?></a>
                                                                        </h4>
                                                                    </div>
                                                                    <ul class="list-inline font-size-xs mb-0">
                                                                        <li class="list-inline-item">
                                                                            <i class="far fa-clock mr-1"></i>
                                                                            <?php echo $val->talep_zaman ?>
                                                                        </li>
                                                                    </ul>
                                                                    <div class="align-middle border-top-0">
                                                                        <?php if ($val->talep_durum == 0) { ?>
                                                                            <span class="badge badge-warning">Cevap Bekleniyor..</span>
                                                                        <?php } elseif ($val->talep_durum == 1) { ?>
                                                                            <span class="badge badge-success">Cevaplandı</span>
                                                                        <?php } elseif ($val->talep_durum == 2) { ?>
                                                                            <span class="badge badge-secondary">Kapatıldı</span>
                                                                        <?php } ?>
                                                                    </div>
                                                                    <button type="button"
                                                                            onclick="window.location.href='<?= base_url('destek-detay-yeni/' . $val->talep_no) ?>'"
                                                                            class="badge btn badge-primary badge-pill">
                                                                        Talep Detay
                                                                    </button>
                                                                </div>
                                                            </div>
                                                        <?php } ?>
                                                    <?php } else { ?>
                                                        <div class="alert alert-info mt-3" role="alert">
                                                            Destek Talepin Bulunmamaktadır. <a
                                                                    href="<?php echo base_url('destek-olustur-yeni') ?>"
                                                                    class="alert-link">Yeni Talep</a>
                                                            Ekliyebilirsin.
                                                        </div>
                                                    <?php } ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</main>