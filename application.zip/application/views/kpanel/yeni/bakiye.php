<main class="k-panel-warper">
    <div class="sec-warper mb-4">
        <div class="container normal-container p-0">
            <div class="k-panel-g-warper">
                <div class="row">
                    <div class="col-xl-3 col-lg-3 col-md-12 col-sm-12 wd-none mt-3 p-0 ">
                        <div class="accordion accordion-flush acc-kpc-menu" id="accordionFlushExample">
                            <div class="accordion-item acc-kpc-menu-item">
                                <h2 class="accordion-header acc-kpc-menu-header" id="flush-headingOne">
                                    <button class="accordion-button collapsed acc-kpc-menu-btn" type="button"
                                            data-bs-toggle="collapse" data-bs-target="#flush-collapseOne"
                                            aria-expanded="false" aria-controls="flush-collapseOne">
                                        Hızlı Menü
                                    </button>
                                </h2>
                                <div id="flush-collapseOne" class="accordion-collapse collapse"
                                     aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
                                    <div class="accordion-body acc-kpc-menu-body">
                                        <div class="k-panel-left-navbar-warper">
                                            <div class="k-panel-left-navbar-area">
                                                <div class="nav flex-column nav-pills bg-custom-none " id="v-pills-tab" role="tablist"
                                                    aria-orientation="vertical">
                                                <?php if (magaza_check()) { ?>
                                                        <div class="gt-store">
                                                            <a href="<?php echo base_url('m/'.magaza($kullanici->kullanici_id)->magaza_seo) ?>" class="btn btn-primary settings-btn mb-3 w-100">Mağzaya Git</a>
                                                        </div>
                                                    <?php } ?>
                                                    <a href="<?php echo base_url('hesabim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"> <img class="panel-icon-img" src="<?php echo base_url('assets/front/images/') ?>" alt="" loading="lazy"> Profilim</a>
                                                    <a href="<?php echo base_url('siparislerim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100">Siparişlerim</a>
                                                    <a href="<?php echo base_url('satislar') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100">Gold Al - Sat</a>
                                                    <a href="<?php echo base_url('sorularim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100">Sorularım</a>
                                                    <a href="<?php echo base_url('bakiye') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100 active">Bakiye</a>
                                                    <a href="<?php echo base_url('odeme-talep') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100">Para Çek</a>
                                                    <a href="<?php echo base_url('destek-taleplerim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100">Destek Taleplerim</a>
                                                    <a href="<?php echo base_url('itirazlarim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100">İtirazlarım</a>
                                                    <a href="<?php echo base_url('hesap-ayarlari') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100">Profil Ayarlarım</a>
                                                    <a class="nav-link kpc-nav-btn w-spacial w-100" href="<?php echo base_url('cikis') ?>">Çıkış</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-3 col-md-12 col-sm-12 md-none pr-0">
                        <div class="k-panel-left-navbar-warper m-bg2">
                            <div class="k-panel-left-navbar-area">
                                <div class="nav flex-column nav-pills bg-custom-none " id="v-pills-tab" role="tablist"
                                     aria-orientation="vertical">
                                   <?php if (magaza_check()) { ?>
                                        <div class="gt-store">
                                            <a href="<?php echo base_url('m/'.magaza($kullanici->kullanici_id)->magaza_seo) ?>" class="btn btn-primary settings-btn mb-3 w-100">Mağzaya Git</a>
                                        </div>
                                    <?php } ?>
                                    <a href="<?php echo base_url('hesabim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"> <img class="sw-icon-item" src="<?php echo base_url('assets/front/images/uzer.webp') ?>" alt="" loading="lazy">Profilim</a>
                                    <a href="<?php echo base_url('siparislerim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"><img class="sw-icon-item" src="<?php echo base_url('assets/front/images/shopping-list.webp') ?>" alt="" loading="lazy">Siparişlerim</a>
                                    <a href="<?php echo base_url('satislar') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"><img class="sw-icon-item" src="<?php echo base_url('assets/front/images/gold.webp') ?>" alt="" loading="lazy">Gold Al - Sat</a>
                                    <a href="<?php echo base_url('sorularim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"><img class="sw-icon-item" src="<?php echo base_url('assets/front/images/s4.png') ?>" alt="" loading="lazy">Sorularım</a>
                                    <a href="<?php echo base_url('bakiye') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100 active"><img class="sw-icon-item" src="<?php echo base_url('assets/front/images/salary.webp') ?>" alt="" loading="lazy">Bakiye</a>
                                    <a href="<?php echo base_url('odeme-talep') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"><img class="sw-icon-item" src="<?php echo base_url('assets/front/images/transfer.webp') ?>" alt="" loading="lazy">Para Çek</a>
                                                                       <a href="<?php echo base_url('destek-taleplerim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"><img class="sw-icon-item" src="<?php echo base_url('assets/front/images/customer-service.webp') ?>" alt="" loading="lazy">Destek Sistemi</a>
                                    <a href="<?php echo base_url('itirazlarim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"><img class="sw-icon-item" src="<?php echo base_url('assets/front/images/error.webp') ?>" alt="" loading="lazy">İtirazlarım</a>
                                    <a href="<?php echo base_url('hesap-ayarlari') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"><img class="sw-icon-item" src="<?php echo base_url('assets/front/images/s1.png') ?>" alt="" loading="lazy">Profil Ayarlarım</a>
                                    <a class="nav-link kpc-nav-btn w-spacial w-100" href="<?php echo base_url('cikis') ?>"><img class="sw-icon-item" src="<?php echo base_url('assets/front/images/logout.webp') ?>" alt="" loading="lazy">Çıkış</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-9 col-lg-9 col-md-12 col-sm-12 m-bg m-br">
                        <div class="k-panel-content-right">
                            <div class="tab-content" id="v-pills-tabContent">
                                <div class="tab-pane fade show active" id="budget" role="tabpanel" aria-labelledby="budget-tab"
                                     tabindex="0">
                                    <div class="container-fluid">
                                        <div class="k-panel-content-box">
                                            <div class="row">
                                                <div class="col-12 control-panel">
                                                    <div class="pb-5">
                                                        <div class="col-12">
                                                            <ul class="nav nav-pills balance-tab mb-3"
                                                                id="pills-tab" role="tablist">
                                                                <li class="nav-item" role="presentation">
                                                                    <button class="nav-link active"
                                                                            id="pills-home-tab" data-bs-toggle="pill"
                                                                            data-bs-target="#payment-1" type="button"
                                                                            role="tab" aria-controls="payment-1"
                                                                            aria-selected="true"><i
                                                                                class="fas fa-bars"></i></button>
                                                                    <div class="title-filter-tab-link">Tüm
                                                                        Ödeme
                                                                        Yöntemleri
                                                                    </div>
                                                                </li>
                                                                <li class="nav-item" role="presentation">
                                                                    <button class="nav-link" id="pills-profile-tab"
                                                                            data-bs-toggle="pill"
                                                                            data-bs-target="#payment-2" type="button"
                                                                            role="tab" aria-controls="payment-2"
                                                                            aria-selected="false"><i
                                                                                class="far fa-credit-card"></i></button>
                                                                    <div class="title-filter-tab-link">Kradi
                                                                        Kartı
                                                                    </div>
                                                                </li>
                                                                <li class="nav-item" role="presentation">
                                                                    <button class="nav-link" id="pills-contact-tab"
                                                                            data-bs-toggle="pill"
                                                                            data-bs-target="#payment-3" type="button"
                                                                            role="tab" aria-controls="payment-3"
                                                                            aria-selected="false"><i
                                                                                class="fas fa-globe-americas"></i>
                                                                    </button>
                                                                    <div class="title-filter-tab-link">Yurt
                                                                        Dışı Kredi
                                                                        veya Banka
                                                                    </div>
                                                                </li>
                                                                <li class="nav-item" role="presentation">
                                                                    <button class="nav-link" id="pills-contact-tab"
                                                                            data-bs-toggle="pill"
                                                                            data-bs-target="#payment-4" type="button"
                                                                            role="tab" aria-controls="payment-4"
                                                                            aria-selected="false"><i
                                                                                class="fas fa-university"></i></button>
                                                                    <div class="title-filter-tab-link">Banka
                                                                        ve Havale
                                                                    </div>
                                                                </li>
                                                                <li class="nav-item" role="presentation">
                                                                    <button class="nav-link" id="pills-contact-tab"
                                                                            data-bs-toggle="pill"
                                                                            data-bs-target="#payment-5" type="button"
                                                                            role="tab" aria-controls="payment-5"
                                                                            aria-selected="false"><i
                                                                                class="fas fa-wallet"></i>
                                                                    </button>
                                                                    <div class="title-filter-tab-link">
                                                                        Cüzdan ve Hediye
                                                                    </div>
                                                                </li>
                                                            </ul>
                                                            <div class="tab-content" id="pills-tabContent">
                                                                <div class="tab-pane fade show active"
                                                                     id="payment-1" role="tabpanel"
                                                                     aria-labelledby="pills-home-tab">
                                                                    <ul class="PaymentTypes" id="paymentTypes">
                                                                        <?php if ($ayarlar->paytr_durum == '1'): ?>
                                                                            <li id="paytr">
                                                                                <tip>Kredi</tip>
                                                                                <div class="paymentImage">
                                                                                    <img
                                                                                            src="<?php echo base_url('assets/images/stripe.png') ?>">
                                                                                </div>
                                                                                <b>Kredi Kartı & Banka Kartı
                                                                                    (PayTR)</b>
                                                                                <span
                                                                                        class="badge badge-info  font-weight-bold">Anında
                                                                                    Onay</span>
                                                                                <span
                                                                                        class="badge badge-warning font-weight-bold"><?= $ayarlar->paytr_komisyon ?>%
                                                                                    Komisyon</span>
                                                                            </li>
                                                                        <?php endif; ?>
                                                                        <?php if ($ayarlar->iyzico_durum == '1'): ?>
                                                                            <li id="iyzico">
                                                                                <tip>Kredi</tip>
                                                                                <div class="paymentImage">
                                                                                    <img
                                                                                            src="<?php echo base_url('assets/images/stripe.png') ?>">
                                                                                </div>
                                                                                <b>Kredi Kartı & Banka Kartı
                                                                                    (Iyzico)</b>
                                                                                <span
                                                                                        class="badge badge-info  font-weight-bold">Anında
                                                                                    Onay</span>
                                                                                <span
                                                                                        class="badge badge-warning font-weight-bold"><?= $ayarlar->iyzico_komisyon ?>%
                                                                                    Komisyon</span>
                                                                            </li>
                                                                        <?php endif; ?>
                                                                        <?php if ($ayarlar->weepay_durum == '1'): ?>
                                                                            <li id="weepay">
                                                                                <tip>Kredi</tip>
                                                                                <div class="paymentImage">
                                                                                    <img
                                                                                            src="<?php echo base_url('assets/images/unnamed.png') ?>">
                                                                                </div>
                                                                                <b>Kredi Kartı & Banka Kartı
                                                                                    (Weepay)</b>
                                                                                <span
                                                                                        class="badge badge-info  font-weight-bold">Anında
                                                                                    Onay</span>
                                                                                <span
                                                                                        class="badge badge-warning font-weight-bold"><?= $ayarlar->weepay_komisyon ?>%
                                                                                    Komisyon</span>
                                                                            </li>
                                                                        <?php endif; ?>
                                                                        <?php if ($ayarlar->stripe_durum == '1'): ?>
                                                                            <li id="stripe">
                                                                                <tip>Kredi</tip>
                                                                                <div class="paymentImage">
                                                                                    <img
                                                                                            src="<?php echo base_url('assets/images/stripe.png') ?>">
                                                                                </div>
                                                                                <b>Kredi Kartı & Banka Kartı
                                                                                    (Stripe)</b>
                                                                                <span
                                                                                        class="badge badge-info  font-weight-bold">Anında
                                                                                    Onay</span>
                                                                                <span
                                                                                        class="badge badge-warning font-weight-bold"><?= $ayarlar->stripe_komisyon ?>
                                                                                    TL Komisyon</span>
                                                                            </li>
                                                                        <?php endif; ?>
                                                                        <?php if ($ayarlar->vallet_durum == '1'): ?>
                                                                            <li id="vallet">
                                                                                <tip>Kredi</tip>
                                                                                <div class="paymentImage">
                                                                                    <img
                                                                                            src="<?php echo base_url('assets/images/vallet.png') ?>">
                                                                                </div>
                                                                                <b>Kredi Kartı & Banka Kartı
                                                                                    (Vallet)</b>
                                                                                <span
                                                                                        class="badge badge-info  font-weight-bold">Anında
                                                                                    Onay</span>
                                                                                <span
                                                                                        class="badge badge-warning font-weight-bold"><?= $ayarlar->vallet_komisyon ?>%
                                                                                    Komisyon</span>
                                                                            </li>
                                                                        <?php endif; ?>
                                                                        <?php
                                                                        $bankalar = bankalar(['status' => 1]);
                                                                        if ($bankalar) { ?>
                                                                            <li id="banks">
                                                                                <tip>Havale/EFT</tip>
                                                                                <div class="paymentImage">
                                                                                    <img
                                                                                            src="<?php echo base_url('assets/images/atm.png') ?>">
                                                                                </div>
                                                                                <b>Havale/EFT</b>
                                                                                <span
                                                                                        class="badge badge-info  font-weight-bold">Süreli
                                                                                    Onay</span>
                                                                                <span
                                                                                        class="badge badge-warning font-weight-bold"><?= $ayarlar->havale_komisyon ?>%
                                                                                    Komisyon</span>
                                                                            </li>
                                                                            <?php
                                                                        }
                                                                        ?>
                                                                        <li id="gift">
                                                                            <tip>Kredi</tip>
                                                                            <div class="paymentImage">
                                                                                <img
                                                                                        src="<?php echo base_url('assets/images/2438193.svg') ?>">
                                                                            </div>
                                                                            <b>Bakiye Kuponu</b>
                                                                            <span
                                                                                    class="badge badge-info  font-weight-bold">Komisyonsuz</span>
                                                                        </li>
                                                                    </ul>
                                                                </div>
                                                                <div class="tab-pane fade" id="payment-2"
                                                                     role="tabpanel"
                                                                     aria-labelledby="pills-profile-tab">

                                                                    <ul class="PaymentTypes" id="paymentTypes">
                                                                        <?php if ($ayarlar->paytr_durum == '1'): ?>
                                                                            <li id="paytr">
                                                                                <tip>Kredi</tip>
                                                                                <div class="paymentImage">
                                                                                    <img
                                                                                            src="<?php echo base_url('assets/images/stripe.png') ?>">
                                                                                </div>
                                                                                <b>Kredi Kartı & Banka Kartı
                                                                                    (PayTR)</b>
                                                                                <span
                                                                                        class="badge badge-info  font-weight-bold">Anında
                                                                                    Onay</span>
                                                                                <span
                                                                                        class="badge badge-warning font-weight-bold"><?= $ayarlar->paytr_komisyon ?>%
                                                                                    Komisyon</span>
                                                                            </li>
                                                                        <?php endif; ?>
                                                                        <?php if ($ayarlar->iyzico_durum == '1'): ?>
                                                                            <li id="iyzico">
                                                                                <tip>Kredi</tip>
                                                                                <div class="paymentImage">
                                                                                    <img
                                                                                            src="<?php echo base_url('assets/images/stripe.png') ?>">
                                                                                </div>
                                                                                <b>Kredi Kartı & Banka Kartı
                                                                                    (Iyzico)</b>
                                                                                <span
                                                                                        class="badge badge-info  font-weight-bold">Anında
                                                                                    Onay</span>
                                                                                <span
                                                                                        class="badge badge-warning font-weight-bold"><?= $ayarlar->iyzico_komisyon ?>%
                                                                                    Komisyon</span>
                                                                            </li>
                                                                        <?php endif; ?>
                                                                        <?php if ($ayarlar->weepay_durum == '1'): ?>
                                                                            <li id="weepay">
                                                                                <tip>Kredi</tip>
                                                                                <div class="paymentImage">
                                                                                    <img
                                                                                            src="<?php echo base_url('assets/images/unnamed.png') ?>">
                                                                                </div>
                                                                                <b>Kredi Kartı & Banka Kartı
                                                                                    (Weepay)</b>
                                                                                <span
                                                                                        class="badge badge-info  font-weight-bold">Anında
                                                                                    Onay</span>
                                                                                <span
                                                                                        class="badge badge-warning font-weight-bold"><?= $ayarlar->weepay_komisyon ?>%
                                                                                    Komisyon</span>
                                                                            </li>
                                                                        <?php endif; ?>
                                                                        <?php if ($ayarlar->stripe_durum == '1'): ?>
                                                                            <li id="stripe">
                                                                                <tip>Kredi</tip>
                                                                                <div class="paymentImage">
                                                                                    <img
                                                                                            src="<?php echo base_url('assets/images/stripe.png') ?>">
                                                                                </div>
                                                                                <b>Kredi Kartı & Banka Kartı
                                                                                    (Stripe)</b>
                                                                                <span
                                                                                        class="badge badge-info  font-weight-bold">Anında
                                                                                    Onay</span>
                                                                                <span
                                                                                        class="badge badge-warning font-weight-bold"><?= $ayarlar->stripe_komisyon ?>
                                                                                    TL Komisyon</span>
                                                                            </li>
                                                                        <?php endif; ?>
                                                                        <?php if ($ayarlar->vallet_durum == '1'): ?>
                                                                            <li id="vallet">
                                                                                <tip>Kredi</tip>
                                                                                <div class="paymentImage">
                                                                                    <img
                                                                                            src="<?php echo base_url('assets/images/vallet.png') ?>">
                                                                                </div>
                                                                                <b>Kredi Kartı & Banka Kartı
                                                                                    (Vallet)</b>
                                                                                <span
                                                                                        class="badge badge-info  font-weight-bold">Anında
                                                                                    Onay</span>
                                                                                <span
                                                                                        class="badge badge-warning font-weight-bold"><?= $ayarlar->vallet_komisyon ?>%
                                                                                    Komisyon</span>
                                                                            </li>
                                                                        <?php endif; ?>
                                                                    </ul>
                                                                </div>
                                                                <div class="tab-pane fade" id="payment-3"
                                                                     role="tabpanel"
                                                                     aria-labelledby="pills-contact-tab">

                                                                    <ul class="PaymentTypes" id="paymentTypes">
                                                                        <?php if ($ayarlar->stripe_durum == '1'): ?>
                                                                            <li id="stripe">
                                                                                <tip>Kredi</tip>
                                                                                <div class="paymentImage">
                                                                                    <img
                                                                                            src="<?php echo base_url('assets/images/stripe.png') ?>">
                                                                                </div>
                                                                                <b>Kredi Kartı & Banka Kartı
                                                                                    (Stripe)</b>
                                                                                <span
                                                                                        class="badge badge-info  font-weight-bold">Anında
                                                                                    Onay</span>
                                                                                <span
                                                                                        class="badge badge-warning font-weight-bold"><?= $ayarlar->stripe_komisyon ?>
                                                                                    TL Komisyon</span>
                                                                            </li>
                                                                        <?php endif; ?>
                                                                    </ul>
                                                                </div>
                                                                <div class="tab-pane fade" id="payment-4"
                                                                     role="tabpanel"
                                                                     aria-labelledby="pills-contact-tab">

                                                                    <ul class="PaymentTypes" id="paymentTypes">
                                                                        <?php
                                                                        $bankalar = bankalar(['status' => 1]);
                                                                        if ($bankalar) { ?>
                                                                            <li id="banks">
                                                                                <tip>Havale/EFT</tip>
                                                                                <div class="paymentImage">
                                                                                    <img
                                                                                            src="<?php echo base_url('assets/images/atm.png') ?>">
                                                                                </div>
                                                                                <b>Havale/EFT</b>
                                                                                <span
                                                                                        class="badge badge-info  font-weight-bold">Süreli
                                                                                    Onay</span>
                                                                                <span
                                                                                        class="badge badge-warning font-weight-bold"><?= $ayarlar->havale_komisyon ?>%
                                                                                    Komisyon</span>
                                                                            </li>
                                                                            <?php
                                                                        }
                                                                        ?>
                                                                    </ul>
                                                                </div>
                                                                <div class="tab-pane fade" id="payment-5"
                                                                     role="tabpanel"
                                                                     aria-labelledby="pills-contact-tab">
                                                                    <ul class="PaymentTypes" id="paymentTypes">
                                                                        <li id="gift">
                                                                            <tip>Kredi</tip>
                                                                            <div class="paymentImage">
                                                                                <img
                                                                                        src="<?php echo base_url('assets/images/2438193.svg') ?>">
                                                                            </div>
                                                                            <b>Bakiye Kuponu</b>
                                                                            <span
                                                                                    class="badge badge-info  font-weight-bold">Komisyonsuz</span>
                                                                        </li>
                                                                    </ul>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-12">
                                                            <div id="intro">
                                                                <div class="text-center">
                                                                    <div>
                                                                        <img src="<?php echo base_url('assets/images/') ?>undraw_wallet_aym5.svg"
                                                                             width="180">
                                                                        <h3 class="c-custom"
                                                                            style="margin-bottom: 0px">
                                                                            Bakiye Yükleme Merkezi</h3>
                                                                        <span>Sol menüde bulunan ödeme
                                                                                yöntemlerinden
                                                                                size en uygun olanı seçin ve
                                                                                hesabınıza
                                                                                anında bakiye yükleyin.<br>
                                                                                Yaptığınız
                                                                                işlemler ödeme sağlayıcılarımız
                                                                                tarafından
                                                                                7/24 kontrol edilip
                                                                                onaylanmaktadır.</span>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="tab-content">
                                                                <div id="paytr-content" class="content d-none">
                                                                    <h3 class="c-custom">PayTR - Kredi /
                                                                        Banka Kartı ile
                                                                        ödeme</h3>
                                                                    <p>Kredi veya banka kartınız ile
                                                                        yapacağınız
                                                                        ödemelerin tümü 3D güvenliği ile
                                                                        gerçekleştirilmektedir.</p>
                                                                    <div
                                                                            class="col-md-8 col-md-offset-2 odeme-paneli">
                                                                        <?php if ($ayarlar->paytr_durum == '1'): ?>
                                                                            <form
                                                                                    action="<?= base_url('bakiye-yukle') ?>"
                                                                                    method="POST">
                                                                                <div class="align-items-center">
                                                                                    <input type="hidden"
                                                                                           id="komisyon_oran"
                                                                                           value="<?= $ayarlar->paytr_komisyon ?>">
                                                                                    <div class="form-group">
                                                                                        <label>Yüklemek
                                                                                            istediğiniz
                                                                                            tutar</label>
                                                                                        <input type="text" name="tutar"
                                                                                               id="tutar"
                                                                                               class="form-control"
                                                                                               inputmode="text">
                                                                                    </div>
                                                                                    <div class="form-group">
                                                                                        <label>Ödenecek
                                                                                            Tutar</label>
                                                                                        <div class="form-control"
                                                                                             id="odenecek_tutar">
                                                                                        </div>
                                                                                    </div>
                                                                                    <button class="btn btn-primary"
                                                                                            type="submit" name="odeme"
                                                                                            value="paytr">
                                                                                        Ödeme Yap
                                                                                    </button>
                                                                                </div>

                                                                            </form>
                                                                        <?php else: ?>
                                                                            <div class="alert alert-danger">
                                                                                PayTR Bulunamadı
                                                                            </div>
                                                                        <?php endif; ?>
                                                                    </div>
                                                                    <div style="clear:both;"></div>
                                                                </div>
                                                                <div id="weepay-content" class="content d-none">
                                                                    <h3 class="c-custom">WeePay - Kredi /
                                                                        Banka Kartı
                                                                        ile ödeme</h3>
                                                                    <p>Kredi veya banka kartınız ile
                                                                        yapacağınız
                                                                        ödemelerin tümü 3D güvenliği ile
                                                                        gerçekleştirilmektedir.</p>
                                                                    <div
                                                                            class="col-md-8 col-md-offset-2 odeme-paneli">
                                                                        <?php if ($ayarlar->weepay_durum == '1'): ?>
                                                                            <form
                                                                                    action="<?= base_url('bakiye-yukle') ?>"
                                                                                    method="POST">
                                                                                <div class="align-items-center">
                                                                                    <input type="hidden"
                                                                                           id="weepay_komisyon_oran"
                                                                                           value="<?= $ayarlar->weepay_komisyon ?>">
                                                                                    <div class="form-group">
                                                                                        <label>Yüklemek
                                                                                            istediğiniz
                                                                                            tutar</label>
                                                                                        <input type="text" name="tutar"
                                                                                               id="weepay_tutar"
                                                                                               class="form-control"
                                                                                               inputmode="text">
                                                                                    </div>
                                                                                    <div class="form-group">
                                                                                        <label>Ödenecek
                                                                                            Tutar</label>
                                                                                        <div class="form-control"
                                                                                             id="weepay_odenecek_tutar">
                                                                                        </div>
                                                                                    </div>
                                                                                    <button class="btn btn-primary"
                                                                                            type="submit" name="odeme"
                                                                                            value="weepay">
                                                                                        Ödeme Yap
                                                                                    </button>
                                                                                </div>

                                                                            </form>
                                                                        <?php else: ?>
                                                                            <div class="alert alert-danger">
                                                                                WeePay Bulunamadı
                                                                            </div>
                                                                        <?php endif; ?>
                                                                    </div>
                                                                    <div style="clear:both;"></div>
                                                                </div>
                                                                <div id="vallet-content" class="content d-none">
                                                                    <h3 class="c-custom">Vallet - Kredi /
                                                                        Banka Kartı
                                                                        ile ödeme</h3>
                                                                    <p>Kredi veya banka kartınız ile
                                                                        yapacağınız
                                                                        ödemelerin tümü 3D güvenliği ile
                                                                        gerçekleştirilmektedir.</p>
                                                                    <div
                                                                            class="col-md-8 col-md-offset-2 odeme-paneli">
                                                                        <?php if ($ayarlar->vallet_durum == '1'): ?>
                                                                            <form
                                                                                    action="<?= base_url('bakiye-yukle') ?>"
                                                                                    method="POST">
                                                                                <div class="align-items-center">
                                                                                    <input type="hidden"
                                                                                           id="vallet_komisyon_oran"
                                                                                           value="<?= $ayarlar->vallet_komisyon ?>">
                                                                                    <div class="form-group">
                                                                                        <label>Yüklemek
                                                                                            istediğiniz
                                                                                            tutar</label>
                                                                                        <input type="text" name="tutar"
                                                                                               id="vallet_tutar"
                                                                                               class="form-control"
                                                                                               inputmode="text">
                                                                                    </div>
                                                                                    <div class="form-group">
                                                                                        <label>Ödenecek
                                                                                            Tutar</label>
                                                                                        <div class="form-control"
                                                                                             id="vallet_odenecek_tutar">
                                                                                        </div>
                                                                                    </div>
                                                                                    <button class="btn btn-primary"
                                                                                            type="submit" name="odeme"
                                                                                            value="vallet">
                                                                                        Ödeme Yap
                                                                                    </button>
                                                                                </div>

                                                                            </form>
                                                                        <?php else: ?>
                                                                            <div class="alert alert-danger">
                                                                                WeePay Bulunamadı
                                                                            </div>
                                                                        <?php endif; ?>
                                                                    </div>
                                                                    <div style="clear:both;"></div>
                                                                </div>
                                                                <div id="stripe-content" class="content d-none">
                                                                    <h3 class="c-custom">Stripe - Kredi /
                                                                        Banka Kartı
                                                                        ile ödeme</h3>
                                                                    <p>Kredi veya banka kartınız ile
                                                                        yapacağınız
                                                                        ödemelerin tümü 3D güvenliği ile
                                                                        gerçekleştirilmektedir.</p>
                                                                    <span
                                                                            class="badge badge-warning font-weight-bold"
                                                                            style="font-size:13px ">Minimum
                                                                            Yükleme Tutarı :
                                                                            <strong>100 TL</strong></span>
                                                                    <span
                                                                            class="badge badge-warning font-weight-bold"
                                                                            style="font-size:13px ">İşlem Ücreti
                                                                            :
                                                                            <strong><?= $ayarlar->stripe_komisyon ?>
                                                                                TL</strong></span>
                                                                    <div
                                                                            class="col-md-8 col-md-offset-2 odeme-paneli">
                                                                        <?php if ($ayarlar->stripe_durum == '1'): ?>
                                                                            <form
                                                                                    action="<?= base_url('bakiye-yukle') ?>"
                                                                                    method="POST">
                                                                                <div class="align-items-center">
                                                                                    <input type="hidden"
                                                                                           id="stripe_komisyon_oran"
                                                                                           value="<?= $ayarlar->stripe_komisyon ?>">
                                                                                    <div class="form-group">
                                                                                        <label>Yüklemek
                                                                                            istediğiniz
                                                                                            tutar</label>
                                                                                        <input type="text" name="tutar"
                                                                                               id="stripe_tutar"
                                                                                               class="form-control"
                                                                                               inputmode="text">
                                                                                    </div>
                                                                                    <div class="form-group">
                                                                                        <label>Ödenecek
                                                                                            Tutar</label>
                                                                                        <div class="form-control"
                                                                                             id="stripe_odenecek_tutar">
                                                                                        </div>
                                                                                    </div>
                                                                                    <button class="btn btn-primary"
                                                                                            type="submit" name="odeme"
                                                                                            value="stripe">
                                                                                        Ödeme Yap
                                                                                    </button>
                                                                                </div>

                                                                            </form>
                                                                        <?php else: ?>
                                                                            <div class="alert alert-danger">
                                                                                Stripe Bulunamadı
                                                                            </div>
                                                                        <?php endif; ?>
                                                                    </div>
                                                                    <div style="clear:both;"></div>
                                                                </div>
                                                                <div id="banks-content" class="content d-none">
                                                                    <h3 class="c-custom">Havale / EFT ile
                                                                        ödeme</h3>
                                                                    <p>Havale eft ile yapacağınız ödemeler
                                                                        için ödeme
                                                                        bildirimi oluşturmalısınız ve
                                                                        kontrol
                                                                        sonrası onaylanacaktır.</p>
                                                                    <?php if ($bankalar): ?>
                                                                        <div class="row">
                                                                            <div class="col-12 text-center">
                                                                                <div class="bank-transfer">
                                                                                    <?php foreach ($bankalar as $banka): ?>
                                                                                        <div class="bank-img-area"
                                                                                             data-id="<?php echo $banka->id ?>"
                                                                                             onclick="paymentInfoPanel()">
                                                                                            <img src="<?= base_url($banka->image); ?>"
                                                                                                 height="100"
                                                                                                 width="auto">
                                                                                        </div>
                                                                                    <?php endforeach; ?>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    <?php else: ?>
                                                                        <div class="alert alert-danger">
                                                                            Banka Bulunamadı
                                                                        </div>
                                                                    <?php endif; ?>
                                                                    <div style="clear:both;"></div>
                                                                </div>
                                                                <div id="iyzico-content" class="content d-none">
                                                                    <h3 class="c-custom">Iyzico - Kredi /
                                                                        Banka Kartı
                                                                        ile ödeme</h3>
                                                                    <p>Kredi veya banka kartınız ile
                                                                        yapacağınız
                                                                        ödemelerin tümü 3D güvenliği ile
                                                                        gerçekleştirilmektedir.</p>
                                                                    <div
                                                                            class="col-md-8 col-md-offset-2 odeme-paneli">
                                                                        <?php if ($ayarlar->iyzico_durum == '1'): ?>
                                                                            <form
                                                                                    action="<?= base_url('bakiye-yukle') ?>"
                                                                                    method="POST">
                                                                                <div class="align-items-center">
                                                                                    <input type="hidden"
                                                                                           id="iyzico_komisyon_oran"
                                                                                           value="<?= $ayarlar->iyzico_komisyon ?>">
                                                                                    <div class="form-group">
                                                                                        <label>Yüklemek
                                                                                            istediğiniz
                                                                                            tutar</label>
                                                                                        <input type="text" name="tutar"
                                                                                               id="iyzico_tutar"
                                                                                               class="form-control"
                                                                                               inputmode="text">
                                                                                    </div>
                                                                                    <div class="form-group">
                                                                                        <label>Ödenecek
                                                                                            Tutar</label>
                                                                                        <div class="form-control"
                                                                                             id="iyzico_odenecek_tutar">
                                                                                        </div>
                                                                                    </div>
                                                                                    <button class="btn btn-primary"
                                                                                            type="submit" name="odeme"
                                                                                            value="iyzico">
                                                                                        Ödeme Yap
                                                                                    </button>
                                                                                </div>

                                                                            </form>
                                                                        <?php else: ?>
                                                                            <div class="alert alert-danger">
                                                                                Iyzico Bulunamadı
                                                                            </div>
                                                                        <?php endif; ?>
                                                                    </div>
                                                                </div>
                                                                <div id="gpay-content" class="content d-none">
                                                                    <div class="col-lg-4">
                                                                        <div class="alert alert-danger">
                                                                            null
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div id="gift-content" class="content d-none">
                                                                    <h3 class="c-custom">Bakiye Kuponu
                                                                        Kullan</h3>
                                                                    <p>Diğer kullanıcılar tarafından size
                                                                        hediye olarak
                                                                        gönderilen bakiye kuponlarını bu
                                                                        alanda
                                                                        bozdurabilirsiniz. Unutmayın 24 saat
                                                                        içerisinde
                                                                        kullanılmayan bakiye kuponları iptal
                                                                        olmaktadır.</p>
                                                                    <br>
                                                                    <form id="bakiyeKuponuForm" action=""
                                                                          method="POST" class="ui form">
                                                                        <div class="field">
                                                                            <label class="light-text-black"
                                                                                   style="font-size: 16px">Kupon
                                                                                Kodunuz</label>
                                                                            <input type="text" name="kod"
                                                                                   placeholder="XXXXX-XXXXX-XXXXX-XXXXX">
                                                                        </div>
                                                                        <button
                                                                                class="ui button btn-block btn-primary kuponBozdur"
                                                                                type="submit">Kuponu Bozdur
                                                                        </button>
                                                                    </form>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<script>
    function getFormData($form) {
        var unindexed_array = $form.serializeArray();
        var indexed_array = {};

        $.map(unindexed_array, function (n, i) {
            indexed_array[n['name']] = n['value'];
        });

        return indexed_array;
    }

    function paymentInfoPanel() {
        Swal.fire({
            html: $(".payment-info-modal .grid").html(),
            showCancelButton: false,
            showConfirmButton: false,
            showCloseButton: true,
            allowOutsideClick: false,
            allowEscapeKey: true,
            focusConfirm: false,
            customClass: {
                container: "login-special-container"
            }
        });
        $(".swal2-html-container #odemeBildirimForm #havale_tutar").on('input', function () {
            var tutar = parseFloat($(this).val());
            var komisyon = parseFloat(<?= $ayarlar->havale_komisyon ?>);
            var komisyon_tutar = (tutar * komisyon) / 100;
            var odenecek = tutar - komisyon_tutar;
            $(".swal2-html-container #odemeBildirimForm #havale_odenecek_tutar").html(odenecek.toFixed(2));
        });

        $(".swal2-html-container #odemeBildirimForm").submit((e) => {
            e.preventDefault();
            var form = $(".swal2-html-container #odemeBildirimForm");
            $.ajax({
                type: "POST",
                url: "<?= base_url("odemebildirimiolustur") ?>",
                data: getFormData(form),
                success: function (res) {
                    res = JSON.parse(res);
                    if (res.status) {
                        Swal.fire({
                            icon: 'success',
                            title: 'Ödeme Bildirimi Alındı',
                            text: 'Ödeme bildiriminiz tarafımıza ulaştı. En kısa süre içerisinde bakiyeniz hesabınıza yüklenecektir.',
                        })
                    } else {
                        if (res.tel_verify) {
                            Swal.close();
                            $("#teldogrula_step_1").modal("show");
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Ödeme Bildirimi Oluşturulamadı.',
                                text: res.message ? res.message : 'Girmiş olduğunuz bilgileri tekrar kontrol ediniz. Sorun hala devam ediyorsa yönetici ile iletişime geçiniz.',
                            })
                        }
                    }
                }
            })
        })
    }

    $(".bank-img-area").on('click', function () {
        var id = $(this).data('id');
        $.ajax({
            type: "POST",
            url: "<?= base_url("Home_controller/banka_getir") ?>",
            data: {
                banka: id
            },
            success: function (res) {
                res = JSON.parse(res);
                if (res.status) {
                    $('.modal-bank-img').attr('src', 'https://kemalellidort.com.tr/' + res.banka.image);
                    $('.modal-transfer-bank-name').html(res.banka.name);
                    $('.modal-iban-area').html(res.banka.iban);
                    $('.modal-bank-desc').html(res.banka.description);
                    $('.modal-bank-select').html('<option value="' + res.banka.id + '">' + res.banka.name + '</option>');
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Hata',
                        text: 'Yapmaya Çalıştığınız İşlem Geçerli Değil',
                    })
                }
            }
        })
    });

    $(document).ready(function () {
        $("#bakiyeKuponuForm").submit((e) => {
            e.preventDefault();
            var form = $("#bakiyeKuponuForm");
            $.ajax({
                type: "POST",
                url: "<?= base_url("kuponkullan") ?>",
                data: getFormData(form),
                success: function (res) {
                    res = JSON.parse(res);
                    if (res.status) {
                        Swal.fire({
                            icon: 'success',
                            title: 'Kupon Kullanıldı',
                            text: res.message ? res.message : 'Kupon bakiyesi hesabınıza aktarıldı.',
                        })
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Kupon Kullanılamadı.',
                            text: res.message ? res.message : 'Yönetici ile iletişime geçiniz.',
                        })
                    }
                }
            })
        })
        $("#tutar").on('input', function () {
            var tutar = parseFloat($(this).val());
            var komisyon = parseFloat($("#komisyon_oran").val());
            var odenecek = tutar + (tutar * komisyon / 100);
            $("#odenecek_tutar").html(odenecek);
        });
        $("#iyzico_tutar").on('input', function () {
            var tutar = parseFloat($(this).val());
            var komisyon = parseFloat($("#iyzico_komisyon_oran").val());
            var odenecek = tutar + (tutar * komisyon / 100);
            $("#iyzico_odenecek_tutar").html(odenecek);
        });
        $("#weepay_tutar").on('input', function () {
            var tutar = parseFloat($(this).val());
            var komisyon = parseFloat($("#weepay_komisyon_oran").val());
            var odenecek = tutar + (tutar * komisyon / 100);
            $("#weepay_odenecek_tutar").html(odenecek);
        });
        $("#vallet_tutar").on('input', function () {
            var tutar = parseFloat($(this).val());
            var komisyon = parseFloat($("#vallet_komisyon_oran").val());
            var odenecek = tutar + (tutar * komisyon / 100);
            $("#vallet_odenecek_tutar").html(odenecek);
        });
        $("#stripe_tutar").on('input', function () {
            var tutar = parseFloat($(this).val());
            var komisyon = parseFloat($("#stripe_komisyon_oran").val());
            var odenecek = tutar + komisyon;
            $("#stripe_odenecek_tutar").html(odenecek);
        });
    });

    $(document).ready(function () {
        // İlk sekme ve içeriği aktif hale getirme
        // Sekme tıklama olayı
        $('.PaymentTypes li').click(function () {
            var tabId = $(this).attr('id');

            // Aktif sekmeleri değiştirme
            $('.PaymentTypes li').removeClass('active');
            $(this).addClass('active');
            $('#intro').addClass("d-none");
            // Tüm içerikleri gizleme
            $('.tab-content .content').addClass('d-none');

            // İlgili içeriği gösterme
            $('#' + tabId + '-content').removeClass('d-none');
        });
    });

</script>