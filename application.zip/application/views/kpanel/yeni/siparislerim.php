<main class="k-panel-warper">
    <div class="sec-warper mb-4">
        <div class="container normal-container p-0">
            <div class="k-panel-g-warper">
                <div class="row">
                    <div class="col-xl-3 col-lg-3 col-md-12 col-sm-12 wd-none mt-3 p-0 ">
                        <div class="accordion accordion-flush acc-kpc-menu" id="accordionFlushExample">
                            <div class="accordion-item acc-kpc-menu-item">
                                <h2 class="accordion-header acc-kpc-menu-header" id="flush-headingOne">
                                    <button class="accordion-button collapsed acc-kpc-menu-btn" type="button"
                                            data-bs-toggle="collapse" data-bs-target="#flush-collapseOne"
                                            aria-expanded="false" aria-controls="flush-collapseOne">
                                        Hızlı Menü
                                    </button>
                                </h2>
                                <div id="flush-collapseOne" class="accordion-collapse collapse"
                                     aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
                                    <div class="accordion-body acc-kpc-menu-body">
                                        <div class="k-panel-left-navbar-warper">
                                            <div class="k-panel-left-navbar-area">
                                                <div class="nav flex-column nav-pills bg-custom-none " id="v-pills-tab" role="tablist"
                                                     aria-orientation="vertical">
                                                    <?php if (magaza_check()) { ?>
                                                        <div class="gt-store">
                                                            <a href="<?php echo base_url('m/' . magaza($kullanici->kullanici_id)->magaza_seo) ?>"
                                                               class="btn btn-primary settings-btn mb-3 w-100">Mağzaya Git</a>
                                                        </div>
                                                    <?php } ?>
                                                    <a href="<?php echo base_url('hesabim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100">Profilim</a>
                                                    <a href="<?php echo base_url('siparislerim') ?>" title=""
                                                       class="nav-link kpc-nav-btn w-spacial w-100 active">Siparişlerim</a>
                                                    <a href="<?php echo base_url('satislar') ?>" title=""
                                                       class="nav-link kpc-nav-btn w-spacial w-100">Gold Al - Sat</a>
                                                    <a href="<?php echo base_url('sorularim') ?>" title=""
                                                       class="nav-link kpc-nav-btn w-spacial w-100">Sorularım</a>
                                                    <a href="<?php echo base_url('bakiye') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100">Bakiye</a>
                                                    <a href="<?php echo base_url('odeme-talep') ?>" title=""
                                                       class="nav-link kpc-nav-btn w-spacial w-100">Para Çek</a>
                                                    <a href="<?php echo base_url('destek-taleplerim') ?>" title=""
                                                       class="nav-link kpc-nav-btn w-spacial w-100">Destek Taleplerim</a>
                                                    <a href="<?php echo base_url('itirazlarim') ?>" title=""
                                                       class="nav-link kpc-nav-btn w-spacial w-100">İtirazlarım</a>
                                                    <a href="<?php echo base_url('hesap-ayarlari') ?>" title=""
                                                       class="nav-link kpc-nav-btn w-spacial w-100">Profil Ayarlarım</a>
                                                    <a class="nav-link kpc-nav-btn w-spacial w-100" href="<?php echo base_url('cikis') ?>">Çıkış</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-3 col-md-12 col-sm-12 md-none pr-0">
                        <div class="k-panel-left-navbar-warper m-bg2">
                            <div class="k-panel-left-navbar-area">
                                <div class="nav flex-column nav-pills bg-custom-none " id="v-pills-tab" role="tablist"
                                     aria-orientation="vertical">
                                    <?php if (magaza_check()) { ?>
                                        <div class="gt-store">
                                            <a href="<?php echo base_url('m/' . magaza($kullanici->kullanici_id)->magaza_seo) ?>"
                                               class="btn btn-primary settings-btn mb-3 w-100">Mağzaya Git</a>
                                        </div>
                                    <?php } ?>
                                    <a href="<?php echo base_url('hesabim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"><img
                                                class="sw-icon-item" src="<?php echo base_url('assets/front/images/uzer.webp') ?>" alt=""
                                                loading="lazy">Profilim</a>
                                    <a href="<?php echo base_url('siparislerim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100 active"><img
                                                class="sw-icon-item" src="<?php echo base_url('assets/front/images/shopping-list.webp') ?>" alt=""
                                                loading="lazy">Siparişlerim</a>
                                    <a href="<?php echo base_url('satislar') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"><img
                                                class="sw-icon-item" src="<?php echo base_url('assets/front/images/gold.webp') ?>" alt=""
                                                loading="lazy">Gold Al - Sat</a>
                                    <a href="<?php echo base_url('sorularim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"><img
                                                class="sw-icon-item" src="<?php echo base_url('assets/front/images/s4.png') ?>" alt="" loading="lazy">Sorularım</a>
                                    <a href="<?php echo base_url('bakiye') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"><img
                                                class="sw-icon-item" src="<?php echo base_url('assets/front/images/salary.webp') ?>" alt=""
                                                loading="lazy">Bakiye</a>
                                    <a href="<?php echo base_url('odeme-talep') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"><img
                                                class="sw-icon-item" src="<?php echo base_url('assets/front/images/transfer.webp') ?>" alt=""
                                                loading="lazy">Para Çek</a>
                                    <a href="<?php echo base_url('destek-taleplerim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"><img
                                                class="sw-icon-item" src="<?php echo base_url('assets/front/images/customer-service.webp') ?>" alt=""
                                                loading="lazy">Destek Sistemi</a>
                                    <a href="<?php echo base_url('itirazlarim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"><img
                                                class="sw-icon-item" src="<?php echo base_url('assets/front/images/error.webp') ?>" alt=""
                                                loading="lazy">İtirazlarım</a>
                                    <a href="<?php echo base_url('hesap-ayarlari') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"><img
                                                class="sw-icon-item" src="<?php echo base_url('assets/front/images/s1.png') ?>" alt="" loading="lazy">Profil
                                        Ayarlarım</a>
                                    <a class="nav-link kpc-nav-btn w-spacial w-100" href="<?php echo base_url('cikis') ?>"><img class="sw-icon-item"
                                                                                                                                src="<?php echo base_url('assets/front/images/logout.webp') ?>"
                                                                                                                                alt="" loading="lazy">Çıkış</a>
                                </div>
                            </div>
                        </div>
                    </div>
                 


                    <div class="col-xl-9 col-lg-9 col-md-12 col-sm-12 m-bg m-br">
                        <div class="k-panel-content-right">
                            <div class="tab-content" id="v-pills-tabContent">
                                <div class="tab-pane fade show active" id="orders" role="tabpanel" aria-labelledby="orders-tab"
                                     tabindex="0">
                                    <div class="container-fluid p-0">
                                        <div class="k-panel-content-box">
                                            <div class="row">
                                                <div class="col-12">
                                                    <section class="my-purchases">
                                                        <div class="container m-0 p-0">
                                                            <div class="panel">
                                                                <div class="panel-body bg-snone">
                                                                    <p>Aşağıda bulunan menüden sipariş türü
                                                                        seçimi
                                                                        yapınız. Seçim yaptıktan sonra
                                                                        siparişleriniz
                                                                        listelenecektir.<br>Detayını
                                                                        görmek istediğiniz siparişin
                                                                        üstüne
                                                                        tıklayınız.</p>
                                                                    <div class="alfa-tabs">
                                                                        <ul class="nav nav-tabs">
                                                                            <li class="nav-item active" tabindex="3"
                                                                                data-tab="aldigim-urunler"
                                                                                onclick="if (!window.__cfRLUnblockHandlers) return false; updateQueryForTab('aldigim-urunler');onTabChange('aldigim-urunler');">
                                                                                <a class="nav-link active"
                                                                                   data-toggle="tab"
                                                                                   href="#aldigimurunler">Satın
                                                                                    Aldığım Ürünler</a>
                                                                            </li>
                                                                            <li class="nav-item"
                                                                                tabindex="1"
                                                                                data-tab="aldigim-ilanlar"
                                                                                onclick="if (!window.__cfRLUnblockHandlers) return false; updateQueryForTab('aldigim-ilanlar');onTabChange('aldigim-ilanlar');">
                                                                                <a class="nav-link"
                                                                                   data-toggle="tab"
                                                                                   href="#aldiklarim">Aldığım
                                                                                    İlanlar </a>
                                                                            </li>
                                                                            <li class="nav-item"
                                                                                id="sattigim-ilanlar" tabindex="2"
                                                                                data-tab="sattigim-ilanlar"
                                                                                onclick="if (!window.__cfRLUnblockHandlers) return false; updateQueryForTab('sattigim-ilanlar');onTabChange('sattigim-ilanlar');">
                                                                                <a class="nav-link" data-toggle="tab" href="#sattiklarim">Sattığım
                                                                                    İlanlar</a>
                                                                            </li>

                                                                        </ul>
                                                                    </div>
                                                                    <div class="tab-content">
                                                                        <div id="aldiklarim"
                                                                             data-tab="aldigim-ilanlar"
                                                                             class="tab-pane"
                                                                             style="padding:0"><br>
                                                                            <div class="well" id="buy-well">
                                                                                <p>*Yapacağınız kelime arama
                                                                                    <b>Sipariş
                                                                                        Numarası</b> ,
                                                                                    <b>İlan
                                                                                        Başlığı</b>
                                                                                    üzerinde
                                                                                    filtrelenecektir.</p>
                                                                                <div class="row">
                                                                                    <div class="col-md-6">
                                                                                        <p>Kelime Arama</p>
                                                                                        <input type="search"
                                                                                               name="searchText"
                                                                                               class="searchText form-control"
                                                                                               style="margin-bottom: 10px;"
                                                                                               placeholder="Filtrelenecek kelimeyi buraya yazınız.">
                                                                                    </div>
                                                                                    <div class="col-md-5">
                                                                                        <p>Sipariş Tarihi
                                                                                        </p>
                                                                                        <input type="date"
                                                                                               class="form-control"
                                                                                               onfocus="this.showPicker()"
                                                                                               name="startDate"
                                                                                               value="">
                                                                                    </div>
                                                                                </div>
                                                                                <button type="button"
                                                                                        class="btn btn-block btn-primary buy-filter"
                                                                                        data-type="buy">Filtrele
                                                                                </button>
                                                                            </div>

                                                                            <div class="aldiklarimIcerik">
                                                                                <div class="col-md-12 text-center">
                                                                                    <div class="spinner-border text-light"
                                                                                         role="status">
                                                                                        <span class="sr-only">Loading...</span>
                                                                                    </div>
                                                                                    <br><br>
                                                                                    <p>İçerik
                                                                                        yükleniyor.<br>Lütfen
                                                                                        bekleyiniz..</p>
                                                                                </div>
                                                                            </div>
                                                                            <div class="ButtonArea text-center">
                                                                            </div>
                                                                        </div>
                                                                        <div id="sattiklarim"
                                                                             data-tab="sattigim-ilanlar"
                                                                             class="tab-pane"
                                                                             style="padding:0">
                                                                            <br>
                                                                            <div class="sattiklarimIcerik">
                                                                                <div class="col-md-12 text-center">
                                                                                    <div class="spinner-border text-light"
                                                                                         role="status"><span
                                                                                                class="sr-only">Loading...</span>
                                                                                    </div>
                                                                                    <br><br>
                                                                                    <p>İçerik
                                                                                        yükleniyor.<br>Lütfen
                                                                                        bekleyiniz..</p>
                                                                                </div>
                                                                            </div>
                                                                            <div class="ButtonArea text-center">
                                                                            </div>
                                                                        </div>
                                                                        <div id="aldigimurunler"
                                                                             data-tab="aldigim-urunler"
                                                                             class="container tab-pane active"
                                                                             style="width: 100%;">
                                                                            <br>
                                                                            <div class="urunlerIcerik" style="justify-content: center">
                                                                                <div class="col-md-12 text-center">
                                                                                    <div class="spinner-border text-light"
                                                                                         role="status"><span
                                                                                                class="sr-only">Loading...</span>
                                                                                    </div>
                                                                                    <br><br>
                                                                                    <p>İçerik
                                                                                        yükleniyor.<br>Lütfen
                                                                                        bekleyiniz..</p>
                                                                                </div>
                                                                            </div>
                                                                            <div class="ButtonArea text-center">
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="modal fade" id="degerlendirmeModal"
                                                                     tabindex="-1" role="dialog"
                                                                     aria-labelledby="myModalLabel">
                                                                    <div class="modal-dialog" role="document">
                                                                        <div class="modal-content">
                                                                            <div class="modal-header">
                                                                                <button type="button" class="close"
                                                                                        data-dismiss="modal"
                                                                                        aria-label="Close"
                                                                                        onclick="document.getElementById('degerlendirmeModal').style.display='none'">
                                                                                        <span
                                                                                                aria-hidden="true">×</span>
                                                                                </button>
                                                                                <h4 class="modal-title"
                                                                                    id="myModalLabel">
                                                                                    Ürün
                                                                                    Değerlendirme
                                                                                </h4>
                                                                            </div>
                                                                            <form action="" method="POST" id="" class="DegerlendirmeFormNotify">
                                                                                <div class="modal-body NotifyPanel">
                                                                                    <input type="hidden"
                                                                                           name="urun-degerlendir-urun-id">
                                                                                    <input type="hidden"
                                                                                           name="urun-degerlendir-siparis-no">
                                                                                    <input type="hidden"
                                                                                           name="urun-degerlendir-magaza-id">
                                                                                    <p>Gerçekleştirmiş
                                                                                        olduğunuz bu
                                                                                        satın alma işlemini
                                                                                        diğer
                                                                                        kullanıcılara
                                                                                        tavsiye
                                                                                        edermisiniz? Bu
                                                                                        satın alma
                                                                                        işleminden
                                                                                        ne
                                                                                        kadar memnun
                                                                                        kaldınız?</p>
                                                                                    <p class="pull-left">
                                                                                        Memnuniyet:</p>
                                                                                    <p class="pull-right"
                                                                                       id="Memnuniyet_Puan">
                                                                                        <b id="Puan_' . $Data->Id . '">5</b><small>
                                                                                            / 5</small>
                                                                                    </p>
                                                                                    <input type="range" min="1"
                                                                                           max="5" value="5"
                                                                                           class="slider"
                                                                                           name="memnuniyet"
                                                                                           data-id="' . $Data->Id . '">
                                                                                    <div style="clear:both;">
                                                                                    </div>
                                                                                    <br>
                                                                                    <p class="pull-left">
                                                                                        Yorumunuz:</p>
                                                                                    <textarea name="yorum"
                                                                                              class="form-control"
                                                                                              rows="4" maxlength="150"
                                                                                              minlength="5"
                                                                                              placeholder="Lütfen ürün satın alma deneyiminizi açıklayın. (Örn: Hızlı teslim edildi teşekkürler.)"
                                                                                              required=""></textarea>
                                                                                </div>
                                                                                <div class="modal-footer">
                                                                                    <button type="submit"
                                                                                            class="btn btn-primary btn-block">
                                                                                        Değerlendirmeyi
                                                                                        Gönder
                                                                                    </button>
                                                                                </div>
                                                                            </form>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </section>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<div class="modal fade" id="sohbet" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
     aria-hidden="true">
    <form action="" method="post" id="infoSohbet">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="form-group">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                        <label for="recipient-name" class="col-form-label">Sohbet'i başlatmak istediğiniz üyenin
                            kullanıcı adını
                            yazın</label>
                        <input name="username" type="text" class="form-control" id="recipient-name"
                               placeholder="Üyenin Kullanıcı Adı">
                        <label for="message-text" class="col-form-label">Mesajınız:</label>
                        <textarea rows="4" cols="50" class="form-control" name="gidicekmesaj" id="mesaj"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-info btn-lg btn-block">Sohbeti Başlat</button>
                </div>
            </div>
        </div>
    </form>
</div>
<script>
    $('.chat-list-name li').click(function () {
        var select_chat = $(this).attr('data-target');
        if ($('.chat-area').hasClass('open')) {
            $('.chat-area').removeClass('open')
            $('#select-chat-' + select_chat).addClass('open')
        } else {
            $('#select-chat-' + select_chat).addClass('open')
        }
    })

    $('#sendmessage').keypress(function (e) {
        if (e.which === 13) {
            $('.sendReMessage').click()
        }
    })

    $(document).on("submit", "#infoSohbet", function (event) {
        <?php if (aktif_kullanici()) : ?>
        $.ajax({
            type: "POST",
            url: base_url + "ajax_controller/sohbet_add_mesaj",
            data: {
                mesaj: $('textarea[name="gidicekmesaj"]').val(),
                username: $('input[name="username"]').val(),
                kullanici_id: <?= $kullanici->kullanici_id ?>
            },
            success: function (data) {
                var d = JSON.parse(data);
                if (d.status.status == 'error') {
                    Swal.fire(
                        'Hata!',
                        d.status.message,
                        d.status.status,
                    );
                } else if (d.status.status == 'success') {
                    Swal.fire(
                        'Başarılı!',
                        d.status.message,
                        d.status.status,
                    ).then((result) => {
                        location.reload();
                    })
                }

            }
        });
        event.preventDefault();
        <?php else : ?>
        Swal.fire({
            title: 'Giriş Yap',
            text: "Mesajlaşmak için giriş yapmalısınız.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Giriş Yap',
            cancelButtonText: 'Hayır, İptal Et',
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = "<?= base_url('giris-yap') ?>";
            }
        })
        <?php endif; ?>
    });

    $(document).on("click", ".menu-left-area", function (event) {
        <?php if (aktif_kullanici()) : ?>
        var uniq = $(this).data('target');
        $.ajax({
            type: "POST",
            url: base_url + "ajax_controller/sohbet_getir",
            data: {
                uniq: uniq,
                kullanici_id: <?= $kullanici->kullanici_id ?>
            },
            success: function (data) {
                var d = JSON.parse(data);
                if (d.status == 'error') {
                    Swal.fire(
                        'Hata!',
                        d.message,
                        d.status,
                    );
                } else if (d.status == 'success') {
                    var targetDiv = $('#select-chat-' + uniq).find('.chat-bar');
                    targetDiv.html(d.html); // İçerik kısmını kendi isteğinize göre güncelleyin
                    $('.chat-bar').scrollTop($('.chat-bar')[0].scrollHeight)
                }

            }
        });
        event.preventDefault();
        <?php else : ?>
        Swal.fire({
            title: 'Giriş Yap',
            text: "Mesajlaşmak için giriş yapmalısınız.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Giriş Yap',
            cancelButtonText: 'Hayır, İptal Et',
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = "<?= base_url('giris-yap') ?>";
            }
        })
        <?php endif; ?>
    });

    $(document).on("click", ".sendReMessage", function (event) {
        <?php if (aktif_kullanici()) : ?>
        var inputValue = $(this).closest('.chat-container').find('input[name="remessage"]').val();
        var uniq = $(this).data('target');
        $.ajax({
            type: "POST",
            url: base_url + "ajax_controller/send_re_message",
            data: {
                uniq: uniq,
                kullanici_id: <?= $kullanici->kullanici_id ?>,
                message: inputValue
            },
            success: function (data) {
                var d = JSON.parse(data);
                if (d.status == 'error') {
                    Swal.fire(
                        'Hata!',
                        d.message,
                        d.status,
                    );
                } else if (d.status == 'success') {
                    var targetDiv = $('#select-chat-' + uniq).find('.chat-bar');
                    targetDiv.append(d.html); // İçerik kısmını kendi isteğinize göre güncelleyin
                    $('#sendmessage').val(' ');
                    $('.chat-bar').scrollTop($('.chat-bar')[0].scrollHeight)
                }

            }
        });
        event.preventDefault();
        <?php else : ?>
        Swal.fire({
            title: 'Giriş Yap',
            text: "Mesajlaşmak için giriş yapmalısınız.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Giriş Yap',
            cancelButtonText: 'Hayır, İptal Et',
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = "<?= base_url('giris-yap') ?>";
            }
        })
        <?php endif; ?>
    });

</script>