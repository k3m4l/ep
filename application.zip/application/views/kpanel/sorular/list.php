<section class="col-lg-8 account-profile-element">
    <div class="account-profile-photo-area"
         style="background-image: url('<?php echo base_url($kullanici->kullanici_banner) ?>')">
        <div class="user-photo-area">
            <?php if (strpos($kullanici->kullanici_resim, "/.jpg") !== false) { ?>
                <img src="https://ui-avatars.com/api/?name=<?= $kullanici->kullanici_ad ?>&background=0D8ABC&color=fff"
                     alt=""/>
            <?php } else { ?>
                <img src="<?= base_url($kullanici->kullanici_resim) ?>" alt=""/>
            <?php } ?>
        </div>
    </div>
</section>
<section class="col-lg-8 control-panel">
    <div class="account-area">
    
    <div class="container-fluid">

        <div class="row">
            <div class="col-lg-3 col-md-4 col-12 p-0">
                <div class="user-img-left-area">
                    <img src="<?= base_url($kullanici->kullanici_resim) ?>" alt=""/>
                    <div>
                        <?= $kullanici->kullanici_ad ?>
                    </div>
                </div>
                
                <?php $this->load->view('kpanel/inc/menu'); ?>
            </div>

            <div class="col-lg-9 col-md-8 col-12 pr-0">
                <h2 class="title">İlan Sorularım</h2>
                <div class="card mb-4">
                    
                    <div class="table-responsive border-0">
                        <table class="table mb-0 text-nowrap dark-table light-table">
                            <thead>
                            <tr>
                                <th class="border-0">İlan İsim</th>
                                <th class="border-0">Soru</th>
                                <th class="border-0">Durum</th>
                                <th class="border-0">Tarih</th>
                                <th class="border-0"></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php if (!empty($sorular)) { ?>
                                <?php foreach ($sorular as $key => $val) { ?>
                                    <tr>
                                        <td class="border-top-0"><?= $val->urun_ad ?></td>
                                        <td class="border-top-0"><?= $val->soru ?></td>
                                        <td class="border-top-0">
                                            <?php if (empty($val->soru_cevap)) { ?>
                                                <span class="badge badge-warning">Cevap Bekliyor..</span>
                                            <?php } else { ?>
                                                <span class="badge badge-success">Cevap Verildi</span>
                                            <?php } ?>
                                        </td>
                                        <td class="border-top-0"><?= ayli_tarih($val->tarih) ?></td>
                                        <td class="border-top-0">
                                            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#sorucevap-<?php echo $val->soru_id ?>"><i class="far fa-eye"></i></button>
                                            <button type="button" onclick="window.location.href='<?php echo base_url($val->urun_seo) ?>'" class="btn btn-info"><i class="fas fa-external-link-alt"></i></button>
                                        </td>
                                    </tr>
                                    <div class="modal fade" id="sorucevap-<?php echo $val->soru_id ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
                                         aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-centered" role="document">
                                            <div class="modal-content sms">
                                                <div class="modal-header">
                                                    <h4 class="modal-title text-center" id="exampleModalCenterTitle"><?php echo $val->urun_ad ?> İlanınızın Sorusu</h4>
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="alert alert-info alert-dismissible text-left alert-grid" role="alert">
                                                    <i class="fas fa-question"></i>
                                                    <div><strong>Soru:</strong><br><?php echo $val->soru ?>
                                                    </div>
                                                </div>
                                                <?php if (!empty($val->soru_cevap)) { ?>
                                                    <div class="alert alert-info alert-dismissible text-left alert-grid" role="alert">
                                                        <div><strong>Cevap:</strong><br><?php echo $val->soru_cevap->soru ?>
                                                        </div>
                                                    </div>
                                                <?php } ?>
                                            </div>
                                        </div>
                                    </div>
                                <?php } ?>
                            <?php } else { ?>
                                <tr>
                                    <td colspan="6" align="center">
                                        <div class="notification warning closeable"><p>Sipariş Bulunamadı</p>
                                        </div>
                                    </td>
                                </tr>
                            <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
</section>