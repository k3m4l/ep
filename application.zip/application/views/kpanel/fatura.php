<?php $this->load->view('kpanel/inc/kullanici_nav', array('kullanici' => $kullanici)); ?>
<div class="pb-5 py-md-5">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-4 col-12">
                <!-- Side navbar -->
                <?php $this->load->view('kpanel/inc/menu'); ?>
            </div>
            <div class="col-lg-9 col-md-8 col-12">
                
                <div class="card border-0" id="invoice">
                    
                    <div class="card-body">
                        <div class="d-flex justify-content-between mb-6">
                            <div>
                                <!-- Img -->
                                <img src="<?= base_url($ayarlar->site_logo) ?>" alt="" class="mb-4">
                                <h4 class="mb-0">Fatura Özeti</h4>
                                <small>SİPARİŞ NUMARASI: #<?= $siparis->siparis_no ?></small>
                            </div>
                            <div>
                                <a href="#!" class="badge badge-primary print-link no-print"><i class="fe fe-printer"></i> Yazdır</a>
                            </div>
                        </div>
                        <!-- Row -->
                        <div class="row">
                            <div class="col-md-6 col-6">
                                <span class="font-size-xs">Satıcı</span>
                                <h5 class="mb-3"><?= $siparis->magaza_ad ?></h5>
                                <p class="mb-0"><?= $siparis->fatura_adres ?></p>
                                <p><?= sehir_ad($siparis->sehir) ?> / <?= ilce_ad($siparis->ilce) ?></p>
                            </div>
                            <div class="col-md-6 col-6">
                                <span class="font-size-xs">Alıcı</span>
                                <h5 class="mb-3"><?= $siparis->siparis_ad . " " . $siparis->siparis_soyad ?></h5>
                                <p class="mb-0"><?= $siparis->siparis_adres ?></p>
                                <p><?= sehir_ad($siparis->siparis_il) ?> / <?= ilce_ad($siparis->siparis_ilce) ?></p>
                            </div>
                        </div>
                        <!-- Row -->
                        <div class="row mb-5">
                            <div class="col-6">
                                <span class="font-size-xs">Sipariş Numarası</span>
                                <h6 class="mb-0">#<?= $siparis->siparis_no ?></h6>
                            </div>
                            <div class="col-6">
                                <div class="float-right">
                                    <span class="font-size-xs">Oluşturulma Tarihi</span>
                                    <h6 class="mb-0"><?= date('d.m.Y H:i', strtotime($siparis->siparis_tarih)) ?></h6>
                                </div>
                            </div>
                        </div>
                        
                        <div class="table-responsive mb-12">
                            <table class="table mb-0 text-nowrap table-borderless">
                                <thead>
                                <tr>
                                    <th scope="col">Ürün</th>
                                    <th scope="col">Adet</th>
                                    <th scope="col">Birim Fiyat</th>
                                    <th scope="col">Tutar</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr class="text-dark">
                                    <td class="py-2"><?= $siparis->urun_ad ?></span></td>
                                    <td class="py-2">1</td>
                                    <td class="py-2"><?= $siparis->siparis_tutar ?>₺</td>
                                    <td class="py-2"><?= $siparis->siparis_tutar ?>₺</td>
                                </tr>
                                </tbody>
                                <tfoot>
                                <tr class="text-dark">
                                    <td colspan="2" class="py-2"></td>
                                    <td colspan="1" class="pb-0">Toplam</td>
                                    <td class="pb-0"><?= $siparis->siparis_tutar ?>₺</td>
                                </tr>
                                <tr class="text-dark">
                                    <td colspan="2" class="py-2"></td>
                                    <td colspan="1" class="py-0">Komisyon/KDV'siz Tutar</td>
                                    <td class="py-0"><?= $siparis->siparis_ktutar ?>₺</td>
                                </tr>
                                <tr class="text-dark">
                                    <td colspan="2" class="py-2"></td>
                                    <td colspan="1" class="pt-0">Komisyon/KDV Tutar*</td>
                                    <td class="pt-0"><?= $siparis->siparis_tutar - $siparis->siparis_ktutar ?>₺</td>
                                </tr>
                                <tr class="text-dark">
                                    <td colspan="2" class="py-2"></td>
                                    <td colspan="1" class="border-top py-1 font-weight-bold">Genel Toplam</td>
                                    <td class="border-top py-1 font-weight-bold"><?= $siparis->siparis_tutar ?>₺</td>
                                </tr>
                                </tfoot>
                            </table>
                        </div>
                        <!-- Short note -->
                        <p class="border-top pt-3 mb-0 ">Not: Bu fatura <span class="text-primary"><?=base_url()?></span> internet adresinden oluşturulmuştur.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>