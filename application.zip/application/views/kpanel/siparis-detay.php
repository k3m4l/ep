<main class="k-panel-warper">
    <div class="sec-warper mb-4">
        <div class="container normal-container p-0">
            <div class="k-panel-g-warper k-panel-content-box">
                <div class="row">
                    <div class="col-xl-3 col-lg-3 col-md-12 col-sm-12 wd-none mt-3 p-0 ">
                        <div class="accordion accordion-flush acc-kpc-menu" id="accordionFlushExample">
                            <div class="accordion-item acc-kpc-menu-item">
                                <h2 class="accordion-header acc-kpc-menu-header" id="flush-headingOne">
                                    <button class="accordion-button collapsed acc-kpc-menu-btn" type="button"
                                            data-bs-toggle="collapse" data-bs-target="#flush-collapseOne"
                                            aria-expanded="false" aria-controls="flush-collapseOne">
                                        Hızlı Menü
                                    </button>
                                </h2>
                                <div id="flush-collapseOne" class="accordion-collapse collapse"
                                     aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
                                    <div class="accordion-body acc-kpc-menu-body">
                                        <div class="k-panel-left-navbar-warper">
                                            <div class="k-panel-left-navbar-area">
                                                <div class="nav flex-column nav-pills bg-custom-none " id="v-pills-tab" role="tablist"
                                                    aria-orientation="vertical">
                                                <?php if (magaza_check()) { ?>
                                                        <div class="gt-store">
                                                            <a href="<?php echo base_url('m/'.magaza($kullanici->kullanici_id)->magaza_seo) ?>" class="btn btn-primary settings-btn mb-3 w-100">Mağzaya Git</a>
                                                        </div>
                                                    <?php } ?>
                                                    <a href="<?php echo base_url('hesabim') ?>" title="" class="nav-link kpc-nav-btn active">Profilim</a>
                                                    <a href="<?php echo base_url('siparislerim') ?>" title="" class="nav-link kpc-nav-btn">Siparişlerim</a>
                                                    <a href="<?php echo base_url('satislar') ?>" title="" class="nav-link kpc-nav-btn">Gold Al - Sat</a>
                                                    <a href="<?php echo base_url('sorularim') ?>" title="" class="nav-link kpc-nav-btn">Sorularım</a>
                                                    <a href="<?php echo base_url('bakiye') ?>" title="" class="nav-link kpc-nav-btn">Bakiye</a>
                                                    <a href="<?php echo base_url('odeme-talep') ?>" title="" class="nav-link kpc-nav-btn">Bakiye Çekim</a>
                                                    <a href="<?php echo base_url('destek-taleplerim') ?>" title="" class="nav-link kpc-nav-btn">Destek Taleplerim</a>
                                                    <a href="<?php echo base_url('itirazlarim') ?>" title="" class="nav-link kpc-nav-btn">İtirazlarım</a>
                                                    <a href="<?php echo base_url('hesap-ayarlari') ?>" title="" class="nav-link kpc-nav-btn">Profil Ayarlarım</a>
                                                    <a class="nav-link kpc-nav-btn" href="<?php echo base_url('cikis') ?>">Çıkış</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-3 col-md-12 col-sm-12 md-none m-bg ">
                        <div class="k-panel-left-navbar-warper">
                            <div class="k-panel-left-navbar-area">
                                <div class="nav flex-column nav-pills bg-custom-none " id="v-pills-tab" role="tablist"
                                     aria-orientation="vertical">
                                   <?php if (magaza_check()) { ?>
                                        <div class="gt-store">
                                            <a href="<?php echo base_url('m/'.magaza($kullanici->kullanici_id)->magaza_seo) ?>" class="btn btn-primary settings-btn mb-3 w-100">Mağzaya Git</a>
                                        </div>
                                    <?php } ?>
                                    <a href="<?php echo base_url('hesabim') ?>" title="" class="nav-link kpc-nav-btn active">Profilim</a>
                                    <a href="<?php echo base_url('siparislerim') ?>" title="" class="nav-link kpc-nav-btn">Siparişlerim</a>
                                    <a href="<?php echo base_url('satislar') ?>" title="" class="nav-link kpc-nav-btn">Gold Al - Sat</a>
                                    <a href="<?php echo base_url('sorularim') ?>" title="" class="nav-link kpc-nav-btn">Sorularım</a>
                                    <a href="<?php echo base_url('bakiye') ?>" title="" class="nav-link kpc-nav-btn">Bakiye</a>
                                    <a href="<?php echo base_url('odeme-talep') ?>" title="" class="nav-link kpc-nav-btn">Bakiye Çekim</a>
                                    <a href="<?php echo base_url('destek-taleplerim') ?>" title="" class="nav-link kpc-nav-btn">Destek Taleplerim</a>
                                    <a href="<?php echo base_url('itirazlarim') ?>" title="" class="nav-link kpc-nav-btn">İtirazlarım</a>
                                    <a href="<?php echo base_url('hesap-ayarlari') ?>" title="" class="nav-link kpc-nav-btn">Profil Ayarlarım</a>
                                    <a class="nav-link kpc-nav-btn" href="<?php echo base_url('cikis') ?>">Çıkış</a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php if ($siparis->siparis_epin == 1) : ?>
                <div class="col-lg-9">
                    <div class="card">
                        <div class="card-body">
                            <div class="card-title">
                                <h4><?= $siparis->siparis_no ?> numaralı sipariş</h4>
                            </div>
                            <div class="card bg-light">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <img src="<?= base_url($siparis->urun_resim) ?>" class="thumbnail" alt="görsel" width="164" height="164">
                                        </div>
                                        <div class="col-md-9">
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <span><?= $siparis->urun_ad ?></span>
                                                    <span class="d-flex justify-content-end"><?= $siparis->siparis_tarih ?></span>
                                                </div>
                                                <div class="col-md-12">
                                                    <div class="input-group">
                                                        <div class="input-group-prepend">
                                                            <button class="input-group-text" id="sipariskeykopyalama" data-key="<?= $siparis->siparis_key ?>">
                                                                <i class="fa fa-paperclip"></i>
                                                            </button>
                                                        </div>
                                                        <input type="password" id="sipariskey" class="form-control" value="<?= $siparis->siparis_key ?>" readonly>
                                                        <div class="input-group-prepend">
                                                            <button class="input-group-text" id="sipariskeybuton">
                                                                <i class="fa fa-eye-slash"></i>
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                                <script>
                                                    $('#sipariskeybuton').click(function() {
                                                        var type = $('#sipariskey').attr('type') == "text" ? "password" : 'text',
                                                            c = $(this).children();
                                                        c.toggleClass("fa-eye-slash fa-eye");
                                                        $('#sipariskey').prop("type", type);
                                                    })

                                                    $('#sipariskeykopyalama').click(function() {
                                                        var textToCopy = $(this).data('key');
                                                        navigator.clipboard.writeText(textToCopy)
                                                            .then(function() {
                                                                Swal.fire({
                                                                    icon: 'success',
                                                                    title: 'Sipariş anahtarı kopyalandı',
                                                                    showConfirmButton: false,
                                                                    timer: 1500
                                                                })
                                                            })
                                                            .catch(function(err) {
                                                                console.error("Metin kopyalanamadı: ", err);
                                                            });
                                                    })
                                                </script>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php elseif ($siparis->siparis_epin == 2) : ?>
                <?php else : ?>
                <div class="col-lg-9 col-md-8 col-12">
                    <div class="k-panel-content-box">
                        <?php $teslimat_kontrol = teslimat_kontrol($siparis->siparis_no);
                        if (!$teslimat_kontrol) { ?>
                            <?php if ($siparis->siparis_durum == 1) { ?>
                                <div class="card mb-4">
                                    <div class="card-body">
                                        <form action="<?= base_url('siparis-teslimat-onay/' . $siparis->siparis_no) ?>" method="post">
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <div class="alert alert-warning text-center">
                                                        Sipariş teslimatınızda her hangi bir sorun yaşamadıysanız siparişinizi
                                                        onaylamanız gerekmektedir.
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label class="form-label">Teslimat Durumu</label>
                                                        <select class="form-control input-radius" id="teslimat_durum" name="teslimat_durumu" data-width="100%" required>
                                                            <option hidden>Teslimat Durumu Seçiniz..</option>
                                                            <option value="1">Teslimatı Onaylıyorum</option>
                                                            <option value="2">Teslimat Onaylamıyorum</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group" style="margin-top: 29px !important;">
                                                        <button class="btn btn-outline-success btn-block input-radius">Sipariş
                                                            Durumunu Güncelle
                                                        </button>
                                                    </div>
                                                </div>
                                                <div class="col-md-12 teslimat_onaysiz" style="display: none">
                                                    <div class="form-group">
                                                        <label class="form-label">Teslimat Onaylamama Nedeniniz?</label>
                                                        <textarea class="form-control teslimat_mesaj" name="mesaj" placeholder="Teslimat Onaylamama Nedeniniz?"></textarea>
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            <?php } ?>
                        <?php } else { ?>
                            <div class="card mb-3 p-0">
                                <div class="card-body account-area">
                                    <div class="row align-items-center">
                                        <div class="col-md-6">
                                            <div class="form-group m-0">
                                                <?php if ($teslimat_kontrol->teslimat_durum == 0) { ?>
                                                    <button type="button " class="btn btn-outline-warning btn-block rounded-pill">
                                                        Teslimat İtiraz Durumu Bekliyor..
                                                    </button>
                                                <?php } elseif ($teslimat_kontrol->teslimat_durum == 1) { ?>
                                                    <button type="button " class="btn btn-success btn-block rounded-pill">
                                                        <i class="fe fe-check-circle"></i> Teslimat İtirazı Çözüldü
                                                    </button>
                                                <?php } elseif ($teslimat_kontrol->teslimat_durum == 2) { ?>
                                                    <button type="button " class="btn btn-danger btn-block rounded-pill">
                                                        <i class="fe fe-x-circle"></i> Teslimat İtirazı Çözülemedi
                                                    </button>
                                                <?php } ?>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group m-0">
                                                <a href="<?= base_url('teslimat/' . $siparis->siparis_no) ?>" class="btn btn-primary btn-block input-radius">
                                                    <i class="fe fe-message-square"></i> İtiraz Detayı
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>

                        <div class="card mb-3 mb-4">
                            <div class="card-body account-area">
                            <div class="row no-gutters">
                                <div class="col-md-8">
                                    
                                    <div class="card-body">
                                        <h3 class="mb-2 text-truncate-line-2 ">
                                            <a target="_blank" href="<?= base_url($siparis->urun_seo) ?>" class="text-inherit"><?= $siparis->urun_ad ?></a>
                                        </h3>
                                        <!-- Row -->
                                        <div class="row align-items-center no-gutters">
                                            <div class="col-auto">
                                                <img src="<?= base_url($siparis->magaza_resim) ?>" class="rounded-circle avatar-xs" alt="<?= $siparis->urun_ad ?>">
                                            </div>
                                            <div class="col ml-2">
                                                <a target="_blank" href="<?= base_url('m/' . $siparis->magaza_seo) ?>"><?= $siparis->magaza_ad ?></a>
                                            </div>
                                        </div>
                                        <div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4 text-center">
                                    <div class="card-body">
                                        <span>Sipariş Tutarı</span>
                                        <div class="d-flex justify-content-center mt-2">
                                            <div class="font-size-27 font-weight-bold text-primary"><?= $siparis->siparis_tutar ?></div>
                                            <span class="h3 mb-0 font-weight-bold text-primary">₺</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            </div>
                            
                            <div class="card-body account-area">
                                <div class="row">
                                    <?php if ($siparis->teslim_alan != "") { ?>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="form-label">Alacak Kişi</label>
                                                <input class="form-control" type="text" value="<?= $siparis->teslim_alan ?>" disabled>
                                            </div>
                                        </div>
                                    <?php } ?>
                                    <?php if ($siparis->teslim_yeri != "") { ?>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="form-label">Alınacak Yer</label>
                                                <input class="form-control" type="text" value="<?= $siparis->teslim_yeri ?>" disabled>
                                            </div>
                                        </div>
                                    <?php } ?>

                                    <?php if ($siparis->siparis_durum == 1 || $siparis->siparis_durum == 2) { ?>
                                        <?php if ($siparis->urun_turu == 1) { ?>
                                            <?php if ($siparis->urun_marka) { ?>
                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <label class="form-label">Ürün Markası</label>
                                                        <input class="form-control" type="text" placeholder="Ürün Markası" value="<?= $siparis->urun_marka ?>" disabled>
                                                    </div>
                                                </div>
                                            <?php } ?>
                                        <?php } elseif ($siparis->urun_turu == 2) { ?>
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label class="form-label">Sanal Ürün Bilgisi</label>
                                                    <textarea class="form-control" type="text" placeholder="Sanal Ürün Bilgisi" disabled><?= $siparis->urun_sanal_bilgi ?></textarea>
                                                </div>
                                            </div>
                                        <?php } elseif ($siparis->urun_turu == 3) { ?>
                                            <div class="col-md-12 mb-3">
                                                <a href="<?= base_url('indir/' . $siparis->siparis_no) ?>" class="btn btn-success btn-block rounded-pill" data-toggle="tooltip" data-placement="top" title="İndir">
                                                    <i class="fe fe-download-cloud"></i> Dosyaları İndir
                                                </a>
                                            </div>
                                        <?php } ?>
                                    <?php } ?>
                                    <?php if ($siparis->siparis_durum == 2) { ?>
                                        <div class="col-md-12 mb-3">
                                            <a href="<?= base_url('fatura/' . $siparis->siparis_no) ?>" class="btn btn-secondary btn-block rounded-pill" data-toggle="tooltip" data-placement="top" title="Fatura">
                                                <i class="fe fe-file-text"></i> Fatura
                                            </a>
                                        </div>
                                    <?php } ?>
                                    <?php if ($siparis->siparis_durum == 3) { ?>
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label class="form-label">Sipariş İptal</label>
                                                <textarea class="form-control" type="text" placeholder="Sipariş No" disabled><?= $siparis->siparis_iptal ?></textarea>
                                            </div>
                                        </div>
                                    <?php } ?>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="form-label">Sipariş No</label>
                                            <input class="form-control" type="text" placeholder="Sipariş No" value="<?= $siparis->siparis_no ?>" disabled>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="form-label">Sipariş Tarihi</label>
                                            <input class="form-control" type="text" placeholder="Sipariş Tarihi" value="<?= date('d.m.Y H:m', strtotime($siparis->siparis_tarih)) ?>" disabled>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="form-label">Ad</label>
                                            <input class="form-control" type="text" placeholder="Ad" value="<?= $siparis->siparis_ad ?>" disabled>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="form-label">Soyad</label>
                                            <input class="form-control" type="text" placeholder="Soyad" value="<?= $siparis->siparis_soyad ?>" disabled>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label class="form-label">Telefon</label>
                                            <input class="form-control" type="text" placeholder="Telefon" value="<?= $siparis->siparis_tel ?>" disabled>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label class="form-label">Şehir</label>
                                            <input class="form-control" type="text" placeholder="Şehir" value="<?= sehir_ad($siparis->siparis_il) ?>" disabled>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label class="form-label">İlçe</label>
                                            <input class="form-control" type="text" placeholder="İlçe" value="<?= ilce_ad($siparis->siparis_ilce) ?>" disabled>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label class="form-label">Posta Kodu</label>
                                            <input class="form-control" type="text" placeholder="Posta Kodu" value="<?= $siparis->siparis_posta ?>" disabled>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label class="form-label">Adres</label>
                                            <textarea class="form-control" type="text" placeholder="Adres" disabled><?= $siparis->siparis_adres ?></textarea>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</main>