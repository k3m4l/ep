<section class="col-lg-8 control-panel">

<?php $this->load->view('kpanel/inc/kullanici_nav', array('kullanici' => $kullanici)); ?>

<div class="pb-5 py-md-5">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-4 col-12">
                
                <?php $this->load->view('kpanel/inc/menu'); ?>
            </div>
            <div class="col-lg-9 col-md-8 col-12">
                
                <a href="<?= base_url('talep-olustur') ?>" target="_blank"
                   class="btn btn-primary btn-block badge-pill d-block d-sm-none mb-3">
                    <i class="fe fe-plus"></i> Destek Talebi Oluştur
                </a>
                <div class="card mb-4">
                    
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <div>
                            <h3 class="mb-0">Destek Taleplerim</h3>
                            <span>Siparişleriniz veya farklı konular için destek talebi oluşturabilirsiniz.</span>
                        </div>
                        <div>
                            <a href="<?= base_url('talep-olustur') ?>" target="_blank"
                               class="btn btn-outline-primary badge-pill btn-sm d-none d-md-block">
                                <i class="fe fe-plus"></i> Destek Talebi Oluştur
                            </a>
                        </div>
                    </div>
                    
                    <div class="table-responsive border-0 overflow-y-hidden">
                        <table class="table mb-0 text-nowrap">
                            <thead>
                            <tr>
                                <th scope="col" class="border-0">Talep No</th>
                                <th scope="col" class="border-0">Talep Zaman</th>
                                <th scope="col" class="border-0">Talep Durum</th>
                                <th scope="col" class="border-0"></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php if ($destek) {
                                foreach ($destek as $key) { ?>
                                    <tr>
                                        <td class="border-top-0">#<?= $key->talep_no ?></td>
                                        <td class="border-top-0"><?= date('d.m.Y H:i', strtotime($key->talep_zaman)) ?></td>
                                        <td class="border-top-0">
                                            <?php if ($key->talep_durum == 0) { ?>
                                                <span class="badge badge-warning">Cevap Bekleniyor..</span>
                                            <?php } elseif ($key->talep_durum == 1) { ?>
                                                <span class="badge badge-success">Cevaplandı</span>
                                            <?php } elseif ($key->talep_durum == 2) { ?>
                                                <span class="badge badge-secondary">Kapatıldı</span>
                                            <?php } ?>
                                        </td>
                                        <td class="text-muted border-top-0">
                                            <a class="badge badge-primary badge-pill" href="<?=base_url('destek-detay/'.$key->talep_no)?>">Talep Detay</a>
                                        </td>
                                    </tr>
                                <?php }
                            } else { ?>
                                <tr>
                                    <td colspan="5" align="center">
                                        <div class="notification warning closeable">
                                            <p>Destek Talebi Bulunamadı!</p>
                                        </div>
                                    </td>
                                </tr>
                            <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</section>