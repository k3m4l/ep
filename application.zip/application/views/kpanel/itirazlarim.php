<main class="k-panel-warper">
    <div class="sec-warper mb-4">
        <div class="container normal-container p-0">
            <div class="k-panel-g-warper">
                <div class="row">
                    <div class="col-xl-3 col-lg-3 col-md-12 col-sm-12 wd-none mt-3 p-0 ">
                        <div class="accordion accordion-flush acc-kpc-menu" id="accordionFlushExample">
                            <div class="accordion-item acc-kpc-menu-item">
                                <h2 class="accordion-header acc-kpc-menu-header" id="flush-headingOne">
                                    <button class="accordion-button collapsed acc-kpc-menu-btn" type="button"
                                            data-bs-toggle="collapse" data-bs-target="#flush-collapseOne"
                                            aria-expanded="false" aria-controls="flush-collapseOne">
                                        Hızlı Menü
                                    </button>
                                </h2>
                                <div id="flush-collapseOne" class="accordion-collapse collapse"
                                     aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
                                    <div class="accordion-body acc-kpc-menu-body">
                                        <div class="k-panel-left-navbar-warper">
                                            <div class="k-panel-left-navbar-area">
                                                <div class="nav flex-column nav-pills bg-custom-none " id="v-pills-tab" role="tablist"
                                                    aria-orientation="vertical">
                                                <?php if (magaza_check()) { ?>
                                                        <div class="gt-store">
                                                            <a href="<?php echo base_url('m/'.magaza($kullanici->kullanici_id)->magaza_seo) ?>" class="btn btn-primary settings-btn mb-3 w-100">Mağzaya Git</a>
                                                        </div>
                                                    <?php } ?>
                                                    <a href="<?php echo base_url('hesabim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"> <img class="" src="<?php echo base_url('assets/front/images/') ?>" alt="" loading="lazy"> Profilim</a>
                                                    <a href="<?php echo base_url('siparislerim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100">Siparişlerim</a>
                                                    <a href="<?php echo base_url('satislar') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100">Gold Al - Sat</a>
                                                    <a href="<?php echo base_url('sorularim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100">Sorularım</a>
                                                    <a href="<?php echo base_url('bakiye') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100">Bakiye</a>
                                                    <a href="<?php echo base_url('odeme-talep') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100">Para Çek</a>
                                                    <a href="<?php echo base_url('destek-taleplerim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100">Destek Taleplerim</a>
                                                    <a href="<?php echo base_url('itirazlarim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100 active">İtirazlarım</a>
                                                    <a href="<?php echo base_url('hesap-ayarlari') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100">Profil Ayarlarım</a>
                                                    <a class="nav-link kpc-nav-btn w-spacial w-100" href="<?php echo base_url('cikis') ?>">Çıkış</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-3 col-md-12 col-sm-12 md-none pr-0">
                        <div class="k-panel-left-navbar-warper m-bg2">
                            <div class="k-panel-left-navbar-area">
                                <div class="nav flex-column nav-pills bg-custom-none " id="v-pills-tab" role="tablist"
                                     aria-orientation="vertical">
                                   <?php if (magaza_check()) { ?>
                                        <div class="gt-store">
                                            <a href="<?php echo base_url('m/'.magaza($kullanici->kullanici_id)->magaza_seo) ?>" class="btn btn-primary settings-btn mb-3 w-100">Mağzaya Git</a>
                                        </div>
                                    <?php } ?>
                                    <a href="<?php echo base_url('hesabim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"> <img class="sw-icon-item" src="<?php echo base_url('assets/front/images/uzer.webp') ?>" alt="" loading="lazy">Profilim</a>
                                    <a href="<?php echo base_url('siparislerim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"><img class="sw-icon-item" src="<?php echo base_url('assets/front/images/shopping-list.webp') ?>" alt="" loading="lazy">Siparişlerim</a>
                                    <a href="<?php echo base_url('satislar') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"><img class="sw-icon-item" src="<?php echo base_url('assets/front/images/gold.webp') ?>" alt="" loading="lazy">Gold Al - Sat</a>
                                    <a href="<?php echo base_url('sorularim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"><img class="sw-icon-item" src="<?php echo base_url('assets/front/images/s4.png') ?>" alt="" loading="lazy">Sorularım</a>
                                    <a href="<?php echo base_url('bakiye') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"><img class="sw-icon-item" src="<?php echo base_url('assets/front/images/salary.webp') ?>" alt="" loading="lazy">Bakiye</a>
                                    <a href="<?php echo base_url('odeme-talep') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"><img class="sw-icon-item" src="<?php echo base_url('assets/front/images/transfer.webp') ?>" alt="" loading="lazy">Para Çek</a>
                                                                       <a href="<?php echo base_url('destek-taleplerim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"><img class="sw-icon-item" src="<?php echo base_url('assets/front/images/customer-service.webp') ?>" alt="" loading="lazy">Destek Sistemi</a>
                                    <a href="<?php echo base_url('itirazlarim') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100 active"><img class="sw-icon-item" src="<?php echo base_url('assets/front/images/error.webp') ?>" alt="" loading="lazy">İtirazlarım</a>
                                    <a href="<?php echo base_url('hesap-ayarlari') ?>" title="" class="nav-link kpc-nav-btn w-spacial w-100"><img class="sw-icon-item" src="<?php echo base_url('assets/front/images/s1.png') ?>" alt="" loading="lazy">Profil Ayarlarım</a>
                                    <a class="nav-link kpc-nav-btn w-spacial w-100" href="<?php echo base_url('cikis') ?>"><img class="sw-icon-item" src="<?php echo base_url('assets/front/images/logout.webp') ?>" alt="" loading="lazy">Çıkış</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-9 col-lg-9 col-md-12 col-sm-12 m-bg m-br">
                        <div class="k-panel-content-right">
                            <div class="container-fluid">
                                <div class="k-panel-content-box">
                                    <div class="row">
                                        <div class="col-12">
                                            <div class="swt-area account-area">
                                                <div class="card mb-4">
                                                    <div class="table-responsive border-0">
                                                        <table class="table mb-0 text-nowrap dark-table light-table">
                                                            <thead>
                                                                <tr>
                                                                    <th class="brs-tb text-center">Sipariş No</th>
                                                                    <th class="brs-tb text-center">İlan</th>
                                                                    <th class="brs-tb text-center">Durum</th>
                                                                    <th class="brs-tb text-center">Tutar</th>
                                                                    <th class="brs-tb text-center">Tarih</th>
                                                                    <th class="brs-tb text-center">İşlemler</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <?php if ($itirazlarim) { foreach ($itirazlarim as $siparis) { ?>
                                                                <tr class="sw-table">
                                                                    <td class="align-middle border-top-0">
                                                                        <a data-toggle="tooltip" data-placement="top"
                                                                            title="İtiraz Detayı"
                                                                            href="<?= base_url('teslimat/' . $siparis->siparis_no) ?>">#<?= $siparis->siparis_no ?></a>
                                                                    </td>
                                                                    <td class="align-middle border-top-0">
                                                                        <?php echo $siparis->urun_ad ?>
                                                                    </td>
                                                                    <td class="align-middle border-top-0">
                                                                        <?php if ($siparis->teslimat_durum == 0) { ?>
                                                                        <a href="javascript:void(0)"
                                                                            class="badge badge-warning">İtiraz
                                                                            Beklemede</a>
                                                                        <?php } elseif ($siparis->teslimat_durum == 1) { ?>
                                                                        <a href="javascript:void(0)"
                                                                            class="badge badge-success">İtiraz
                                                                            Çözüldü</a>
                                                                        <?php } elseif ($siparis->teslimat_durum == 2) { ?>
                                                                        <span class="badge badge-danger">İtiraz
                                                                            Çözülemedi</span>
                                                                        <?php } elseif ($siparis->teslimat_durum == 3) { ?>
                                                                        <span class="badge badge-info">İtiraz Cevap
                                                                            Verildi</span>
                                                                        <?php } ?>
                                                                    </td>
                                                                    <td class="align-middle border-top-0">
                                                                        <?= $siparis->siparis_tutar ?>₺</td>
                                                                    <td class="align-middle border-top-0">
                                                                        <?= date('d.m.Y H:m', strtotime($siparis->siparis_tarih)) ?>
                                                                    </td>
                                                                    <td class="align-middle border-top-0">
                                                                        <a href="<?= base_url('teslimat/' . $siparis->siparis_no) ?>"
                                                                            class="btn btn-primary btn-sm"
                                                                            data-toggle="tooltip" data-placement="top"
                                                                            title="İtiraz Detay">
                                                                            <i class="fe fe-eye"></i>
                                                                        </a>
                                                                        <?php if ($siparis->siparis_durum == 2) { ?>
                                                                        <a href="<?= base_url('fatura/' . $siparis->siparis_no) ?>"
                                                                            class="btn btn-secondary btn-sm"
                                                                            data-toggle="tooltip" data-placement="top"
                                                                            title="Fatura">
                                                                            <i class="fe fe-file-text"></i>
                                                                        </a>
                                                                        <?php } ?>
                                                                    </td>
                                                                </tr>
                                                                <?php }
                                                                      } else { ?>
                                                                <tr>
                                                                    <td colspan="6" align="center" class="br-0"> 
                                                                        <div class="notification warning closeable">
                                                                            <p>İtiraz Bulunamadı</p>
                                                                        </div>
                                                                    </td>
                                                                </tr>
                                                                <?php } ?>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>















<?php if (1 == 2) { ?>
<!--
<section class="col-lg-8 account-billing-cart-area">
    <div class="billing">
        <div class="row">

            <div class="col-md-4">
                <div class="bg-info rounded overflow-hidden">
                    <div class="pd-x-20 pd-t-20 d-flex align-items-center">
                        <i class="fas fa-star tx-60 tx-white op-7"></i>
                        <div class="mg-l-20">
                            <p class="tx-15 tx-spacing-1 tx-mont tx-semibold tx-uppercase tx-white-8 mg-b-10">Hesap Bakiyesi</p>
                            <p class="tx-24 tx-white tx-lato tx-bold mg-b-0 lh-1"><?= $kullanici->bakiye ?> ₺</p>
                        </div>
                    </div>
                    <div id="ch1" class="ht-50 tr-y-1 rickshaw_graph">
                        <img src="<?php echo base_url('assets/images/cart_img.svg') ?>" alt="">
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="bg-purple rounded overflow-hidden">
                    <div class="pd-x-20 pd-t-20 d-flex align-items-center">
                        <i class="fas fa-store tx-60 tx-white op-7"></i>
                        <div class="mg-l-20">
                            <p class="tx-15 tx-spacing-1 tx-mont tx-semibold tx-uppercase tx-white-8 mg-b-10">Destek Taleplerim</p>
                            <p class="tx-24 tx-white tx-lato tx-bold mg-b-0 lh-1">0</p>
                        </div>
                    </div>
                    <div id="ch1" class="ht-50 tr-y-1 rickshaw_graph">
                        <img src="<?php echo base_url('assets/images/cart_img.svg') ?>" alt="">
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="bg-warning rounded overflow-hidden">
                    <div class="pd-x-20 pd-t-20 d-flex align-items-center">
                        <i class="fas fa-coins tx-60 tx-white op-7"></i>
                        <div class="mg-l-20">
                            <p class="tx-15 tx-spacing-1 tx-mont tx-semibold tx-uppercase tx-white-8 mg-b-10">Siparişlerim</p>
                            <p class="tx-24 tx-white tx-lato tx-bold mg-b-0 lh-1"><?= $siparis_say; ?></p>
                        </div>
                    </div>
                    <div id="ch1" class="ht-50 tr-y-1 rickshaw_graph">
                        <img src="<?php echo base_url('assets/images/cart_img.svg') ?>" alt="">
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="col-lg-8 control-panel">
    <div class="account-area">
     Content 
        <div class="container-fluid">

            <div class="row">
                <div class="col-lg-3 col-md-4 col-12 p-0">
                    <div class="user-img-left-area">
                        <img src="<?= base_url($kullanici->kullanici_resim) ?>" alt=""/>
                        <div>
                            <?= $kullanici->kullanici_ad ?>
                        </div>
                    </div>
              
                    <?php $this->load->view('kpanel/inc/menu'); ?>
                </div>

                <div class="col-lg-9 col-md-8 col-12 pr-0">
                    <h2 class="title">İtirazlarım</h2>
                    <div class="card mb-4">
             
                        <div class="card-header border-bottom-0">
                            <h3 class="h4 mb-3">Sipariş İtirazlarım</h3>
                        </div>
                   
                        <div class="table-responsive border-0">
                            <table class="table mb-0 text-nowrap dark-table light-table">
                                <thead>
                                <tr>
                                    <th class="border-0 text-center">Sipariş No</th>
                                    <th class="border-0 text-center">İlan</th>
                                    <th class="border-0 text-center">Durum</th>
                                    <th class="border-0 text-center">Tutar</th>
                                    <th class="border-0 text-center">Tarih</th>
                                    <th class="border-0 text-center">İşlemler</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php if ($itirazlarim) {
                                    foreach ($itirazlarim as $siparis) { ?>
                                        <tr>
                                            <td class="align-middle border-top-0">
                                                <a data-toggle="tooltip" data-placement="top" title="İtiraz Detayı"
                                                   href="<?= base_url('teslimat/' . $siparis->siparis_no) ?>">#<?= $siparis->siparis_no ?></a>
                                            </td>
                                            <td class="align-middle border-top-0">
                                                <?php echo $siparis->urun_ad ?>
                                            </td>
                                            <td class="align-middle border-top-0">
                                                <?php if ($siparis->teslimat_durum == 0) { ?>
                                                    <a href="javascript:void(0)"
                                                       class="badge badge-warning">İtiraz Beklemede</a>
                                                <?php } elseif ($siparis->teslimat_durum == 1) { ?>
                                                    <a href="javascript:void(0)"
                                                       class="badge badge-success">İtiraz Çözüldü</a>
                                                <?php } elseif ($siparis->teslimat_durum == 2) { ?>
                                                    <span class="badge badge-danger">İtiraz Çözülemedi</span>
                                                <?php } elseif ($siparis->teslimat_durum == 3) { ?>
                                                    <span class="badge badge-info">İtiraz Cevap Verildi</span>
                                                <?php } ?>
                                            </td>
                                            <td class="align-middle border-top-0"><?= $siparis->siparis_tutar ?>₺</td>
                                            <td class="align-middle border-top-0"><?= date('d.m.Y H:m', strtotime($siparis->siparis_tarih)) ?></td>
                                            <td class="align-middle border-top-0">
                                                <a href="<?= base_url('teslimat/' . $siparis->siparis_no) ?>"
                                                   class="btn btn-primary btn-sm" data-toggle="tooltip"
                                                   data-placement="top" title="İtiraz Detay">
                                                    <i class="fe fe-eye"></i>
                                                </a>
                                                <?php if ($siparis->siparis_durum == 2) { ?>
                                                    <a href="<?= base_url('fatura/' . $siparis->siparis_no) ?>"
                                                       class="btn btn-secondary btn-sm" data-toggle="tooltip"
                                                       data-placement="top" title="Fatura">
                                                        <i class="fe fe-file-text"></i>
                                                    </a>
                                                <?php } ?>
                                            </td>
                                        </tr>
                                    <?php }
                                } else { ?>
                                    <tr>
                                        <td colspan="6" align="center">
                                            <div class="notification warning closeable"><p>İtiraz Bulunamadı</p></div>
                                        </td>
                                    </tr>
                                <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
-->                <?php } ?>