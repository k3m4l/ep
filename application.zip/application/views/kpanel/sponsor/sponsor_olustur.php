<!-- Page header-->
<div class="py-4 py-lg-6 bg-primary">
    <div class="container">
        <div class="row">
            <div class="offset-lg-1 col-lg-10 col-md-12 col-12">
                <div class="d-lg-flex align-items-center justify-content-between">
                    
                    <div class="mb-4 mb-lg-0">
                        <h1 class="text-white mb-1">Sponsor Başvurusu Yap</h1>
                        <p class="mb-0 text-white lead">
                            Bireysel olarak sponsor başvurusu yapabilirsiniz.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Page Content -->
<div class="pb-12">
    <div class="container">
        <div class="bs-stepper">
            <div class="row">
                <div class="offset-lg-1 col-lg-10 col-md-12 col-12">
                    <div class="bs-stepper-content mt-5">



                        <?php if ($kullanici->kullanici_tel == "") { ?>
                            <div class="alert alert-danger">İşleme devam edebilmek için hesabınızdan telefon numaranızı kaydetmiş olmalısınız.</div>
                        <?php } elseif ($kullanici->kullanici_tel != "" && !isset($_SESSION["sponsordog"])) {

                            if (
                                !isset($_SESSION["sponsorsms"])
                                ||
                                (isset($_SESSION["sponsorsmstime"]) && $_SESSION["sponsorsmstime"] + 120 < time())
                            ) {

                                $_SESSION["sponsorsms"] = substr(number_format(time() * rand(), 0, '', ''), 0, 6);
                                $_SESSION["sponsorsmstime"] = time();

                                $ayarlar = ayarlar();
                                $username = $ayarlar->netgsm_user;
                                $pass = $ayarlar->netgsm_pass;
                                $header = $ayarlar->netgsm_header;

                                $startdate = date('d.m.Y H:i');
                                $startdate = str_replace('.', '', $startdate);
                                $startdate = str_replace(':', '', $startdate);
                                $startdate = str_replace(' ', '', $startdate);

                                $stopdate = date('d.m.Y H:i', strtotime('+1 day'));
                                $stopdate = str_replace('.', '', $stopdate);
                                $stopdate = str_replace(':', '', $stopdate);
                                $stopdate = str_replace(' ', '', $stopdate);


                                $msg = html_entity_decode("Herseyoyun.com sponsor başvurusu yapmak için doğrulama kodunuz: " . $_SESSION["sponsorsms"], ENT_COMPAT, "UTF-8");
                                //$msg = rawurlencode($msg);


                                $gonderici = html_entity_decode($header, ENT_COMPAT, "UTF-8");
                                $gonderici = rawurlencode($gonderici);

                                $curl = curl_init();


                                curl_setopt_array($curl, array(
                                    CURLOPT_URL => 'https://api.netgsm.com.tr/sms/send/get',
                                    CURLOPT_RETURNTRANSFER => true,
                                    CURLOPT_ENCODING => '',
                                    CURLOPT_MAXREDIRS => 10,
                                    CURLOPT_TIMEOUT => 0,
                                    CURLOPT_FOLLOWLOCATION => true,
                                    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                                    CURLOPT_CUSTOMREQUEST => 'POST',
                                    CURLOPT_POSTFIELDS => array('usercode' => $username, 'password' => $pass, 'gsmno' => $kullanici->kullanici_tel, 'message' => $msg, 'msgheader' => $gonderici, 'filter' => '0', 'startdate' => $startdate, 'stopdate' => $stopdate, 'dil' => 'TR'),
                                ));

                                $response = curl_exec($curl);
                                curl_close($curl);
                                // print_r($response);

                            }

                            if (@$_POST["kod"] != null) {

                                if (@$_POST["kod"] == $_SESSION["sponsorsms"]) {
                                    $_SESSION["sponsordog"] = "1";
                                    header("Refresh:0");
                                    exit;
                                } else {
                                    echo '<div class="alert alert-danger">Doğrulama kodu hatalı girildi.</div>';
                                }
                            }

                        ?>

                            <div class="alert alert-info">
                                <?php echo $kullanici->kullanici_tel; ?> numaranıza gönderilmiştir.
                                <br>
                                Telefonunuza gönderilen doğrulama kodunu giriniz.
                            </div>
                            <form method="post">

                                <div class="card mb-3 ">
                                    <div class="card-header border-bottom px-4 py-3">
                                        <h4 class="mb-0">İşlem Doğrulama</h4>
                                    </div>
                                    
                                    <div class="card-body">
                                        <div class="form-group">
                                            <label class="form-label">Doğrulama Kodu</label>
                                            <input class="form-control input-radius" type="number" name="kod" />
                                        </div>

                                    </div>

                                    <button type="submit" class="btn btn-primary btn-block badge-pill ">Doğrula
                                    </button>
                            </form>
                        <?php } else { ?>

                            <form class="sponsor_form" method="post">
                                
                                <div class="alert alert-secondary mb-4 text-center input-radius">
                                    Başvurular için <b>TC Kimlik</b> doğrulama işlemi yapılmaktadır. Dolandırıcılığın
                                    önüne geçmek için uygulanan bir güvenlik tedbiridir.
                                </div>
                                <div class="card mb-3 ">
                                    <div class="card-header border-bottom px-4 py-3">
                                        <h4 class="mb-0">Sponsor & Kişisel Bilgiler</h4>
                                    </div>
                                    
                                    <div class="card-body">

                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="form-label">Adınız</label>
                                                    <input class="form-control input-radius" name="spo_ad" type="text" placeholder="Adınız.." />
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="form-label">Soyadınız</label>
                                                    <input class="form-control input-radius" name="spo_soyad" type="text" placeholder="Soyadınız.." />
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="form-label">TC Kimlik Numarası</label>
                                                    <input class="form-control input-radius" name="spo_tc" type="number" onKeyPress="if(this.value.length==11) return false;" min="0" placeholder="TC Kimlik Numarası" />
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="form-label">Doğum Yılı <small>(Örn: 1998)</small></label>
                                                    <input class="form-control input-radius" name="spo_dogum_tarihi" type="number" onKeyPress="if(this.value.length==4) return false;" min="0" placeholder="Doğum Yılı (4 rakam)" />
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <p class="font-size-11 text-left">Kimlik doğrulama işlemi <b>T.C. İçişleri
                                                        Bakanlığı Nüfus ve
                                                        Vatandaşlık İşleri Genel Müdürlüğü</b> Servis Alt Yapısı Sayesinde
                                                    Yapılmaktadır.</p>
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="form-label">Şehir</label>
                                                    <select id="ilsec" name="sehir" class="form-control input-radius" data-width="100%" required>
                                                        <option value="">Lütfen Seçiniz...</option>
                                                        <?php if ($iller) {
                                                            foreach ($iller as $il) { ?>
                                                                <option value="<?= $il->id ?>"><?= $il->il_adi ?></option>
                                                        <?php }
                                                        } ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label class="form-label">İlçe</label>
                                                    <select id="ilcesec" name="ilce" class="form-control input-radius" data-width="100%" required>
                                                        <option>Lütfen Şehir Seçiniz..</option>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="col-md-12 mt-4 mb-4">

                                                <div class="form-group">
                                                    <label class="form-label">
                                                        Sponsor Olmak İstediğiniz Kategorileri Seçiniz
                                                        <br>
                                                        <small>(çoklu seçim yapılabilir)</small>
                                                    </label>
                                                    <select class="form-control kats" name="kategoriler[]" multiple id="mult-cat" required>
                                                        <?php if ($kategoriler) {
                                                            foreach ($kategoriler as $kategori) {
                                                                $alt_kategoriler = alt_kategoriler($kategori->kategori_id); ?>
                                                                <optgroup label="<?= $kategori->kategori_ad ?>">
                                                                    <?php if ($alt_kategoriler) {
                                                                        foreach ($alt_kategoriler as $alt_kategori) { ?>
                                                                            <option value="<?= $alt_kategori->kategori_id ?>"><?= $alt_kategori->kategori_ad ?></option>
                                                                    <?php }
                                                                    } ?>
                                                                </optgroup>
                                                        <?php
                                                            }
                                                        }
                                                        ?>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- <div class="form-group">
                                            <label class="form-label">Mağazanızda ne satacaksınız?</label>
                                            <textarea class="form-control input-radius" name="magaza_bilgi" rows="5" placeholder="Mağaza Hakkında Bilgi Verin.."></textarea>
                                        </div> -->
                                        <a href="<?= $ayarlar->gizlilik_politikasi; ?>">Başvuru Sözleşmesini</a> okudum, anladım kabul ediyorum.
                                    </div>
                                </div>

                                <!-- Button -->
                                <button type="submit" class="btn btn-primary btn-block badge-pill sponsor_olustur" id="sponsor_btn">
                                    Sponsor Başvurusunu Gönder
                                </button>
                            </form>
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    $('.sponsor_form').submit(function (event) {
        event.preventDefault();

        document.getElementById("sponsor_btn").innerHTML = '<span class="spinner-border spinner-border-sm mr-2" role="status" aria-hidden="true"></span><span class="saving">Sponsor Başvurusu Yapılıyor<span>.</span><span>.</span><span>.</span></span>';
        document.getElementById("sponsor_btn").disabled = true;

        var formData = {
            'spo_ad': $('input[name=spo_ad]').val(),
            'spo_soyad': $('input[name=spo_soyad]').val(),
            'spo_tc': $('input[name=spo_tc]').val(),
            'spo_dogum_tarihi': $('input[name=spo_dogum_tarihi]').val(),
            'sehir': $('select[name=sehir]').val(),
            'ilce': $('select[name=ilce]').val(),
            'kategoriler': $('.kats').val()
        };

        $.ajax({
            type: 'POST',
            url: base_url + 'ajax_controller/sponsor_olustur',
            data: formData,
            dataType: 'json',
            encode: true
        }).done(function (data) {

            if (data.durum == 'success') {
                iziToast.success({
                    title: 'Başarılı!',
                    message: data.s_baslik,
                    position: 'topRight',
                });
                document.getElementById("sponsor_btn").innerHTML = 'Sponsor Oluştur';
                document.getElementById("sponsor_btn").disabled = false;
            }

            if (data.durum == 'error') {
                iziToast.error({
                    title: 'Hata!',
                    message: data.s_baslik,
                    position: 'topRight',
                });
                document.getElementById("sponsor_btn").innerHTML = 'Sponsor Oluştur';
                document.getElementById("sponsor_btn").disabled = false;
            }

            if (data.redirect == true) {
                setTimeout(function () {
                    window.location.href = base_url + data.redirect_url;
                }, 2500);
            }


        });
    });
</script>