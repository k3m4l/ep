<?php $kullanici = aktif_kullanici(); ?>
<?php $firmayorumlari = firmayorumlari($kullanici->kullanici_id); ?>
<div id="dashboard">

	<!-- Navigation
	================================================== -->

	<!-- Responsive Navigation Trigger -->
	<a href="#" class="dashboard-responsive-nav-trigger"><i class="fa fa-reorder"></i> Navigation</a>

	<?php $this->load->view("kpanel/inc/menu"); ?>
	<!-- Navigation / End -->


	<div class="dashboard-content">

		<!-- Titlebar -->
		<div id="titlebar">
			<div class="row">
				<div class="col-md-12">
					<h2>Yorumlar</h2>
					<!-- Breadcrumbs -->
					<nav id="breadcrumbs">
						<ul>
							<li><a href="<?=base_url()?>">Anasayfa</a></li>
							<li><a href="<?=base_url("kullanici-paneli")?>">Kullanıcı Paneli</a></li>
							<li>Yorumlar</li>
						</ul>
					</nav>
				</div>
			</div>
		</div>

		<div class="row">
			
			<!-- Listings -->
			<div class="col-lg-12 col-md-12">

				<div class="dashboard-list-box margin-top-0">

					<h4>Firmanıza Yapılan Yorumlar</h4> 

					<ul>
						<?php if ($firmayorumlari) { ?>
						<?php foreach ($firmayorumlari as $key) { ?>
							<li>
								<div class="comments listing-reviews">
									<ul>
										<li>
											<div class="avatar"><img src="<?=base_url().$key->kullanici_resim?>" alt="<?=$key->kullanici_isim." ".$key->kullanici_soyisim?>" /></div>
											<div class="comment-content"><div class="arrow-comment"></div>
												<div class="comment-by"><?=$key->kullanici_isim." ".$key->kullanici_soyisim?> <div class="comment-by-listing">- <a href="<?=base_url("firma/").$key->firma_seo?>"><?=$key->firma_ad?> </a>
												</div> <span class="date"><?=zamanCevir($key->yorum_zaman)?></span>
													<div class="star-rating" data-rating="<?=$key->yorum_puan?>"></div>
												</div>
												<p><?=$key->yorum_detay?></p>
												<?php if ($key->yorum_durum==0) { ?>
													<div class="notification warning closeable text-center">
														<p><span>Yorum Yönetim Tarafından Onay Beklemektedir</span></p>
													</div>
												<?php } ?>
											</div>
										</li>
									</ul>
								</div>
							</li>
						<?php } ?>
						<?php } ?>
					</ul>
				</div>


			</div>

			<?php $this->load->view("kpanel/inc/footer"); ?>

		</div>

	</div>


</div>
<!-- Dashboard / End -->


</div>