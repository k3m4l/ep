<section class="col-lg-8 control-panel">
    <div class="account-area">

        <?php $this->load->view('kpanel/inc/kullanici_nav', array('kullanici' => $kullanici)); ?>
        
        <div class="pb-5 py-md-5">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-md-4 col-12">
                        <div class="user-img-left-area">
                            <img src="<?= base_url($kullanici->kullanici_resim) ?>" alt=""/>
                            <div>
                                <?= $kullanici->kullanici_ad ?>
                            </div>
                        </div>
                        
                        <?php $this->load->view('kpanel/inc/menu'); ?>
                    </div>
                    <div class="col-lg-9 col-md-8 col-12">
                        <div class="card mb-4">
                            
                            <div class="card-header border-bottom-0">
                                <h3 class="h4 mb-3">Satışlarım</h3>
                            </div>
                            
                            <div class="my-sales-tabs">
                                <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                                    <li class="nav-item" role="presentation">
                                        <button class="nav-link active" id="pills-waiting-tab" data-bs-toggle="pill"
                                                data-bs-target="#pills-waiting" type="button" role="tab"
                                                aria-controls="pills-waiting" aria-selected="true">Bekleyen
                                        </button>
                                    </li>
                                    <li class="nav-item" role="presentation">
                                        <button class="nav-link" id="pills-complate-tab" data-bs-toggle="pill"
                                                data-bs-target="#pills-complate" type="button" role="tab"
                                                aria-controls="pills-complate" aria-selected="false">Tamamlanan
                                        </button>
                                    </li>
                                    <li class="nav-item" role="presentation">
                                        <button class="nav-link" id="pills-cancel-tab" data-bs-toggle="pill"
                                                data-bs-target="#pills-cancel" type="button" role="tab"
                                                aria-controls="pills-cancel" aria-selected="false">İptal Edilenler
                                        </button>
                                    </li>
                                </ul>
                                <div class="tab-content" id="pills-tabContent">
                                    <div class="tab-pane fade show active" id="pills-waiting" role="tabpanel"
                                         aria-labelledby="pills-waiting-tab">
                                        <?php if (!empty($bekleyen_satislarim)) { ?>
                                            <?php foreach ($bekleyen_satislarim as $key => $val) { ?>
                                                <div class="sales-box-warper">
                                                    <div class="sale-cards border-n">
                                                        <div class="sale-container">
                                                            <div class="sale-card">
                                                                <div class="product-detail">
                                                                    <div class="sale-img">
                                                                        <a href="javascript:void(0)">
                                                                            <img src="<?php echo base_url($val->urun_resim_min) ?>">
                                                                        </a>
                                                                    </div>
                                                                    <div class="product-info">
                                                                        <div class="p-name">
                                                                            <a href="javascript:void(0)"><?php echo $val->urun_ad ?></a>
                                                                        </div>
                                                                        <div class="p-price">
                                                                            Fiyat:
                                                                            <span><?php echo $val->urun_alimfiyat ?> TL</span>
                                                                        </div>
                                                                        <div class="p-price">
                                                                            Toplam Kazanç:
                                                                            <span><?php echo $val->price ?> TL</span>
                                                                        </div>
                                                                        <div class="p-quantity">
                                                                            Adet:
                                                                            <span><?php echo $val->quantity ?></span>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="sale-status status-0"><i
                                                                            class="fa-solid fa-gauge-high"></i> Teslimat
                                                                    bekliyor
                                                                    <button
                                                                            class="btn btn-primary btn-sm sale-detail-button align-self-end"
                                                                            data-bs-toggle="modal"
                                                                            data-bs-target="#info-modal-<?php echo $val->id ?>">
                                                                        İletilen Bilgiler
                                                                    </button>
                                                                </div>
                                                                <div class="sale-info">
                                                                    <div class="s-date">
                                                                        <i class="fa-regular fa-clock"></i> <?php echo $val->added_time ?>
                                                                    </div>
                                                                    <div class="s-delivery">
                                                                        Satıcı: <a class="p-seller"
                                                                                   href=""><?php echo $val->kullanici_ad ?></a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="sale-alerts">
                                                                <div>
                                                                    <?php echo $val->urun_alimbaslik ?>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="modal fade" id="info-modal-<?php echo $val->id ?>"
                                                     tabindex="-1"
                                                     aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                    <div class="modal-dialog">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <button type="button" class="btn-close"
                                                                        data-bs-dismiss="modal"
                                                                        aria-label="Close"></button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <div class="detail-data-rows">
                                                                    <div class="detail-data-row">
                                                                        <span class="detail-data-name">
                                                                            Oyundaki Karakter Adınız :
                                                                        </span>
                                                                        <span class="detail-data-val">
                                                                            <?php echo $val->character_name ?>
                                                                        </span>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="modal-footer boder-0">
                                                                <button type="button" class="btn btn-secondary"
                                                                        data-bs-dismiss="modal">Kapat
                                                                </button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php } ?>
                                        <?php } else { ?>
                                            <div class="sale-cards border-n"><h4 class="inside-warning"> Herhangi bir geçmiş
                                                    satışınız bulunmuyor.</h4></div>
                                        <?php } ?>
                                    </div>
                                    <div class="tab-pane fade" id="pills-complate" role="tabpanel"
                                         aria-labelledby="pills-complate-tab">
                                        <?php if (!empty($tamamlanan_satislarim)) { ?>
                                            <?php foreach ($tamamlanan_satislarim as $key => $val) { ?>
                                                <div class="sale-cards border-n">
                                                    <div class="sale-container">
                                                        <div class="sale-card">
                                                            <div class="product-detail">
                                                                <div class="sale-img">
                                                                    <a href="javascript:void(0)">
                                                                        <img src="<?php echo base_url($val->urun_resim_min) ?>">
                                                                    </a>
                                                                </div>
                                                                <div class="product-info">
                                                                    <div class="p-name">
                                                                        <a href="javascript:void(0)"><?php echo $val->urun_ad ?></a>
                                                                    </div>
                                                                    <div class="p-price">
                                                                        Fiyat: <span><?php echo $val->urun_alimfiyat ?> TL</span>
                                                                    </div>
                                                                    <div class="p-price">
                                                                        Toplam Kazanç: <span><?php echo $val->price ?> TL</span>
                                                                    </div>
                                                                    <div class="p-quantity">
                                                                        Adet: <span><?php echo $val->quantity ?></span>
                                                                    </div>
                                                                </div>
                                                            </div>

                                                            <div class="sale-info">
                                                                <div class="s-date">
                                                                    <i class="fa-regular fa-clock"></i> <?php echo $val->added_time ?>
                                                                </div>
                                                                <div class="s-delivery">
                                                                    Teslimat Tarihi:
                                                                    <span><?php echo $val->delivery_date ?></span>
                                                                </div>
                                                                <div class="s-delivery">
                                                                    Satıcı: <a class="p-seller"
                                                                               href=""><?php echo $val->kullanici_ad ?></a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="sale-status-g">
                                                            <div class="sale-status status-1"><i
                                                                        class="fa-solid fa-circle-check"></i> Teslim
                                                                edildi
                                                            </div>
                                                            <div class="s-name">
                                                                Teslim edilecek karakter adı: <span>*******</span>
                                                            </div>
                                                            <button
                                                                    class="btn btn-primary btn-sm sale-detail-button align-self-end"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#info-comp-modal-<?php echo $val->id ?>">
                                                                İletilen Bilgiler
                                                            </button>

                                                        </div>
                                                    </div>
                                                    <div class="sale-alerts">
                                                        <div>
                                                            <?php echo $val->urun_alimbaslik ?>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="modal fade" id="info-comp-modal-<?php echo $val->id ?>"
                                                     tabindex="-1"
                                                     aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                    <div class="modal-dialog">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <button type="button" class="btn-close"
                                                                        data-bs-dismiss="modal"
                                                                        aria-label="Close"></button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <div class="detail-data-rows">
                                                                    <div class="detail-data-row">
                                                                        <span class="detail-data-name">
                                                                            Oyundaki Karakter Adınız :
                                                                        </span>
                                                                        <span class="detail-data-val">
                                                                            <?php echo $val->character_name ?>
                                                                        </span>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="modal-footer boder-0">
                                                                <button type="button" class="btn btn-secondary"
                                                                        data-bs-dismiss="modal">Kapat
                                                                </button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php } ?>
                                        <?php } else { ?>
                                            <div class="sale-cards border-n"><h4 class="inside-warning"><i
                                                            class="fad fa-engine-warning"></i> Herhangi bir geçmiş
                                                    satışınız bulunmuyor.</h4></div>
                                        <?php } ?>
                                    </div>
                                    <div class="tab-pane fade" id="pills-cancel" role="tabpanel"
                                         aria-labelledby="pills-cancel-tab">
                                        <?php if (!empty($iptal_edilen_satislarim)) { ?>
                                            <?php foreach ($iptal_edilen_satislarim as $key => $val) { ?>
                                                <div class="sale-cards border-n">
                                                    <div class="sale-container">
                                                        <div class="sale-card">
                                                            <div class="product-detail">
                                                                <div class="sale-img">
                                                                    <a href="javascript:void(0)">
                                                                        <img src="<?php echo base_url($val->urun_resim_min) ?>">
                                                                    </a>
                                                                </div>
                                                                <div class="product-info">
                                                                    <div class="p-name">
                                                                        <a href="javascript:void(0)">
                                                                            <?php echo $val->urun_ad ?>
                                                                        </a>
                                                                    </div>
                                                                    <div class="p-price">
                                                                        Fiyat: <span><?php echo $val->urun_alimfiyat ?> TL</span>
                                                                    </div>
                                                                    <div class="p-price">
                                                                        Toplam Kazanç: <span><?php echo $val->price ?> TL</span>
                                                                    </div>
                                                                    <div class="p-quantity">
                                                                        Adet: <span><?php echo $val->quantity ?></span>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="sale-status status-2"><i class="fa-solid fa-ban"></i> İptal edildi
                                                                <button class="btn btn-primary btn-sm sale-detail-button align-self-end mt-3"
                                                                        data-bs-toggle="modal"
                                                                        data-bs-target="#info-cancel-modal-<?php echo $val->id ?>">
                                                                    İletilen Bilgiler
                                                                </button>
                                                            </div>
                                                            <div class="sale-info">
                                                                <div class="s-date">
                                                                    <i class="fad fa-clock"></i> <?php echo $val->added_time ?>
                                                                </div>
                                                                <div class="s-delivery">
                                                                    Satıcı: <a class="p-seller" href="javascript:void(0)"><?php echo $val->kullanici_ad ?></a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="sale-alerts red">Satışınız iptal edilmiştir.
                                                            <?php echo $val->reason_for_cancellation ?>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="modal fade" id="info-cancel-modal-<?php echo $val->id ?>"
                                                     tabindex="-1"
                                                     aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                    <div class="modal-dialog">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <button type="button" class="btn-close"
                                                                        data-bs-dismiss="modal"
                                                                        aria-label="Close"></button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <div class="detail-data-rows">
                                                                    <div class="detail-data-row">
                                                                        <span class="detail-data-name">
                                                                            Oyundaki Karakter Adınız :
                                                                        </span>
                                                                        <span class="detail-data-val">
                                                                            <?php echo $val->character_name ?>
                                                                        </span>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="modal-footer boder-0">
                                                                <button type="button" class="btn btn-secondary"
                                                                        data-bs-dismiss="modal">Kapat
                                                                </button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php } ?>
                                        <?php } else { ?>
                                            <div class="sale-cards border-n "><h4 class="inside-warning"><i
                                                            class="fad fa-engine-warning"></i> Herhangi bir geçmiş
                                                    satışınız bulunmuyor.</h4></div>
                                        <?php } ?>
                                    </div>
                                </div>
                            </div>
                            <div class="card-header border-bottom-0">
                                <h3 class="h4 mb-3">Satın Aldıklarım</h3>
                            </div>
                            <div class="getgold-area">
                                <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                                    <li class="nav-item" role="presentation">
                                        <button class="nav-link active" id="pills-waiting-5-tab" data-bs-toggle="pill" data-bs-target="#pills-waiting-5" type="button" role="tab" aria-controls="pills-waiting-5" aria-selected="true">Bekleyen</button>
                                    </li>
                                    <li class="nav-item" role="presentation">
                                        <button class="nav-link" id="pills-complate-5-tab" data-bs-toggle="pill" data-bs-target="#pills-complate-5" type="button" role="tab" aria-controls="pills-complate-5" aria-selected="false">Teslim Edilen</button>
                                    </li>
                                    <li class="nav-item" role="presentation">
                                        <button class="nav-link" id="pills-canseled-5-tab" data-bs-toggle="pill" data-bs-target="#pills-canseled-5" type="button" role="tab" aria-controls="pills-canseled-5" aria-selected="false">İptal Edilen</button>
                                    </li>
                                </ul>
                            </div>
         
                            <div class="tab-content" id="pills-tabContent">
                                <div class="tab-pane fade show active" id="pills-waiting-5" role="tabpanel" aria-labelledby="pills-waiting-5-tab"><div class="sale-cards">
                                        <div class="sale-container">
                                            <div class="sale-card">
                                                <div class="product-detail">
                                                    <div class="sale-img"><a href=""><img src="https://kemalellidort.com.tr/uploads/urunler/images/min/8399e2b6f9b8a91709d8dbbffc4b6e18.png"></a>
                                                    </div>
                                                    <div class="product-info">
                                                        <div class="p-name"><a href="">Silkroad
                                                                Turkey 300 Silk</a>
                                                        </div>
                                                        <div class="p-price">Fiyat:
                                                            <span>180 TL</span>
                                                        </div>
                                                        <div class="p-price">Toplam
                                                            Kazanç:<span>360.00
                                                                TL</span></div>
                                                        <div class="p-quantity">
                                                            Adet:<span>2</span></div>
                                                    </div>
                                                </div>
                                                <div class="sale-status status-0"><i class="fa-solid fa-gauge-high"></i>
                                                    Teslimat bekliyor <button class="btn btn-primary btn-sm sale-detail-button align-self-end" data-bs-toggle="modal" data-bs-target="#info-modal-3">
                                                        İletilen Bilgiler </button>
                                                </div>
                                                <div class="sale-info">
                                                    <div class="s-date"> <i class="fa-regular fa-clock"></i>2024-03-08
                                                        17:53:27</div>
                                                    <div class="s-delivery">Satıcı: <a class="p-seller" href="">admin</a></div>
                                                </div>
                                            </div>
                                            <div class="sale-alerts ">
                                                <div>Teslim Yeri : denemee</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="tab-pane fade" id="pills-complate-5" role="tabpanel" aria-labelledby="pills-complate-5-tab">
                                    <div class="sale-cards">
                                        <div class="sale-container">
                                            <div class="sale-card">
                                                <div class="product-detail">
                                                    <div class="sale-img">
                                                        <a href="">
                                                            <img src="https://bursagb.s3.eu-central-1.amazonaws.com/AGARTHA_1691835141.webp">
                                                        </a>
                                                    </div>
                                                    <div class="product-info">
                                                        <div class="p-name">
                                                            <a href="">Agartha
                                                                10M Gold Bar</a>
                                                        </div>
                                                        <div class="p-price">
                                                            Fiyat: <span>32.21 TL</span>
                                                        </div>
                                                        <div class="p-price">
                                                            Toplam Kazanç: <span>32.21
                                                                TL</span>
                                                        </div>
                                                        <div class="p-quantity">
                                                            Adet: <span>1</span>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="sale-info">
                                                    <div class="s-date">
                                                        <i class="fa-regular fa-clock"></i>
                                                        2024-03-07 14:16:57
                                                    </div>
                                                    <div class="s-delivery">
                                                        Teslimat Tarihi: <span>2024-03-07
                                                            17:41:34</span>
                                                    </div>
                                                    <div class="s-delivery">
                                                        Satıcı: <a class="p-seller" href="">Hyper</a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="sale-status status-1 dflx">
                                                <div class="te-ip">
                                                    <i class="fa-solid fa-circle-check"></i>
                                                    Teslim edildi
                                                </div>
                                                <div class="s-name">
                                                    Teslim edilecek karakter adı:
                                                    <span>*******</span>
                                                </div>
                                                <div class="btn btn-primary btn-sm sale-detail-button align-self-end">
                                                    İletilen Bilgiler
                                                </div>

                                            </div>
                                            <div class="sale-alerts ">
                                                <div>Teslimat Yeri : Agartha 2. Server Folk
                                                    Banka Teslimat '' TRADE '' ile yapılır.
                                                    Takas geçmeden önce belirtilen alanda
                                                    hazır olunuz.</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="tab-pane fade" id="pills-canseled-5" role="tabpanel" aria-labelledby="pills-canseled-5-tab"><div class="sale-cards">
                                    <div class="sale-container">
                                        <div class="sale-card">
                                            <div class="product-detail">
                                                <div class="sale-img">
                                                    <a href="">
                                                        <img src="https://bursagb.s3.eu-central-1.amazonaws.com/AGARTHA_1691835141.webp">
                                                    </a>
                                                </div>
                                                <div class="product-info">
                                                    <div class="p-name">
                                                        <a href="">Agartha
                                                            10M Gold Bar</a>
                                                    </div>
                                                    <div class="p-price">
                                                        Fiyat: <span>32.20 TL</span>
                                                    </div>
                                                    <div class="p-price">
                                                        Toplam Kazanç: <span>64.40
                                                            TL</span>
                                                    </div>
                                                    <div class="p-quantity">
                                                        Adet: <span>2</span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="sale-status status-2"><i class="fa-solid fa-ban"></i>
                                                İptal edildi<div class="btn btn-primary btn-sm sale-detail-button align-self-end mt-3">
                                                    İletilen Bilgiler
                                                </div>
                                            </div>
                                            <div class="sale-info">
                                                <div class="s-date">
                                                    <i class="fa-regular fa-clock"></i>
                                                    2024-03-09 17:44:25
                                                </div>
                                                <div class="s-delivery">
                                                    Satıcı: <a class="p-seller" href="">Hyper</a>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="sale-alerts red">Satışınız iptal
                                            edilmiştir. Karakter Oyunda yada Teslimat
                                            Noktasında Değil.</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<script>
    setInterval(sendBekleyenAjaxRequest, 20000);
    setInterval(sendOnaylananAjaxRequest, 20000);
    setInterval(sendIptalAjaxRequest, 20000);

    function sendBekleyenAjaxRequest() {
        <?php if (aktif_kullanici()) : ?>
        $.post({
            url: "<?= base_url('onay-bekleyen-satislar')?>",
            type: 'POST',
            success: function (response) {
                var data = JSON.parse(response);
                if (data.status === true) {
                    var html = '';
                    $.each(data.data, function (index, val) {
                        html += '<div class="sales-box-warper"><div class="sale-cards"><div class="sale-container"><div class="sale-card"><div class="product-detail"><div class="sale-img">';
                        html += '<a href="javascript:void(0)"><img src="https://kemalellidort.com.tr/' + val.urun_resim_min + '"></a></div>';
                        html += '<div class="product-info"><div class="p-name"><a href="javascript:void(0)">' + val.urun_ad + '</a></div> <div class="p-price">Fiyat: <span>' + val.urun_alimfiyat + ' TL</span></div><div class="p-price">Toplam Kazanç:<span>' + val.price + ' TL</span></div><div class="p-quantity">Adet:<span>' + val.quantity + '</span></div></div></div>';
                        html += '<div class="sale-status status-0"><i class="fa-solid fa-gauge-high"></i> Teslimat bekliyor <button class="btn btn-primary btn-sm sale-detail-button align-self-end" data-bs-toggle="modal" data-bs-target="#info-modal-' + val.id + '"> İletilen Bilgiler </button></div>';
                        html += '<div class="sale-info"><div class="s-date"> <i class="fa-regular fa-clock"></i>' + val.added_time + '</div><div class="s-delivery">Satıcı: <a class="p-seller" href="">' + val.kullanici_ad + '</a></div></div></div><div class="sale-alerts "><div>' + val.urun_alimbaslik + '</div></div></div></div></div>';
                        html += '<div class="modal fade" id="info-modal-' + val.id + '" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true"><div class="modal-dialog"><div class="modal-content"><div class="modal-header"><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div><div class="modal-body"><div class="detail-data-rows"><div class="detail-data-row"><span class="detail-data-name">Oyundaki Karakter Adınız :</span><span class="detail-data-val">' + val.character_name + '</span></div></div></div><div class="modal-footer boder-0"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Kapat</button></div></div></div></div>';
                    });
                    $('#pills-waiting').html(html);
                } else {
                    Swal.fire({
                        title: 'Hata',
                        text: data.message,
                        icon: 'warning',
                    })
                }
            },
            error: function (response) {
                console.log(response);
            }
        });
        <?php else : ?>
        Swal.fire({
            title: 'Giriş Yap',
            text: "İşlem Yapabilmek İçin Giriş Yapmalısınız.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Giriş Yap',
            cancelButtonText: 'Hayır, İptal Et',
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = "<?= base_url('giris-yap') ?>";
            }
        })
        <?php endif; ?>
    }

    function sendOnaylananAjaxRequest() {
        <?php if (aktif_kullanici()) : ?>
        $.post({
            url: "<?= base_url('tamamlanan-satislar')?>",
            type: 'POST',
            success: function (response) {
                var data = JSON.parse(response);
                if (data.status === true) {
                    var html = '';
                    $.each(data.data, function (index, val) {
                        html += '<div class="sale-cards"><div class="sale-container"><div class="sale-card"><div class="product-detail"><div class="sale-img">';
                        html += '<a href="javascript:void(0)"><img src="https://kemalellidort.com.tr/' + val.urun_resim_min + '"> </a></div>';
                        html += '<div class="product-info"><div class="p-name"><a href="javascript:void(0)">' + val.urun_ad + '</a></div><div class="p-price">Fiyat: <span>' + val.urun_alimfiyat + ' TL</span></div><div class="p-price">Toplam Kazanç: <span>' + val.price + ' TL</span></div><div class="p-quantity">Adet: <span>' + val.quantity + '</span></div></div></div>';
                        html += '<div class="sale-info"><div class="s-date"><i class="fa-regular fa-clock"></i> ' + val.added_time + '</div><div class="s-delivery">Teslimat Tarihi: <span>' + val.delivery_date + '</span></div><div class="s-delivery">Satıcı: <a class="p-seller" href="">' + val.kullanici_ad + '</a></div></div></div>';
                        html += '<div class="sale-status-g"><div class="sale-status status-1"><i class="fa-solid fa-circle-check"></i> Teslim edildi</div><div class="s-name">Teslim edilecek karakter adı: <span>*******</span></div><button class="btn btn-primary btn-sm sale-detail-button align-self-end" data-bs-toggle="modal" data-bs-target="#info-comp-modal-' + val.id + '">İletilen Bilgiler</button></div></div><div class="sale-alerts "><div>' + val.urun_alimbaslik + '</div></div></div>';
                        html += '<div class="modal fade" id="info-comp-modal-' + val.id + '" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true"><div class="modal-dialog"><div class="modal-content"><div class="modal-header"><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div><div class="modal-body"><div class="detail-data-rows"><div class="detail-data-row"><span class="detail-data-name">Oyundaki Karakter Adınız :</span><span class="detail-data-val">' + val.character_name + '</span></div></div></div><div class="modal-footer boder-0"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Kapat</button></div></div></div></div>';
                    });
                    $('#pills-complate').html(html);
                } else {
                    Swal.fire({
                        title: 'Hata',
                        text: data.message,
                        icon: 'warning',
                    })
                }
            },
            error: function (response) {
                console.log(response);
            }
        });
        <?php else : ?>
        Swal.fire({
            title: 'Giriş Yap',
            text: "İşlem Yapabilmek İçin Giriş Yapmalısınız.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Giriş Yap',
            cancelButtonText: 'Hayır, İptal Et',
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = "<?= base_url('giris-yap') ?>";
            }
        })
        <?php endif; ?>
    }

    function sendIptalAjaxRequest() {
        <?php if (aktif_kullanici()) : ?>
        $.post({
            url: "<?= base_url('iptal-edilen-satislar')?>",
            type: 'POST',
            success: function (response) {
                var data = JSON.parse(response);
                if (data.status === true) {
                    var html = '';
                    $.each(data.data, function (index, val) {
                        html += '<div class="sale-cards"><div class="sale-container"><div class="sale-card"><div class="product-detail"><div class="sale-img">';
                        html += '<a href="javascript:void(0)"><img src="https://kemalellidort.com.tr/' + val.urun_resim_min + '"> </a></div>';
                        html += '<div class="product-info"><div class="p-name"><a href="javascript:void(0)">' + val.urun_ad + '</a></div><div class="p-price">Fiyat: <span>' + val.urun_alimfiyat + ' TL</span></div><div class="p-price">Toplam Kazanç: <span>' + val.price + ' TL</span></div><div class="p-quantity">Adet: <span>' + val.quantity + '</span></div></div></div>';
                        html += '<div class="sale-status status-2"><i class="fad fa-window-close"></i> İptal edildi <button class="btn btn-primary btn-sm sale-detail-button align-self-end" data-bs-toggle="modal" data-bs-target="#info-cancel-modal-' + val.id + '">İletilen Bilgiler</button></div><div class="sale-info"><div class="s-date"><i class="fad fa-clock"></i> ' + val.added_time + '</div><div class="s-delivery">Satıcı: <a class="p-seller" href="javascript:void(0)">' + val.kullanici_ad + '</a></div></div></div>';
                        html += '<div class="sale-alerts red">Satışınız iptal edilmiştir.' + val.reason_for_cancellation + '</div></div></div>';
                        html += '<div class="modal fade" id="info-cancel-modal-' + val.id + '" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true"><div class="modal-dialog"><div class="modal-content"><div class="modal-header"><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div><div class="modal-body"><div class="detail-data-rows"><div class="detail-data-row"><span class="detail-data-name">Oyundaki Karakter Adınız :</span><span class="detail-data-val">' + val.character_name + '</span></div></div></div><div class="modal-footer boder-0"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Kapat</button></div></div></div></div>'
                    });
                    $('#pills-cancel').html(html);
                } else {
                    Swal.fire({
                        title: 'Hata',
                        text: data.message,
                        icon: 'warning',
                    })
                }
            },
            error: function (response) {
                console.log(response);
            }
        });
        <?php else : ?>
        Swal.fire({
            title: 'Giriş Yap',
            text: "İşlem Yapabilmek İçin Giriş Yapmalısınız.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Giriş Yap',
            cancelButtonText: 'Hayır, İptal Et',
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = "<?= base_url('giris-yap') ?>";
            }
        })
        <?php endif; ?>
    }

</script>