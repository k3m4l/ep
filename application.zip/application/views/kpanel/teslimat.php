<main class="k-panel-warper">
    <div class="sec-warper mb-4">
        <div class="container normal-container p-0">
            <div class="k-panel-g-warper k-panel-content-box">
                <div class="row">
                    <div class="col-xl-3 col-lg-3 col-md-12 col-sm-12 wd-none mt-3 p-0 ">
                        <div class="accordion accordion-flush acc-kpc-menu" id="accordionFlushExample">
                            <div class="accordion-item acc-kpc-menu-item">
                                <h2 class="accordion-header acc-kpc-menu-header" id="flush-headingOne">
                                    <button class="accordion-button collapsed acc-kpc-menu-btn" type="button"
                                            data-bs-toggle="collapse" data-bs-target="#flush-collapseOne"
                                            aria-expanded="false" aria-controls="flush-collapseOne">
                                        Hızlı Menü
                                    </button>
                                </h2>
                                <div id="flush-collapseOne" class="accordion-collapse collapse"
                                     aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
                                    <div class="accordion-body acc-kpc-menu-body">
                                        <div class="k-panel-left-navbar-warper">
                                            <div class="k-panel-left-navbar-area">
                                                <div class="nav flex-column nav-pills bg-custom-none " id="v-pills-tab" role="tablist"
                                                    aria-orientation="vertical">
                                                    <?php if (magaza_check()) { ?>
                                                        <div class="gt-store">
                                                            <a href="<?php echo base_url('m/'.magaza($kullanici->kullanici_id)->magaza_seo) ?>" class="btn btn-primary settings-btn mb-3 w-100">Mağzaya Git</a>
                                                        </div>
                                                    <?php } ?>
                                                    <a href="<?php echo base_url('hesabim') ?>" title="" class="nav-link kpc-nav-btn">Profilim</a>
                                                    <a href="<?php echo base_url('siparislerim') ?>" title="" class="nav-link kpc-nav-btn">Siparişlerim</a>
                                                    <a href="<?php echo base_url('satislar') ?>" title="" class="nav-link kpc-nav-btn">Gold Al - Sat</a>
                                                    <a href="<?php echo base_url('sorularim') ?>" title="" class="nav-link kpc-nav-btn">Sorularım</a>
                                                    <a href="<?php echo base_url('bakiye') ?>" title="" class="nav-link kpc-nav-btn">Bakiye</a>
                                                    <a href="<?php echo base_url('odeme-talep') ?>" title="" class="nav-link kpc-nav-btn">Bakiye Çekim</a>
                                                    <a href="<?php echo base_url('destek-taleplerim') ?>" title="" class="nav-link kpc-nav-btn">Destek Taleplerim</a>
                                                    <a href="<?php echo base_url('itirazlarim') ?>" title="" class="nav-link kpc-nav-btn active">İtirazlarım</a>
                                                    <a href="<?php echo base_url('hesap-ayarlari') ?>" title="" class="nav-link kpc-nav-btn">Profil Ayarlarım</a>
                                                    <a class="nav-link kpc-nav-btn" href="<?php echo base_url('cikis') ?>">Çıkış</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-3 col-md-12 col-sm-12 md-none m-bg ">
                        <div class="k-panel-left-navbar-warper">
                            <div class="k-panel-left-navbar-area">
                                <div class="nav flex-column nav-pills bg-custom-none " id="v-pills-tab" role="tablist"
                                    aria-orientation="vertical">
                                <?php if (magaza_check()) { ?>
                                        <div class="gt-store">
                                            <a href="<?php echo base_url('m/'.magaza($kullanici->kullanici_id)->magaza_seo) ?>" class="btn btn-primary settings-btn mb-3 w-100">Mağzaya Git</a>
                                        </div>
                                    <?php } ?>
                                    <a href="<?php echo base_url('hesabim') ?>" title="" class="nav-link kpc-nav-btn">Profilim</a>
                                    <a href="<?php echo base_url('siparislerim') ?>" title="" class="nav-link kpc-nav-btn">Siparişlerim</a>
                                    <a href="<?php echo base_url('satislar') ?>" title="" class="nav-link kpc-nav-btn">Gold Al - Sat</a>
                                    <a href="<?php echo base_url('sorularim') ?>" title="" class="nav-link kpc-nav-btn">Sorularım</a>
                                    <a href="<?php echo base_url('bakiye') ?>" title="" class="nav-link kpc-nav-btn">Bakiye</a>
                                    <a href="<?php echo base_url('odeme-talep') ?>" title="" class="nav-link kpc-nav-btn">Bakiye Çekim</a>
                                    <a href="<?php echo base_url('destek-taleplerim') ?>" title="" class="nav-link kpc-nav-btn">Destek Taleplerim</a>
                                    <a href="<?php echo base_url('itirazlarim') ?>" title="" class="nav-link kpc-nav-btn active">İtirazlarım</a>
                                    <a href="<?php echo base_url('hesap-ayarlari') ?>" title="" class="nav-link kpc-nav-btn">Profil Ayarlarım</a>
                                    <a class="nav-link kpc-nav-btn" href="<?php echo base_url('cikis') ?>">Çıkış</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-9 col-md-8 col-12">
                        <div class="k-panel-content-box">
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <?php if ($teslimat->teslimat_durum == 0) { ?>
                                        <button type="button" class="btn btn-outline-warning btn-block rounded-pill">
                                            Teslimat İtiraz Durumu Bekliyor..
                                        </button>
                                    <?php } elseif ($teslimat->teslimat_durum == 1) { ?>
                                        <button type="button" class="btn btn-success btn-block rounded-pill">
                                            <i class="fe fe-check-circle"></i> Teslimat İtirazı Çözüldü
                                        </button>
                                    <?php } elseif ($teslimat->teslimat_durum == 2) { ?>
                                        <button type="button" class="btn btn-danger btn-block rounded-pill">
                                            <i class="fe fe-x-circle"></i> Teslimat İtirazı Çözülemedi
                                        </button>
                                    <?php } elseif ($teslimat->teslimat_durum == 3) { ?>
                                        <button type="button" class="btn btn-info btn-block rounded-pill">
                                            Teslimat İtirazı Cevap Verildi..
                                        </button>
                                    <?php } ?>
                                </div>
                                <div class="col-md-6">
                                    <button type="button" class="btn btn-primary btn-block rounded-pill">
                                        <?= date('d.m.Y H:s', strtotime($teslimat->teslimat_zaman)) ?>
                                    </button>
                                </div>
                            </div>
                            <div class="card br-0">
                                <div class="card-body account-area">
                                    <?php if ($mesajlar) {
                                        foreach ($mesajlar as $mesaj) { ?>
                                            <div class="pt-0 pb-5 mt-3">
                                                <div class="row mb-2">
                                                    <div class="col-lg-12 mb-lg-0">
                                                    <span class="d-flex">
                                                        <?php if ($mesaj->kullanici_yetki != 9) { ?>
                                                            <span class="h4 mb-0"><?= $mesaj->kullanici_isim . " " . $mesaj->kullanici_soyisim ?></span>
                                                        <?php } else { ?>
                                                            <span class="h4 mb-0 text-success">Destek Yetkilisi</span>
                                                        <?php } ?>
                                                        <br>
                                                        <?php if ($mesaj->kullanici_yetki != 9) { ?>
                                                            <!--<span class="h6 m-0"><?= $mesaj->kullanici_mail ?></span>-->
                                                            <!--<br>-->
                                                            <span class="ml-2">(<?= date('d.m.Y H:s', strtotime($mesaj->mesaj_zaman)) ?>)</span>
                                                        <?php } else { ?>
                                                            <span class="ml-2">(<?= date('d.m.Y H:s', strtotime($mesaj->mesaj_zaman)) ?>)</span>
                                                        <?php } ?>
                                                    </span>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-lg-12 mb-2 mb-lg-0">
                                                        <?= $mesaj->mesaj ?>
                                                    </h6-->
                                                        <div class="form-group">
                                                        <textarea class="form-control" rows="3" type="text"
                                                                    placeholder="İtiraz Cevabı"
                                                                    disabled><?= $mesaj->mesaj ?></textarea>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php }
                                    } ?>
                                    <?php if ($teslimat->teslimat_durum == 0 || $teslimat->teslimat_durum == 3) { ?>
                                        <form method="post"
                                                action="<?php echo base_url('teslimat-cevap/' . $teslimat->siparis_no) ?>">
                                            <div class="form-group mt-5">
                                                <label class="form-label">Cevap Gönder</label>
                                                <textarea class="form-control" rows="5" type="text"
                                                            placeholder="Cevap"
                                                            name="cevap"></textarea>
                                                <button type="submit" class="btn btn-block btn-primary mt-3">Cevapla</button>
                                            </div>
                                        </form>
                                    <?php } ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>         
