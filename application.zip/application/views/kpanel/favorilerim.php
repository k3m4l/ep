<?php $kullanici = aktif_kullanici(); ?>
<?php $favorilerim = favorilerim($kullanici->kullanici_id); ?>
<div id="dashboard">

	<!-- Navigation
	================================================== -->

	<!-- Responsive Navigation Trigger -->
	<a href="#" class="dashboard-responsive-nav-trigger"><i class="fa fa-reorder"></i> Navigation</a>

	<?php $this->load->view("kpanel/inc/menu"); ?>
	<!-- Navigation / End -->


	<!-- Content
	================================================== -->
	<div class="dashboard-content">

		<!-- Titlebar -->
		<div id="titlebar">
			<div class="row">
				<div class="col-md-12">
					<h2>Favorilerim</h2>
					<!-- Breadcrumbs -->
					<nav id="breadcrumbs">
						<ul>
							<li><a href="<?=base_url()?>">Anasayfa</a></li>
							<li><a href="<?=base_url("kullanici-paneli")?>">Kullanıcı Paneli</a></li>
							<li>Favorilerim</li>
						</ul>
					</nav>
				</div>
			</div>
		</div>

		<div class="row">
			
			<!-- Listings -->
				<div class="dashboard-list-box margin-top-0">
					<ul>
						<?php if ($favorilerim) { ?>
							<?php foreach ($favorilerim as $key) { ?>
								<?php $yorumpuan = yorumpsay($key->firma_id); ?>
								<li>
									<div class="list-box-listing">
										<div class="list-box-listing-img"><a href="<?=base_url("firma/").$key->firma_seo?>"><img src="<?=base_url($key->firma_resim)?>" alt="<?=$key->firma_ad?>"></a></div>
										<div class="list-box-listing-content">
											<div class="inner">
												<h3><?=$key->firma_ad?></h3>
												<span><?=$key->firma_adres?></span>
												<div class="star-rating" data-rating="<?=$yorumpuan->yorum_puan?>">
													<div class="rating-counter">(<?php echo yorumsaydir($key->firma_id); ?> yorum)</div>
												</div>
											</div>
										</div>
									</div>
								</li>
							<?php } ?>
						<?php }else{ ?>
							<div class="notification warning closeable text-center">
								<p>Favorilere Hiç Firma Eklemediniz!</p>
							</div>
						<?php } ?>
					</ul>
				</div>
			</div>

			<?php $this->load->view("kpanel/inc/footer"); ?>

		</div>

	</div>
	<!-- Content / End -->


</div>
<!-- Dashboard / End -->


</div>