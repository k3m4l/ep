<section class="col-lg-8 account-profile-element">
    <div class="account-profile-photo-area"
         style="background-image: url('<?php echo base_url($kullanici->kullanici_banner) ?>')">
        <div class="user-photo-area">
            <?php if (strpos($kullanici->kullanici_resim, "/.jpg") !== false) { ?>
                <img src="https://ui-avatars.com/api/?name=<?= $kullanici->kullanici_ad ?>&background=0D8ABC&color=fff"
                     alt=""/>
            <?php } else { ?>
                <img src="<?= base_url($kullanici->kullanici_resim) ?>" alt=""/>
            <?php } ?>
        </div>
    </div>
</section>

<section class="col-lg-8 account-billing-cart-area">
    <div class="billing">
        <div class="row">
            <div class="col-md-4">
                <div class="bg-info rounded overflow-hidden">
                    <div class="pd-x-20 pd-t-20 d-flex align-items-center">
                        <i class="fas fa-star tx-60 tx-white op-7"></i>
                        <div class="mg-l-20">
                            <p class="tx-15 tx-spacing-1 tx-mont tx-semibold tx-uppercase tx-white-8 mg-b-10">Hesap Bakiyesi</p>
                            <p class="tx-24 tx-white tx-lato tx-bold mg-b-0 lh-1"><?= $kullanici->bakiye ?> ₺</p>
                        </div>
                    </div>
                    <div id="ch1" class="ht-50 tr-y-1 rickshaw_graph">
                        <img src="<?php echo base_url('assets/images/cart_img.svg') ?>" alt="">
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="bg-purple rounded overflow-hidden">
                    <div class="pd-x-20 pd-t-20 d-flex align-items-center">
                        <i class="fas fa-store tx-60 tx-white op-7"></i>
                        <div class="mg-l-20">
                            <p class="tx-15 tx-spacing-1 tx-mont tx-semibold tx-uppercase tx-white-8 mg-b-10">Destek Taleplerim</p>
                            <p class="tx-24 tx-white tx-lato tx-bold mg-b-0 lh-1">0</p>
                        </div>
                    </div>
                    <div id="ch1" class="ht-50 tr-y-1 rickshaw_graph">
                        <img src="<?php echo base_url('assets/images/cart_img.svg') ?>" alt="">
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="bg-warning rounded overflow-hidden">
                    <div class="pd-x-20 pd-t-20 d-flex align-items-center">
                        <i class="fas fa-coins tx-60 tx-white op-7"></i>
                        <div class="mg-l-20">
                            <p class="tx-15 tx-spacing-1 tx-mont tx-semibold tx-uppercase tx-white-8 mg-b-10">Siparişlerim</p>
                            <p class="tx-24 tx-white tx-lato tx-bold mg-b-0 lh-1"><?= $siparis_say; ?></p>
                        </div>
                    </div>
                    <div id="ch1" class="ht-50 tr-y-1 rickshaw_graph">
                        <img src="<?php echo base_url('assets/images/cart_img.svg') ?>" alt="">
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="col-lg-8 control-panel">
    <div class="account-area">
    
    <div class="container-fluid p-0">

        <div class="row">
            <div class="col-lg-3 col-md-4 col-12 pr-0">
                <div class="user-img-left-area">
                    <img src="<?= base_url($kullanici->kullanici_resim) ?>" alt=""/>
                    <div>
                    <?= $kullanici->kullanici_ad ?>
                    </div>
                </div>
                
                <?php $this->load->view('kpanel/inc/menu'); ?>
            </div>

            <div class="col-lg-9 col-md-8 col-12">
                <div class="pt-area">
                <h2 class="title">Hesap Özeti</h2>
                <?php
                if (1 == 2) {
                    if (!isset($_SESSION["sistembildir"])) {
                        $_SESSION["sistembildir"] = "0";
                    }

                    //  $this->db->select('COUNT(talep_id) as toplam');
                    $this->db->where("kullanici_id='" . $kullanici->kullanici_id . "' and talep_durum='0'");
                    $aylik_siparis_adet = $this->db->get('talep')->result();
                    $data = [];
                    $say = "0";
                    $yaz = "";
                    foreach ($aylik_siparis_adet as $row) {
                        $say++;
                        $yaz .= $say . " - <a style='color:#376d85' href='/destek-detay/" . $row->talep_no . "' target='_blank'>" . $row->talep . "</a><br>";
                    }
                    if ($say != "0") {
                        echo '<div class="alert alert-info tex-">' . $yaz . $say . ' adet talep yanıtlanmayı bekliyor.</div>';
                    }

                    if ($say != $_SESSION["sistembildir"]) {
                        if ($say > $_SESSION["sistembildir"]) {
                            echo '  
                            <audio autoplay="autoplay">
                              <source src="https://soundbible.com/grab.php?id=2155&type=mp3" type="audio/mpeg" />
                              Tarayıcınız audio etiketini desteklemiyor.
                            </audio>';
                        }
                        $_SESSION["sistembildir"] = $say;
                    }
                }
                ?>
                <?php if (!empty($siparislerim)) { ?>
                    <?php foreach ($siparislerim as $key => $val) { ?>
                        <div class="purchase-card" style="width: 100% !important;">
                            <div class="purchase-card-bg"
                                 style="background-image: url(https://kemalellidort.com.tr/assets/images/valorant-313.png);background-size: cover !important;background-position: center;"></div>
                            <div class="purchase-body">
                                <div class="ProductImage"
                                     style="background: url(<?php echo base_url($val->urun_resim_min) ?>);"></div>
                                <div class="ProductName"><?php echo $val->urun_ad ?></div>
                                <div class="DeliveredTime"><?php echo date("d.m.Y", strtotime($val->siparis_tarih)) ?></div>
                                <?php if ($val->siparis_durum == 1) { ?>
                                    <div class="topupDiv">
                                        <div class="topupStatus status-1"><i class="fas fa-circle"></i><span>Sipariş Bekliyor</span>
                                        </div>
                                        <div class="pre-order-description">Bu sipariş bir ön sipariş olarak
                                            oluşturulmuştur,
                                            Ürününüz en kısa sürede hazırlanıp size iletilecektir.
                                        </div>
                                    </div>
                                <?php } else if ($val->siparis_durum == 3) { ?>
                                    <div class="topupDiv">
                                        <div class="topupStatus status-4"><i class="fas fa-circle"></i><span>Sipariş iptal edildi</span>
                                        </div>
                                        <div class="pre-order-description">Bu sipariş bir ön sipariş olarak
                                            oluşturulmuştur,
                                            Ürününüz en kısa sürede hazırlanıp size iletilecektir.
                                        </div>
                                    </div>
                                    <div class="pre-order-description pre-order-cancel">
                                        <?php echo $val->siparis_iptal ?>
                                    </div>
                                <?php } else if ($val->siparis_durum == 2) { ?>
                                    <?php
                                    $tempHTML = '';
                                    if ($val->urun_turu == 1) {
                                        $metin = $val->siparis_key;
                                        $satirlar = explode("\n", $metin);

                                        foreach ($satirlar as $satir) {
                                            $parcalar = explode(':', $satir);
                                            if (count($parcalar) === 2) {
                                                $etiket = trim($parcalar[0]);
                                                $deger = trim($parcalar[1]);
                                                if (strtolower($etiket) === "id") {
                                                    $tempHTML .= '<div class="KeyDiv">' .
                                                        '<button class="btn btn-default btn-sm btn-copy-password copy-to-clipboard" type="button" data-clipboard-text="' . $deger . '"><i class="fas fa-copy"></i></button>' .
                                                        '<input id="Code' . $val->siparis_id . '" type="password" class="PurchaseKey" value="ID:' . $deger . '" readonly="">' .
                                                        '<button data-id="Code' . $val->siparis_id . '" data-code="' . $val->siparis_id . '" class="btn btn-default btn-sm btn-hide-password" type="button" onclick="HideShowPasswordInput(this)"><i class="fas fa-low-vision"></i></button>' .
                                                        '</div>';
                                                } elseif (strtolower($etiket) === "key") {
                                                    $tempHTML .= '<div class="KeyDiv">' .
                                                        '<button class="btn btn-default btn-sm btn-copy-password copy-to-clipboard" type="button" data-clipboard-text="' . $deger . '"><i class="fas fa-copy"></i></button>' .
                                                        '<input id="Code' . $val->siparis_id . '" type="password" class="PurchaseKey" value="KEY:' . $deger . '" readonly="">' .
                                                        '<button data-id="Code' . $val->siparis_id . '" data-code="' . $val->siparis_id . '" class="btn btn-default btn-sm btn-hide-password" type="button" onclick="HideShowPasswordInput(this)"><i class="fas fa-low-vision"></i></button>' .
                                                        '</div>';
                                                }
                                            }
                                        }
                                    } else {
                                        $tempHTML .= '<div class="KeyDiv">' .
                                            '<button class="btn btn-default btn-sm btn-copy-password copy-to-clipboard" type="button" data-clipboard-text="' . $val->siparis_key . '"><i class="fas fa-copy"></i></button>' .
                                            '<input id="Code' . $val->siparis_id . '" type="password" class="PurchaseKey" value="' . $val->siparis_key . '" readonly="">' .
                                            '<button data-id="Code' . $val->siparis_id . '" data-code="' . $val->siparis_id . '" class="btn btn-default btn-sm btn-hide-password" type="button" onclick="HideShowPasswordInput(this)"><i class="fas fa-low-vision"></i></button>' .
                                            '</div>';
                                    }

                                    echo $tempHTML;
                                    ?>

                                <?php } ?>
                                <div class="TotalPaid"><b>Ödenen Ücret: </b> <?php echo $val->siparis_tutar ?>
                                    <price>₺</price>
                                </div>
                            </div>
                        </div>
                    <?php } ?>
                <?php } else { ?>
                    <div class="alert alert-warning" role="alert">
                        Satın Aldığınız Ürün Bulunmamaktadır!!
                    </div>
                <?php } ?>

                <?php if (1 == 2) { ?>
                    <div class="card mb-4">
                        <div class="card-header border-bottom-0">
                            <h3 class="h4 mb-3">Son 5 Siparişlerim</h3>
                        </div>
                        
                        <div class="table-responsive border-0">
                            <?php if (1 == 2) { ?>
                                <table class="table mb-0 text-nowrap dark-table light-table">
                                    <thead>
                                    <tr>
                                        <th class="border-0">Sipariş No</th>
                                        <th class="border-0">Durum</th>
                                        <th class="border-0">Tutar</th>
                                        <th class="border-0">Tarih</th>
                                        <th class="border-0"></th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php if ($siparislerim) {
                                        foreach ($siparislerim as $siparis) { ?>
                                            <tr>
                                                <td class="align-middle border-top-0">
                                                    <a data-toggle="tooltip" data-placement="top" title="Sipariş Detayı"
                                                       href="<?= base_url('siparis-detay/' . $siparis->siparis_no) ?>">#<?= $siparis->siparis_no ?></a>
                                                </td>
                                                <td class="align-middle border-top-0">
                                                    <?php if ($siparis->siparis_durum == 0) { ?>
                                                        <a target="_blank"
                                                           href="<?= base_url('odeme/' . $siparis->siparis_no) ?>"
                                                           class="badge badge-warning">Ödeme Yapılmadı..</a>
                                                    <?php } elseif ($siparis->siparis_durum == 1) { ?>
                                                        <a href="javascript:void(0)" class="badge badge-secondary"
                                                           data-toggle="modal"
                                                           data-target="#odeme_onay_<?= $siparis->siparis_id ?>">Teslimatı
                                                            Onaylayın
                                                        </a>
                                                    <?php } elseif ($siparis->siparis_durum == 2) { ?>
                                                        <span class="badge badge-success">Ödeme Yapıldı</span>
                                                    <?php } elseif ($siparis->siparis_durum == 3) { ?>
                                                        <span data-toggle="tooltip" data-placement="top"
                                                              title="<?= $siparis->siparis_iptal ?>"
                                                              class="badge badge-danger">Sipariş İptal Edildi</span>
                                                    <?php } ?>
                                                </td>
                                                <td class="align-middle border-top-0"><?= $siparis->siparis_tutar ?>₺
                                                </td>
                                                <td class="align-middle border-top-0"><?= date('d.m.Y H:m', strtotime($siparis->siparis_tarih)) ?></td>
                                                <td class="align-middle border-top-0">
                                                    <a href="<?= base_url('siparis-detay/' . $siparis->siparis_no) ?>"
                                                       class="btn btn-primary btn-sm" data-toggle="tooltip"
                                                       data-placement="top" title="Görüntüle">
                                                        <i class="fe fe-eye"></i>
                                                    </a>
                                                    <?php if ($siparis->siparis_durum == 2) { ?>
                                                        <a href="<?= base_url('fatura/' . $siparis->siparis_no) ?>"
                                                           class="btn btn-secondary btn-sm" data-toggle="tooltip"
                                                           data-placement="top" title="Fatura">
                                                            <i class="fe fe-file-text"></i>
                                                        </a>
                                                        <a href="javascript:void(0)" data-toggle="modal"
                                                           data-target="#yorum_<?= $siparis->siparis_id ?>"
                                                           class="btn btn-warning btn-sm"
                                                           data-toggle="tooltip"
                                                           data-placement="top" title="Değerlendir">
                                                            <i class="text-light fe fe-star"></i>
                                                        </a>
                                                    <?php } ?>
                                                    <?php if ($siparis->urun_turu == 3) {
                                                        if ($siparis->siparis_durum == 1 || $siparis->siparis_durum == 2) { ?>
                                                            <a href="<?= base_url('indir/' . $siparis->siparis_no) ?>"
                                                               class="btn btn-success btn-sm" data-toggle="tooltip"
                                                               data-placement="top" title="İndir">
                                                                <i class="fe fe-download-cloud"></i>
                                                            </a>
                                                        <?php }
                                                    } ?>

                                                </td>
                                            </tr>
                                            <?php if ($siparis->siparis_durum == 1) { ?>
                                                <div class="modal fade" id="odeme_onay_<?= $siparis->siparis_id ?>"
                                                     tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
                                                     aria-hidden="true">
                                                    <div class="modal-dialog modal-dialog-centered" role="document">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title" id="exampleModalLabel">Teslimat
                                                                    Onay
                                                                    Bilgilendirme</h5>
                                                                <button type="button" class="close" data-dismiss="modal"
                                                                        aria-label="Close">
                                                                    <span aria-hidden="true">&times;</span>
                                                                </button>
                                                            </div>
                                                            <div class="modal-body text-center">
                                                                <span class="badge badge-warning mb-2">SİPARİŞ NO : <?= $siparis->siparis_no ?></span>
                                                                <p class="text-center">Teslimatta her hangi bir sıkıntı
                                                                    yaşamadıysanız satıcının ödemesini onaylamanız
                                                                    gerekmektedir!
                                                                    Onaylamadığınız taktirde sistem otomatik olarak
                                                                    <span
                                                                            class="badge badge-success badge-pill">1 gün</span>
                                                                    sonra onaylayacaktır. Teslimatı onaylamak için
                                                                    sipariş
                                                                    detayına gidin.</p>
                                                                <a href="<?= base_url('siparis-detay/' . $siparis->siparis_no) ?>"
                                                                   class="btn btn-outline-primary btn-block input-radius"><i
                                                                            class="fe fe-eye"></i> Sipariş Detayı</a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php } ?>
                                            <?php if ($siparis->siparis_durum == 2) { ?>
                                                <div class="modal fade" id="yorum_<?= $siparis->siparis_id ?>"
                                                     tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
                                                     aria-hidden="true">
                                                    <div class="modal-dialog modal-dialog-centered" role="document">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title" id="exampleModalLabel">Siparişi
                                                                    Değerlendirin</h5>
                                                                <button type="button" class="close" data-dismiss="modal"
                                                                        aria-label="Close">
                                                                    <span aria-hidden="true">&times;</span>
                                                                </button>
                                                            </div>
                                                            <div class="modal-body text-center">
                                                                <?php if (yorum_kontrol($kullanici->kullanici_id, $siparis->siparis_no) != 0) {
                                                                    $yorum = yorum($kullanici->kullanici_id, $siparis->siparis_no); ?>
                                                                    <?php if ($yorum->yorum_durum == 0) { ?>
                                                                        <button class="btn btn-outline-warning btn-block rounded-pill">
                                                                            Onay
                                                                            Bekleniyor..
                                                                        </button>
                                                                    <?php } elseif ($yorum->yorum_durum == 1) { ?>
                                                                        <button class="btn btn-success btn-block rounded-pill">
                                                                            Değerlendirme Yayınlandı
                                                                        </button>
                                                                    <?php } elseif ($yorum->yorum_durum == 2) { ?>
                                                                        <button class="btn btn-danger btn-block rounded-pill">
                                                                            Onaylanmadı
                                                                        </button>
                                                                    <?php } ?>
                                                                    <div id="full-stars-example-two">
                                                                        <div class="rating-group">
                                                                            <input class="rating__input rating__input--none"
                                                                                   name="puan" id="rating3-none"
                                                                                   value="0"
                                                                                   type="radio" <?php if ($yorum->yorum_durum == 0) {
                                                                                echo 'checked';
                                                                            } ?> disabled>
                                                                            <label aria-label="1 star"
                                                                                   class="rating__label"
                                                                                   for="rating3-1"><i
                                                                                        class="rating__icon rating__icon--star fa fa-star"></i></label>
                                                                            <input class="rating__input" name="puan"
                                                                                   id="rating3-1" value="1"
                                                                                   type="radio" <?php if ($yorum->yorum_puan == 1) {
                                                                                echo 'checked';
                                                                            } ?> disabled>
                                                                            <label aria-label="2 stars"
                                                                                   class="rating__label"
                                                                                   for="rating3-2"><i
                                                                                        class="rating__icon rating__icon--star fa fa-star"></i></label>
                                                                            <input class="rating__input" name="puan"
                                                                                   id="rating3-2" value="2"
                                                                                   type="radio" <?php if ($yorum->yorum_puan == 2) {
                                                                                echo 'checked';
                                                                            } ?> disabled>
                                                                            <label aria-label="3 stars"
                                                                                   class="rating__label"
                                                                                   for="rating3-3"><i
                                                                                        class="rating__icon rating__icon--star fa fa-star"></i></label>
                                                                            <input class="rating__input" name="puan"
                                                                                   id="rating3-3" value="3"
                                                                                   type="radio" <?php if ($yorum->yorum_puan == 3) {
                                                                                echo 'checked';
                                                                            } ?> disabled>
                                                                            <label aria-label="4 stars"
                                                                                   class="rating__label"
                                                                                   for="rating3-4"><i
                                                                                        class="rating__icon rating__icon--star fa fa-star"></i></label>
                                                                            <input class="rating__input" name="puan"
                                                                                   id="rating3-4" value="4"
                                                                                   type="radio" <?php if ($yorum->yorum_puan == 4) {
                                                                                echo 'checked';
                                                                            } ?> disabled>
                                                                            <label aria-label="5 stars"
                                                                                   class="rating__label"
                                                                                   for="rating3-5"><i
                                                                                        class="rating__icon rating__icon--star fa fa-star"></i></label>
                                                                            <input class="rating__input" name="puan"
                                                                                   id="rating3-5" value="5"
                                                                                   type="radio" <?php if ($yorum->yorum_puan == 5) {
                                                                                echo 'checked';
                                                                            } ?> disabled>
                                                                        </div>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label>Yorumunuz <small>(İsteğe
                                                                                Bağlı)</small></label>
                                                                        <textarea class="form-control" rows="5"
                                                                                  placeholder="Yorumunuz.."
                                                                                  disabled><?= $yorum->yorum_detay ?></textarea>
                                                                    </div>

                                                                <?php } else { ?>
                                                                    <form action="<?= base_url('yorum-yap/' . $siparis->siparis_no) ?>"
                                                                          method="post">
                                                                        <div id="full-stars-example-two">
                                                                            <div class="rating-group">
                                                                                <input checked
                                                                                       class="rating__input rating__input--none"
                                                                                       name="puan" id="rating3-none"
                                                                                       value="0"
                                                                                       type="radio">
                                                                                <label aria-label="1 star"
                                                                                       class="rating__label"
                                                                                       for="rating3-1-<?= $siparis->siparis_id ?>"><i
                                                                                            class="rating__icon rating__icon--star fa fa-star"></i></label>
                                                                                <input class="rating__input" name="puan"
                                                                                       id="rating3-1-<?= $siparis->siparis_id ?>"
                                                                                       value="1" type="radio">
                                                                                <label aria-label="2 stars"
                                                                                       class="rating__label"
                                                                                       for="rating3-2-<?= $siparis->siparis_id ?>"><i
                                                                                            class="rating__icon rating__icon--star fa fa-star"></i></label>
                                                                                <input class="rating__input" name="puan"
                                                                                       id="rating3-2-<?= $siparis->siparis_id ?>"
                                                                                       value="2" type="radio">
                                                                                <label aria-label="3 stars"
                                                                                       class="rating__label"
                                                                                       for="rating3-3-<?= $siparis->siparis_id ?>"><i
                                                                                            class="rating__icon rating__icon--star fa fa-star"></i></label>
                                                                                <input class="rating__input" name="puan"
                                                                                       id="rating3-3-<?= $siparis->siparis_id ?>"
                                                                                       value="3" type="radio">
                                                                                <label aria-label="4 stars"
                                                                                       class="rating__label"
                                                                                       for="rating3-4-<?= $siparis->siparis_id ?>"><i
                                                                                            class="rating__icon rating__icon--star fa fa-star"></i></label>
                                                                                <input class="rating__input" name="puan"
                                                                                       id="rating3-4-<?= $siparis->siparis_id ?>"
                                                                                       value="4" type="radio">
                                                                                <label aria-label="5 stars"
                                                                                       class="rating__label"
                                                                                       for="rating3-5-<?= $siparis->siparis_id ?>"><i
                                                                                            class="rating__icon rating__icon--star fa fa-star"></i></label>
                                                                                <input class="rating__input" name="puan"
                                                                                       id="rating3-5-<?= $siparis->siparis_id ?>"
                                                                                       value="5" type="radio">
                                                                            </div>
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <label>Yorumunuz <small>(İsteğe
                                                                                    Bağlı)</small></label>
                                                                            <textarea name="yorum" class="form-control"
                                                                                      rows="5"
                                                                                      placeholder="Yorumunuz.."></textarea>
                                                                        </div>
                                                                        <button type="submit"
                                                                                class="btn btn-outline-primary btn-block input-radius">
                                                                            <i class="fe fe-comment"></i> Yorumu Paylaş
                                                                        </button>
                                                                    </form>
                                                                <?php } ?>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php } ?>
                                        <?php }
                                    } else { ?>
                                        <tr>
                                            <td colspan="6" align="center">
                                                <div class="notification warning closeable"><p>Sipariş Bulunamadı</p>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php } ?>
                                    </tbody>
                                </table>
                            <?php } ?>
                        </div>
                    </div>
                <?php } ?>
                </div>
            </div>
        </div>
    </div>
    </div>
</section>
