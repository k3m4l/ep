
<?php

$site =ayarlar();

$tat =  explode("/", $_SERVER['REQUEST_URI']);

if ($tat[3] == "iyzico" and $site->iyzico_durum == 1) {
    
    $ayarlar = ayarlar();
    require_once('application/libraries/iyzipay/IyzipayBootstrap.php');
    IyzipayBootstrap::init();
    $options = new \Iyzipay\Options();
    $options->setApiKey($ayarlar->iyzico_api);
    $options->setSecretKey($ayarlar->iyzico_secret);
    $options->setBaseUrl("https://sandbox-api.iyzipay.com");
    
    $request = new \Iyzipay\Request\CreateCheckoutFormInitializeRequest();
    $request->setLocale(\Iyzipay\Model\Locale::TR);
    $request->setConversationId('123456789');
    $request->setPrice($siparis->bakiye_tutar);
    $request->setPaidPrice(($siparis->bakiye_tutar + ($siparis->bakiye_tutar*$site->iyzico_komisyon/100)));
    $request->setCurrency(\Iyzipay\Model\Currency::TL);
    $request->setBasketId($siparis->bakiye_no);
    $request->setPaymentGroup(\Iyzipay\Model\PaymentGroup::PRODUCT);
    $request->setCallbackUrl(base_url('kpanel_controller/bakiye_odeme_onay_iyzico'));
    $request->setEnabledInstallments(array(2, 3, 6, 9));

    $buyer = new \Iyzipay\Model\Buyer();
    $buyer->setId($kullanici->kullanici_id);
    $buyer->setName($kullanici->kullanici_isim);
    $buyer->setSurname($kullanici->kullanici_soyisim);
    $buyer->setGsmNumber($kullanici->kullanici_tel);
    $buyer->setEmail($kullanici->kullanici_mail);
    $buyer->setIdentityNumber("74300864791");
    $buyer->setLastLoginDate($kullanici->kullanici_sonzaman);
    $buyer->setRegistrationDate($kullanici->kullanici_zaman);
    $buyer->setRegistrationAddress($kullanici->kullanici_adres);
    $buyer->setIp(getIPAddress());
    $buyer->setCity(sehir_ad($kullanici->kullanici_sehir));
    $buyer->setCountry('Türkiye');
    $buyer->setZipCode('34732');

    $request->setBuyer($buyer);
    $shippingAddress = new \Iyzipay\Model\Address();
    $shippingAddress->setContactName($kullanici->kullanici_isim." ".$kullanici->kullanici_soyisim);
    $shippingAddress->setCity(sehir_ad($kullanici->kullanici_sehir));
    $shippingAddress->setCountry('Türkiye');
    $shippingAddress->setAddress($kullanici->kullanici_adres);
    $shippingAddress->setZipCode($kullanici->kullanici_mail);
    $request->setShippingAddress($shippingAddress);

    $billingAddress = new \Iyzipay\Model\Address();
    $billingAddress->setContactName($kullanici->kullanici_isim." ".$kullanici->kullanici_soyisim);
    $billingAddress->setCity(sehir_ad($kullanici->kullanici_sehir));
    $billingAddress->setCountry('Türkiye');
    $billingAddress->setAddress($kullanici->kullanici_adres);
    $billingAddress->setZipCode($kullanici->kullanici_mail);
    $request->setBillingAddress($billingAddress);

    $basketItems = array();
    $firstBasketItem = new \Iyzipay\Model\BasketItem();
    $firstBasketItem->setId($siparis->bakiye_no);
    $firstBasketItem->setName('Bakiye Yükleme');
    $firstBasketItem->setCategory1('Bakiye Yükleme');
    $firstBasketItem->setCategory2('Bakiye Yükleme');
    $firstBasketItem->setItemType(\Iyzipay\Model\BasketItemType::PHYSICAL);
    $firstBasketItem->setPrice($siparis->bakiye_tutar);
    $basketItems[0] = $firstBasketItem;

    $request->setBasketItems($basketItems);

    $checkoutFormInitialize = \Iyzipay\Model\CheckoutFormInitialize::create($request, $options);
//print_r($checkoutFormInitialize->getStatus());
//print_r($checkoutFormInitialize->getErrorMessage());
    print_r($checkoutFormInitialize->getCheckoutFormContent());
    ?>

    <div class="py-lg-6 py-4 bg-primary">
        <div class="container">
            <div class="row">
                <div class="col-xl-12 col-lg-12 col-md-12 col-12">
                    <div>
                        <h1 class="text-white display-4 mb-0">Ödeme Yap</h1>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="py-6">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    
                    <div class="card  mb-4">
                        
                        <div class="card-header">
                            <h3 class="mb-0">3D Güvenli Ödeme</h3>
                        </div>
                        
                        <div class="card-body">
                            <div id="iyzipay-checkout-form" class="responsive"></div>
                            <div id="ucs-cards"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php
}else{
    // redirect(base_url());
}
if ($tat[2] == "weepay" and $site->weepay_durum == 1) {
    error_reporting(E_ALL);
    ini_set('display_errors',1);
    require_once('application/libraries/weepay/weepayBootstrap.php');

    weepayBootstrap::initialize();
    $options = new \weepay\Auth();
    $options->setBayiID($site->weepay_bayiId);
    $options->setApiKey($site->weepay_api);
    $options->setSecretKey($site->weepay_secret);
    $options->setBaseUrl("https://api.weepay.co/");

    $request = new \weepay\Request\FormInitializeRequest();
    $request->setOrderId($siparis->bakiye_no);
    $request->setIpAddress(getIPAddress());
    $request->setPrice(($siparis->bakiye_tutar + ($siparis->bakiye_tutar*$site->weepay_komisyon/100)));
    $request->setCurrency(\weepay\Model\Currency::TL);
    $request->setLocale(\weepay\Model\Locale::TR);
    $request->setDescription('Herşey Oyun Bakiye Yükleme');
    $request->setCallBackUrl(base_url('home_controller/bakiye_odeme_onay_weepay'));
    $request->setPaymentGroup(\weepay\Model\PaymentGroup::PRODUCT);
    $request->setPaymentChannel(\weepay\Model\PaymentChannel::WEB);
    //Customer
    $customer = new \weepay\Model\Customer();
    $customer->setCustomerId($kullanici->kullanici_id); // Üye işyeri müşteri Id 
    $customer->setCustomerName($kullanici->kullanici_isim); //Üye işyeri müşteri ismi 
    $customer->setCustomerSurname($kullanici->kullanici_soyisim); //Üye işyeri müşteri Soyisim
    $customer->setGsmNumber($kullanici->kullanici_tel); //Üye işyeri müşteri Cep Tel
    $customer->setEmail($kullanici->kullanici_mail); //Üye işyeri müşteri ismi 
    $customer->setIdentityNumber("74300864791"); //Üye işyeri müşteri TC numarası
    $customer->setCity(sehir_ad($kullanici->kullanici_sehir)); //Üye işyeri müşteri il
    $customer->setCountry("Türkiye");//Üye işyeri müşteri ülke
    $request->setCustomer($customer);

    // Fatura Adresi
    $BillingAddress = new \weepay\Model\Address();
    $BillingAddress->setContactName($kullanici->kullanici_isim." ".$kullanici->kullanici_soyisim);
    $BillingAddress->setAddress($kullanici->kullanici_adres);
    $BillingAddress->setCity(sehir_ad($kullanici->kullanici_sehir));
    $BillingAddress->setCountry("Türkiye");
    $request->setBillingAddress($BillingAddress);


    $basketItems = array();

    $firstBasketItem = new \weepay\Model\Product();
    $firstBasketItem->setName("Bakiye Yükleme");
    $firstBasketItem->setProductId($siparis->bakiye_no);
    $firstBasketItem->setProductPrice($siparis->bakiye_tutar);
    $firstBasketItem->setItemType(\weepay\Model\ProductType::VIRTUAL);
    $basketItems[0] = $firstBasketItem;

    $request->setProducts($basketItems);
    $checkoutFormInitialize = \weepay\Model\CheckoutFormInitialize::create($request, $options);
    ?>

    <div class="py-lg-6 py-4 bg-primary">
        <div class="container">
            <div class="row">
                <div class="col-xl-12 col-lg-12 col-md-12 col-12">
                    <div>
                        <h1 class="text-white display-4 mb-0">Ödeme Yap</h1>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="py-6">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    
                    <div class="card  mb-4">
                        
                        <div class="card-header">
                            <h3 class="mb-0">3D Güvenli Ödeme</h3>
                        </div>
                        
                        <div class="card-body">
                            <div id="weePay-checkout-form" class="responsive"><?=$checkoutFormInitialize->getCheckoutFormData()?></div>
                            <div id="ucs-cards"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php
}else{
}
if ($tat[2] == "stripe" and $site->stripe_durum == 1) {
    require_once('vendor/stripe-php-master/init.php');
    $bakiye_hatasi = '';
    if($siparis->bakiye_tutar >= 100) {
        error_reporting(E_ALL);
        ini_set("display_errors", 1);

        $stripe = new \Stripe\StripeClient($site->stripe_secret);
        $checkout_session = $stripe->checkout->sessions->create([
            'ui_mode' => 'embedded',
            'line_items' => [[
                'price_data' => [
                    'currency'=>'try',
                    'product_data'=> [
                        'name'=> "$siparis->bakiye_tutar TL Bakiye Yüklemesi" 
                    ],
                    'unit_amount'=>($siparis->bakiye_tutar + $site->stripe_komisyon)*100
                ],
                'quantity' => 1,
            ]],
            'metadata' => [
                'orderId'=>$siparis->bakiye_no
            ],
            'mode' => 'payment',
            'return_url' => base_url('kpanel_controller/bakiye_odeme_onay_stripe?session_id={CHECKOUT_SESSION_ID}'),
            'automatic_tax' => [
            'enabled' => true,
            ],
        ]);
    } else {
        $bakiye_hatasi = "Minimum Bakiye Yükleme Tutarı 100 TL'dir";
    }
    ?>
    <script src="https://js.stripe.com/v3/"></script>
    <div class="py-lg-6 py-4 bg-primary">
        <div class="container">
            <div class="row">
                <div class="col-xl-12 col-lg-12 col-md-12 col-12">
                    <div>
                        <h1 class="text-white display-4 mb-0">Ödeme Yap</h1>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="py-6">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    
                    <div class="card  mb-4">
                        
                        <div class="card-header">
                            <h3 class="mb-0">3D Güvenli Ödeme</h3>
                        </div>
                        
                        <div class="card-body">
                            <div id="stripe-checkout-form"><?= $bakiye_hatasi ?></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        const stripe = Stripe("<?= $site->stripe_api ?>");

        initialize();

        // Create a Checkout Session as soon as the page loads
        async function initialize() {
            var clientSecret = {
                clientSecret:"<?= $checkout_session->client_secret; ?>"
            }
            const checkout = await stripe.initEmbeddedCheckout(clientSecret);

            // Mount Checkout
            checkout.mount('#stripe-checkout-form');
        }
    </script>
    <?php
}else{
}

if ($tat[2] == "vallet" and $site->vallet_durum == 1) {
    
function send_post($post_url,$post_data)
{

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL,$post_url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, 1) ;
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post_data));
    curl_setopt($ch, CURLOPT_FRESH_CONNECT, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 20);
    if (defined('CURLOPT_IPRESOLVE') && defined('CURL_IPRESOLVE_V4')){ curl_setopt($ch, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4); }
    curl_setopt($ch, CURLOPT_REFERER, $_SERVER['SERVER_NAME']);

    $result_origin = curl_exec($ch);
    $response = array();
    if (curl_errno($ch))
    {
        /*Curl sırasında bir sorun oluştu*/
        $response = array(
            'status'=>'error',
            'errorMessage'=>'Curl Geçersiz bir cevap aldı'.curl_error($ch),
        );
    }
    else
    {
        /*Curl Cevabını Alın*/
        
        /*Curl Cevabını jsondan array'a dönüştür*/
        $result = json_decode($result_origin,true);
        if (is_array($result))
        {
            $response = (array) $result;
        }
        else
        {
            $response = array(
                'status'=>'error',
                'errorMessage'=>'Dönen cevap Array değildi',
            );
        }
    }
    curl_close($ch);
    return $response;
}
function hash_generate($string)
{
    $hash = base64_encode(pack('H*',sha1($string)));
    return $hash;
}
    error_reporting(E_ALL);
    ini_set('display_errors',1);
    $post_data = array(
        'userName' => $site->vallet_username,
        'password' => $site->vallet_password,
        'shopCode' => $site->vallet_shopCode,
        'productName' => 'Herşey Oyun Bakiye Yükleme',
        'productData' => array(
            array(
                'productName'=>'Herşey Oyun Bakiye Yükleme',
                'productPrice'=>$siparis->bakiye_tutar,
                'productType'=>'DIJITAL_URUN',
            )
        ),
        'productType' => 'DIJITAL_URUN',
        'productsTotalPrice' => $siparis->bakiye_tutar,
        'orderPrice' => ($siparis->bakiye_tutar + ($siparis->bakiye_tutar*$site->vallet_komisyon/100)),
        'currency' => 'TRY',
        'orderId' => $siparis->bakiye_no,
        'buyerName' => $kullanici->kullanici_isim,
        'buyerSurName' => $kullanici->kullanici_soyisim,
        'buyerGsmNo' => !empty($kullanici->kullanici_tel) ? $kullanici->kullanici_tel : '5555555555',
        'buyerIp' => $this->input->ip_address(),
        'buyerMail' => $kullanici->kullanici_mail,
        'callbackOkUrl' => base_url('odeme-basarili'),
        'callbackFailUrl' => base_url('odeme-basarisiz')
    );
    $post_data['hash'] = hash_generate($site->vallet_username.$site->vallet_password.$site->vallet_shopCode.$post_data['orderId'].$post_data['currency'].$post_data['orderPrice'].$post_data['productsTotalPrice'].$post_data['productType'].$post_data['callbackOkUrl'].$post_data['callbackFailUrl'].$site->vallet_hash);
    
    $response = send_post('https://www.vallet.com.tr/api/v1/create-payment-link',$post_data);
    $icerik = "";
    if ($response['status']=='success' && isset($response['payment_page_url']))
    {
        $icerik = "<iframe src='{$response['payment_page_url']}' style='width:100%;height:1000px;'></iframe>";
    }
    else
    {
        $icerik = "Ödeme linki üretilirken bir sorun oluştu.".json_encode($response);
    }

    ?>

    <div class="py-lg-6 py-4 bg-primary">
        <div class="container">
            <div class="row">
                <div class="col-xl-12 col-lg-12 col-md-12 col-12">
                    <div>
                        <h1 class="text-white display-4 mb-0">Ödeme Yap</h1>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="py-6">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    
                    <div class="card  mb-4">
                        
                        <div class="card-header">
                            <h3 class="mb-0">3D Güvenli Ödeme</h3>
                        </div>
                        
                        <div class="card-body">
                            <div id="weePay-checkout-form" class="responsive"><?=$icerik?></div>
                            <div id="ucs-cards"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php
}else{
}
if ($tat[3] == "paytr" and $site->paytr_durum == 1) {
    error_reporting(0);
    ## API Entegrasyon Bilgileri - Mağaza paneline giriş yaparak BİLGİ sayfasından alabilirsiniz.
    $merchant_id    = $site->paytr_merchant_id;
    $merchant_key   = $site->paytr_api;
    $merchant_salt  = $site->paytr_secret;
    #
    ## Müşterinizin sitenizde kayıtlı veya form vasıtasıyla aldığınız eposta adresi
    $email =$kullanici->kullanici_mail;
    #
    ## Tahsil edilecek tutar.
    $payment_amount = ($siparis->bakiye_tutar + ($siparis->bakiye_tutar*$site->paytr_komisyon/100))*100; //9.99 için 9.99 * 100 = 999 gönderilmelidir.
    #
    ## Sipariş numarası: Her işlemde benzersiz olmalıdır!! Bu bilgi bildirim sayfanıza yapılacak bildirimde geri gönderilir.
    $merchant_oid = $siparis->bakiye_no;
    #
    ## Müşterinizin sitenizde kayıtlı veya form aracılığıyla aldığınız ad ve soyad bilgisi
    $user_name = $kullanici->kullanici_isim." ".$kullanici->kullanici_soyisim;
    #
    ## Müşterinizin sitenizde kayıtlı veya form aracılığıyla aldığınız adres bilgisi
    $user_address = $kullanici->kullanici_adres;
    #
    ## Müşterinizin sitenizde kayıtlı veya form aracılığıyla aldığınız telefon bilgisi
    $user_phone = $kullanici->kullanici__tel;
    #
    ## Başarılı ödeme sonrası müşterinizin yönlendirileceği sayfa
    ## !!! Bu sayfa siparişi onaylayacağınız sayfa değildir! Yalnızca müşterinizi bilgilendireceğiniz sayfadır!
    ## !!! Siparişi onaylayacağız sayfa "Bildirim URL" sayfasıdır (Bakınız: 2.ADIM Klasörü).
    $merchant_ok_url = base_url('kpanel_controller/bakiye_odeme_onay_paytr');
    #
    ## Ödeme sürecinde beklenmedik bir hata oluşması durumunda müşterinizin yönlendirileceği sayfa
    ## !!! Bu sayfa siparişi iptal edeceğiniz sayfa değildir! Yalnızca müşterinizi bilgilendireceğiniz sayfadır!
    ## !!! Siparişi iptal edeceğiniz sayfa "Bildirim URL" sayfasıdır (Bakınız: 2.ADIM Klasörü).
    $merchant_fail_url = base_url('kpanel_controller/bakiye_odeme_onay_paytr');
    #
    ## Müşterinin sepet/sipariş içeriği
    $user_basket = array("Bakiye Yükleme", $siparis->bakiye_tutar);
    #
    /* ÖRNEK $user_basket oluşturma - Ürün adedine göre array'leri çoğaltabilirsiniz
    $user_basket = base64_encode(json_encode(array(
        array("Örnek ürün 1", "18.00", 1), // 1. ürün (Ürün Ad - Birim Fiyat - Adet )
        array("Örnek ürün 2", "33.25", 2), // 2. ürün (Ürün Ad - Birim Fiyat - Adet )
        array("Örnek ürün 3", "45.42", 1)  // 3. ürün (Ürün Ad - Birim Fiyat - Adet )
    )));
    */
    ############################################################################################

    ## Kullanıcının IP adresi
    if( isset( $_SERVER["HTTP_CLIENT_IP"] ) ) {
        $ip = $_SERVER["HTTP_CLIENT_IP"];
    } elseif( isset( $_SERVER["HTTP_X_FORWARDED_FOR"] ) ) {
        $ip = $_SERVER["HTTP_X_FORWARDED_FOR"];
    } else {
        $ip = $_SERVER["REMOTE_ADDR"];
    }

    ## !!! Eğer bu örnek kodu sunucuda değil local makinanızda çalıştırıyorsanız
    ## buraya dış ip adresinizi (https://www.whatismyip.com/) yazmalısınız. Aksi halde geçersiz paytr_token hatası alırsınız.
    $user_ip=$ip;
    ##

    ## İşlem zaman aşımı süresi - dakika cinsinden
    $timeout_limit = "30";

    ## Hata mesajlarının ekrana basılması için entegrasyon ve test sürecinde 1 olarak bırakın. Daha sonra 0 yapabilirsiniz.
    $debug_on = 0;

    ## Mağaza canlı modda iken test işlem yapmak için 1 olarak gönderilebilir.
    $test_mode = 0;

    $no_installment = 0; // Taksit yapılmasını istemiyorsanız, sadece tek çekim sunacaksanız 1 yapın

    ## Sayfada görüntülenecek taksit adedini sınırlamak istiyorsanız uygun şekilde değiştirin.
    ## Sıfır (0) gönderilmesi durumunda yürürlükteki en fazla izin verilen taksit geçerli olur.
    $max_installment = 0;

    $currency = "TL";

    ####### Bu kısımda herhangi bir değişiklik yapmanıza gerek yoktur. #######
    $hash_str = $merchant_id .$user_ip .$merchant_oid .$email .$payment_amount .$user_basket.$no_installment.$max_installment.$currency.$test_mode;
    $paytr_token=base64_encode(hash_hmac('sha256',$hash_str.$merchant_salt,$merchant_key,true));
    $post_vals=array(
        'merchant_id'=>$merchant_id,
        'user_ip'=>$user_ip,
        'merchant_oid'=>$merchant_oid,
        'email'=>$email,
        'payment_amount'=>$payment_amount,
        'paytr_token'=>$paytr_token,
        'user_basket'=>$user_basket,
        'debug_on'=>$debug_on,
        'no_installment'=>$no_installment,
        'max_installment'=>$max_installment,
        'user_name'=>$user_name,
        'user_address'=>$user_address,
        'user_phone'=>$user_phone,
        'merchant_ok_url'=>$merchant_ok_url,
        'merchant_fail_url'=>$merchant_fail_url,
        'timeout_limit'=>$timeout_limit,
        'currency'=>$currency,
        'test_mode'=>$test_mode
    );

    $ch=curl_init();
    curl_setopt($ch, CURLOPT_URL, "https://www.paytr.com/odeme/api/get-token");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, 1) ;
    curl_setopt($ch, CURLOPT_POSTFIELDS, $post_vals);
    curl_setopt($ch, CURLOPT_FRESH_CONNECT, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 20);

    // XXX: DİKKAT: lokal makinanızda "SSL certificate problem: unable to get local issuer certificate" uyarısı alırsanız eğer
    // aşağıdaki kodu açıp deneyebilirsiniz. ANCAK, güvenlik nedeniyle sunucunuzda (gerçek ortamınızda) bu kodun kapalı kalması çok önemlidir!
    // curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);

    $result = @curl_exec($ch);

    if(curl_errno($ch))
        die("PAYTR IFRAME connection error. err:".curl_error($ch));

    curl_close($ch);

    $result=json_decode($result,1);

    if($result['status']=='success')
        $token=$result['token'];
    else
        die("PAYTR IFRAME failed. reason:".$result['reason']);
    #########################################################################

    ?>

    <!-- Ödeme formunun açılması için gereken HTML kodlar / Başlangıç -->
    <script src="https://www.paytr.com/js/iframeResizer.min.js"></script>
    <iframe src="https://www.paytr.com/odeme/guvenli/<?php echo $token;?>" id="paytriframe" frameborder="0" scrolling="no" style="width: 100%;"></iframe>
    <script>iFrameResize({},'#paytriframe');</script>
    <!-- Ödeme formunun açılması için gereken HTML kodlar / Bitiş -->



    <?php

}else{
    //redirect(base_url());
}

?>