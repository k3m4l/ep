<?php $this->load->view('kpanel/inc/kullanici_nav', array('kullanici' => $kullanici)); ?>

<div class="pb-5 py-md-5">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-4 col-12">
                <div class="user-img-left-area">
                    <img src="<?= base_url($kullanici->kullanici_resim) ?>" alt=""/>
                    <div>
                        <?= $kullanici->kullanici_ad ?>
                    </div>
                </div>
                
                <?php $this->load->view('kpanel/inc/menu'); ?>
            </div>
            <div class="col-lg-9 col-md-8 col-12">

                <?php $teslimat_kontrol = teslimat_kontrol($siparis->siparis_no);
                if (!$teslimat_kontrol) { ?>
                    <?php /* if ($siparis->siparis_durum == 1) { ?>
                        <div class="card mb-4">
                            <div class="card-body">
                                <form action="<?= base_url('siparis-teslimat-onay/' . $siparis->siparis_no) ?>"
                                      method="post">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="alert alert-warning text-center">
                                                Sipariş teslimatınızda her hangi bir sorun yaşamadıysanız siparişinizi
                                                onaylamanız gerekmektedir.
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="form-label">Teslimat Durumu</label>
                                                <select class="form-control input-radius" id="teslimat_durum"
                                                        name="teslimat_durumu" data-width="100%" required>
                                                    <option hidden>Teslimat Durumu Seçiniz..</option>
                                                    <option value="1">Teslimatı Onaylıyorum</option>
                                                    <option value="2">Teslimat Onaylamıyorum</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group" style="margin-top: 29px !important;">
                                                <button class="btn btn-outline-success btn-block input-radius">Sipariş
                                                    Durumunu Güncelle
                                                </button>
                                            </div>
                                        </div>
                                        <div class="col-md-12 teslimat_onaysiz" style="display: none">
                                            <div class="form-group">
                                                <label class="form-label">Teslimat Onaylamama Nedeniniz?</label>
                                                <textarea class="form-control teslimat_mesaj" name="mesaj"
                                                          placeholder="Teslimat Onaylamama Nedeniniz?"></textarea>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    <?php } */ ?>
                <?php } else { ?>
                    <div class="card mb-4">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <?php if ($teslimat_kontrol->teslimat_durum == 0) { ?>
                                            <button type="button"
                                                    class="btn btn-outline-warning btn-block rounded-pill">
                                                Teslimat İtiraz Durumu Bekliyor..
                                            </button>
                                        <?php } elseif ($teslimat_kontrol->teslimat_durum == 1) { ?>
                                            <button type="button" class="btn btn-success btn-block rounded-pill">
                                                <i class="fe fe-check-circle"></i> Teslimat İtirazı Çözüldü
                                            </button>
                                        <?php } elseif ($teslimat_kontrol->teslimat_durum == 2) { ?>
                                            <button type="button" class="btn btn-danger btn-block rounded-pill">
                                                <i class="fe fe-x-circle"></i> Teslimat İtirazı Çözülemedi
                                            </button>
                                        <?php } ?>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <a href="<?= base_url('teslimat/' . $siparis->siparis_no) ?>"
                                           class="btn btn-primary btn-block input-radius">
                                            <i class="fe fe-message-square"></i> İtiraz Detayı
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php } ?>

                <div class="card mb-4">
                    <div class="row no-gutters">
                        <div class="col-md-8">
                            
                            <div class="card-body">
                                <h3 class="mb-2 text-truncate-line-2 ">
                                    <a target="_blank" href="<?= base_url($siparis->urun_seo) ?>"
                                       class="text-inherit"><?= $siparis->urun_ad ?></a>
                                </h3>
                                <!-- Row -->
                         
                                <div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 text-center">
                            <div class="card-body">
                                <span>Sipariş Tutarı</span>
                                <div class="d-flex justify-content-center">
                                    <div class="font-size-27 font-weight-bold text-primary"><?= $siparis->siparis_tutar ?></div>
                                    <span class="h3 mb-0 font-weight-bold text-primary">₺</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    
                    <div class="card-body">
                        <div class="row">
                            
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label">Alacak Kişi</label>
                                    <input class="form-control" type="text" 
                                           value="<?= $siparis->teslim_alan ?>" disabled>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label">Alınacak Yer</label>
                                    <input class="form-control" type="text" 
                                           value="<?= $siparis->teslim_yeri ?>" disabled>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label class="form-label">Bilgi</label>
                                    <textarea class="form-control" disabled><?= $siparis->bilgi ?></textarea>
                                </div>
                            </div>
                            <?php if ($siparis->siparis_durum == 1 || $siparis->siparis_durum == 2) { ?>
                                <?php if ($siparis->urun_turu == 1) { ?>
                                    <?php if ($siparis->urun_marka) { ?>
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label class="form-label">Ürün Markası</label>
                                                <input class="form-control" type="text" placeholder="Ürün Markası"
                                                       value="<?= $siparis->urun_marka ?>" disabled>
                                            </div>
                                        </div>
                                    <?php } ?>
                                <?php } elseif ($siparis->urun_turu == 2) { ?>
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label class="form-label">Sanal Ürün Bilgisi</label>
                                            <textarea class="form-control" type="text" placeholder="Sanal Ürün Bilgisi"
                                                      disabled><?= $siparis->urun_sanal_bilgi ?></textarea>
                                        </div>
                                    </div>
                                <?php } elseif ($siparis->urun_turu == 3) { ?>
                                    <div class="col-md-12 mb-3">
                                        <a href="<?= base_url('indir/' . $siparis->siparis_no) ?>"
                                           class="btn btn-success btn-block rounded-pill" data-toggle="tooltip"
                                           data-placement="top" title="İndir">
                                            <i class="fe fe-download-cloud"></i> Dosyaları İndir
                                        </a>
                                    </div>
                                <?php } ?>
                            <?php } ?>
                            <?php if ($siparis->siparis_durum == 2) { ?>
                                <div class="col-md-12 mb-3">
                                    <a href="<?= base_url('fatura/' . $siparis->siparis_no) ?>"
                                       class="btn btn-secondary btn-block rounded-pill" data-toggle="tooltip"
                                       data-placement="top" title="Fatura">
                                        <i class="fe fe-file-text"></i> Fatura
                                    </a>
                                </div>
                            <?php } ?>
                            <?php if ($siparis->siparis_durum == 3) { ?>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="form-label">Sipariş İptal</label>
                                        <textarea class="form-control" type="text" placeholder="Sipariş No"
                                                  disabled><?= $siparis->siparis_iptal ?></textarea>
                                    </div>
                                </div>
                            <?php } ?>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label">Sipariş No</label>
                                    <input class="form-control" type="text" placeholder="Sipariş No"
                                           value="<?= $siparis->siparis_no ?>" disabled>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label">Sipariş Tarihi</label>
                                    <input class="form-control" type="text" placeholder="Sipariş Tarihi"
                                           value="<?= date('d.m.Y H:m', strtotime($siparis->siparis_tarih)) ?>"
                                           disabled>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label">Ad</label>
                                    <input class="form-control" type="text" placeholder="Ad"
                                           value="<?= $siparis->siparis_ad ?>" disabled>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label">Soyad</label>
                                    <input class="form-control" type="text" placeholder="Soyad"
                                           value="<?= $siparis->siparis_soyad ?>" disabled>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label class="form-label">Telefon</label>
                                    <input class="form-control" type="text" placeholder="Telefon"
                                           value="<?= $siparis->siparis_tel ?>" disabled>
                                </div>
                            </div>
                 
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>