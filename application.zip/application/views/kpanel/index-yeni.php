<main class="k-panel-warper">
    <div class="sec-warper">
        <div class="container normal-container p-0">
            <div class="k-panel-g-warper">
                <div class="row">
                    <div class="col-xl-3 col-lg-3 col-md-12 col-sm-12 wd-none mt-3 p-0">
                        <div class="accordion accordion-flush acc-kpc-menu" id="accordionFlushExample">
                            <div class="accordion-item acc-kpc-menu-item">
                                <h2 class="accordion-header acc-kpc-menu-header" id="flush-headingOne">
                                    <button class="accordion-button collapsed acc-kpc-menu-btn" type="button"
                                            data-bs-toggle="collapse" data-bs-target="#flush-collapseOne"
                                            aria-expanded="false" aria-controls="flush-collapseOne">
                                        Hızlı Menü
                                    </button>
                                </h2>
                                <div id="flush-collapseOne" class="accordion-collapse collapse"
                                     aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
                                    <div class="accordion-body acc-kpc-menu-body">
                                        <div class="k-panel-left-navbar-warper">
                                            <div class="k-panel-left-navbar-area">
                                                <div class="nav flex-column nav-pills bg-custom-none " id="v-pills-tab"
                                                     role="tablist" aria-orientation="vertical">

                                                    <div class="gt-store">
                                                        <a href="" class="btn btn-primary settings-btn mb-3 w-100">Mağzaya
                                                            Git</a>
                                                    </div>

                                                    <button class="nav-link kpc-nav-btn w-spacial" id="my-account-tab"
                                                            data-bs-toggle="pill" data-bs-target="#my-account"
                                                            type="button"
                                                            role="tab" aria-controls="my-account"
                                                            aria-selected="true">Profilim
                                                    </button>

                                                    <button class="nav-link kpc-nav-btn w-spacial" id="orders-tab"
                                                            data-bs-toggle="pill" data-bs-target="#orders" type="button"
                                                            role="tab" aria-controls="orders"
                                                            aria-selected="false">Siparişlerim
                                                    </button>

                                                    <button class="nav-link kpc-nav-btn w-spacial" id="gold-orders-tab"
                                                            data-bs-toggle="pill" data-bs-target="#gold-orders"
                                                            type="button" role="tab" aria-controls="gold-orders"
                                                            aria-selected="false">Gold Al -
                                                        Sat
                                                    </button>

                                                    <?php if (1 == 2) { ?>
                                                        <button class="nav-link kpc-nav-btn w-spacial " id="message-tab"
                                                                data-bs-toggle="pill" data-bs-target="#message"
                                                                type="button"
                                                                role="tab" aria-controls="message" aria-selected="true">
                                                            Mesajlar
                                                        </button>
                                                    <?php } ?>


                                                    <button class="nav-link kpc-nav-btn w-spacial" id="atq-tab"
                                                            data-bs-toggle="pill" data-bs-target="#atq" type="button"
                                                            role="tab" aria-controls="atq" aria-selected="false">İlan
                                                        Sorularım
                                                    </button>


                                                    <button class="nav-link kpc-nav-btn w-spacial" id="budget-tab"
                                                            data-bs-toggle="pill" data-bs-target="#budget" type="button"
                                                            role="tab" aria-controls="budget" aria-selected="false">
                                                        Bakiye
                                                    </button>

                                                    <button class="nav-link kpc-nav-btn w-spacial" id="take-money-tab"
                                                            data-bs-toggle="pill" data-bs-target="#take-money"
                                                            type="button"
                                                            role="tab" aria-controls="take-money"
                                                            aria-selected="false">Bakiye
                                                        Çekim
                                                    </button>

                                                    <button class="nav-link kpc-nav-btn w-spacial" id="support-request-tab"
                                                            data-bs-toggle="pill" data-bs-target="#support-request"
                                                            type="button" role="tab" aria-controls="support-request"
                                                            aria-selected="false">Destek
                                                        Taleplerim
                                                    </button>

                                                    <button class="nav-link kpc-nav-btn w-spacial" id="account-settings-tab"
                                                            data-bs-toggle="pill" data-bs-target="#account-settings"
                                                            type="button" role="tab" aria-controls="account-settings"
                                                            aria-selected="false">Profil
                                                        Ayarlarım
                                                    </button>


                                                    <button class="nav-link kpc-nav-btn w-spacial" type="button"
                                                            onclick="window.location.href='<?php echo base_url('cikis') ?>'">
                                                        Çıkış
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-3 col-md-12 col-sm-12 md-none ">
                        <div class="k-panel-left-navbar-warper">
                            <div class="k-panel-left-navbar-area">
                                <div class="nav flex-column nav-pills bg-custom-none " id="v-pills-tab" role="tablist"
                                     aria-orientation="vertical">
                                   <?php if (magaza_check()) { ?>
                                        <div class="gt-store">
                                            <a href="<?php echo base_url('m/'.magaza($kullanici->kullanici_id)->magaza_seo) ?>" target="_blank" class="btn btn-primary settings-btn mb-3 w-100">Mağzaya Git</a>
                                        </div>
                                    <?php } ?>

                                    <button class="nav-link kpc-nav-btn w-spacial" id="my-account-tab" data-bs-toggle="pill"
                                            data-bs-target="#my-account" type="button" role="tab"
                                            aria-controls="my-account"
                                            aria-selected="true">Profilim
                                    </button>

                                    <button class="nav-link kpc-nav-btn w-spacial" id="orders-tab" data-bs-toggle="pill"
                                            data-bs-target="#orders" type="button" role="tab" aria-controls="orders"
                                            aria-selected="false">Siparişlerim
                                    </button>

                                    <button class="nav-link kpc-nav-btn w-spacial" id="gold-orders-tab" data-bs-toggle="pill"
                                            data-bs-target="#gold-orders" type="button" role="tab"
                                            aria-controls="gold-orders" aria-selected="false">Gold Al
                                        -
                                        Sat
                                    </button>

                                    <?php if (1 == 2) { ?>
                                        <button class="nav-link kpc-nav-btn w-spacial " id="message-tab" data-bs-toggle="pill"
                                                data-bs-target="#message" type="button" role="tab"
                                                aria-controls="message"
                                                aria-selected="true">Mesajlar
                                        </button>
                                    <?php } ?>


                                    <button class="nav-link kpc-nav-btn w-spacial" id="atq-tab" data-bs-toggle="pill"
                                            data-bs-target="#atq" type="button" role="tab" aria-controls="atq"
                                            aria-selected="false">Sorularım
                                    </button>


                                    <button class="nav-link kpc-nav-btn w-spacial" id="budget-tab" data-bs-toggle="pill"
                                            data-bs-target="#budget" type="button" role="tab" aria-controls="budget"
                                            aria-selected="false">Bakiye
                                    </button>

                                    <button class="nav-link kpc-nav-btn w-spacial" id="take-money-tab" data-bs-toggle="pill"
                                            data-bs-target="#take-money" type="button" role="tab"
                                            aria-controls="take-money"
                                            aria-selected="false">Bakiye
                                        Çekim
                                    </button>

                                    <button class="nav-link kpc-nav-btn w-spacial" id="support-request-tab" data-bs-toggle="pill"
                                            data-bs-target="#support-request" type="button" role="tab"
                                            aria-controls="support-request" aria-selected="false">Destek
                                        Taleplerim
                                    </button>

                                    <button class="nav-link kpc-nav-btn w-spacial" id="account-settings-tab" data-bs-toggle="pill"
                                            data-bs-target="#account-settings" type="button" role="tab"
                                            aria-controls="account-settings" aria-selected="false">Profil
                                        Ayarlarım
                                    </button>

                                    <button class="nav-link kpc-nav-btn w-spacial" type="button"
                                            onclick="window.location.href='<?php echo base_url('cikis') ?>'">Çıkış
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-9 col-lg-9 col-md-12 col-sm-12">
                        <div class="k-panel-content-right">
                            <div class="tab-content" id="v-pills-tabContent">
                                <div class="tab-pane fade show active" id="my-account" role="tabpanel"
                                     aria-labelledby="my-account-tab" tabindex="0">
                                    <div class="container-fluid">
                                        <div class="k-panel-content-box">
                                            <div class="row">
                                                <div class="col-12">
                                                    <div class="kpc-tt">
                                                        <i class="fa-solid fa-user"></i> Profilim
                                                    </div>
                                                    <div class="pt-area">
                                                        <?php if (1 == 2) { ?>
                                                        <div class="row">
                                                            <div class="col-6">
                                                                <?php if (!empty($siparislerim)) { ?>
                                                                    <?php foreach ($siparislerim as $key => $val) { ?>

                                                                        <div class="purchase-card"
                                                                             style="width: 100% !important;">
                                                                            <div class="purchase-card-bg"
                                                                                 style="background-image: url(https://kemalellidort.com.tr/assets/images/valorant-313.png);background-size: cover !important;background-position: center;">
                                                                            </div>
                                                                            <div class="purchase-body">
                                                                                <div class="ProductImage"
                                                                                     style="background: url(<?php echo base_url($val->urun_resim_min) ?>);">
                                                                                </div>
                                                                                <div class="ProductName">
                                                                                    <?php echo $val->urun_ad ?>
                                                                                </div>
                                                                                <div class="DeliveredTime">
                                                                                    <?php echo date("d.m.Y", strtotime($val->siparis_tarih)) ?>
                                                                                </div>
                                                                                <?php if ($val->siparis_durum == 1) { ?>
                                                                                    <div class="topupDiv">
                                                                                        <div class="topupStatus status-1">
                                                                                            <i
                                                                                                    class="fas fa-circle"></i><span>Sipariş
                                                                                        Bekliyor</span>
                                                                                        </div>
                                                                                        <div class="pre-order-description">
                                                                                            Bu
                                                                                            sipariş bir ön
                                                                                            sipariş olarak
                                                                                            oluşturulmuştur,
                                                                                            Ürününüz en kısa sürede
                                                                                            hazırlanıp
                                                                                            size
                                                                                            iletilecektir.
                                                                                        </div>
                                                                                    </div>
                                                                                <?php } else if ($val->siparis_durum == 3) { ?>
                                                                                    <div class="topupDiv">
                                                                                        <div class="topupStatus status-4">
                                                                                            <i
                                                                                                    class="fas fa-circle"></i><span>Sipariş
                                                                                        iptal edildi</span>
                                                                                        </div>
                                                                                        <div class="pre-order-description">
                                                                                            Bu
                                                                                            sipariş bir ön
                                                                                            sipariş olarak
                                                                                            oluşturulmuştur,
                                                                                            Ürününüz en kısa sürede
                                                                                            hazırlanıp
                                                                                            size
                                                                                            iletilecektir.
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="pre-order-description pre-order-cancel">
                                                                                        <?php echo $val->siparis_iptal ?>
                                                                                    </div>
                                                                                <?php } else if ($val->siparis_durum == 2) { ?>
                                                                                    <?php
                                                                                    $tempHTML = '';
                                                                                    if ($val->urun_turu == 1) {
                                                                                        $metin = $val->siparis_key;
                                                                                        $satirlar = explode("\n", $metin);

                                                                                        foreach ($satirlar as $satir) {
                                                                                            $parcalar = explode(':', $satir);
                                                                                            if (count($parcalar) === 2) {
                                                                                                $etiket = trim($parcalar[0]);
                                                                                                $deger = trim($parcalar[1]);
                                                                                                if (strtolower($etiket) === "id") {
                                                                                                    $tempHTML .= '<div class="KeyDiv">' .
                                                                                                        '<button class="btn btn-default btn-sm btn-copy-password copy-to-clipboard" type="button" data-clipboard-text="' . $deger . '"><i class="fas fa-copy"></i></button>' .
                                                                                                        '<input id="Code' . $val->siparis_id . '" type="password" class="PurchaseKey" value="ID:' . $deger . '" readonly="">' .
                                                                                                        '<button data-id="Code' . $val->siparis_id . '" data-code="' . $val->siparis_id . '" class="btn btn-default btn-sm btn-hide-password" type="button" onclick="HideShowPasswordInput(this)"><i class="fas fa-low-vision"></i></button>' .
                                                                                                        '</div>';
                                                                                                } elseif (strtolower($etiket) === "key") {
                                                                                                    $tempHTML .= '<div class="KeyDiv">' .
                                                                                                        '<button class="btn btn-default btn-sm btn-copy-password copy-to-clipboard" type="button" data-clipboard-text="' . $deger . '"><i class="fas fa-copy"></i></button>' .
                                                                                                        '<input id="Code' . $val->siparis_id . '" type="password" class="PurchaseKey" value="KEY:' . $deger . '" readonly="">' .
                                                                                                        '<button data-id="Code' . $val->siparis_id . '" data-code="' . $val->siparis_id . '" class="btn btn-default btn-sm btn-hide-password" type="button" onclick="HideShowPasswordInput(this)"><i class="fas fa-low-vision"></i></button>' .
                                                                                                        '</div>';
                                                                                                }
                                                                                            }
                                                                                        }
                                                                                    } else {
                                                                                        $tempHTML .= '<div class="KeyDiv">' .
                                                                                            '<button class="btn btn-default btn-sm btn-copy-password copy-to-clipboard" type="button" data-clipboard-text="' . $val->siparis_key . '"><i class="fas fa-copy"></i></button>' .
                                                                                            '<input id="Code' . $val->siparis_id . '" type="password" class="PurchaseKey" value="' . $val->siparis_key . '" readonly="">' .
                                                                                            '<button data-id="Code' . $val->siparis_id . '" data-code="' . $val->siparis_id . '" class="btn btn-default btn-sm btn-hide-password" type="button" onclick="HideShowPasswordInput(this)"><i class="fas fa-low-vision"></i></button>' .
                                                                                            '</div>';
                                                                                    }

                                                                                    echo $tempHTML;
                                                                                    ?>

                                                                                <?php } ?>
                                                                                <div class="TotalPaid"><b>Ödenen
                                                                                        Ücret: </b>
                                                                                    <?php echo $val->siparis_tutar ?>
                                                                                    <price>₺</price>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    <?php } ?>
                                                                <?php } else { ?>
                                                                    <div class="alert alert-warning" role="alert">
                                                                        Satın Aldığınız Ürün Bulunmamaktadır!!
                                                                    </div>
                                                                <?php } ?>
                                                            </div>
                                                        </div>
                                                        <?php } ?>

                                                        <?php if (1 == 2) { ?>
                                                            <div class="card mb-4">
                                                                
                                                                <div class="card-header border-bottom-0">
                                                                    <h3 class="h4 mb-3">Son 5 Siparişlerim</h3>
                                                                </div>
                                                                
                                                                <div class="table-responsive border-0">
                                                                    <?php if (1 == 2) { ?>
                                                                        <table
                                                                                class="table mb-0 text-nowrap dark-table light-table">
                                                                            <thead>
                                                                            <tr>
                                                                                <th class="border-0">Sipariş No
                                                                                </th>
                                                                                <th class="border-0">Durum</th>
                                                                                <th class="border-0">Tutar</th>
                                                                                <th class="border-0">Tarih</th>
                                                                                <th class="border-0"></th>
                                                                            </tr>
                                                                            </thead>
                                                                            <tbody>
                                                                            <?php if ($siparislerim) {
                                                                                foreach ($siparislerim as $siparis) { ?>
                                                                                    <tr>
                                                                                        <td class="align-middle border-top-0">
                                                                                            <a data-toggle="tooltip"
                                                                                               data-placement="top"
                                                                                               title="Sipariş Detayı"
                                                                                               href="<?= base_url('siparis-detay/' . $siparis->siparis_no) ?>">#<?= $siparis->siparis_no ?></a>
                                                                                        </td>
                                                                                        <td class="align-middle border-top-0">
                                                                                            <?php if ($siparis->siparis_durum == 0) { ?>
                                                                                                <a target="_blank"
                                                                                                   href="<?= base_url('odeme/' . $siparis->siparis_no) ?>"
                                                                                                   class="badge badge-warning">Ödeme
                                                                                                    Yapılmadı..</a>
                                                                                            <?php } elseif ($siparis->siparis_durum == 1) { ?>
                                                                                                <a href="javascript:void(0)"
                                                                                                   class="badge badge-secondary"
                                                                                                   data-toggle="modal"
                                                                                                   data-target="#odeme_onay_<?= $siparis->siparis_id ?>">Teslimatı
                                                                                                    Onaylayın
                                                                                                </a>
                                                                                            <?php } elseif ($siparis->siparis_durum == 2) { ?>
                                                                                                <span class="badge badge-success">Ödeme
                                                                                    Yapıldı</span>
                                                                                            <?php } elseif ($siparis->siparis_durum == 3) { ?>
                                                                                                <span data-toggle="tooltip"
                                                                                                      data-placement="top"
                                                                                                      title="<?= $siparis->siparis_iptal ?>"
                                                                                                      class="badge badge-danger">Sipariş
                                                                                    İptal Edildi</span>
                                                                                            <?php } ?>
                                                                                        </td>
                                                                                        <td class="align-middle border-top-0">
                                                                                            <?= $siparis->siparis_tutar ?>
                                                                                            ₺
                                                                                        </td>
                                                                                        <td class="align-middle border-top-0">
                                                                                            <?= date('d.m.Y H:m', strtotime($siparis->siparis_tarih)) ?>
                                                                                        </td>
                                                                                        <td class="align-middle border-top-0">
                                                                                            <a href="<?= base_url('siparis-detay/' . $siparis->siparis_no) ?>"
                                                                                               class="btn btn-primary btn-sm"
                                                                                               data-toggle="tooltip"
                                                                                               data-placement="top"
                                                                                               title="Görüntüle">
                                                                                                <i class="fe fe-eye"></i>
                                                                                            </a>
                                                                                            <?php if ($siparis->siparis_durum == 2) { ?>
                                                                                                <a href="<?= base_url('fatura/' . $siparis->siparis_no) ?>"
                                                                                                   class="btn btn-secondary btn-sm"
                                                                                                   data-toggle="tooltip"
                                                                                                   data-placement="top"
                                                                                                   title="Fatura">
                                                                                                    <i class="fe fe-file-text"></i>
                                                                                                </a>
                                                                                                <a href="javascript:void(0)"
                                                                                                   data-toggle="modal"
                                                                                                   data-target="#yorum_<?= $siparis->siparis_id ?>"
                                                                                                   class="btn btn-warning btn-sm"
                                                                                                   data-toggle="tooltip"
                                                                                                   data-placement="top"
                                                                                                   title="Değerlendir">
                                                                                                    <i
                                                                                                            class="text-light fe fe-star"></i>
                                                                                                </a>
                                                                                            <?php } ?>
                                                                                            <?php if ($siparis->urun_turu == 3) {
                                                                                                if ($siparis->siparis_durum == 1 || $siparis->siparis_durum == 2) { ?>
                                                                                                    <a href="<?= base_url('indir/' . $siparis->siparis_no) ?>"
                                                                                                       class="btn btn-success btn-sm"
                                                                                                       data-toggle="tooltip"
                                                                                                       data-placement="top"
                                                                                                       title="İndir">
                                                                                                        <i class="fe fe-download-cloud"></i>
                                                                                                    </a>
                                                                                                <?php }
                                                                                            } ?>

                                                                                        </td>
                                                                                    </tr>
                                                                                    <?php if ($siparis->siparis_durum == 1) { ?>
                                                                                        <div class="modal fade"
                                                                                             id="odeme_onay_<?= $siparis->siparis_id ?>"
                                                                                             tabindex="-1" role="dialog"
                                                                                             aria-labelledby="exampleModalLabel"
                                                                                             aria-hidden="true">
                                                                                            <div class="modal-dialog modal-dialog-centered"
                                                                                                 role="document">
                                                                                                <div class="modal-content">
                                                                                                    <div class="modal-header">
                                                                                                        <h5 class="modal-title"
                                                                                                            id="exampleModalLabel">
                                                                                                            Teslimat
                                                                                                            Onay
                                                                                                            Bilgilendirme
                                                                                                        </h5>
                                                                                                        <button type="button"
                                                                                                                class="close"
                                                                                                                data-dismiss="modal"
                                                                                                                aria-label="Close">
                                                                                            <span
                                                                                                    aria-hidden="true">&times;</span>
                                                                                                        </button>
                                                                                                    </div>
                                                                                                    <div class="modal-body text-center">
                                                                                        <span
                                                                                                class="badge badge-warning mb-2">SİPARİŞ
                                                                                            NO :
                                                                                            <?= $siparis->siparis_no ?></span>
                                                                                                        <p class="text-center">
                                                                                                            Teslimatta
                                                                                                            her
                                                                                                            hangi bir
                                                                                                            sıkıntı
                                                                                                            yaşamadıysanız
                                                                                                            satıcının
                                                                                                            ödemesini
                                                                                                            onaylamanız
                                                                                                            gerekmektedir!
                                                                                                            Onaylamadığınız
                                                                                                            taktirde
                                                                                                            sistem
                                                                                                            otomatik
                                                                                                            olarak
                                                                                                            <span
                                                                                                                    class="badge badge-success badge-pill">1
                                                                                                gün</span>
                                                                                                            sonra
                                                                                                            onaylayacaktır.
                                                                                                            Teslimatı
                                                                                                            onaylamak
                                                                                                            için
                                                                                                            sipariş
                                                                                                            detayına
                                                                                                            gidin.
                                                                                                        </p>
                                                                                                        <a href="<?= base_url('siparis-detay/' . $siparis->siparis_no) ?>"
                                                                                                           class="btn btn-outline-primary btn-block input-radius"><i
                                                                                                                    class="fe fe-eye"></i>
                                                                                                            Sipariş
                                                                                                            Detayı</a>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                    <?php } ?>
                                                                                    <?php if ($siparis->siparis_durum == 2) { ?>
                                                                                        <div class="modal fade"
                                                                                             id="yorum_<?= $siparis->siparis_id ?>"
                                                                                             tabindex="-1" role="dialog"
                                                                                             aria-labelledby="exampleModalLabel"
                                                                                             aria-hidden="true">
                                                                                            <div class="modal-dialog modal-dialog-centered"
                                                                                                 role="document">
                                                                                                <div class="modal-content">
                                                                                                    <div class="modal-header">
                                                                                                        <h5 class="modal-title"
                                                                                                            id="exampleModalLabel">
                                                                                                            Siparişi
                                                                                                            Değerlendirin
                                                                                                        </h5>
                                                                                                        <button type="button"
                                                                                                                class="close"
                                                                                                                data-dismiss="modal"
                                                                                                                aria-label="Close">
                                                                                            <span
                                                                                                    aria-hidden="true">&times;</span>
                                                                                                        </button>
                                                                                                    </div>
                                                                                                    <div class="modal-body text-center">
                                                                                                        <?php if (yorum_kontrol($kullanici->kullanici_id, $siparis->siparis_no) != 0) {
                                                                                                            $yorum = yorum($kullanici->kullanici_id, $siparis->siparis_no); ?>
                                                                                                            <?php if ($yorum->yorum_durum == 0) { ?>
                                                                                                                <button
                                                                                                                        class="btn btn-outline-warning btn-block rounded-pill">
                                                                                                                    Onay
                                                                                                                    Bekleniyor..
                                                                                                                </button>
                                                                                                            <?php } elseif ($yorum->yorum_durum == 1) { ?>
                                                                                                                <button
                                                                                                                        class="btn btn-success btn-block rounded-pill">
                                                                                                                    Değerlendirme
                                                                                                                    Yayınlandı
                                                                                                                </button>
                                                                                                            <?php } elseif ($yorum->yorum_durum == 2) { ?>
                                                                                                                <button
                                                                                                                        class="btn btn-danger btn-block rounded-pill">
                                                                                                                    Onaylanmadı
                                                                                                                </button>
                                                                                                            <?php } ?>
                                                                                                            <div
                                                                                                                    id="full-stars-example-two">
                                                                                                                <div class="rating-group">
                                                                                                                    <input
                                                                                                                            class="rating__input rating__input--none"
                                                                                                                            name="puan"
                                                                                                                            id="rating3-none"
                                                                                                                            value="0"
                                                                                                                            type="radio"
                                                                                                                        <?php if ($yorum->yorum_durum == 0) {
                                                                                                                            echo 'checked';
                                                                                                                        } ?>
                                                                                                                            disabled>
                                                                                                                    <label
                                                                                                                            aria-label="1 star"
                                                                                                                            class="rating__label"
                                                                                                                            for="rating3-1"><i
                                                                                                                                class="rating__icon rating__icon--star fa fa-star"></i></label>
                                                                                                                    <input
                                                                                                                            class="rating__input"
                                                                                                                            name="puan"
                                                                                                                            id="rating3-1"
                                                                                                                            value="1"
                                                                                                                            type="radio"
                                                                                                                        <?php if ($yorum->yorum_puan == 1) {
                                                                                                                            echo 'checked';
                                                                                                                        } ?>
                                                                                                                            disabled>
                                                                                                                    <label
                                                                                                                            aria-label="2 stars"
                                                                                                                            class="rating__label"
                                                                                                                            for="rating3-2"><i
                                                                                                                                class="rating__icon rating__icon--star fa fa-star"></i></label>
                                                                                                                    <input
                                                                                                                            class="rating__input"
                                                                                                                            name="puan"
                                                                                                                            id="rating3-2"
                                                                                                                            value="2"
                                                                                                                            type="radio"
                                                                                                                        <?php if ($yorum->yorum_puan == 2) {
                                                                                                                            echo 'checked';
                                                                                                                        } ?>
                                                                                                                            disabled>
                                                                                                                    <label
                                                                                                                            aria-label="3 stars"
                                                                                                                            class="rating__label"
                                                                                                                            for="rating3-3"><i
                                                                                                                                class="rating__icon rating__icon--star fa fa-star"></i></label>
                                                                                                                    <input
                                                                                                                            class="rating__input"
                                                                                                                            name="puan"
                                                                                                                            id="rating3-3"
                                                                                                                            value="3"
                                                                                                                            type="radio"
                                                                                                                        <?php if ($yorum->yorum_puan == 3) {
                                                                                                                            echo 'checked';
                                                                                                                        } ?>
                                                                                                                            disabled>
                                                                                                                    <label
                                                                                                                            aria-label="4 stars"
                                                                                                                            class="rating__label"
                                                                                                                            for="rating3-4"><i
                                                                                                                                class="rating__icon rating__icon--star fa fa-star"></i></label>
                                                                                                                    <input
                                                                                                                            class="rating__input"
                                                                                                                            name="puan"
                                                                                                                            id="rating3-4"
                                                                                                                            value="4"
                                                                                                                            type="radio"
                                                                                                                        <?php if ($yorum->yorum_puan == 4) {
                                                                                                                            echo 'checked';
                                                                                                                        } ?>
                                                                                                                            disabled>
                                                                                                                    <label
                                                                                                                            aria-label="5 stars"
                                                                                                                            class="rating__label"
                                                                                                                            for="rating3-5"><i
                                                                                                                                class="rating__icon rating__icon--star fa fa-star"></i></label>
                                                                                                                    <input
                                                                                                                            class="rating__input"
                                                                                                                            name="puan"
                                                                                                                            id="rating3-5"
                                                                                                                            value="5"
                                                                                                                            type="radio"
                                                                                                                        <?php if ($yorum->yorum_puan == 5) {
                                                                                                                            echo 'checked';
                                                                                                                        } ?>
                                                                                                                            disabled>
                                                                                                                </div>
                                                                                                            </div>
                                                                                                            <div class="form-group">
                                                                                                                <label>Yorumunuz
                                                                                                                    <small>(İsteğe
                                                                                                                        Bağlı)</small></label>
                                                                                                                <textarea
                                                                                                                        class="form-control"
                                                                                                                        rows="5"
                                                                                                                        placeholder="Yorumunuz.."
                                                                                                                        disabled><?= $yorum->yorum_detay ?></textarea>
                                                                                                            </div>

                                                                                                        <?php } else { ?>
                                                                                                            <form
                                                                                                                    action="<?= base_url('yorum-yap/' . $siparis->siparis_no) ?>"
                                                                                                                    method="post">
                                                                                                                <div
                                                                                                                        id="full-stars-example-two">
                                                                                                                    <div
                                                                                                                            class="rating-group">
                                                                                                                        <input checked
                                                                                                                               class="rating__input rating__input--none"
                                                                                                                               name="puan"
                                                                                                                               id="rating3-none"
                                                                                                                               value="0"
                                                                                                                               type="radio">
                                                                                                                        <label
                                                                                                                                aria-label="1 star"
                                                                                                                                class="rating__label"
                                                                                                                                for="rating3-1-<?= $siparis->siparis_id ?>"><i
                                                                                                                                    class="rating__icon rating__icon--star fa fa-star"></i></label>
                                                                                                                        <input
                                                                                                                                class="rating__input"
                                                                                                                                name="puan"
                                                                                                                                id="rating3-1-<?= $siparis->siparis_id ?>"
                                                                                                                                value="1"
                                                                                                                                type="radio">
                                                                                                                        <label
                                                                                                                                aria-label="2 stars"
                                                                                                                                class="rating__label"
                                                                                                                                for="rating3-2-<?= $siparis->siparis_id ?>"><i
                                                                                                                                    class="rating__icon rating__icon--star fa fa-star"></i></label>
                                                                                                                        <input
                                                                                                                                class="rating__input"
                                                                                                                                name="puan"
                                                                                                                                id="rating3-2-<?= $siparis->siparis_id ?>"
                                                                                                                                value="2"
                                                                                                                                type="radio">
                                                                                                                        <label
                                                                                                                                aria-label="3 stars"
                                                                                                                                class="rating__label"
                                                                                                                                for="rating3-3-<?= $siparis->siparis_id ?>"><i
                                                                                                                                    class="rating__icon rating__icon--star fa fa-star"></i></label>
                                                                                                                        <input
                                                                                                                                class="rating__input"
                                                                                                                                name="puan"
                                                                                                                                id="rating3-3-<?= $siparis->siparis_id ?>"
                                                                                                                                value="3"
                                                                                                                                type="radio">
                                                                                                                        <label
                                                                                                                                aria-label="4 stars"
                                                                                                                                class="rating__label"
                                                                                                                                for="rating3-4-<?= $siparis->siparis_id ?>"><i
                                                                                                                                    class="rating__icon rating__icon--star fa fa-star"></i></label>
                                                                                                                        <input
                                                                                                                                class="rating__input"
                                                                                                                                name="puan"
                                                                                                                                id="rating3-4-<?= $siparis->siparis_id ?>"
                                                                                                                                value="4"
                                                                                                                                type="radio">
                                                                                                                        <label
                                                                                                                                aria-label="5 stars"
                                                                                                                                class="rating__label"
                                                                                                                                for="rating3-5-<?= $siparis->siparis_id ?>"><i
                                                                                                                                    class="rating__icon rating__icon--star fa fa-star"></i></label>
                                                                                                                        <input
                                                                                                                                class="rating__input"
                                                                                                                                name="puan"
                                                                                                                                id="rating3-5-<?= $siparis->siparis_id ?>"
                                                                                                                                value="5"
                                                                                                                                type="radio">
                                                                                                                    </div>
                                                                                                                </div>
                                                                                                                <div class="form-group">
                                                                                                                    <label>Yorumunuz
                                                                                                                        <small>(İsteğe
                                                                                                                            Bağlı)</small></label>
                                                                                                                    <textarea
                                                                                                                            name="yorum"
                                                                                                                            class="form-control"
                                                                                                                            rows="5"
                                                                                                                            placeholder="Yorumunuz.."></textarea>
                                                                                                                </div>
                                                                                                                <button type="submit"
                                                                                                                        class="btn btn-outline-primary btn-block input-radius">
                                                                                                                    <i
                                                                                                                            class="fe fe-comment"></i>
                                                                                                                    Yorumu
                                                                                                                    Paylaş
                                                                                                                </button>
                                                                                                            </form>
                                                                                                        <?php } ?>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                    <?php } ?>
                                                                                <?php }
                                                                            } else { ?>
                                                                                <tr>
                                                                                    <td colspan="6" align="center">
                                                                                        <div
                                                                                                class="notification warning closeable">
                                                                                            <p>Sipariş Bulunamadı
                                                                                            </p>
                                                                                        </div>
                                                                                    </td>
                                                                                </tr>
                                                                            <?php } ?>
                                                                            </tbody>
                                                                        </table>
                                                                    <?php } ?>
                                                                </div>
                                                            </div>
                                                        <?php } ?>
                                                        <div class="panel-body ">
                                                            <div class="flexCard k-panel-content-box">
                                                                <div class="userAvatar kpc-user-avatar">
                                                                    <?php if (strpos($kullanici->kullanici_resim, "/.jpg") !== false) { ?>
                                                                        <img class="kpc-user-avatar-item" src="https://ui-avatars.com/api/?name=<?= $kullanici->kullanici_isim ?>+<?= $kullanici->kullanici_soyisim ?>&background=0D8ABC&color=fff" title="<?php echo $kullanici->kullanici_isim ?>" alt="<?php echo $kullanici->kullanici_isim ?>">
                                                                    <?php } else { ?>
                                                                        <img class="kpc-user-avatar-item" src="<?php echo base_url($kullanici->kullanici_resim) ?>" title="<?php echo $kullanici->kullanici_isim ?>" alt="<?php echo $kullanici->kullanici_isim ?>">
                                                                    <?php } ?>
                                                                </div>
                                                                <div class="userDetails userDetails-kpc">
                                                                    <h1><?php echo $kullanici->kullanici_ad ?>
                                                                       <?php if (magaza_check()) { ?>
                                                                        <a href="javascript:void(0)"
                                                                           class="top-0 right-0" data-toggle="tooltip"
                                                                           data-placement="top" title=""
                                                                           data-original-title="Doğrulanmış Mağaza">
                                                                            <img src="https://kemalellidort.com.tr/assets/front/images/checked-mark.svg"
                                                                                 alt="" height="30" width="30">
                                                                        </a>
                                                                       <?php } ?>
                                                                    </h1>
                                                                    <div class="email-area-pfb">
                                                                        <span><?php echo $kullanici->kullanici_mail ?></span>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="k-panel-content-box">
                                                                <div class="row">
                                                                    <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 mb-3">
                                                                        <div class="card">
                                                                            <div class="card-content">
                                                                                <div class="card-body mh-85 bc-22">
                                                                                    <div class="card-img-body">
                                                                                        <div class="media  ">
                                                                                            <div class="card-img-body-warper">
                                                                                                <img class="card-img-body-icon"
                                                                                                     src="https://kemalellidort.com.tr/assets/images/money-bag.png "
                                                                                                     alt="">
                                                                                            </div>
                                                                                            <div class="media-body text-right-c">
                                                                                                <h3><?php echo $siparis_say ?></h3>
                                                                                                <span>Siparişlerim</span>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 mb-3">
                                                                        <div class="card">
                                                                            <div class="card-content">
                                                                                <div class="card-body mh-85 bc-22">
                                                                                    <div class="card-img-body">
                                                                                        <div class="media  ">
                                                                                            <div class="card-img-body-warper">
                                                                                                <img class="card-img-body-icon"
                                                                                                     src="https://kemalellidort.com.tr/assets/images/ty6.png "
                                                                                                     alt="">
                                                                                            </div>
                                                                                            <div class="media-body text-right-c">
                                                                                                <h3><?php echo $aldigim_gold_count ?></h3>
                                                                                                <span>Satın Aldığım Gold</span>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 mb-3">
                                                                        <div class="card">
                                                                            <div class="card-content">
                                                                                <div class="card-body mh-85 bc-22">
                                                                                    <div class="card-img-body">
                                                                                        <div class="media  ">
                                                                                            <div class="card-img-body-warper">
                                                                                                <img class="card-img-body-icon"
                                                                                                     src="https://kemalellidort.com.tr/assets/images/ty7.png "
                                                                                                     alt="">
                                                                                            </div>
                                                                                            <div class="media-body text-right-c">
                                                                                                <h3><?php echo $sattigim_gold_count ?></h3>
                                                                                                <span>Sattığım Gold</span>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 mb-3">
                                                                        <div class="card">
                                                                            <div class="card-content">
                                                                                <div class="card-body mh-85 bc-22">
                                                                                    <div class="card-img-body">
                                                                                        <div class="media  ">
                                                                                            <div class="card-img-body-warper">
                                                                                                <img class="card-img-body-icon"
                                                                                                     src="https://kemalellidort.com.tr/assets/images/reconciliation.png "
                                                                                                     alt="">
                                                                                            </div>
                                                                                            <div class="media-body text-right-c">
                                                                                                <h3><?php echo $odenebilir_kazanclar ?></h3>
                                                                                                <span>Çekilebilir Kazanç</span>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 mb-3">
                                                                        <div class="card">
                                                                            <div class="card-content">
                                                                                <div class="card-body mh-85 bc-22">
                                                                                    <div class="card-img-body">
                                                                                        <div class="media  ">
                                                                                            <div class="card-img-body-warper">
                                                                                                <img class="card-img-body-icon"
                                                                                                     src="https://kemalellidort.com.tr/assets/images/ty1.png "
                                                                                                     alt="">
                                                                                            </div>
                                                                                            <div class="media-body text-right-c">
                                                                                                <h3><?php echo $kullanici->bakiye ?></h3>
                                                                                                <span>Bakiye</span>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 mb-3">
                                                                        <div class="card">
                                                                            <div class="card-content">
                                                                                <div class="card-body mh-85 bc-22">
                                                                                    <div class="card-img-body">
                                                                                        <div class="media  ">
                                                                                            <div class="card-img-body-warper">
                                                                                                <img class="card-img-body-icon"
                                                                                                     src="https://kemalellidort.com.tr/assets/images/ty2.png "
                                                                                                     alt="">
                                                                                            </div>
                                                                                            <div class="media-body text-right-c">
                                                                                                <h3><?php echo $destek_talep_count ?></h3>
                                                                                                <span>Destek Taleplerim</span>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="tab-pane fade" id="budget" role="tabpanel" aria-labelledby="budget-tab"
                                     tabindex="0">
                                    <div class="container-fluid">
                                        <div class="k-panel-content-box">
                                            <div class="row">
                                                <div class="col-12 control-panel">
                                                    <div class="pb-5 py-md-5">
                                                        <div class="col-12">
                                                            <!-- <h4 class="title mb-5">Bakiye Yükleyin</h4> -->
                                                            <ul class="nav nav-pills balance-tab mb-3"
                                                                id="pills-tab" role="tablist">
                                                                <li class="nav-item" role="presentation">
                                                                    <button class="nav-link active"
                                                                            id="pills-home-tab" data-bs-toggle="pill"
                                                                            data-bs-target="#payment-1" type="button"
                                                                            role="tab" aria-controls="payment-1"
                                                                            aria-selected="true"><i
                                                                                class="fas fa-bars"></i></button>
                                                                    <div class="title-filter-tab-link">Tüm
                                                                        Ödeme
                                                                        Yöntemleri
                                                                    </div>
                                                                </li>
                                                                <li class="nav-item" role="presentation">
                                                                    <button class="nav-link" id="pills-profile-tab"
                                                                            data-bs-toggle="pill"
                                                                            data-bs-target="#payment-2" type="button"
                                                                            role="tab" aria-controls="payment-2"
                                                                            aria-selected="false"><i
                                                                                class="far fa-credit-card"></i></button>
                                                                    <div class="title-filter-tab-link">Kradi
                                                                        Kartı
                                                                    </div>
                                                                </li>
                                                                <li class="nav-item" role="presentation">
                                                                    <button class="nav-link" id="pills-contact-tab"
                                                                            data-bs-toggle="pill"
                                                                            data-bs-target="#payment-3" type="button"
                                                                            role="tab" aria-controls="payment-3"
                                                                            aria-selected="false"><i
                                                                                class="fas fa-globe-americas"></i>
                                                                    </button>
                                                                    <div class="title-filter-tab-link">Yurt
                                                                        Dışı Kredi
                                                                        veya Banka
                                                                    </div>
                                                                </li>
                                                                <li class="nav-item" role="presentation">
                                                                    <button class="nav-link" id="pills-contact-tab"
                                                                            data-bs-toggle="pill"
                                                                            data-bs-target="#payment-4" type="button"
                                                                            role="tab" aria-controls="payment-4"
                                                                            aria-selected="false"><i
                                                                                class="fas fa-university"></i></button>
                                                                    <div class="title-filter-tab-link">Banka
                                                                        ve Havale
                                                                    </div>
                                                                </li>
                                                                <li class="nav-item" role="presentation">
                                                                    <button class="nav-link" id="pills-contact-tab"
                                                                            data-bs-toggle="pill"
                                                                            data-bs-target="#payment-5" type="button"
                                                                            role="tab" aria-controls="payment-5"
                                                                            aria-selected="false"><i
                                                                                class="fas fa-wallet"></i>
                                                                    </button>
                                                                    <div class="title-filter-tab-link">
                                                                        Cüzdan ve Hediye
                                                                    </div>
                                                                </li>
                                                            </ul>
                                                            <div class="tab-content" id="pills-tabContent">
                                                                <div class="tab-pane fade show active"
                                                                     id="payment-1" role="tabpanel"
                                                                     aria-labelledby="pills-home-tab">
                                                                    <ul class="PaymentTypes" id="paymentTypes">
                                                                        <?php if ($ayarlar->paytr_durum == '1'): ?>
                                                                            <li id="paytr">
                                                                                <tip>Kredi</tip>
                                                                                <div class="paymentImage">
                                                                                    <img
                                                                                            src="<?php echo base_url('assets/images/stripe.png') ?>">
                                                                                </div>
                                                                                <b>Kredi Kartı & Banka Kartı
                                                                                    (PayTR)</b>
                                                                                <span
                                                                                        class="badge badge-info  font-weight-bold">Anında
                                                                                    Onay</span>
                                                                                <span
                                                                                        class="badge badge-warning font-weight-bold"><?= $ayarlar->paytr_komisyon ?>%
                                                                                    Komisyon</span>
                                                                            </li>
                                                                        <?php endif; ?>
                                                                        <?php if ($ayarlar->iyzico_durum == '1'): ?>
                                                                            <li id="iyzico">
                                                                                <tip>Kredi</tip>
                                                                                <div class="paymentImage">
                                                                                    <img
                                                                                            src="<?php echo base_url('assets/images/stripe.png') ?>">
                                                                                </div>
                                                                                <b>Kredi Kartı & Banka Kartı
                                                                                    (Iyzico)</b>
                                                                                <span
                                                                                        class="badge badge-info  font-weight-bold">Anında
                                                                                    Onay</span>
                                                                                <span
                                                                                        class="badge badge-warning font-weight-bold"><?= $ayarlar->iyzico_komisyon ?>%
                                                                                    Komisyon</span>
                                                                            </li>
                                                                        <?php endif; ?>
                                                                        <?php if ($ayarlar->weepay_durum == '1'): ?>
                                                                            <li id="weepay">
                                                                                <tip>Kredi</tip>
                                                                                <div class="paymentImage">
                                                                                    <img
                                                                                            src="<?php echo base_url('assets/images/unnamed.png') ?>">
                                                                                </div>
                                                                                <b>Kredi Kartı & Banka Kartı
                                                                                    (Weepay)</b>
                                                                                <span
                                                                                        class="badge badge-info  font-weight-bold">Anında
                                                                                    Onay</span>
                                                                                <span
                                                                                        class="badge badge-warning font-weight-bold"><?= $ayarlar->weepay_komisyon ?>%
                                                                                    Komisyon</span>
                                                                            </li>
                                                                        <?php endif; ?>
                                                                        <?php if ($ayarlar->stripe_durum == '1'): ?>
                                                                            <li id="stripe">
                                                                                <tip>Kredi</tip>
                                                                                <div class="paymentImage">
                                                                                    <img
                                                                                            src="<?php echo base_url('assets/images/stripe.png') ?>">
                                                                                </div>
                                                                                <b>Kredi Kartı & Banka Kartı
                                                                                    (Stripe)</b>
                                                                                <span
                                                                                        class="badge badge-info  font-weight-bold">Anında
                                                                                    Onay</span>
                                                                                <span
                                                                                        class="badge badge-warning font-weight-bold"><?= $ayarlar->stripe_komisyon ?>
                                                                                    TL Komisyon</span>
                                                                            </li>
                                                                        <?php endif; ?>
                                                                        <?php if ($ayarlar->vallet_durum == '1'): ?>
                                                                            <li id="vallet">
                                                                                <tip>Kredi</tip>
                                                                                <div class="paymentImage">
                                                                                    <img
                                                                                            src="<?php echo base_url('assets/images/vallet.png') ?>">
                                                                                </div>
                                                                                <b>Kredi Kartı & Banka Kartı
                                                                                    (Vallet)</b>
                                                                                <span
                                                                                        class="badge badge-info  font-weight-bold">Anında
                                                                                    Onay</span>
                                                                                <span
                                                                                        class="badge badge-warning font-weight-bold"><?= $ayarlar->vallet_komisyon ?>%
                                                                                    Komisyon</span>
                                                                            </li>
                                                                        <?php endif; ?>
                                                                        <?php
                                                                        $bankalar = bankalar(['status' => 1]);
                                                                        if ($bankalar) { ?>
                                                                            <li id="banks">
                                                                                <tip>Havale/EFT</tip>
                                                                                <div class="paymentImage">
                                                                                    <img
                                                                                            src="<?php echo base_url('assets/images/atm.png') ?>">
                                                                                </div>
                                                                                <b>Havale/EFT</b>
                                                                                <span
                                                                                        class="badge badge-info  font-weight-bold">Süreli
                                                                                    Onay</span>
                                                                                <span
                                                                                        class="badge badge-warning font-weight-bold"><?= $ayarlar->havale_komisyon ?>%
                                                                                    Komisyon</span>
                                                                            </li>
                                                                            <?php
                                                                        }
                                                                        ?>
                                                                        <li id="gift">
                                                                            <tip>Kredi</tip>
                                                                            <div class="paymentImage">
                                                                                <img
                                                                                        src="<?php echo base_url('assets/images/2438193.svg') ?>">
                                                                            </div>
                                                                            <b>Bakiye Kuponu</b>
                                                                            <span
                                                                                    class="badge badge-info  font-weight-bold">Komisyonsuz</span>
                                                                        </li>
                                                                        <!--<li id="papara">
                                                                                    <tip>Papara</tip>
                                                                                    <div class="paymentImage">
                                                                                        <img src="https://cdn.itempazar.com/global/icons/payments/papara.svg">
                                                                                    </div>
                                                                                    <b>Papara Ödeme</b>
                                                                                    <span class="badge badge-warning  font-weight-bold">%1.9 Komisyon</span>
                                                                                </li>
                                                                                <li id="gpay">
                                                                                    <tip>G-Pay</tip>
                                                                                    <div class="paymentImage">
                                                                                        <img src="https://cdn.itempazar.com/global/icons/credit-card.svg">
                                                                                    </div>
                                                                                    <b>G-Pay Kredi Kartı & Banka Kartı</b>
                                                                                    <span class="badge badge-danger  font-weight-bold">%1.xx Komisyon</span>
                                                                                </li>-->
                                                                    </ul>
                                                                </div>
                                                                <div class="tab-pane fade" id="payment-2"
                                                                     role="tabpanel"
                                                                     aria-labelledby="pills-profile-tab">

                                                                    <ul class="PaymentTypes" id="paymentTypes">
                                                                        <?php if ($ayarlar->paytr_durum == '1'): ?>
                                                                            <li id="paytr">
                                                                                <tip>Kredi</tip>
                                                                                <div class="paymentImage">
                                                                                    <img
                                                                                            src="<?php echo base_url('assets/images/stripe.png') ?>">
                                                                                </div>
                                                                                <b>Kredi Kartı & Banka Kartı
                                                                                    (PayTR)</b>
                                                                                <span
                                                                                        class="badge badge-info  font-weight-bold">Anında
                                                                                    Onay</span>
                                                                                <span
                                                                                        class="badge badge-warning font-weight-bold"><?= $ayarlar->paytr_komisyon ?>%
                                                                                    Komisyon</span>
                                                                            </li>
                                                                        <?php endif; ?>
                                                                        <?php if ($ayarlar->iyzico_durum == '1'): ?>
                                                                            <li id="iyzico">
                                                                                <tip>Kredi</tip>
                                                                                <div class="paymentImage">
                                                                                    <img
                                                                                            src="<?php echo base_url('assets/images/stripe.png') ?>">
                                                                                </div>
                                                                                <b>Kredi Kartı & Banka Kartı
                                                                                    (Iyzico)</b>
                                                                                <span
                                                                                        class="badge badge-info  font-weight-bold">Anında
                                                                                    Onay</span>
                                                                                <span
                                                                                        class="badge badge-warning font-weight-bold"><?= $ayarlar->iyzico_komisyon ?>%
                                                                                    Komisyon</span>
                                                                            </li>
                                                                        <?php endif; ?>
                                                                        <?php if ($ayarlar->weepay_durum == '1'): ?>
                                                                            <li id="weepay">
                                                                                <tip>Kredi</tip>
                                                                                <div class="paymentImage">
                                                                                    <img
                                                                                            src="<?php echo base_url('assets/images/unnamed.png') ?>">
                                                                                </div>
                                                                                <b>Kredi Kartı & Banka Kartı
                                                                                    (Weepay)</b>
                                                                                <span
                                                                                        class="badge badge-info  font-weight-bold">Anında
                                                                                    Onay</span>
                                                                                <span
                                                                                        class="badge badge-warning font-weight-bold"><?= $ayarlar->weepay_komisyon ?>%
                                                                                    Komisyon</span>
                                                                            </li>
                                                                        <?php endif; ?>
                                                                        <?php if ($ayarlar->stripe_durum == '1'): ?>
                                                                            <li id="stripe">
                                                                                <tip>Kredi</tip>
                                                                                <div class="paymentImage">
                                                                                    <img
                                                                                            src="<?php echo base_url('assets/images/stripe.png') ?>">
                                                                                </div>
                                                                                <b>Kredi Kartı & Banka Kartı
                                                                                    (Stripe)</b>
                                                                                <span
                                                                                        class="badge badge-info  font-weight-bold">Anında
                                                                                    Onay</span>
                                                                                <span
                                                                                        class="badge badge-warning font-weight-bold"><?= $ayarlar->stripe_komisyon ?>
                                                                                    TL Komisyon</span>
                                                                            </li>
                                                                        <?php endif; ?>
                                                                        <?php if ($ayarlar->vallet_durum == '1'): ?>
                                                                            <li id="vallet">
                                                                                <tip>Kredi</tip>
                                                                                <div class="paymentImage">
                                                                                    <img
                                                                                            src="<?php echo base_url('assets/images/vallet.png') ?>">
                                                                                </div>
                                                                                <b>Kredi Kartı & Banka Kartı
                                                                                    (Vallet)</b>
                                                                                <span
                                                                                        class="badge badge-info  font-weight-bold">Anında
                                                                                    Onay</span>
                                                                                <span
                                                                                        class="badge badge-warning font-weight-bold"><?= $ayarlar->vallet_komisyon ?>%
                                                                                    Komisyon</span>
                                                                            </li>
                                                                        <?php endif; ?>

                                                                        <!--<li id="papara">
                                                                                    <tip>Papara</tip>
                                                                                    <div class="paymentImage">
                                                                                        <img src="https://cdn.itempazar.com/global/icons/payments/papara.svg">
                                                                                    </div>
                                                                                    <b>Papara Ödeme</b>
                                                                                    <span class="badge badge-warning  font-weight-bold">%1.9 Komisyon</span>
                                                                                </li>
                                                                                <li id="gpay">
                                                                                    <tip>G-Pay</tip>
                                                                                    <div class="paymentImage">
                                                                                        <img src="https://cdn.itempazar.com/global/icons/credit-card.svg">
                                                                                    </div>
                                                                                    <b>G-Pay Kredi Kartı & Banka Kartı</b>
                                                                                    <span class="badge badge-danger  font-weight-bold">%1.xx Komisyon</span>
                                                                                </li>-->
                                                                    </ul>
                                                                </div>
                                                                <div class="tab-pane fade" id="payment-3"
                                                                     role="tabpanel"
                                                                     aria-labelledby="pills-contact-tab">

                                                                    <ul class="PaymentTypes" id="paymentTypes">
                                                                        <?php if ($ayarlar->stripe_durum == '1'): ?>
                                                                            <li id="stripe">
                                                                                <tip>Kredi</tip>
                                                                                <div class="paymentImage">
                                                                                    <img
                                                                                            src="<?php echo base_url('assets/images/stripe.png') ?>">
                                                                                </div>
                                                                                <b>Kredi Kartı & Banka Kartı
                                                                                    (Stripe)</b>
                                                                                <span
                                                                                        class="badge badge-info  font-weight-bold">Anında
                                                                                    Onay</span>
                                                                                <span
                                                                                        class="badge badge-warning font-weight-bold"><?= $ayarlar->stripe_komisyon ?>
                                                                                    TL Komisyon</span>
                                                                            </li>
                                                                        <?php endif; ?>
                                                                        <!--<li id="papara">
                                                                                    <tip>Papara</tip>
                                                                                    <div class="paymentImage">
                                                                                        <img src="https://cdn.itempazar.com/global/icons/payments/papara.svg">
                                                                                    </div>
                                                                                    <b>Papara Ödeme</b>
                                                                                    <span class="badge badge-warning  font-weight-bold">%1.9 Komisyon</span>
                                                                                </li>
                                                                                <li id="gpay">
                                                                                    <tip>G-Pay</tip>
                                                                                    <div class="paymentImage">
                                                                                        <img src="https://cdn.itempazar.com/global/icons/credit-card.svg">
                                                                                    </div>
                                                                                    <b>G-Pay Kredi Kartı & Banka Kartı</b>
                                                                                    <span class="badge badge-danger  font-weight-bold">%1.xx Komisyon</span>
                                                                                </li>-->
                                                                    </ul>
                                                                </div>
                                                                <div class="tab-pane fade" id="payment-4"
                                                                     role="tabpanel"
                                                                     aria-labelledby="pills-contact-tab">

                                                                    <ul class="PaymentTypes" id="paymentTypes">
                                                                        <?php
                                                                        $bankalar = bankalar(['status' => 1]);
                                                                        if ($bankalar) { ?>
                                                                            <li id="banks">
                                                                                <tip>Havale/EFT</tip>
                                                                                <div class="paymentImage">
                                                                                    <img
                                                                                            src="<?php echo base_url('assets/images/atm.png') ?>">
                                                                                </div>
                                                                                <b>Havale/EFT</b>
                                                                                <span
                                                                                        class="badge badge-info  font-weight-bold">Süreli
                                                                                    Onay</span>
                                                                                <span
                                                                                        class="badge badge-warning font-weight-bold"><?= $ayarlar->havale_komisyon ?>%
                                                                                    Komisyon</span>
                                                                            </li>
                                                                            <?php
                                                                        }
                                                                        ?>
                                                                        <!--<li id="papara">
                                                                                    <tip>Papara</tip>
                                                                                    <div class="paymentImage">
                                                                                        <img src="https://cdn.itempazar.com/global/icons/payments/papara.svg">
                                                                                    </div>
                                                                                    <b>Papara Ödeme</b>
                                                                                    <span class="badge badge-warning  font-weight-bold">%1.9 Komisyon</span>
                                                                                </li>
                                                                                <li id="gpay">
                                                                                    <tip>G-Pay</tip>
                                                                                    <div class="paymentImage">
                                                                                        <img src="https://cdn.itempazar.com/global/icons/credit-card.svg">
                                                                                    </div>
                                                                                    <b>G-Pay Kredi Kartı & Banka Kartı</b>
                                                                                    <span class="badge badge-danger  font-weight-bold">%1.xx Komisyon</span>
                                                                                </li>-->
                                                                    </ul>
                                                                </div>
                                                                <div class="tab-pane fade" id="payment-5"
                                                                     role="tabpanel"
                                                                     aria-labelledby="pills-contact-tab">
                                                                    <ul class="PaymentTypes" id="paymentTypes">
                                                                        <li id="gift">
                                                                            <tip>Kredi</tip>
                                                                            <div class="paymentImage">
                                                                                <img
                                                                                        src="<?php echo base_url('assets/images/2438193.svg') ?>">
                                                                            </div>
                                                                            <b>Bakiye Kuponu</b>
                                                                            <span
                                                                                    class="badge badge-info  font-weight-bold">Komisyonsuz</span>
                                                                        </li>
                                                                        <!--<li id="papara">
                                                                                    <tip>Papara</tip>
                                                                                    <div class="paymentImage">
                                                                                        <img src="https://cdn.itempazar.com/global/icons/payments/papara.svg">
                                                                                    </div>
                                                                                    <b>Papara Ödeme</b>
                                                                                    <span class="badge badge-warning  font-weight-bold">%1.9 Komisyon</span>
                                                                                </li>
                                                                                <li id="gpay">
                                                                                    <tip>G-Pay</tip>
                                                                                    <div class="paymentImage">
                                                                                        <img src="https://cdn.itempazar.com/global/icons/credit-card.svg">
                                                                                    </div>
                                                                                    <b>G-Pay Kredi Kartı & Banka Kartı</b>
                                                                                    <span class="badge badge-danger  font-weight-bold">%1.xx Komisyon</span>
                                                                                </li>-->
                                                                    </ul>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-12">
                                                            <div id="intro">
                                                                <div class="text-center">
                                                                    <div>
                                                                        <img src="https://cdn.itempazar.com/global/illustrations/undraw_wallet_aym5.svg"
                                                                             width="180">
                                                                        <h3 class="c-custom"
                                                                            style="margin-bottom: 0px">
                                                                            Bakiye Yükleme Merkezi</h3>
                                                                        <span>Sol menüde bulunan ödeme
                                                                                yöntemlerinden
                                                                                size en uygun olanı seçin ve
                                                                                hesabınıza
                                                                                anında bakiye yükleyin.<br>
                                                                                Yaptığınız
                                                                                işlemler ödeme sağlayıcılarımız
                                                                                tarafından
                                                                                7/24 kontrol edilip
                                                                                onaylanmaktadır.</span>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="tab-content">
                                                                <div id="paytr-content" class="content d-none">
                                                                    <h3 class="c-custom">PayTR - Kredi /
                                                                        Banka Kartı ile
                                                                        ödeme</h3>
                                                                    <p>Kredi veya banka kartınız ile
                                                                        yapacağınız
                                                                        ödemelerin tümü 3D güvenliği ile
                                                                        gerçekleştirilmektedir.</p>
                                                                    <div
                                                                            class="col-md-8 col-md-offset-2 odeme-paneli">
                                                                        <?php if ($ayarlar->paytr_durum == '1'): ?>
                                                                            <form
                                                                                    action="<?= base_url('bakiye-yukle') ?>"
                                                                                    method="POST">
                                                                                <div class="align-items-center">
                                                                                    <input type="hidden"
                                                                                           id="komisyon_oran"
                                                                                           value="<?= $ayarlar->paytr_komisyon ?>">
                                                                                    <div class="form-group">
                                                                                        <label>Yüklemek
                                                                                            istediğiniz
                                                                                            tutar</label>
                                                                                        <input type="text" name="tutar"
                                                                                               id="tutar"
                                                                                               class="form-control"
                                                                                               inputmode="text">
                                                                                    </div>
                                                                                    <div class="form-group">
                                                                                        <label>Ödenecek
                                                                                            Tutar</label>
                                                                                        <div class="form-control"
                                                                                             id="odenecek_tutar">
                                                                                        </div>
                                                                                    </div>
                                                                                    <button class="btn btn-primary"
                                                                                            type="submit" name="odeme"
                                                                                            value="paytr">
                                                                                        Ödeme Yap
                                                                                    </button>
                                                                                </div>

                                                                            </form>
                                                                        <?php else: ?>
                                                                            <div class="alert alert-danger">
                                                                                PayTR Bulunamadı
                                                                            </div>
                                                                        <?php endif; ?>
                                                                    </div>
                                                                    <div style="clear:both;"></div>
                                                                </div>
                                                                <div id="weepay-content" class="content d-none">
                                                                    <h3 class="c-custom">WeePay - Kredi /
                                                                        Banka Kartı
                                                                        ile ödeme</h3>
                                                                    <p>Kredi veya banka kartınız ile
                                                                        yapacağınız
                                                                        ödemelerin tümü 3D güvenliği ile
                                                                        gerçekleştirilmektedir.</p>
                                                                    <div
                                                                            class="col-md-8 col-md-offset-2 odeme-paneli">
                                                                        <?php if ($ayarlar->weepay_durum == '1'): ?>
                                                                            <form
                                                                                    action="<?= base_url('bakiye-yukle') ?>"
                                                                                    method="POST">
                                                                                <div class="align-items-center">
                                                                                    <input type="hidden"
                                                                                           id="weepay_komisyon_oran"
                                                                                           value="<?= $ayarlar->weepay_komisyon ?>">
                                                                                    <div class="form-group">
                                                                                        <label>Yüklemek
                                                                                            istediğiniz
                                                                                            tutar</label>
                                                                                        <input type="text" name="tutar"
                                                                                               id="weepay_tutar"
                                                                                               class="form-control"
                                                                                               inputmode="text">
                                                                                    </div>
                                                                                    <div class="form-group">
                                                                                        <label>Ödenecek
                                                                                            Tutar</label>
                                                                                        <div class="form-control"
                                                                                             id="weepay_odenecek_tutar">
                                                                                        </div>
                                                                                    </div>
                                                                                    <button class="btn btn-primary"
                                                                                            type="submit" name="odeme"
                                                                                            value="weepay">
                                                                                        Ödeme Yap
                                                                                    </button>
                                                                                </div>

                                                                            </form>
                                                                        <?php else: ?>
                                                                            <div class="alert alert-danger">
                                                                                WeePay Bulunamadı
                                                                            </div>
                                                                        <?php endif; ?>
                                                                    </div>
                                                                    <div style="clear:both;"></div>
                                                                </div>
                                                                <div id="vallet-content" class="content d-none">
                                                                    <h3 class="c-custom">Vallet - Kredi /
                                                                        Banka Kartı
                                                                        ile ödeme</h3>
                                                                    <p>Kredi veya banka kartınız ile
                                                                        yapacağınız
                                                                        ödemelerin tümü 3D güvenliği ile
                                                                        gerçekleştirilmektedir.</p>
                                                                    <div
                                                                            class="col-md-8 col-md-offset-2 odeme-paneli">
                                                                        <?php if ($ayarlar->vallet_durum == '1'): ?>
                                                                            <form
                                                                                    action="<?= base_url('bakiye-yukle') ?>"
                                                                                    method="POST">
                                                                                <div class="align-items-center">
                                                                                    <input type="hidden"
                                                                                           id="vallet_komisyon_oran"
                                                                                           value="<?= $ayarlar->vallet_komisyon ?>">
                                                                                    <div class="form-group">
                                                                                        <label>Yüklemek
                                                                                            istediğiniz
                                                                                            tutar</label>
                                                                                        <input type="text" name="tutar"
                                                                                               id="vallet_tutar"
                                                                                               class="form-control"
                                                                                               inputmode="text">
                                                                                    </div>
                                                                                    <div class="form-group">
                                                                                        <label>Ödenecek
                                                                                            Tutar</label>
                                                                                        <div class="form-control"
                                                                                             id="vallet_odenecek_tutar">
                                                                                        </div>
                                                                                    </div>
                                                                                    <button class="btn btn-primary"
                                                                                            type="submit" name="odeme"
                                                                                            value="vallet">
                                                                                        Ödeme Yap
                                                                                    </button>
                                                                                </div>

                                                                            </form>
                                                                        <?php else: ?>
                                                                            <div class="alert alert-danger">
                                                                                WeePay Bulunamadı
                                                                            </div>
                                                                        <?php endif; ?>
                                                                    </div>
                                                                    <div style="clear:both;"></div>
                                                                </div>
                                                                <div id="stripe-content" class="content d-none">
                                                                    <h3 class="c-custom">Stripe - Kredi /
                                                                        Banka Kartı
                                                                        ile ödeme</h3>
                                                                    <p>Kredi veya banka kartınız ile
                                                                        yapacağınız
                                                                        ödemelerin tümü 3D güvenliği ile
                                                                        gerçekleştirilmektedir.</p>
                                                                    <span
                                                                            class="badge badge-warning font-weight-bold"
                                                                            style="font-size:13px ">Minimum
                                                                            Yükleme Tutarı :
                                                                            <strong>100 TL</strong></span>
                                                                    <span
                                                                            class="badge badge-warning font-weight-bold"
                                                                            style="font-size:13px ">İşlem Ücreti
                                                                            :
                                                                            <strong><?= $ayarlar->stripe_komisyon ?>
                                                                                TL</strong></span>
                                                                    <div
                                                                            class="col-md-8 col-md-offset-2 odeme-paneli">
                                                                        <?php if ($ayarlar->stripe_durum == '1'): ?>
                                                                            <form
                                                                                    action="<?= base_url('bakiye-yukle') ?>"
                                                                                    method="POST">
                                                                                <div class="align-items-center">
                                                                                    <input type="hidden"
                                                                                           id="stripe_komisyon_oran"
                                                                                           value="<?= $ayarlar->stripe_komisyon ?>">
                                                                                    <div class="form-group">
                                                                                        <label>Yüklemek
                                                                                            istediğiniz
                                                                                            tutar</label>
                                                                                        <input type="text" name="tutar"
                                                                                               id="stripe_tutar"
                                                                                               class="form-control"
                                                                                               inputmode="text">
                                                                                    </div>
                                                                                    <div class="form-group">
                                                                                        <label>Ödenecek
                                                                                            Tutar</label>
                                                                                        <div class="form-control"
                                                                                             id="stripe_odenecek_tutar">
                                                                                        </div>
                                                                                    </div>
                                                                                    <button class="btn btn-primary"
                                                                                            type="submit" name="odeme"
                                                                                            value="stripe">
                                                                                        Ödeme Yap
                                                                                    </button>
                                                                                </div>

                                                                            </form>
                                                                        <?php else: ?>
                                                                            <div class="alert alert-danger">
                                                                                Stripe Bulunamadı
                                                                            </div>
                                                                        <?php endif; ?>
                                                                    </div>
                                                                    <div style="clear:both;"></div>
                                                                </div>
                                                                <div id="banks-content" class="content d-none">
                                                                    <h3 class="c-custom">Havale / EFT ile
                                                                        ödeme</h3>
                                                                    <p>Havale eft ile yapacağınız ödemeler
                                                                        için ödeme
                                                                        bildirimi oluşturmalısınız ve
                                                                        kontrol
                                                                        sonrası onaylanacaktır.</p>
                                                                    <?php if ($bankalar): ?>
                                                                        <div class="row">
                                                                            <div class="col-12 text-center">
                                                                                <div class="bank-transfer">
                                                                                    <?php foreach ($bankalar as $banka): ?>
                                                                                        <div class="bank-img-area"
                                                                                             data-id="<?php echo $banka->id ?>"
                                                                                             onclick="paymentInfoPanel()">
                                                                                            <img src="<?= base_url($banka->image); ?>"
                                                                                                 height="100"
                                                                                                 width="auto">
                                                                                        </div>
                                                                                    <?php endforeach; ?>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    <?php else: ?>
                                                                        <div class="alert alert-danger">
                                                                            Banka Bulunamadı
                                                                        </div>
                                                                    <?php endif; ?>
                                                                    <div style="clear:both;"></div>
                                                                </div>
                                                                <div id="iyzico-content" class="content d-none">
                                                                    <h3 class="c-custom">Iyzico - Kredi /
                                                                        Banka Kartı
                                                                        ile ödeme</h3>
                                                                    <p>Kredi veya banka kartınız ile
                                                                        yapacağınız
                                                                        ödemelerin tümü 3D güvenliği ile
                                                                        gerçekleştirilmektedir.</p>
                                                                    <div
                                                                            class="col-md-8 col-md-offset-2 odeme-paneli">
                                                                        <?php if ($ayarlar->iyzico_durum == '1'): ?>
                                                                            <form
                                                                                    action="<?= base_url('bakiye-yukle') ?>"
                                                                                    method="POST">
                                                                                <div class="align-items-center">
                                                                                    <input type="hidden"
                                                                                           id="iyzico_komisyon_oran"
                                                                                           value="<?= $ayarlar->iyzico_komisyon ?>">
                                                                                    <div class="form-group">
                                                                                        <label>Yüklemek
                                                                                            istediğiniz
                                                                                            tutar</label>
                                                                                        <input type="text" name="tutar"
                                                                                               id="iyzico_tutar"
                                                                                               class="form-control"
                                                                                               inputmode="text">
                                                                                    </div>
                                                                                    <div class="form-group">
                                                                                        <label>Ödenecek
                                                                                            Tutar</label>
                                                                                        <div class="form-control"
                                                                                             id="iyzico_odenecek_tutar">
                                                                                        </div>
                                                                                    </div>
                                                                                    <button class="btn btn-primary"
                                                                                            type="submit" name="odeme"
                                                                                            value="iyzico">
                                                                                        Ödeme Yap
                                                                                    </button>
                                                                                </div>

                                                                            </form>
                                                                        <?php else: ?>
                                                                            <div class="alert alert-danger">
                                                                                Iyzico Bulunamadı
                                                                            </div>
                                                                        <?php endif; ?>
                                                                    </div>
                                                                </div>
                                                                <div id="gpay-content" class="content d-none">
                                                                    <div class="col-lg-4">
                                                                        <div class="alert alert-danger">
                                                                            null
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div id="gift-content" class="content d-none">
                                                                    <h3 class="c-custom">Bakiye Kuponu
                                                                        Kullan</h3>
                                                                    <p>Diğer kullanıcılar tarafından size
                                                                        hediye olarak
                                                                        gönderilen bakiye kuponlarını bu
                                                                        alanda
                                                                        bozdurabilirsiniz. Unutmayın 24 saat
                                                                        içerisinde
                                                                        kullanılmayan bakiye kuponları iptal
                                                                        olmaktadır.</p>
                                                                    <br>
                                                                    <form id="bakiyeKuponuForm" action=""
                                                                          method="POST" class="ui form">
                                                                        <div class="field">
                                                                            <label class="light-text-black"
                                                                                   style="font-size: 16px">Kupon
                                                                                Kodunuz</label>
                                                                            <input type="text" name="kod"
                                                                                   placeholder="XXXXX-XXXXX-XXXXX-XXXXX">
                                                                        </div>
                                                                        <button
                                                                                class="ui button btn-block btn-primary kuponBozdur"
                                                                                type="submit">Kuponu Bozdur
                                                                        </button>
                                                                    </form>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="tab-pane fade" id="take-money" role="tabpanel"
                                     aria-labelledby="take-money-tab" tabindex="0">
                                    <div class="container-fluid">
                                        <div class="k-panel-content-box">
                                            <div class="row">
                                                <div class="col-12">
                                                    <div class="kpc-tt">
                                                        Para Çekme Talebi
                                                    </div>
                                                    <div class="account-area">
                                                        <div class="pb-5 py-md-5">
                                                            <div class="">
                                                                
                                                                <div class="card mb-5">
                                                                    
                                                                    <div class="card-body">
                                                                        <div class="col-12 page-header">
                                                                            <h3 class="page-title">Lütfen
                                                                                çekim yapmak
                                                                                istediğiniz hesap türünü
                                                                                seçin.</h3>
                                                                        </div>
                                                                        <script>
                                                                            $(document).ready(function () {
                                                                                // İlk sekme ve içeriği aktif hale getirme
                                                                                // Sekme tıklama olayı
                                                                                $('.cekimTipiSecimi li').click(function () {
                                                                                    var tabId = $(this).attr('id');
                                                                                    // Aktif sekmeleri değiştirme
                                                                                    $('.cekimTipiSecimi li').removeClass('active');
                                                                                    $(this).addClass('active');
                                                                                    //$('#intro').addClass("d-none");
                                                                                    // Tüm içerikleri gizleme
                                                                                    $('.odeme-section .content').addClass('d-none');
                                                                                    $('#banks-names').val(tabId);
                                                                                    // İlgili içeriği gösterme
                                                                                    $('#' + tabId + '-content').removeClass('d-none');
                                                                                });
                                                                            });
                                                                        </script>
                                                                        <style>
                                                                            ul.cekimTipiSecimi {
                                                                                margin: 0;
                                                                                padding: 0;
                                                                                list-style: none;
                                                                                margin-top: 10px;
                                                                            }

                                                                            ul.cekimTipiSecimi li.active,
                                                                            ul.cekimTipiSecimi li:hover {
                                                                                border-bottom: 3px solid rgb(141 174 255);
                                                                                background: rgb(57 73 112);
                                                                            }

                                                                            ul.cekimTipiSecimi li {
                                                                                float: left;
                                                                                width: 140px;
                                                                                height: 50px;
                                                                                padding: 0 15px;
                                                                                background: rgb(49 61 90);
                                                                                margin-right: 10px;
                                                                                text-align: center;
                                                                                cursor: pointer;
                                                                                border-radius: 3px;
                                                                            }

                                                                            ul.cekimTipiSecimi li img {
                                                                                width: 80px;
                                                                                height: 50px;
                                                                                padding: 10px;
                                                                                object-fit: contain;
                                                                            }

                                                                            [data-inverted][data-position~=top][data-tooltip]:before {
                                                                                background: #1b1c1d;
                                                                            }

                                                                            [data-position~=top][data-tooltip]:before {
                                                                                background: #fff;
                                                                            }

                                                                            [data-position="top center"][data-tooltip]:before {
                                                                                top: auto;
                                                                                right: auto;
                                                                                bottom: 100%;
                                                                                left: 50%;
                                                                                background: #fff;
                                                                                margin-left: -0.07142857rem;
                                                                                margin-bottom: 0.14285714rem;
                                                                            }
                                                                        </style>
                                                                        <?php $yontemler = $this->magaza_model->get_para_cekme_yontemler() ?>
                                                                        <div class="row align-items-center justify-content-space-between">
                                                                            <div class="col-xl-4 col-lg-4 col-md-12 col-sm-12 ">
                                                                                <div class="card vcards">
                                                                                    <div class="card-content">
                                                                                        <div class="card-body mh-85 bc-22">
                                                                                            <div class="card-img-body">
                                                                                                <div class="media  ">
                                                                                                    <div class="card-img-body-warper">
                                                                                                        <img class="card-img-body-icon"
                                                                                                             src="https://kemalellidort.com.tr/assets/yonetim/img/wallet.png"
                                                                                                             alt="">
                                                                                                    </div>
                                                                                                    <div class="media-body text-right-c">
                                                                                                        <h5 class="mb-0 display-4 font-weight-bold">
                                                                                                            <?= $odenebilir_kazanclar ?>
                                                                                                            ₺
                                                                                                        </h5>
                                                                                                        <span>Çekilebilir Kazanç</span>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                        <form action="<?= base_url('para-cek') ?>"
                                                                                              method="post">
                                                                                            <input type="hidden"
                                                                                                   id="banks-names"
                                                                                                   value="banka"
                                                                                                   name="bankname">
                                                                                            <button class="btn btn-success btn-block rounded-pill "
                                                                                                    type="submit">
                                                                                                Para Çekme
                                                                                                Talebi
                                                                                                Oluştur
                                                                                            </button>
                                                                                        </form>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="col-xl-8 col-lg-8 col-md-12 col-sm-12 ">
                                                                                <ul class="cekimTipiSecimi">
                                                                                    <?php foreach (!empty($yontemler) ? $yontemler : [] as $key => $val) { ?>
                                                                                        <li data-tab="banka-cekim"
                                                                                            id="<?php echo $val->row_div_id ?>"
                                                                                            class="<?php echo $key == 0 ? 'active' : '' ?>"
                                                                                            data-inverted=""
                                                                                            data-tooltip="<?php echo $val->row_title ?>"
                                                                                            data-position="top center">
                                                                                            <img src="<?php echo base_url($val->row_image) ?>">
                                                                                        </li>
                                                                                    <?php } ?>
                                                                                </ul>
                                                                            </div>
                                                                            <div class="col-12 mt-5">
                                                                                <div class="odeme-section">
                                                                                    <div class="content p-4 rounded-lg mb-3 d-none"
                                                                                         id="ininal-content">
                                                                                        <div class="custom-control custom-radio">
                                                                                            <form class="form-row"
                                                                                                  action="<?= base_url('ininal-bilgi') ?>"
                                                                                                  method="post">
                                                                                                <!-- First name -->
                                                                                                <div class="form-group col-md-12">
                                                                                                    <label
                                                                                                            class="form-label">Ininal
                                                                                                        No</label>
                                                                                                    <input
                                                                                                            type="text"
                                                                                                            name="iban"
                                                                                                            class="form-control"
                                                                                                            placeholder="Ininal No"
                                                                                                            value="<?= $kullanici->ininal_no ?>">
                                                                                                </div>
                                                                                                <!-- Last name -->
                                                                                                <div
                                                                                                        class="form-group col-md-12">
                                                                                                    <label
                                                                                                            class="form-label">Alıcı
                                                                                                        Adı
                                                                                                        Soyadı</label>
                                                                                                    <input
                                                                                                            type="text"
                                                                                                            name="alici"
                                                                                                            class="form-control"
                                                                                                            placeholder="Alıcı Adı Soyadı"
                                                                                                            value="<?= $kullanici->alici_ininal ?>">
                                                                                                </div>
                                                                                                <!-- Phone -->
                                                                                                <div
                                                                                                        class="form-group col-md-12">
                                                                                                    <label
                                                                                                            class="form-label">Alıcı
                                                                                                        Telefon
                                                                                                        Numarası</label>
                                                                                                    <input
                                                                                                            type="number"
                                                                                                            name="telefon"
                                                                                                            class="form-control"
                                                                                                            placeholder="Alıcı Telefon Numarası"
                                                                                                            value="<?= $kullanici->tel_ininal ?>">
                                                                                                </div>
                                                                                                <div class="col-12">
                                                                                                    <!-- Button -->
                                                                                                    <button
                                                                                                            class="btn btn-primary rounded-pill"
                                                                                                            type="submit">
                                                                                                        Bilgilerimi
                                                                                                        Güncelle
                                                                                                    </button>
                                                                                                </div>
                                                                                            </form>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="content p-4 rounded-lg mb-3 d-none"
                                                                                         id="papara-content">
                                                                                        <div class="custom-control custom-radio">
                                                                                            <form class="form-row"
                                                                                                  action="<?= base_url('papara-bilgi') ?>"
                                                                                                  method="post">
                                                                                                <!-- First name -->
                                                                                                <div class="form-group col-md-12">
                                                                                                    <label class="form-label">Papara
                                                                                                        No</label>
                                                                                                    <input type="text"
                                                                                                           name="iban"
                                                                                                           class="form-control"
                                                                                                           placeholder="Papara No"
                                                                                                           value="<?= $kullanici->papara_no ?>">
                                                                                                </div>
                                                                                                <!-- Last name -->
                                                                                                <div class="form-group col-md-12">
                                                                                                    <label class="form-label">Alıcı
                                                                                                        Adı
                                                                                                        Soyadı</label>
                                                                                                    <input type="text"
                                                                                                           name="alici"
                                                                                                           class="form-control"
                                                                                                           placeholder="Alıcı Adı Soyadı"
                                                                                                           value="<?= $kullanici->alici_papara ?>">
                                                                                                </div>
                                                                                                <!-- Phone -->
                                                                                                <div class="form-group col-md-12">
                                                                                                    <label class="form-label">Alıcı
                                                                                                        Telefon
                                                                                                        Numarası</label>
                                                                                                    <input type="number"
                                                                                                           name="telefon"
                                                                                                           class="form-control"
                                                                                                           placeholder="Alıcı Telefon Numarası"
                                                                                                           value="<?= $kullanici->tel_papara ?>">
                                                                                                </div>
                                                                                                <div class="col-12">
                                                                                                    <!-- Button -->
                                                                                                    <button class="btn btn-primary rounded-pill"
                                                                                                            type="submit">
                                                                                                        Bilgilerimi
                                                                                                        Güncelle
                                                                                                    </button>
                                                                                                </div>
                                                                                            </form>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="content p-4 rounded-lg mb-3"
                                                                                         id="banka-content">
                                                                                        <div class="custom-control custom-radio">
                                                                                            <form class="form-row"
                                                                                                  action="<?= base_url('iban-bilgi') ?>"
                                                                                                  method="post">
                                                                                                <!-- First name -->
                                                                                                <div class="form-group col-md-12">
                                                                                                    <label class="form-label">IBAN
                                                                                                        No</label>
                                                                                                    <input type="text"
                                                                                                           name="iban"
                                                                                                           class="form-control"
                                                                                                           placeholder="IBAN No"
                                                                                                           value="<?= $kullanici->kullanici_iban ?>">
                                                                                                </div>
                                                                                                <!-- Last name -->
                                                                                                <div class="form-group col-md-12">
                                                                                                    <label class="form-label">Alıcı
                                                                                                        Adı
                                                                                                        Soyadı</label>
                                                                                                    <input type="text"
                                                                                                           name="alici"
                                                                                                           class="form-control"
                                                                                                           placeholder="Alıcı Adı Soyadı"
                                                                                                           value="<?= $kullanici->kullanici_alici ?>">
                                                                                                </div>
                                                                                                <!-- Phone -->
                                                                                                <div class="form-group col-md-12">
                                                                                                    <label class="form-label">Alıcı
                                                                                                        Telefon
                                                                                                        Numarası</label>
                                                                                                    <input type="number"
                                                                                                           name="telefon"
                                                                                                           class="form-control"
                                                                                                           placeholder="Alıcı Telefon Numarası"
                                                                                                           value="<?= $kullanici->kullanici_alici_tel ?>">
                                                                                                </div>
                                                                                                <div class="col-12">
                                                                                                    <!-- Button -->
                                                                                                    <button class="btn btn-primary rounded-pill"
                                                                                                            type="submit">
                                                                                                        Bilgilerimi
                                                                                                        Güncelle
                                                                                                    </button>
                                                                                                </div>
                                                                                            </form>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <!-- Check box -->
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="tab-pane fade" id="gold-orders" role="tabpanel"
                                     aria-labelledby="gold-orders-tab" tabindex="0">
                                    <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                                        <li class="nav-item" role="presentation">
                                            <button class="nav-link active" id="gold-purchased-tab"
                                                    data-bs-toggle="pill" data-bs-target="#gold-purchased" type="button"
                                                    role="tab" aria-controls="gold-purchased" aria-selected="true">Satın
                                                Alınan Gold'lar
                                            </button>
                                        </li>
                                        <li class="nav-item" role="presentation">
                                            <button class="nav-link" id="gold-sold-tab" data-bs-toggle="pill"
                                                    data-bs-target="#gold-sold" type="button" role="tab"
                                                    aria-controls="gold-sold" aria-selected="false">Satılan
                                                Gold'lar
                                            </button>
                                        </li>
                                    </ul>
                                    <div class="tab-content" id="pills-tabContent">
                                        <div class="tab-pane fade show active" id="gold-purchased" role="tabpanel"
                                             aria-labelledby="gold-purchased-tab">
                                            <div class="container-fluid">
                                                <div class="k-panel-content-box">
                                                    <div class="row">
                                                        <div class="col-12">
                                                            <div class="kpc-tt">
                                                                Satın Aldığınız Gold'lar
                                                            </div>
                                                            <div class="mb-4">
                                                                <div class="my-sales-tabs">
                                                                    <ul class="nav nav-pills mb-3" id="pills-tab"
                                                                        role="tablist">
                                                                        <li class="nav-item" role="presentation">
                                                                            <button class="nav-link active"
                                                                                    id="pills-waiting-6-tab"
                                                                                    data-bs-toggle="pill"
                                                                                    data-bs-target="#pills-waiting-6"
                                                                                    type="button" role="tab"
                                                                                    aria-controls="pills-waiting-6"
                                                                                    aria-selected="true">Bekleyen
                                                                            </button>
                                                                        </li>
                                                                        <li class="nav-item" role="presentation">
                                                                            <button class="nav-link"
                                                                                    id="pills-complate-6-tab"
                                                                                    data-bs-toggle="pill"
                                                                                    data-bs-target="#pills-complate-6"
                                                                                    type="button" role="tab"
                                                                                    aria-controls="pills-complate-6"
                                                                                    aria-selected="false">Tamamlanan
                                                                            </button>
                                                                        </li>
                                                                        <li class="nav-item" role="presentation">
                                                                            <button class="nav-link"
                                                                                    id="pills-canseled-6-tab"
                                                                                    data-bs-toggle="pill"
                                                                                    data-bs-target="#pills-canseled-6"
                                                                                    type="button" role="tab"
                                                                                    aria-controls="pills-canseled-6"
                                                                                    aria-selected="false">İptal
                                                                                Edilenler
                                                                            </button>
                                                                        </li>
                                                                    </ul>
                                                                    <div class="tab-content" id="pills-tabContent">
                                                                        <div class="tab-pane fade show active"
                                                                             id="pills-waiting" role="tabpanel"
                                                                             aria-labelledby="pills-waiting-tab">
                                                                        </div>
                                                                        <div class="tab-pane fade"
                                                                             id="pills-complate" role="tabpanel"
                                                                             aria-labelledby="pills-complate-tab">
                                                                            <div class="sale-cards">
                                                                                <div class="sale-container">
                                                                                    <div class="sale-card">
                                                                                        <div class="product-detail">
                                                                                            <div class="sale-img"><a
                                                                                                        href="javascript:void(0)"><img
                                                                                                            src="https://kemalellidort.com.tr/uploads/urunler/images/min/8399e2b6f9b8a91709d8dbbffc4b6e18.png">
                                                                                                </a></div>
                                                                                            <div
                                                                                                    class="product-info">
                                                                                                <div class="p-name">
                                                                                                    <a
                                                                                                            href="javascript:void(0)">Silkroad1
                                                                                                        Turkey 300
                                                                                                        Silk</a>
                                                                                                </div>
                                                                                                <div
                                                                                                        class="p-price">
                                                                                                    Fiyat:
                                                                                                    <span>180
                                                                                                            TL</span>
                                                                                                </div>
                                                                                                <div
                                                                                                        class="p-price">
                                                                                                    Toplam
                                                                                                    Kazanç:
                                                                                                    <span>360.00
                                                                                                            TL</span>
                                                                                                </div>
                                                                                                <div
                                                                                                        class="p-quantity">
                                                                                                    Adet:
                                                                                                    <span>2</span>
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div class="sale-info">
                                                                                            <div class="s-date"><i
                                                                                                        class="fa-regular fa-clock"></i>
                                                                                                2024-03-08 17:53:27
                                                                                            </div>
                                                                                            <div class="s-delivery">
                                                                                                Teslimat
                                                                                                Tarihi:
                                                                                                <span>0000-00-00
                                                                                                        00:00:00</span>
                                                                                            </div>
                                                                                            <div class="s-delivery">
                                                                                                Satıcı: <a
                                                                                                        class="p-seller"
                                                                                                        href="">admin</a>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="sale-status-g">
                                                                                        <div
                                                                                                class="sale-status status-1">
                                                                                            <i
                                                                                                    class="fa-solid fa-circle-check"></i>
                                                                                            Teslim edildi
                                                                                        </div>
                                                                                        <div class="s-name">Teslim
                                                                                            edilecek
                                                                                            karakter adı:
                                                                                            <span>*******</span>
                                                                                        </div>
                                                                                        <button
                                                                                                class="btn btn-primary btn-sm sale-detail-button align-self-end"
                                                                                                data-bs-toggle="modal"
                                                                                                data-bs-target="#info-comp-modal-3">
                                                                                            İletilen
                                                                                            Bilgiler
                                                                                        </button>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="sale-alerts ">
                                                                                    <div>Teslim Yeri : denemee</div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="modal fade"
                                                                                 id="info-comp-modal-3" tabindex="-1"
                                                                                 aria-labelledby="exampleModalLabel"
                                                                                 aria-hidden="true">
                                                                                <div class="modal-dialog">
                                                                                    <div class="modal-content">
                                                                                        <div class="modal-header">
                                                                                            <button type="button"
                                                                                                    class="btn-close"
                                                                                                    data-bs-dismiss="modal"
                                                                                                    aria-label="Close"></button>
                                                                                        </div>
                                                                                        <div class="modal-body">
                                                                                            <div
                                                                                                    class="detail-data-rows">
                                                                                                <div
                                                                                                        class="detail-data-row">
                                                                                                        <span
                                                                                                                class="detail-data-name">Oyundaki
                                                                                                            Karakter
                                                                                                            Adınız
                                                                                                            :</span><span
                                                                                                            class="detail-data-val">eeeee</span>
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div
                                                                                                class="modal-footer boder-0">
                                                                                            <button type="button"
                                                                                                    class="btn btn-secondary"
                                                                                                    data-bs-dismiss="modal">
                                                                                                Kapat
                                                                                            </button>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="tab-pane fade" id="pills-cancel"
                                                                             role="tabpanel"
                                                                             aria-labelledby="pills-cancel-tab">
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="tab-content" id="pills-tabContent">
                                                        <div class="tab-pane fade show active" id="pills-waiting-6"
                                                             role="tabpanel" aria-labelledby="pills-waiting-6-tab">
                                                            <?php if (!empty($bekleyen_alislarim)) { ?>
                                                                <?php foreach ($bekleyen_alislarim as $key => $val) { ?>
                                                                    <div class="sale-cards">
                                                                        <div class="sale-container">
                                                                            <div class="sale-card">
                                                                                <div class="product-detail">
                                                                                    <div class="sale-img"><a
                                                                                                href="javascript:void(0)"><img
                                                                                                    src="<?php echo base_url($val->urun_resim_min) ?>"></a>
                                                                                    </div>
                                                                                    <div class="product-info">
                                                                                        <div class="p-name">
                                                                                            <a href="javascript:void(0)"><?php echo $val->urun_ad ?></a>
                                                                                        </div>
                                                                                        <div class="p-price">Fiyat:
                                                                                            <span><?php echo $val->urun_alimfiyat ?> TL</span>
                                                                                        </div>
                                                                                        <div class="p-price">Toplam
                                                                                            Kazanç:
                                                                                            <span><?php echo $val->price ?> TL</span>
                                                                                        </div>
                                                                                        <div class="p-quantity">
                                                                                            Adet:
                                                                                            <span><?php echo $val->quantity ?></span>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="sale-status status-0"><i
                                                                                            class="fa-solid fa-gauge-high"></i>
                                                                                    Teslimat bekliyor
                                                                                    <button class="btn btn-primary btn-sm sale-detail-button align-self-end"
                                                                                            data-bs-toggle="modal"
                                                                                            data-bs-target="#info-alis-w-modal<?php echo $val->id ?>">
                                                                                        İletilen Bilgiler
                                                                                    </button>
                                                                                </div>
                                                                                <div class="sale-info">
                                                                                    <div class="s-date"><i
                                                                                                class="fa-regular fa-clock"></i>
                                                                                        <?php echo $val->added_time ?>
                                                                                    </div>
                                                                                    <div class="s-delivery">Satıcı: <a
                                                                                                class="p-seller"
                                                                                                href="javascript:void(0)"><?php echo $val->kullanici_ad ?></a>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="sale-alerts">
                                                                                <div><?php echo $val->urun_alimbaslik ?></div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="modal fade"
                                                                         id="info-alis-w-modal<?php echo $val->id ?>"
                                                                         tabindex="-1"
                                                                         aria-labelledby="exampleModalLabel"
                                                                         aria-hidden="true">
                                                                        <div class="modal-dialog">
                                                                            <div class="modal-content">
                                                                                <div class="modal-header">
                                                                                    <button type="button"
                                                                                            class="btn-close"
                                                                                            data-bs-dismiss="modal"
                                                                                            aria-label="Close"></button>
                                                                                </div>
                                                                                <div class="modal-body">
                                                                                    <div class="detail-data-rows">
                                                                                        <div class="detail-data-row">
                                                                                                <span class="detail-data-name">
                                                                                                    Oyundaki Karakter Adınız :
                                                                                                </span>
                                                                                            <span class="detail-data-val">
                                                                                                <?php echo $val->character_name ?>
                                                                                            </span>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="modal-footer boder-0">
                                                                                    <button type="button"
                                                                                            class="btn btn-secondary"
                                                                                            data-bs-dismiss="modal">
                                                                                        Kapat
                                                                                    </button>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                <?php } ?>
                                                            <?php } else { ?>
                                                                <div class="sale-cards border-n"><h4
                                                                            class="inside-warning"> Herhangi bir geçmiş
                                                                        bekleyen alımınız bulunmuyor.</h4></div>
                                                            <?php } ?>
                                                        </div>
                                                        <div class="tab-pane fade" id="pills-complate-6"
                                                             role="tabpanel" aria-labelledby="pills-complate-6-tab">
                                                            <?php if (!empty($tamamlanan_alislarim)) { ?>
                                                                <?php foreach ($tamamlanan_alislarim as $key => $val) { ?>
                                                                    <div class="sale-cards">
                                                                        <div class="sale-container">
                                                                            <div class="sale-card">
                                                                                <div class="product-detail">
                                                                                    <div class="sale-img">
                                                                                        <a href="javascript:void(0)">
                                                                                            <img src="<?php echo base_url($val->urun_resim_min) ?>">
                                                                                        </a>
                                                                                    </div>
                                                                                    <div class="product-info">
                                                                                        <div class="p-name">
                                                                                            <a href="javascript:void(0)"><?php echo $val->urun_ad ?></a>
                                                                                        </div>
                                                                                        <div class="p-price">
                                                                                            Fiyat:
                                                                                            <span><?php echo $val->urun_alimfiyat ?> TL</span>
                                                                                        </div>
                                                                                        <div class="p-price">
                                                                                            Toplam Kazanç:
                                                                                            <span><?php echo $val->price ?> TL</span>
                                                                                        </div>
                                                                                        <div class="p-quantity">
                                                                                            Adet:
                                                                                            <span><?php echo $val->quantity ?></span>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="sale-info">
                                                                                    <div class="s-date">
                                                                                        <i class="fa-regular fa-clock"></i>
                                                                                        <?php echo $val->added_time ?>
                                                                                    </div>
                                                                                    <div class="s-delivery">
                                                                                        Teslimat Tarihi:
                                                                                        <span><?php echo $val->delivery_date ?></span>
                                                                                    </div>
                                                                                    <div class="s-delivery">
                                                                                        Satıcı: <a class="p-seller"
                                                                                                   href="javascript:void(0)"><?php echo $val->kullanici_ad ?></a>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="sale-status status-1 dflx">
                                                                                <div class="te-ip">
                                                                                    <i class="fa-solid fa-circle-check"></i>
                                                                                    Teslim edildi
                                                                                </div>
                                                                                <div class="s-name">
                                                                                    Teslim edilecek karakter adı:
                                                                                    <span>*******</span>
                                                                                </div>
                                                                                <button class="btn btn-primary btn-sm sale-detail-button align-self-end"
                                                                                        data-bs-toggle="modal"
                                                                                        data-bs-target="#info-alim-comp-modal-<?php echo $val->id ?>">
                                                                                    İletilen Bilgiler
                                                                                </button>

                                                                            </div>
                                                                            <div class="sale-alerts">
                                                                                <div>
                                                                                    <?php echo $val->urun_alimbaslik ?>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="modal fade"
                                                                         id="info-alim-comp-modal-<?php echo $val->id ?>"
                                                                         tabindex="-1"
                                                                         aria-labelledby="exampleModalLabel"
                                                                         aria-hidden="true">
                                                                        <div class="modal-dialog">
                                                                            <div class="modal-content">
                                                                                <div class="modal-header">
                                                                                    <button type="button"
                                                                                            class="btn-close"
                                                                                            data-bs-dismiss="modal"
                                                                                            aria-label="Close"></button>
                                                                                </div>
                                                                                <div class="modal-body">
                                                                                    <div class="detail-data-rows">
                                                                                        <div class="detail-data-row">
                                                                        <span class="detail-data-name">
                                                                            Oyundaki Karakter Adınız :
                                                                        </span>
                                                                                            <span class="detail-data-val">
                                                                            <?php echo $val->character_name ?>
                                                                        </span>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="modal-footer boder-0">
                                                                                    <button type="button"
                                                                                            class="btn btn-secondary"
                                                                                            data-bs-dismiss="modal">
                                                                                        Kapat
                                                                                    </button>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                <?php } ?>
                                                            <?php } else { ?>
                                                                <div class="sale-cards border-n"><h4
                                                                            class="inside-warning"> Herhangi bir geçmiş
                                                                        tamamlanan alımınız bulunmuyor.</h4></div>
                                                            <?php } ?>
                                                        </div>
                                                        <div class="tab-pane fade" id="pills-canseled-6"
                                                             role="tabpanel" aria-labelledby="pills-canseled-6-tab">
                                                            <?php if (!empty($iptal_edilen_alislarim)) { ?>
                                                                <?php foreach ($iptal_edilen_alislarim as $key => $val) { ?>
                                                                    <div class="sale-cards">
                                                                        <div class="sale-container">
                                                                            <div class="sale-card">
                                                                                <div class="product-detail">
                                                                                    <div class="sale-img">
                                                                                        <a href="javascript:void(0)">
                                                                                            <img src="<?php echo base_url($val->urun_resim_min) ?>">
                                                                                        </a>
                                                                                    </div>
                                                                                    <div class="product-info">
                                                                                        <div class="p-name">
                                                                                            <a href="javascript:vodi(0)"><?php echo $val->urun_ad ?></a>
                                                                                        </div>
                                                                                        <div class="p-price">
                                                                                            Fiyat:
                                                                                            <span><?php echo $val->urun_alimfiyat ?> TL</span>
                                                                                        </div>
                                                                                        <div class="p-price">
                                                                                            Toplam Kazanç:
                                                                                            <span><?php echo $val->price ?> TL</span>
                                                                                        </div>
                                                                                        <div class="p-quantity">
                                                                                            Adet:
                                                                                            <span><?php echo $val->quantity ?></span>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="sale-status status-2"><i
                                                                                            class="fa-solid fa-ban"></i>
                                                                                    İptal edildi
                                                                                    <button class="btn btn-primary btn-sm sale-detail-button align-self-end mt-3"
                                                                                            data-bs-toggle="modal"
                                                                                            data-bs-target="#info-alim-cancel-modal-<?php echo $val->id ?>">
                                                                                        İletilen Bilgiler
                                                                                    </button>
                                                                                </div>
                                                                                <div class="sale-info">
                                                                                    <div class="s-date">
                                                                                        <i class="fa-regular fa-clock"></i>
                                                                                        2024-03-09 17:44:25
                                                                                    </div>
                                                                                    <div class="s-delivery">
                                                                                        Satıcı: <a class="p-seller"
                                                                                                   href="">Hyper</a>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="sale-alerts red">Satışınız iptal
                                                                                edilmiştir. Karakter Oyunda yada
                                                                                Teslimat
                                                                                Noktasında Değil.
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="modal fade"
                                                                         id="info-alim-cancel-modal-<?php echo $val->id ?>"
                                                                         tabindex="-1"
                                                                         aria-labelledby="exampleModalLabel"
                                                                         aria-hidden="true">
                                                                        <div class="modal-dialog">
                                                                            <div class="modal-content">
                                                                                <div class="modal-header">
                                                                                    <button type="button"
                                                                                            class="btn-close"
                                                                                            data-bs-dismiss="modal"
                                                                                            aria-label="Close"></button>
                                                                                </div>
                                                                                <div class="modal-body">
                                                                                    <div class="detail-data-rows">
                                                                                        <div class="detail-data-row">
                                                                        <span class="detail-data-name">
                                                                            Oyundaki Karakter Adınız :
                                                                        </span>
                                                                                            <span class="detail-data-val">
                                                                            <?php echo $val->character_name ?>
                                                                        </span>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="modal-footer boder-0">
                                                                                    <button type="button"
                                                                                            class="btn btn-secondary"
                                                                                            data-bs-dismiss="modal">
                                                                                        Kapat
                                                                                    </button>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                <?php } ?>
                                                            <?php } else { ?>
                                                                <div class="sale-cards border-n"><h4
                                                                            class="inside-warning"> Herhangi bir geçmiş
                                                                        iptal edilen alımınız bulunmuyor.</h4></div>
                                                            <?php } ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="tab-pane fade" id="gold-sold" role="tabpanel"
                                             aria-labelledby="gold-sold-tab">
                                            <div class="container-fluid">
                                                <div class="k-panel-content-box">
                                                    <div class="row">
                                                        <div class="col-12">
                                                            <div class="mb-4">
                                                                <div class="kpc-tt">
                                                                    Satmış Olduğunuz Gold'lar
                                                                </div>
                                                                <div class="getgold-area">
                                                                    <ul class="nav nav-pills mb-3" id="pills-tab"
                                                                        role="tablist">
                                                                        <li class="nav-item" role="presentation">
                                                                            <button class="nav-link active"
                                                                                    id="pills-waiting-5-tab"
                                                                                    data-bs-toggle="pill"
                                                                                    data-bs-target="#pills-waiting-5"
                                                                                    type="button" role="tab"
                                                                                    aria-controls="pills-waiting-5"
                                                                                    aria-selected="true">Bekleyen
                                                                            </button>
                                                                        </li>
                                                                        <li class="nav-item" role="presentation">
                                                                            <button class="nav-link"
                                                                                    id="pills-complate-5-tab"
                                                                                    data-bs-toggle="pill"
                                                                                    data-bs-target="#pills-complate-5"
                                                                                    type="button" role="tab"
                                                                                    aria-controls="pills-complate-5"
                                                                                    aria-selected="false">Teslim Edilen
                                                                            </button>
                                                                        </li>
                                                                        <li class="nav-item" role="presentation">
                                                                            <button class="nav-link"
                                                                                    id="pills-canseled-5-tab"
                                                                                    data-bs-toggle="pill"
                                                                                    data-bs-target="#pills-canseled-5"
                                                                                    type="button" role="tab"
                                                                                    aria-controls="pills-canseled-5"
                                                                                    aria-selected="false">İptal Edilen
                                                                            </button>
                                                                        </li>
                                                                    </ul>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="tab-content" id="pills-tabContent">
                                                        <div class="tab-pane fade show active" id="pills-waiting-5"
                                                             role="tabpanel" aria-labelledby="pills-waiting-5-tab">
                                                            <?php if (!empty($bekleyen_satislarim)) { ?>
                                                                <?php foreach ($bekleyen_satislarim as $key => $val) { ?>
                                                                    <div class="sale-cards">
                                                                        <div class="sale-container">
                                                                            <div class="sale-card">
                                                                                <div class="product-detail">
                                                                                    <div class="sale-img">
                                                                                        <a href="javascript:void(0)">
                                                                                            <img src="<?php echo base_url($val->urun_resim_min) ?>">
                                                                                        </a>
                                                                                    </div>
                                                                                    <div class="product-info">
                                                                                        <div class="p-name">
                                                                                            <a href="javascript:void(0)">
                                                                                                <?php echo $val->urun_ad ?>
                                                                                            </a>
                                                                                        </div>
                                                                                        <div class="p-price">Fiyat:
                                                                                            <span><?php echo $val->urun_alimfiyat ?> TL</span>
                                                                                        </div>
                                                                                        <div class="p-price">Toplam
                                                                                            Kazanç:
                                                                                            <span><?php echo $val->price ?> TL</span>
                                                                                        </div>
                                                                                        <div class="p-quantity">
                                                                                            Adet:
                                                                                            <span><?php echo $val->quantity ?></span>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="sale-status status-0"><i
                                                                                            class="fa-solid fa-gauge-high"></i>
                                                                                    Teslimat bekliyor
                                                                                    <button class="btn btn-primary btn-sm sale-detail-button align-self-end"
                                                                                            data-bs-toggle="modal"
                                                                                            data-bs-target="#info-satim-modal-<?php echo $val->id ?>">
                                                                                        İletilen Bilgiler
                                                                                    </button>
                                                                                </div>
                                                                                <div class="sale-info">
                                                                                    <div class="s-date"><i
                                                                                                class="fa-regular fa-clock"></i>
                                                                                        <?php echo $val->added_time ?>
                                                                                    </div>
                                                                                    <div class="s-delivery">Satıcı: <a
                                                                                                class="p-seller"
                                                                                                href="javascript:void(0)"><?php echo $val->kullanici_ad ?></a>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="sale-alerts ">
                                                                                <div>
                                                                                    <?php echo $val->urun_alimbaslik ?>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="modal fade"
                                                                         id="info-satim-modal-<?php echo $val->id ?>"
                                                                         tabindex="-1"
                                                                         aria-labelledby="exampleModalLabel"
                                                                         aria-hidden="true">
                                                                        <div class="modal-dialog">
                                                                            <div class="modal-content">
                                                                                <div class="modal-header">
                                                                                    <button type="button"
                                                                                            class="btn-close"
                                                                                            data-bs-dismiss="modal"
                                                                                            aria-label="Close"></button>
                                                                                </div>
                                                                                <div class="modal-body">
                                                                                    <div class="detail-data-rows">
                                                                                        <div class="detail-data-row">
                                                                        <span class="detail-data-name">
                                                                            Oyundaki Karakter Adınız :
                                                                        </span>
                                                                                            <span class="detail-data-val">
                                                                            <?php echo $val->character_name ?>
                                                                        </span>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="modal-footer boder-0">
                                                                                    <button type="button"
                                                                                            class="btn btn-secondary"
                                                                                            data-bs-dismiss="modal">
                                                                                        Kapat
                                                                                    </button>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                <?php } ?>
                                                            <?php } else { ?>
                                                                <div class="sale-cards border-n"><h4
                                                                            class="inside-warning"> Herhangi bir geçmiş
                                                                        bekleyen satışınız bulunmuyor.</h4></div>
                                                            <?php } ?>
                                                        </div>
                                                        <div class="tab-pane fade" id="pills-complate-5" role="tabpanel"
                                                             aria-labelledby="pills-complate-5-tab">
                                                            <?php if (!empty($tamamlanan_satislarim)) { ?>
                                                                <?php foreach ($tamamlanan_satislarim as $key => $val) { ?>
                                                                    <div class="sale-cards">
                                                                        <div class="sale-container">
                                                                            <div class="sale-card">
                                                                                <div class="product-detail">
                                                                                    <div class="sale-img">
                                                                                        <a href="javascript:void(0)">
                                                                                            <img src="<?php echo base_url($val->urun_resim_min) ?>">
                                                                                        </a>
                                                                                    </div>
                                                                                    <div class="product-info">
                                                                                        <div class="p-name">
                                                                                            <a href="javascript:void(0)">
                                                                                                <?php echo $val->urun_ad ?>
                                                                                            </a>
                                                                                        </div>
                                                                                        <div class="p-price">
                                                                                            Fiyat:
                                                                                            <span><?php echo $val->urun_alimfiyat ?> TL</span>
                                                                                        </div>
                                                                                        <div class="p-price">
                                                                                            Toplam Kazanç:
                                                                                            <span><?php echo $val->price ?> TL</span>
                                                                                        </div>
                                                                                        <div class="p-quantity">
                                                                                            Adet:
                                                                                            <span><?php echo $val->quantity ?></span>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="sale-info">
                                                                                    <div class="s-date">
                                                                                        <i class="fa-regular fa-clock"></i>
                                                                                        <?php echo $val->added_time ?>
                                                                                    </div>
                                                                                    <div class="s-delivery">
                                                                                        Teslimat Tarihi:
                                                                                        <span><?php echo $val->delivery_date ?></span>
                                                                                    </div>
                                                                                    <div class="s-delivery">
                                                                                        Satıcı: <a class="p-seller"
                                                                                                   href="javascript:void(0)"><?php echo $val->kullanici_ad ?></a>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="sale-status status-1 dflx">
                                                                                <div class="te-ip">
                                                                                    <i class="fa-solid fa-circle-check"></i>
                                                                                    Teslim edildi
                                                                                </div>
                                                                                <div class="s-name">
                                                                                    Teslim edilecek karakter adı:
                                                                                    <span>*******</span>
                                                                                </div>
                                                                                <button class="btn btn-primary btn-sm sale-detail-button align-self-end"
                                                                                        data-bs-toggle="modal"
                                                                                        data-bs-target="#info-satim-comp-modal-<?php echo $val->id ?>">
                                                                                    İletilen Bilgiler
                                                                                </button>

                                                                            </div>
                                                                            <div class="sale-alerts ">
                                                                                <div>
                                                                                    <?php echo $val->urun_alimbaslik ?>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="modal fade"
                                                                         id="info-satim-comp-modal-<?php echo $val->id ?>"
                                                                         tabindex="-1"
                                                                         aria-labelledby="exampleModalLabel"
                                                                         aria-hidden="true">
                                                                        <div class="modal-dialog">
                                                                            <div class="modal-content">
                                                                                <div class="modal-header">
                                                                                    <button type="button"
                                                                                            class="btn-close"
                                                                                            data-bs-dismiss="modal"
                                                                                            aria-label="Close"></button>
                                                                                </div>
                                                                                <div class="modal-body">
                                                                                    <div class="detail-data-rows">
                                                                                        <div class="detail-data-row">
                                                                                            <span class="detail-data-name">
                                                                                                Oyundaki Karakter Adınız :
                                                                                            </span>
                                                                                            <span class="detail-data-val">
                                                                                                <?php echo $val->character_name ?>
                                                                                            </span>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="modal-footer boder-0">
                                                                                    <button type="button"
                                                                                            class="btn btn-secondary"
                                                                                            data-bs-dismiss="modal">
                                                                                        Kapat
                                                                                    </button>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                <?php } ?>
                                                            <?php } else { ?>
                                                                <div class="sale-cards border-n"><h4
                                                                            class="inside-warning"> Herhangi bir geçmiş
                                                                        tamamlanan satışınız bulunmuyor.</h4></div>
                                                            <?php } ?>
                                                        </div>
                                                        <div class="tab-pane fade" id="pills-canseled-5"
                                                             role="tabpanel" aria-labelledby="pills-canseled-5-tab">
                                                            <?php if (!empty($iptal_edilen_satislarim)) { ?>
                                                                <?php foreach ($iptal_edilen_satislarim as $key => $val) { ?>
                                                                    <div class="sale-cards">
                                                                        <div class="sale-container">
                                                                            <div class="sale-card">
                                                                                <div class="product-detail">
                                                                                    <div class="sale-img">
                                                                                        <a href="javascript:void(0)">
                                                                                            <img src="<?php echo base_url($val->urun_resim_min) ?>">
                                                                                        </a>
                                                                                    </div>
                                                                                    <div class="product-info">
                                                                                        <div class="p-name">
                                                                                            <a href="javascript:void(0)">
                                                                                                <?php echo $val->urun_ad ?>
                                                                                            </a>
                                                                                        </div>
                                                                                        <div class="p-price">
                                                                                            Fiyat:
                                                                                            <span><?php echo $val->urun_alimfiyat ?> TL</span>
                                                                                        </div>
                                                                                        <div class="p-price">
                                                                                            Toplam Kazanç:
                                                                                            <span><?php echo $val->price ?> TL</span>
                                                                                        </div>
                                                                                        <div class="p-quantity">
                                                                                            Adet:
                                                                                            <span><?php echo $val->quantity ?></span>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="sale-status status-2"><i
                                                                                            class="fa-solid fa-ban"></i>
                                                                                    İptal edildi
                                                                                    <button class="btn btn-primary btn-sm sale-detail-button align-self-end mt-3"
                                                                                            data-bs-toggle="modal"
                                                                                            data-bs-target="#info-satim-cancel-modal-<?php echo $val->id ?>">
                                                                                        İletilen Bilgiler
                                                                                    </button>
                                                                                </div>
                                                                                <div class="sale-info">
                                                                                    <div class="s-date">
                                                                                        <i class="fa-regular fa-clock"></i>
                                                                                        <?php echo $val->added_time ?>
                                                                                    </div>
                                                                                    <div class="s-delivery">
                                                                                        Satıcı: <a class="p-seller"
                                                                                                   href="javascript:void(0)"><?php echo $val->kullanici_ad ?></a>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="sale-alerts red">
                                                                                <?php echo $val->reason_for_cancellation ?>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="modal fade"
                                                                         id="info-satim-cancel-modal-<?php echo $val->id ?>"
                                                                         tabindex="-1"
                                                                         aria-labelledby="exampleModalLabel"
                                                                         aria-hidden="true">
                                                                        <div class="modal-dialog">
                                                                            <div class="modal-content">
                                                                                <div class="modal-header">
                                                                                    <button type="button"
                                                                                            class="btn-close"
                                                                                            data-bs-dismiss="modal"
                                                                                            aria-label="Close"></button>
                                                                                </div>
                                                                                <div class="modal-body">
                                                                                    <div class="detail-data-rows">
                                                                                        <div class="detail-data-row">
                                                                        <span class="detail-data-name">
                                                                            Oyundaki Karakter Adınız :
                                                                        </span>
                                                                                            <span class="detail-data-val">
                                                                            <?php echo $val->character_name ?>
                                                                        </span>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="modal-footer boder-0">
                                                                                    <button type="button"
                                                                                            class="btn btn-secondary"
                                                                                            data-bs-dismiss="modal">
                                                                                        Kapat
                                                                                    </button>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                <?php } ?>
                                                            <?php } else { ?>
                                                                <div class="sale-cards border-n"><h4
                                                                            class="inside-warning"> Herhangi bir geçmiş
                                                                        iptal edilen satışınız bulunmuyor.</h4></div>
                                                            <?php } ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>


                                <div class="tab-pane fade" id="orders" role="tabpanel" aria-labelledby="orders-tab"
                                     tabindex="0">
                                    <div class="container-fluid">
                                        <div class="k-panel-content-box">
                                            <div class="row">
                                                <div class="col-12">
                                                    <div class="kpc-tt">
                                                        Siparişlerim
                                                    </div>
                                                    <section class="my-purchases">
                                                        <div class="container">
                                                            <div class="panel ">
                                                                <div class="panel-body bg-snone">
                                                                    <p>Aşağıda bulunan menüden sipariş türü
                                                                        seçimi
                                                                        yapınız. Seçim yaptıktan sonra
                                                                        siparişleriniz
                                                                        listelenecektir.<br>Detayını
                                                                        görmek istediğiniz siparişin
                                                                        üstüne
                                                                        tıklayınız.</p>

                                                                    <div class="alfa-tabs">
                                                                        <ul class="nav nav-tabs">
                                                                            <li class="nav-item " tabindex="3"
                                                                                data-tab="aldigim-urunler"
                                                                                onclick="if (!window.__cfRLUnblockHandlers) return false; updateQueryForTab('aldigim-urunler');onTabChange('aldigim-urunler');">
                                                                                <a class="nav-link  "
                                                                                   data-toggle="tab"
                                                                                   href="#aldigimurunler">Satın
                                                                                    Aldığım Ürünler</a>
                                                                            </li>
                                                                            <li class="nav-item active "
                                                                                tabindex="1"
                                                                                data-tab="aldigim-ilanlar"
                                                                                onclick="if (!window.__cfRLUnblockHandlers) return false; updateQueryForTab('aldigim-ilanlar');onTabChange('aldigim-ilanlar');">
                                                                                <a class="nav-link  active"
                                                                                   data-toggle="tab"
                                                                                   href="#aldiklarim">Aldığım
                                                                                    İlanlar </a>
                                                                            </li>
                                                                            <li class="nav-item "
                                                                                id="sattigim-ilanlar" tabindex="2"
                                                                                data-tab="sattigim-ilanlar"
                                                                                onclick="if (!window.__cfRLUnblockHandlers) return false; updateQueryForTab('sattigim-ilanlar');onTabChange('sattigim-ilanlar');">
                                                                                <a class="nav-link  "
                                                                                   data-toggle="tab"
                                                                                   href="#sattiklarim">Sattığım
                                                                                    İlanlar</a>
                                                                            </li>

                                                                        </ul>
                                                                    </div>

                                                                    <div class="tab-content">
                                                                        <div id="aldiklarim"
                                                                             data-tab="aldigim-ilanlar"
                                                                             class="tab-pane ui tab active"
                                                                             style="padding:0"><br>
                                                                            <div class="well" id="buy-well">
                                                                                <p>*Yapacağınız kelime arama
                                                                                    <b>Sipariş
                                                                                        Numarası</b> ,
                                                                                    <b>İlan
                                                                                        Başlığı</b>
                                                                                    üzerinde
                                                                                    filtrelenecektir.</p>
                                                                                <div class="row">
                                                                                    <div class="col-md-6">
                                                                                        <p>Kelime Arama</p>
                                                                                        <input type="search"
                                                                                               name="searchText"
                                                                                               class="searchText form-control"
                                                                                               style="margin-bottom: 10px;"
                                                                                               placeholder="Filtrelenecek kelimeyi buraya yazınız.">
                                                                                    </div>
                                                                                    <div class="col-md-5">
                                                                                        <p>Sipariş Tarihi
                                                                                        </p>
                                                                                        <input type="date"
                                                                                               class="form-control"
                                                                                               onfocus="this.showPicker()"
                                                                                               name="startDate"
                                                                                               value="">
                                                                                    </div>
                                                                                </div>
                                                                                <button type="button"
                                                                                        class="btn btn-block btn-primary buy-filter"
                                                                                        data-type="buy">Filtrele
                                                                                </button>
                                                                            </div>

                                                                            <div class="aldiklarimIcerik">
                                                                                <div class="col-md-12 text-center"
                                                                                     style="margin:40px 0;">
                                                                                    <div class="spinner-border text-light"
                                                                                         role="status"><span
                                                                                                class="sr-only">Loading...</span>
                                                                                    </div>
                                                                                    <br><br>
                                                                                    <p>İçerik
                                                                                        yükleniyor.<br>Lütfen
                                                                                        bekleyiniz..</p>
                                                                                </div>
                                                                            </div>
                                                                            <div class="ButtonArea text-center">
                                                                            </div>
                                                                        </div>

                                                                        <div id="sattiklarim"
                                                                             data-tab="sattigim-ilanlar"
                                                                             class="ui tab tab-pane "
                                                                             style="padding:0">
                                                                            <br>
                                                                            <div class="sattiklarimIcerik">
                                                                                <div class="col-md-12 text-center"
                                                                                     style="margin:40px 0;">
                                                                                    <div class="spinner-border text-light"
                                                                                         role="status"><span
                                                                                                class="sr-only">Loading...</span>
                                                                                    </div>
                                                                                    <br><br>
                                                                                    <p>İçerik
                                                                                        yükleniyor.<br>Lütfen
                                                                                        bekleyiniz..</p>
                                                                                </div>
                                                                            </div>
                                                                            <div class="ButtonArea text-center">
                                                                            </div>
                                                                        </div>
                                                                        <div id="aldigimurunler"
                                                                             data-tab="aldigim-urunler"
                                                                             class="container tab-pane ui tab  "
                                                                             style="padding:0;    width: 100%;">
                                                                            <br>
                                                                            <div class="urunlerIcerik"
                                                                                 style="justify-content: center">
                                                                                <div class="col-md-12 text-center"
                                                                                     style="margin:40px 0;">
                                                                                    <div class="spinner-border text-light"
                                                                                         role="status"><span
                                                                                                class="sr-only">Loading...</span>
                                                                                    </div>
                                                                                    <br><br>
                                                                                    <p>İçerik
                                                                                        yükleniyor.<br>Lütfen
                                                                                        bekleyiniz..</p>
                                                                                </div>
                                                                            </div>
                                                                            <div class="ButtonArea text-center">
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                                <div class="modal fade" id="degerlendirmeModal"
                                                                     tabindex="-1" role="dialog"
                                                                     aria-labelledby="myModalLabel">
                                                                    <div class="modal-dialog" role="document">
                                                                        <div class="modal-content">
                                                                            <div class="modal-header">
                                                                                <button type="button" class="close"
                                                                                        data-dismiss="modal"
                                                                                        aria-label="Close"
                                                                                        onclick="document.getElementById('degerlendirmeModal').style.display='none'">
                                                                                        <span
                                                                                                aria-hidden="true">×</span>
                                                                                </button>
                                                                                <h4 class="modal-title"
                                                                                    id="myModalLabel">
                                                                                    Ürün
                                                                                    Değerlendirme
                                                                                </h4>
                                                                            </div>
                                                                            <form action="" method="POST" id=""
                                                                                  class="DegerlendirmeFormNotify">
                                                                                <div class="modal-body NotifyPanel">
                                                                                    <input type="hidden"
                                                                                           name="urun-degerlendir-urun-id">
                                                                                    <input type="hidden"
                                                                                           name="urun-degerlendir-siparis-no">
                                                                                    <input type="hidden"
                                                                                           name="urun-degerlendir-magaza-id">
                                                                                    <p>Gerçekleştirmiş
                                                                                        olduğunuz bu
                                                                                        satın alma işlemini
                                                                                        diğer
                                                                                        kullanıcılara
                                                                                        tavsiye
                                                                                        edermisiniz? Bu
                                                                                        satın alma
                                                                                        işleminden
                                                                                        ne
                                                                                        kadar memnun
                                                                                        kaldınız?</p>
                                                                                    <p class="pull-left">
                                                                                        Memnuniyet:</p>
                                                                                    <p class="pull-right"
                                                                                       id="Memnuniyet_Puan">
                                                                                        <b
                                                                                                id="Puan_' . $Data->Id . '">5</b><small>
                                                                                            / 5</small>
                                                                                    </p>
                                                                                    <input type="range" min="1"
                                                                                           max="5" value="5"
                                                                                           class="slider"
                                                                                           name="Memnuniyet"
                                                                                           data-id="' . $Data->Id . '">
                                                                                    <div style="clear:both;">
                                                                                    </div>
                                                                                    <br>
                                                                                    <p class="pull-left">
                                                                                        Yorumunuz:</p>
                                                                                    <textarea name="yorum"
                                                                                              class="form-control"
                                                                                              rows="4" maxlength="150"
                                                                                              minlength="5"
                                                                                              placeholder="Lütfen ürün satın alma deneyiminizi açıklayın. (Örn: Hızlı teslim edildi teşekkürler.)"
                                                                                              required=""></textarea>
                                                                                </div>
                                                                                <div class="modal-footer">
                                                                                    <button type="submit"
                                                                                            class="btn btn-primary btn-block">
                                                                                        Değerlendirmeyi
                                                                                        Gönder
                                                                                    </button>
                                                                                </div>
                                                                            </form>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="tab-pane fade" id="objections" role="tabpanel"
                                     aria-labelledby="objections-tab" tabindex="0">
                                    <div class="container-fluid">
                                        <div class="k-panel-content-box">
                                            <div class="row">
                                                <div class="col-12">
                                                    <div class="kpc-tt">
                                                        Sipariş İtirazlarım
                                                    </div>
                                                    <div class="kpc-item">
                                                        <div class="kpc-border">
                                                            <div class="product-name-panel">
                                                                <h4 class="custom-text-area">
                                                                    <a target="_blank" href=""
                                                                       class="custom-text">Konu</a>
                                                                </h4>
                                                            </div>
                                                            <ul class="list-inline font-size-xs mb-0">
                                                                <li class="list-inline-item">
                                                                    <i class="far fa-clock mr-1"></i>
                                                                    22.02.2024
                                                                    18:35
                                                                </li>
                                                            </ul>
                                                        </div>
                                                        <div class="atq-dsc">
                                                            <p>Lorem ipsum, dolor sit amet consectetur
                                                                adipisicing elit.
                                                                Quasi accusamus itaque hic perspiciatis,
                                                                quaerat dolorum
                                                                quo explicabo et pariatur debitis obcaecati,
                                                                eum esse.
                                                                Facere dignissimos, ipsum quibusdam corporis
                                                                architecto
                                                                repudiandae.</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="tab-pane fade" id="site-sales" role="tabpanel"
                                     aria-labelledby="site-sales-tab" tabindex="0">
                                    <div class="container-fluid">
                                        <div class="k-panel-content-box">
                                            <div class="row">
                                                <div class=" col-12">
                                                    <div class="mb-4">
                                                        <div class="my-sales-tabs">
                                                            <ul class="nav nav-pills mb-3 bg-nav-pills"
                                                                id="pills-tab" role="tablist">
                                                                <li class="nav-item" role="presentation">
                                                                    <button class="nav-link active"
                                                                            id="pills-waiting-tab" data-bs-toggle="pill"
                                                                            data-bs-target="#pills-waiting"
                                                                            type="button" role="tab"
                                                                            aria-controls="pills-waiting"
                                                                            aria-selected="true">Bekleyen
                                                                    </button>
                                                                </li>
                                                                <li class="nav-item" role="presentation">
                                                                    <button class="nav-link" id="pills-complate-tab"
                                                                            data-bs-toggle="pill"
                                                                            data-bs-target="#pills-complate"
                                                                            type="button" role="tab"
                                                                            aria-controls="pills-complate"
                                                                            aria-selected="false">Tamamlanan
                                                                    </button>
                                                                </li>
                                                                <li class="nav-item" role="presentation">
                                                                    <button class="nav-link" id="pills-cancel-tab"
                                                                            data-bs-toggle="pill"
                                                                            data-bs-target="#pills-cancel" type="button"
                                                                            role="tab" aria-controls="pills-cancel"
                                                                            aria-selected="false">İptal
                                                                        Edilenler
                                                                    </button>
                                                                </li>
                                                            </ul>
                                                            <div class="tab-content" id="pills-tabContent">
                                                                <div class="tab-pane fade show active"
                                                                     id="gold-orders" role="tabpanel"
                                                                     aria-labelledby="gold-orders-tab">
                                                                    <?php if (!empty($bekleyen_satislarim)) { ?>
                                                                        <?php foreach ($bekleyen_satislarim as $key => $val) { ?>
                                                                            <div class="sales-box-warper">
                                                                                <div class="sale-cards border-n ">
                                                                                    <div class="sale-container">
                                                                                        <div class="sale-card">
                                                                                            <div class="product-detail">
                                                                                                <div class="sale-img">
                                                                                                    <a
                                                                                                            href="javascript:void(0)">
                                                                                                        <img
                                                                                                                src="<?php echo base_url($val->urun_resim_min) ?>">
                                                                                                    </a>
                                                                                                </div>
                                                                                                <div class="product-info">
                                                                                                    <div class="p-name">
                                                                                                        <a
                                                                                                                href="javascript:void(0)"><?php echo $val->urun_ad ?></a>
                                                                                                    </div>
                                                                                                    <div class="p-price">
                                                                                                        Fiyat:
                                                                                                        <span><?php echo $val->urun_alimfiyat ?>
                                                                                                        TL</span>
                                                                                                    </div>
                                                                                                    <div class="p-price">
                                                                                                        Toplam
                                                                                                        Kazanç:
                                                                                                        <span><?php echo $val->price ?>
                                                                                                        TL</span>
                                                                                                    </div>
                                                                                                    <div class="p-quantity">
                                                                                                        Adet:
                                                                                                        <span><?php echo $val->quantity ?></span>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                            <div
                                                                                                    class="sale-status status-0">
                                                                                                <i
                                                                                                        class="fa-solid fa-gauge-high"></i>
                                                                                                Teslimat
                                                                                                bekliyor
                                                                                                <button
                                                                                                        class="btn btn-primary btn-sm sale-detail-button align-self-end"
                                                                                                        data-bs-toggle="modal"
                                                                                                        data-bs-target="#info-modal-<?php echo $val->id ?>">
                                                                                                    İletilen
                                                                                                    Bilgiler
                                                                                                </button>
                                                                                            </div>
                                                                                            <div class="sale-info">
                                                                                                <div class="s-date">
                                                                                                    <i
                                                                                                            class="fa-regular fa-clock"></i>
                                                                                                    <?php echo $val->added_time ?>
                                                                                                </div>
                                                                                                <div class="s-delivery">
                                                                                                    Satıcı: <a
                                                                                                            class="p-seller"
                                                                                                            href=""><?php echo $val->kullanici_ad ?></a>
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div class="sale-alerts ">
                                                                                            <div>
                                                                                                <?php echo $val->urun_alimbaslik ?>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="modal fade"
                                                                                 id="info-modal-<?php echo $val->id ?>"
                                                                                 tabindex="-1"
                                                                                 aria-labelledby="exampleModalLabel"
                                                                                 aria-hidden="true">
                                                                                <div class="modal-dialog">
                                                                                    <div class="modal-content">
                                                                                        <div class="modal-header">
                                                                                            <button type="button"
                                                                                                    class="btn-close"
                                                                                                    data-bs-dismiss="modal"
                                                                                                    aria-label="Close"></button>
                                                                                        </div>
                                                                                        <div class="modal-body">
                                                                                            <div class="detail-data-rows">
                                                                                                <div
                                                                                                        class="detail-data-row">
                                                                                                <span
                                                                                                        class="detail-data-name">
                                                                                                    Oyundaki
                                                                                                    Karakter
                                                                                                    Adınız :
                                                                                                </span>
                                                                                                    <span
                                                                                                            class="detail-data-val">
                                                                                                    <?php echo $val->character_name ?>
                                                                                                </span>
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div class="modal-footer boder-0">
                                                                                            <button type="button"
                                                                                                    class="btn btn-secondary"
                                                                                                    data-bs-dismiss="modal">
                                                                                                Kapat
                                                                                            </button>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        <?php } ?>
                                                                    <?php } else { ?>
                                                                        <div class="sale-cards border-n">
                                                                            <h4 class="inside-warning"> Herhangi
                                                                                bir geçmiş
                                                                                satışınız bulunmuyor.</h4>
                                                                        </div>
                                                                    <?php } ?>
                                                                </div>
                                                                <div class="tab-pane fade" id="pills-complate"
                                                                     role="tabpanel"
                                                                     aria-labelledby="pills-complate-tab">
                                                                    <?php if (!empty($tamamlanan_satislarim)) { ?>
                                                                        <?php foreach ($tamamlanan_satislarim as $key => $val) { ?>
                                                                            <div class="sale-cards border-n">
                                                                                <div class="sale-container">
                                                                                    <div class="sale-card">
                                                                                        <div class="product-detail">
                                                                                            <div class="sale-img">
                                                                                                <a
                                                                                                        href="javascript:void(0)">
                                                                                                    <img
                                                                                                            src="<?php echo base_url($val->urun_resim_min) ?>">
                                                                                                </a>
                                                                                            </div>
                                                                                            <div class="product-info">
                                                                                                <div class="p-name">
                                                                                                    <a
                                                                                                            href="javascript:void(0)"><?php echo $val->urun_ad ?></a>
                                                                                                </div>
                                                                                                <div class="p-price">
                                                                                                    Fiyat:
                                                                                                    <span><?php echo $val->urun_alimfiyat ?>
                                                                                                    TL</span>
                                                                                                </div>
                                                                                                <div class="p-price">
                                                                                                    Toplam Kazanç:
                                                                                                    <span><?php echo $val->price ?>
                                                                                                    TL</span>
                                                                                                </div>
                                                                                                <div class="p-quantity">
                                                                                                    Adet:
                                                                                                    <span><?php echo $val->quantity ?></span>
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>

                                                                                        <div class="sale-info">
                                                                                            <div class="s-date">
                                                                                                <i
                                                                                                        class="fa-regular fa-clock"></i>
                                                                                                <?php echo $val->added_time ?>
                                                                                            </div>
                                                                                            <div class="s-delivery">
                                                                                                Teslimat Tarihi:
                                                                                                <span><?php echo $val->delivery_date ?></span>
                                                                                            </div>
                                                                                            <div class="s-delivery">
                                                                                                Satıcı: <a
                                                                                                        class="p-seller"
                                                                                                        href=""><?php echo $val->kullanici_ad ?></a>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="sale-status-g">
                                                                                        <div class="sale-status status-1">
                                                                                            <i
                                                                                                    class="fa-solid fa-circle-check"></i>
                                                                                            Teslim
                                                                                            edildi
                                                                                        </div>
                                                                                        <div class="s-name">
                                                                                            Teslim edilecek karakter
                                                                                            adı:
                                                                                            <span>*******</span>
                                                                                        </div>
                                                                                        <button
                                                                                                class="btn btn-primary btn-sm sale-detail-button align-self-end"
                                                                                                data-bs-toggle="modal"
                                                                                                data-bs-target="#info-comp-modal-<?php echo $val->id ?>">
                                                                                            İletilen Bilgiler
                                                                                        </button>

                                                                                    </div>
                                                                                </div>
                                                                                <div class="sale-alerts ">
                                                                                    <div>
                                                                                        <?php echo $val->urun_alimbaslik ?>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="modal fade"
                                                                                 id="info-comp-modal-<?php echo $val->id ?>"
                                                                                 tabindex="-1"
                                                                                 aria-labelledby="exampleModalLabel"
                                                                                 aria-hidden="true">
                                                                                <div class="modal-dialog">
                                                                                    <div class="modal-content">
                                                                                        <div class="modal-header">
                                                                                            <button type="button"
                                                                                                    class="btn-close"
                                                                                                    data-bs-dismiss="modal"
                                                                                                    aria-label="Close"></button>
                                                                                        </div>
                                                                                        <div class="modal-body">
                                                                                            <div class="detail-data-rows">
                                                                                                <div
                                                                                                        class="detail-data-row">
                                                                                                <span
                                                                                                        class="detail-data-name">
                                                                                                    Oyundaki
                                                                                                    Karakter
                                                                                                    Adınız :
                                                                                                </span>
                                                                                                    <span
                                                                                                            class="detail-data-val">
                                                                                                    <?php echo $val->character_name ?>
                                                                                                </span>
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div class="modal-footer boder-0">
                                                                                            <button type="button"
                                                                                                    class="btn btn-secondary"
                                                                                                    data-bs-dismiss="modal">
                                                                                                Kapat
                                                                                            </button>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        <?php } ?>
                                                                    <?php } else { ?>
                                                                        <div class="sale-cards border-n">
                                                                            <h4 class="inside-warning"><i
                                                                                        class="fad fa-engine-warning"></i>
                                                                                Herhangi bir geçmiş
                                                                                satışınız bulunmuyor.</h4>
                                                                        </div>
                                                                    <?php } ?>
                                                                </div>
                                                                <div class="tab-pane fade" id="pills-cancel"
                                                                     role="tabpanel"
                                                                     aria-labelledby="pills-cancel-tab">
                                                                    <?php if (!empty($iptal_edilen_satislarim)) { ?>
                                                                        <?php foreach ($iptal_edilen_satislarim as $key => $val) { ?>
                                                                            <div class="sale-cards border-n">
                                                                                <div class="sale-container">
                                                                                    <div class="sale-card">
                                                                                        <div class="product-detail">
                                                                                            <div class="sale-img">
                                                                                                <a
                                                                                                        href="javascript:void(0)">
                                                                                                    <img
                                                                                                            src="<?php echo base_url($val->urun_resim_min) ?>">
                                                                                                </a>
                                                                                            </div>
                                                                                            <div class="product-info">
                                                                                                <div class="p-name">
                                                                                                    <a
                                                                                                            href="javascript:void(0)">
                                                                                                        <?php echo $val->urun_ad ?>
                                                                                                    </a>
                                                                                                </div>
                                                                                                <div class="p-price">
                                                                                                    Fiyat:
                                                                                                    <span><?php echo $val->urun_alimfiyat ?>
                                                                                                    TL</span>
                                                                                                </div>
                                                                                                <div class="p-price">
                                                                                                    Toplam Kazanç:
                                                                                                    <span><?php echo $val->price ?>
                                                                                                    TL</span>
                                                                                                </div>
                                                                                                <div class="p-quantity">
                                                                                                    Adet:
                                                                                                    <span><?php echo $val->quantity ?></span>
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div class="sale-status status-2">
                                                                                            <i class="fa-solid fa-ban"></i>
                                                                                            İptal edildi
                                                                                            <button
                                                                                                    class="btn btn-primary btn-sm sale-detail-button align-self-end mt-3"
                                                                                                    data-bs-toggle="modal"
                                                                                                    data-bs-target="#info-cancel-modal-<?php echo $val->id ?>">
                                                                                                İletilen Bilgiler
                                                                                            </button>
                                                                                        </div>
                                                                                        <div class="sale-info">
                                                                                            <div class="s-date">
                                                                                                <i class="fad fa-clock"></i>
                                                                                                <?php echo $val->added_time ?>
                                                                                            </div>
                                                                                            <div class="s-delivery">
                                                                                                Satıcı: <a
                                                                                                        class="p-seller"
                                                                                                        href="javascript:void(0)"><?php echo $val->kullanici_ad ?></a>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="sale-alerts red">
                                                                                        Satışınız iptal edilmiştir.
                                                                                        <?php echo $val->reason_for_cancellation ?>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="modal fade"
                                                                                 id="info-cancel-modal-<?php echo $val->id ?>"
                                                                                 tabindex="-1"
                                                                                 aria-labelledby="exampleModalLabel"
                                                                                 aria-hidden="true">
                                                                                <div class="modal-dialog">
                                                                                    <div class="modal-content">
                                                                                        <div class="modal-header">
                                                                                            <button type="button"
                                                                                                    class="btn-close"
                                                                                                    data-bs-dismiss="modal"
                                                                                                    aria-label="Close"></button>
                                                                                        </div>
                                                                                        <div class="modal-body">
                                                                                            <div class="detail-data-rows">
                                                                                                <div
                                                                                                        class="detail-data-row">
                                                                                                <span
                                                                                                        class="detail-data-name">
                                                                                                    Oyundaki
                                                                                                    Karakter
                                                                                                    Adınız :
                                                                                                </span>
                                                                                                    <span
                                                                                                            class="detail-data-val">
                                                                                                    <?php echo $val->character_name ?>
                                                                                                </span>
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div class="modal-footer boder-0">
                                                                                            <button type="button"
                                                                                                    class="btn btn-secondary"
                                                                                                    data-bs-dismiss="modal">
                                                                                                Kapat
                                                                                            </button>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        <?php } ?>
                                                                    <?php } else { ?>
                                                                        <div class="sale-cards border-n ">
                                                                            <h4 class="inside-warning"><i
                                                                                        class="fad fa-engine-warning"></i>
                                                                                Herhangi bir geçmiş
                                                                                satışınız bulunmuyor.</h4>
                                                                        </div>
                                                                    <?php } ?>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="get-gold-warper">
                                                            <h3 class="h4 mb-3">Satın Aldıklarım</h3>
                                                            <div class="getgold-area">
                                                                <ul class="nav nav-pills mb-3 bg-nav-pills"
                                                                    id="pills-tab" role="tablist">
                                                                    <li class="nav-item" role="presentation">
                                                                        <button class="nav-link active"
                                                                                id="pills-waiting-5-tab"
                                                                                data-bs-toggle="pill"
                                                                                data-bs-target="#pills-waiting-5"
                                                                                type="button" role="tab"
                                                                                aria-controls="pills-waiting-5"
                                                                                aria-selected="true">Bekleyen
                                                                        </button>
                                                                    </li>
                                                                    <li class="nav-item" role="presentation">
                                                                        <button class="nav-link"
                                                                                id="pills-complate-5-tab"
                                                                                data-bs-toggle="pill"
                                                                                data-bs-target="#pills-complate-5"
                                                                                type="button" role="tab"
                                                                                aria-controls="pills-complate-5"
                                                                                aria-selected="false">Teslim
                                                                            Edilen
                                                                        </button>
                                                                    </li>
                                                                    <li class="nav-item" role="presentation">
                                                                        <button class="nav-link"
                                                                                id="pills-canseled-5-tab"
                                                                                data-bs-toggle="pill"
                                                                                data-bs-target="#pills-canseled-5"
                                                                                type="button" role="tab"
                                                                                aria-controls="pills-canseled-5"
                                                                                aria-selected="false">İptal
                                                                            Edilen
                                                                        </button>
                                                                    </li>
                                                                </ul>
                                                            </div>

                                                            <div class="tab-content" id="pills-tabContent">
                                                                <div class="tab-pane fade show active"
                                                                     id="pills-waiting-5" role="tabpanel"
                                                                     aria-labelledby="pills-waiting-5-tab">
                                                                    <div class="sale-cards">
                                                                        <div class="sale-container">
                                                                            <div class="sale-card">
                                                                                <div class="product-detail">
                                                                                    <div class="sale-img"><a
                                                                                                href=""><img
                                                                                                    src="https://kemalellidort.com.tr/uploads/urunler/images/min/8399e2b6f9b8a91709d8dbbffc4b6e18.png"></a>
                                                                                    </div>
                                                                                    <div class="product-info">
                                                                                        <div class="p-name">
                                                                                            <a href="">Silkroad
                                                                                                Turkey 300
                                                                                                Silk</a>
                                                                                        </div>
                                                                                        <div class="p-price">
                                                                                            Fiyat:
                                                                                            <span>180
                                                                                                    TL</span>
                                                                                        </div>
                                                                                        <div class="p-price">
                                                                                            Toplam
                                                                                            Kazanç:<span>360.00
                                                                                                    TL</span>
                                                                                        </div>
                                                                                        <div class="p-quantity">
                                                                                            Adet:<span>2</span>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="sale-status status-0">
                                                                                    <i
                                                                                            class="fa-solid fa-gauge-high"></i>
                                                                                    Teslimat bekliyor
                                                                                    <button
                                                                                            class="btn btn-primary btn-sm sale-detail-button align-self-end"
                                                                                            data-bs-toggle="modal"
                                                                                            data-bs-target="#info-modal-3">
                                                                                        İletilen Bilgiler
                                                                                    </button>
                                                                                </div>
                                                                                <div class="sale-info">
                                                                                    <div class="s-date"><i
                                                                                                class="fa-regular fa-clock"></i>2024-03-08
                                                                                        17:53:27
                                                                                    </div>
                                                                                    <div class="s-delivery">
                                                                                        Satıcı: <a class="p-seller"
                                                                                                   href="">admin</a>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="sale-alerts ">
                                                                                <div>Teslim Yeri : denemee
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="tab-pane fade" id="pills-complate-5"
                                                                     role="tabpanel"
                                                                     aria-labelledby="pills-complate-5-tab">
                                                                    <div class="sale-cards">
                                                                        <div class="sale-container">
                                                                            <div class="sale-card">
                                                                                <div class="product-detail">
                                                                                    <div class="sale-img">
                                                                                        <a href="">
                                                                                            <img
                                                                                                    src="https://bursagb.s3.eu-central-1.amazonaws.com/AGARTHA_1691835141.webp">
                                                                                        </a>
                                                                                    </div>
                                                                                    <div class="product-info">
                                                                                        <div class="p-name">
                                                                                            <a href="">Agartha
                                                                                                10M Gold
                                                                                                Bar</a>
                                                                                        </div>
                                                                                        <div class="p-price">
                                                                                            Fiyat:
                                                                                            <span>32.21
                                                                                                    TL</span>
                                                                                        </div>
                                                                                        <div class="p-price">
                                                                                            Toplam Kazanç:
                                                                                            <span>32.21
                                                                                                    TL</span>
                                                                                        </div>
                                                                                        <div class="p-quantity">
                                                                                            Adet:
                                                                                            <span>1</span>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="sale-info">
                                                                                    <div class="s-date">
                                                                                        <i
                                                                                                class="fa-regular fa-clock"></i>
                                                                                        2024-03-07 14:16:57
                                                                                    </div>
                                                                                    <div class="s-delivery">
                                                                                        Teslimat Tarihi:
                                                                                        <span>2024-03-07
                                                                                                17:41:34</span>
                                                                                    </div>
                                                                                    <div class="s-delivery">
                                                                                        Satıcı: <a class="p-seller"
                                                                                                   href="">Hyper</a>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="sale-status status-1 dflx">
                                                                                <div class="te-ip">
                                                                                    <i
                                                                                            class="fa-solid fa-circle-check"></i>
                                                                                    Teslim edildi
                                                                                </div>
                                                                                <div class="s-name">
                                                                                    Teslim edilecek karakter
                                                                                    adı:
                                                                                    <span>*******</span>
                                                                                </div>
                                                                                <div
                                                                                        class="btn btn-primary btn-sm sale-detail-button align-self-end">
                                                                                    İletilen Bilgiler
                                                                                </div>

                                                                            </div>
                                                                            <div class="sale-alerts ">
                                                                                <div>Teslimat Yeri : Agartha
                                                                                    2. Server Folk
                                                                                    Banka Teslimat '' TRADE
                                                                                    '' ile yapılır.
                                                                                    Takas geçmeden önce
                                                                                    belirtilen alanda
                                                                                    hazır olunuz.
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="tab-pane fade" id="pills-canseled-5"
                                                                     role="tabpanel"
                                                                     aria-labelledby="pills-canseled-5-tab">
                                                                    <div class="sale-cards">
                                                                        <div class="sale-container">
                                                                            <div class="sale-card">
                                                                                <div class="product-detail">
                                                                                    <div class="sale-img">
                                                                                        <a href="">
                                                                                            <img
                                                                                                    src="https://bursagb.s3.eu-central-1.amazonaws.com/AGARTHA_1691835141.webp">
                                                                                        </a>
                                                                                    </div>
                                                                                    <div class="product-info">
                                                                                        <div class="p-name">
                                                                                            <a href="">Agartha
                                                                                                10M Gold
                                                                                                Bar</a>
                                                                                        </div>
                                                                                        <div class="p-price">
                                                                                            Fiyat:
                                                                                            <span>32.20
                                                                                                    TL</span>
                                                                                        </div>
                                                                                        <div class="p-price">
                                                                                            Toplam Kazanç:
                                                                                            <span>64.40
                                                                                                    TL</span>
                                                                                        </div>
                                                                                        <div class="p-quantity">
                                                                                            Adet:
                                                                                            <span>2</span>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="sale-status status-2">
                                                                                    <i class="fa-solid fa-ban"></i>
                                                                                    İptal edildi
                                                                                    <div
                                                                                            class="btn btn-primary btn-sm sale-detail-button align-self-end mt-3">
                                                                                        İletilen Bilgiler
                                                                                    </div>
                                                                                </div>
                                                                                <div class="sale-info">
                                                                                    <div class="s-date">
                                                                                        <i
                                                                                                class="fa-regular fa-clock"></i>
                                                                                        2024-03-09 17:44:25
                                                                                    </div>
                                                                                    <div class="s-delivery">
                                                                                        Satıcı: <a class="p-seller"
                                                                                                   href="">Hyper</a>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="sale-alerts red">
                                                                                Satışınız iptal
                                                                                edilmiştir. Karakter Oyunda
                                                                                yada Teslimat
                                                                                Noktasında Değil.
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="tab-pane fade" id="site-sales" role="tabpanel"
                                     aria-labelledby="site-sales-tab" tabindex="0">
                                    <div class="container-fluid">
                                        <div class="k-panel-content-box">
                                            <div class="row">
                                                <div class=" col-12">
                                                    <div class="mb-4">
                                                        <h3 class="h4 mb-3">Satışlarım</h3>
                                                        <div class="my-sales-tabs">
                                                            <ul class="nav nav-pills mb-3 bg-nav-pills"
                                                                id="pills-tab" role="tablist">
                                                                <li class="nav-item" role="presentation">
                                                                    <button class="nav-link active"
                                                                            id="pills-waiting-tab" data-bs-toggle="pill"
                                                                            data-bs-target="#pills-waiting"
                                                                            type="button" role="tab"
                                                                            aria-controls="pills-waiting"
                                                                            aria-selected="true">Bekleyen
                                                                    </button>
                                                                </li>
                                                                <li class="nav-item" role="presentation">
                                                                    <button class="nav-link" id="pills-complate-tab"
                                                                            data-bs-toggle="pill"
                                                                            data-bs-target="#pills-complate"
                                                                            type="button" role="tab"
                                                                            aria-controls="pills-complate"
                                                                            aria-selected="false">Tamamlanan
                                                                    </button>
                                                                </li>
                                                                <li class="nav-item" role="presentation">
                                                                    <button class="nav-link" id="pills-cancel-tab"
                                                                            data-bs-toggle="pill"
                                                                            data-bs-target="#pills-cancel" type="button"
                                                                            role="tab" aria-controls="pills-cancel"
                                                                            aria-selected="false">İptal
                                                                        Edilenler
                                                                    </button>
                                                                </li>
                                                            </ul>
                                                            <div class="tab-content" id="pills-tabContent">
                                                                <div class="tab-pane fade show active"
                                                                     id="pills-waiting" role="tabpanel"
                                                                     aria-labelledby="pills-waiting-tab">
                                                                    <?php if (!empty($bekleyen_satislarim)) { ?>
                                                                        <?php foreach ($bekleyen_satislarim as $key => $val) { ?>
                                                                            <div class="sales-box-warper">
                                                                                <div class="sale-cards border-n ">
                                                                                    <div class="sale-container">
                                                                                        <div class="sale-card">
                                                                                            <div class="product-detail">
                                                                                                <div class="sale-img">
                                                                                                    <a
                                                                                                            href="javascript:void(0)">
                                                                                                        <img
                                                                                                                src="<?php echo base_url($val->urun_resim_min) ?>">
                                                                                                    </a>
                                                                                                </div>
                                                                                                <div class="product-info">
                                                                                                    <div class="p-name">
                                                                                                        <a
                                                                                                                href="javascript:void(0)"><?php echo $val->urun_ad ?></a>
                                                                                                    </div>
                                                                                                    <div class="p-price">
                                                                                                        Fiyat:
                                                                                                        <span><?php echo $val->urun_alimfiyat ?>
                                                                                                        TL</span>
                                                                                                    </div>
                                                                                                    <div class="p-price">
                                                                                                        Toplam
                                                                                                        Kazanç:
                                                                                                        <span><?php echo $val->price ?>
                                                                                                        TL</span>
                                                                                                    </div>
                                                                                                    <div class="p-quantity">
                                                                                                        Adet:
                                                                                                        <span><?php echo $val->quantity ?></span>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                            <div
                                                                                                    class="sale-status status-0">
                                                                                                <i
                                                                                                        class="fa-solid fa-gauge-high"></i>
                                                                                                Teslimat
                                                                                                bekliyor
                                                                                                <button
                                                                                                        class="btn btn-primary btn-sm sale-detail-button align-self-end"
                                                                                                        data-bs-toggle="modal"
                                                                                                        data-bs-target="#info-modal-<?php echo $val->id ?>">
                                                                                                    İletilen
                                                                                                    Bilgiler
                                                                                                </button>
                                                                                            </div>
                                                                                            <div class="sale-info">
                                                                                                <div class="s-date">
                                                                                                    <i
                                                                                                            class="fa-regular fa-clock"></i>
                                                                                                    <?php echo $val->added_time ?>
                                                                                                </div>
                                                                                                <div class="s-delivery">
                                                                                                    Satıcı: <a
                                                                                                            class="p-seller"
                                                                                                            href=""><?php echo $val->kullanici_ad ?></a>
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div class="sale-alerts ">
                                                                                            <div>
                                                                                                <?php echo $val->urun_alimbaslik ?>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="modal fade"
                                                                                 id="info-modal-<?php echo $val->id ?>"
                                                                                 tabindex="-1"
                                                                                 aria-labelledby="exampleModalLabel"
                                                                                 aria-hidden="true">
                                                                                <div class="modal-dialog">
                                                                                    <div class="modal-content">
                                                                                        <div class="modal-header">
                                                                                            <button type="button"
                                                                                                    class="btn-close"
                                                                                                    data-bs-dismiss="modal"
                                                                                                    aria-label="Close"></button>
                                                                                        </div>
                                                                                        <div class="modal-body">
                                                                                            <div class="detail-data-rows">
                                                                                                <div
                                                                                                        class="detail-data-row">
                                                                                                <span
                                                                                                        class="detail-data-name">
                                                                                                    Oyundaki
                                                                                                    Karakter
                                                                                                    Adınız :
                                                                                                </span>
                                                                                                    <span
                                                                                                            class="detail-data-val">
                                                                                                    <?php echo $val->character_name ?>
                                                                                                </span>
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div class="modal-footer boder-0">
                                                                                            <button type="button"
                                                                                                    class="btn btn-secondary"
                                                                                                    data-bs-dismiss="modal">
                                                                                                Kapat
                                                                                            </button>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        <?php } ?>
                                                                    <?php } else { ?>
                                                                        <div class="sale-cards border-n">
                                                                            <h4 class="inside-warning"> Herhangi
                                                                                bir geçmiş
                                                                                satışınız bulunmuyor.</h4>
                                                                        </div>
                                                                    <?php } ?>
                                                                </div>
                                                                <div class="tab-pane fade" id="pills-complate"
                                                                     role="tabpanel"
                                                                     aria-labelledby="pills-complate-tab">
                                                                    <?php if (!empty($tamamlanan_satislarim)) { ?>
                                                                        <?php foreach ($tamamlanan_satislarim as $key => $val) { ?>
                                                                            <div class="sale-cards border-n">
                                                                                <div class="sale-container">
                                                                                    <div class="sale-card">
                                                                                        <div class="product-detail">
                                                                                            <div class="sale-img">
                                                                                                <a
                                                                                                        href="javascript:void(0)">
                                                                                                    <img
                                                                                                            src="<?php echo base_url($val->urun_resim_min) ?>">
                                                                                                </a>
                                                                                            </div>
                                                                                            <div class="product-info">
                                                                                                <div class="p-name">
                                                                                                    <a
                                                                                                            href="javascript:void(0)"><?php echo $val->urun_ad ?></a>
                                                                                                </div>
                                                                                                <div class="p-price">
                                                                                                    Fiyat:
                                                                                                    <span><?php echo $val->urun_alimfiyat ?>
                                                                                                    TL</span>
                                                                                                </div>
                                                                                                <div class="p-price">
                                                                                                    Toplam Kazanç:
                                                                                                    <span><?php echo $val->price ?>
                                                                                                    TL</span>
                                                                                                </div>
                                                                                                <div class="p-quantity">
                                                                                                    Adet:
                                                                                                    <span><?php echo $val->quantity ?></span>
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>

                                                                                        <div class="sale-info">
                                                                                            <div class="s-date">
                                                                                                <i
                                                                                                        class="fa-regular fa-clock"></i>
                                                                                                <?php echo $val->added_time ?>
                                                                                            </div>
                                                                                            <div class="s-delivery">
                                                                                                Teslimat Tarihi:
                                                                                                <span><?php echo $val->delivery_date ?></span>
                                                                                            </div>
                                                                                            <div class="s-delivery">
                                                                                                Satıcı: <a
                                                                                                        class="p-seller"
                                                                                                        href=""><?php echo $val->kullanici_ad ?></a>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="sale-status-g">
                                                                                        <div class="sale-status status-1">
                                                                                            <i
                                                                                                    class="fa-solid fa-circle-check"></i>
                                                                                            Teslim
                                                                                            edildi
                                                                                        </div>
                                                                                        <div class="s-name">
                                                                                            Teslim edilecek karakter
                                                                                            adı:
                                                                                            <span>*******</span>
                                                                                        </div>
                                                                                        <button
                                                                                                class="btn btn-primary btn-sm sale-detail-button align-self-end"
                                                                                                data-bs-toggle="modal"
                                                                                                data-bs-target="#info-comp-modal-<?php echo $val->id ?>">
                                                                                            İletilen Bilgiler
                                                                                        </button>

                                                                                    </div>
                                                                                </div>
                                                                                <div class="sale-alerts ">
                                                                                    <div>
                                                                                        <?php echo $val->urun_alimbaslik ?>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="modal fade"
                                                                                 id="info-comp-modal-<?php echo $val->id ?>"
                                                                                 tabindex="-1"
                                                                                 aria-labelledby="exampleModalLabel"
                                                                                 aria-hidden="true">
                                                                                <div class="modal-dialog">
                                                                                    <div class="modal-content">
                                                                                        <div class="modal-header">
                                                                                            <button type="button"
                                                                                                    class="btn-close"
                                                                                                    data-bs-dismiss="modal"
                                                                                                    aria-label="Close"></button>
                                                                                        </div>
                                                                                        <div class="modal-body">
                                                                                            <div class="detail-data-rows">
                                                                                                <div
                                                                                                        class="detail-data-row">
                                                                                                <span
                                                                                                        class="detail-data-name">
                                                                                                    Oyundaki
                                                                                                    Karakter
                                                                                                    Adınız :
                                                                                                </span>
                                                                                                    <span
                                                                                                            class="detail-data-val">
                                                                                                    <?php echo $val->character_name ?>
                                                                                                </span>
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div class="modal-footer boder-0">
                                                                                            <button type="button"
                                                                                                    class="btn btn-secondary"
                                                                                                    data-bs-dismiss="modal">
                                                                                                Kapat
                                                                                            </button>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        <?php } ?>
                                                                    <?php } else { ?>
                                                                        <div class="sale-cards border-n">
                                                                            <h4 class="inside-warning"><i
                                                                                        class="fad fa-engine-warning"></i>
                                                                                Herhangi bir geçmiş
                                                                                satışınız bulunmuyor.</h4>
                                                                        </div>
                                                                    <?php } ?>
                                                                </div>
                                                                <div class="tab-pane fade" id="pills-cancel"
                                                                     role="tabpanel"
                                                                     aria-labelledby="pills-cancel-tab">
                                                                    <?php if (!empty($iptal_edilen_satislarim)) { ?>
                                                                        <?php foreach ($iptal_edilen_satislarim as $key => $val) { ?>
                                                                            <div class="sale-cards border-n">
                                                                                <div class="sale-container">
                                                                                    <div class="sale-card">
                                                                                        <div class="product-detail">
                                                                                            <div class="sale-img">
                                                                                                <a
                                                                                                        href="javascript:void(0)">
                                                                                                    <img
                                                                                                            src="<?php echo base_url($val->urun_resim_min) ?>">
                                                                                                </a>
                                                                                            </div>
                                                                                            <div class="product-info">
                                                                                                <div class="p-name">
                                                                                                    <a
                                                                                                            href="javascript:void(0)">
                                                                                                        <?php echo $val->urun_ad ?>
                                                                                                    </a>
                                                                                                </div>
                                                                                                <div class="p-price">
                                                                                                    Fiyat:
                                                                                                    <span><?php echo $val->urun_alimfiyat ?>
                                                                                                    TL</span>
                                                                                                </div>
                                                                                                <div class="p-price">
                                                                                                    Toplam Kazanç:
                                                                                                    <span><?php echo $val->price ?>
                                                                                                    TL</span>
                                                                                                </div>
                                                                                                <div class="p-quantity">
                                                                                                    Adet:
                                                                                                    <span><?php echo $val->quantity ?></span>
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div class="sale-status status-2">
                                                                                            <i class="fa-solid fa-ban"></i>
                                                                                            İptal edildi
                                                                                            <button
                                                                                                    class="btn btn-primary btn-sm sale-detail-button align-self-end mt-3"
                                                                                                    data-bs-toggle="modal"
                                                                                                    data-bs-target="#info-cancel-modal-<?php echo $val->id ?>">
                                                                                                İletilen Bilgiler
                                                                                            </button>
                                                                                        </div>
                                                                                        <div class="sale-info">
                                                                                            <div class="s-date">
                                                                                                <i class="fad fa-clock"></i>
                                                                                                <?php echo $val->added_time ?>
                                                                                            </div>
                                                                                            <div class="s-delivery">
                                                                                                Satıcı: <a
                                                                                                        class="p-seller"
                                                                                                        href="javascript:void(0)"><?php echo $val->kullanici_ad ?></a>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="sale-alerts red">
                                                                                        Satışınız iptal edilmiştir.
                                                                                        <?php echo $val->reason_for_cancellation ?>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="modal fade"
                                                                                 id="info-cancel-modal-<?php echo $val->id ?>"
                                                                                 tabindex="-1"
                                                                                 aria-labelledby="exampleModalLabel"
                                                                                 aria-hidden="true">
                                                                                <div class="modal-dialog">
                                                                                    <div class="modal-content">
                                                                                        <div class="modal-header">
                                                                                            <button type="button"
                                                                                                    class="btn-close"
                                                                                                    data-bs-dismiss="modal"
                                                                                                    aria-label="Close"></button>
                                                                                        </div>
                                                                                        <div class="modal-body">
                                                                                            <div class="detail-data-rows">
                                                                                                <div
                                                                                                        class="detail-data-row">
                                                                                                <span
                                                                                                        class="detail-data-name">
                                                                                                    Oyundaki
                                                                                                    Karakter
                                                                                                    Adınız :
                                                                                                </span>
                                                                                                    <span
                                                                                                            class="detail-data-val">
                                                                                                    <?php echo $val->character_name ?>
                                                                                                </span>
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div class="modal-footer boder-0">
                                                                                            <button type="button"
                                                                                                    class="btn btn-secondary"
                                                                                                    data-bs-dismiss="modal">
                                                                                                Kapat
                                                                                            </button>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        <?php } ?>
                                                                    <?php } else { ?>
                                                                        <div class="sale-cards border-n ">
                                                                            <h4 class="inside-warning"><i
                                                                                        class="fad fa-engine-warning"></i>
                                                                                Herhangi bir geçmiş
                                                                                satışınız bulunmuyor.</h4>
                                                                        </div>
                                                                    <?php } ?>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="get-gold-warper">
                                                            <h3 class="h4 mb-3">Satın Aldıklarım</h3>
                                                            <div class="getgold-area">
                                                                <ul class="nav nav-pills mb-3 bg-nav-pills"
                                                                    id="pills-tab" role="tablist">
                                                                    <li class="nav-item" role="presentation">
                                                                        <button class="nav-link active"
                                                                                id="pills-waiting-5-tab"
                                                                                data-bs-toggle="pill"
                                                                                data-bs-target="#pills-waiting-5"
                                                                                type="button" role="tab"
                                                                                aria-controls="pills-waiting-5"
                                                                                aria-selected="true">Bekleyen
                                                                        </button>
                                                                    </li>
                                                                    <li class="nav-item" role="presentation">
                                                                        <button class="nav-link"
                                                                                id="pills-complate-5-tab"
                                                                                data-bs-toggle="pill"
                                                                                data-bs-target="#pills-complate-5"
                                                                                type="button" role="tab"
                                                                                aria-controls="pills-complate-5"
                                                                                aria-selected="false">Teslim
                                                                            Edilen
                                                                        </button>
                                                                    </li>
                                                                    <li class="nav-item" role="presentation">
                                                                        <button class="nav-link"
                                                                                id="pills-canseled-5-tab"
                                                                                data-bs-toggle="pill"
                                                                                data-bs-target="#pills-canseled-5"
                                                                                type="button" role="tab"
                                                                                aria-controls="pills-canseled-5"
                                                                                aria-selected="false">İptal
                                                                            Edilen
                                                                        </button>
                                                                    </li>
                                                                </ul>
                                                            </div>

                                                            <div class="tab-content" id="pills-tabContent">
                                                                <div class="tab-pane fade show active"
                                                                     id="pills-waiting-5" role="tabpanel"
                                                                     aria-labelledby="pills-waiting-5-tab">
                                                                    <div class="sale-cards">
                                                                        <div class="sale-container">
                                                                            <div class="sale-card">
                                                                                <div class="product-detail">
                                                                                    <div class="sale-img"><a
                                                                                                href=""><img
                                                                                                    src="https://kemalellidort.com.tr/uploads/urunler/images/min/8399e2b6f9b8a91709d8dbbffc4b6e18.png"></a>
                                                                                    </div>
                                                                                    <div class="product-info">
                                                                                        <div class="p-name">
                                                                                            <a href="">Silkroad
                                                                                                Turkey 300
                                                                                                Silk</a>
                                                                                        </div>
                                                                                        <div class="p-price">
                                                                                            Fiyat:
                                                                                            <span>180
                                                                                                    TL</span>
                                                                                        </div>
                                                                                        <div class="p-price">
                                                                                            Toplam
                                                                                            Kazanç:<span>360.00
                                                                                                    TL</span>
                                                                                        </div>
                                                                                        <div class="p-quantity">
                                                                                            Adet:<span>2</span>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="sale-status status-0">
                                                                                    <i
                                                                                            class="fa-solid fa-gauge-high"></i>
                                                                                    Teslimat bekliyor
                                                                                    <button
                                                                                            class="btn btn-primary btn-sm sale-detail-button align-self-end"
                                                                                            data-bs-toggle="modal"
                                                                                            data-bs-target="#info-modal-3">
                                                                                        İletilen Bilgiler
                                                                                    </button>
                                                                                </div>
                                                                                <div class="sale-info">
                                                                                    <div class="s-date"><i
                                                                                                class="fa-regular fa-clock"></i>2024-03-08
                                                                                        17:53:27
                                                                                    </div>
                                                                                    <div class="s-delivery">
                                                                                        Satıcı: <a class="p-seller"
                                                                                                   href="">admin</a>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="sale-alerts ">
                                                                                <div>Teslim Yeri : denemee
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="tab-pane fade" id="pills-complate-5"
                                                                     role="tabpanel"
                                                                     aria-labelledby="pills-complate-5-tab">
                                                                    <div class="sale-cards">
                                                                        <div class="sale-container">
                                                                            <div class="sale-card">
                                                                                <div class="product-detail">
                                                                                    <div class="sale-img">
                                                                                        <a href="">
                                                                                            <img
                                                                                                    src="https://bursagb.s3.eu-central-1.amazonaws.com/AGARTHA_1691835141.webp">
                                                                                        </a>
                                                                                    </div>
                                                                                    <div class="product-info">
                                                                                        <div class="p-name">
                                                                                            <a href="">Agartha
                                                                                                10M Gold
                                                                                                Bar</a>
                                                                                        </div>
                                                                                        <div class="p-price">
                                                                                            Fiyat:
                                                                                            <span>32.21
                                                                                                    TL</span>
                                                                                        </div>
                                                                                        <div class="p-price">
                                                                                            Toplam Kazanç:
                                                                                            <span>32.21
                                                                                                    TL</span>
                                                                                        </div>
                                                                                        <div class="p-quantity">
                                                                                            Adet:
                                                                                            <span>1</span>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="sale-info">
                                                                                    <div class="s-date">
                                                                                        <i
                                                                                                class="fa-regular fa-clock"></i>
                                                                                        2024-03-07 14:16:57
                                                                                    </div>
                                                                                    <div class="s-delivery">
                                                                                        Teslimat Tarihi:
                                                                                        <span>2024-03-07
                                                                                                17:41:34</span>
                                                                                    </div>
                                                                                    <div class="s-delivery">
                                                                                        Satıcı: <a class="p-seller"
                                                                                                   href="">Hyper</a>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="sale-status status-1 dflx">
                                                                                <div class="te-ip">
                                                                                    <i
                                                                                            class="fa-solid fa-circle-check"></i>
                                                                                    Teslim edildi
                                                                                </div>
                                                                                <div class="s-name">
                                                                                    Teslim edilecek karakter
                                                                                    adı:
                                                                                    <span>*******</span>
                                                                                </div>
                                                                                <div
                                                                                        class="btn btn-primary btn-sm sale-detail-button align-self-end">
                                                                                    İletilen Bilgiler
                                                                                </div>

                                                                            </div>
                                                                            <div class="sale-alerts ">
                                                                                <div>Teslimat Yeri : Agartha
                                                                                    2. Server Folk
                                                                                    Banka Teslimat '' TRADE
                                                                                    '' ile yapılır.
                                                                                    Takas geçmeden önce
                                                                                    belirtilen alanda
                                                                                    hazır olunuz.
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="tab-pane fade" id="pills-canseled-5"
                                                                     role="tabpanel"
                                                                     aria-labelledby="pills-canseled-5-tab">
                                                                    <div class="sale-cards">
                                                                        <div class="sale-container">
                                                                            <div class="sale-card">
                                                                                <div class="product-detail">
                                                                                    <div class="sale-img">
                                                                                        <a href="">
                                                                                            <img
                                                                                                    src="https://bursagb.s3.eu-central-1.amazonaws.com/AGARTHA_1691835141.webp">
                                                                                        </a>
                                                                                    </div>
                                                                                    <div class="product-info">
                                                                                        <div class="p-name">
                                                                                            <a href="">Agartha
                                                                                                10M Gold
                                                                                                Bar</a>
                                                                                        </div>
                                                                                        <div class="p-price">
                                                                                            Fiyat:
                                                                                            <span>32.20
                                                                                                    TL</span>
                                                                                        </div>
                                                                                        <div class="p-price">
                                                                                            Toplam Kazanç:
                                                                                            <span>64.40
                                                                                                    TL</span>
                                                                                        </div>
                                                                                        <div class="p-quantity">
                                                                                            Adet:
                                                                                            <span>2</span>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="sale-status status-2">
                                                                                    <i class="fa-solid fa-ban"></i>
                                                                                    İptal edildi
                                                                                    <div
                                                                                            class="btn btn-primary btn-sm sale-detail-button align-self-end mt-3">
                                                                                        İletilen Bilgiler
                                                                                    </div>
                                                                                </div>
                                                                                <div class="sale-info">
                                                                                    <div class="s-date">
                                                                                        <i
                                                                                                class="fa-regular fa-clock"></i>
                                                                                        2024-03-09 17:44:25
                                                                                    </div>
                                                                                    <div class="s-delivery">
                                                                                        Satıcı: <a class="p-seller"
                                                                                                   href="">Hyper</a>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="sale-alerts red">
                                                                                Satışınız iptal
                                                                                edilmiştir. Karakter Oyunda
                                                                                yada Teslimat
                                                                                Noktasında Değil.
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="tab-pane fade" id="support-request" role="tabpanel"
                                     aria-labelledby="support-request-tab" tabindex="0">
                                    <div class="container-fluid">
                                        <div class="k-panel-content-box">
                                            <div class="row">
                                                <div class="col-12">
                                                    <div class="dwr">
                                                        <a href="<?php echo base_url('destek-olustur-yeni') ?>"
                                                           class="btn btn-primary settings-btn"><i class="fas fa-plus"
                                                                                                   aria-hidden="true"></i>
                                                            Yeni Talep Oluştur</a>
                                                    </div>
                                                </div>
                                                <div class="col-12">
                                                    <div class="kpc-tt">
                                                        Destek Taleplerim
                                                    </div>
                                                    <div class="request-warper">
                                                        <?php if (!empty($taleplerim)) { ?>
                                                            <?php foreach ($taleplerim as $key => $val) { ?>
                                                                <div class="kpc-item">
                                                                    <div class="kpc-border">
                                                                        <div class="raffle-id">
                                                                            <span># <?php echo $val->talep_id ?></span>
                                                                        </div>
                                                                        <div class="product-name-panel">
                                                                            <h4 class="custom-text-area">
                                                                                <a href="<?= base_url('destek-detay/' . $val->talep_no) ?>"
                                                                                   class="custom-text"><?php echo $val->talep ?></a>
                                                                            </h4>
                                                                        </div>
                                                                        <ul class="list-inline font-size-xs mb-0">
                                                                            <li class="list-inline-item">
                                                                                <i class="far fa-clock mr-1"></i>
                                                                                <?php echo $val->talep_zaman ?>
                                                                            </li>
                                                                        </ul>
                                                                        <div class="align-middle border-top-0">
                                                                            <?php if ($val->talep_durum == 0) { ?>
                                                                                <span class="badge badge-warning">Cevap Bekleniyor..</span>
                                                                            <?php } elseif ($val->talep_durum == 1) { ?>
                                                                                <span class="badge badge-success">Cevaplandı</span>
                                                                            <?php } elseif ($val->talep_durum == 2) { ?>
                                                                                <span class="badge badge-secondary">Kapatıldı</span>
                                                                            <?php } ?>
                                                                        </div>
                                                                        <button type="button"
                                                                                onclick="window.location.href='<?= base_url('destek-detay-yeni/' . $val->talep_no) ?>'"
                                                                                class="badge btn badge-primary badge-pill">
                                                                            Talep Detay
                                                                        </button>
                                                                    </div>
                                                                </div>
                                                            <?php } ?>
                                                        <?php } else { ?>
                                                            <div class="alert alert-info mt-3" role="alert">
                                                                Destek Talepin Bulunmamaktadır. <a
                                                                        href="<?php echo base_url('destek-olustur-yeni') ?>"
                                                                        class="alert-link">Yeni Talep</a>
                                                                Ekliyebilirsin.
                                                            </div>
                                                        <?php } ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="tab-pane fade" id="account-settings" role="tabpanel"
                                     aria-labelledby="account-settings-tab" tabindex="0">
                                    <div class="container-fluid">
                                        <div class="k-panel-content-box">
                                            <div class="row">
                                                <div class="col-12">
                                                    <div class="kpc-tt">
                                                        Kullanıcı Bilgileri
                                                    </div>
                                                    <div class=" bg-none mb-4">
                                                        <div class="card-body">
                                                            <div class="row align-items-center">
                                                                <div class="col-lg-6 col-md-12">
                                                                    <div class="dashboard-list-box margin-top-0">
                                                                        <div class="dashboard-list-box-static">
                                                                            <form method="post"
                                                                                  action="<?= base_url("kullanicibilgi") ?>"
                                                                                  enctype="multipart/form-data">
                                                                                <!-- Avatar -->
                                                                                <div class="d-flex flex-wrap">
                                                                                    <div class="avatar-upload">
                                                                                            <span class="upload-setting-span">Profil
                                                                                                Fotoğrafı</span>
                                                                                        <div class="avatar-edit">
                                                                                            <input type='file'
                                                                                                   id="imageUpload"
                                                                                                   name="file"
                                                                                                   accept=".png, .jpg, .jpeg"/>
                                                                                            <label
                                                                                                    for="imageUpload"></label>
                                                                                        </div>
                                                                                        <div class="avatar-preview">

                                                                                            <?php if (strpos($kullanici->kullanici_resim, "/.jpg") !== false) { ?>
                                                                                                <div id="imagePreview"
                                                                                                     style="background-image: url(https://ui-avatars.com/api/?name=<?= $kullanici->kullanici_isim ?>+<?= $kullanici->kullanici_soyisim ?>&background=0D8ABC&color=fff">
                                                                                                </div>
                                                                                            <?php } else { ?>
                                                                                                <div id="imagePreview"
                                                                                                     style="background-image: url(<?= base_url($kullanici->kullanici_resim) ?>);">
                                                                                                </div>
                                                                                            <?php } ?>

                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="row">
                                                                                    <div
                                                                                            class="form-group col-12 col-md-12">
                                                                                        <label
                                                                                                class="form-label">Kullanıcı
                                                                                            Adı</label>
                                                                                        <input type="text"
                                                                                               class="form-control"
                                                                                               placeholder="Adınız"
                                                                                               value="<?= $kullanici->kullanici_ad ?>"
                                                                                               required="" readonly>
                                                                                    </div>
                                                                                    <div
                                                                                            class="form-group col-12 col-md-6">
                                                                                        <label
                                                                                                class="form-label">Adınız</label>
                                                                                        <input type="text" name="ad"
                                                                                               class="form-control"
                                                                                               placeholder="Adınız"
                                                                                               value="<?= $kullanici->kullanici_isim ?>"
                                                                                               required="">
                                                                                    </div>

                                                                                    <div
                                                                                            class="form-group col-12 col-md-6">
                                                                                        <label
                                                                                                class="form-label">Soyadınız</label>
                                                                                        <input type="text"
                                                                                               name="soyad"
                                                                                               class="form-control"
                                                                                               placeholder="Soyadınız"
                                                                                               value="<?= $kullanici->kullanici_soyisim ?>"
                                                                                               required="">
                                                                                    </div>

                                                                                    <div
                                                                                            class="form-group col-12 col-md-12">
                                                                                        <label
                                                                                                class="form-label">E-Posta
                                                                                            Adresi</label>
                                                                                        <input type="text"
                                                                                               class="form-control"
                                                                                               placeholder="E-Posta Adresi"
                                                                                               value="<?= $kullanici->kullanici_mail ?>"
                                                                                               disabled>
                                                                                    </div>
                                                                                    <div
                                                                                            class="form-group col-9 col-md-9">
                                                                                        <label
                                                                                                class="form-label">Telefon</label>
                                                                                        <input type="number"
                                                                                               id="accountPhone"
                                                                                               name="telefon"
                                                                                               class="form-control"
                                                                                               placeholder="05XXXXXXXXX"
                                                                                               value="<?= $kullanici->kullanici_tel ?>"
                                                                                               required="">
                                                                                    </div>
                                                                                    <script>
                                                                                        $(document).ready(
                                                                                            function () {
                                                                                                $('#accountPhone')
                                                                                                    .on('input',
                                                                                                        function () {
                                                                                                            var value =
                                                                                                                $(
                                                                                                                    this
                                                                                                                )
                                                                                                                    .val();
                                                                                                            value
                                                                                                                =
                                                                                                                value
                                                                                                                    .replace(
                                                                                                                        /\D/g,
                                                                                                                        ''
                                                                                                                    ); // Sadece sayıları al

                                                                                                            if (value
                                                                                                                    .charAt(
                                                                                                                        0
                                                                                                                    ) !==
                                                                                                                '0'
                                                                                                            ) {
                                                                                                                // Başında 0 yoksa otomatik ekle
                                                                                                                value
                                                                                                                    =
                                                                                                                    '0' +
                                                                                                                    value;
                                                                                                            }

                                                                                                            // 11 karakteri geçmemesi için kontrol
                                                                                                            if (value
                                                                                                                    .length >
                                                                                                                11
                                                                                                            ) {
                                                                                                                // 11 karakterden fazla ise son eklenen karakteri kaldır
                                                                                                                value
                                                                                                                    =
                                                                                                                    value
                                                                                                                        .slice(
                                                                                                                            0,
                                                                                                                            11
                                                                                                                        );
                                                                                                            }

                                                                                                            // Telefon numarasını formatla
                                                                                                            var formattedValue =
                                                                                                                value
                                                                                                                    .replace(
                                                                                                                        /(\d{4})(\d{3})(\d{4})/,
                                                                                                                        '$1 $2 $3'
                                                                                                                    );
                                                                                                            $(this)
                                                                                                                .val(
                                                                                                                    value
                                                                                                                );
                                                                                                        }
                                                                                                    );
                                                                                            });
                                                                                    </script>
                                                                                    <?php if ($kullanici->tel_dogrulama == 0) { ?>
                                                                                        <div
                                                                                                class="form-group col-3 col-md-3 mt-3">
                                                                                            <button type="button"
                                                                                                    class="btn btn-danger mt-3 tel-dogrula-button"
                                                                                                    data-toggle="modal"
                                                                                                    data-target="#teldogrula"
                                                                                                    data-id="<?php echo $kullanici->kullanici_id ?>">
                                                                                                Doğrula
                                                                                            </button>
                                                                                        </div>
                                                                                    <?php } else { ?>
                                                                                        <div
                                                                                                class="form-group col-3 col-md-3 mt-3">
                                                                                            <button type="button"
                                                                                                    class="btn btn-success mt-3">
                                                                                                Doğrulandı
                                                                                            </button>
                                                                                        </div>
                                                                                    <?php } ?>
                                                                                    <?php if (1 == 2) { ?>
                                                                                        <hr>
                                                                                        <h4>Fatura Bilgileri
                                                                                        </h4>
                                                                                        <div
                                                                                                class="form-group col-12 col-md-12">
                                                                                            <label
                                                                                                    class="form-label">Adres</label>
                                                                                            <textarea
                                                                                                    class="form-control"
                                                                                                    name="adres"
                                                                                                    id="adres"
                                                                                                    rows="5"
                                                                                                    placeholder="Adres"
                                                                                                    required><?= $kullanici->kullanici_adres ?></textarea>
                                                                                        </div>

                                                                                        <div
                                                                                                class="form-group col-12 col-md-6">
                                                                                            <label
                                                                                                    class="form-label">Şehir</label>
                                                                                            <select id="ilsec"
                                                                                                    name="sehir"
                                                                                                    class="form-control input-radius"
                                                                                                    data-width="100%"
                                                                                                    required>
                                                                                                <option value="">
                                                                                                    Lütfen
                                                                                                    Seçiniz...
                                                                                                </option>
                                                                                                <?php if ($iller) {
                                                                                                    foreach ($iller as $il) { ?>
                                                                                                        <option
                                                                                                            <?= $kullanici->kullanici_sehir === $il->id ? 'selected' : '' ?>
                                                                                                                value="<?= $il->id ?>">
                                                                                                            <?= $il->il_adi ?>
                                                                                                        </option>
                                                                                                    <?php }
                                                                                                } ?>
                                                                                            </select>
                                                                                        </div>
                                                                                        <!-- Country  -->
                                                                                        <div
                                                                                                class="form-group col-12 col-md-6">
                                                                                            <label
                                                                                                    class="form-label">İlçe</label>
                                                                                            <select id="ilsechesap"
                                                                                                    name="ilce"
                                                                                                    class="form-control input-radius"
                                                                                                    data-width="100%"
                                                                                                    required>
                                                                                                <option>Lütfen
                                                                                                    Şehir
                                                                                                    Seçiniz..
                                                                                                </option>
                                                                                            </select>
                                                                                        </div>
                                                                                    <?php } ?>
                                                                                </div>

                                                                                <button type="submit"
                                                                                        class="btn btn-primary rounded-pill mt-3">
                                                                                    Bilgileri Güncelle
                                                                                </button>
                                                                            </form>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-lg-6 col-md-12">
                                                                    <div class="dashboard-list-box c-stand">
                                                                        <h4 class="gray">Şifre Değiştir</h4>
                                                                        <div class="dashboard-list-box-static">
                                                                            <form method="post"
                                                                                  action="<?= base_url("sifre-degistir") ?>">
                                                                                <div class="row">
                                                                                    <div
                                                                                            class="form-group col-12 col-md-12">
                                                                                        <label
                                                                                                class="form-label">Eski
                                                                                            Şifre</label>
                                                                                        <input type="text"
                                                                                               name="eski"
                                                                                               class="form-control"
                                                                                               placeholder="Eski Şifre"
                                                                                               required="">
                                                                                    </div>
                                                                                    <div
                                                                                            class="form-group col-12 col-md-12">
                                                                                        <label
                                                                                                class="form-label">Yeni
                                                                                            Şifre</label>
                                                                                        <input type="text"
                                                                                               name="yeni"
                                                                                               class="form-control"
                                                                                               placeholder="Yeni Şifre"
                                                                                               required="">
                                                                                    </div>
                                                                                    <div
                                                                                            class="form-group col-12 col-md-12">
                                                                                        <label
                                                                                                class="form-label">Eski
                                                                                            Şifre</label>
                                                                                        <input type="text"
                                                                                               name="tekrar"
                                                                                               class="form-control"
                                                                                               placeholder="Yeni Şifre Tekrar"
                                                                                               required="">
                                                                                    </div>
                                                                                </div>

                                                                                <button type="submit"
                                                                                        class="btn btn-primary rounded-pill mt-3">
                                                                                    Şifre
                                                                                    Değiştir
                                                                                </button>
                                                                            </form>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="tab-pane fade d-none" id="message" role="tabpanel"
                                     aria-labelledby="message-tab" tabindex="0">
                                    <div class="container-fluid">
                                        <div class="k-panel-content-box">
                                            <div class="row">
                                                <div class="col-12">
                                                    <div class="kpc-tt">
                                                        Mesajlarım
                                                    </div>
                                                    <main class="main-content pt-xl-4 pt-3 pb-xl-4 pb-3">
                                                        <div class="container-fluid">
                                                            <div
                                                                    class="row align-items-center no-gutters justify-content-between">
                                                            </div>
                                                            <div class="row mt-4 mb-4">
                                                                <div class="col-xl-3 col-lg-3 col-12 mb-xl-0 mb-3">
                                                                    <div class="bg-color message-users"
                                                                         id="box_list">
                                                                        <div id="asagial"></div>
                                                                        <div class="">
                                                                            <a class="newmessage"
                                                                               data-toggle="modal"
                                                                               data-target="#sohbet"><i>+</i>
                                                                                YENİ SOHBET</a>
                                                                        </div>
                                                                        <div class="chat-search">
                                                                            <input type="text" name="s"
                                                                                   class="cat-search" onkeyup="var value = $(this).val().toLowerCase();
                                                                                            $(&quot;.isim&quot;).filter(function() {
                                                                                                $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
                                                                                            });"
                                                                                   placeholder="Aradığınız Kullanıcıyı Yazın...">
                                                                        </div>
                                                                        <div class="d-flex align-items-center">
                                                                        </div>
                                                                        <ul id="yenimesaj" class="chat-list-name">
                                                                            <?php if ($mesaj || $giden_mesaj) { ?>
                                                                                <?php foreach ($mesaj as $key => $val) { ?>
                                                                                    <?php $user = kullanici_bilgi($val->gonderen_id); ?>
                                                                                    <li class="messageus menu-left-area"
                                                                                        data-target="<?php echo $val->uniq ?>">
                                                                                        <div style="cursor:pointer;"
                                                                                             onclick="$(document).scrollTop($('div#asagial').offset().top);">
                                                                                            <a
                                                                                                    class="row no-gutters align-items-center isim">
                                                                                            <span class="col-3">
                                                                                                <span class="mu-image">
                                                                                                    <?php if (strpos($user->kullanici_resim, "/.jpg") !== false) { ?>
                                                                                                        <img src="https://ui-avatars.com/api/?name=<?= $user->kullanici_isim ?>+<?= $user->kullanici_soyisim ?>&background=0D8ABC&color=fff"
                                                                                                             alt="">
                                                                                                    <?php } else { ?>
                                                                                                        <img src="<?= base_url($user->kullanici_resim) ?>"
                                                                                                             alt="">
                                                                                                    <?php } ?>
                                                                                                </span>
                                                                                            </span>
                                                                                                <span class="col-9">
                                                                                                <span
                                                                                                        class="row justify-content-between"></span>
                                                                                                <span class="col-auto">
                                                                                                    <span
                                                                                                            class="mu-name"><?= $user->kullanici_ad ?>
                                                                                                    </span>
                                                                                                    <br><span
                                                                                                            class="col-auto">
                                                                                                        <span id=""
                                                                                                              class="mu-date">
                                                                                                            <?php echo $val->tarih ?>
                                                                                                        </span>
                                                                                                    </span>
                                                                                                </span>
                                                                                            </span>
                                                                                            </a>
                                                                                        </div>
                                                                                    </li>
                                                                                <?php } ?>
                                                                                <?php foreach ($giden_mesaj as $key => $val) { ?>
                                                                                    <?php $user = kullanici_bilgi($val->alan_id); ?>
                                                                                    <li class="messageus menu-left-area"
                                                                                        data-target="<?php echo $val->uniq ?>">
                                                                                        <div style="cursor:pointer;"
                                                                                             onclick="$(document).scrollTop($('div#asagial').offset().top);">
                                                                                            <a
                                                                                                    class="row no-gutters align-items-center isim">
                                                                                            <span class="col-3">
                                                                                                <span class="mu-image">
                                                                                                    <?php if (strpos($user->kullanici_resim, "/.jpg") !== false) { ?>
                                                                                                        <img src="https://ui-avatars.com/api/?name=<?= $user->kullanici_isim ?>+<?= $user->kullanici_soyisim ?>&background=0D8ABC&color=fff"
                                                                                                             alt="">
                                                                                                    <?php } else { ?>
                                                                                                        <img src="<?= base_url($user->kullanici_resim) ?>"
                                                                                                             alt="">
                                                                                                    <?php } ?>
                                                                                                </span>
                                                                                            </span>
                                                                                                <span class="col-9">
                                                                                                <span
                                                                                                        class="row justify-content-between"></span>
                                                                                                <span class="col-auto">
                                                                                                    <span
                                                                                                            class="mu-name"><?= $user->kullanici_ad ?>
                                                                                                    </span>
                                                                                                    <br><span
                                                                                                            class="col-auto">
                                                                                                        <span id=""
                                                                                                              class="mu-date">
                                                                                                            <?php echo $val->tarih ?>
                                                                                                        </span>
                                                                                                    </span>
                                                                                                </span>
                                                                                            </span>
                                                                                            </a>
                                                                                        </div>
                                                                                    </li>
                                                                                <?php } ?>
                                                                            <?php } else { ?>
                                                                                <li class="messageus" data-target="0">
                                                                                    <div style="cursor:pointer;"
                                                                                         onclick="$(document).scrollTop($('div#asagial').offset().top);">
                                                                                        <a
                                                                                                class="row no-gutters align-items-center isim">
                                                                                            <span class="col-12"
                                                                                                  style="text-align: center;margin-top:15px">
                                                                                                <span
                                                                                                        class="row justify-content-between"></span>
                                                                                                <span class="col-auto">
                                                                                                    <span
                                                                                                            class="mu-name">Mesaj
                                                                                                        Bulunmamaktadır.
                                                                                                    </span>
                                                                                                    <br><span
                                                                                                            class="col-auto">
                                                                                                    </span>
                                                                                                </span>
                                                                                            </span>
                                                                                        </a>
                                                                                    </div>
                                                                                </li>
                                                                            <?php } ?>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                                <div class="col-xl-9 col-lg-9 col-12" id="n">
                                                                    <div
                                                                            class="bg-color mu-message-area pl-3 pb-3 pr-3">
                                                                        <div class="empty-chat">
                                                                            <div class="mma-top border-bottom">
                                                                                <div
                                                                                        class="row mma-row justify-content-between align-items-center">
                                                                                </div>
                                                                            </div>
                                                                            <div class="mma-content"
                                                                                 id="mma-content">
                                                                                <div id="mma-red"
                                                                                     style="text-align: center;padding: 15px; display: block;">
                                                                                    <img height="300"
                                                                                         src="<?php echo base_url('assets/images/chats-1.png') ?>">
                                                                                </div>
                                                                                <div id="mma-red-text"
                                                                                     class="mma-chat-text"
                                                                                     style="text-align: center;">
                                                                                    <h4>Anlık sohbet
                                                                                        sistemine hoşgeldin
                                                                                    </h4>
                                                                                    <span>Buradan anlık
                                                                                            olarak sitemiz
                                                                                            üzerindeki
                                                                                            kullanıcılar ile
                                                                                            mesajlaşabilir ve
                                                                                            Yeni sohbet oluştur
                                                                                            butonuna tıklayarak
                                                                                            yeni bir sohbet
                                                                                            başlatabilirsin.</span>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <?php if ($mesaj || $giden_mesaj) { ?>
                                                                            <?php foreach ($mesaj as $key => $val) { ?>
                                                                                <?php $user = kullanici_bilgi($val->alan_id); ?>
                                                                                <div class="chat-area"
                                                                                     id="select-chat-<?php echo $val->uniq ?>">
                                                                                    <div
                                                                                            class="row mma-row justify-content-between align-items-center">
                                                                                        <div style="display: block;"
                                                                                             id="mma-ustbar"
                                                                                             class="col-xl-auto col-12">
                                                                                            <div
                                                                                                    class="row align-items-center">
                                                                                                <div class="col-auto">
                                                                                                    <div class="mma-image">
                                                                                                        <a id="profilegit"
                                                                                                           alt=""
                                                                                                           href="javascript:void(0)">
                                                                                                            <?php if (strpos($user->kullanici_resim, "/.jpg") !== false) { ?>
                                                                                                                <img src="https://ui-avatars.com/api/?name=<?= $user->kullanici_isim ?>+<?= $user->kullanici_soyisim ?>&background=0D8ABC&color=fff"
                                                                                                                     alt=""
                                                                                                                     id="pp">
                                                                                                            <?php } else { ?>
                                                                                                                <img id="pp"
                                                                                                                     alt=""
                                                                                                                     src="<?= base_url($user->kullanici_resim) ?>">
                                                                                                            <?php } ?>
                                                                                                        </a>
                                                                                                    </div>
                                                                                                </div>
                                                                                                <div class="col-auto">
                                                                                                    <div class="mma-name"
                                                                                                         id="mma-name">
                                                                                                        <?php echo $user->kullanici_ad ?>
                                                                                                    </div>
                                                                                                </div>
                                                                                                <marquee
                                                                                                        class="duyurutext">
                                                                                                    <?php echo $ayarlar->mesaj_detay_kayan_yazi ?>
                                                                                                </marquee>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="chat-bar">

                                                                                    </div>

                                                                                    <div class="mm-chat-sender">
                                                                                        <div
                                                                                                class="row no-gutters chat-container">
                                                                                            <div class="col-xl-11 col-10">
                                                                                                <input
                                                                                                        style="display: block;"
                                                                                                        id="sendmessage"
                                                                                                        type="text"
                                                                                                        class="chat-input"
                                                                                                        name="remessage"
                                                                                                        placeholder="Bir şeyler yazın...">
                                                                                            </div>
                                                                                            <div class="col-xl-1 col-2">
                                                                                                <button
                                                                                                        style="display: block;"
                                                                                                        id="sendmessagebutton"
                                                                                                        data-target="<?php echo $val->uniq ?>"
                                                                                                        class="chat-button sendReMessage"></button>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            <?php } ?>
                                                                            <?php foreach ($giden_mesaj as $key => $val) { ?>
                                                                                <?php $user = kullanici_bilgi($val->alan_id); ?>
                                                                                <div class="chat-area"
                                                                                     id="select-chat-<?php echo $val->uniq ?>">
                                                                                    <div
                                                                                            class="row mma-row justify-content-between align-items-center">
                                                                                        <div style="display: block;"
                                                                                             id="mma-ustbar"
                                                                                             class="col-xl-auto col-12">
                                                                                            <div
                                                                                                    class="row align-items-center">
                                                                                                <div class="col-auto">
                                                                                                    <div class="mma-image">
                                                                                                        <a id="profilegit"
                                                                                                           alt=""
                                                                                                           href="javascript:void(0)">
                                                                                                            <?php if (strpos($user->kullanici_resim, "/.jpg") !== false) { ?>
                                                                                                                <img src="https://ui-avatars.com/api/?name=<?= $user->kullanici_isim ?>+<?= $user->kullanici_soyisim ?>&background=0D8ABC&color=fff"
                                                                                                                     alt=""
                                                                                                                     id="pp">
                                                                                                            <?php } else { ?>
                                                                                                                <img id="pp"
                                                                                                                     alt=""
                                                                                                                     src="<?= base_url($user->kullanici_resim) ?>">
                                                                                                            <?php } ?>
                                                                                                        </a>
                                                                                                    </div>
                                                                                                </div>
                                                                                                <div class="col-auto">
                                                                                                    <div class="mma-name"
                                                                                                         id="mma-name">
                                                                                                        <?php echo $user->kullanici_ad ?>
                                                                                                    </div>
                                                                                                </div>
                                                                                                <marquee
                                                                                                        class="duyurutext">
                                                                                                    <?php echo $ayarlar->mesaj_detay_kayan_yazi ?>
                                                                                                </marquee>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="chat-bar">

                                                                                    </div>
                                                                                    <div class="mm-chat-sender">
                                                                                        <div
                                                                                                class="row no-gutters chat-container">
                                                                                            <div class="col-xl-11 col-10">
                                                                                                <input
                                                                                                        style="display: block;"
                                                                                                        id="sendmessage"
                                                                                                        type="text"
                                                                                                        class="chat-input"
                                                                                                        name="remessage"
                                                                                                        placeholder="Bir şeyler yazın...">
                                                                                            </div>
                                                                                            <div class="col-xl-1 col-2">
                                                                                                <button
                                                                                                        style="display: block;"
                                                                                                        id="sendmessagebutton"
                                                                                                        data-target="<?php echo $val->uniq ?>"
                                                                                                        class="chat-button sendReMessage"></button>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            <?php } ?>
                                                                        <?php } ?>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </main>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>


                                <div class="tab-pane fade" id="atq" role="tabpanel" aria-labelledby="atq-tab"
                                     tabindex="0">
                                    <div class="container-fluid">
                                        <div class="k-panel-content-box">
                                            <div class="row">
                                                <div class="col-12">
                                                    <div class="kpc-tt">
                                                        Sorularım
                                                    </div>
                                                    <?php if (!empty($sorular)) { ?>
                                                        <?php foreach ($sorular as $key => $val) { ?>
                                                            <div class="kpc-item">
                                                                <div class="kpc-border">
                                                                    <a target="_blank"
                                                                       href="<?php echo base_url($val->urun_seo) ?>">
                                                                        <img src="<?php echo base_url($val->urun_resim_min) ?>"
                                                                             alt="<?php echo $val->urun_ad ?>"
                                                                             class="rounded img-4by3-lg product-table-img"></a>

                                                                    <div class="product-name-panel">
                                                                        <h4 class="custom-text-area">
                                                                            <a target="_blank" href=""
                                                                               class="custom-text"><?php echo $val->urun_ad ?></a>
                                                                        </h4>
                                                                    </div>
                                                                    <ul class="list-inline font-size-xs mb-0">
                                                                        <li class="list-inline-item">
                                                                            <i class="far fa-clock mr-1"></i>
                                                                            <?php echo $val->tarih ?>
                                                                        </li>
                                                                    </ul>
                                                                    <div class="align-middle border-top-0">
                                                                        <?php if (empty($val->soru_cevap)) { ?>
                                                                            <span class="badge badge-warning">Cevap Bekliyor..</span>
                                                                        <?php } else { ?>
                                                                            <span class="badge badge-success">Cevap Verildi</span>
                                                                        <?php } ?>
                                                                    </div>
                                                                    <div class="atq-modal-btn">
                                                                        <button type="button" class="btn btn-primary"
                                                                                data-toggle="modal"
                                                                                data-target="#sorucevap-<?php echo $val->soru_id ?>">
                                                                            <i class="far fa-eye"></i></button>
                                                                        <button type="button"
                                                                                onclick="window.location.href='<?php echo base_url($val->urun_seo) ?>'"
                                                                                class="btn btn-info"><i
                                                                                    class="fas fa-external-link-alt"></i>
                                                                        </button>
                                                                    </div>
                                                                </div>
                                                                <div class="atq-dsc">
                                                                    <p><?php echo $val->soru ?></p>
                                                                </div>
                                                            </div>
                                                            <div class="modal fade"
                                                                 id="sorucevap-<?php echo $val->soru_id ?>"
                                                                 tabindex="-1" role="dialog"
                                                                 aria-labelledby="exampleModalCenterTitle"
                                                                 aria-hidden="true">
                                                                <div class="modal-dialog modal-dialog-centered"
                                                                     role="document">
                                                                    <div class="modal-content sms">
                                                                        <div class="modal-header">
                                                                            <h4 class="modal-title text-center"
                                                                                id="exampleModalCenterTitle"><?php echo $val->urun_ad ?>
                                                                                İlanınızın Sorusu</h4>
                                                                            <button type="button" class="close"
                                                                                    data-dismiss="modal"
                                                                                    aria-label="Close">
                                                                                <span aria-hidden="true">&times;</span>
                                                                            </button>
                                                                        </div>
                                                                        <div class="alert alert-info alert-dismissible text-left alert-grid"
                                                                             role="alert">
                                                                            <i class="fas fa-question"></i>
                                                                            <div>
                                                                                <strong>Soru:</strong><br><?php echo $val->soru ?>
                                                                            </div>
                                                                        </div>
                                                                        <?php if (!empty($val->soru_cevap)) { ?>
                                                                            <div class="alert alert-info alert-dismissible text-left alert-grid"
                                                                                 role="alert">
                                                                                <div>
                                                                                    <strong>Cevap:</strong><br><?php echo $val->soru_cevap->soru ?>
                                                                                </div>
                                                                            </div>
                                                                        <?php } ?>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        <?php } ?>
                                                    <?php } else { ?>
                                                        <div class="alert alert-info mt-2 text-center" role="alert">
                                                            Sorunuz Bulunmamaktadır!!
                                                        </div>
                                                    <?php } ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<div class="modal fade" id="sohbet" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
     aria-hidden="true">
    <form action="" method="post" id="infoSohbet">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="form-group">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                        <label for="recipient-name" class="col-form-label">Sohbet'i başlatmak istediğiniz üyenin
                            kullanıcı adını
                            yazın</label>
                        <input name="username" type="text" class="form-control" id="recipient-name"
                               placeholder="Üyenin Kullanıcı Adı">
                        <label for="message-text" class="col-form-label">Mesajınız:</label>
                        <textarea rows="4" cols="50" class="form-control" name="gidicekmesaj" id="mesaj"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-info btn-lg btn-block">Sohbeti Başlat</button>
                </div>
            </div>
        </div>
    </form>
</div>
<script>
    $('.chat-list-name li').click(function () {
        var select_chat = $(this).attr('data-target');
        if ($('.chat-area').hasClass('open')) {
            $('.chat-area').removeClass('open')
            $('#select-chat-' + select_chat).addClass('open')
        } else {
            $('#select-chat-' + select_chat).addClass('open')
        }
    })

    $('#sendmessage').keypress(function (e) {
        if (e.which === 13) {
            $('.sendReMessage').click()
        }
    })

    $(document).on("submit", "#infoSohbet", function (event) {
        <?php if (aktif_kullanici()) : ?>
        $.ajax({
            type: "POST",
            url: base_url + "ajax_controller/sohbet_add_mesaj",
            data: {
                mesaj: $('textarea[name="gidicekmesaj"]').val(),
                username: $('input[name="username"]').val(),
                kullanici_id: <?= $kullanici->kullanici_id ?>
            },
            success: function (data) {
                var d = JSON.parse(data);
                if (d.status.status == 'error') {
                    Swal.fire(
                        'Hata!',
                        d.status.message,
                        d.status.status,
                    );
                } else if (d.status.status == 'success') {
                    Swal.fire(
                        'Başarılı!',
                        d.status.message,
                        d.status.status,
                    ).then((result) => {
                        location.reload();
                    })
                }

            }
        });
        event.preventDefault();
        <?php else : ?>
        Swal.fire({
            title: 'Giriş Yap',
            text: "Mesajlaşmak için giriş yapmalısınız.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Giriş Yap',
            cancelButtonText: 'Hayır, İptal Et',
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = "<?= base_url('giris-yap') ?>";
            }
        })
        <?php endif; ?>
    });

    $(document).on("click", ".menu-left-area", function (event) {
        <?php if (aktif_kullanici()) : ?>
        var uniq = $(this).data('target');
        $.ajax({
            type: "POST",
            url: base_url + "ajax_controller/sohbet_getir",
            data: {
                uniq: uniq,
                kullanici_id: <?= $kullanici->kullanici_id ?>
            },
            success: function (data) {
                var d = JSON.parse(data);
                if (d.status == 'error') {
                    Swal.fire(
                        'Hata!',
                        d.message,
                        d.status,
                    );
                } else if (d.status == 'success') {
                    var targetDiv = $('#select-chat-' + uniq).find('.chat-bar');
                    targetDiv.html(d.html); // İçerik kısmını kendi isteğinize göre güncelleyin
                    $('.chat-bar').scrollTop($('.chat-bar')[0].scrollHeight)
                }

            }
        });
        event.preventDefault();
        <?php else : ?>
        Swal.fire({
            title: 'Giriş Yap',
            text: "Mesajlaşmak için giriş yapmalısınız.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Giriş Yap',
            cancelButtonText: 'Hayır, İptal Et',
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = "<?= base_url('giris-yap') ?>";
            }
        })
        <?php endif; ?>
    });

    $(document).on("click", ".sendReMessage", function (event) {
        <?php if (aktif_kullanici()) : ?>
        var inputValue = $(this).closest('.chat-container').find('input[name="remessage"]').val();
        var uniq = $(this).data('target');
        $.ajax({
            type: "POST",
            url: base_url + "ajax_controller/send_re_message",
            data: {
                uniq: uniq,
                kullanici_id: <?= $kullanici->kullanici_id ?>,
                message: inputValue
            },
            success: function (data) {
                var d = JSON.parse(data);
                if (d.status == 'error') {
                    Swal.fire(
                        'Hata!',
                        d.message,
                        d.status,
                    );
                } else if (d.status == 'success') {
                    var targetDiv = $('#select-chat-' + uniq).find('.chat-bar');
                    targetDiv.append(d.html); // İçerik kısmını kendi isteğinize göre güncelleyin
                    $('#sendmessage').val(' ');
                    $('.chat-bar').scrollTop($('.chat-bar')[0].scrollHeight)
                }

            }
        });
        event.preventDefault();
        <?php else : ?>
        Swal.fire({
            title: 'Giriş Yap',
            text: "Mesajlaşmak için giriş yapmalısınız.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Giriş Yap',
            cancelButtonText: 'Hayır, İptal Et',
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = "<?= base_url('giris-yap') ?>";
            }
        })
        <?php endif; ?>
    });


</script>


<div class="modal fade" id="teldogrula_step_1" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
     aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content sms">
            <div class="modal-header">
                <h4 class="modal-title text-center" id="exampleModalCenterTitle">Telefon Doğrulama</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="tel-dogrula-alert">
                <div class="alert alert-danger alert-dismissible text-left alert-grid" role="alert">
                    <i class="fas fa-check"></i>
                    <div><strong>Doğrulama Gerekiyor</strong><br>
                        Ödeme bildirimi oluşturabilmek için telefon numaranızı doğrulamanız gerekmektedir.
                    </div>
                </div>
            </div>
            <div class="p-2">
                <div class="row">
                    <div class="col-12">
                        <label class="form-label">Telefon No</label>
                        <input type="text" class="form-control" name="telefon" id="telefon" value="0" maxlength="11">
                    </div>
                </div>
                <div class="py-2">
                    <button type="button" class="btn btn-primary rounded-pill tel-dogrula-button w-100"
                            data-id="<?php echo $kullanici->kullanici_id ?>">SMS Gönder
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="teldogrula" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
     aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content sms">
            <div class="modal-header">
                <h4 class="modal-title text-center" id="exampleModalCenterTitle">Telefon Doğrulama</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="tel-dogrula-alert">
                <div class="alert alert-success alert-dismissible text-left alert-grid" role="alert">
                    <i class="fas fa-check"></i>
                    <div><strong>Başarılı</strong><br>
                        Doğrulama Kodunuz Başarılı Şekilde Gönderilmiştir. Lütfen Aşağıda ki alana kodu giriniz.
                    </div>
                </div>
            </div>
            <style>
                #countdown {
                    display: none;
                    font-size: 15px;
                    margin-left: 5px;
                    margin-top: 7px;
                }

                .countdown-area {
                    display: flex;
                    margin-top: 5px;
                    margin-bottom: 10px;
                }
            </style>
            <form class="p-2 tel-dogrulama-form" method="post">
                <div class="row">
                    <div class="col-12">
                        <label class="form-label">Doğrulama Kodu</label>
                        <input type="text" class="form-control" name="tel_dogrulama">
                    </div>
                </div>
                <div class="py-2">
                    <div class="countdown-area">
                        <button id="sendSMS" type="button" data-id="<?php echo $kullanici->kullanici_id ?>"
                                class="btn btn-warning rounded-pill">SMS Gönder
                        </button>
                        <div id="countdown"></div>
                    </div>
                    <button type="submit" class="btn btn-primary rounded-pill soru-sor-btn w-100">Doğrula</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    var countdownTimer;
    var countdownDuration = 60; // 60 saniye

    function startCountdown() {
        $("#sendSMS").prop("disabled", true);
        $("#countdown").show();

        countdownTimer = setInterval(function () {
            $("#countdown").text("Kalan süre: " + countdownDuration + " saniye");

            if (countdownDuration === 0) {
                clearInterval(countdownTimer);
                $("#sendSMS").prop("disabled", false);
                $("#countdown").hide();
            } else {
                countdownDuration--;
            }
        }, 1000);
    }

    function resetCountdown() {
        clearInterval(countdownTimer);
        countdownDuration = 60;
        $("#sendSMS").prop("disabled", true);
        startCountdown();
    }

    // Sayfa yüklendiğinde otomatik geri sayım başlat
    //startCountdown();

    $("#sendSMS").click(function () {
        // Eğer geri sayım başlamamışsa başlat
        if (countdownDuration === 60) {
            startCountdown();
            var user = $(this).data('id');
            $.ajax({
                type: "POST",
                url: base_url + "ajax_controller/tel_dogrulama_resend",
                data: {
                    kullanici: user,
                    telefon: $("#telefon").val()
                },
                success: function (data) {
                    var d = JSON.parse(data);
                    if (d.status.status == 'success') {
                        startCountdown();
                        $(".tel-dogrula-alert").html(d.status.alert_html);
                    } else {
                        $(".tel-dogrula-alert").html(d.status.alert_html);
                    }
                }
            });
        } else {
            // Eğer geri sayım başlamışsa sıfırla ve tekrar başlat
            resetCountdown();
            var user = $(this).data('id');
            $.ajax({
                type: "POST",
                url: base_url + "ajax_controller/tel_dogrulama_resend",
                data: {
                    kullanici: user,
                    telefon: $("#telefon").val()
                },
                success: function (data) {
                    var d = JSON.parse(data);
                    if (d.status.status == 'success') {
                        startCountdown();
                        $(".tel-dogrula-alert").html(d.status.alert_html);
                    } else {
                        $(".tel-dogrula-alert").html(d.status.alert_html);
                    }
                }
            });
        }

        // Burada SMS gönderme işlemlerini gerçekleştirebilirsiniz.
    });


    $('.tel-dogrula-button').on('click', function () {
        var user = $(this).data('id');
        $.ajax({
            type: "POST",
            url: base_url + "ajax_controller/tel_dogrulama",
            data: {
                kullanici: user,
                telefon: $("#telefon").val()
            },
            success: function (data) {
                var d = JSON.parse(data);
                $("#teldogrula_step_1").modal("hide");
                $("#teldogrula").modal("show");
                if (d.status.status == 'success') {
                    startCountdown();
                    $(".tel-dogrula-alert").html(d.status.alert_html);
                } else {
                    $(".tel-dogrula-alert").html(d.status.alert_html);
                }
            }
        });

    });

    $('.tel-dogrulama-form').on('submit', function () {
        var kod = $('input[name="tel_dogrulama"]').val();
        $.ajax({
            type: "POST",
            url: base_url + "ajax_controller/tel_kod_dogrulama",
            data: {
                code: kod,
            },
            success: function (data) {
                var d = JSON.parse(data);
                if (d.status.status == 'success') {
                    Swal.fire(
                        'Başarılı!',
                        d.status.message,
                        d.status.status,
                    );
                    setTimeout(
                        function () {
                            window.location.reload();
                        }, 2000);
                } else {
                    Swal.fire(
                        'Hata!',
                        d.status.message,
                        d.status.status,
                    );
                }
            }
        });

    });
</script>
<script>
    function getFormData($form) {
        var unindexed_array = $form.serializeArray();
        var indexed_array = {};

        $.map(unindexed_array, function (n, i) {
            indexed_array[n['name']] = n['value'];
        });

        return indexed_array;
    }

    function paymentInfoPanel() {
        Swal.fire({
            html: $(".payment-info-modal .grid").html(),
            showCancelButton: false,
            showConfirmButton: false,
            showCloseButton: true,
            allowOutsideClick: false,
            allowEscapeKey: true,
            focusConfirm: false,
            customClass: {
                container: "login-special-container"
            }
        });
        $(".swal2-html-container #odemeBildirimForm #havale_tutar").on('input', function () {
            var tutar = parseFloat($(this).val());
            var komisyon = parseFloat(<?= $ayarlar->havale_komisyon ?>);
            var odenecek = (tutar / (100 + komisyon)) * 100;
            $(".swal2-html-container #odemeBildirimForm #havale_odenecek_tutar").html(odenecek.toFixed(2));
        });
        moment.updateLocale('tr', {
            meridiem: function (hour, minute, isLowercase) {
                if (hour < 12) {
                    return 'ÖÖ';
                } else {
                    return 'ÖS';
                }
            }
        });

        moment.updateLocale('tr', {
            meridiem: function (hour, minute, isLowercase) {
                if (hour < 12) {
                    return 'öö';
                } else {
                    return 'ös';
                }
            }
        });

        $('.swal2-html-container #odemeBildirimForm #odeme_bildirim_date').daterangepicker({
            "singleDatePicker": true,
            "timePicker": true,
            "startDate": "<?= date('d.m.Y H:i:s') ?>",
            "minDate": "<?= date('d.m.Y H:i:s', strtotime("-31 days")) ?>",
            "maxDate": "<?= date('d.m.Y H:i:s') ?>",
            "locale": {
                "format": "DD.MM.YYYY HH:mm:ss",
                "separator": " - ",
                "applyLabel": "Uygula",
                "cancelLabel": "Vazgeç",
                "fromLabel": "Dan",
                "toLabel": "a",
                "customRangeLabel": "Seç",
                "daysOfWeek": [
                    "Pt",
                    "Sl",
                    "Çr",
                    "Pr",
                    "Cm",
                    "Ct",
                    "Pz"
                ],
                "monthNames": [
                    "Ocak",
                    "Şubat",
                    "Mart",
                    "Nisan",
                    "Mayıs",
                    "Haziran",
                    "Temmuz",
                    "Ağustos",
                    "Eylül",
                    "Ekim",
                    "Kasım",
                    "Aralık"
                ],
                "firstDay": 1
            },
        }, function (start, end, label) {

        });
        $(".swal2-html-container #odemeBildirimForm").submit((e) => {
            e.preventDefault();
            var form = $(".swal2-html-container #odemeBildirimForm");
            $.ajax({
                type: "POST",
                url: "<?= base_url("odemebildirimiolustur") ?>",
                data: getFormData(form),
                success: function (res) {
                    res = JSON.parse(res);
                    if (res.status) {
                        Swal.fire({
                            icon: 'success',
                            title: 'Ödeme Bildirimi Alındı',
                            text: 'Ödeme bildiriminiz tarafımıza ulaştı. En kısa süre içerisinde bakiyeniz hesabınıza yüklenecektir.',
                        })
                    } else {
                        if (res.tel_verify) {
                            Swal.close();
                            $("#teldogrula_step_1").modal("show");
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Ödeme Bildirimi Oluşturulamadı.',
                                text: res.message ? res.message : 'Girmiş olduğunuz bilgileri tekrar kontrol ediniz. Sorun hala devam ediyorsa yönetici ile iletişime geçiniz.',
                            })
                        }
                    }
                }
            })
        })
    }

    $(".bank-img-area").on('click', function () {
        var id = $(this).data('id');
        $.ajax({
            type: "POST",
            url: "<?= base_url("Home_controller/banka_getir") ?>",
            data: {
                banka: id
            },
            success: function (res) {
                res = JSON.parse(res);
                if (res.status) {
                    $('.modal-bank-img').attr('src', 'https://kemalellidort.com.tr/' + res.banka.image);
                    $('.modal-transfer-bank-name').html(res.banka.name);
                    $('.modal-iban-area').html(res.banka.iban);
                    $('.modal-bank-desc').html(res.banka.description);
                    $('.modal-bank-select').html('<option value="' + res.banka.id + '">' + res.banka.name + '</option>');
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Hata',
                        text: 'Yapmaya Çalıştığınız İşlem Geçerli Değil',
                    })
                }
            }
        })
    });


    $(document).ready(function () {
        $("#bakiyeKuponuForm").submit((e) => {
            e.preventDefault();
            var form = $("#bakiyeKuponuForm");
            $.ajax({
                type: "POST",
                url: "<?= base_url("kuponkullan") ?>",
                data: getFormData(form),
                success: function (res) {
                    res = JSON.parse(res);
                    if (res.status) {
                        Swal.fire({
                            icon: 'success',
                            title: 'Kupon Kullanıldı',
                            text: res.message ? res.message : 'Kupon bakiyesi hesabınıza aktarıldı.',
                        })
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Kupon Kullanılamadı.',
                            text: res.message ? res.message : 'Yönetici ile iletişime geçiniz.',
                        })
                    }
                }
            })
        })
        $("#tutar").on('input', function () {
            var tutar = parseFloat($(this).val());
            var komisyon = parseFloat($("#komisyon_oran").val());
            var odenecek = tutar + (tutar * komisyon / 100);
            $("#odenecek_tutar").html(odenecek);
        });
        $("#iyzico_tutar").on('input', function () {
            var tutar = parseFloat($(this).val());
            var komisyon = parseFloat($("#iyzico_komisyon_oran").val());
            var odenecek = tutar + (tutar * komisyon / 100);
            $("#iyzico_odenecek_tutar").html(odenecek);
        });
        $("#weepay_tutar").on('input', function () {
            var tutar = parseFloat($(this).val());
            var komisyon = parseFloat($("#weepay_komisyon_oran").val());
            var odenecek = tutar + (tutar * komisyon / 100);
            $("#weepay_odenecek_tutar").html(odenecek);
        });
        $("#vallet_tutar").on('input', function () {
            var tutar = parseFloat($(this).val());
            var komisyon = parseFloat($("#vallet_komisyon_oran").val());
            var odenecek = tutar + (tutar * komisyon / 100);
            $("#vallet_odenecek_tutar").html(odenecek);
        });
        $("#stripe_tutar").on('input', function () {
            var tutar = parseFloat($(this).val());
            var komisyon = parseFloat($("#stripe_komisyon_oran").val());
            var odenecek = tutar + komisyon;
            $("#stripe_odenecek_tutar").html(odenecek);
        });
    })
</script>

<div class="modal fade" id="teldogrula" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
     aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content sms">
            <div class="modal-header">
                <h4 class="modal-title text-center" id="exampleModalCenterTitle">Satıcıya Soru Sor</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="tel-dogrula-alert">
                <div class="alert alert-success alert-dismissible text-left alert-grid" role="alert">
                    <i class="fas fa-check"></i>
                    <div><strong>Başarılı</strong><br>
                        Doğrulama Kodunuz Başarılı Şekilde Gönderilmiştir. Lütfen Aşağıda ki alana kodu giriniz.
                    </div>
                </div>
            </div>
            <style>
                #countdown {
                    display: none;
                    font-size: 15px;
                    margin-left: 5px;
                    margin-top: 7px;
                }

                .countdown-area {
                    display: flex;
                    margin-top: 5px;
                    margin-bottom: 10px;
                }
            </style>
            <form class="p-2 tel-dogrulama-form" method="post">
                <div class="row">
                    <div class="col-12">
                        <label class="form-label">Doğrulama Kodu</label>
                        <input type="text" class="form-control" name="tel_dogrulama">
                    </div>
                </div>
                <div class="py-2">
                    <div class="countdown-area">
                        <button id="sendSMS" type="button" data-id="<?php echo $kullanici->kullanici_id ?>"
                                class="btn btn-warning rounded-pill">SMS Gönder
                        </button>
                        <div id="countdown"></div>
                    </div>
                    <button type="submit" class="btn btn-primary rounded-pill soru-sor-btn w-100">Doğrula</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="<?= base_url('assets/front/') ?>libs/jquery/dist/jquery.min.js"></script>
<script>
    var il_id = "<?= $kullanici->kullanici_sehir ?>";
    var ilce_id = "<?= $kullanici->kullanici_ilce ?>";
    var base_url = "<?= base_url() ?>";
    if (il_id !== "") {
        var il_id = $("#ilsec option:selected").val();
        $.ajax({
            type: "POST",
            url: base_url + "ajax_controller/il_ajax_hesap",
            data: {
                il_id: il_id,
                ilce_id: ilce_id
            },
            success: function (data) {
                $("#ilsechesap").html(data);
            }
        });
    }

    $('#ilsec').on('change', function () {
        var il_ids = $("#ilsec option:selected").val();

        $.ajax({
            type: "POST",
            url: base_url + "ajax_controller/il_ajax",
            data: {
                il_id: il_ids,
            },
            success: function (data) {
                $("#ilsechesap").html(data);
            }
        });

    });
</script>
<?php if ($kullanici->tel_dogrula == 0) { ?>
    <script>
        var countdownTimer;
        var countdownDuration = 60; // 60 saniye

        function startCountdown() {
            $("#sendSMS").prop("disabled", true);
            $("#countdown").show();

            countdownTimer = setInterval(function () {
                $("#countdown").text("Kalan süre: " + countdownDuration + " saniye");

                if (countdownDuration === 0) {
                    clearInterval(countdownTimer);
                    $("#sendSMS").prop("disabled", false);
                    $("#countdown").hide();
                } else {
                    countdownDuration--;
                }
            }, 1000);
        }

        function resetCountdown() {
            clearInterval(countdownTimer);
            countdownDuration = 60;
            $("#sendSMS").prop("disabled", true);
            startCountdown();
        }

        // Sayfa yüklendiğinde otomatik geri sayım başlat
        //startCountdown();

        $("#sendSMS").click(function () {
            // Eğer geri sayım başlamamışsa başlat
            if (countdownDuration === 60) {
                startCountdown();
                var user = $(this).data('id');
                $.ajax({
                    type: "POST",
                    url: base_url + "ajax_controller/tel_dogrulama_resend",
                    data: {
                        kullanici: user,
                        telefon: $("#accountPhone").val()
                    },
                    success: function (data) {
                        var d = JSON.parse(data);
                        if (d.status.status == 'success') {
                            startCountdown();
                            $(".tel-dogrula-alert").html(d.status.alert_html);
                        } else {
                            $(".tel-dogrula-alert").html(d.status.alert_html);
                        }
                    }
                });
            } else {
                // Eğer geri sayım başlamışsa sıfırla ve tekrar başlat
                resetCountdown();
                var user = $(this).data('id');
                $.ajax({
                    type: "POST",
                    url: base_url + "ajax_controller/tel_dogrulama_resend",
                    data: {
                        kullanici: user,
                        telefon: $("#accountPhone").val()
                    },
                    success: function (data) {
                        var d = JSON.parse(data);
                        if (d.status.status == 'success') {
                            startCountdown();
                            $(".tel-dogrula-alert").html(d.status.alert_html);
                        } else {
                            $(".tel-dogrula-alert").html(d.status.alert_html);
                        }
                    }
                });
            }

            // Burada SMS gönderme işlemlerini gerçekleştirebilirsiniz.
        });

        $('.tel-dogrula-button').on('click', function () {
            var user = $(this).data('id');
            $.ajax({
                type: "POST",
                url: base_url + "ajax_controller/tel_dogrulama",
                data: {
                    kullanici: user,
                    telefon: $("#accountPhone").val()
                },
                success: function (data) {
                    var d = JSON.parse(data);
                    if (d.status.status == 'success') {
                        startCountdown();
                        $(".tel-dogrula-alert").html(d.status.alert_html);
                    } else {
                        $(".tel-dogrula-alert").html(d.status.alert_html);
                    }
                }
            });

        });

        $('.tel-dogrulama-form').on('submit', function () {
            var kod = $('input[name="tel_dogrulama"]').val();
            $.ajax({
                type: "POST",
                url: base_url + "ajax_controller/tel_kod_dogrulama",
                data: {
                    code: kod,
                },
                success: function (data) {
                    var d = JSON.parse(data);
                    if (d.status.status == 'success') {
                        Swal.fire(
                            'Başarılı!',
                            d.status.message,
                            d.status.status,
                        );
                        setTimeout(
                            function () {
                                window.location.reload();
                            }, 2000);
                    } else {
                        Swal.fire(
                            'Hata!',
                            d.status.message,
                            d.status.status,
                        );
                    }
                }
            });

        });
    </script>


    <script>
        $(document).ready(function () {
            // İlk sekme ve içeriği aktif hale getirme
            // Sekme tıklama olayı
            $('.PaymentTypes li').click(function () {
                var tabId = $(this).attr('id');

                // Aktif sekmeleri değiştirme
                $('.PaymentTypes li').removeClass('active');
                $(this).addClass('active');
                $('#intro').addClass("d-none");
                // Tüm içerikleri gizleme
                $('.tab-content .content').addClass('d-none');

                // İlgili içeriği gösterme
                $('#' + tabId + '-content').removeClass('d-none');
            });
        });

        var BreadcrumbInitialList = [{"name": "Ana Sayfa", "link": "\/"}, {
            "name": "Sipari\u015flerim",
            "link": "\/siparislerim"
        }];
        var BreadcrumbNames = {
            "aldigim-ilanlar": "Ald\u0131\u011f\u0131m \u0130lanlar",
            "sattigim-ilanlar": "Satt\u0131\u011f\u0131m \u0130lanlar",
            "aldigim-urunler": "Ald\u0131\u011f\u0131m \u00dcr\u00fcnler"
        };
        var ActiveTab = "aldigim-ilanlar";
    </script>
<?php } ?>

<script>
    setInterval(sendBekleyenAjaxRequest, 20000);
    setInterval(sendOnaylananAjaxRequest, 20000);
    setInterval(sendIptalAjaxRequest, 20000);

    setInterval(sendAlimBekleyenAjaxRequest, 20000);
    setInterval(sendAlimOnaylananAjaxRequest, 20000);
    setInterval(sendAlimIptalAjaxRequest, 20000);

    function sendBekleyenAjaxRequest() {
        <?php if (aktif_kullanici()) : ?>
        $.post({
            url: "<?= base_url('onay-bekleyen-satislar')?>",
            type: 'POST',
            success: function (response) {
                var data = JSON.parse(response);
                if (data.status === true) {
                    var html = '';
                    $.each(data.data, function (index, val) {
                        html += '<div class="sale-cards"><div class="sale-container"><div class="sale-card"><div class="product-detail"><div class="sale-img">';
                        html += '<a href="javascript:void(0)"><img src="https://kemalellidort.com.tr/' + val.urun_resim_min + '"></a></div>';
                        html += '<div class="product-info"><div class="p-name"><a href="javascript:void(0)">' + val.urun_ad + '</a></div> <div class="p-price">Fiyat: <span>' + val.urun_alimfiyat + ' TL</span></div><div class="p-price">Toplam Kazanç:<span>' + val.price + ' TL</span></div><div class="p-quantity">Adet:<span>' + val.quantity + '</span></div></div></div>';
                        html += '<div class="sale-status status-0"><i class="fa-solid fa-gauge-high"></i> Teslimat bekliyor <button class="btn btn-primary btn-sm sale-detail-button align-self-end" data-bs-toggle="modal" data-bs-target="#info-satim-modal-' + val.id + '"> İletilen Bilgiler </button></div>';
                        html += '<div class="sale-info"><div class="s-date"> <i class="fa-regular fa-clock"></i>' + val.added_time + '</div><div class="s-delivery">Satıcı: <a class="p-seller" href="">' + val.kullanici_ad + '</a></div></div></div><div class="sale-alerts "><div>' + val.urun_alimbaslik + '</div></div></div></div></div>';
                        html += '<div class="modal fade" id="info-satim-modal-' + val.id + '" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true"><div class="modal-dialog"><div class="modal-content"><div class="modal-header"><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div><div class="modal-body"><div class="detail-data-rows"><div class="detail-data-row"><span class="detail-data-name">Oyundaki Karakter Adınız :</span><span class="detail-data-val">' + val.character_name + '</span></div></div></div><div class="modal-footer boder-0"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Kapat</button></div></div></div></div>';
                    });
                    $('#pills-waiting-5').html(html);
                } else {
                    Swal.fire({
                        title: 'Hata',
                        text: data.message,
                        icon: 'warning',
                    })
                }
            },
            error: function (response) {
                console.log(response);
            }
        });
        <?php else : ?>
        Swal.fire({
            title: 'Giriş Yap',
            text: "İşlem Yapabilmek İçin Giriş Yapmalısınız.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Giriş Yap',
            cancelButtonText: 'Hayır, İptal Et',
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = "<?= base_url('giris-yap') ?>";
            }
        })
        <?php endif; ?>
    }

    function sendOnaylananAjaxRequest() {
        <?php if (aktif_kullanici()) : ?>
        $.post({
            url: "<?= base_url('tamamlanan-satislar')?>",
            type: 'POST',
            success: function (response) {
                var data = JSON.parse(response);
                if (data.status === true) {
                    var html = '';
                    $.each(data.data, function (index, val) {
                        html += '<div class="sale-cards"><div class="sale-container"><div class="sale-card"><div class="product-detail"><div class="sale-img">';
                        html += '<a href="javascript:void(0)"><img src="https://kemalellidort.com.tr/' + val.urun_resim_min + '"> </a></div>';
                        html += '<div class="product-info"><div class="p-name"><a href="javascript:void(0)">' + val.urun_ad + '</a></div><div class="p-price">Fiyat: <span>' + val.urun_alimfiyat + ' TL</span></div><div class="p-price">Toplam Kazanç: <span>' + val.price + ' TL</span></div><div class="p-quantity">Adet: <span>' + val.quantity + '</span></div></div></div>';
                        html += '<div class="sale-info"><div class="s-date"><i class="fa-regular fa-clock"></i> ' + val.added_time + '</div><div class="s-delivery">Teslimat Tarihi: <span>' + val.delivery_date + '</span></div><div class="s-delivery">Satıcı: <a class="p-seller" href="">' + val.kullanici_ad + '</a></div></div></div>';
                        html += '<div class="sale-status-g"><div class="sale-status status-1"><i class="fa-solid fa-circle-check"></i> Teslim edildi</div><div class="s-name">Teslim edilecek karakter adı: <span>*******</span></div><button class="btn btn-primary btn-sm sale-detail-button align-self-end" data-bs-toggle="modal" data-bs-target="#info-satim-comp-modal-' + val.id + '">İletilen Bilgiler</button></div></div><div class="sale-alerts "><div>' + val.urun_alimbaslik + '</div></div></div>';
                        html += '<div class="modal fade" id="info-satim-comp-modal-' + val.id + '" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true"><div class="modal-dialog"><div class="modal-content"><div class="modal-header"><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div><div class="modal-body"><div class="detail-data-rows"><div class="detail-data-row"><span class="detail-data-name">Oyundaki Karakter Adınız :</span><span class="detail-data-val">' + val.character_name + '</span></div></div></div><div class="modal-footer boder-0"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Kapat</button></div></div></div></div>';
                    });
                    $('#pills-complate-5').html(html);
                } else {
                    Swal.fire({
                        title: 'Hata',
                        text: data.message,
                        icon: 'warning',
                    })
                }
            },
            error: function (response) {
                console.log(response);
            }
        });
        <?php else : ?>
        Swal.fire({
            title: 'Giriş Yap',
            text: "İşlem Yapabilmek İçin Giriş Yapmalısınız.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Giriş Yap',
            cancelButtonText: 'Hayır, İptal Et',
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = "<?= base_url('giris-yap') ?>";
            }
        })
        <?php endif; ?>
    }

    function sendIptalAjaxRequest() {
        <?php if (aktif_kullanici()) : ?>
        $.post({
            url: "<?= base_url('iptal-edilen-satislar')?>",
            type: 'POST',
            success: function (response) {
                var data = JSON.parse(response);
                if (data.status === true) {
                    var html = '';
                    $.each(data.data, function (index, val) {
                        html += '<div class="sale-cards"><div class="sale-container"><div class="sale-card"><div class="product-detail"><div class="sale-img">';
                        html += '<a href="javascript:void(0)"><img src="https://kemalellidort.com.tr/' + val.urun_resim_min + '"> </a></div>';
                        html += '<div class="product-info"><div class="p-name"><a href="javascript:void(0)">' + val.urun_ad + '</a></div><div class="p-price">Fiyat: <span>' + val.urun_alimfiyat + ' TL</span></div><div class="p-price">Toplam Kazanç: <span>' + val.price + ' TL</span></div><div class="p-quantity">Adet: <span>' + val.quantity + '</span></div></div></div>';
                        html += '<div class="sale-status status-2"><i class="fad fa-window-close"></i> İptal edildi <button class="btn btn-primary btn-sm sale-detail-button align-self-end" data-bs-toggle="modal" data-bs-target="#info-satim-cancel-modal-' + val.id + '">İletilen Bilgiler</button></div><div class="sale-info"><div class="s-date"><i class="fad fa-clock"></i> ' + val.added_time + '</div><div class="s-delivery">Satıcı: <a class="p-seller" href="javascript:void(0)">' + val.kullanici_ad + '</a></div></div></div>';
                        html += '<div class="sale-alerts red">Satışınız iptal edilmiştir.' + val.reason_for_cancellation + '</div></div></div>';
                        html += '<div class="modal fade" id="info-satim-cancel-modal-' + val.id + '" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true"><div class="modal-dialog"><div class="modal-content"><div class="modal-header"><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div><div class="modal-body"><div class="detail-data-rows"><div class="detail-data-row"><span class="detail-data-name">Oyundaki Karakter Adınız :</span><span class="detail-data-val">' + val.character_name + '</span></div></div></div><div class="modal-footer boder-0"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Kapat</button></div></div></div></div>'
                    });
                    $('#pills-canseled-5').html(html);
                } else {
                    Swal.fire({
                        title: 'Hata',
                        text: data.message,
                        icon: 'warning',
                    })
                }
            },
            error: function (response) {
                console.log(response);
            }
        });
        <?php else : ?>
        Swal.fire({
            title: 'Giriş Yap',
            text: "İşlem Yapabilmek İçin Giriş Yapmalısınız.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Giriş Yap',
            cancelButtonText: 'Hayır, İptal Et',
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = "<?= base_url('giris-yap') ?>";
            }
        })
        <?php endif; ?>
    }

    // Alimlar

    function sendAlimBekleyenAjaxRequest() {
        <?php if (aktif_kullanici()) : ?>
        $.post({
            url: "<?= base_url('onay-bekleyen-alimlar')?>",
            type: 'POST',
            success: function (response) {
                var data = JSON.parse(response);
                if (data.status === true) {
                    var html = '';
                    $.each(data.data, function (index, val) {
                        html += '<div class="sale-cards"><div class="sale-container"><div class="sale-card"><div class="product-detail"><div class="sale-img">';
                        html += '<a href="javascript:void(0)"><img src="https://kemalellidort.com.tr/' + val.urun_resim_min + '"></a></div>';
                        html += '<div class="product-info"><div class="p-name"><a href="javascript:void(0)">' + val.urun_ad + '</a></div> <div class="p-price">Fiyat: <span>' + val.urun_alimfiyat + ' TL</span></div><div class="p-price">Toplam Kazanç:<span>' + val.price + ' TL</span></div><div class="p-quantity">Adet:<span>' + val.quantity + '</span></div></div></div>';
                        html += '<div class="sale-status status-0"><i class="fa-solid fa-gauge-high"></i> Teslimat bekliyor <button class="btn btn-primary btn-sm sale-detail-button align-self-end" data-bs-toggle="modal" data-bs-target="#info-alis-w-modal' + val.id + '"> İletilen Bilgiler </button></div>';
                        html += '<div class="sale-info"><div class="s-date"> <i class="fa-regular fa-clock"></i>' + val.added_time + '</div><div class="s-delivery">Satıcı: <a class="p-seller" href="">' + val.kullanici_ad + '</a></div></div></div><div class="sale-alerts "><div>' + val.urun_alimbaslik + '</div></div></div></div></div>';
                        html += '<div class="modal fade" id="info-alis-w-modal' + val.id + '" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true"><div class="modal-dialog"><div class="modal-content"><div class="modal-header"><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div><div class="modal-body"><div class="detail-data-rows"><div class="detail-data-row"><span class="detail-data-name">Oyundaki Karakter Adınız :</span><span class="detail-data-val">' + val.character_name + '</span></div></div></div><div class="modal-footer boder-0"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Kapat</button></div></div></div></div>';
                    });
                    $('#pills-waiting-6').html(html);
                } else {
                    Swal.fire({
                        title: 'Hata',
                        text: data.message,
                        icon: 'warning',
                    })
                }
            },
            error: function (response) {
                console.log(response);
            }
        });
        <?php else : ?>
        Swal.fire({
            title: 'Giriş Yap',
            text: "İşlem Yapabilmek İçin Giriş Yapmalısınız.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Giriş Yap',
            cancelButtonText: 'Hayır, İptal Et',
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = "<?= base_url('giris-yap') ?>";
            }
        })
        <?php endif; ?>
    }

    function sendAlimOnaylananAjaxRequest() {
        <?php if (aktif_kullanici()) : ?>
        $.post({
            url: "<?= base_url('tamamlanan-alimlar')?>",
            type: 'POST',
            success: function (response) {
                var data = JSON.parse(response);
                if (data.status === true) {
                    var html = '';
                    $.each(data.data, function (index, val) {
                        html += '<div class="sale-cards"><div class="sale-container"><div class="sale-card"><div class="product-detail"><div class="sale-img">';
                        html += '<a href="javascript:void(0)"><img src="https://kemalellidort.com.tr/' + val.urun_resim_min + '"> </a></div>';
                        html += '<div class="product-info"><div class="p-name"><a href="javascript:void(0)">' + val.urun_ad + '</a></div><div class="p-price">Fiyat: <span>' + val.urun_alimfiyat + ' TL</span></div><div class="p-price">Toplam Kazanç: <span>' + val.price + ' TL</span></div><div class="p-quantity">Adet: <span>' + val.quantity + '</span></div></div></div>';
                        html += '<div class="sale-info"><div class="s-date"><i class="fa-regular fa-clock"></i> ' + val.added_time + '</div><div class="s-delivery">Teslimat Tarihi: <span>' + val.delivery_date + '</span></div><div class="s-delivery">Satıcı: <a class="p-seller" href="">' + val.kullanici_ad + '</a></div></div></div>';
                        html += '<div class="sale-status-g"><div class="sale-status status-1"><i class="fa-solid fa-circle-check"></i> Teslim edildi</div><div class="s-name">Teslim edilecek karakter adı: <span>*******</span></div><button class="btn btn-primary btn-sm sale-detail-button align-self-end" data-bs-toggle="modal" data-bs-target="#info-alim-comp-modal-' + val.id + '">İletilen Bilgiler</button></div></div><div class="sale-alerts "><div>' + val.urun_alimbaslik + '</div></div></div>';
                        html += '<div class="modal fade" id="info-alim-comp-modal-' + val.id + '" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true"><div class="modal-dialog"><div class="modal-content"><div class="modal-header"><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div><div class="modal-body"><div class="detail-data-rows"><div class="detail-data-row"><span class="detail-data-name">Oyundaki Karakter Adınız :</span><span class="detail-data-val">' + val.character_name + '</span></div></div></div><div class="modal-footer boder-0"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Kapat</button></div></div></div></div>';
                    });
                    $('#pills-complate-6').html(html);
                } else {
                    Swal.fire({
                        title: 'Hata',
                        text: data.message,
                        icon: 'warning',
                    })
                }
            },
            error: function (response) {
                console.log(response);
            }
        });
        <?php else : ?>
        Swal.fire({
            title: 'Giriş Yap',
            text: "İşlem Yapabilmek İçin Giriş Yapmalısınız.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Giriş Yap',
            cancelButtonText: 'Hayır, İptal Et',
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = "<?= base_url('giris-yap') ?>";
            }
        })
        <?php endif; ?>
    }

    function sendAlimIptalAjaxRequest() {
        <?php if (aktif_kullanici()) : ?>
        $.post({
            url: "<?= base_url('iptal-edilen-alimlar')?>",
            type: 'POST',
            success: function (response) {
                var data = JSON.parse(response);
                if (data.status === true) {
                    var html = '';
                    $.each(data.data, function (index, val) {
                        html += '<div class="sale-cards"><div class="sale-container"><div class="sale-card"><div class="product-detail"><div class="sale-img">';
                        html += '<a href="javascript:void(0)"><img src="https://kemalellidort.com.tr/' + val.urun_resim_min + '"> </a></div>';
                        html += '<div class="product-info"><div class="p-name"><a href="javascript:void(0)">' + val.urun_ad + '</a></div><div class="p-price">Fiyat: <span>' + val.urun_alimfiyat + ' TL</span></div><div class="p-price">Toplam Kazanç: <span>' + val.price + ' TL</span></div><div class="p-quantity">Adet: <span>' + val.quantity + '</span></div></div></div>';
                        html += '<div class="sale-status status-2"><i class="fad fa-window-close"></i> İptal edildi <button class="btn btn-primary btn-sm sale-detail-button align-self-end" data-bs-toggle="modal" data-bs-target="#info-alim-cancel-modal-' + val.id + '">İletilen Bilgiler</button></div><div class="sale-info"><div class="s-date"><i class="fad fa-clock"></i> ' + val.added_time + '</div><div class="s-delivery">Satıcı: <a class="p-seller" href="javascript:void(0)">' + val.kullanici_ad + '</a></div></div></div>';
                        html += '<div class="sale-alerts red">Satışınız iptal edilmiştir.' + val.reason_for_cancellation + '</div></div></div>';
                        html += '<div class="modal fade" id="info-alim-cancel-modal-' + val.id + '" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true"><div class="modal-dialog"><div class="modal-content"><div class="modal-header"><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div><div class="modal-body"><div class="detail-data-rows"><div class="detail-data-row"><span class="detail-data-name">Oyundaki Karakter Adınız :</span><span class="detail-data-val">' + val.character_name + '</span></div></div></div><div class="modal-footer boder-0"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Kapat</button></div></div></div></div>'
                    });
                    $('#pills-canseled-6').html(html);
                } else {
                    Swal.fire({
                        title: 'Hata',
                        text: data.message,
                        icon: 'warning',
                    })
                }
            },
            error: function (response) {
                console.log(response);
            }
        });
        <?php else : ?>
        Swal.fire({
            title: 'Giriş Yap',
            text: "İşlem Yapabilmek İçin Giriş Yapmalısınız.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Giriş Yap',
            cancelButtonText: 'Hayır, İptal Et',
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = "<?= base_url('giris-yap') ?>";
            }
        })
        <?php endif; ?>
    }

</script>


<script>
    document.addEventListener("DOMContentLoaded", function () {
        var button = document.getElementById("targetButton");
        var targetId = button.getAttribute("data-target");
        var targetElement = document.querySelector(targetId);

        button.addEventListener("click", function () {
            targetElement.style.display = "block";
        });
    });

</script>
