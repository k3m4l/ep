<div class="navbar-nav flex-column">
    <span class="navbar-header">Giden Mesajlar</span>
    <?php if ($mesaj) {?>
        <ul class="list-unstyled ml-n2 mb-0 scroll-down-account <?php if ($amesaj->uniq==$this->uri->segment(2)){ echo ' account-active'; } ?>" id="style-3" >
            <?php foreach ($mesaj as $ms) { ?>
                <?php if (magaza_check_id($ms->alan_id)) { ?>
                    <?php $magazaCek = magaza_bilgi($ms->alan_id); ?>
                    <li class="nav-item">
                        <a class="nav-link d-flex align-items-center"
                           href="<?= base_url('mesaj/' . $ms->uniq) ?>">
                                        <span class="avatar avatar-xs">
                                            <img src="<?= base_url($magazaCek->magaza_resim) ?>"
                                                 alt="<?= $magazaCek->magaza_ad ?>" class="rounded-circle"/>
                                        </span>
                            <span class="ml-1"><?= $magazaCek->magaza_ad ?></span>
                        </a>
                    </li>
                <?php } else { ?>
                    <?php $user = kullanici_bilgi($ms->gonderen_id); ?>
                    <li class="nav-item">
                        <a class="nav-link d-flex align-items-center"
                           href="<?= base_url('mesaj/' . $ms->uniq) ?>">
                                        <span class="avatar avatar-xs">
                                            <img src="<?= base_url($user->kullanici_resim) ?>"
                                                 alt="<?= $user->kullanici_isim . " " . $user->kullanici_soyisim ?>"
                                                 class="rounded-circle"/>
                                        </span>
                            <span class="ml-1"><?= $user->kullanici_isim . " " . $user->kullanici_soyisim ?></span>
                        </a>
                    </li>
                <?php } ?>
            <?php } ?>
        </ul>
    <?php } else { ?>
        <ul class="list-unstyled ml-n2 mb-0 text-center">
            <span>Mesaj Bulunamadı</span>
        </ul>
    <?php } ?>
</div>