<nav class="navbar navbar-expand-md navbar-light shadow-sm mb-4 mb-lg-0 small-sidenav" style="margin-top: 0 !important;">
    <!-- Menu -->
    <a class="d-xl-none d-lg-none d-md-none text-inherit font-weight-bold" href="#!">Menüler</a>
    <!-- Button -->
    <button class="navbar-toggler d-md-none icon-shape icon-sm rounded bg-primary text-light"
            type="button"
            data-toggle="collapse" data-target="#smallSidenav" aria-controls="smallSidenav"
            aria-expanded="false"
            aria-label="Toggle navigation">
        <span class="fe fe-menu"></span>
    </button>
    <!-- Collapse -->
    <div class="collapse navbar-collapse" id="smallSidenav"  style="overflow:hidden;">
        <div class="navbar-nav flex-column">
            <!--<div class="user-info">
                <img class="img-profile img-circle img-responsive center-block" style="height: 166px;width: auto;" src="<?php // base_url($kullanici->kullanici_resim) ?>" alt="">
                <ul class="meta list list-unstyled" style="text-align: center;">
                    <li class="name"><?php //$kullanici->kullanici_isim . " " . $kullanici->kullanici_soyisim ?></li>
                </ul>
            </div>
            -->

            <?php if (magaza_check()) { ?>
                <span class="navbar-header navbar-border tabs-btn" style="text-align: left;" data-target="1">Mağaza</span>
                <ul class="profile-segments tab-area active" style="margin-left: -50px;" id="tabs-target-1">
                    <!-- Nav item -->
                    <li class="profile-item <?php if ($this->uri->segment(1) == "magazam") {
                        echo 'prf-active';
                    } ?>">
                        <a class="profile-link" href="<?= base_url('magazam') ?>">
                            <i class="fas fa-store-alt"></i> Mağazam
                        </a>
                    </li>
                    <!-- Nav item -->
                    <li class="profile-item <?php if ($this->uri->segment(1) == "urunlerim" || $this->uri->segment(1) == "urun-reklam" || $this->uri->segment(1) == "urun-galeri" || $this->uri->segment(1) == "urun-dosya" || $this->uri->segment(1) == "urun-duzenle"){
                        echo 'prf-active';
                    } ?>">
                        <a class="profile-link" href="<?= base_url('ilanlarim') ?>">
                            <i class="fas fa-shopping-cart"></i> İlanlarım</a>
                    </li>
                    <!-- Nav item -->
                    <li class="profile-item <?php if ($this->uri->segment(1) == "yorumlar") {
                        echo 'prf-active';
                    } ?>">
                        <a class="profile-link" href="<?= base_url('yorumlar') ?>">
                            <i class="fas fa-star"></i> Ürün Değerlendirmeleri</a>
                    </li>
                    <!-- Nav item -->
                    <li class="profile-item <?php if ($this->uri->segment(1) == "satislarim" || $this->uri->segment(1) == "satis-detay") {
                        echo 'prf-active';
                    } ?>">
                        <a class="profile-link" href="<?= base_url('satislarim') ?>">
                            <i class="fas fa-chart-bar"></i> Satışlarım &nbsp; <span
                                    class="badge badge-success badge-sm rounded-pill"><?= toplam_siparis_adet($kullanici->kullanici_id) ?></span>
                        </a>
                    </li>

                    <!-- Nav item -->
                    <li class="profile-item <?php if ($this->uri->segment(1) == "kazanclarim") {
                        echo 'prf-active';
                    } ?>">
                        <a class="profile-link" href="<?= base_url('kazanclarim') ?>">
                            <i class="fas fa-chart-pie"></i> Kazançlarım</a>
                    </li>

                    <li class="profile-item <?php if ($this->uri->segment(1) == "cekilislerim") {
                        echo 'prf-active';
                    } ?>">
                        <a class="profile-link" href="<?= base_url('cekilislerim') ?>">
                            <i class="fas fa-gift"></i> Çekilişlerim</a>
                    </li>

                    <li class="profile-item <?php if ($this->uri->segment(1) == "ilan-sorulari") {
                        echo 'prf-active';
                    } ?>">
                        <a class="profile-link" href="<?= base_url('ilan-sorulari') ?>">
                            <i class="fas fa-question"></i> İlan Soruları</a>
                    </li>


                    <li class="profile-item <?php if ($this->uri->segment(1) == "magaza-ayarlarim") {
                        echo 'prf-active';
                    } ?>">
                        <a class="profile-link" href="<?= base_url('magaza-ayarlarim') ?>">
                            <i class="fas fa-cog"></i> Mağaza Ayarlarım</a>
                    </li>
                </ul>
            <?php } ?>
            <!-- Navbar header -->

            <span class="navbar-header navbar-border tabs-btn" style="text-align: left;" data-target="2">Hesabım</span>
            <ul class="profile-segments tab-area active" style="margin-left: -50px;" id="tabs-target-2">
                <li class="profile-item <?php if ($this->uri->segment(1) == "hesabim"):?> prf-active <?php endif;?>">
                    <a href="<?= base_url('hesabim') ?>" class="profile-link ">
                        <i class="fas fa-home"></i> Hesabım
                    </a>
                </li>
                <li class="profile-item <?php if ($this->uri->segment(1) == "bakiye"):?> prf-active <?php endif;?>">
                    <a class="profile-link" href="<?= base_url('bakiye') ?>">
                        <i class="fas fa-coins"></i> Bakiye
                    </a>
                </li>
                <li class="profile-item <?php if ($this->uri->segment(1) == "odeme-talep") {
                    echo 'prf-active';
                } ?>">
                    <a class="profile-link" href="<?= base_url('odeme-talep') ?>">
                        <i class="far fa-credit-card"></i> Para Çek</a>
                </li>
                <li class="profile-item <?php if ($this->uri->segment(1) == "siparislerim" || $this->uri->segment(1) == "siparis-detay") {
                    echo 'prf-active';
                } ?>">
                    <a class="profile-link" href="<?= base_url('siparislerim') ?>">
                        <i class="fas fa-shopping-cart"></i> Siparişlerim
                    </a>
                </li>
                <li class="profile-item <?php if ($this->uri->segment(1) == "itirazlarim") {
                    echo 'prf-active';
                } ?>">
                    <a class="profile-link" href="<?= base_url('itirazlarim') ?>">
                        <i class="fas fa-hand-paper"></i> İtirazlarım
                    </a>
                </li>
                <li class="profile-item <?php if ($this->uri->segment(1) == "sorularim") {
                    echo 'prf-active';
                } ?>">
                    <a class="profile-link" href="<?= base_url('sorularim') ?>">
                        <i class="fas fa-question"></i> Sorularım
                    </a>
                </li>
                <!-- Nav item -->
                <li class="profile-item <?php if ($this->uri->segment(1) == "satislar" || $this->uri->segment(1) == "sat-detay") {
                    echo 'prf-active';
                } ?>">
                    <a class="profile-link" href="<?= base_url('satislar') ?>">
                        <i class="fas fa-chart-bar"></i> Siteye Satışlarım
                    </a>
                </li>
                <!-- Nav item -->
                <li class="profile-item <?php if ($this->uri->segment(1) == "hesap-ayarlari") {
                    echo 'prf-active';
                } ?>">
                    <a class="profile-link" href="<?= base_url('hesap-ayarlari') ?>">
                        <i class="fas fa-cog"></i> Hesap Ayarları
                    </a>
                </li>
                <!-- Nav item -->
                <li class="profile-item <?php if ($this->uri->segment(1) == "destek-taleplerim") {
                    echo 'prf-active';
                } ?>">
                    <a class="profile-link" href="<?= base_url('destek-taleplerim') ?>">
                        <i class="far fa-comments"></i> Destek Taleplerim &nbsp; <span
                                class="badge badge-success badge-sm rounded-pill" style="margin auto;"  data-toggle="tooltip"
                                data-placement="top" title="Yanıtlanmamış / Toplam"><?php
                            $this->db->select('COUNT(talep_id) as toplam');
                            $this->db->where("kullanici_id='".$kullanici->kullanici_id."' and talep_durum='0'");
                            $aylik_siparis_adet= $this->db->get('talep')->result();
                            $data = [];
                            foreach ($aylik_siparis_adet as $row) {
                                $data[] += $row->toplam;
                            }
                            echo $data[0];

                            ?> / <?php
                            $this->db->select('COUNT(talep_id) as toplam');
                            $this->db->where("kullanici_id='".$kullanici->kullanici_id."'");
                            $aylik_siparis_adet= $this->db->get('talep')->result();
                            $data = [];
                            foreach ($aylik_siparis_adet as $row) {
                                $data[] += $row->toplam;
                            }
                            echo $data[0];

                            ?></span>
                    </a>
                </li>

                <!-- Nav item -->
                <li class="profile-item">
                    <a class="profile-link" href="<?= base_url('cikis') ?>">
                        <i class="fas fa-power-off"></i> Çıkış Yap
                    </a>
                </li>
            </ul>
        </div>
    </div>
