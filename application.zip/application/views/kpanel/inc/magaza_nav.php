<section class="col-lg-8 account-profile-element">
    <div class="account-profile-photo-area" style="background-image: url('<?php echo base_url($kadijoin->kullanici_banner)?>')">
        <div class="user-photo-area-shop">
            <div class="row align-items-center">
                <div class="col-xl-12 col-lg-12 col-md-12 col-12">
                    <div
                        class="px-4 pt-2 pb-4 rounded-none rounded-bottom shadow-sm">
                        <div class="d-flex align-items-center" style="margin-bottom: 15px;">
                            <div class="mr-2 position-relative d-flex justify-content-end align-items-end">

                                <?php if (strpos($kadijoin->kullanici_resim, "/.jpg") !== false) { ?>
                                    <img
                                        src="https://ui-avatars.com/api/?name=<?= $kadijoin->kullanici_ad ?>&background=0D8ABC&color=fff"
                                        class="avatar-xl rounded-circle border-width-4 border-white position-relative" alt=""/>
                                <?php } else { ?>
                                    <img src="<?= base_url($kadijoin->kullanici_resim) ?>"
                                         class="avatar-xl rounded-circle border-width-4 border-white position-relative" alt=""/>
                                <?php } ?>

                                <?php if ($magaza->magaza_dogrulama == 1) { ?>
                                    <a href="javascript:void(0)" class="position-absolute top-0 right-0"
                                       data-toggle="tooltip"
                                       data-placement="top" title=""
                                       data-original-title="Doğrulanmış Mağaza">
                                        <img src="<?= base_url('assets/front/') ?>images/checked-mark.svg" alt=""
                                             height="25" width="25"/>
                                    </a>
                                <?php } ?>
                            </div>
                            <div class="lh-1">
                                <h2 class="mb-0 light-color"><?= $magaza->magaza_ad ?></h2>
                                <p class="mb-0 light-color d-block">@<?= $magaza->magaza_seo ?></p>
                            </div>
                        </div>
                        <div class="d-flex align-items-center">
                            <?php if ($magaza->magaza_durum == 0) { ?>
                                <span class="btn btn-primary btn-sm mr-3 badge-pill">Onay Bekliyor <span
                                        class="spinner-border spinner-border-sm ml-2" role="status"
                                        aria-hidden="true"></span></span>
                            <?php } elseif ($magaza->magaza_durum == 1) { ?>
                                <span class="btn btn-success btn-sm mr-3 badge-pill"><i class="fe fe-check-circle"></i> Doğrulandı</span>
                            <?php } elseif ($magaza->magaza_durum == 2) { ?>
                                <span class="btn btn-danger btn-sm mr-3 badge-pill"><i class="fe fe-x-circle"></i> Doğrulanamadı!</span>
                            <?php } ?>
                            <a href="<?= base_url('m/' . $magaza->magaza_seo) ?>" target="_blank"
                               class="btn btn-primary btn-sm d-none d-md-block badge-pill">
                                <i class="fe fe-external-link"></i> Mağazam
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>