<style>
    .newMessageBtn {
        position: relative;
        font-size: 13px;
        height: 50px;
        line-height: 50px;
    }
    .newMessageBtn {
        display: none;
        bottom: 0;
        right: 0;
        width: 280px;
        text-align: center;
        line-height: 70px;
        background: linear-gradient(45deg,#677cff,#3295ec);
        color: #fff;
        font-weight: 900;
        font-size: 15px;
        cursor: pointer;
        text-transform: uppercase;
        border-top-left-radius: 4px;
    }
    .newMessageBtn img {
        display: inline-block;
        vertical-align: middle;
    }
</style>
<div class="navbar-nav flex-column nv">
    <a href="<?= base_url('yeni-mesaj'); ?>" class="btn btn-sm btn-light-info mb-5">Yeni Sohbet</a>
    <span class="navbar-header">Gelen/Giden Kutusu</span>

    <style>
        .userListMessage li {
            width: 280px;
            height: 70px;
            border-bottom: 1px solid #363a48;
            padding: 15px;
            cursor: pointer;
            position: relative;
            border-left: 3px solid transparent;
        }
    </style>
    <?php if ($mesaj) { ?>

        <ul class="list-unstyled ml-n2 mb-0 scroll-down-account" id="style-3">
            <?php foreach ($mesaj as $ms) { ?>
                <?php if (magaza_check_id($ms->gonderen_id)) { ?>
                    <?php $magazaCek = magaza_kbilgi($ms->gonderen_id); ?>
                    <?php if ($magazaCek) { ?>
                        <li class="nav-item <?php if ($ms->uniq == $this->uri->segment(2)) {
                            echo ' active';
                        } ?>">
                            <a class="nav-link d-flex align-items-center"
                               href="<?= base_url('mesaj/' . $ms->uniq) ?>">
                                        <span class="avatar avatar-xs">
                                            <img src="<?= base_url($magazaCek->magaza_resim) ?>"
                                                 alt="<?= $magazaCek->magaza_ad ?>" class="rounded-circle"/>
                                        </span>
                                <span class="ml-1"><?= $magazaCek->magaza_ad ?></span>
                            </a>
                        </li>
                    <?php } ?>
                <?php } else { ?>
                    <?php $user = kullanici_bilgi($ms->gonderen_id); ?>
                    <li class="nav-item <?php if ($ms->uniq == $this->uri->segment(2)) {
                        echo ' active';
                    } ?>">
                        <a class="nav-link d-flex align-items-center"
                           href="<?= base_url('mesaj/' . $ms->uniq) ?>">
                                        <span class="avatar avatar-xs">
                                            <img src="<?= base_url($user->kullanici_resim) ?>"
                                                 alt="<?= $user->kullanici_isim . " " . $user->kullanici_soyisim ?>"
                                                 class="rounded-circle"/>
                                        </span>
                            <span class="ml-1"><?= $user->kullanici_isim . " " . $user->kullanici_soyisim ?></span>
                        </a>
                    </li>
                <?php } ?>
            <?php } ?>
        </ul>
    <?php } ?>

    <?php if ($giden_mesaj) { ?>
        <ul class="list-unstyled ml-n2 mb-0 scroll-down-account" id="style-3">
            <?php foreach ($giden_mesaj as $ms) { ?>
                <?php if (magaza_check_id($ms->alan_id)) { ?>
                    <?php $magazaCek = magaza_kbilgi($ms->alan_id); ?>
                    <li class="nav-item  <?php if ($ms->uniq == $this->uri->segment(2)) {
                        echo ' active';
                    } ?>">
                        <a class="nav-link d-flex align-items-center justify-content-between"
                           href="<?= base_url('mesaj/' . $ms->uniq) ?>">
                            <div class="d-flex align-items-center">
                                <span class="avatar avatar-xs">
                                            <img src="<?= base_url($magazaCek->magaza_resim) ?>"
                                                 alt="<?= $magazaCek->magaza_ad ?>" class="rounded-circle"/>
                                        </span>
                                <span class="ml-1"><?= $magazaCek->magaza_ad ?></span>
                            </div>
                            <?php if (mesajOkunmamis()) { ?>
                                <span class="badge badge-warning text-white badge-pill tx-8"><?= mesajOkunmamisSay() ?></span>
                            <?php } ?>
                        </a>

                    </li>
                <?php } else { ?>
                    <?php $user = kullanici_bilgi($ms->gonderen_id); ?>
                    <li class="nav-item <?php if ($ms->uniq == $this->uri->segment(2)) {
                        echo ' active';
                    } ?>">
                        <a class="nav-link d-flex align-items-center"
                           href="<?= base_url('mesaj/' . $ms->uniq) ?>">
                                        <span class="avatar avatar-xs">
                                            <img src="<?= base_url($user->kullanici_resim) ?>"
                                                 alt="<?= $user->kullanici_isim . " " . $user->kullanici_soyisim ?>"
                                                 class="rounded-circle"/>
                                        </span>
                            <span class="ml-1"><?= $user->kullanici_isim . " " . $user->kullanici_soyisim ?></span>
                        </a>
                    </li>
                <?php } ?>
            <?php } ?>
        </ul>
    <?php } ?>
</div>
