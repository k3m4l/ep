<?php

defined('BASEPATH') or exit('No direct script access allowed');


use Anilken\Turkpin\Turkpin;

class TurkpinApi extends CI_Controller
{
    public function index()
    {
        $api = new Turkpin('agentsunucu@gmail.com', 'Mehmet.3434');

        try {
            $epinOrder = $api->epinOrder(6, 10929, 1, '');
            print_r($epinOrder['list'][0]['code']);
        } catch (\Exception $e) {
            echo $e->getMessage();
            echo "no";
        }

    }
}
