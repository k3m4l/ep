<?php

defined('BASEPATH') or exit('No direct script access allowed');

class kupon_controller extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        date_default_timezone_set('Europe/Istanbul');
    }
    function log_records() {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }
        $data = new stdClass();

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;
        $data->kayitlar = $this->kupon_model->get_all_logs();

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/kupon/kayitlar', $data);
        $this->load->view('yonetim/inc/_footer');
    }
    function index() {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }
        $data = new stdClass();

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;
        $data->kuponlar = $this->kupon_model->get_all();

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/kupon/kuponlar', $data);
        $this->load->view('yonetim/inc/_footer');
    }
    function kuponekle() {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }
        $data = new stdClass();

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/kupon/kupon-ekle', $data);
        $this->load->view('yonetim/inc/_footer');
    }
    public function kupon_go()
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $this->load->library("form_validation");

        $this->form_validation->set_rules("ad", "Kupon Adı", "required|trim");
        $this->form_validation->set_rules("kod", "Kupon Kodu", "required|trim|is_unique[kuponlar.kod]");
        $this->form_validation->set_rules("tutar", "Kupon Tutarı", "required|trim");
        $this->form_validation->set_rules("stok", "Kupon Adeti", "required|trim");
        $this->form_validation->set_rules("bitis_tarihi", "Kupon Geçerlilik Tarihi", "required|trim");
        $this->form_validation->set_rules("durum", "Kupon Durumu", "required|trim");

        $this->form_validation->set_message(
            array(
                "required" => "{field} Boş Bırakılamaz!",
                "is_unique" => "{field} zaten var!",
            )
        );

        $validat = $this->form_validation->run();
        if ($validat) {

            $data = array(
                "ad" => $this->input->post("ad"),
                "kod" => $this->input->post("kod"),
                "tutar" => $this->input->post("tutar"),
                "stok" => $this->input->post("stok"),
                "bitis_tarihi" => date('Y-m-d',strtotime($this->input->post("bitis_tarihi"))),
                "durum" => $this->input->post("durum")
            );
            $insert = $this->kupon_model->add($data);
            
            $alert = array(
                "title" => "İşlem Başarılı",
                "text" => "Kupon Başarılı Şekilde Eklendi",
                "type" => "success"
            );
            $this->session->set_flashdata("alert", $alert);
            redirect(base_url(admin_url() . "kupon-ekle"));
            die();
        } else {

            if (!active_user()) {
                redirect(base_url(admin_url() . 'giris'));
            }
            $data = new stdClass();

            $siteayar = ayarlar();
            $data->form_error = true;
            $data->title = $siteayar->site_baslik;
            $data->description = $siteayar->site_aciklama;
            $data->keywords = $siteayar->site_keyw;
    
            $this->load->view('yonetim/inc/_header', $data);
            $this->load->view('yonetim/kupon/kupon-ekle', $data);
            $this->load->view('yonetim/inc/_footer');
        }
    }
    function kuponduzenle($id) {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }
        $data = new stdClass();

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;
        $data->kupon = $this->kupon_model->get(['id'=> $id]);

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/kupon/kupon-duzenle', $data);
        $this->load->view('yonetim/inc/_footer');
    }
    public function kuponduzenle_go($id)
    {
        ini_set('display_errors','1');
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $this->load->library("form_validation");

        $this->form_validation->set_rules("ad", "Kupon Adı", "required|trim");
        $this->form_validation->set_rules("kod", "Kupon Kodu", "required|trim|edit_unique[kuponlar.kod.$id]");
        $this->form_validation->set_rules("tutar", "Kupon Tutarı", "required|trim");
        $this->form_validation->set_rules("stok", "Kupon Adeti", "required|trim");
        $this->form_validation->set_rules("bitis_tarihi", "Kupon Geçerlilik Tarihi", "required|trim");
        $this->form_validation->set_rules("durum", "Kupon Durumu", "required|trim");

        $this->form_validation->set_message(
            array(
                "required" => "{field} Boş Bırakılamaz!",
                "edit_unique" => "{field} zaten var!",
            )
        );

        $validat = $this->form_validation->run();
        if ($validat) {

            $data = array(
                "ad" => $this->input->post("ad"),
                "kod" => $this->input->post("kod"),
                "tutar" => $this->input->post("tutar"),
                "stok" => $this->input->post("stok"),
                "bitis_tarihi" => date('Y-m-d',strtotime($this->input->post("bitis_tarihi"))),
                "durum" => $this->input->post("durum")
            );
            $update = $this->kupon_model->update(['id'=>$id],$data);
            
            $alert = array(
                "title" => "İşlem Başarılı",
                "text" => "Kupon Başarılı Şekilde Güncellendi",
                "type" => "success"
            );
            $this->session->set_flashdata("alert", $alert);
            redirect(base_url(admin_url() . "kupon-duzenle/".$id));
            die();
        } else {

            if (!active_user()) {
                redirect(base_url(admin_url() . 'giris'));
            }
            $data = new stdClass();

            $siteayar = ayarlar();
            $data->form_error = true;
            $data->title = $siteayar->site_baslik;
            $data->description = $siteayar->site_aciklama;
            $data->keywords = $siteayar->site_keyw;
            $data->kupon = $this->kupon_model->get(['id'=>$id]);
    
            $this->load->view('yonetim/inc/_header', $data);
            $this->load->view('yonetim/kupon/kupon-duzenle', $data);
            $this->load->view('yonetim/inc/_footer');
        }
    }
    public function kupondelete($id) {
        
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }
        $this->kupon_model->delete(array("id" => $id));
        redirect(base_url(admin_url() . "kuponlar"));
    }
    public function kuponkayitdelete($id) {
        
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }
        $this->kupon_model->logdelete(array("id" => $id));
        redirect(base_url(admin_url() . "kuponlar"));
    }
}