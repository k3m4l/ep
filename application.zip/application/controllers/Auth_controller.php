<?php

defined('BASEPATH') or exit('No direct script access allowed');

class auth_controller extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->helper('security');
        $this->load->helper('url');
        $this->load->library("pagination");
    }

    public function giris_yap()
    {
        if (aktif_kullanici()) {
            redirect(base_url());
        }

        $data = new stdClass();

        $data->title = "Giriş Yap";
        $data->description = "";
        $data->keywords = "";
        $data->ayarlar = ayarlar();
        $data->kullanici = kullanicicek();

        $this->load->view('inc/_header', $data);
        $this->load->view('auth/giris', $data);
        $this->load->view('inc/_footer', $data);
    }

    public function hesap_olustur()
    {
        if (aktif_kullanici()) {
            redirect(base_url());
        }

        $data = new stdClass();

        $data->title = "Hesap Oluştur";
        $data->description = "";
        $data->keywords = "";
        $data->ayarlar = ayarlar();
        $data->kullanici = kullanicicek();

        $this->load->view('inc/_header', $data);
        $this->load->view('auth/hesap-olustur', $data);
        $this->load->view('inc/_footer', $data);
    }

    public function new_login_register()
    {
        if (aktif_kullanici()) {
            redirect(base_url());
        }

        $data = new stdClass();

        $data->title = "Giriş Yap & Kayıt Ol";
        $data->description = "";
        $data->keywords = "";
        $data->ayarlar = ayarlar();
        $data->kullanici = kullanicicek();
        $data->none = "d-none";

        $this->load->view('inc/_header', $data);
        $this->load->view('auth/new-tasarim', $data);
        $this->load->view('inc/_footer', $data);
    }

    public function hesapolustur()
    {

        if (aktif_kullanici()) {
            redirect(base_url());
            die();
        }
        if (!$_POST) {
            redirect(base_url());
            die();
        }

        $ayarlar = ayarlar();

        $recaptchaResponse = trim($this->input->post('g-recaptcha-response'));
        $userIp = $this->input->ip_address();

        $secret = $ayarlar->google_secret;

        $url = "https://www.google.com/recaptcha/api/siteverify?secret=" . $secret . "&response=" . $recaptchaResponse . "&remoteip=" . $userIp;

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $output = curl_exec($ch);
        curl_close($ch);

        $status = json_decode($output, true);

        if ($status['success'] == 1) {

            $this->load->library("form_validation");

            $this->form_validation->set_rules("kullaniciadi", "Kullanıcı Adı", "required|is_unique[kullanici.kullanici_ad]|trim|xss_clean");
            $this->form_validation->set_rules("ad", "Adınız", "required|trim|xss_clean");
            $this->form_validation->set_rules("soyad", "Soyadınız", "required|trim|xss_clean");
            $this->form_validation->set_rules("mail", "E-Posta", "required|valid_email|is_unique[kullanici.kullanici_mail]|trim|xss_clean");
            $this->form_validation->set_rules("sifre", "Şifre", "required|trim|xss_clean|min_length[6]");
            $this->form_validation->set_rules("sifretekrar", "Şifre Tekrar", "required|trim|xss_clean|min_length[6]|matches[sifre]");
            $this->form_validation->set_message(
                array(
                    "required" => "{field} Boş Bırakılamaz!",
                    "min_length" => "Şifreniz Minimum 6 Karakter Olmalı!",
                    "is_unique" => "{field} adresi zaten var!",
                    "xss_clean" => "XSS filter issue!"
                )
            );

            $validat = $this->form_validation->run();
            if ($validat) {

                if ($this->input->post("sifre") != $this->input->post("sifretekrar")) {
                    $alert = array(
                        "title" => "Hata!",
                        "text" => "Şifreler Uyuşmuyor!",
                        "type" => "error"
                    );
                    $this->session->set_flashdata("alert", $alert);
                    redirect($_SERVER['HTTP_REFERER']); // bypass edilebilir kritik seviyesinde değil
                    die();
                }

                if (!aktif_kullanici()) {

                    /*
                    $kullanici_ad = htmlspecialchars(seo($this->input->post("ad") . "-" . $this->input->post("soyad") . "-" . rand(1111, 9999)));

                    $rand_key = rand(99999, 9999999);
                    mkdir('uploads/urunler/' . $kullanici_ad, 0777);
                    mkdir('uploads/urunler/' . $kullanici_ad . '/galeri', 0777);
                    mkdir('uploads/kullanici/' . $kullanici_ad, 0777);
                    mkdir('uploads/dosya/' . $kullanici_ad, 0777);
                    */
                    $rand_key = rand(99999, 9999999);
                    $kullanici_ad = $this->input->post('kullaniciadi');
                    curl_resim_kaydet("https://ui-avatars.com/api/?rounded=true&name=" . $this->input->post("ad") . "+" . $this->input->post("soyad") . "&color=fffff&rounded=true&bold=true&size=150&background=754ffc", 'uploads/img/' . $rand_key . '.jpg');

                    $hesap = array(
                        "kullanici_ad" => $kullanici_ad,
                        "kullanici_sifre" => htmlspecialchars(password_hash($this->input->post("sifre"), PASSWORD_DEFAULT)),
                        "kullanici_mail" => htmlspecialchars($this->input->post("mail")),
                        "kullanici_yetki" => 1,
                        "kullanici_isim" => htmlspecialchars($this->input->post("ad")),
                        "kullanici_soyisim" => htmlspecialchars($this->input->post("soyad")),
                        "kullanici_uniq" => uniqid(),
                        "kullanici_resim" => 'uploads/img/' . $rand_key . '.jpg'

                    );

                    $insert = $this->home_model->kullaniciadd($hesap);
                    $kullanicid = $this->db->insert_id();

                    $kullanicises = $this->yonetim_model->get(array("kullanici_id" => $kullanicid));
                    $this->session->set_userdata("aktifkullanici", $kullanicises);

                    $alert = array(
                        "title" => "Hesap Oluşturuldu!",
                        "text" => "Hesabınız Başarılı Bir Şekilde Oluşturuldu!",
                        "type" => "success"
                    );

                    $this->session->set_flashdata("alert", $alert);
                    redirect(base_url());
                    die();
                }
            } else {
                if (aktif_kullanici()) {
                    redirect(base_url());
                }

                if (form_error("ad")) {
                    $alert = array(
                        "title" => "Hata!",
                        "text" => form_error("ad"),
                        "type" => "error"
                    );
                    $this->session->set_flashdata("alert", $alert);
                    redirect($_SERVER['HTTP_REFERER']);
                    die();
                } else if (form_error("soyad")) {
                    $alert = array(
                        "title" => "Hata!",
                        "text" => form_error("soyad"),
                        "type" => "error"
                    );
                    $this->session->set_flashdata("alert", $alert);
                    redirect($_SERVER['HTTP_REFERER']);
                    die();
                } else if (form_error("mail")) {
                    $alert = array(
                        "title" => "Hata!",
                        "text" => form_error("mail"),
                        "type" => "error"
                    );
                    $this->session->set_flashdata("alert", $alert);
                    redirect($_SERVER['HTTP_REFERER']);
                    die();
                } else if (form_error("sifre")) {
                    $alert = array(
                        "title" => "Hata!",
                        "text" => form_error("sifre"),
                        "type" => "error"
                    );
                    $this->session->set_flashdata("alert", $alert);
                    redirect($_SERVER['HTTP_REFERER']);
                    die();
                } else if (form_error("sifretekrar")) {
                    $alert = array(
                        "title" => "Hata!",
                        "text" => form_error("sifretekrar"),
                        "type" => "error"
                    );
                    $this->session->set_flashdata("alert", $alert);
                    redirect($_SERVER['HTTP_REFERER']);
                    die();
                } else if (form_error('kullaniciadi')) {
                    $alert = array(
                        "title" => "Hata!",
                        "text" => form_error("kullaniciadi"),
                        "type" => "error"
                    );
                    $this->session->set_flashdata("alert", $alert);
                    redirect($_SERVER['HTTP_REFERER']);
                    die();
                }
            }
        } else {
            $alert = array(
                "title" => "Hata!",
                "text" => "Robot Kontrolünü Boş Bırakmayınız!!",
                "type" => "error"
            );
            $this->session->set_flashdata("alert", $alert);
            redirect($_SERVER['HTTP_REFERER']); // bypass edilebilir kritik seviyesinde değil
            die();
        }

    }

    public function girisyap()
    {
        $this->load->library("form_validation");
        $this->form_validation->set_rules("username", "Kullanıcı Adı Veya E-Posta Adresiniz", "required|trim");
        $this->form_validation->set_rules("password", "Şifre", "required|trim");
        $this->form_validation->set_message(
            array(
                "required" => "{field} Boş Bırakılamaz!",
            )
        );
        $validat = $this->form_validation->run();

        if ($validat) {

            $email_or_username = $this->input->post("username");

            $kullanici = $this->yonetim_model->login_user($email_or_username);

            $recaptchaResponse = trim($this->input->post('g-recaptcha-response'));
            $userIp = $this->input->ip_address();
            $ayarlar = ayarlar();

            $secret = $ayarlar->google_secret;

            $url = "https://www.google.com/recaptcha/api/siteverify?secret=" . $secret . "&response=" . $recaptchaResponse . "&remoteip=" . $userIp;

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            $output = curl_exec($ch);
            curl_close($ch);

            $status = json_decode($output, true);

            if ($status['success'] == 1) {
                if ($kullanici) {
                    if (!password_verify($this->input->post('password'), $kullanici->kullanici_sifre)) {
                        $alert = array(
                            "title" => "Bir Sorun Var!",
                            "text" => "Kullanıcı Adı veya Şifre Yanlış. Lütfen Tekrar Deneyin..",
                            "type" => "error"
                        );
                        $this->session->set_flashdata("alert", $alert);
                        redirect($_SERVER['HTTP_REFERER']);
                        die();
                    } else {
                        if (password_needs_rehash($kullanici->kullanici_sifre, PASSWORD_DEFAULT)) {
                            $newHash = password_hash($this->input->post('password'), PASSWORD_DEFAULT);
                            $this->yonetim_model->update(array(
                                "kullanici_ad" => $this->input->post("username"),
                            ), array(
                                "kullanici_sifre" => $newHash,
                            ));
                        }

                        if ($kullanici->kullanici_yetki == 9) {
                            $this->session->set_userdata("kullanici", $kullanici);
                        }

                        $alert = array(
                            "title" => "Hoşgeldiniz,",
                            "text" => "Başarılı Şekilde Giriş Yaptınız",
                            "type" => "success"
                        );
                        $this->session->set_flashdata("alert", $alert);
                        $this->session->set_userdata("aktifkullanici", $kullanici);

                        // if (!empty($this->input->post("beni_hatirla"))) {
                        //     setcookie("username", $this->input->post("username"), time() + (10 * 365 * 24 * 60 * 60));
                        //     setcookie("password", md5($this->input->post("password")), time() + (10 * 365 * 24 * 60 * 60));
                        // } else {
                        //     setcookie("username", "");
                        //     setcookie("password", "");
                        // }

                        $guncelle = $this->yonetim_model->update(array(
                            "kullanici_ad" => $this->input->post("username"),
                        ), array(
                            "kullanici_sonzaman" => date("Y-m-d H:i:s"),
                            "kullanici_ip" => $_SERVER['REMOTE_ADDR'] // bypass vpn, basit ip değiştirme uygulamasıyla değiştirebilir
                        ));

                        redirect($_SERVER['HTTP_REFERER']);

                        die();
                    }
                } else {

                    $alert = array(
                        "title" => "Bir Sorun Var!",
                        "text" => "Kullanıcı Adı veya Şifre Yanlış. Lütfen Tekrar Deneyin..",
                        "type" => "error"
                    );

                    $this->session->set_flashdata("alert", $alert);

                    redirect($_SERVER['HTTP_REFERER']);

                    die();
                }
            } else {
                $alert = array(
                    "title" => "Hata!",
                    "text" => "Robot Kontrolünü Boş Bırakmayınız!!",
                    "type" => "error"
                );
                $this->session->set_flashdata("alert", $alert);
                redirect($_SERVER['HTTP_REFERER']); // bypass edilebilir kritik seviyesinde değil
                die();
            }
        } else {

            $data = new stdClass();
            $data->title = "";
            $data->description = "";
            $data->keywords = "";
            $data->form_error = true;
            $data->ayarlar = ayarlar();
            $data->kullanici = kullanicicek();

            $this->load->view('inc/_header', $data);
            $this->load->view('auth/new-tasarim', $data);
            $this->load->view('inc/_footer', $data);
        }
    }

    public function cikis()
    {
        $theme = $_SESSION["theme"];
        $this->session->unset_userdata("aktifkullanici");
        $this->session->sess_regenerate(TRUE);
        $this->output->set_header("Cache-Control: no-store, no-cache, must-revalidate, no-transform, max-age=0, post-check=0, pre-check=0");
        $this->output->set_header("Pragma: no-cache");
        $_SESSION["theme"] = $theme;
        redirect(base_url());
    }

    public function password()
    {
        if (aktif_kullanici()) {
            redirect(base_url());
            die();
        }

        $data = new stdClass();

        $siteayar = ayarlar();

        $data->title = 'Şifremi Unuttum?';
        $data->description = "";
        $data->keywords = "";
        $data->google_key = $siteayar->google_key;
        $data->ayarlar = $siteayar;
        $data->kullanici = kullanicicek();


        $this->load->view('inc/_header', $data);
        $this->load->view('auth/yeni-password', $data);
        $this->load->view('inc/_footer', $data);
    }

    public function sifre_sifirla()
    {
        $siteayar = ayarlar();
        $recaptchaResponse = trim($this->input->post('g-recaptcha-response'));

        $userIp = $this->input->ip_address();

        $secret = $siteayar->google_secret;

        $url = "https://www.google.com/recaptcha/api/siteverify?secret=" . $secret . "&response=" . $recaptchaResponse . "&remoteip=" . $userIp;

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $output = curl_exec($ch);
        curl_close($ch);

        $status = json_decode($output, true);

        if ($status['success']) {

            $this->load->library("form_validation");
            $this->form_validation->set_rules("mail", "E-Posta", "required|trim|xss_clean");

            $this->form_validation->set_message(
                array(
                    "required"       => "{field} boş bırakılamaz"
                )
            );

            $validat = $this->form_validation->run();
            if ($validat) {

                if (!aktif_kullanici()) {

                    $kullanicises = $this->yonetim_model->get(array("kullanici_mail" => $this->input->post("mail")));
                    if (!$kullanicises) {
                        $alert = array(
                            "title" =>     "Hata!",
                            "text" =>     "Bu E-Posta Adresine Kayıtlı Hesap Bulunamadı!",
                            "type"  =>     "error"
                        );
                        $this->session->set_flashdata("alert", $alert);
                        redirect(base_url('sifremi-unuttum'));
                        die();
                    }

                    $token_row = $this->destek_model->token(array('kullanici_id' => $kullanicises->kullanici_id));
                    $token = openssl_random_pseudo_bytes(50);
                    $token = bin2hex($token);

                    if ($token_row) {
                        $token_update = $this->destek_model->token_update(array('kullanici_id' => $kullanicises->kullanici_id), array("token"     =>     $token, "token_update" => date('Y-m-d H:i:s', time())));
                    } else {
                        $token_add = $this->destek_model->token_add(array('kullanici_id' => $kullanicises->kullanici_id, 'token' => $token));
                    }

                    $SMTP_HOST = $siteayar->smtp_host;
                    $SMTP_USER = $siteayar->smtp_mail;
                    $SMTP_PASS = $siteayar->smtp_sifre;
                    $SMTP_PORT = $siteayar->smtp_port;
                    $SMTP_GO = $siteayar->smtp_gomail;
                    $alan = $kullanicises->kullanici_mail;
                    $konu = "Şifre Sıfırlama Bağlantısı";

                    $this->load->library('email');

                    $config['protocol']  = 'smtp';
                    $config['smtp_host'] = $SMTP_HOST;
                    $config['smtp_user'] = $SMTP_USER;
                    $config['smtp_pass'] = $SMTP_PASS;
                    $config['smtp_port'] = $SMTP_PORT;
                    $config['smtp_crypto'] = 'ssl';
                    $config['mailtype']  = 'html';
                    $config['charset'] = 'utf-8';

                    $this->email->initialize($config);

                    $this->email->from("$SMTP_USER", "Şifre Sıfırlama Bağlantısı");
                    $this->email->to($alan);
                    $this->email->subject($konu);
                    $this->email->message('<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html dir="ltr" xmlns="http://www.w3.org/1999/xhtml" xmlns:o="urn:schemas-microsoft-com:office:office" lang="tr" style="padding:0;Margin:0">
 <head>
  <meta charset="UTF-8">
  <meta content="width=device-width, initial-scale=1" name="viewport">
  <meta name="x-apple-disable-message-reformatting">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta content="telephone=no" name="format-detection">
  <title>New email template 2024-01-15</title><!--[if (mso 16)]>
    <style type="text/css">
    a {text-decoration: none;}
    </style>
    <![endif]--><!--[if gte mso 9]><style>sup { font-size: 100% !important; }</style><![endif]--><!--[if gte mso 9]>
<xml>
    <o:OfficeDocumentSettings>
    <o:AllowPNG></o:AllowPNG>
    <o:PixelsPerInch>96</o:PixelsPerInch>
    </o:OfficeDocumentSettings>
</xml>
<![endif]-->
  <style type="text/css">
#outlook a {
	padding:0;
}
.ExternalClass {
	width:100%;
}
.ExternalClass,
.ExternalClass p,
.ExternalClass span,
.ExternalClass font,
.ExternalClass td,
.ExternalClass div {
	line-height:100%;
}
.es-button {
	mso-style-priority:100!important;
	text-decoration:none!important;
}
a[x-apple-data-detectors] {
	color:inherit!important;
	text-decoration:none!important;
	font-size:inherit!important;
	font-family:inherit!important;
	font-weight:inherit!important;
	line-height:inherit!important;
}
.es-desk-hidden {
	display:none;
	float:left;
	overflow:hidden;
	width:0;
	max-height:0;
	line-height:0;
	mso-hide:all;
}
.es-button-border:hover a.es-button, .es-button-border:hover button.es-button {
	background:#ffffff!important;
}
.es-button-border:hover {
	background:#ffffff!important;
	border-style:solid solid solid solid!important;
	border-color:#3d5ca3 #3d5ca3 #3d5ca3 #3d5ca3!important;
}
@media only screen and (max-width:600px) {p, ul li, ol li, a { line-height:150%!important } h1, h2, h3, h1 a, h2 a, h3 a { line-height:120%!important } h1 { font-size:20px!important; text-align:center } h2 { font-size:16px!important; text-align:left } h3 { font-size:20px!important; text-align:center } .es-header-body h1 a, .es-content-body h1 a, .es-footer-body h1 a { font-size:20px!important } h2 a { text-align:left } .es-header-body h2 a, .es-content-body h2 a, .es-footer-body h2 a { font-size:16px!important } .es-header-body h3 a, .es-content-body h3 a, .es-footer-body h3 a { font-size:20px!important } .es-menu td a { font-size:14px!important } .es-header-body p, .es-header-body ul li, .es-header-body ol li, .es-header-body a { font-size:10px!important } .es-content-body p, .es-content-body ul li, .es-content-body ol li, .es-content-body a { font-size:16px!important } .es-footer-body p, .es-footer-body ul li, .es-footer-body ol li, .es-footer-body a { font-size:12px!important } .es-infoblock p, .es-infoblock ul li, .es-infoblock ol li, .es-infoblock a { font-size:12px!important } *[class="gmail-fix"] { display:none!important } .es-m-txt-c, .es-m-txt-c h1, .es-m-txt-c h2, .es-m-txt-c h3 { text-align:center!important } .es-m-txt-r, .es-m-txt-r h1, .es-m-txt-r h2, .es-m-txt-r h3 { text-align:right!important } .es-m-txt-l, .es-m-txt-l h1, .es-m-txt-l h2, .es-m-txt-l h3 { text-align:left!important } .es-m-txt-r img, .es-m-txt-c img, .es-m-txt-l img { display:inline!important } .es-button-border { display:block!important } a.es-button, button.es-button { font-size:14px!important; display:block!important; border-left-width:0px!important; border-right-width:0px!important } .es-btn-fw { border-width:10px 0px!important; text-align:center!important } .es-adaptive table, .es-btn-fw, .es-btn-fw-brdr, .es-left, .es-right { width:100%!important } .es-content table, .es-header table, .es-footer table, .es-content, .es-footer, .es-header { width:100%!important; max-width:600px!important } .es-adapt-td { display:block!important; width:100%!important } .adapt-img { width:100%!important; height:auto!important } .es-m-p0 { padding:0px!important } .es-m-p0r { padding-right:0px!important } .es-m-p0l { padding-left:0px!important } .es-m-p0t { padding-top:0px!important } .es-m-p0b { padding-bottom:0!important } .es-m-p20b { padding-bottom:20px!important } .es-mobile-hidden, .es-hidden { display:none!important } tr.es-desk-hidden, td.es-desk-hidden, table.es-desk-hidden { width:auto!important; overflow:visible!important; float:none!important; max-height:inherit!important; line-height:inherit!important } tr.es-desk-hidden { display:table-row!important } table.es-desk-hidden { display:table!important } td.es-desk-menu-hidden { display:table-cell!important } .es-menu td { width:1%!important } table.es-table-not-adapt, .esd-block-html table { width:auto!important } table.es-social { display:inline-block!important } table.es-social td { display:inline-block!important } .es-desk-hidden { display:table-row!important; width:auto!important; overflow:visible!important; max-height:inherit!important } }
@media screen and (max-width:384px) {.mail-message-content { width:414px!important } }
</style>
 </head>
 <body style="width:100%;padding:0;Margin:0">
  <div dir="ltr" class="es-wrapper-color" lang="tr" style="background-color:#FAFAFA"><!--[if gte mso 9]>
			<v:background xmlns:v="urn:schemas-microsoft-com:vml" fill="t">
				<v:fill type="tile" color="#fafafa"></v:fill>
			</v:background>
		<![endif]-->
   <table class="es-wrapper" width="100%" cellspacing="0" cellpadding="0" role="none" style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;padding:0;Margin:0;width:100%;height:100%;background-repeat:repeat;background-position:center top;background-color:#FAFAFA">
     <tr style="border-collapse:collapse">
      <td valign="top" style="padding:0;Margin:0">
       <table cellpadding="0" cellspacing="0" class="es-content" align="center" role="none" style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;table-layout:fixed !important;width:100%">
         <tr style="border-collapse:collapse">
          <td class="es-adaptive" align="center" style="padding:0;Margin:0">
           <table class="es-content-body" style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;background-color:transparent;width:600px" cellspacing="0" cellpadding="0" bgcolor="#ffffff" align="center" role="none">
             <tr style="border-collapse:collapse">
              <td align="left" style="padding:10px;Margin:0">
               <table width="100%" cellspacing="0" cellpadding="0" role="none" style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px">
                 <tr style="border-collapse:collapse">
                  <td valign="top" align="center" style="padding:0;Margin:0;width:580px">
                   <table width="100%" cellspacing="0" cellpadding="0" role="presentation" style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px">
                     <tr style="border-collapse:collapse">
                      <td align="center" class="es-infoblock" style="padding:0;Margin:0;line-height:14px;font-size:12px;color:#CCCCCC"><p style="Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;line-height:14px;color:#CCCCCC;font-size:12px">Put your preheader text here. <a href="https://viewstripo.email" class="view" target="_blank" style="-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;text-decoration:none;color:#CCCCCC;font-size:12px">View in browser</a></p></td>
                     </tr>
                   </table></td>
                 </tr>
               </table></td>
             </tr>
           </table></td>
         </tr>
       </table>
       <table cellpadding="0" cellspacing="0" class="es-header" align="center" role="none" style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;table-layout:fixed !important;width:100%;background-color:transparent;background-repeat:repeat;background-position:center top">
         <tr style="border-collapse:collapse">
          <td class="es-adaptive" align="center" style="padding:0;Margin:0">
           <table class="es-header-body" style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;background-color:#3d5ca3;width:600px" cellspacing="0" cellpadding="0" bgcolor="#3d5ca3" align="center" role="none">
             <tr style="border-collapse:collapse">
              <td style="Margin:0;padding-top:20px;padding-bottom:20px;padding-left:20px;padding-right:20px;background-color:#1c2438" bgcolor="#1C2438" align="left"><!--[if mso]><table style="width:560px" cellpadding="0" 
                        cellspacing="0"><tr><td style="width:270px" valign="top"><![endif]-->
               <table class="es-left" cellspacing="0" cellpadding="0" align="left" role="none" style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;float:left">
                 <tr style="border-collapse:collapse">
                  <td class="es-m-p20b" align="left" style="padding:0;Margin:0;width:270px">
                   <table width="100%" cellspacing="0" cellpadding="0" role="presentation" style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px">
                     <tr style="border-collapse:collapse">
                      <td class="es-m-p0l es-m-txt-c" align="left" style="padding:0;Margin:0;font-size:0px"><a href="https://viewstripo.email" target="_blank" style="-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;text-decoration:none;color:#1376C8;font-size:14px"><img src="'.base_url($siteayar->site_logo).'" alt style="display:block;border:0;outline:none;text-decoration:none;-ms-interpolation-mode:bicubic" width="183"></a></td>
                     </tr>
                   </table></td>
                 </tr>
               </table><!--[if mso]></td><td style="width:20px"></td><td style="width:270px" valign="top"><![endif]-->
               <table class="es-right" cellspacing="0" cellpadding="0" align="right" role="none" style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;float:right">
                 <tr style="border-collapse:collapse">
                  <td align="left" style="padding:0;Margin:0;width:270px">
                   <table width="100%" cellspacing="0" cellpadding="0" role="presentation" style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px">
                     <tr style="border-collapse:collapse">
                      <td class="es-m-txt-c" align="right" style="padding:0;Margin:0;padding-top:10px"><span class="es-button-border" style="border-style:solid;border-color:#3D5CA3;background:#FFFFFF;border-width:2px;display:inline-block;border-radius:10px;width:auto"><a href="https://kemalellidort.com.tr/" class="es-button" target="_blank" style="mso-style-priority:100 !important;text-decoration:none;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;color:#3D5CA3;font-size:14px;display:inline-block;background:#FFFFFF;border-radius:10px;font-weight:bold;font-style:normal;line-height:17px;width:auto;text-align:center;padding:15px 20px 15px 20px;mso-padding-alt:0;mso-border-alt:10px solid #FFFFFF">Şifre Sıfırlama Talebi</a></span></td>
                     </tr>
                   </table></td>
                 </tr>
               </table><!--[if mso]></td></tr></table><![endif]--></td>
             </tr>
           </table></td>
         </tr>
       </table>
       <table class="es-content" cellspacing="0" cellpadding="0" align="center" role="none" style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;table-layout:fixed !important;width:100%">
         <tr style="border-collapse:collapse">
          <td style="padding:0;Margin:0;background-color:#fafafa" bgcolor="#fafafa" align="center">
           <table class="es-content-body" style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;background-color:#ffffff;width:600px" cellspacing="0" cellpadding="0" bgcolor="#ffffff" align="center" role="none">
             <tr style="border-collapse:collapse">
              <td style="padding:0;Margin:0;padding-left:20px;padding-right:20px;padding-top:40px;background-color:transparent;background-position:left top" bgcolor="transparent" align="left">
               <table width="100%" cellspacing="0" cellpadding="0" role="none" style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px">
                 <tr style="border-collapse:collapse">
                  <td valign="top" align="center" style="padding:0;Margin:0;width:560px">
                   <table style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;background-position:left top" width="100%" cellspacing="0" cellpadding="0" role="presentation">
                     <tr style="border-collapse:collapse">
                      <td align="center" style="padding:0;Margin:0;padding-top:5px;padding-bottom:5px;font-size:0"><img src="https://phtqvn.stripocdn.email/content/guids/CABINET_dd354a98a803b60e2f0411e893c82f56/images/23891556799905703.png" alt style="display:block;border:0;outline:none;text-decoration:none;-ms-interpolation-mode:bicubic" width="175"></td>
                     </tr>
                     <tr style="border-collapse:collapse">
                      <td align="center" style="padding:0;Margin:0;padding-top:15px;padding-bottom:15px"><h1 style="Margin:0;line-height:24px;mso-line-height-rule:exactly;font-size:20px;font-style:normal;font-weight:normal;color:#333333"><b>Şifrenizi mi Unuttunuz ?</b></h1></td>
                     </tr>
                     <tr style="border-collapse:collapse">
                      <td align="center" style="padding:0;Margin:0;padding-top:25px;padding-left:40px;padding-right:40px"><p style="Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;line-height:24px;color:#666666;font-size:16px">Şifrenizi sıfırlamak için aşağıda ki bağlantıya tıklıyabilirsiniz. Eğer bu bağlantıyı siz göndermediyseniz bizim ile iletişime geçiniz ve tıklamayınız.</p></td>
                     </tr>
                     <tr style="border-collapse:collapse">
                      <td align="center" style="Margin:0;padding-left:10px;padding-right:10px;padding-top:40px;padding-bottom:40px"><span class="es-button-border" style="border-style:solid;border-color:#3D5CA3;background:#FFFFFF;border-width:2px;display:inline-block;border-radius:10px;width:auto"><a href="'.base_url('sifre-yenile/' . $token).'" class="es-button" target="_blank" style="mso-style-priority:100 !important;text-decoration:none;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;color:#3D5CA3;font-size:14px;display:inline-block;background:#FFFFFF;border-radius:10px;font-weight:bold;font-style:normal;line-height:17px;width:auto;text-align:center;padding:15px 20px 15px 20px;mso-padding-alt:0;mso-border-alt:10px solid #FFFFFF">Sıfırla</a></span></td>
                     </tr>
                   </table></td>
                 </tr>
               </table></td>
             </tr>
             <tr style="border-collapse:collapse">
              <td style="padding:0;Margin:0;padding-left:10px;padding-right:10px;padding-top:20px;background-position:center center" align="left"><!--[if mso]><table style="width:580px" cellpadding="0" cellspacing="0"><tr><td style="width:199px" valign="top"><![endif]-->
               <table class="es-left" cellspacing="0" cellpadding="0" align="left" role="none" style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;float:left">
                 <tr style="border-collapse:collapse">
                  <td align="left" style="padding:0;Margin:0;width:199px">
                   <table style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;background-position:center center" width="100%" cellspacing="0" cellpadding="0" role="presentation">
                     <tr style="border-collapse:collapse">
                      <td class="es-m-txt-c" align="right" style="padding:0;Margin:0;padding-top:15px"><p style="Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;line-height:24px;color:#666666;font-size:16px"><strong>Takip Et:</strong></p></td>
                     </tr>
                   </table></td>
                 </tr>
               </table><!--[if mso]></td><td style="width:20px"></td><td style="width:361px" valign="top"><![endif]-->
               <table class="es-right" cellspacing="0" cellpadding="0" align="right" role="none" style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;float:right">
                 <tr style="border-collapse:collapse">
                  <td align="left" style="padding:0;Margin:0;width:361px">
                   <table style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;background-position:center center" width="100%" cellspacing="0" cellpadding="0" role="presentation">
                     <tr style="border-collapse:collapse">
                      <td class="es-m-txt-c" align="left" style="padding:0;Margin:0;padding-bottom:5px;padding-top:10px;font-size:0">
                       <table class="es-table-not-adapt es-social" cellspacing="0" cellpadding="0" role="presentation" style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px">
                         <tr style="border-collapse:collapse">
                          <td valign="top" align="center" style="padding:0;Margin:0;padding-right:10px"><a href="'.$siteayar->facebook.'"><img src="https://phtqvn.stripocdn.email/content/assets/img/social-icons/rounded-gray/facebook-rounded-gray.png" alt="Fb" title="Facebook" width="32" style="display:block;border:0;outline:none;text-decoration:none;-ms-interpolation-mode:bicubic"></a></td>
                          <td valign="top" align="center" style="padding:0;Margin:0;padding-right:10px"><a href="'.$siteayar->twitter.'"><img src="https://phtqvn.stripocdn.email/content/assets/img/social-icons/rounded-gray/twitter-rounded-gray.png" alt="Tw" title="Twitter" width="32" style="display:block;border:0;outline:none;text-decoration:none;-ms-interpolation-mode:bicubic"></a></td>
                          <td valign="top" align="center" style="padding:0;Margin:0;padding-right:10px"><a href="'.$siteayar->instagram.'"><img src="https://phtqvn.stripocdn.email/content/assets/img/social-icons/rounded-gray/instagram-rounded-gray.png" alt="Ig" title="Instagram" width="32" style="display:block;border:0;outline:none;text-decoration:none;-ms-interpolation-mode:bicubic"></a></td>
                         </tr>
                       </table></td>
                     </tr>
                   </table></td>
                 </tr>
               </table><!--[if mso]></td></tr></table><![endif]--></td>
             </tr>
             <tr style="border-collapse:collapse">
              <td style="Margin:0;padding-top:5px;padding-bottom:20px;padding-left:20px;padding-right:20px;background-position:left top" align="left">
               <table width="100%" cellspacing="0" cellpadding="0" role="none" style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px">
                 <tr style="border-collapse:collapse">
                  <td valign="top" align="center" style="padding:0;Margin:0;width:560px">
                   <table width="100%" cellspacing="0" cellpadding="0" role="presentation" style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px">
                     <tr style="border-collapse:collapse">
                      <td align="center" style="padding:0;Margin:0"><p style="Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;line-height:24px;color:#666666;font-size:14px">İletişim: <a target="_blank" style="-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;text-decoration:none;color:#666666;font-size:14px" href="tel:'.$siteayar->iletisim_tel.'"></a><a href="tel:'.$siteayar->iletisim_tel.'" style="-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;text-decoration:none;color:#0B5394;font-size:16px">'.$siteayar->iletisim_tel.'</a><a target="_blank" style="-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;text-decoration:none;color:#666666;font-size:14px" href="tel:'.$siteayar->iletisim_tel.'"></a> | <a target="_blank" href="mailto:'.$siteayar->iletisim_mail.'" style="-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;text-decoration:none;color:#666666;font-size:14px">'.$siteayar->iletisim_mail.'</a></p></td>
                     </tr>
                   </table></td>
                 </tr>
               </table></td>
             </tr>
           </table></td>
         </tr>
       </table>
       <table class="es-footer" cellspacing="0" cellpadding="0" align="center" role="none" style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;table-layout:fixed !important;width:100%;background-color:transparent;background-repeat:repeat;background-position:center top">
         <tr style="border-collapse:collapse">
          <td style="padding:0;Margin:0;background-color:#fafafa" bgcolor="#fafafa" align="center">
           <table class="es-footer-body" cellspacing="0" cellpadding="0" bgcolor="#ffffff" align="center" role="none" style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;background-color:transparent;width:600px">
             <tr style="border-collapse:collapse">
              <td style="Margin:0;padding-top:10px;padding-left:20px;padding-right:20px;padding-bottom:30px;background-color:#1c2438" bgcolor="#1c2438" align="left">
               <table width="100%" cellspacing="0" cellpadding="0" role="none" style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px">
                 <tr style="border-collapse:collapse">
                  <td valign="top" align="center" style="padding:0;Margin:0;width:560px">
                   <table width="100%" cellspacing="0" cellpadding="0" role="presentation" style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px">
                     <tr style="border-collapse:collapse">
                      <td align="left" style="padding:0;Margin:0;padding-top:5px;padding-bottom:5px"><h2 style="Margin:0;line-height:19px;mso-line-height-rule:exactly;font-size:16px;font-style:normal;font-weight:normal;color:#ffffff"><strong>Bir Sorunuz mu var ?</strong></h2></td>
                     </tr>
                     <tr style="border-collapse:collapse">
                      <td align="left" style="padding:0;Margin:0;padding-bottom:5px"><p style="Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;line-height:21px;color:#ffffff;font-size:14px">Bizim ile iletişime geçerek aklınız takılan her soruya cevap alabilirsiniz.</p></td>
                     </tr>
                   </table></td>
                 </tr>
               </table></td>
             </tr>
           </table></td>
         </tr>
       </table>
       <table class="es-content" cellspacing="0" cellpadding="0" align="center" role="none" style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;table-layout:fixed !important;width:100%">
         <tr style="border-collapse:collapse">
          <td style="padding:0;Margin:0;background-color:#fafafa" bgcolor="#fafafa" align="center">
           <table class="es-content-body" style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;background-color:transparent;width:600px" cellspacing="0" cellpadding="0" bgcolor="transparent" align="center" role="none">
             <tr style="border-collapse:collapse">
              <td style="padding:0;Margin:0;padding-top:15px;background-position:left top" align="left">
               <table width="100%" cellspacing="0" cellpadding="0" role="none" style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px">
                 <tr style="border-collapse:collapse">
                  <td valign="top" align="center" style="padding:0;Margin:0;width:600px">
                   <table width="100%" cellspacing="0" cellpadding="0" role="presentation" style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px">
                     <tr style="border-collapse:collapse">
                      <td style="padding:0;Margin:0">
                       <table class="es-menu" width="100%" cellspacing="0" cellpadding="0" role="presentation" style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px">
                         <tr class="links" style="border-collapse:collapse">
                          <td style="Margin:0;padding-left:5px;padding-right:5px;padding-top:0px;padding-bottom:1px;border:0" id="esd-menu-id-0" width="33.33%" valign="top" bgcolor="transparent" align="center"><a target="_blank" href="https://kemalellidort.com.tr/giris-yap" style="-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;text-decoration:none;display:block;color:#3D5CA3;font-size:14px">Giriş Yap</a></td>
                          <td style="Margin:0;padding-left:5px;padding-right:5px;padding-top:0px;padding-bottom:1px;border:0;border-left:1px solid #3d5ca3" id="esd-menu-id-1" esdev-border-color="#3d5ca3" width="33.33%" valign="top" bgcolor="transparent" align="center"><a target="_blank" href="https://kemalellidort.com.tr/blog/" style="-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;text-decoration:none;display:block;color:#3D5CA3;font-size:14px">Blog</a></td>
                          <td style="Margin:0;padding-left:5px;padding-right:5px;padding-top:0px;padding-bottom:1px;border:0;border-left:1px solid #3d5ca3" id="esd-menu-id-2" esdev-border-color="#3d5ca3" width="33.33%" valign="top" bgcolor="transparent" align="center"><a target="_blank" href="https://kemalellidort.com.tr/sayfa/hakkimizda" style="-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;text-decoration:none;display:block;color:#3D5CA3;font-size:14px">Hakkımızda</a></td>
                         </tr>
                       </table></td>
                     </tr>
                     <tr style="border-collapse:collapse">
                      <td align="center" style="padding:0;Margin:0;padding-bottom:20px;padding-left:20px;padding-right:20px;font-size:0">
                       <table width="100%" height="100%" cellspacing="0" cellpadding="0" border="0" role="presentation" style="mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px">
                         <tr style="border-collapse:collapse">
                          <td style="padding:0;Margin:0;border-bottom:1px solid #fafafa;background:none;height:1px;width:100%;margin:0px"></td>
                         </tr>
                       </table></td>
                     </tr>
                   </table></td>
                 </tr>
               </table></td>
             </tr>
           </table></td>
         </tr>
       </table></td>
     </tr>
   </table>
  </div>
 </body>
</html>');
                    // ' . base_url('sifre-yenile/' . $token) . '
                    if (!$this->email->send()) {
                        prex($this->email->print_debugger());
                        $alert = array(
                            "title" =>     "Hata!",
                            "text" =>     "Şifre Bağlantısı E-Posta Adresinize Gönderilemedi!",
                            "type"  =>     "error"
                        );

                        $this->session->set_flashdata("alert", $alert);

                        redirect($_SERVER['HTTP_REFERER']);
                    } else {

                        $alert = array(
                            "title" =>     "Başarılı!",
                            "text" =>     "Yeni Şifre Bağlantınız E-Posta Adresinize Gönderildi",
                            "type"  =>     "success"
                        );

                        $this->session->set_flashdata("alert", $alert);

                        redirect(base_url());
                    }
                }
            } else {
                if (aktif_kullanici()) {
                    redirect(base_url());
                    die();
                }

                $data = new stdClass();

                $siteayar = ayarlar();

                $data->title = "Şifremi Unuttum?";
                $data->description = "";
                $data->keywords = "";
                $data->google_key = $siteayar->google_key;
                $data->form_error = true;
                $data->ayarlar = $siteayar;
                $data->kullanici = kullanicicek();


                $this->load->view('inc/_header', $data);
                $this->load->view('auth/password', $data);
                $this->load->view('inc/_footer', $data);
            }
        } else {

            $alert = array(
                "title" =>     "Hata!",
                "text" =>     "Lütfen Bot Olmadığınızı Doğrulayın!",
                "type"  =>     "error"
            );

            $this->session->set_flashdata("alert", $alert);
            redirect($_SERVER['HTTP_REFERER']);
        }
    }

    public function sifre_yenile($token)
    {

        if (aktif_kullanici()) {
            redirect(base_url());
            die();
        }

        $tokens = $this->destek_model->token(array('token' => $token));

        if (!$tokens) {
            redirect(base_url());
            die();
        }

        $kullanici = $this->yonetim_model->get(array('kullanici_id' => $tokens->kullanici_id));

        if (!$kullanici) {
            redirect(base_url());
            die();
        }

        $data = new stdClass();

        $siteayar = ayarlar();

        $data->title = 'Şifre Yenile';
        $data->description = "";
        $data->keywords = "";
        $data->kullanici = $kullanici;
        $data->token = $token;
        $data->ayarlar = $siteayar;


        $this->load->view('inc/_header', $data);
        $this->load->view('auth/yeni-sifre', $data);
        $this->load->view('inc/_footer', $data);
    }

    public function sifre_yenile_post()
    {
        $sifre         = $this->input->post('password');
        $sifretkr     = $this->input->post('repassword');
        $token         = $this->input->post('tkn');

        if ($sifre != $sifretkr) {
            $alert = array(
                "title" =>     "Hata!",
                "text" =>     "Şifreler Uyuşmuyor!",
                "type"  =>     "error"
            );
            $this->session->set_flashdata("alert", $alert);
            redirect($_SERVER['HTTP_REFERER']);
            die();
        }

        if (strlen($sifre) < 6) {
            $alert = array(
                "title" =>     "Hata!",
                "text" =>     "Şifreniz Minimum 6 Karakter Olmalı!",
                "type"  =>     "error"
            );
            $this->session->set_flashdata("alert", $alert);
            redirect($_SERVER['HTTP_REFERER']);
            die();
        }

        $token_row = $this->destek_model->token(array('token' => $token));
        $kullanici_update = $this->yonetim_model->update(
            array('kullanici_id' => $token_row->kullanici_id),
            array('kullanici_sifre' => htmlspecialchars(password_hash($sifre, PASSWORD_DEFAULT)))
        );
        $token_del  = $this->destek_model->token_delete(array('token' => $token));


        $alert = array(
            "title" =>     "Başarılı!",
            "text" =>     "Yeni Şifreniz ile Giriş Yapabilirsiniz!",
            "type"  =>     "success"
        );

        $this->session->set_flashdata("alert", $alert);

        redirect(base_url());
    }
}
