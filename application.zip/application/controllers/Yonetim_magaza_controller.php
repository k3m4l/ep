<?php

use Anilken\Turkpin\Turkpin;
use Turkpin as GlobalTurkpin;

defined('BASEPATH') or exit('No direct script access allowed');

class yonetim_magaza_controller extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        date_default_timezone_set('Europe/Istanbul');
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }
    }

    /**
     * Mağaza İşlemleri
     */
    
     public function bayiler()
     {
         $data = new stdClass();
         $siteayar = ayarlar();

         $data->title = $siteayar->site_baslik;
         $data->description = $siteayar->site_aciklama;
         $data->keywords = $siteayar->site_keyw;
         $data->bayiler = $this->yonetim_magaza_model->bayiler(['durum' => 0]);
         $this->load->view('yonetim/inc/_header', $data);
         $this->load->view('yonetim/bayilik/bayiler', $data);
         $this->load->view('yonetim/inc/_footer');
     }

    public function tum_bayiler()
    {
        $data = new stdClass();
        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;
        $data->bayiler = $this->yonetim_magaza_model->bayiler(['durum' => 1]);
        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/bayilik/bayiler', $data);
        $this->load->view('yonetim/inc/_footer');
    }
     public function bayilik_basvuru_islem($basvuru_id,$durum)
     {
         $update = $this->yonetim_magaza_model->basvuru_update(array('id'=>$basvuru_id),array('durum'=>$durum));
 
         if ($update) {
             redirect(base_url(admin_url() . "bayiler"));
         } else {
             redirect(base_url(admin_url() . "bayiler"));
         }
     }
     public function bayilik_basvuru_sil($basvuru_id)
     {
         $update = $this->yonetim_magaza_model->basvuru_sil(array('id'=>$basvuru_id));
 
         if ($update) {
             redirect(base_url(admin_url() . "bayiler"));
         } else {
             redirect(base_url(admin_url() . "bayiler"));
         }
     }

    public function sponsorlar()
    {
        $data = new stdClass();
        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;
        $data->sponsorlar = $this->yonetim_magaza_model->sponsorlar(['durum' => 0]);
        $res = [];

        foreach ($data->sponsorlar as $data) {
            $res[] = (object)[
                'id' => $data->id,
                'kullanici_id' => $data->kullanici_id,
                'durum' => $data->durum,
                'isim' => $data->isim,
                'soyisim' => $data->soyisim,
                'tc' => $data->tc,
                'dogum_tarihi' => $data->dogum_tarihi,
                'kategoriler' => array_map(function ($kategori) {
                    return $kategori->kategori_ad;
                }, $this->db->select('kategori_ad')->where_in('kategori_id', explode(',', $data->kats))->order_by('kategori_id', 'desc')->get("kategori")->result())
            ];
        }

        $data->sponsorlar = $res;
        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/sponsor/sponsorlar', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function tum_sponsorlar()
    {
        $data = new stdClass();
        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;
        $data->sponsorlar = $this->yonetim_magaza_model->sponsorlar(['durum' => 1]);
        $res = [];

        foreach ($data->sponsorlar as $data) {
            $res[] = (object)[
                'id' => $data->id,
                'kullanici_id' => $data->kullanici_id,
                'durum' => $data->durum,
                'isim' => $data->isim,
                'soyisim' => $data->soyisim,
                'tc' => $data->tc,
                'dogum_tarihi' => $data->dogum_tarihi,
                'kategoriler' => array_map(function ($kategori) {
                    return $kategori->kategori_ad;
                }, $this->db->select('kategori_ad')->where_in('kategori_id', explode(',', $data->kats))->order_by('kategori_id', 'desc')->get("kategori")->result())
            ];
        }

        $data->sponsorlar = $res;
        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/sponsor/sponsorlar', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function magazalar()
    {
        $data = new stdClass();
        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;
        $data->magazalar = $this->yonetim_magaza_model->magazalar();

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/magaza/magazalar', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function magaza_duzenle($magaza_id)
    {
        $data = new stdClass();

        $where = $this->yonetim_magaza_model->magaza(array("magaza_id" => $magaza_id));

        if (!$where) {
            redirect(base_url(admin_url() . 'magazalar'));
            die();
        }

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;
        $data->magaza = $where;
        $data->iller = $this->yonetim_magaza_model->iller();
        $data->ilceler = $this->yonetim_magaza_model->ilceler();


        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/magaza/magaza-duzenle', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function magazaduzenle($magaza_uniq)
    {

        $magazaduzenle = $this->input->post("magazaduzenle");

        $magaza = $this->yonetim_magaza_model->magaza(array("magaza_uniq" => $magaza_uniq));

        if (!$magaza) {
            redirect(base_url(admin_url() . 'magazalar'));
            die();
        }


        if ($magazaduzenle == 1){
            $file_name = seo(pathinfo($_FILES["file"]["name"], PATHINFO_FILENAME)) . "." . pathinfo($_FILES["file"]["name"], PATHINFO_EXTENSION);
            $sifrele = uniqid();
            $config["allowed_types"] = "jpg|jpeg|png";
            $config["upload_path"] = "uploads/img/";
            $config['encrypt_name'] = TRUE;
            //$config["file_name"] = $sifrele . "_" . $file_name;

            $this->load->library("upload", $config);

            $upload = $this->upload->do_upload("file");

            $uploaded_file = $this->upload->data("file_name");

            if ($upload) {
                $insert = $this->yonetim_magaza_model->magaza_update(
                    array("magaza_uniq" => $magaza_uniq),
                    array(
                        "magaza_resim" => "uploads/img/" . $uploaded_file,
                        "magaza_ad" => htmlspecialchars($this->input->post("ad")),
                        "magaza_seo" => htmlspecialchars(seo($this->input->post("seo"))),
                        "magaza_durum" => htmlspecialchars($this->input->post("durum")),
                        "magaza_iptal" => htmlspecialchars($this->input->post("magaza_iptal")),
                        "magaza_dogrulama" => htmlspecialchars($this->input->post("rozet")),
                        "magaza_tur" => htmlspecialchars($this->input->post("magaza_turu")),
                        "isim" => htmlspecialchars($this->input->post("isim")),
                        "soyisim" => htmlspecialchars($this->input->post("soyisim")),
                        "telefon" => htmlspecialchars($this->input->post("phone")),
                        "tc" => $this->input->post("tc"),
                        "dogum_tarihi" => $this->input->post("dogum_tarihi"),
                        "fatura_adres" => htmlspecialchars($this->input->post("fatura_adres")),
                        "sehir" => htmlspecialchars($this->input->post("sehir")),
                        "ilce" => htmlspecialchars($this->input->post("ilce")),
                        "magaza_hakkinda" => htmlspecialchars($this->input->post("hakkinda")),
                    )
                );
            } else {
                $insert = $this->yonetim_magaza_model->magaza_update(
                    array("magaza_uniq" => $magaza_uniq),
                    array(
                        "magaza_ad" => htmlspecialchars($this->input->post("ad")),
                        "magaza_seo" => htmlspecialchars(seo($this->input->post("seo"))),
                        "magaza_durum" => htmlspecialchars($this->input->post("durum")),
                        "magaza_iptal" => htmlspecialchars($this->input->post("magaza_iptal")),
                        "magaza_dogrulama" => htmlspecialchars($this->input->post("rozet")),
                        "magaza_tur" => htmlspecialchars($this->input->post("magaza_turu")),
                        "isim" => htmlspecialchars($this->input->post("isim")),
                        "soyisim" => htmlspecialchars($this->input->post("soyisim")),
                        "telefon" => htmlspecialchars($this->input->post("phone")),
                        "tc" => $this->input->post("tc"),
                        "dogum_tarihi" => $this->input->post("dogum_tarihi"),
                        "fatura_adres" => htmlspecialchars($this->input->post("fatura_adres")),
                        "sehir" => htmlspecialchars($this->input->post("sehir")),
                        "ilce" => htmlspecialchars($this->input->post("ilce")),
                        "magaza_hakkinda" => htmlspecialchars($this->input->post("hakkinda")),
                    )
                );
            }

            $alert = array(
                "title" => "İşlem Başarılı",
                "text" => "Mağaza Başarılı Şekilde Güncellendi",
                "type" => "success"
            );

            $this->session->set_flashdata("alert", $alert);
            redirect(base_url(admin_url() . 'magaza-duzenle/' . $magaza->magaza_id));
        }else{
            if ($_FILES["file"]["name"]) {
                $file_name = seo(pathinfo($_FILES["file"]["name"], PATHINFO_FILENAME)) . "." . pathinfo($_FILES["file"]["name"], PATHINFO_EXTENSION);
                $sifrele = uniqid();
                $config["allowed_types"] = "jpg|jpeg|png";
                $config["upload_path"] = "uploads/kategori/rand/";
                $config['encrypt_name'] = TRUE;
                //$config["file_name"] = $sifrele . "_" . $file_name;

                $this->load->library("upload", $config);

                $upload = $this->upload->do_upload("file");

                if ($upload) {

                    $uploaded_file = $this->upload->data("file_name");
                    $this->yonetim_model->kategoriupdate(
                        array("kategori_id" => $katid),
                        array(
                            "kategori_resim_rand" => "uploads/kategori/rand/" . $uploaded_file,

                        )
                    );

                    $alert = array(
                        "title" => "İşlem Başarılı",
                        "text" => "Kategori Başarılı Şekilde Güncellendi",
                        "type" => "success"
                    );
                    $this->session->set_flashdata("alert", $alert);
                    redirect(base_url(admin_url() . "kategoriler"));
                    die();
                } else {

                    $alert = array(
                        "title" => "İşlem Başarısız",
                        "text" => "Fotoğraf Yüklenemedi!",
                        "type" => "error"
                    );

                    $this->session->set_flashdata("alert", $alert);

                    redirect(base_url(admin_url() . "kategoriler"));

                    die();
                }
            }
        }

        die();
    }

    public function magaza_sil($magaza_id)
    {
        $delete = $this->yonetim_magaza_model->magaza_sil(array("magaza_id" => $magaza_id));

        if ($delete) {
            redirect(base_url(admin_url() . "magazalar"));
        } else {
            redirect(base_url(admin_url() . "magazalar"));
        }
    }
    public function sponsor_sil($sponsor_id)
    {
        $delete = $this->yonetim_magaza_model->sponsor_sil(array("id" => $sponsor_id));

        if ($delete) {
            redirect(base_url(admin_url() . "sponsorlar"));
        } else {
            redirect(base_url(admin_url() . "sponsorlar"));
        }
    }

    public function onay_bekleyen_magazalar()
    {
        $data = new stdClass();
        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;
        $data->magazalar = $this->yonetim_magaza_model->magazalar(array('magaza_durum' => 0));

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/magaza/bekleyen-magazalar', $data);
        $this->load->view('yonetim/inc/_footer');
    }
/**
 * Vitrin İşlemleri
 */
    
 public function vitrin_ekle()
 {

     $data = new stdClass();

     $siteayar = ayarlar();

     $data->title = $siteayar->site_baslik;
     $data->description = $siteayar->site_aciklama;
     $data->keywords = $siteayar->site_keyw;


     $this->load->view('yonetim/inc/_header', $data);
     $this->load->view('yonetim/vitrin/vitrin-ekle', $data);
     $this->load->view('yonetim/inc/_footer');
 }


 public function vitrinurun_ekle($vitrin_id)
 {

     $this->load->library("form_validation");
     $this->form_validation->set_rules("urun_id", "Ürün ID", "required|trim|xss_clean");
     $this->form_validation->set_message(
         array("required" => "{field} Boş Bırakılamaz!")
     );

     $validat = $this->form_validation->run();

     if ($validat) {
            
        $data = array(
            "vitrin_id" => $vitrin_id,
            "urun_id" => $this->input->post("urun_id"),
        );

        $insert = $this->magaza_model->vitrinurun_add($data);


        $alert = array(
            "title" => "İşlem Başarılı",
            "text" => "Vitrine Ürün Başarılı Şekilde Eklendi",
            "type" => "success"
        );

        $this->session->set_flashdata("alert", $alert);
        redirect(base_url(admin_url() . "vitrin-detay/".$vitrin_id));
     } else {
        redirect(base_url(admin_url() . "vitrin-detay/".$vitrin_id));
     }
 }



 public function vitrinekle()
 {

     if (!is_dir('uploads/vitrinler/')) {
         mkdir('uploads/vitrinler/', 0777);
     }
     $this->load->library("form_validation");
     $this->form_validation->set_rules("name", "Vitrin Adı", "required|trim|xss_clean");
     $this->form_validation->set_rules("sira", "Vitrin Sırası", "required|trim|xss_clean|numeric");
     $this->form_validation->set_rules("type", "Vitrin Türü", "required|trim|xss_clean");
     $this->form_validation->set_message(
         array("required" => "{field} Boş Bırakılamaz!")
     );

     $validat = $this->form_validation->run();

     if ($validat) {

         if ($_FILES["file"]["name"]) {
             $file_name = seo(pathinfo($_FILES["file"]["name"], PATHINFO_FILENAME)) . "." . pathinfo($_FILES["file"]["name"], PATHINFO_EXTENSION);
             $sifrele = uniqid();
             $config["allowed_types"] = "jpg|jpeg|png";
             $config["upload_path"] = "uploads/vitrinler/";
             $config["file_name"] = $sifrele . "_" . $file_name;
             //$config['encrypt_name'] = TRUE;

             $this->load->library("upload", $config);
             $upload = $this->upload->do_upload("file");
             $kaboom = explode(".", $this->upload->data("file_name"));
             $fileExt = end($kaboom);
             $source_path = 'uploads/vitrinler/' . $this->upload->data("file_name");
             $target_path = 'uploads/vitrinler/' . $this->upload->data("file_name");
             $wmax = 32;
             $hmax = 32;
             resize_img_specific($source_path, $target_path, $wmax, $hmax, $fileExt);

             if ($upload) {

                 $uploaded_file = $this->upload->data("file_name");
                 $data = array(
                     "name" => $this->input->post("name"),
                     "type" => $this->input->post("type"),
                     "sira" => $this->input->post("sira"),
                     "icon" => "uploads/vitrinler/" . $uploaded_file,
                     "contents" => $this->input->post("contents"),
                     "tarih" => date('Y-m-d H:i:s')
                 );

                 $insert = $this->magaza_model->vitrin_add($data);

                 $alert = array(
                     "title" => "İşlem Başarılı",
                     "text" => "Vitrin Başarılı Şekilde Eklendi",
                     "type" => "success"
                 );

                 $this->session->set_flashdata("alert", $alert);
                 redirect(base_url(admin_url() . "vitrinler"));
                 die();
             } else {
                 $alert = array(
                     "title" => "İşlem Başarısız",
                     "text" => "Bir şeyler ters gitti..",
                     "type" => "error"
                 );

                 $this->session->set_flashdata("alert", $alert);
                 redirect(base_url(admin_url() . "vitrin-ekle"));
                 die();
             }
         } else {
             $alert = array(
                 "title" => "İşlem Başarısız",
                 "text" => "Lütfen Vitrin Iconu Seçin!",
                 "type" => "error"
             );
             $this->session->set_flashdata("alert", $alert);
             redirect(admin_url() . base_url("urun-ekle"));
             die();
         }
     } else {
         $data = new stdClass();
         $siteayar = ayarlar();

         $data->title = $siteayar->site_baslik;
         $data->description = $siteayar->site_aciklama;
         $data->keywords = $siteayar->site_keyw;

         $this->load->view('yonetim/inc/_header', $data);
         $this->load->view('yonetim/urun/vitrin-ekle', $data);
         $this->load->view('yonetim/inc/_footer');
     }
 }

 public function vitrinler()
 {
     $data = new stdClass();
     $siteayar = ayarlar();

     $data->title = $siteayar->site_baslik;
     $data->description = $siteayar->site_aciklama;
     $data->keywords = $siteayar->site_keyw;
     $data->vitrinler = $this->db->get('vitrinler')->result();

     $this->load->view('yonetim/inc/_header', $data);
     $this->load->view('yonetim/vitrin/vitrinler', $data);
     $this->load->view('yonetim/inc/_footer');
 }
 public function vitrin_duzenle($id)
{

 $data = new stdClass();
 $siteayar = ayarlar();

 $data->title = $siteayar->site_baslik;
 $data->description = $siteayar->site_aciklama;
 $data->keywords = $siteayar->site_keyw;
 $data->ayarlar = $siteayar;
 
 $data->vitrin = $this->db->where('id', $id)->get('vitrinler')->row();
 
 $this->load->view('yonetim/inc/_header', $data);
 $this->load->view('yonetim/vitrin/vitrin-duzenle', $data);
 $this->load->view('yonetim/inc/_footer');
}

public function vitrinduzenle($id)
{
    $vitrin = $this->db->where('id',$id)->get('vitrinler')->row();
    if ($_FILES["file"]["name"]) {
        $file_name = seo(pathinfo($_FILES["file"]["name"], PATHINFO_FILENAME)) . "." . pathinfo($_FILES["file"]["name"], PATHINFO_EXTENSION);
        $sifrele = uniqid();
        $config["allowed_types"] = "jpg|jpeg|png";
        $config["upload_path"] = "uploads/vitrinler/";
        $config["file_name"] = $sifrele . "_" . $file_name;
        
        if (!is_dir('uploads/vitrinler/'))
            mkdir('uploads/vitrinler/' , 0777);
        $this->load->library("upload", $config);
        $upload = $this->upload->do_upload("file");
        $kaboom = explode(".", $this->upload->data("file_name"));
        $fileExt = end($kaboom);
        $source_path = 'uploads/vitrinler/' . $this->upload->data("file_name");
        $target_path = 'uploads/vitrinler/' . $this->upload->data("file_name");
        $wmax = 32;
        $hmax = 32;
        resize_img_specific($source_path, $target_path, $wmax, $hmax, $fileExt);
        
        if ($upload) {

            $uploaded_file = $this->upload->data("file_name");
            
            $data = array(
                "name" => $this->input->post("name"),
                "type" => $this->input->post("type"),
                "sira" => $this->input->post("sira"),
                "icon" => "uploads/vitrinler/". $uploaded_file,
                "contents" => $this->input->post("contents")
            );

            $insert = $this->magaza_model->vitrin_update(array('id' => $vitrin->id), $data);


            $alert = array(
                "title" => "İşlem Başarılı",
                "text" => "Vitrin Başarılı Şekilde Güncellendi",
                "type" => "success"
            );


            $this->session->set_flashdata("alert", $alert);
            redirect(base_url(admin_url() . "vitrin-duzenle/" . $vitrin->id));
            die();
        } else {

            $alert = array(
                "title" => "İşlem Başarısız",
                "text" => "Bir şeyler ters gitti..",
                "type" => "error"
            );

            $this->session->set_flashdata("alert", $alert);
            redirect(base_url(admin_url() . "vitrin-duzenle/" . $vitrin->id));
            die();
        }
    } else {
        $data = array(
            "name" => $this->input->post("name"),
            "type" => $this->input->post("type"),
            "sira" => $this->input->post("sira"),
            "contents" => $this->input->post("contents")
        );

        $insert = $this->magaza_model->vitrin_update(array('id' => $vitrin->id), $data);

        $alert = array(
            "title" => "İşlem Başarılı",
            "text" => "Vitrin Başarılı Şekilde Güncellendi",
            "type" => "success"
        );


        $this->session->set_flashdata("alert", $alert);
        redirect(base_url(admin_url() . "vitrin-duzenle/" . $vitrin->id));
        die();
    }
}

 public function vitrin_sil($id)
 {
     $delete = $this->magaza_model->vitrin_delete(array("id" => $id));

     if ($delete) {
         redirect(base_url(admin_url() . "vitrinler"));
     } else {
         redirect(base_url(admin_url() . "vitrinler"));
     }
 }
 public function vitrinurun_sil($vitrin_id,$id)
 {
     $delete = $this->magaza_model->vitrinurun_delete(array("id" => $id));

     if ($delete) {
         redirect(base_url(admin_url() . "vitrin-detay/".$vitrin_id));
     } else {
         redirect(base_url(admin_url() . "vitrin-detay/".$vitrin_id));
     }
 }
 public function vitrinurun_sira($vitrin_id,$id,$sira)
 {
     $update = $this->magaza_model->vitrinurun_update(array("id" => $id),array('sira'=>$sira));

     if ($update) {
         redirect(base_url(admin_url() . "vitrin-detay/".$vitrin_id));
     } else {
         redirect(base_url(admin_url() . "vitrin-detay/".$vitrin_id));
     }
 }

 
 public function vitrin_detay($id)
 {
     $data = new stdClass();
     $siteayar = ayarlar();

     $data->title = $siteayar->site_baslik;
     $data->description = $siteayar->site_aciklama;
     $data->keywords = $siteayar->site_keyw;
     $data->vitrin = $this->db->where('id',$id)->get('vitrinler')->row();
     $data->urunler = $this->db->select('vt.id,u.urun_ad,vt.sira')->join('urunler u','vt.urun_id=u.urun_id')->where('vt.vitrin_id',$id)->order_by('vt.sira','ASC')->get('vitrin_urunler vt')->result();
     if ($data->vitrin->contents == 1) {
         $data->tum_urunler = $this->db->select('u.*')->join('vitrin_urunler vt', 'vt.urun_id=u.urun_id', 'left')->where('vt.id', NULL)->where('admin', 1)->get('urunler u')->result();
     } else {
         $data->tum_urunler = $this->db->select('u.*')->join('vitrin_urunler vt', 'vt.urun_id=u.urun_id', 'left')->where('vt.id', NULL)->where('u.admin', 0)->where('u.urun_alim', 0)->get('urunler u')->result();
     }

     $this->load->view('yonetim/inc/_header', $data);
     $this->load->view('yonetim/vitrin/vitrin-detay', $data);
     $this->load->view('yonetim/inc/_footer');
 }
    /**
     * Ürün İşlemleri
     */
    public function urun_ekle()
    {

        $data = new stdClass();

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/urun/urun-ekle', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function urunekle()
    {

        $kullanici = $_SESSION["kullanici"];

        $magaza = magaza("1");
		if(!$magaza) {
			$alert = array(
				"title" => "Hata!",
				"text" => "Mağaza bulunamadı!",
				"type" => "error"
			);
			$this->session->set_flashdata("alert", $alert);
			redirect(base_url(admin_url() . "urunler"));
			die();
		}


        $stok = $this->input->post("urun_stok");

        if (!$stok && $stok < 0) {
            $alert = array(
                "title" => "Hata!",
                "text" => "Ürün Stoğu Girmelisiniz!",
                "type" => "warning",

            );

            $this->session->set_flashdata("alert", $alert);
            redirect(base_url(admin_url() . "urun-ekle"));
            die();
        }

        $tur = $this->input->post("urun_turu");

        if (1 == 2) {
            if ($tur == 2) {
                if (!$this->input->post("sanal_urun_bilgileri")) {
                    $alert = array(
                        "title" => "Hata!",
                        "text" => "Sanal ürün bilgisi girmeniz gerekmektedir!",
                        "type" => "warning"
                    );
                    $this->session->set_flashdata("alert", $alert);
                    redirect(base_url(admin_url() . "urun-ekle"));
                    die();
                }
            }
        }

        if ($tur == 3) {
            if (!$_FILES["dosya"]["name"]) {
                $alert = array(
                    "title" => "Hata!",
                    "text" => "İndirilebilir ürün kullanımı için dosya yüklemeniz gerekmektedir.",
                    "type" => "warning"
                );
                $this->session->set_flashdata("alert", $alert);
                redirect(base_url(admin_url() . "urun-ekle"));
                die();
            }
        }


        if (!is_dir('uploads/urunler/images')) {
            mkdir('uploads/urunler/images', 0777);
            mkdir('uploads/urunler/images' . '/galeri', 0777);
        }
        if(!is_dir('uploads/urunler/images' . '/min'))
            mkdir('uploads/urunler/images' . '/min' , 0777);

        if (!is_dir('uploads/dosya')) {
            mkdir('uploads/dosya/', 0777);
        }


        $this->load->library("form_validation");
        $this->form_validation->set_rules("urun_ad", "Ürün Adı", "required|trim|xss_clean");
        $this->form_validation->set_rules("urun_turu", "Ürün Türü", "required|trim|xss_clean");
        $this->form_validation->set_rules("fiyat", "Fiyat", "required|trim|xss_clean");
        $this->form_validation->set_rules("urun_aciklama", "Ürün Açıklaması", "required|trim|xss_clean");
        $this->form_validation->set_message(
            array("required" => "{field} Boş Bırakılamaz!")
        );

        $validat = $this->form_validation->run();

        if ($validat) {


            if ($_FILES["file"]["name"]) {
                $file_name = seo(pathinfo($_FILES["file"]["name"], PATHINFO_FILENAME)) . "." . pathinfo($_FILES["file"]["name"], PATHINFO_EXTENSION);
                $sifrele = uniqid();
                $config["allowed_types"] = "jpg|jpeg|png";
                $config["upload_path"] = "uploads/urunler/images/";
                $config['encrypt_name'] = TRUE;
                //$config["file_name"] = $sifrele . "_" . $file_name;

                $this->load->library("upload", $config);
                $upload = $this->upload->do_upload("file");
                $kaboom = explode(".", $this->upload->data("file_name"));
                $fileExt = end($kaboom);
                $source_path = 'uploads/urunler/images/' . $this->upload->data("file_name");
                $target_path = 'uploads/urunler/images/min/' . $this->upload->data("file_name");
                $wmax = 300;
                $hmax = 200;
                resize_img_specific($source_path, $target_path, $wmax, $hmax, $fileExt);
                $source_path = 'uploads/urunler/images/' . $this->upload->data("file_name");
                $target_path = 'uploads/urunler/images/' . $this->upload->data("file_name");
                $wmax = 500;
                $hmax = 450;
                resize_img($source_path, $target_path, $wmax, $hmax, $fileExt);

                if ($upload) {
                    $uploaded_file = $this->upload->data("file_name");
                    $seourl = seo($this->input->post("urun_ad")) . "-" . rand(1000, 9999);
                    $kategoriler = $this->input->post("kategori");


                    $data = array(
                        "kullanici_id" => $kullanici->kullanici_id,
                        "kategori_json" => json_encode($kategoriler),
                        "magaza_id" => $magaza->magaza_id,
                        "urun_turu" => $this->input->post("urun_turu"),
                        "urun_ad" => $this->input->post("urun_ad"),
                        "urun_resim" => "uploads/urunler/images/" . $uploaded_file,
                        "urun_resim_min" => "uploads/urunler/images/min/" . $uploaded_file,
                        "urun_marka" => $this->input->post("urun_marka"),
                        "urun_stok" => $this->input->post("urun_stok"),
                        "urun_fiyat" => $this->input->post("fiyat"),
                        "urun_eski_fiyat" => $this->input->post("eski_fiyat"),
                        "urun_kfiyat" => komisyon_hesap($this->input->post("fiyat")),
                        "urun_durum" => 1,
                        "urun_aciklama" => $this->input->post("urun_aciklama"),
                        "urun_seo" => $seourl,
                        "urun_uniq" => uniqid(),
                        /*"urun_sanal_bilgi" => $this->input->post("sanal_urun_bilgileri"),*/
                        "urun_alim" => $this->input->post("urun_alim"),
                        "urun_alimfiyat" => $this->input->post("urun_alimfiyat"),
                        "urun_alimbaslik" => $this->input->post('urun_alimbaslik'),
                        "urun_alim_uyari" => $this->input->post('urun_alim_uyari'),
                        "urun_alim_stok" => $this->input->post('urun_alim_stok'),
                        "admin" => 1,
                        "turkpin" => $this->input->post("teslim_turu"),
                        "epin_id" => $this->input->post("urunlistesi"),
                        "product_id" => $this->input->post("turkpinurunler"),
                        "urun_sira" => $this->input->post('urun_sira'),
                        /*"urun_vitrin_sira" => $this->input->post("urun_vitrin_sira")*/
                    );

                    $insert = $this->magaza_model->urun_add($data);

                    $last_id = $this->db->insert_id();
                    $galeri_arr = array();
                    $countfiles = count($_FILES['galeri']['name']);
                    $files = $_FILES;

                    for ($i = 0; $i < $countfiles; $i++) {

                        $rand_uniq = uniqid(TRUE);
                        $_FILES['files']['name'] = $files['galeri']['name'][$i];
                        $_FILES['files']['type'] = $files['galeri']['type'][$i];
                        $_FILES['files']['tmp_name'] = $files['galeri']['tmp_name'][$i];
                        $_FILES['files']['error'] = $files['galeri']['error'][$i];
                        $_FILES['files']['size'] = $files['galeri']['size'][$i];
                        $configs['upload_path'] = "uploads/urunler/images/galeri/";
                        $configs["allowed_types"] = "jpg|jpeg|png";
                        $configs['max_size'] = '5000';
                        $configs['encrypt_name'] = TRUE;
                        //$configs['file_name'] = $rand_uniq . $_FILES['files']['name'];

                        $this->load->library('upload', $configs);
                        $this->upload->initialize($configs);
                        if ($this->upload->do_upload('files')) {
                            $uploadData = $this->upload->data();
                            $filename = $uploadData['file_name'];
                            $galeri_arr['filenames'][] = $filename;
                            $galeri_arr_get = $galeri_arr['filenames'];
                        } else {
                            //$alert = array(
                            //  "title" => "Hata!",
                            //  "text" => $this->upload->display_errors(),
                            //  "type" => "error"
                            //);
                            //$this->session->set_flashdata("alert", $alert);
                            $galeri_arr_get = array();
                        }
                        //print_r($this->upload->display_errors());

                    }

                    $veri = array('urun_galeri' => json_encode($galeri_arr_get, JSON_UNESCAPED_UNICODE));
                    $insert = $this->magaza_model->urun_update(array('urun_id' => $last_id), $veri);

                    if ($_FILES["dosya"]["name"]) {
                        $file_name = seo(pathinfo($_FILES["dosya"]["name"], PATHINFO_FILENAME)) . "." . pathinfo($_FILES["dosya"]["name"], PATHINFO_EXTENSION);
                        $sifrele = uniqid();
                        $dosya_conf["allowed_types"] = "zip";
                        $dosya_conf["upload_path"] = "uploads/dosya/";
                        $dosya_conf['encrypt_name'] = TRUE;
                        //$dosya_conf["file_name"] = $sifrele . "_" . $file_name;

                        $this->load->library("upload", $dosya_conf);
                        $this->upload->initialize($dosya_conf);
                        $dosya_upload = $this->upload->do_upload("dosya");

                        if ($dosya_upload) {
                            $data_upload_file = $this->upload->data("file_name");
                            $dosya_veri = array(
                                'urun_indir' => "uploads/dosya/" . $data_upload_file,
                            );
                            $dosya_insert = $this->magaza_model->urun_update(array('urun_id' => $last_id), $dosya_veri);
                        }
                    }

                    if ($_FILES["urun_alimimg"]["name"]) {
                        $file_name = seo(pathinfo($_FILES["urun_alimimg"]["name"], PATHINFO_FILENAME)) . "." . pathinfo($_FILES["urun_alimimg"]["name"], PATHINFO_EXTENSION);
                        $sifrele = uniqid();
                        $dosya_conf["allowed_types"] = "jpg|jpeg|png";
                        $dosya_conf["upload_path"] = "uploads/urunler/images/";
                        $dosya_conf['encrypt_name'] = TRUE;
                        //$dosya_conf["file_name"] = $sifrele . "_" . $file_name;
                        $this->load->library("upload", $dosya_conf);
                        $this->upload->initialize($dosya_conf);
                        $dosya_upload = $this->upload->do_upload("urun_alimimg");
                        if ($dosya_upload) {
                            $data_upload_file = $this->upload->data("file_name");
                            $img_veri = array(
                                'urun_alimimg' => "uploads/urunler/images/" . $data_upload_file,
                            );
                            $inserts = $this->magaza_model->urun_update(array('urun_id' => $last_id), $dosya_veri);
                        }
                    }

                    $alert = array(
                        "title" => "İşlem Başarılı",
                        "text" => "Ürün Başarılı Şekilde Eklendi",
                        "type" => "success"
                    );

                    $this->session->set_flashdata("alert", $alert);
                    redirect(base_url(admin_url() . "urunler"));
                    die();
                } else {
                    $alert = array(
                        "title" => "İşlem Başarısız",
                        "text" => "Bir şeyler ters gitti..",
                        "type" => "error"
                    );

                    $this->session->set_flashdata("alert", $alert);
                    redirect(base_url(admin_url() . "urun-ekle"));
                    die();
                }
            } else {
                $alert = array(
                    "title" => "İşlem Başarısız",
                    "text" => "Lütfen Ürün Vitrin Fotoğrafı Seçin!",
                    "type" => "error"
                );
                $this->session->set_flashdata("alert", $alert);
                redirect(admin_url() . base_url("urun-ekle"));
                die();
            }
        } else {
            $data = new stdClass();
            $siteayar = ayarlar();

            $data->title = $siteayar->site_baslik;
            $data->description = $siteayar->site_aciklama;
            $data->keywords = $siteayar->site_keyw;

            $this->load->view('yonetim/inc/_header', $data);
            $this->load->view('yonetim/urun/urun-ekle', $data);
            $this->load->view('yonetim/inc/_footer');
        }
    }

    public function urunler()
    {
        $data = new stdClass();
        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;
        $data->urunler = $this->db->where('admin', 1)->get('urunler')->result();

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/urun/urunler', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function urun_duzenle($urun_id) {
      
        $data = new stdClass();
        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;
        $data->ayarlar = $siteayar;
        
        //$data->urun = $this->yonetim_magaza_model->urun(array('urunler.urun_id' => $urun_id));
        $data->urun = $this->db->where('urun_id', $urun_id)->get('urunler')->row();
        //$data->urun->kullanici_ad = $this->db->where('kullanici_id', $data->urun->kullanici_id)->get('kullanicilar')->row()->kullanici_ad;
        $data->urun->kullanici_ad = $this->db->where('kullanici_id', $data->urun->kullanici_id)->get('kullanici')->row()->kullanici_ad;

        //$api = new Turkpin('agentsunucu@gmail.com', 'Mehmet.3434', true);
        //print_r($api->epinList());
        //die;
        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/urun/urun-duzenle', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function urunduzenle($uniq)
    {
        $kullanici = kullanicicek();
        $urun = $this->magaza_model->urun(array("urun_uniq" => $uniq));
        $urun_sahibi = $this->magaza_model->getwho(array('kullanici_id'=>$urun->kullanici_id));

        $stok = $this->input->post("urun_stok");
        if (!$stok && $stok < 0) {
            $alert = array(
                "title" => "Hata!",
                "text" => "Ürün Stoğu Girmelisiniz!",
                "type" => "warning"
            );

            $this->session->set_flashdata("alert", $alert);
            redirect(base_url(admin_url() . "urun-duzenle/" . $urun->urun_id));
            die();
        }

        /*if ($urun->urun_turu == 2) {
            if (!$this->input->post("sanal_urun_bilgileri")) {
                $alert = array(
                    "title" => "Hata!",
                    "text" => "Sanal ürün bilgisi girmeniz gerekmektedir!",
                    "type" => "warning"
                );
                $this->session->set_flashdata("alert", $alert);
                redirect(base_url(admin_url() . "urun-duzenle/" . $urun->urun_id));
                die();
            }
        }*/
        if ($_FILES["file"]["name"]) {
            $file_name = seo(pathinfo($_FILES["file"]["name"], PATHINFO_FILENAME)) . "." . pathinfo($_FILES["file"]["name"], PATHINFO_EXTENSION);
            $sifrele = uniqid();
            $config["allowed_types"] = "jpg|jpeg|png";
            $config["upload_path"] = "uploads/urunler/images/";
            $config['encrypt_name'] = TRUE;
            //$config["file_name"] = $sifrele . "_" . $file_name;
            
            if (!is_dir('uploads/urunler/images/min'))
                mkdir('uploads/urunler/images/min' , 0777);
            $this->load->library("upload", $config);
            $upload = $this->upload->do_upload("file");
            $kaboom = explode(".", $this->upload->data("file_name"));
            $fileExt = end($kaboom);
            $source_path = 'uploads/urunler/images/' . $this->upload->data("file_name");
            $target_path = 'uploads/urunler/images/min/' . $this->upload->data("file_name");
            $wmax = 300;
            $hmax = 200;
            resize_img_specific($source_path, $target_path, $wmax, $hmax, $fileExt);
            $source_path = 'uploads/urunler/images/' . $this->upload->data("file_name");
            $target_path = 'uploads/urunler/images/' . $this->upload->data("file_name");
            $wmax = 500;
            $hmax = 450;
            resize_img($source_path, $target_path, $wmax, $hmax, $fileExt);

            if ($upload) {

                $uploaded_file = $this->upload->data("file_name");
                if ($urun->urun_ad == $this->input->post("urun_ad")) {
                    $seourl = $urun->urun_seo;
                } else {
                    $seourl = seo($this->input->post("urun_ad")) . "-" . rand(1000, 9999);
                }

                $kategoriler = $this->input->post("kategori");

                if ($this->input->post("teslim_turu") == 1) {
                    $data = array(
                        "kategori_json" => json_encode($kategoriler),
                        "urun_ad" => $this->input->post("urun_ad"),
                        "urun_resim" => "uploads/urunler/images/" . $uploaded_file,
                        "urun_resim_min" => "uploads/urunler/images/min/" . $uploaded_file,
                        "urun_marka" => $this->input->post("urun_marka"),
                        "urun_stok" => $this->input->post("urun_stok"),
                        "urun_fiyat" => $this->input->post("fiyat"),
                        "urun_eski_fiyat" => $this->input->post("eski_fiyat"),
                        "urun_kfiyat" => komisyon_hesap($this->input->post("fiyat")),
                        "urun_populer" => $this->input->post("urun_populer"),
                        "urun_populer_kat" => $this->input->post("urun_populer_kat"),
                        "urun_iptal" => $this->input->post("urun_iptal"),
                        "urun_aciklama" => $this->input->post("urun_aciklama"),
                        "urun_seo" => $seourl,
                        "urun_sanal_bilgi" => $this->input->post("sanal_urun_bilgileri"),
                        /*"kenar" => $this->input->post("kenar"),*/
                        "urun_alim" => $this->input->post("urun_alim"),
                        "urun_alimfiyat" => $this->input->post("urun_alimfiyat"),
                        "urun_alimbaslik" => $this->input->post('urun_alimbaslik'),
                        "urun_sira" => $this->input->post("urun_sira"),
                        "urun_vitrin_sira" => $this->input->post("urun_vitrin_sira"),
                        "urun_alim_uyari" => $this->input->post('urun_alim_uyari'),
                        "urun_alim_stok" => $this->input->post('urun_alim_stok')
                    );
                } else {
                    $data = array(
                        "kategori_json" => json_encode($kategoriler),
                        "urun_ad" => $this->input->post("urun_ad"),
                        "urun_resim" => "uploads/urunler/images/" . $uploaded_file,
                        "urun_resim_min" => "uploads/urunler/images/min/" . $uploaded_file,
                        "urun_marka" => $this->input->post("urun_marka"),
                        "urun_stok" => $this->input->post("urun_stok"),
                        "urun_fiyat" => $this->input->post("fiyat"),
                        "urun_eski_fiyat" => $this->input->post("eski_fiyat"),
                        "urun_kfiyat" => komisyon_hesap($this->input->post("fiyat")),
                        "urun_populer" => $this->input->post("urun_populer"),
                        "urun_populer_kat" => $this->input->post("urun_populer_kat"),
                        "urun_iptal" => $this->input->post("urun_iptal"),
                        "urun_aciklama" => $this->input->post("urun_aciklama"),
                        "urun_seo" => $seourl,
                        "urun_sanal_bilgi" => $this->input->post("sanal_urun_bilgileri"),
                        /*"kenar" => $this->input->post("kenar"),*/
                        "urun_alim" => $this->input->post("urun_alim"),
                        "urun_alimfiyat" => $this->input->post("urun_alimfiyat"),
                        "urun_alimbaslik" => $this->input->post('urun_alimbaslik'),
                        "urun_sira" => $this->input->post("urun_sira"),
                        "urun_vitrin_sira" => $this->input->post("urun_vitrin_sira"),
                        "turkpin" => $this->input->post("teslim_turu"),
                        "epin_id" => $this->input->post("urunlistesi"),
                        "product_id" => $this->input->post("turkpinurunler"),
                        "urun_alim_uyari" => $this->input->post('urun_alim_uyari'),
                        "urun_alim_stok" => $this->input->post('urun_alim_stok')
                    );
                }

                $insert = $this->magaza_model->urun_update(array('urun_uniq' => $uniq), $data);


                if ($_FILES["urun_alimimg"]["name"]) {
                    $file_name = seo(pathinfo($_FILES["urun_alimimg"]["name"], PATHINFO_FILENAME)) . "." . pathinfo($_FILES["urun_alimimg"]["name"], PATHINFO_EXTENSION);
                    $sifrele = uniqid();
                    $dosya_conf["allowed_types"] = "jpg|jpeg|png";
                    $dosya_conf["upload_path"] = "uploads/urunler/images/";
                    $dosya_conf['encrypt_name'] = TRUE;
                    //$dosya_conf["file_name"] = $sifrele . "_" . $file_name;
                    $this->load->library("upload", $dosya_conf);
                    $this->upload->initialize($dosya_conf);
                    $dosya_upload = $this->upload->do_upload("urun_alimimg");
                    if ($dosya_upload) {
                        $data_upload_file = $this->upload->data("file_name");
                        $img_veri = array(
                            'urun_alimimg' => "uploads/urunler/images/" . $data_upload_file,
                        );
                        $inserts = $this->magaza_model->urun_update(array('urun_uniq' => $uniq), $img_veri);
                    }
                }

                $alert = array(
                    "title" => "İşlem Başarılı",
                    "text" => "Ürün Başarılı Şekilde Güncellendi",
                    "type" => "success"
                );

                $this->session->set_flashdata("alert", $alert);
                redirect(base_url(admin_url() . "urun-duzenle/" . $urun->urun_id));
                die();
            } else {

                $alert = array(
                    "title" => "İşlem Başarısız",
                    "text" => "Bir şeyler ters gitti..",
                    "type" => "error"
                );

                $this->session->set_flashdata("alert", $alert);
                redirect(base_url(admin_url() . "urun-duzenle/" . $urun->urun_id));
                die();
            }
        } else {
            if ($urun->urun_ad == $this->input->post("urun_ad")) {
                $seourl = $urun->urun_seo;
            } else {
                $seourl = seo($this->input->post("urun_ad")) . "-" . rand(1000, 9999);
            }
            $kategoriler = $this->input->post("kategori");

            $stok = $this->input->post("urun_stok");

            if (!$stok && $stok < 0) {
                $alert = array(
                    "title" => "Hata!",
                    "text" => "Ürün Stoğu Girmelisiniz!",
                    "type" => "warning"
                );

                $this->session->set_flashdata("alert", $alert);
                redirect(base_url(admin_url() . "urun-duzenle/" . $urun->urun_id));
                die();
            }

            /*if ($urun->urun_turu == 2) {
                if (!$this->input->post("sanal_urun_bilgileri")) {
                    $alert = array(
                        "title" => "Hata!",
                        "text" => "Sanal ürün bilgisi girmeniz gerekmektedir!",
                        "type" => "warning"
                    );
                    $this->session->set_flashdata("alert", $alert);
                    redirect(base_url(admin_url() . "urun-duzenle/" . $urun->urun_id));
                    die();
                }
            }*/



            if ($this->input->post("teslim_turu") == 1) {
                $data = array(
                    "kategori_json" => json_encode($kategoriler),
                    "urun_ad" => $this->input->post("urun_ad"),
                    "urun_marka" => $this->input->post("urun_marka"),
                    "urun_stok" => $this->input->post("urun_stok"),
                    "urun_fiyat" => $this->input->post("fiyat"),
                    "urun_eski_fiyat" => $this->input->post("eski_fiyat"),
                    "urun_kfiyat" => komisyon_hesap($this->input->post("fiyat")),
                    "urun_populer" => $this->input->post("urun_populer"),
                    "urun_populer_kat" => $this->input->post("urun_populer_kat"),
                    "urun_iptal" => $this->input->post("urun_iptal"),
                    "urun_aciklama" => $this->input->post("urun_aciklama"),
                    "urun_seo" => $seourl,
                    "urun_sanal_bilgi" => $this->input->post("sanal_urun_bilgileri"),
                    /*"kenar" => $this->input->post("kenar"),*/
                    "urun_alim" => $this->input->post("urun_alim"),
                    "urun_alimfiyat" => $this->input->post("urun_alimfiyat"),
                    "urun_alimbaslik" => $this->input->post('urun_alimbaslik'),
                    "urun_sira" => $this->input->post("urun_sira"),
                    "urun_vitrin_sira" => $this->input->post("urun_vitrin_sira"),
                    "urun_alim_uyari" => $this->input->post('urun_alim_uyari'),
                    "urun_alim_stok" => $this->input->post('urun_alim_stok')
                );
            } else {
                $data = array(
                    "kategori_json" => json_encode($kategoriler),
                    "urun_ad" => $this->input->post("urun_ad"),
                    "urun_marka" => $this->input->post("urun_marka"),
                    "urun_stok" => $this->input->post("urun_stok"),
                    "urun_fiyat" => $this->input->post("fiyat"),
                    "urun_eski_fiyat" => $this->input->post("eski_fiyat"),
                    "urun_kfiyat" => komisyon_hesap($this->input->post("fiyat")),
                    "urun_populer" => $this->input->post("urun_populer"),
                    "urun_populer_kat" => $this->input->post("urun_populer_kat"),
                    "urun_iptal" => $this->input->post("urun_iptal"),
                    "urun_aciklama" => $this->input->post("urun_aciklama"),
                    "urun_seo" => $seourl,
                    "urun_sanal_bilgi" => $this->input->post("sanal_urun_bilgileri"),
                    /*"kenar" => $this->input->post("kenar"),*/
                    "urun_alim" => $this->input->post("urun_alim"),
                    "urun_alimfiyat" => $this->input->post("urun_alimfiyat"),
                    "urun_alimbaslik" => $this->input->post('urun_alimbaslik'),
                    "urun_sira" => $this->input->post("urun_sira"),
                    "urun_vitrin_sira" => $this->input->post("urun_vitrin_sira"),
                    "turkpin" => $this->input->post("teslim_turu"),
                    "epin_id" => $this->input->post("urunlistesi"),
                    "product_id" => $this->input->post("turkpinurunler"),
                    "urun_alim_uyari" => $this->input->post('urun_alim_uyari'),
                    "urun_alim_stok" => $this->input->post('urun_alim_stok')
                );
            }
            $insert = $this->magaza_model->urun_update(array('urun_uniq' => $uniq), $data);

            if ($_FILES["urun_alimimg"]["name"]) {
                $file_name = seo(pathinfo($_FILES["urun_alimimg"]["name"], PATHINFO_FILENAME)) . "." . pathinfo($_FILES["urun_alimimg"]["name"], PATHINFO_EXTENSION);
                $sifrele = uniqid();
                $dosya_conf["allowed_types"] = "jpg|jpeg|png";
                $dosya_conf["upload_path"] = "uploads/urunler/images/";
                $dosya_conf['encrypt_name'] = TRUE;
                //$dosya_conf["file_name"] = $sifrele . "_" . $file_name;
                $this->load->library("upload", $dosya_conf);
                $this->upload->initialize($dosya_conf);
                $dosya_upload = $this->upload->do_upload("urun_alimimg");
                if ($dosya_upload) {
                    $data_upload_file = $this->upload->data("file_name");
                    $img_veri = array(
                        'urun_alimimg' => "uploads/urunler/images/" . $data_upload_file,
                    );
                    $inserts = $this->magaza_model->urun_update(array('urun_uniq' => $uniq), $img_veri);
                }
            }

            $alert = array(
                "title" => "İşlem Başarılı",
                "text" => "Ürün Başarılı Şekilde Güncellendi",
                "type" => "success"
            );

            $this->session->set_flashdata("alert", $alert);
            redirect(base_url(admin_url() . "urun-duzenle/" . $urun->urun_id));
            die();
        }
    }

    public function onay_bekleyen_urunler()
    {
        $data = new stdClass();
        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;
        $data->urunler = $this->yonetim_magaza_model->urunler(array('urunler.urun_durum' => 0));

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/urun/onay-bekleyen-urunler', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function urun_sil($urun_id)
    {
        $delete = $this->yonetim_magaza_model->urun_sil(array("urun_id" => $urun_id));

        if ($delete) {
            redirect(base_url(admin_url() . "urunler"));
        } else {
            redirect(base_url(admin_url() . "urunler"));
        }
    }

    public function ilan_sil($urun_id)
    {
        $delete = $this->yonetim_magaza_model->urun_sil(array("urun_id" => $urun_id));

        if ($delete) {
            redirect(base_url(admin_url() . "ilanlar"));
        } else {
            redirect(base_url(admin_url() . "ilanlar"));
        }
    }


    public function onay_bekleyen_ilanlar() {
        $data = new stdClass();
        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;
        $data->ilanlar = $this->yonetim_magaza_model->urunler(array('urunler.urun_durum' => 0));

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/ilan/onay-bekleyen-ilanlar', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function pasif_ilanlar() {
        $data = new stdClass();
        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;
        $data->ilanlar = $this->yonetim_magaza_model->urunler(array('urunler.urun_durum' => 2));

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/ilan/pasif-ilanlar', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function satin_alinan_ilanlar() {
        $data = new stdClass();
        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;
        $data->ilanlar = $this->siparis_model->siparisler(array('siparis.siparis_durum' => 2, 'urunler.admin' => 0));

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/ilan/satin-alinan-ilanlar', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function resim_sil($urun_id, $image)
    {
        $data = new stdClass();

        $data->urun = $this->db->where('urun_id', $urun_id)->get('urunler')->row();

        $db_images = json_decode($data->urun->urun_galeri);

        $filteredArray = array_filter($db_images, function ($element) use ($image) {
            return $element !== $image;
        });

        $filteredArray = array_values($filteredArray);

        $veri = array('urun_galeri' => json_encode($filteredArray, JSON_UNESCAPED_UNICODE));
        $insert = $this->magaza_model->urun_update(array('urun_id' => $urun_id), $veri);

        redirect(base_url().admin_url().'ilan-duzenle/'.$urun_id);
    }

    public function ilan_duzenle($ilan_id) {
      
        $data = new stdClass();
        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;
        $data->ayarlar = $siteayar;

        //$data->urun = $this->yonetim_magaza_model->urun(array('urunler.urun_id' => $urun_id));
        $data->urun = $this->db->where('urun_id', $ilan_id)->get('urunler')->row();
        //$data->urun->kullanici_ad = $this->db->where('kullanici_id', $data->urun->kullanici_id)->get('kullanicilar')->row()->kullanici_ad;

        $data->urun->kullanici_ad = $this->db->where('kullanici_id', $data->urun->kullanici_id)->get('kullanici')->row()->kullanici_ad;

        //$api = new Turkpin('agentsunucu@gmail.com', 'Mehmet.3434', true);
        //print_r($api->epinList());
        //die;

        if (isset($_POST['ilan_duzenle'])) {

            $stok = $this->input->post("urun_stok");

            if (!$stok && $stok < 0) {
                $alert = array(
                    "title" => "Hata!",
                    "text" => "Ürün Stoğu Girmelisiniz!",
                    "type" => "warning"
                );

                $this->session->set_flashdata("alert", $alert);
                redirect(base_url("wodosystem/ilan-duzenle/" . $ilan_id));
                die();
            }

            $tur = $this->input->post("urun_turu");

            if ($tur == 2) {
                if (!$this->input->post("sanal_urun_bilgileri")) {
                    $alert = array(
                        "title" => "Hata!",
                        "text" => "Sanal ürün bilgisi girmeniz gerekmektedir!",
                        "type" => "warning"
                    );
                    $this->session->set_flashdata("alert", $alert);
                    redirect(base_url("wodosystem/ilan-duzenle/" . $ilan_id));
                    die();
                }
            }

            if ($_FILES["file"]["name"]) {
                if (!is_dir('uploads/urunler/images/min'))
                    mkdir('uploads/urunler/images/min', 0777);
                $file_name = seo(pathinfo($_FILES["file"]["name"], PATHINFO_FILENAME)) . "." . pathinfo($_FILES["file"]["name"], PATHINFO_EXTENSION);
                $sifrele = uniqid();
                $config["allowed_types"] = "jpg|jpeg|png";
                $config["upload_path"] = "uploads/urunler/images/";
                $config['encrypt_name'] = TRUE;
                //$config["file_name"] = $sifrele . "_" . $file_name;

                $this->load->library("upload", $config);
                $upload = $this->upload->do_upload("file");
                $kaboom = explode(".", $this->upload->data("file_name"));
                $fileExt = end($kaboom);
                $source_path = 'uploads/urunler/images/' . $this->upload->data("file_name");
                $target_path = 'uploads/urunler/images/min/' . $this->upload->data("file_name");
                $wmax = 300;
                $hmax = 200;
                resize_img_specific($source_path, $target_path, $wmax, $hmax, $fileExt);
                $source_path = 'uploads/urunler/images/' . $this->upload->data("file_name");
                $target_path = 'uploads/urunler/images/' . $this->upload->data("file_name");
                $wmax = 500;
                $hmax = 450;
                resize_img($source_path, $target_path, $wmax, $hmax, $fileExt);

                if ($upload) {

                    $uploaded_file = $this->upload->data("file_name");
                    if ($data->urun->urun_ad == $this->input->post("urun_ad")) {
                        $seourl = $data->urun->urun_seo;
                    } else {
                        $seourl = seo($this->input->post("urun_ad")) . "-" . rand(1000, 9999);
                    }
                    $kategoriler = $this->input->post("kategori");


                    $update_data = array(
                        "kategori_json" => json_encode($kategoriler),
                        "urun_turu" => $this->input->post("urun_turu"),
                        /*"urun_bitis_tarihi" => date('Y-m-d H:i:s', strtotime($this->input->post("urun_bitis_tarihi"))),*/
                        "urun_ad" => $this->input->post("urun_ad"),
                        "urun_resim" => "uploads/urunler/images/" . $uploaded_file,
                        "urun_resim_min" => "uploads/urunler/images/min/" . $uploaded_file,
                        "urun_marka" => $this->input->post("urun_marka"),
                        "urun_stok" => $this->input->post("urun_stok"),
                        "urun_fiyat" => $this->input->post("fiyat"),
                        "urun_kfiyat" => komisyon_hesap($this->input->post("fiyat")),
                        "urun_durum" => $this->input->post('urun_durum'),
                        "urun_iptal" => $this->input->post('urun_iptal'),
                        "urun_aciklama" => $this->input->post("urun_aciklama"),
                        "urun_short_aciklama" => $this->input->post("urun_short_aciklama"),
                        "urun_seo" => $seourl,
                        "urun_sanal_bilgi" => $this->input->post("sanal_urun_bilgileri"),
                        "urun_populer" => $this->input->post('urun_populer')
                    );

                    $insert = $this->magaza_model->urun_update(array('urun_id' => $ilan_id), $update_data);


                    if ($_FILES['galeri']['name'][0]) {

                        $galeri_arr = array();
                        $countfiles = count($_FILES['galeri']['name']);
                        $files = $_FILES;

                        for ($i = 0; $i < $countfiles; $i++) {
                            $rand_uniq = uniqid(TRUE);
                            $_FILES['files']['name'] = $files['galeri']['name'][$i];
                            $_FILES['files']['type'] = $files['galeri']['type'][$i];
                            $_FILES['files']['tmp_name'] = $files['galeri']['tmp_name'][$i];
                            $_FILES['files']['error'] = $files['galeri']['error'][$i];
                            $_FILES['files']['size'] = $files['galeri']['size'][$i];
                            $configs['upload_path'] = "uploads/img/";
                            $configs["allowed_types"] = "jpg|jpeg|png";
                            $configs['max_size'] = '5000';
                            $configs['encrypt_name'] = TRUE;
                            //$configs['file_name'] = $rand_uniq . $_FILES['files']['name'];

                            $this->load->library('upload', $configs);
                            $this->upload->initialize($configs);
                            if ($this->upload->do_upload('files')) {
                                $uploadData = $this->upload->data();
                                $filename = $uploadData['file_name'];
                                $galeri_arr['filenames'][] = $filename;
                            }
                        }

                        if (!empty($data->urun->urun_galeri)) {
                            $birlestir = array_merge(json_decode($data->urun->urun_galeri), $galeri_arr['filenames']);
                        } else {
                            $birlestir = $galeri_arr['filenames'];
                        }
                        $veri = array('urun_galeri' => json_encode($birlestir, JSON_UNESCAPED_UNICODE));
                        $insert = $this->magaza_model->urun_update(array('urun_id' => $ilan_id), $veri);
                    }

                    if ($_FILES["dosya"]["name"]) {
                        $file_name = seo(pathinfo($_FILES["dosya"]["name"], PATHINFO_FILENAME)) . "." . pathinfo($_FILES["dosya"]["name"], PATHINFO_EXTENSION);
                        $sifrele = uniqid();
                        $dosya_conf["allowed_types"] = "zip";
                        $dosya_conf["upload_path"] = "uploads/dosya/";
                        $config['encrypt_name'] = TRUE;
                        //$dosya_conf["file_name"] = $sifrele . "_" . $file_name;

                        $this->load->library("upload", $dosya_conf);
                        $this->upload->initialize($dosya_conf);
                        $dosya_upload = $this->upload->do_upload("dosya");

                        if ($dosya_upload) {
                            $data_upload_file = $this->upload->data("file_name");
                            $dosya_veri = array(
                                'urun_indir' => "uploads/dosya/" . $data_upload_file,
                            );
                            $dosya_insert = $this->magaza_model->urun_update(array('urun_id' => $ilan_id), $dosya_veri);
                        }
                    }

                    $alert = array(
                        "title" => "İşlem Başarılı",
                        "text" => "Ürün Başarılı Şekilde Güncellendi",
                        "type" => "success"
                    );


                    $this->session->set_flashdata("alert", $alert);
                    redirect(base_url("wodosystem/ilan-duzenle/" . $ilan_id));
                    die();
                } else {

                    $alert = array(
                        "title" => "İşlem Başarısız",
                        "text" => "Bir şeyler ters gitti..",
                        "type" => "error"
                    );

                    $this->session->set_flashdata("alert", $alert);
                    redirect(base_url("wodosystem/ilan-duzenle/" . $ilan_id));
                    die();
                }
            } else {
                if ($data->urun->urun_ad == $this->input->post("urun_ad")) {
                    $seourl = $data->urun->urun_seo;
                } else {
                    $seourl = seo($this->input->post("urun_ad")) . "-" . rand(1000, 9999);
                }
                $kategoriler = $this->input->post("kategori");


                $stok = $this->input->post("urun_stok");

                if (!$stok && $stok < 0) {
                    $alert = array(
                        "title" => "Hata!",
                        "text" => "Ürün Stoğu Girmelisiniz!",
                        "type" => "warning"
                    );

                    $this->session->set_flashdata("alert", $alert);
                    redirect(base_url("wodosystem/ilan-duzenle/" . $ilan_id));
                    die();
                }

                $tur = $this->input->post("urun_turu");

                if ($tur == 2) {
                    if (!$this->input->post("sanal_urun_bilgileri")) {
                        $alert = array(
                            "title" => "Hata!",
                            "text" => "Sanal ürün bilgisi girmeniz gerekmektedir!",
                            "type" => "warning"
                        );
                        $this->session->set_flashdata("alert", $alert);
                        redirect(base_url("wodosystem/ilan-duzenle/" . $ilan_id));
                        die();
                    }
                }
                $update_data = array(
                    "kategori_json" => json_encode($kategoriler),
                    "urun_turu" => $this->input->post("urun_turu"),
                    /*"urun_bitis_tarihi" => date('Y-m-d H:i:s', strtotime($this->input->post("urun_bitis_tarihi"))),*/
                    "urun_ad" => $this->input->post("urun_ad"),
                    "urun_marka" => $this->input->post("urun_marka"),
                    "urun_stok" => $this->input->post("urun_stok"),
                    "urun_fiyat" => $this->input->post("fiyat"),
                    "urun_kfiyat" => komisyon_hesap($this->input->post("fiyat")),
                    "urun_durum" => $this->input->post('urun_durum'),
                    "urun_iptal" => $this->input->post('urun_iptal'),
                    "urun_aciklama" => $this->input->post("urun_aciklama"),
                    "urun_short_aciklama" => $this->input->post("urun_short_aciklama"),
                    "urun_seo" => $seourl,
                    "urun_sanal_bilgi" => $this->input->post("sanal_urun_bilgileri"),
                    "urun_populer" => $this->input->post('urun_populer')
                );

                $insert = $this->magaza_model->urun_update(array('urun_id' => $ilan_id), $update_data);

                if ($_FILES['galeri']['name'][0]) {
                    $galeri_arr = array();
                    $countfiles = count($_FILES['galeri']['name']);
                    $files = $_FILES;

                    for ($i = 0; $i < $countfiles; $i++) {
                        $rand_uniq = uniqid(TRUE);
                        $_FILES['files']['name'] = $files['galeri']['name'][$i];
                        $_FILES['files']['type'] = $files['galeri']['type'][$i];
                        $_FILES['files']['tmp_name'] = $files['galeri']['tmp_name'][$i];
                        $_FILES['files']['error'] = $files['galeri']['error'][$i];
                        $_FILES['files']['size'] = $files['galeri']['size'][$i];
                        $configs['upload_path'] = "uploads/img/";
                        $configs["allowed_types"] = "jpg|jpeg|png";
                        $configs['max_size'] = '5000';
                        $configs['encrypt_name'] = TRUE;
                        //$configs['file_name'] = $rand_uniq . $_FILES['files']['name'];

                        $this->load->library('upload', $configs);
                        $this->upload->initialize($configs);
                        if ($this->upload->do_upload('files')) {
                            $uploadData = $this->upload->data();
                            $filename = $uploadData['file_name'];
                            $galeri_arr['filenames'][] = $filename;
                        }
                    }

                    if (!empty($data->urun->urun_galeri)) {
                        $birlestir = array_merge(json_decode($data->urun->urun_galeri), $galeri_arr['filenames']);
                    } else {
                        $birlestir = $galeri_arr['filenames'];
                    }
                    $veri = array('urun_galeri' => json_encode($birlestir, JSON_UNESCAPED_UNICODE));
                    $insert = $this->magaza_model->urun_update(array('urun_id' => $ilan_id), $veri);
                }

                if ($_FILES["dosya"]["name"]) {
                    $file_name = seo(pathinfo($_FILES["dosya"]["name"], PATHINFO_FILENAME)) . "." . pathinfo($_FILES["dosya"]["name"], PATHINFO_EXTENSION);
                    $sifrele = uniqid();
                    $dosya_conf["allowed_types"] = "zip";
                    $dosya_conf["upload_path"] = "uploads/dosya/";
                    $config['encrypt_name'] = TRUE;
                    //$dosya_conf["file_name"] = $sifrele . "_" . $file_name;

                    $this->load->library("upload", $dosya_conf);
                    $this->upload->initialize($dosya_conf);
                    $dosya_upload = $this->upload->do_upload("dosya");

                    if ($dosya_upload) {
                        $data_upload_file = $this->upload->data("file_name");
                        $dosya_veri = array(
                            'urun_indir' => "uploads/dosya/" . $data_upload_file,
                        );
                        $dosya_insert = $this->magaza_model->urun_update(array('urun_id' => $ilan_id), $dosya_veri);
                    }
                }

                $alert = array(
                    "title" => "İşlem Başarılı",
                    "text" => "Ürün Başarılı Şekilde Güncellendi",
                    "type" => "success"
                );


                $this->session->set_flashdata("alert", $alert);
                redirect(base_url("wodosystem/ilan-duzenle/" . $ilan_id));
                die();
            }
        }

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/ilan/ilan-duzenle', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    /**
     * Teslimat İşlemleri
     */

    public function teslimat()
    {
        $data = new stdClass();
        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;
        $data->teslimat = $this->yonetim_magaza_model->teslimatlar();

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/teslimat/teslimat', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function teslimat_detay($id)
    {
        $data = new stdClass();
        $siteayar = ayarlar();

        $teslimat = $this->yonetim_magaza_model->teslimat(array('teslimat.siparis_no' => $id));

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;
        $data->teslimat = $teslimat;
        $data->siparis = $this->siparis_model->siparis(array('siparis.siparis_no' => $id));
        $data->mesajlar = $this->siparis_model->mesajlar(array('mesaj.teslimat_id' => $teslimat->teslimat_id));

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/teslimat/teslimat-detay', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function teslimat_duzenle($teslimat_uniq, $siparis_no)
    {
        $teslimat = $this->yonetim_magaza_model->teslimat(array('teslimat.teslimat_uniq' => $teslimat_uniq));
        $kullanici = admin_kullanicicek();

        /**
         * Mesaj İşlemi
         */
        if ($this->input->post("mesaj")) {
            $mesaj = array(
                'teslimat_id' => $teslimat->teslimat_id,
                'mesaj_gonderen' => $kullanici->kullanici_id,
                'mesaj' => htmlspecialchars($this->input->post('mesaj'))
            );
            $this->siparis_model->mesaj_add($mesaj);
        }
        /**
         * Sipariş İşlemi
         */
        if ($this->input->post('siparis_durum') == 2) {
            $siparis = $this->siparis_model->siparis(array('siparis.kullanici_id' => $teslimat->kullanici_id, 'siparis.siparis_no' => $siparis_no));

            $magaza_bilgi = magaza_bilgi($siparis->magaza);
            $satici_bilgi = kullanici_bilgi($magaza_bilgi->kullanici_id);

            $kategori_id = json_decode($siparis->kategori_json)[0];

            $category = $this->home_model->kategoricek(array('kategori_id' => $kategori_id));

            $komisyon_tutar = kategori_komisyon_hesap($siparis->siparis_tutar, $category->komisyon);

            $satici_odenecek_tutar = $siparis->siparis_tutar - $komisyon_tutar;
            $satici_odenecek_tutar = number_format($satici_odenecek_tutar, 2);

            $satici_arr = [
                'bakiye' => number_format($satici_bilgi->bakiye+$satici_odenecek_tutar,2)
            ];

            $this->siparis_model->update_bakiye(array('kullanici_id' => $satici_bilgi->kullanici_id), $satici_arr);
        } else if ($this->input->post('siparis_durum') == 3) {
            $siparis = $this->siparis_model->siparis(array('siparis.kullanici_id' => $teslimat->kullanici_id, 'siparis.siparis_no' => $siparis_no));

            $alici_bilgi = kullanici_bilgi($teslimat->kullanici_id);

            $alici_arr = [
                'bakiye' => $alici_bilgi->bakiye+$siparis->siparis_tutar
            ];
            $this->siparis_model->update_bakiye(array('kullanici_id' => $teslimat->kullanici_id), $alici_arr);
        }
        $siparis_durum = array('siparis_durum' => $this->input->post('siparis_durum'), 'siparis_iptal' => $this->input->post('siparis_iptal'));
        $this->siparis_model->siparis_update(array('siparis_no' => $siparis_no), $siparis_durum);
        /**
         * Teslimat İşlemi
         */
        $teslimat_siparis_durum = array('teslimat_durum' => $this->input->post('teslimat_durum'));
        $this->yonetim_magaza_model->teslimat_update(array('teslimat_uniq' => $teslimat_uniq), $teslimat_siparis_durum);

        $alert = array(
            "title" => "İşlem Başarılı",
            "text" => "Teslimat İtirazı Başarılı Şekilde Güncellendi",
            "type" => "success"
        );


        $this->session->set_flashdata("alert", $alert);
        redirect(base_url(admin_url() . "teslimat-detay/" . $siparis_no));
        die();
    }

    public function teslimat_sil($teslimat_id)
    {
        $delete = $this->yonetim_magaza_model->teslimat_sil(array("teslimat_id" => $teslimat_id));

        if ($delete) {
            redirect(base_url(admin_url() . "teslimat"));
        } else {
            redirect(base_url(admin_url() . "teslimat"));
        }
    }

    public function onay_bekleyen_teslimat()
    {
        $data = new stdClass();
        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;

        $data->teslimat = $this->yonetim_magaza_model->teslimatlar(array('teslimat_durum' => 0));

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/teslimat/onay-bekleyen-teslimat', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    /**
     * Destek Talep İşlemleri
     */

    public function destek_talepleri()
    {
        $data = new stdClass();
        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;
        $data->destekler = $this->siparis_model->destekler();

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/destek/destek-talepleri', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function destek_detay($talep_no)
    {
        $data = new stdClass();
        $siteayar = ayarlar();

        $destek = $this->siparis_model->destek(array('talep_no' => $talep_no));
        if (!$destek) {
            redirect(base_url(admin_url() . 'destek-talepleri'));
            die();
        }

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;
        $data->destek = $destek;

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/destek/destek-detay', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function destek_duzenle($talep_no)
    {
        $talep = $this->siparis_model->destek(array('talep_no' => $talep_no));
        $kullanici = admin_kullanicicek();

        if (!$talep) {
            redirect(base_url(admin_url() . 'destek-talepleri'));
            die();
        }
        if (@$_POST["cevap"] != Null) {
            $data = array(
                'cevap_user' => $kullanici->kullanici_id,
                'cevap' => $this->input->post('cevap'),
                'cevap_tarih' => date("Y-m-d H:i:s"),
                'cevap_ticket' => $talep->talep_id
            );

            $this->siparis_model->cevap_add($data);
        }
        $data = array(
            'talep_durum' => $this->input->post('talep_durum'),
            'talep_cevap' => $this->input->post('cevap'),
        );

        $this->siparis_model->destek_update(array('talep_no' => $talep_no), $data);


        $alert = array(
            "title" => "İşlem Başarılı",
            "text" => "Destek Talebi Başarılı Şekilde Güncellendi",
            "type" => "success"
        );


        $this->session->set_flashdata("alert", $alert);
        redirect(base_url(admin_url() . "destek-detay/" . $talep_no));
        die();
    }

    public function bekleyen_destek_talepleri()
    {
        $data = new stdClass();
        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;
        $data->destekler = $this->siparis_model->destekler(array('talep_durum' => 0));

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/destek/bekleyen-destek-talepleri', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function talep_sil($talep_no)
    {
        $delete = $this->siparis_model->talep_sil(array("talep_no" => $talep_no));

        if ($delete) {
            redirect(base_url(admin_url() . "destek-talepleri"));
        } else {
            redirect(base_url(admin_url() . "destek-talepleri"));
        }
    }


    public function bfirmalar()
    {

        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $data = new stdClass();

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;


        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/firma/bfirmalar', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function firmadurum($id)
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        if ($id) {

            $durumum = ($this->input->post("data") === "true") ? 1 : 0;

            $this->yonetim_model->firmaupdate(array("firma_id" => $id), array("firma_durum" => $durumum));
        }
    }

    public function yorumdurum($id)
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        if ($id) {

            $durumum = ($this->input->post("data") === "true") ? 1 : 0;

            $this->destek_model->yorumupdate(array("yorum_id" => $id), array("yorum_durum" => $durumum));
        }
    }

    public function yorumonecikart($id)
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        if ($id) {

            $durumum = ($this->input->post("data") === "true") ? 1 : 0;

            $this->destek_model->yorumupdate(array("yorum_id" => $id), array("yorum_onecikart" => $durumum));
        }
    }


    /**
     * Yorum İşlemleri
     */

    public function yorumlar()
    {
        $data = new stdClass();

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;
        $data->yorumlar = $this->siparis_model->yorumlar();


        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/yorum/yorumlar', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function yorum_detay($siparis_no)
    {
        $data = new stdClass();
        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;
        $data->yorum = $this->siparis_model->yorum(array('siparis_no' => $siparis_no));


        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/yorum/yorum-detay', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function yorum_duzenle($siparis_no)
    {
        $yorum = $this->siparis_model->yorum(array('siparis_no' => $siparis_no));
        if ($yorum) {
            $this->siparis_model->yorum_update(array('siparis_no' => $siparis_no), array('yorum_durum' => $this->input->post('yorum_durum')));

            $alert = array(
                "title" => "İşlem Başarılı",
                "text" => "Yorum Durumu Güncellendi",
                "type" => "success"
            );
            $this->session->set_flashdata("alert", $alert);
            redirect(base_url(admin_url() . "yorum-detay/" . $siparis_no));
            die();
        } else {
            $alert = array(
                "title" => "Hata!",
                "text" => "Yorum bulunamadı!",
                "type" => "danger"
            );
            $this->session->set_flashdata("alert", $alert);
            redirect(base_url(admin_url() . "yorumlar"));
            die();
        }
    }

    public function yorum_sil($yorum_id)
    {
        $delete = $this->yonetim_model->yorumdelete(array("yorum_id" => $yorum_id));

        if ($delete) {
            redirect(base_url(admin_url() . 'yorumlar'));
        } else {
            redirect(base_url(admin_url() . 'yorumlar'));
        }
    }

    public function onay_bekleyen_yorumlar()
    {
        $data = new stdClass();

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;
        $data->yorumlar = $this->siparis_model->yorumlar(array('yorum_durum' => 0));


        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/yorum/onay-bekleyen-yorumlar', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function yorum_itiraz()
    {
        $data = new stdClass();

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;
        $data->yorumlar = $this->magaza_model->yorum_itirazlar();


        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/yorum/yorum-itirazlar', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function itiraz_detay($itiraz_id)
    {
        $data = new stdClass();
        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;
        $data->yorum = $this->magaza_model->yorum_itiraz(array('yorum_itiraz.itiraz_id' => $itiraz_id));


        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/yorum/itiraz-detay', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function itiraz_duzenle($itiraz_id)
    {
        $yorum = $this->magaza_model->yorum_itiraz(array('yorum_itiraz.itiraz_id' => $itiraz_id));
        if ($yorum) {
            $this->siparis_model->yorum_update(array('siparis_no' => $yorum->siparis_no), array('yorum_durum' => $this->input->post('yorum_durum')));
            $this->magaza_model->itiraz_update(array('itiraz_id' => $itiraz_id), array('itiraz_durum' => $this->input->post('itiraz_durum')));

            $alert = array(
                "title" => "İşlem Başarılı",
                "text" => "Değişiklikler Güncellendi",
                "type" => "success"
            );
            $this->session->set_flashdata("alert", $alert);
            redirect(base_url(admin_url() . "itiraz-detay/" . $itiraz_id));
            die();
        } else {
            $alert = array(
                "title" => "Hata!",
                "text" => "Yorum İtiraz bulunamadı!",
                "type" => "danger"
            );
            $this->session->set_flashdata("alert", $alert);
            redirect(base_url(admin_url() . "itiraz-talepleri"));
            die();
        }
    }

    public function itiraz_sil($itiraz_id)
    {
        $delete = $this->magaza_model->itiraz_sil(array("itiraz_id" => $itiraz_id));

        if ($delete) {
            redirect(base_url(admin_url() . "itiraz-talepleri"));
        } else {
            redirect(base_url(admin_url() . "itiraz-talepleri"));
        }
    }

    /**
     * Bakiye Talepleri
     */
    public function bakiye_talepleri()
    {
        $data = new stdClass();
        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;
        $data->talepler = $this->magaza_model->bakiye_talep_cek();

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/bakiye-yukleme/bakiye-talepleri', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function bekleyen_bakiye_talepleri()
    {
        $data = new stdClass();
        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;
        $data->talepler = $this->magaza_model->bakiye_talep_cek(['balance_upload_request.status' => 0]);

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/bakiye-yukleme/onay-bekleyen', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function bakiye_detay($id)
    {
        $data = new stdClass();
        $siteayar = ayarlar();
        $odeme = $this->magaza_model->bakiyetalepcek(array('balance_upload_request.id' => $id));
        if (!$odeme) {
            redirect(base_url(admin_url() . 'bakiye-yukleme-talepleri'));
            die();
        }

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;
        $data->talep = $odeme;

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/bakiye-yukleme/odeme-detay', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function bakiye_bekleyen_detay($id)
    {
        $data = new stdClass();
        $siteayar = ayarlar();
        $odeme = $this->magaza_model->bakiyetalepcek(array('balance_upload_request.id' => $id));
        if (!$odeme) {
            redirect(base_url(admin_url() . 'bakiye-yukleme-talepleri'));
            die();
        }

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;
        $data->talep = $odeme;

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/bakiye-yukleme/bekleyen-odeme-detay', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function bakiye_duzenle($id)
    {
        $ayarlar = ayarlar();
        $odeme = $this->magaza_model->bakiyetalepcek(array('balance_upload_request.id' => $id));
        if (!$odeme) {
            redirect(base_url(admin_url() . 'bakiye-yukleme-talepleri'));
            die();
        }

        $odeme_durum = $this->input->post('status');
        if($odeme_durum == 1) {
            $kullanici = $this->yonetim_model->get(array(
                "kullanici_id" => $odeme->user_id
            ));
            $yuklenecek_tutar = round(($odeme->amount/(100+$ayarlar->havale_komisyon)) * 100,2);
            $this->destek_model->kullaniciupdate(['kullanici_id'=>$odeme->user_id],['bakiye'=> (floatval($kullanici->bakiye) + $yuklenecek_tutar)]);
        }
        $this->magaza_model->bakiyetalep_update(array('id' => $id), array('status' => $odeme_durum));
        $alert = array(
            "title" => "İşlem Başarılı",
            "text" => "Bakiye Yükleme Talebi Başarılı Şekilde Güncellendi",
            "type" => "success"
        );

        $this->session->set_flashdata("alert", $alert);
        redirect(base_url(admin_url() . "bakiye-yukleme-detay/" . $id));
        die();
    }

    public function bakiye_sil($id)
    {
        $delete = $this->magaza_model->bakiyetalep_sil(array("id" => $id));

        if ($delete) {
            redirect(base_url(admin_url() . 'bakiye-yukleme-talepleri'));
        } else {
            redirect(base_url(admin_url() . 'bakiye-yukleme-talepleri'));
        }
    }

    /**
     * Ödeme Talepleri
     */
    public function bayi_odeme_talepleri()
    {
        $data = new stdClass();
        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;
        $data->talepler = $this->yonetim_model->bayipara_cek(['balance_withdraw_requests.status' => 1]);
        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/bayi/odeme-talepleri', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function bayi_bekleyen_odeme_talepleri()
    {
        $data = new stdClass();
        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;
        $data->talepler = $this->yonetim_model->bayipara_cek(['balance_withdraw_requests.status' => 0]);

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/bayi/onay-bekleyen', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function bayi_odeme_detay($id)
    {
        $data = new stdClass();
        $siteayar = ayarlar();
        $odeme = $this->yonetim_model->bayipara_cek(array('balance_withdraw_requests.id' => $id));
        if (!$odeme) {
            redirect(base_url(admin_url() . 'odeme-talepleri'));
            die();
        }

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;
        $data->talep = $odeme[0];

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/bayi/odeme-detay', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function bayi_odeme_duzenle($id)
    {
        $odeme = $this->yonetim_model->bayipara_cek(array('balance_withdraw_requests.id' => $id));
        if (!$odeme) {
            redirect(base_url(admin_url() . 'odeme-talepleri'));
            die();
        }
        $where = $this->yonetim_model->kullaniciget(
            array(
                "kullanici_id" => $odeme[0]->user_id
            )
        );
        $odeme_durum = $this->input->post('odeme_durum');
        if($odeme_durum == 2) {
            $json = json_decode($odeme[0]->information_json);
            $this->yonetim_model->yoneticiupdate(
                array("kullanici_id" => $odeme[0]->user_id),
                array(
                    "kullanici_bayi_bakiye" => $where->kullanici_bayi_bakiye + $json->amountWithoutCommissionAmount,
                )
            );
        }

        $this->yonetim_model->bayiparacek_update(array('id' => $id), array('status' => $odeme_durum));

        $alert = array(
            "title" => "İşlem Başarılı",
            "text" => "Para Çekme Talebi Başarılı Şekilde Güncellendi",
            "type" => "success"
        );

        $this->session->set_flashdata("alert", $alert);
        redirect(base_url(admin_url() . "bayi-odeme-detay/" . $id));
        die();
    }

    public function bayi_odeme_sil($id)
    {
        $delete = $this->yonetim_model->bayiparacek_sil(array("id" => $id));

        if ($delete) {
            redirect(base_url(admin_url() . 'bayi-odeme-talepleri'));
        } else {
            redirect(base_url(admin_url() . 'bayi-odeme-talepleri'));
        }
    }
    /**
     * Ödeme Talepleri
     */
    public function odeme_talepleri()
    {
        $data = new stdClass();
        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;
        $data->talepler = $this->magaza_model->kpara_cek();

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/odeme/odeme-talepleri', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function bekleyen_odeme_talepleri()
    {
        $data = new stdClass();
        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;
        $data->talepler = $this->magaza_model->kpara_cek(['para_cek.paracek_durum' => 0]);

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/odeme/onay-bekleyen', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function odeme_detay($odeme_talep_no)
    {
        $data = new stdClass();
        $siteayar = ayarlar();
        $odeme = $this->magaza_model->kparacek(array('paracek_no' => $odeme_talep_no));
        if (!$odeme) {
            redirect(base_url(admin_url() . 'odeme-talepleri'));
            die();
        }

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;
        $data->talep = $odeme;

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/odeme/odeme-detay', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function odeme_duzenle($odeme_talep_no)
    {
        $odeme = $this->magaza_model->kparacek(array('paracek_no' => $odeme_talep_no));
        if (!$odeme) {
            redirect(base_url(admin_url() . 'odeme-talepleri'));
            die();
        }

        $odeme_durum = $this->input->post('odeme_durum');

        if ($odeme_durum == 0) {
            $odeme_talep_durum = 0;
        } elseif ($odeme_durum == 1) {
            $odeme_talep_durum = 1;
        } elseif ($odeme_durum == 2) {
            $odeme_talep_durum = 0;
        } else {
            $odeme_talep_durum = 0;
        }

        /*$paracek_json = json_decode($odeme->paracek_json);
        if ($paracek_json) {
            foreach ($paracek_json as $id) {
                $this->siparis_model->siparis_update(array('siparis_id' => $id), array('odeme_onay' => $odeme_talep_durum));
            }
        }*/


        $user_bakiye = $odeme->bakiye;
        $paracek_tutar = $odeme->paracek_tutar;

        $last_bakiye = $user_bakiye+$paracek_tutar;
        if ($odeme_talep_durum == 0) {
            $this->magaza_model->update_user_bakiye($odeme->kullanici_id, $last_bakiye);
        }
        $this->magaza_model->paracek_update(array('paracek_no' => $odeme_talep_no), array('paracek_durum' => $odeme_durum));

        $alert = array(
            "title" => "İşlem Başarılı",
            "text" => "Para Çekme Talebi Başarılı Şekilde Güncellendi",
            "type" => "success"
        );

        $this->session->set_flashdata("alert", $alert);
        redirect(base_url(admin_url() . "odeme-detay/" . $odeme_talep_no));
        die();
    }

    public function odeme_sil($odeme_talep_no)
    {
        $delete = $this->magaza_model->paracek_sil(array("paracek_no" => $odeme_talep_no));

        if ($delete) {
            redirect(base_url(admin_url() . 'odeme-talepleri'));
        } else {
            redirect(base_url(admin_url() . 'odeme-talepleri'));
        }
    }

    /**
     * Siparişler
     */
    public function siparisler()
    {
        $data = new stdClass();
        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;
        $data->siparisler = $this->siparis_model->siparisler();

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/siparis/siparisler', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function satislar()
    {
        $data = new stdClass();
        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;
        $data->siparisler = $this->siparis_model->satislar();

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/satis/satislar', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function bekleyen_satislar()
    {
        $data = new stdClass();
        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;
        $data->siparisler = $this->siparis_model->satislar(array('siparis_satis.siparis_durum' => 0));

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/satis/bekleyen-satislar', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function tamamlanan_siparisler()
    {
        $data = new stdClass();
        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;
        $data->siparisler = $this->siparis_model->satislar(array('siparis_satis.siparis_durum' => 2));

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/satis/tamamlanan-satislar', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function satis_detay($siparis_no)
    {
        $data = new stdClass();
        $siteayar = ayarlar();

        $siparis = $this->siparis_model->satis(array('siparis_satis.siparis_no' => $siparis_no));
        if (!$siparis) {
            redirect(base_url(admin_url() . 'satislar'));
            die();
        }
        if (@$_GET["bal"] == "1") {
            $this->siparis_model->satis_update(array('siparis_no' => $siparis_no), array('siparis_bakiye' => 1));

            $this->destek_model->kullaniciupdate(
                array("kullanici_id" => $siparis->kullanici_id),
                array(
                    "bakiye" => $siparis->bakiye + $siparis->siparis_tutar
                )
            );
            redirect(base_url(admin_url() . "satis-detay/" . $siparis_no));
            die();
        }

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;
        $data->siparis = $siparis;

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/satis/satis-detay', $data);
        $this->load->view('yonetim/inc/_footer');
    }
    public function satis_duzenle($siparis_no)
    {
        if (!$_POST) {
            redirect(base_url(admin_url() . 'satislar'));
        }

        $siparis_durum = array(
            'siparis_durum' => $this->input->post('siparis_durum'),
            'teslim_alan' => $this->input->post('teslim_alan'),
            'teslim_yeri' => $this->input->post('teslim_yeri'),
            'bilgi' => $this->input->post('bilgi'),
            'siparis_iptal' => $this->input->post('siparis_iptal')
        );
        $this->siparis_model->satis_update(array('siparis_no' => $siparis_no), $siparis_durum);
        $alert = array(
            "title" => "İşlem Başarılı",
            "text" => "Satış Başarılı Şekilde Güncellendi",
            "type" => "success"
        );


        $this->session->set_flashdata("alert", $alert);
        redirect(base_url(admin_url() . "satis-detay/" . $siparis_no));
        die();
    }

    public function reklam_siparisler()
    {
        $data = new stdClass();
        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;
        $data->siparisler = $this->magaza_model->reklamlar();

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/siparis/reklam-siparisler', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function odeme_bekleyen_siparisler()
    {
        $data = new stdClass();
        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;
        $data->siparisler = $this->siparis_model->siparisler(array('siparis.siparis_durum' => 0));

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/siparis/odeme-bekleyen-siparisler', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function onay_bekleyen_siparisler()
    {
        $data = new stdClass();
        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;
        $data->siparisler = $this->siparis_model->siparisler(array('siparis.siparis_durum' => 1));

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/siparis/onay-bekleyen-siparisler', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function onaylanan_siparisler()
    {
        $data = new stdClass();
        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;
        $data->siparisler = $this->siparis_model->siparisler(array('siparis.siparis_durum' => 2));

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/siparis/onaylanan-siparisler', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function iptal_siparisler()
    {
        $data = new stdClass();
        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;
        $data->siparisler = $this->siparis_model->siparisler(array('siparis.siparis_durum' => 3, 'urunler.admin' => 1));

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/siparis/iptal-siparisler', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function siparis_detay($siparis_no)
    {
        $data = new stdClass();
        $siteayar = ayarlar();

        $siparis = $this->siparis_model->siparis(array('siparis.siparis_no' => $siparis_no));
        if (!$siparis) {
            redirect(base_url(admin_url() . 'siparisler'));
            die();
        }

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;
        $data->siparis = $siparis;

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/siparis/siparis-detay', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function siparis_duzenle($siparis_no)
    {
        if (!$_POST) {
            redirect(base_url(admin_url() . 'siparisler'));
        }

        $siparis_durum = array(
            'siparis_durum' => $this->input->post('siparis_durum'),
            'siparis_iptal' => $this->input->post('siparis_iptal'),
            'teslim_alan' => $this->input->post('teslim_alan'),
            'teslim_yeri' => $this->input->post('teslim_yeri')
        );
        $this->siparis_model->siparis_update(array('siparis_no' => $siparis_no), $siparis_durum);
        $alert = array(
            "title" => "İşlem Başarılı",
            "text" => "Sipariş Başarılı Şekilde Güncellendi",
            "type" => "success"
        );


        $this->session->set_flashdata("alert", $alert);
        redirect(base_url(admin_url() . "siparis-detay/" . $siparis_no));
        die();
    }

    public function reklam_detay($reklam_no)
    {
        $data = new stdClass();
        $siteayar = ayarlar();

        $siparis = $this->magaza_model->reklam(array('reklam.reklam_no' => $reklam_no));
        if (!$siparis) {
            redirect(base_url(admin_url() . 'reklam-siparisler'));
            die();
        }

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;
        $data->reklam = $siparis;

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/siparis/reklam-detay', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function reklam_duzenle($reklam_no)
    {
        if (!$_POST) {
            redirect(base_url(admin_url() . 'reklam-siparisler'));
        }
        $siparis = $this->magaza_model->reklam(array('reklam.reklam_no' => $reklam_no));

        $siparis_durum = array('reklam_durum' => $this->input->post('siparis_durum'), 'reklam_bitis' => $this->input->post('reklam_bitis'));

        $this->magaza_model->reklam_update(array('reklam_no' => $reklam_no), $siparis_durum);

        if ($siparis->reklam_turu == 'anasayfa') {
            $this->magaza_model->urun_update(array('urun_id' => $siparis->urun_id), array('urun_populer' => $this->input->post('siparis_durum')));
        } elseif ($siparis->reklam_turu == 'kategori') {
            $this->magaza_model->urun_update(array('urun_id' => $siparis->urun_id), array('urun_populer_kat' => $this->input->post('siparis_durum')));
        }
        $alert = array(
            "title" => "İşlem Başarılı",
            "text" => "Reklam Sipariş Başarılı Şekilde Güncellendi",
            "type" => "success"
        );


        $this->session->set_flashdata("alert", $alert);
        redirect(base_url(admin_url() . "reklam-detay/" . $reklam_no));
        die();
    }

    public function ilanlar()
    {
        $data = new stdClass();
        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;
        $data->urunler = $this->db->where(['admin' => 0, 'urun_durum' => 1])->get('urunler')->result();

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/ilan/ilanlar', $data);
        $this->load->view('yonetim/inc/_footer');
    }
}
