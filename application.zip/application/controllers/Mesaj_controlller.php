<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Mesaj_controlller extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        date_default_timezone_set('Europe/Istanbul');
        if (!aktif_kullanici()) {
            redirect(base_url('giris-yap'));
        }
    }

    /**
     * Mesajlaşma Sistemi
     */
    public function mesajlar()
    {
        $data = new stdClass();
        $kullanici = kullanicicek();
        $data->title = "Gelen Mesajlar";
        $data->description = "";
        $data->keywords = "";
        $data->ayarlar = ayarlar();
        $data->kullanici = $kullanici;
        $data->mesaj = $this->destek_model->mesaj(array('alan_id' => $kullanici->kullanici_id, 'mesaj_tur' => 1));
        $data->magaza = $this->magaza_model->magaza(array('kullanici_id' => $kullanici->kullanici_id));

        $this->load->view('inc/_header', $data);
        $this->load->view('kpanel/mesaj/index', $data);
        $this->load->view('inc/_footer', $data);
    }

    public function giden_mesajlar()
    {
        $data = new stdClass();
        $kullanici = kullanicicek();
        $data->title = "Giden Mesajlar";
        $data->description = "";
        $data->keywords = "";
        $data->ayarlar = ayarlar();
        $data->kullanici = $kullanici;
        $data->mesaj = $this->destek_model->mesaj(array('alan_id' => $kullanici->kullanici_id, 'mesaj_tur' => 0));
        $data->magaza = $this->magaza_model->magaza(array('kullanici_id' => $kullanici->kullanici_id));

        $this->load->view('inc/_header', $data);
        $this->load->view('kpanel/mesaj/giden-mesajlar', $data);
        $this->load->view('inc/_footer', $data);
    }

    public function yeni_mesaj($magaza_uniq)
    {
        $magaza = magaza_bilgi($magaza_uniq);

        if (!$magaza) {
            redirect(base_url());
            die();
        }
        $data = new stdClass();
        $kullanici = kullanicicek();
        $data->title = "Yeni Mesaj";
        $data->description = "";
        $data->keywords = "";
        $data->ayarlar = ayarlar();
        $data->kullanici = $kullanici;
        $data->alici = $magaza;
        $data->magaza = $this->magaza_model->magaza(array('kullanici_id' => $kullanici->kullanici_id));

        $this->load->view('inc/_header', $data);
        $this->load->view('kpanel/mesaj/yeni', $data);
        $this->load->view('inc/_footer', $data);
    }

    public function yeni_mesaj_post($magaza_uniq)
    {
        $magaza = magaza_bilgi($magaza_uniq);
        $kullanici = kullanicicek();

        if (!$magaza) {
            redirect(base_url());
            die();
        }

        if (!$this->input->post('mesaj')) {
            $alert = array(
                "title" => "Uyarı!",
                "text" => "Lütfen Mesaj Alanını Boş Bırakmayın.",
                "type" => "warning"
            );

            $this->session->set_flashdata("alert", $alert);
            redirect(base_url('yeni-mesaj/' . $magaza_uniq));
            die();
        }

        if ($kullanici->kullanici_id == $magaza->kullanici_id) {
            $alert = array(
                "title" => "Hata!",
                "text" => "Kendinize mesaj gönderemezsiniz!",
                "type" => "warning"
            );

            $this->session->set_flashdata("alert", $alert);
            redirect(base_url('mesajlar'));
            die();
        } else {
            $amesaj_id = $this->mesaj_model->add_amesaj();
            if ($amesaj_id) {

                $data = array(
                    'amesaj_id' => $amesaj_id,
                    'alan_id' => $magaza->magaza_id,
                    'gonderen_id' => $kullanici->kullanici_id,
                    'mesaj' => $this->input->post('mesaj'),
                    'alan_durum' => 1,
                    'gonderen_durum' => 0,
                    'mesaj_tur' => 0,
                    'uniq' => uniqid()
                );

                $this->destek_model->mesaj_add($data);

                $alert = array(
                    "title" => "Başarılı!",
                    "text" => "Mesajınız başarılı şekilde gönderildi!",
                    "type" => "success"
                );

                $this->session->set_flashdata("alert", $alert);
                redirect(base_url('mesajlar'));
                die();

            } else {
                $alert = array(
                    "title" => "Hata!",
                    "text" => "Mesaj gönderilemedi! Lütfen Tekrar Deneyin.",
                    "type" => "warning"
                );

                $this->session->set_flashdata("alert", $alert);
                redirect(base_url('mesajlar'));
                die();
            }
        }



        die();


    }

    public function mesaj($uniq)
    {
        $magaza = magaza_bilgi($uniq);

        if (!$magaza) {
            redirect(base_url());
            die();
        }
        $data = new stdClass();
        $kullanici = kullanicicek();
        $data->title = "Yeni Mesaj";
        $data->description = "";
        $data->keywords = "";
        $data->ayarlar = ayarlar();
        $data->kullanici = $kullanici;
        $data->alici = $magaza;
        $data->magaza = $this->magaza_model->magaza(array('kullanici_id' => $kullanici->kullanici_id));

        $this->load->view('inc/_header', $data);
        $this->load->view('kpanel/mesaj/yeni', $data);
        $this->load->view('inc/_footer', $data);
    }
}