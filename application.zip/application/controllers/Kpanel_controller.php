<?php
defined('BASEPATH') or exit('No direct script access allowed');

class kpanel_controller extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        date_default_timezone_set('Europe/Istanbul');
        if (!aktif_kullanici()) {
            redirect(base_url('giris-yap'));
        }
    }

    /**
     * Hesabım Fonksiyonları
     */
    public function hesabim()
    {
        $data = new stdClass();
        $kullanici = kullanicicek();
        $data->title = "Hesabım";
        $data->description = "";
        $data->keywords = "";
        $data->ayarlar = ayarlar();
        $data->kullanici = $kullanici;
        $data->siparislerim = $this->siparis_model->siparis_5(array('siparis.kullanici_id' => $kullanici->kullanici_id, 'urunler.admin' => 1));
        $data->siparis_say = siparis_say($kullanici->kullanici_id);
        $data->destek_say = destek_say($kullanici->kullanici_id);

        // Gold Alım - Satım

        $data->bekleyen_satislarim = $this->siparis_model->siteye_sattiklarim_getir(['user_id' => $kullanici->kullanici_id, 'status' => 0, 'type' => 1]);
        $data->tamamlanan_satislarim = $this->siparis_model->siteye_sattiklarim_getir(['user_id' => $kullanici->kullanici_id, 'status' => 1, 'type' => 1]);
        $data->iptal_edilen_satislarim = $this->siparis_model->siteye_sattiklarim_getir(['user_id' => $kullanici->kullanici_id, 'status' => 2, 'type' => 1]);

        $data->bekleyen_alislarim = $this->siparis_model->siteye_sattiklarim_getir(['user_id' => $kullanici->kullanici_id, 'status' => 0, 'type' => 2]);
        $data->tamamlanan_alislarim = $this->siparis_model->siteye_sattiklarim_getir(['user_id' => $kullanici->kullanici_id, 'status' => 1, 'type' => 2]);
        $data->iptal_edilen_alislarim = $this->siparis_model->siteye_sattiklarim_getir(['user_id' => $kullanici->kullanici_id, 'status' => 2, 'type' => 2]);

        // sorular

        $data->sorular = $this->magaza_model->get_my_sorular($kullanici->kullanici_id);
        foreach ($data->sorular as $key => $val) {
            $data->sorular[$key]->soru_cevap = $this->magaza_model->get_soru_cevap($val->soru_id);
        }

        // destek taleplerim

        $data->taleplerim = $this->magaza_model->get_destek_taleperim($kullanici->kullanici_id);

        //para çek


        $data->odenebilir_kazanclar = !empty(odenebilir_kazanclar($kullanici->kullanici_id)) ? odenebilir_kazanclar($kullanici->kullanici_id) : '0.00';
        // profil sayılar

        $data->sattigim_gold_count = count($data->tamamlanan_satislarim);
        $data->destek_talep_count = count($data->taleplerim);
        $data->aldigim_gold_count = count($data->tamamlanan_alislarim);

        $this->load->view('inc/_header', $data);
        $this->load->view('kpanel/yeni/index', $data);
        $this->load->view('inc/_footer', $data);
    }

    public function hesabimv2()
    {
        $data = new stdClass();
        $kullanici = kullanicicek();
        $data->title = "Hesabım";
        $data->description = "";
        $data->keywords = "";
        $data->ayarlar = ayarlar();
        $data->kullanici = $kullanici;
        $data->siparislerim = $this->siparis_model->siparis_5(array('siparis.kullanici_id' => $kullanici->kullanici_id, 'urunler.admin' => 1));
        $data->siparis_say = siparis_say($kullanici->kullanici_id);
        $data->destek_say = destek_say($kullanici->kullanici_id);

        // Gold Alım - Satım

        $data->bekleyen_satislarim = $this->siparis_model->siteye_sattiklarim_getir(['user_id' => $kullanici->kullanici_id, 'status' => 0, 'type' => 1]);
        $data->tamamlanan_satislarim = $this->siparis_model->siteye_sattiklarim_getir(['user_id' => $kullanici->kullanici_id, 'status' => 1, 'type' => 1]);
        $data->iptal_edilen_satislarim = $this->siparis_model->siteye_sattiklarim_getir(['user_id' => $kullanici->kullanici_id, 'status' => 2, 'type' => 1]);

        $data->bekleyen_alislarim = $this->siparis_model->siteye_sattiklarim_getir(['user_id' => $kullanici->kullanici_id, 'status' => 0, 'type' => 2]);
        $data->tamamlanan_alislarim = $this->siparis_model->siteye_sattiklarim_getir(['user_id' => $kullanici->kullanici_id, 'status' => 1, 'type' => 2]);
        $data->iptal_edilen_alislarim = $this->siparis_model->siteye_sattiklarim_getir(['user_id' => $kullanici->kullanici_id, 'status' => 2, 'type' => 2]);

        // sorular

        $data->sorular = $this->magaza_model->get_my_sorular($kullanici->kullanici_id);
        foreach ($data->sorular as $key => $val) {
            $data->sorular[$key]->soru_cevap = $this->magaza_model->get_soru_cevap($val->soru_id);
        }

        // destek taleplerim

        $data->taleplerim = $this->magaza_model->get_destek_taleperim($kullanici->kullanici_id);

        //para çek


        $data->odenebilir_kazanclar = !empty(odenebilir_kazanclar($kullanici->kullanici_id)) ? odenebilir_kazanclar($kullanici->kullanici_id) : '0.00';
        // profil sayılar

        $data->sattigim_gold_count = count($data->tamamlanan_satislarim);
        $data->destek_talep_count = count($data->taleplerim);
        $data->aldigim_gold_count = count($data->tamamlanan_alislarim);

        $this->load->view('inc/_header', $data);
        $this->load->view('kpanel/index-yeni', $data);
        $this->load->view('inc/_footer', $data);
    }

    public function itirazlarim()
    {
        if (!$kullanici = aktif_kullanici()) {
            redirect(base_url('giris-yap'));
        }
        $data = new stdClass();

        $data->title = "Sipariş İtirazlarım";
        $data->description = "";
        $data->keywords = "";
        $data->ayarlar = ayarlar();
        $data->kullanici = $kullanici;

        $data->itirazlarim = $this->siparis_model->get_itiraz_ettiklerim($kullanici->kullanici_id);

        $this->load->view('inc/_header', $data);
        $this->load->view('kpanel/itirazlarim', $data);
        $this->load->view('inc/_footer');
    }

    public function cekilislerim()
    {
        if (!$kullanici = aktif_kullanici()) {
            redirect(base_url('giris-yap'));
        }
        if (!magaza_check()) {
            redirect(base_url('magaza-olustur'));
        }
        $data = new stdClass();

        $magaza = magaza($kullanici->kullanici_id);

        $data->cekilislerim = $this->db->where(['magaza_id' => $magaza->magaza_id])->get('cekilis')->result();
        $kullanici = kullanicicek();
        $data->title = "Hesabım";
        $data->description = "";
        $data->keywords = "";
        $data->ayarlar = ayarlar();
        $data->kullanici = $kullanici;

        $this->load->view('inc/_header', $data);
        $this->load->view('kpanel/cekilis/list', $data);
        $this->load->view('inc/_footer');
    }

    public function bakiye()
    {
        $data = new stdClass();
        $kullanici = kullanicicek();
        $data->title = "Bakiye";
        $data->description = "";
        $data->keywords = "";
        $data->ayarlar = ayarlar();
        $data->kullanici = $kullanici;

        // Gold Alım - Satım

        $data->bekleyen_satislarim = $this->siparis_model->siteye_sattiklarim_getir(['user_id' => $kullanici->kullanici_id, 'status' => 0, 'type' => 1]);
        $data->tamamlanan_satislarim = $this->siparis_model->siteye_sattiklarim_getir(['user_id' => $kullanici->kullanici_id, 'status' => 1, 'type' => 1]);
        $data->iptal_edilen_satislarim = $this->siparis_model->siteye_sattiklarim_getir(['user_id' => $kullanici->kullanici_id, 'status' => 2, 'type' => 1]);

        $data->bekleyen_alislarim = $this->siparis_model->siteye_sattiklarim_getir(['user_id' => $kullanici->kullanici_id, 'status' => 0, 'type' => 2]);
        $data->tamamlanan_alislarim = $this->siparis_model->siteye_sattiklarim_getir(['user_id' => $kullanici->kullanici_id, 'status' => 1, 'type' => 2]);
        $data->iptal_edilen_alislarim = $this->siparis_model->siteye_sattiklarim_getir(['user_id' => $kullanici->kullanici_id, 'status' => 2, 'type' => 2]);

        // sorular

        $data->sorular = $this->magaza_model->get_my_sorular($kullanici->kullanici_id);
        foreach ($data->sorular as $key => $val) {
            $data->sorular[$key]->soru_cevap = $this->magaza_model->get_soru_cevap($val->soru_id);
        }

        // destek taleplerim

        $data->taleplerim = $this->magaza_model->get_destek_taleperim($kullanici->kullanici_id);

        //para çek


        $data->odenebilir_kazanclar = !empty(odenebilir_kazanclar($kullanici->kullanici_id)) ? odenebilir_kazanclar($kullanici->kullanici_id) : '0.00';
        // profil sayılar

        $data->sattigim_gold_count = count($data->tamamlanan_satislarim);
        $data->destek_talep_count = count($data->taleplerim);
        $data->aldigim_gold_count = count($data->tamamlanan_alislarim);

        $this->load->view('inc/_header', $data);
        $this->load->view('kpanel/yeni/bakiye', $data);
        $this->load->view('inc/_footer', $data);
    }

    public function satislar()
    {
        $data = new stdClass();
        $kullanici = kullanicicek();
        $data->title = "Satışlarım";
        $data->description = "";
        $data->keywords = "";
        $data->ayarlar = ayarlar();
        $data->kullanici = kullanicicek();

        // Gold Alım - Satım

        $data->bekleyen_satislarim = $this->siparis_model->siteye_sattiklarim_getir(['user_id' => $kullanici->kullanici_id, 'status' => 0, 'type' => 1]);
        $data->tamamlanan_satislarim = $this->siparis_model->siteye_sattiklarim_getir(['user_id' => $kullanici->kullanici_id, 'status' => 1, 'type' => 1]);
        $data->iptal_edilen_satislarim = $this->siparis_model->siteye_sattiklarim_getir(['user_id' => $kullanici->kullanici_id, 'status' => 2, 'type' => 1]);

        $data->bekleyen_alislarim = $this->siparis_model->siteye_sattiklarim_getir(['user_id' => $kullanici->kullanici_id, 'status' => 0, 'type' => 2]);
        $data->tamamlanan_alislarim = $this->siparis_model->siteye_sattiklarim_getir(['user_id' => $kullanici->kullanici_id, 'status' => 1, 'type' => 2]);
        $data->iptal_edilen_alislarim = $this->siparis_model->siteye_sattiklarim_getir(['user_id' => $kullanici->kullanici_id, 'status' => 2, 'type' => 2]);

        // sorular

        $data->sorular = $this->magaza_model->get_my_sorular($kullanici->kullanici_id);
        foreach ($data->sorular as $key => $val) {
            $data->sorular[$key]->soru_cevap = $this->magaza_model->get_soru_cevap($val->soru_id);
        }

        // destek taleplerim

        $data->taleplerim = $this->magaza_model->get_destek_taleperim($kullanici->kullanici_id);

        //para çek


        $data->odenebilir_kazanclar = !empty(odenebilir_kazanclar($kullanici->kullanici_id)) ? odenebilir_kazanclar($kullanici->kullanici_id) : '0.00';
        // profil sayılar

        $data->sattigim_gold_count = count($data->tamamlanan_satislarim);
        $data->destek_talep_count = count($data->taleplerim);
        $data->aldigim_gold_count = count($data->tamamlanan_alislarim);

        $this->load->view('inc/_header', $data);
        $this->load->view('kpanel/yeni/gold-al-sat', $data);
        $this->load->view('inc/_footer', $data);
    }

    public function bekleyen_satislarim()
    {
        $user = aktif_kullanici();
        if ($user) {
            $data = $this->siparis_model->siteye_sattiklarim_getir(['user_id' => $user->kullanici_id, 'status' => 0, 'type' => 1]);
            echo json_encode(array('status' => true, 'data' => $data));
            die();
        } else {
            echo json_encode(array('status' => false, 'message' => 'İşlem Yapabilmek İçin Giriş Yapmalısınız.'));
            die();
        }
    }

    public function tamamlanan_satislarim()
    {
        $user = aktif_kullanici();
        if ($user) {
            $data = $this->siparis_model->siteye_sattiklarim_getir(['user_id' => $user->kullanici_id, 'status' => 1, 'type' => 1]);
            echo json_encode(array('status' => true, 'data' => $data));
            die();
        } else {
            echo json_encode(array('status' => false, 'message' => 'İşlem Yapabilmek İçin Giriş Yapmalısınız.'));
            die();
        }
    }

    public function iptal_edilen_satislarim()
    {
        $user = aktif_kullanici();
        if ($user) {
            $data = $this->siparis_model->siteye_sattiklarim_getir(['user_id' => $user->kullanici_id, 'status' => 2, 'type' => 1]);
            echo json_encode(array('status' => true, 'data' => $data));
            die();
        } else {
            echo json_encode(array('status' => false, 'message' => 'İşlem Yapabilmek İçin Giriş Yapmalısınız.'));
            die();
        }
    }

    public function bekleyen_alimlar()
    {
        $user = aktif_kullanici();
        if ($user) {
            $data = $this->siparis_model->siteye_sattiklarim_getir(['user_id' => $user->kullanici_id, 'status' => 0, 'type' => 2]);
            echo json_encode(array('status' => true, 'data' => $data));
            die();
        } else {
            echo json_encode(array('status' => false, 'message' => 'İşlem Yapabilmek İçin Giriş Yapmalısınız.'));
            die();
        }
    }

    public function tamamlanan_alimlar()
    {
        $user = aktif_kullanici();
        if ($user) {
            $data = $this->siparis_model->siteye_sattiklarim_getir(['user_id' => $user->kullanici_id, 'status' => 1, 'type' => 2]);
            echo json_encode(array('status' => true, 'data' => $data));
            die();
        } else {
            echo json_encode(array('status' => false, 'message' => 'İşlem Yapabilmek İçin Giriş Yapmalısınız.'));
            die();
        }
    }

    public function iptal_edilen_alimlar()
    {
        $user = aktif_kullanici();
        if ($user) {
            $data = $this->siparis_model->siteye_sattiklarim_getir(['user_id' => $user->kullanici_id, 'status' => 2, 'type' => 2]);
            echo json_encode(array('status' => true, 'data' => $data));
            die();
        } else {
            echo json_encode(array('status' => false, 'message' => 'İşlem Yapabilmek İçin Giriş Yapmalısınız.'));
            die();
        }
    }

    public function siparislerim()
    {
        $data = new stdClass();
        $kullanici = kullanicicek();
        $data->title = "Siparişlerim";
        $data->description = "";
        $data->keywords = "";
        $data->ayarlar = ayarlar();
        $data->kullanici = kullanicicek();

        // Gold Alım - Satım

        $data->bekleyen_satislarim = $this->siparis_model->siteye_sattiklarim_getir(['user_id' => $kullanici->kullanici_id, 'status' => 0, 'type' => 1]);
        $data->tamamlanan_satislarim = $this->siparis_model->siteye_sattiklarim_getir(['user_id' => $kullanici->kullanici_id, 'status' => 1, 'type' => 1]);
        $data->iptal_edilen_satislarim = $this->siparis_model->siteye_sattiklarim_getir(['user_id' => $kullanici->kullanici_id, 'status' => 2, 'type' => 1]);

        $data->bekleyen_alislarim = $this->siparis_model->siteye_sattiklarim_getir(['user_id' => $kullanici->kullanici_id, 'status' => 0, 'type' => 2]);
        $data->tamamlanan_alislarim = $this->siparis_model->siteye_sattiklarim_getir(['user_id' => $kullanici->kullanici_id, 'status' => 1, 'type' => 2]);
        $data->iptal_edilen_alislarim = $this->siparis_model->siteye_sattiklarim_getir(['user_id' => $kullanici->kullanici_id, 'status' => 2, 'type' => 2]);

        // sorular

        $data->sorular = $this->magaza_model->get_my_sorular($kullanici->kullanici_id);
        foreach ($data->sorular as $key => $val) {
            $data->sorular[$key]->soru_cevap = $this->magaza_model->get_soru_cevap($val->soru_id);
        }

        // destek taleplerim

        $data->taleplerim = $this->magaza_model->get_destek_taleperim($kullanici->kullanici_id);

        //para çek


        $data->odenebilir_kazanclar = !empty(odenebilir_kazanclar($kullanici->kullanici_id)) ? odenebilir_kazanclar($kullanici->kullanici_id) : '0.00';
        // profil sayılar

        $data->sattigim_gold_count = count($data->tamamlanan_satislarim);
        $data->destek_talep_count = count($data->taleplerim);
        $data->aldigim_gold_count = count($data->tamamlanan_alislarim);

        $this->load->view('inc/_header', $data);
        $this->load->view('kpanel/yeni/siparislerim', $data);
        $this->load->view('inc/_footer', $data);
    }

    public function siparis_detay($siparis_no)
    {
        $data = new stdClass();
        $kullanici = kullanicicek();

        $siparis = $this->siparis_model->siparis(array('siparis.kullanici_id' => $kullanici->kullanici_id, 'siparis.siparis_no' => $siparis_no));
        if (!$siparis) {
            redirect(base_url('siparislerim'));
            die();
        }
        $data->title = "Sipariş Detay";
        $data->description = "";
        $data->keywords = "";
        $data->ayarlar = ayarlar();
        $data->kullanici = kullanicicek();
        $data->siparis = $siparis;

        $this->load->view('inc/_header', $data);
        $this->load->view('kpanel/siparis-detay', $data);
        $this->load->view('inc/_footer', $data);
    }

    public function sat_detay($siparis_no)
    {
        $data = new stdClass();
        $kullanici = kullanicicek();

        $siparis = $this->siparis_model->siparis_satis(array('siparis_satis.kullanici_id' => $kullanici->kullanici_id, 'siparis_satis.siparis_no' => $siparis_no));
        if (!$siparis) {
            redirect(base_url('satislar'));
            die();
        }
        $data->title = "Satış Detay";
        $data->description = "";
        $data->keywords = "";
        $data->ayarlar = ayarlar();
        $data->kullanici = kullanicicek();
        $data->siparis = $siparis;

        $this->load->view('inc/_header', $data);
        $this->load->view('kpanel/sat-detay', $data);
        $this->load->view('inc/_footer', $data);
    }

    public function fatura_detay($siparis_no)
    {
        $data = new stdClass();
        $kullanici = kullanicicek();

        $siparis = $this->siparis_model->siparis(array('siparis.kullanici_id' => $kullanici->kullanici_id, 'siparis.siparis_no' => $siparis_no, 'siparis.siparis_durum' => 2));
        if (!$siparis) {
            redirect(base_url('siparislerim'));
            die();
        }
        $data->title = "Fatura";
        $data->description = "";
        $data->keywords = "";
        $data->ayarlar = ayarlar();
        $data->kullanici = kullanicicek();
        $data->siparis = $siparis;

        $this->load->view('inc/_header', $data);
        $this->load->view('kpanel/fatura', $data);
        $this->load->view('inc/_footer', $data);
    }

    public function siparis_teslimat_onay($siparis_no)
    {
        $data = new stdClass();

        $kullanici = kullanicicek();
        $siparis = $this->siparis_model->siparis(array('siparis.kullanici_id' => $kullanici->kullanici_id, 'siparis.siparis_no' => $siparis_no));
        if (!$siparis) {
            //redirect(base_url('siparislerim'));
            $data->message = 'Yapmaya çalıştığınız işlem geçerli değildir!!';
            $data->success = false;
            echo json_encode($data);
            die();
        }
        $teslimat_durumu = $this->input->post('teslimat_durumu');

        if ($teslimat_durumu == 1) {
            // Teslimat Onaylama ve satıcı bakiye yükleme bölümü
            $magaza_bilgi = magaza_bilgi($siparis->magaza);
            $satici_bilgi = kullanici_bilgi($magaza_bilgi->kullanici_id);

            $kategori_id = json_decode($siparis->kategori_json)[0];

            $category = $this->home_model->kategoricek(array('kategori_id' => $kategori_id));

            $komisyon_tutar = kategori_komisyon_hesap($siparis->siparis_tutar, $category->komisyon);

            $satici_odenecek_tutar = $siparis->siparis_tutar - $komisyon_tutar;
            $satici_odenecek_tutar = number_format($satici_odenecek_tutar, 2);

            $satici_arr = [
                'bakiye' => number_format($satici_bilgi->bakiye + $satici_odenecek_tutar, 2)
            ];

            $this->siparis_model->update_bakiye(array('kullanici_id' => $satici_bilgi->kullanici_id), $satici_arr);
            $this->siparis_model->siparis_update(array('siparis_no' => $siparis_no, 'kullanici_id' => $kullanici->kullanici_id), array('siparis_durum' => 2));
            /*$alert = array(
                "title" => "Başarılı!",
                "text" => "Teslimatı Onayladınız.",
                "type" => "success"
            );*/
            //$this->session->set_flashdata("alert", $alert);
            $data->url = base_url('siparis-detay/' . $siparis_no);
            $data->success = true;
        } elseif ($teslimat_durumu == 2) {
            if ($this->siparis_model->teslimat($siparis_no)) {
                $data->message = 'Bu Sipariş İçin Zaten İtiraz Talebiniz Bulunmaktadır!!';
                $data->success = false;
                echo json_encode($data);
                die();
            }
            // Teslimat İtiraz Kısmı
            $teslimat_data = array(
                'kullanici_id' => $kullanici->kullanici_id,
                'siparis_no' => $siparis_no,
                'teslimat_durum' => 0,
                'teslimat_uniq' => uniqid()
            );
            $this->siparis_model->teslimat_add($teslimat_data);
            $last_id = $this->db->insert_id();
            $mesaj = array(
                'mesaj_gonderen' => $kullanici->kullanici_id,
                'mesaj' => htmlspecialchars($this->input->post('mesaj')),
                'teslimat_id' => $last_id
            );
            $this->siparis_model->mesaj_add($mesaj);

            $alert = array(
                "title" => "Başarılı!",
                "text" => "Teslimat Onaylanmadı. Destek için yeni rapor oluşturuldu",
                "type" => "success"
            );
            //$this->session->set_flashdata("alert", $alert);
            $data->url = base_url('siparis-detay/' . $siparis_no);
            $data->success = true;
            //die();
        } else {
            $alert = array(
                "title" => "Hata!",
                "text" => "Lütfen teslimat durumu seçin",
                "type" => "warning"
            );
            //$this->session->set_flashdata("alert", $alert);
            //redirect(base_url('siparis-detay/' . $siparis_no));
            //die();
            $data->success = false;
            $data->message = 'Teslimat Onaylanırken Bir Hata Meydana Geldi Lütfen Daha Sonra Tekrar Deneyiniz!!';
        }
        echo json_encode($data);
    }

    public function teslimat($siparis_no)
    {

        $teslimat = $this->siparis_model->teslimat_row(array('siparis_no' => $siparis_no));
        if (!$teslimat) {
            redirect(base_url('siparislerim'));
            die();
        }
        $kullanici = kullanicicek();
        $data = new stdClass();
        $data->title = "Teslimat";
        $data->description = "";
        $data->keywords = "";
        $data->ayarlar = ayarlar();
        $data->kullanici = kullanicicek();
        $data->teslimat = $teslimat;
        $data->siparis = $this->siparis_model->siparis(array('siparis.siparis_no' => $teslimat->siparis_no));
        $data->mesajlar = $this->siparis_model->mesajlar(array('mesaj.teslimat_id' => $teslimat->teslimat_id));

        $this->load->view('inc/_header', $data);
        $this->load->view('kpanel/teslimat', $data);
        $this->load->view('inc/_footer', $data);
    }

    public function teslimat_cevap($siparis_no)
    {
        $teslimat = $this->siparis_model->teslimat_row(array('siparis_no' => $siparis_no));
        if (!$teslimat) {
            redirect(base_url('itirazlarim'));
            die();
        }
        $mesaj = $this->input->post('cevap');
        $teslimat_id = $teslimat->teslimat_id;
        $kullanici_id = kullanicicek()->kullanici_id;

        $arr = [
            'teslimat_id' => $teslimat_id,
            'mesaj_gonderen' => $kullanici_id,
            'mesaj' => $mesaj,
            'mesaj_zaman' => date('Y-m-d H:i:s')
        ];
        $this->db->set($arr)->insert('mesaj');

        $this->db->where(['siparis_no' => $siparis_no])->set(['teslimat_durum' => 0])->update('teslimat');

        $alert = array(
            "title" => "Başarılı!",
            "text" => "Cevabınız Başarılı Bir Şekilde Gönderildi",
            "type" => "success"
        );
        $this->session->set_flashdata("alert", $alert);
        redirect(base_url('teslimat/' . $siparis_no));
        die();
    }

    public function yorum_yap($siparis_no)
    {
        $kullanici = kullanicicek();
        $siparis = $this->siparis_model->siparis(array('siparis.kullanici_id' => $kullanici->kullanici_id, 'siparis.siparis_no' => $siparis_no));
        if (!$siparis) {
            redirect(base_url('siparislerim'));
            die();
        }

        if (yorum_kontrol($kullanici->kullanici_id, $siparis->siparis_no) != 0) {
            $alert = array(
                "title" => "Hata!",
                "text" => "Daha önce bu firmaya yorum yaptınız!",
                "type" => "error"
            );
            $this->session->set_flashdata("alert", $alert);
            redirect(base_url('siparislerim'));
            die();
        }

        if (!$this->input->post('puan')) {
            $alert = array(
                "title" => "Hata!",
                "text" => "Lütfen puan seçin!",
                "type" => "warning"
            );
            $this->session->set_flashdata("alert", $alert);
            redirect(base_url('siparislerim'));
            die();
        }

        if ($this->input->post('puan') == 1) {
            $puan = 1;
        } elseif ($this->input->post('puan') == 2) {
            $puan = 2;
        } elseif ($this->input->post('puan') == 3) {
            $puan = 3;
        } elseif ($this->input->post('puan') == 4) {
            $puan = 4;
        } elseif ($this->input->post('puan') == 5) {
            $puan = 5;
        } else {
            $alert = array(
                "title" => "Hata!",
                "text" => "Lütfen puan seviyesini değiştirmeyin!!",
                "type" => "error"
            );
            $this->session->set_flashdata("alert", $alert);
            redirect(base_url('siparislerim'));
            die();
        }

        $data = array(
            'kullanici_id' => $kullanici->kullanici_id,
            'siparis_no' => $siparis_no,
            'magaza_id' => $siparis->magaza_id,
            'urun_id' => $siparis->urun_id,
            'yorum_puan' => $puan,
            'yorum_detay' => $this->input->post('yorum'),
            'yorum_durum' => 0

        );

        $this->siparis_model->yorum_add($data);

        $alert = array(
            "title" => "Başarılı!",
            "text" => "Değerlendirme başarılı şekilde yapıldı. En kısa zamanda onaylanacaktır.",
            "type" => "success"
        );
        $this->session->set_flashdata("alert", $alert);
        redirect(base_url('siparislerim'));
        die();
    }

    public function hesapayar()
    {
        $data = new stdClass();

        $data->title = "Hesap Ayarları";
        $data->description = "";
        $data->keywords = "";
        $data->ayarlar = ayarlar();
        $data->kullanici = kullanicicek();
        $data->iller = $this->magaza_model->iller();

        // Gold Alım - Satım

        $data->bekleyen_satislarim = $this->siparis_model->siteye_sattiklarim_getir(['user_id' => $kullanici->kullanici_id, 'status' => 0, 'type' => 1]);
        $data->tamamlanan_satislarim = $this->siparis_model->siteye_sattiklarim_getir(['user_id' => $kullanici->kullanici_id, 'status' => 1, 'type' => 1]);
        $data->iptal_edilen_satislarim = $this->siparis_model->siteye_sattiklarim_getir(['user_id' => $kullanici->kullanici_id, 'status' => 2, 'type' => 1]);

        $data->bekleyen_alislarim = $this->siparis_model->siteye_sattiklarim_getir(['user_id' => $kullanici->kullanici_id, 'status' => 0, 'type' => 2]);
        $data->tamamlanan_alislarim = $this->siparis_model->siteye_sattiklarim_getir(['user_id' => $kullanici->kullanici_id, 'status' => 1, 'type' => 2]);
        $data->iptal_edilen_alislarim = $this->siparis_model->siteye_sattiklarim_getir(['user_id' => $kullanici->kullanici_id, 'status' => 2, 'type' => 2]);

        // sorular

        $data->sorular = $this->magaza_model->get_my_sorular($kullanici->kullanici_id);
        foreach ($data->sorular as $key => $val) {
            $data->sorular[$key]->soru_cevap = $this->magaza_model->get_soru_cevap($val->soru_id);
        }

        // destek taleplerim

        $data->taleplerim = $this->magaza_model->get_destek_taleperim($kullanici->kullanici_id);

        //para çek


        $data->odenebilir_kazanclar = !empty(odenebilir_kazanclar($kullanici->kullanici_id)) ? odenebilir_kazanclar($kullanici->kullanici_id) : '0.00';
        // profil sayılar

        $data->sattigim_gold_count = count($data->tamamlanan_satislarim);
        $data->destek_talep_count = count($data->taleplerim);
        $data->aldigim_gold_count = count($data->tamamlanan_alislarim);

        $this->load->view('inc/_header', $data);
        $this->load->view('kpanel/yeni/hesapayar', $data);
        $this->load->view('inc/_footer');
    }

    public function destek_taleplerim()
    {
        $data = new stdClass();
        $kullanici = kullanicicek();

        /*$config = array();
        $config["base_url"] = base_url('destek-taleplerim');
        $config["total_rows"] = destek_say($kullanici->kullanici_id);
        $config["per_page"] = 12;
        $config["uri_segment"] = 2;


        $config['first_link'] = '&laquo';
        $config['last_link'] = '&raquo';
        $config['attributes'] = array('class' => 'page-link');

        $config['full_tag_open'] = "<ul class='pagination justify-content-center'>";
        $config['full_tag_close'] = "</ul>";
        $config['num_tag_open'] = '<li class="page-item">';
        $config['num_tag_close'] = '</li>';
        $config['cur_tag_open'] = '<li class="page-item active"><a class="page-link" href="#">';
        $config['cur_tag_close'] = "</a></li>";

        $config['next_link'] = 'İleri';
        $config['next_tag_open'] = '<li class="page-item">';
        $config['next_tagl_close'] = "</li>";

        $config['prev_link'] = 'Geri';
        $config['prev_tag_open'] = '<li class="page-item">';
        $config['prev_tagl_close'] = "</li>";

        $config['first_tag_open'] = '<li class="page-item">';
        $config['first_tagl_close'] = "</li>";
        $config['last_tag_open'] = '<li class="page-item">';
        $config['last_tagl_close'] = "</li>";

        $this->pagination->initialize($config);

        $page = ($this->uri->segment(2)) ? $this->uri->segment(2) : 0;
        $data->links = $this->pagination->create_links();
        $data->destek = $this->siparis_model->destek_sayfalama(array('talep.kullanici_id' => $kullanici->kullanici_id), $config["per_page"], $page);*/

        $data->title = "Destek Taleplerim";
        $data->description = "";
        $data->keywords = "";
        $data->ayarlar = ayarlar();
        $data->kullanici = kullanicicek();

        // Gold Alım - Satım

        $data->bekleyen_satislarim = $this->siparis_model->siteye_sattiklarim_getir(['user_id' => $kullanici->kullanici_id, 'status' => 0, 'type' => 1]);
        $data->tamamlanan_satislarim = $this->siparis_model->siteye_sattiklarim_getir(['user_id' => $kullanici->kullanici_id, 'status' => 1, 'type' => 1]);
        $data->iptal_edilen_satislarim = $this->siparis_model->siteye_sattiklarim_getir(['user_id' => $kullanici->kullanici_id, 'status' => 2, 'type' => 1]);

        $data->bekleyen_alislarim = $this->siparis_model->siteye_sattiklarim_getir(['user_id' => $kullanici->kullanici_id, 'status' => 0, 'type' => 2]);
        $data->tamamlanan_alislarim = $this->siparis_model->siteye_sattiklarim_getir(['user_id' => $kullanici->kullanici_id, 'status' => 1, 'type' => 2]);
        $data->iptal_edilen_alislarim = $this->siparis_model->siteye_sattiklarim_getir(['user_id' => $kullanici->kullanici_id, 'status' => 2, 'type' => 2]);

        // sorular

        $data->sorular = $this->magaza_model->get_my_sorular($kullanici->kullanici_id);
        foreach ($data->sorular as $key => $val) {
            $data->sorular[$key]->soru_cevap = $this->magaza_model->get_soru_cevap($val->soru_id);
        }

        // destek taleplerim

        $data->taleplerim = $this->magaza_model->get_destek_taleperim($kullanici->kullanici_id);

        //para çek


        $data->odenebilir_kazanclar = !empty(odenebilir_kazanclar($kullanici->kullanici_id)) ? odenebilir_kazanclar($kullanici->kullanici_id) : '0.00';
        // profil sayılar

        $data->sattigim_gold_count = count($data->tamamlanan_satislarim);
        $data->destek_talep_count = count($data->taleplerim);
        $data->aldigim_gold_count = count($data->tamamlanan_alislarim);

        $this->load->view('inc/_header', $data);
        $this->load->view('kpanel/yeni/destek-taleplerim', $data);
        $this->load->view('inc/_footer', $data);
    }

    public function destek_olustur()
    {
        $data = new stdClass();
        $kullanici = kullanicicek();
        $data->title = "Destek Oluştur";
        $data->description = "";
        $data->keywords = "";
        $data->ayarlar = ayarlar();
        $data->kullanici = $kullanici;

        $this->load->view('inc/_header', $data);
        $this->load->view('kpanel/destek/destek-olustur-yeni', $data);
        $this->load->view('inc/_footer', $data);
    }

    public function destek_olustur_yeni()
    {
        $data = new stdClass();
        $kullanici = kullanicicek();
        $data->title = "Destek Oluştur";
        $data->description = "";
        $data->keywords = "";
        $data->ayarlar = ayarlar();
        $data->kullanici = $kullanici;

        $this->load->view('inc/_header', $data);
        $this->load->view('kpanel/destek/destek-olustur-yeni', $data);
        $this->load->view('inc/_footer', $data);
    }

    public function destekolustur()
    {
        $kullanici = kullanicicek();
        if (!$this->input->post('baslik') || !$this->input->post('detay')) {
            $alert = array(
                "title" => "Hata!",
                "text" => "Lütfen Boş Alan Bırakmayın!",
                "type" => "warning"
            );

            $this->session->set_flashdata("alert", $alert);
            redirect(base_url("destek-olustur"));
            die();
        }

        // Sipariş No Kontrolü
        /*if ($this->input->post('siparis_no')) {
            $siparis = $this->siparis_model->siparis(array('siparis.siparis_no' => $this->input->post('siparis_no'), 'siparis.kullanici_id' => $kullanici->kullanici_id));
            if (!$siparis) {
                $alert = array(
                    "title" => "Hata!",
                    "text" => "Yazmış olduğunuz sipariş numarasına ait bir sipariş bulunamadı!",
                    "type" => "error"
                );
                $this->session->set_flashdata("alert", $alert);
                redirect(base_url('destek-olustur'));
                die();
            }
        }*/

        $data = array(
            'kullanici_id' => $kullanici->kullanici_id,
            'siparis_no' => $this->input->post('siparis_no'),
            'talep' => $this->input->post('baslik'),
            'talep_aciklama' => $this->input->post('detay'),
            'talep_no' => uretken(13),
            'talep_durum' => 0
        );

        $this->siparis_model->talep_add($data);

        $alert = array(
            "title" => "Başarılı!",
            "text" => "Destek Talebi Oluşturuldu.",
            "type" => "success"
        );
        $this->session->set_flashdata("alert", $alert);
        redirect(base_url('destek-olustur'));
        die();
    }

    public function destek_detay($destek_no)
    {
        $data = new stdClass();
        $kullanici = kullanicicek();
        $destek = $this->siparis_model->destek(array('kullanici.kullanici_id' => $kullanici->kullanici_id, 'talep_no' => $destek_no));
        if (!$destek) {
            redirect(base_url('destek-taleplerim'));
            die();
        }
        if (@$_POST["cevap"] != Null) {
            $data = array(
                'cevap_user' => $kullanici->kullanici_id,
                'cevap' => $this->input->post('cevap'),
                'cevap_tarih' => date("Y-m-d H:i:s"),
                'cevap_ticket' => $destek->talep_id
            );

            $this->siparis_model->cevap_add($data);

            $data = array(
                "talep_durum" => "0"
            );
            $insert = $this->siparis_model->talep_update(array('talep_id' => $destek->talep_id), $data);
            header("Refresh:0");
            exit;
        }

        $data->title = "Destek Detay";
        $data->description = "";
        $data->keywords = "";
        $data->ayarlar = ayarlar();
        $data->kullanici = kullanicicek();
        $data->destek = $destek;

        $this->load->view('inc/_header', $data);
        $this->load->view('kpanel/destek/destek-detay-yeni', $data);
        $this->load->view('inc/_footer', $data);
    }

    public function destek_detay_yeni($destek_no)
    {
        $data = new stdClass();
        $kullanici = kullanicicek();
        $destek = $this->siparis_model->destek(array('kullanici.kullanici_id' => $kullanici->kullanici_id, 'talep_no' => $destek_no));
        if (!$destek) {
            redirect(base_url('destek-taleplerim'));
            die();
        }
        if (@$_POST["cevap"] != Null) {
            $data = array(
                'cevap_user' => $kullanici->kullanici_id,
                'cevap' => $this->input->post('cevap'),
                'cevap_tarih' => date("Y-m-d H:i:s"),
                'cevap_ticket' => $destek->talep_id
            );

            $this->siparis_model->cevap_add($data);

            $data = array(
                "talep_durum" => "0"
            );
            $insert = $this->siparis_model->talep_update(array('talep_id' => $destek->talep_id), $data);
            header("Refresh:0");
            exit;
        }

        $data->title = "Destek Detay";
        $data->description = "";
        $data->keywords = "";
        $data->ayarlar = ayarlar();
        $data->kullanici = kullanicicek();
        $data->destek = $destek;

        $this->load->view('inc/_header', $data);
        $this->load->view('kpanel/destek/destek-detay-yeni', $data);
        $this->load->view('inc/_footer', $data);
    }

    public function sifre_degistir()
    {
        if (!$_POST) {
            redirect(base_url());
        }

        $kullanici = kullanicicek();
        $where = $this->destek_model->kullaniciget(array("kullanici_id" => $kullanici->kullanici_id));
        $this->load->library("form_validation");

        $this->form_validation->set_rules("eski", "Eski Şifre", "required|trim");
        $this->form_validation->set_rules("yeni", "Yeni Şifre", "required|trim");
        $this->form_validation->set_rules("tekrar", "Yeni Şifre Tekrar", "required|trim");

        $this->form_validation->set_message(
            array(
                "required" => "{field} Boş Bırakılamaz!",
            )
        );

        $validat = $this->form_validation->run();

        if ($validat) {

            $eskisifre = htmlspecialchars($this->input->post("eski"));
            $yenisifre = htmlspecialchars($this->input->post("yeni"));
            $yenitekrar = htmlspecialchars($this->input->post("tekrar"));

            if (!password_verify($eskisifre, $kullanici->kullanici_sifre)) {
                $alert = array(
                    "title" => "Hata!",
                    "text" => "Eski Şifreniz Doğru Değil!",
                    "type" => "error"
                );

                $this->session->set_flashdata("alert", $alert);
                redirect(base_url("hesap-ayarlari"));
                die();
            }

            if ($yenisifre != $yenitekrar) {
                $alert = array(
                    "title" => "Hata!",
                    "text" => "Yeni Şifreler Uyuşmuyor!",
                    "type" => "error"
                );

                $this->session->set_flashdata("alert", $alert);
                redirect(base_url("hesap-ayarlari"));
                die();
            }

            if (strlen($yenisifre) < 6) {
                $alert = array(
                    "title" => "Hata!",
                    "text" => "Yeni Şifreniz 6 Karakterden Küçük Olamaz!",
                    "type" => "error"
                );

                $this->session->set_flashdata("alert", $alert);
                redirect(base_url("hesap-ayarlari"));
                die();
            }

            $insert = $this->destek_model->kullaniciupdate(
                array("kullanici_id" => $kullanici->kullanici_id),
                array(
                    "kullanici_sifre " => password_hash($yenisifre, PASSWORD_DEFAULT),
                )
            );

            $alert = array(
                "title" => "Başarılı!",
                "text" => "Şifreniz Başarılı Şekilde Güncellendi!",
                "type" => "success"
            );

            $this->session->set_flashdata("alert", $alert);
            redirect(base_url("hesap-ayarlari"));
        } else {
            $alert = array(
                "title" => "Hata!",
                "text" => "Lütfen Boş Alan Bırakmayın!",
                "type" => "error"
            );

            $this->session->set_flashdata("alert", $alert);
            redirect(base_url("hesap-ayarlari"));
        }
    }

    public function sendmgz()
    {
        $kullanici = kullanicicek();

        if (!$_POST) {
            redirect(base_url());
        }

        $phone = $this->input->post("phone");

        function generateRandomStringx($length = 10)
        {
            $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
            $charactersLength = strlen($characters);
            $randomString = '';
            for ($i = 0; $i < $length; $i++) {
                $randomString .= $characters[rand(0, $charactersLength - 1)];
            }
            return $randomString;
        }

        $_SESSION["magazatel"] = $phone;
        $_SESSION["magazasms"] = substr(number_format(time() * rand(), 0, '', ''), 0, 6);
        $ayarlar = ayarlar();
        $username = $ayarlar->netgsm_user;
        $pass = $ayarlar->netgsm_pass;
        $header = $ayarlar->netgsm_header;

        $startdate = date('d.m.Y H:i');
        $startdate = str_replace('.', '', $startdate);
        $startdate = str_replace(':', '', $startdate);
        $startdate = str_replace(' ', '', $startdate);

        $stopdate = date('d.m.Y H:i', strtotime('+1 day'));
        $stopdate = str_replace('.', '', $stopdate);
        $stopdate = str_replace(':', '', $stopdate);
        $stopdate = str_replace(' ', '', $stopdate);


        $msg = html_entity_decode("Herseyoyun.com mağaza oluşturma doğrulama kodunuz: " . $_SESSION["magazasms"], ENT_COMPAT, "UTF-8");
        //$msg = rawurlencode($msg);


        $gonderici = html_entity_decode($header, ENT_COMPAT, "UTF-8");
        $gonderici = rawurlencode($gonderici);

        $curl = curl_init();

        curl_setopt_array($curl, array(
                CURLOPT_URL => 'https://api.netgsm.com.tr/sms/send/get',
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => '',
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 0,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => 'POST',
                CURLOPT_POSTFIELDS => array('usercode' => $username, 'password' => $pass, 'gsmno' => $phone, 'message' => $msg, 'msgheader' => $gonderici, 'filter' => '0', 'startdate' => $startdate, 'stopdate' => $stopdate, 'dil' => 'TR'),
            )
        );

        $response = curl_exec($curl);
        curl_close($curl);

    }

    public function telefononay()
    {
        $data = new stdClass();

        if ($this->input->post("kod") != Null) {
            if ($this->input->post("kod") == $_SESSION["magazasms"]) {
                $_SESSION["magazadog"] = "1";
                $data->status = [
                    'status' => 'success',
                    'message' => 'Doğrulama İşlemi Başarılı Bir Şekilde Gerçekleştirildi.',
                ];
                print_r(json_encode($data));
                die();
            } else {
                $data->status = [
                    'status' => 'error',
                    'message' => 'Lütfen Doğrulama Kodunu Doğru Giriniz!.',
                ];
                print_r(json_encode($data));
                die();
            }
        } else {
            $data->status = [
                'status' => 'error',
                'message' => 'Lütfen Kod Alanını Boş Bırakmayın!.'
            ];
            print_r(json_encode($data));
            die();
        }
    }

    public function kullanicibilgi()
    {
        $kullanici = kullanicicek();

        if (!$_POST) {
            redirect(base_url());
        }

        if (!$this->input->post("ad") || !$this->input->post("soyad")) {
            $alert = array(
                "title" => "Hata!",
                "text" => "Ad veya Soyad boş bırakılamaz!",
                "type" => "error"
            );

            $this->session->set_flashdata("alert", $alert);
            redirect(base_url('hesap-ayarlari'));
            die();
        }
        if ($_FILES["file"]["name"] || $_FILES['banner']['name']) {
            if ($_FILES['file']['name']) {
                $file_name = seo(pathinfo($_FILES["file"]["name"], PATHINFO_FILENAME)) . "." . pathinfo($_FILES["file"]["name"], PATHINFO_EXTENSION);
                $sifrele = uniqid();
                $config["allowed_types"] = "jpg|jpeg|png";
                $config["upload_path"] = "uploads/img/";
                $config['encrypt_name'] = TRUE;
                //$config["file_name"] = $sifrele . "_" . $file_name;

                $this->load->library("upload", $config);

                $upload = $this->upload->do_upload("file");
                $uploaded_file = $this->upload->data("file_name");

                if ($upload) {
                    $uploaded_file = $this->upload->data("file_name");

                    $insert = $this->destek_model->kullaniciupdate(
                        array("kullanici_id" => $kullanici->kullanici_id),
                        array(
                            "kullanici_isim" => htmlspecialchars($this->input->post("ad")),
                            "kullanici_soyisim" => htmlspecialchars($this->input->post("soyad")),
                            "kullanici_tel" => htmlspecialchars($this->input->post("telefon")),
                            /*"kullanici_adres" => htmlspecialchars($this->input->post("adres")),
                            "kullanici_sehir" => htmlspecialchars($this->input->post("sehir")),
                            "kullanici_ilce" => htmlspecialchars($this->input->post("ilce")),*/
                            "kullanici_resim" => "uploads/img/" . $uploaded_file,
                            $kullanici->kullanici_tel == htmlspecialchars($this->input->post("telefon")) ? '' : "tel_dogrulama" => 0
                        )
                    );

                    $alert = array(
                        "title" => "İşlem Başarılı",
                        "text" => "Kullanıcı Bilgileri Başarılı Şekilde Güncellendi",
                        "type" => "success"
                    );

                    $this->session->set_flashdata("alert", $alert);
                    redirect(base_url('hesap-ayarlari'));
                    die();
                } else {

                    $alert = array(
                        "title" => "İşlem Başarısız",
                        "text" => "Fotoğraf Yüklenemedi!",
                        "type" => "error"
                    );

                    $this->session->set_flashdata("alert", $alert);
                    redirect(base_url('hesap-ayarlari'));
                    die();
                }
            }
            if ($_FILES['banner']['name']) {
                $file_names = seo(pathinfo($_FILES["banner"]["name"], PATHINFO_FILENAME)) . "." . pathinfo($_FILES["banner"]["name"], PATHINFO_EXTENSION);
                $sifrele = uniqid();
                $config["allowed_types"] = "jpg|jpeg|png";
                $config["upload_path"] = "uploads/img/";
                $config['encrypt_name'] = TRUE;
                //$config["file_name"] = $sifrele . "_" . $file_names;

                $this->load->library("upload", $config);

                $uploads = $this->upload->do_upload("banner");
                $uploaded_files = $this->upload->data("file_name");

                if ($uploads) {
                    $uploaded_files = $this->upload->data("file_name");

                    $insert = $this->destek_model->kullaniciupdate(
                        array("kullanici_id" => $kullanici->kullanici_id),
                        array(
                            "kullanici_isim" => htmlspecialchars($this->input->post("ad")),
                            "kullanici_soyisim" => htmlspecialchars($this->input->post("soyad")),
                            "kullanici_tel" => htmlspecialchars($this->input->post("telefon")),
                            /*"kullanici_adres" => htmlspecialchars($this->input->post("adres")),
                            "kullanici_sehir" => htmlspecialchars($this->input->post("sehir")),
                            "kullanici_ilce" => htmlspecialchars($this->input->post("ilce")),*/
                            "kullanici_banner" => "uploads/img/" . $uploaded_files,
                            $kullanici->kullanici_tel == htmlspecialchars($this->input->post("telefon")) ? '' : "tel_dogrulama" => 0
                        )
                    );

                    $alert = array(
                        "title" => "İşlem Başarılı",
                        "text" => "Kullanıcı Bilgileri Başarılı Şekilde Güncellendi",
                        "type" => "success"
                    );

                    $this->session->set_flashdata("alert", $alert);
                    redirect(base_url('hesap-ayarlari'));
                    die();
                } else {

                    $alert = array(
                        "title" => "İşlem Başarısız",
                        "text" => "Fotoğraf Yüklenemedi!",
                        "type" => "error"
                    );

                    $this->session->set_flashdata("alert", $alert);
                    redirect(base_url('hesap-ayarlari'));
                    die();
                }
            }
        } else {
            $insert = $this->destek_model->kullaniciupdate(
                array("kullanici_id" => $kullanici->kullanici_id),
                array(
                    "kullanici_isim" => htmlspecialchars($this->input->post("ad")),
                    "kullanici_soyisim" => htmlspecialchars($this->input->post("soyad")),
                    "kullanici_tel" => htmlspecialchars($this->input->post("telefon")),
                    /*"kullanici_adres" => htmlspecialchars($this->input->post("adres")),
                    "kullanici_sehir" => htmlspecialchars($this->input->post("sehir")),
                    "kullanici_ilce" => htmlspecialchars($this->input->post("ilce")),*/
                    "tel_dogrulama" => $kullanici->kullanici_tel == htmlspecialchars($this->input->post("telefon")) ? $kullanici->tel_dogrulama : 0
                )
            );

            $alert = array(
                "title" => "İşlem Başarılı",
                "text" => "Kullanıcı Bilgileri Başarılı Şekilde Güncellendi",
                "type" => "success"
            );

            $this->session->set_flashdata("alert", $alert);

            redirect($_SERVER['HTTP_REFERER']);

            die();
        }
    }


    public function sponsor_basvuru()
    {
        if (magaza_check()) {
            redirect(base_url());
            die();
        }
        $data = new stdClass();
        $data->title = "Sponsor Başvurusu Yap";
        $data->description = "";
        $data->keywords = "";
        $data->ayarlar = ayarlar();
        $data->kullanici = kullanicicek();
        $data->iller = $this->magaza_model->iller();
        $data->kategoriler = kategoriler();

        $this->load->view('inc/_header', $data);
        $this->load->view('kpanel/sponsor/sponsor_olustur', $data);
        $this->load->view('inc/_footer', $data);
    }

    /**
     * Mağaza Fonksiyonları
     */
    public function magaza_olustur()
    {
        $data = new stdClass();
        $data->title = "Mağaza Oluştur";
        $data->description = "";
        $data->keywords = "";
        $data->ayarlar = ayarlar();
        $data->kullanici = kullanicicek();
        $data->iller = $this->magaza_model->iller();
        if (magaza_check()) {
            $data->magaza = $this->magaza_model->magaza(array('kullanici_id' => $data->kullanici->kullanici_id));
            if ($data->magaza->magaza_durum == 0) {
                $alert = array(
                    "title" => "Bilgi!",
                    "text" => "Mağaza Oluşturma İşleminiz Henüz Tamamlanmamıştır! Lütfen Bekleyiniz!",
                    "type" => "info"
                );

                $this->session->set_flashdata("alert", $alert);
                redirect(base_url('hesabim'));
                die();
            } else if ($data->magaza->magaza_durum == 1) {
                $alert = array(
                    "title" => "Hata!",
                    "text" => "Zaten Bir Mağaza Oluşturmuşsunuz!",
                    "type" => "error"
                );

                $this->session->set_flashdata("alert", $alert);
                redirect(base_url('magazam'));
                die();
            }
        }

        $this->load->view('inc/_header', $data);
        $this->load->view('kpanel/magaza/magaza_olustur', $data);
        $this->load->view('inc/_footer', $data);
    }

    public function magazam()
    {
        if (!magaza_check()) {
            redirect(base_url('magaza-olustur'));
            die();
        }
        $data = new stdClass();
        $kullanici = kullanicicek();
        $data->title = "Mağazam";
        $data->description = "";
        $data->keywords = "";
        $data->ayarlar = ayarlar();
        $data->kullanici = $kullanici;
        $data->magaza = $this->magaza_model->magaza(array('kullanici_id' => $kullanici->kullanici_id));
        $data->aylik_kazanc = aylik_toplam_kazanc($kullanici->kullanici_id);
        $data->aylik_siparis_adet = aylik_siparis_adet($kullanici->kullanici_id);
        $data->toplam_yorum_ortalamasi = toplam_yorum_ortalamasi($kullanici->kullanici_id);
        $data->kadijoin = $this->magaza_model->getwho(array("kullanici_id" => $kullanici->kullanici_id));

        $this->load->view('inc/_header', $data);
        $this->load->view('kpanel/magaza/index', $data);
        $this->load->view('inc/_footer', $data);
    }

    public function magaza_ayar()
    {
        if (!magaza_check()) {
            redirect(base_url('magaza-olustur'));
            die();
        }
        $data = new stdClass();
        $kullanici = kullanicicek();
        $data->title = "Mağazam";
        $data->description = "";
        $data->keywords = "";
        $data->ayarlar = ayarlar();
        $data->kullanici = $kullanici;
        $data->magaza = $this->magaza_model->magaza(array('kullanici_id' => $kullanici->kullanici_id));
        $data->kadijoin = $this->magaza_model->getwho(array("kullanici_id" => $kullanici->kullanici_id));

        $this->load->view('inc/_header', $data);
        $this->load->view('kpanel/magaza/magaza-ayar', $data);
        $this->load->view('inc/_footer', $data);

    }

    public function urunler()
    {
        if (!magaza_check()) {
            redirect(base_url('magaza-olustur'));
            die();
        }
        $data = new stdClass();
        $kullanici = kullanicicek();
        $magaza_info = magaza_kbilgi($kullanici->kullanici_id);

        //$urunler = $this->magaza_model->urunler(array('kullanici_id' => $kullanici->kullanici_id));

        $config = array();
        $config["base_url"] = base_url('ilanlarim');
        $config["total_rows"] = urunsay_magza($magaza_info->magaza_id);
        $config["per_page"] = 12;
        $config["uri_segment"] = 2;


        $config['first_link'] = '&laquo';
        $config['last_link'] = '&raquo';
        $config['attributes'] = array('class' => 'page-link');

        $config['full_tag_open'] = "<ul class='pagination justify-content-center'>";
        $config['full_tag_close'] = "</ul>";
        $config['num_tag_open'] = '<li class="page-item">';
        $config['num_tag_close'] = '</li>';
        $config['cur_tag_open'] = '<li class="page-item active"><a class="page-link" href="#">';
        $config['cur_tag_close'] = "</a></li>";

        $config['next_link'] = 'İleri';
        $config['next_tag_open'] = '<li class="page-item">';
        $config['next_tagl_close'] = "</li>";

        $config['prev_link'] = 'Geri';
        $config['prev_tag_open'] = '<li class="page-item">';
        $config['prev_tagl_close'] = "</li>";

        $config['first_tag_open'] = '<li class="page-item">';
        $config['first_tagl_close'] = "</li>";
        $config['last_tag_open'] = '<li class="page-item">';
        $config['last_tagl_close'] = "</li>";

        $this->pagination->initialize($config);

        $page = ($this->uri->segment(2)) ? $this->uri->segment(2) : 0;
        $data->links = $this->pagination->create_links();
        $data->urunler = $this->magaza_model->urun_sayfalama(array("urunler.magaza_id" => $magaza_info->magaza_id), $config["per_page"], $page);

        $data->title = "Ürünlerim";
        $data->description = "";
        $data->keywords = "";
        $data->ayarlar = ayarlar();
        $data->kullanici = $kullanici;
        $data->magaza = $this->magaza_model->magaza(array('kullanici_id' => $kullanici->kullanici_id));
        //$data->urunler = $this->magaza_model->urunler(array('kullanici_id' => $kullanici->kullanici_id));
        $data->kadijoin = $this->magaza_model->getwho(array("kullanici_id" => $kullanici->kullanici_id));

        $this->load->view('inc/_header', $data);
        $this->load->view('kpanel/magaza/urun/urunler', $data);
        $this->load->view('inc/_footer', $data);
    }

    public function ilan_ekle()
    {

        $data = new stdClass();
        $kullanici = kullanicicek();
        $data->title = "İlan Ekle";
        $data->description = "";
        $data->keywords = "";
        $data->ayarlar = ayarlar();
        $data->kullanici = $kullanici;
        $data->magaza = $this->magaza_model->magaza(array('kullanici_id' => $kullanici->kullanici_id));
        $data->kadijoin = $this->magaza_model->getwho(array("kullanici_id" => $kullanici->kullanici_id));

        $wer = "kategori_durum=1 AND parent=0";
        $data->kategoriler = $this->db->where($wer)->order_by("kategori_ad ASC")->get("kategori")->result();

        $this->load->view('inc/_header', $data);
        $this->load->view('kpanel/magaza/urun/ilan-ekle', $data);
        $this->load->view('inc/_footer', $data);

    }

    public function urun_ekle()
    {
        if (!magaza_check()) {
            redirect(base_url('magaza-olustur'));
            die();
        }
        $data = new stdClass();
        $kullanici = kullanicicek();
        $data->title = "İlan Ekle";
        $data->description = "";
        $data->keywords = "";
        $data->ayarlar = ayarlar();
        $data->kullanici = $kullanici;
        $data->magaza = $this->magaza_model->magaza(array('kullanici_id' => $kullanici->kullanici_id));
        $data->kadijoin = $this->magaza_model->getwho(array("kullanici_id" => $kullanici->kullanici_id));

        $this->session->unset_userdata('product_images');
        $this->session->unset_userdata('gallery');
        $this->session->unset_userdata('product_file');

        $wer = "kategori_durum=1 AND parent=0";
        $data->kategoriler = $this->db->where($wer)->order_by("kategori_ad ASC")->get("kategori")->result();

        $ana_json_array = array();
        $x = 0;
        foreach ($data->kategoriler as $ana_veri) {
            $wer2 = "kategori_tur='1' AND kategori_durum=1 AND parent=" . trim($ana_veri->kategori_id);
            $alt_kategori_veri = $this->db->where($wer2)->order_by("kategori_ad ASC")->get("kategori")->result();

            if (sizeof($alt_kategori_veri) > 0) {
                $ana_json_array[$x]['kategori_id'] = trim($ana_veri->kategori_id);
                $ana_json_array[$x]['kategori_ad'] = trim($ana_veri->kategori_ad);
                $ana_json_array[$x]['kategori_resim'] = trim($ana_veri->kategori_resim);
                $x++;
            }

        }

        $data->kategoriler = $ana_json_array;

        $this->load->view('inc/_header', $data);
        $this->load->view('kpanel/magaza/urun/urun-ekle', $data);
        $this->load->view('inc/_footer', $data);
    }

    public function api_getMyBoughtOrders()
    {
        $data = new stdClass();
        $filter = new stdClass();
        $data->ayarlar = new stdClass();
        $kullanici = kullanicicek();
        $ayarlar = ayarlar();

        $page = $this->input->post('Page');
        $filter->search = $this->input->post('Search');
        $filter->date = $this->input->post('StartDate');

        $data->Datas = $this->siparis_model->aldigim_ilanlar(array('siparis.kullanici_id' => $kullanici->kullanici_id, 'urunler.admin' => 0), 10, $page, $filter);
        $data->success = true;
        $data->mobile_check = true;
        $data->ayarlar->iyzico_durum = $ayarlar->iyzico_durum;
        $data->ayarlar->paytr_durum = $ayarlar->paytr_durum;
        echo json_encode($data);
    }

    public function api_getMySoldOrders()
    {
        $data = new stdClass();
        $data->ayarlar = new stdClass();
        $kullanici = kullanicicek();
        $ayarlar = ayarlar();
        $magaza = magaza($kullanici->kullanici_id);

        if ($magaza) {
            $page = $this->input->post('Page');

            $data->Datas = $this->siparis_model->sattigim_ilanlar(array('siparis.magaza' => $magaza->magaza_id), 10, $page);
            $data->success = true;
            $data->mobile_check = true;
            echo json_encode($data);
        } else {
            $data->Datas = '';
            $data->success = true;
            $data->mobile_check = true;
            echo json_encode($data);
        }
        //echo '{"success":true,"mobile_check":true,"Datas":[]}';

    }

    public function siparis_iptal()
    {
        $data = new stdClass();

        $message = $this->input->post('iptal_mesaj');
        $order_id = $this->input->post('order_id');

        $arr = [
            'siparis_durum' => 3,
            'siparis_iptal' => $message
        ];

        if ($this->siparis_model->siparis_update(array('siparis_id' => $order_id), $arr)) {
            $data->success = true;
        } else {
            $data->success = false;
            $data->message = 'Sipariş iptal edilirken bir hata meydana geldi lütfen daha sonra tekrar deneyiniz!!';
        }
        echo json_encode($data);
    }

    public function siparis_onayla()
    {
        $data = new stdClass();

        $order_id = $this->input->post('order_id');

        $siparis_data = $this->siparis_model->get_selected_siparis($order_id);
        $magaza_bilgi = magaza_bilgi($siparis_data->magaza);
        $satici_bilgi = kullanici_bilgi($magaza_bilgi->kullanici_id);

        $kategori_id = json_decode($siparis_data->kategori_json)[0];

        $category = $this->home_model->kategoricek(array('kategori_id' => $kategori_id));

        $komisyon_tutar = kategori_komisyon_hesap($siparis_data->siparis_tutar, $category->komisyon);

        $satici_odenecek_tutar = $siparis_data->siparis_tutar - $komisyon_tutar;
        $satici_odenecek_tutar = number_format($satici_odenecek_tutar, 2);

        $arr = [
            'siparis_durum' => 2
        ];
        $satici_arr = [
            'bakiye' => number_format($satici_bilgi->bakiye + $satici_odenecek_tutar, 2)
        ];

        if ($this->siparis_model->siparis_update(array('siparis_id' => $order_id), $arr)) {
            if ($this->siparis_model->update_bakiye(array('kullanici_id' => $satici_bilgi->kullanici_id), $satici_arr)) {
                $data->success = true;

            } else {
                $data->success = false;
                $data->message = 'Sipariş onaylanırken bir hata meydana geldi lütfen daha sonra tekrar deneyiniz!!';
            }
        } else {
            $data->success = false;
            $data->message = 'Sipariş onaylanırken bir hata meydana geldi lütfen daha sonra tekrar deneyiniz!!';
        }
        echo json_encode($data);
    }

    public function api_getMySoldOrderDetail()
    {
        $data = new stdClass();
        $data->Logs = new stdClass();
        $data->pay = new stdClass();
        $ayarlar = ayarlar();

        $logs = [];

        $order_id = $this->input->post('orderID');
        if ($data->Data = $this->siparis_model->get_selected_siparis($order_id)) {
            $data->link = base_url('siparis-detay/' . $data->Data->siparis_no);
            $data->order_key = !empty($data->Data->siparis_key) ? $data->Data->siparis_key : 'Siparişiniz Bekliyor';
            if ($data->Data->siparis_durum == 3) {
                $logs[0]['StateTitle'] = 'Satıcının teslimatı bekleniyor';
                $logs[0]['StateText'] = false;
                $logs[0]['State'] = 2;

                $logs[1]['StateTitle'] = 'Sipariş İptal edildi';
                $logs[1]['StateText'] = $data->Data->siparis_iptal;
                $logs[1]['State'] = 6;
                $data->order_key = 'Siparişi İptal Ettiniz';
            } else {
                if ($data->Data->siparis_epin == 1) {
                    $logs[0]['StateTitle'] = 'Sipariş teslim edildi';
                    $logs[0]['StateText'] = 'Bu sipariş otomatik teslim edilmiştir.';
                    $logs[0]['State'] = 1;
                } else if ($data->Data->siparis_epin == 2) {
                    $logs[0]['StateTitle'] = 'Sipariş Bekleniyor';
                    $logs[0]['StateText'] = 'Bu sipariş otomatik teslim edilecektir.';
                    $logs[0]['State'] = 3;
                } else {
                    $logs[0]['StateTitle'] = 'Satıcının teslimatı bekleniyor';
                    $logs[0]['StateText'] = false;
                    $logs[0]['State'] = 2;
                    if ($data->Data->siparis_durum == 0) {
                        $logs[1]['StateTitle'] = 'Ödeme Bekleniyor';
                        $logs[1]['StateText'] = false;
                        $logs[1]['State'] = 2;
                    } else if ($data->Data->siparis_durum == 1) {
                        $logs[1]['StateTitle'] = 'Alıcının teslimatı onaylaması bekleniyor.';
                        $logs[1]['StateText'] = false;
                        $logs[1]['State'] = 4;
                    } else if ($data->Data->siparis_durum == 2) {
                        $logs[1]['StateTitle'] = 'Sipariş teslim edildi';
                        $logs[1]['StateText'] = 'Siparişiniz kullanıcıya teslim edildi.';
                        $logs[1]['State'] = 1;
                    } else if ($data->Data->siparis_durum == 3) {
                        $logs[1]['StateTitle'] = 'Sipariş İptal edildi';
                        $logs[1]['StateText'] = $data->Data->siparis_iptal;
                        $logs[1]['State'] = 6;
                        $data->order_key = 'Sİparişi İptal Ettiniz';
                    }
                }
            }
            $data->Logs = array_to_object($logs);
            if ($data->Data->siparis_durum == 0) {
                if ($ayarlar->iyzico_durum == 1) {
                    $data->pay->iyzico_status = true;
                }
                if ($ayarlar->paytr_durum == 1) {
                    $data->pay->paytr_status = true;
                }
                $data->pay->balance = true;
            } else {
                $data->pay->iyzico_status = false;
                $data->pay->paytr_status = false;
                $data->pay->balance = false;
            }
            $data->mobile_check = true;
            $data->success = true;
        } else {
            $data->success = false;
            $data->message = 'Bir Hata Meydana Geldi Lütfen Daha Sonra Tekrar Deneyiniz!!';
        }
        echo json_encode($data);
        // {"success":true,"mobile_check":true,"Data":{"State":"1","Price":"149.90","Datetime":"2023-05-31 14:18:35","Id":"91624","UserId":"31844","postType":"KEY","categoryName":"Discord","Description":"<ul><li><strong>14x boost takviyesiyle sunucunuzu son seviye olan 3. seviye yaparsınız.<\/strong><\/li><li><strong>0-1 saat arasında gönderilir. Yoğunluğa bağlı gönderim süresi değişir.<\/strong><\/li><li><strong>Davet linkiniz sınırsız süreli ve sınırsız kullanıcılı olmalıdır.<\/strong><\/li><li><strong>3 aylıktır.<\/strong><\/li><\/ul><p><strong><u>Discord 3. Seviye Özellikleri:<\/u><\/strong><\/p><ul><li><strong>+100 adet sunucu emojisi yeri (toplamda 250)<\/strong><\/li><li><strong>+30 özel çıkartma yeri (toplamda 60)<\/strong><\/li><li><strong>384kbps ses kalitesi<\/strong><\/li><li><strong>Sunucu için Özel Davet Bağlantısı<\/strong><\/li><li><strong>Tüm Üyeler için 100MB yükleme sınırı<\/strong><\/li><li><strong>Hareketli Sunucu Afişi<\/strong><\/li><li><strong>Diğer 2. ve 1. seviye avantajları<\/strong><\/li><\/ul>","AdvertImage":"uploads\/post_images\/hizli-teslimat-3-aylik-14x-boost-28181996.png","Details":{"details":{"156":"Aylık"}},"AdvertPrice":"180.00","Title":"[HIZLI TESLİMAT] 3 AYLIK 14X BOOST","AdvertId":"63824","LastLogin":"2023-10-05 22:54:37","Level":"14","UserName":"AsilShop","Avatar":"user\/dcc39e3148057208e3f31ad239cef8ea11256782.png","Link":"\/discord\/hizli-teslimat-3-aylik-14x-boost-63824"},"Logs":[{"Id":"204232","PurchaseId":"91624","Datetime":"31 Mayıs 2023 , 14:18 , Çarşamba","State":"3","StateTitle":"Alıcının teslimatı onaylaması bekleniyor","StateText":false},{"Id":"204842","PurchaseId":"91624","Datetime":"1 Haziran 2023 , 14:19 , Perşembe","State":"1","StateTitle":"Sipariş teslim edildi","StateText":"Siparişiniz tarafınıza teslim edildi, Satıcı ödemesini teslim aldı. Diğer üyelerimizin satıcı ile aranızda gerçekleşen ticaretten haberdar olması için lütfen satıcı değerlendirmesini doldurunuz."}],"Stock":{"Value":"BOTU EKLEYİNCE HABER VERİNİZ."}}';

    }

    public function api_getMyPurchases()
    {
        $data = new stdClass();
        $data->ayarlar = new stdClass();
        $kullanici = kullanicicek();
        $ayarlar = ayarlar();

        $page = $this->input->post('Page');

        //$data->datas = $this->siparis_model->aldigim_urunler(array('siparis.kullanici_id' => $kullanici->kullanici_id, 'siparis.siparis_epin !=' => 0, 'urunler.urun_turu' => 2), 10, $page);
        $data->datas = $this->siparis_model->aldigim_urunler(array('siparis.kullanici_id' => $kullanici->kullanici_id, 'urunler.admin' => 1), 5, $page);
        $data->success = true;
        $data->Background = 'https://kemalellidort.com.tr/assets/images/valorant-313.png';
        $data->mobile_check = true;
        echo json_encode($data);
        //echo '{"success":true,"mobile_check":true,"datas":[{"Id":"16516","Background":"https:\/\/cdn.itempazar.com\/uploads\/category_images\/valorant-313.png","CategoryId":"1109","Logo":"https:\/\/cdn.itempazar.com\/uploads\/images\/valorant-485-vp-776.png","Count":"1","Title":"Valorant 485 VP","Date":"06.06.2023 14:53","Value":"RA-PNZQCA4C6JXU3H3M","ValueNl":"RA-PNZQCA4C6JXU3H3M","Price":"57.4","Rated":"0","ProductIDReal":"2368","Seo":"485-vp-satin-al","productSeo":"valorant-vp-satin-al","isTopup":"0","preOrderState":null,"preOrderStatus":null,"topupStatus":"Sipariş topup değil","topupData":null,"topupIptal":"true","multiLine":false}]}';

    }

    public function api_getMyBoughtOrderDetail()
    {
        $data = new stdClass();
        $data->Logs = new stdClass();
        $data->pay = new stdClass();
        $ayarlar = ayarlar();

        $logs = [];

        $order_id = $this->input->post('orderID');
        if ($data->Data = $this->siparis_model->get_selected_siparis($order_id)) {
            $data->link = base_url('siparis-detay/' . $data->Data->siparis_no);
            $data->order_key = !empty($data->Data->siparis_key) ? $data->Data->siparis_key : 'Satıcıyla İletişime Geç';
            if ($data->Data->siparis_durum == 3) {
                $logs[0]['StateTitle'] = 'Satıcının teslimatı bekleniyor';
                $logs[0]['StateText'] = false;
                $logs[0]['State'] = 2;

                $logs[1]['StateTitle'] = 'Sipariş İptal edildi';
                $logs[1]['StateText'] = $data->Data->siparis_iptal;
                $logs[1]['State'] = 6;
                $data->order_key = 'Siparişiniz İptal Edildi';
            } else {
                /*if ($data->Data->siparis_epin == 1) {
                    $logs[0]['StateTitle'] = 'Sipariş teslim edildi';
                    $logs[0]['StateText'] = 'Bu sipariş otomatik teslim edilmiştir.';
                    $logs[0]['State'] = 1;
                } else if ($data->Data->siparis_epin == 2) {
                    $logs[0]['StateTitle'] = 'Sipariş Bekleniyor';
                    $logs[0]['StateText'] = 'Bu sipariş otomatik teslim edilecektir.';
                    $logs[0]['State'] = 3;
                } else {
                    $logs[0]['StateTitle'] = 'Satıcının teslimatı bekleniyor';
                    $logs[0]['StateText'] = false;
                    $logs[0]['State'] = 2;
                    if ($data->Data->siparis_durum == 0) {
                        $logs[1]['StateTitle'] = 'Ödeme Bekleniyor';
                        $logs[1]['StateText'] = false;
                        $logs[1]['State'] = 2;
                    } else if ($data->Data->siparis_durum == 1) {
                        $logs[1]['StateTitle'] = 'Alıcının teslimatı onaylaması bekleniyor.';
                        $logs[1]['StateText'] = false;
                        $logs[1]['State'] = 4;
                    } else if ($data->Data->siparis_durum == 2) {
                        $logs[1]['StateTitle'] = 'Sipariş teslim edildi';
                        $logs[1]['StateText'] = 'Siparişiniz tarafınıza teslim edildi, Satıcı ödemesini teslim aldı. Diğer üyelerimizin satıcı ile aranızda gerçekleşen ticaretten haberdar olması için lütfen satıcı değerlendirmesini doldurunuz.';
                        $logs[1]['State'] = 1;
                    } else if ($data->Data->siparis_durum == 3) {
                        $logs[1]['StateTitle'] = 'Sipariş İptal edildi';
                        $logs[1]['StateText'] = $data->Data->siparis_iptal;
                        $logs[1]['State'] = 6;
                        $data->order_key = 'Siparişiniz İptal Edildi';
                    }
                }*/
                if (!empty($data->Data->siparis_key)) {
                    $logs[0]['StateTitle'] = 'Alıcının Teslimatı Onaylaması Bekleniyor';
                    $logs[0]['StateText'] = false;
                    $logs[0]['State'] = 3;
                    if ($data->Data->siparis_durum == 0) {
                        $logs[1]['StateTitle'] = 'Ödeme Bekleniyor';
                        $logs[1]['StateText'] = false;
                        $logs[1]['State'] = 2;
                    } else if ($data->Data->siparis_durum == 1) {
                        $logs[1]['StateTitle'] = 'Alıcının teslimatı onaylaması bekleniyor.';
                        $logs[1]['StateText'] = false;
                        $logs[1]['State'] = 4;
                    } else if ($data->Data->siparis_durum == 2) {
                        $logs[1]['StateTitle'] = 'Sipariş teslim edildi';
                        $logs[1]['StateText'] = 'Siparişiniz tarafınıza teslim edildi, Satıcı ödemesini teslim aldı. Diğer üyelerimizin satıcı ile aranızda gerçekleşen ticaretten haberdar olması için lütfen satıcı değerlendirmesini doldurunuz.';
                        $logs[1]['State'] = 1;
                    } else if ($data->Data->siparis_durum == 3) {
                        $logs[1]['StateTitle'] = 'Sipariş İptal edildi';
                        $logs[1]['StateText'] = $data->Data->siparis_iptal;
                        $logs[1]['State'] = 6;
                        $data->order_key = 'Siparişiniz İptal Edildi';
                    }
                } else {
                    $logs[0]['StateTitle'] = 'Satıcının Teslimatı Bekleniyor';
                    $logs[0]['StateText'] = false;
                    $logs[0]['State'] = 2;
                }

            }
            $data->Logs = array_to_object($logs);
            if ($data->Data->siparis_durum == 0) {
                if ($ayarlar->iyzico_durum == 1) {
                    $data->pay->iyzico_status = true;
                }
                if ($ayarlar->paytr_durum == 1) {
                    $data->pay->paytr_status = true;
                }
                $data->pay->balance = true;
            } else {
                $data->pay->iyzico_status = false;
                $data->pay->paytr_status = false;
                $data->pay->balance = false;
            }
            $data->mobile_check = true;
            $data->success = true;
        } else {
            $data->success = false;
            $data->message = 'Bir Hata Meydana Geldi Lütfen Daha Sonra Tekrar Deneyiniz!!';
        }
        echo json_encode($data);
        // {"success":true,"mobile_check":true,"Data":{"State":"1","Price":"149.90","Datetime":"2023-05-31 14:18:35","Id":"91624","UserId":"31844","postType":"KEY","categoryName":"Discord","Description":"<ul><li><strong>14x boost takviyesiyle sunucunuzu son seviye olan 3. seviye yaparsınız.<\/strong><\/li><li><strong>0-1 saat arasında gönderilir. Yoğunluğa bağlı gönderim süresi değişir.<\/strong><\/li><li><strong>Davet linkiniz sınırsız süreli ve sınırsız kullanıcılı olmalıdır.<\/strong><\/li><li><strong>3 aylıktır.<\/strong><\/li><\/ul><p><strong><u>Discord 3. Seviye Özellikleri:<\/u><\/strong><\/p><ul><li><strong>+100 adet sunucu emojisi yeri (toplamda 250)<\/strong><\/li><li><strong>+30 özel çıkartma yeri (toplamda 60)<\/strong><\/li><li><strong>384kbps ses kalitesi<\/strong><\/li><li><strong>Sunucu için Özel Davet Bağlantısı<\/strong><\/li><li><strong>Tüm Üyeler için 100MB yükleme sınırı<\/strong><\/li><li><strong>Hareketli Sunucu Afişi<\/strong><\/li><li><strong>Diğer 2. ve 1. seviye avantajları<\/strong><\/li><\/ul>","AdvertImage":"uploads\/post_images\/hizli-teslimat-3-aylik-14x-boost-28181996.png","Details":{"details":{"156":"Aylık"}},"AdvertPrice":"180.00","Title":"[HIZLI TESLİMAT] 3 AYLIK 14X BOOST","AdvertId":"63824","LastLogin":"2023-10-05 22:54:37","Level":"14","UserName":"AsilShop","Avatar":"user\/dcc39e3148057208e3f31ad239cef8ea11256782.png","Link":"\/discord\/hizli-teslimat-3-aylik-14x-boost-63824"},"Logs":[{"Id":"204232","PurchaseId":"91624","Datetime":"31 Mayıs 2023 , 14:18 , Çarşamba","State":"3","StateTitle":"Alıcının teslimatı onaylaması bekleniyor","StateText":false},{"Id":"204842","PurchaseId":"91624","Datetime":"1 Haziran 2023 , 14:19 , Perşembe","State":"1","StateTitle":"Sipariş teslim edildi","StateText":"Siparişiniz tarafınıza teslim edildi, Satıcı ödemesini teslim aldı. Diğer üyelerimizin satıcı ile aranızda gerçekleşen ticaretten haberdar olması için lütfen satıcı değerlendirmesini doldurunuz."}],"Stock":{"Value":"BOTU EKLEYİNCE HABER VERİNİZ."}}';

    }

    public function api_get_category()
    {

        $cat_id = trim($_POST['Id']);

        $wer = "kategori_durum=1 AND kategori_id=" . $cat_id;
        $ana_kategori_veri = $this->db->where($wer)->order_by("kategori_ad ASC")->get("kategori")->result();

        $ana_json_array = array();
        $x = 0;
        foreach ($ana_kategori_veri as $ana_veri) {

            $wer2 = "kategori_tur='1' AND kategori_durum=1 AND parent=" . trim($ana_veri->kategori_id);
            $alt_kategori_veri = $this->db->where($wer2)->order_by("kategori_ad ASC")->get("kategori")->result();

            if (sizeof($alt_kategori_veri) > 0) {
                $ana_json_array[$x]['Id'] = trim($ana_veri->kategori_id);
                $ana_json_array[$x]['Name'] = trim($ana_veri->kategori_ad);
                $ana_json_array[$x]['Order'] = trim($ana_veri->kategori_sira);
                $ana_json_array[$x]['Image'] = trim($ana_veri->kategori_resim);
                $ana_json_array[$x]['MainMenu'] = trim($ana_veri->kategori_tur);
                $ana_json_array[$x]['Advert'] = trim($ana_veri->kategori_tur);
                $ana_json_array[$x]['_id'] = trim($cat_id);
                $x++;
            }

        }


        $wer2 = "kategori_tur='1' AND kategori_durum=1 AND parent=" . $cat_id;
        $data->kategoriler = $this->db->where($wer2)->order_by("kategori_ad ASC")->get("kategori")->result();

        $json_array = array();
        $x = 0;
        foreach ($data->kategoriler as $veri) {
            $json_array[$x]['text'] = trim($veri->kategori_ad);
            $json_array[$x]['value'] = trim($veri->kategori_id);
            $json_array[$x]['image'] = trim($veri->kategori_resim);
            $x++;
        }


        $alt_kategori_json = json_encode([
            "success" => true,
            "mobile_check" => true,
            "getD" => $ana_json_array,
            "Datas" => [],
            "ads" => "kategoriler",
            "results" => $json_array
        ]);

        echo $alt_kategori_json;

    }

    public function api_get_categoryDefaultImages()
    {

        echo '{"success":true,"mobile_check":true,"image":["global\/default\/hesap-valorant-3-452.png","global\/default\/hesap-valorant-2-926.png","global\/default\/hesap-valorant-834.png"],"comission":7,"minPrice":"10.00","requestPost":false,"allowUnLimited":true,"deliveryTimes":{"3":"3 Saat","6":"6 Saat","12":"12 Saat","24":"1 Gün"}}';

    }

    public function api_get_TypeDetail()
    {
        // dizi_goster($_POST);
        //echo '{"success":true,"mobile_check":true,"Details":[{"dID":"213","Title":"Garantili Mi","Type":"Select","Description":"","Required":true,"Values":["Evet","Hayır"]},{"dID":"29","Title":"İlk Mail","Type":"Select","Description":"","Required":true,"Values":["Evet","Hayır"]}]}';
        //$data =
        $category_id = $this->input->post('Id');


        $filters = $this->home_model->get_category_filter($category_id);

        $data = json_encode([
            "success" => true,
            "mobile_check" => true,
            "Details" => $filters,
        ]);

        echo $data;
    }

    public function api_get_sub_filter()
    {
        $filter_id = $this->input->post('value');

        $sub_filters = $this->home_model->get_sub_filters($filter_id);
        $tempHtml = '';
        foreach (!empty($sub_filters) ? $sub_filters : [] as $key => $val) {
            if ($val->type == 1) { // select option ise
                $ozellikler = $this->home_model->get_filter_ozellik($val->filtre_id);
                if (!empty($ozellikler)) {
                    $tempHtml .= '<label class="form-label">Filtre ' . $val->filtre_adi . ' Seçenekleri</label>';
                    $tempHtml .= '<select class="form-control" data-width="100%" name="' . $val->slug . '">';
                    $tempHtml .= '<option>Lütfen Seçim Yapınız</option>>';
                    foreach (!empty($ozellikler) ? $ozellikler : [] as $_key => $_val) {
                        $tempHtml .= '<option value="' . $_val->name . '">' . $_val->name . '</option>';
                    }
                    $tempHtml .= '</select><br>';
                }
            } else if ($val->type == 2) { // input ise
                $tempHtml .= '<label class="form-label">Filtre ' . $val->filtre_adi . ' Seçenekleri</label>';
                $tempHtml .= '<input type="text" name="' . $val->slug . '" class="form-control" value="" required/><br>';
            }
        }

        $data = json_encode([
            "success" => true,
            "mobile_check" => true,
            "tempHtml" => $tempHtml,
        ]);

        echo $data;
    }

    public function urunekle()
    {
        $this->result = new stdClass();

        if (!magaza_check()) {
            $this->result->status = false;
            $this->result->message = 'Mağaza Oluşturmadan Ürün Ekleyemezsiniz!';
            echo json_encode($this->result);
            die();
        }

        $kullanici = kullanicicek();
        $magaza = magaza($kullanici->kullanici_id);

        if (!$magaza) {
            $this->result->status = false;
            $this->result->message = 'Mağaza Oluşturmadan Ürün Ekleyemezsiniz!';
            echo json_encode($this->result);
            die();
        }

        $this->load->library("form_validation");

        if (!isset($_POST['category_2'])) {
            $this->form_validation->set_rules("category_1", "İlan Ketegorisi", "required|trim|xss_clean");
            $this->form_validation->set_rules("category_2", "İlan Ketegorisi", "required|trim|xss_clean");
        }

        $this->form_validation->set_rules("urun_ad", "İlan Adı", "required|trim|xss_clean");
        $this->form_validation->set_rules("urun_turu", "İlan Türü", "required|trim|xss_clean");
        $this->form_validation->set_rules('urun_turu[]', 'İlan Türü', 'required');
        $this->form_validation->set_rules("urun_stok", "Ürün Stoğu", "required|trim|xss_clean");

        $this->form_validation->set_rules("fiyat", "Fiyat", "required|trim|xss_clean");
        $this->form_validation->set_rules("urun_aciklama", "İlan Açıklaması", "required|trim|xss_clean");
        $this->form_validation->set_rules("urun_short_aciklama", "İlan Kısa Açıklaması", "required|trim|xss_clean");
        $this->form_validation->set_rules("urun_bitis_tarihi", "İlan Bitiş Tarihi", "required|trim|xss_clean");
        $this->form_validation->set_message(
            array("required" => "{field} Boş Bırakılamaz!")
        );

        $ana_kategori = $this->input->post("category_1");
        $alt_kategori = $this->input->post("category_2");
        $urun_ad = $this->input->post("urun_ad");
        $stok = $this->input->post("urun_stok");
        $tur = $this->input->post("urun_turu");
        $urun_aciklama = $this->input->post("urun_aciklama");
        $urun_kisa_aciklama = $this->input->post("urun_aciklama");


        if (!is_dir('uploads/urunler/images/min'))
            mkdir('uploads/urunler/images/min', 0777);
        if (!is_dir('uploads/urunler/images')) {
            mkdir('uploads/urunler/images', 0777);
            mkdir('uploads/urunler/images/galeri', 0777);
        }

        $validat = $this->form_validation->run();

        if ($validat) {
            if (strlen($urun_aciklama) <= 0 || strlen($urun_kisa_aciklama) <= 0) {
                $this->result->status = false;
                $this->result->message = 'İlan açıklama alanları boş bırakılamaz!';
                echo json_encode($this->result);
                die();
            }
            if (!$stok && $stok == 0) {
                $this->result->status = false;
                $this->result->message = 'Ürün Stoğu Girmelisiniz!';
                echo json_encode($this->result);
                die();
            }
            if ($tur == 2) {
                if (!$this->input->post("sanal_urun_bilgileri")) {
                    $this->result->status = false;
                    $this->result->message = 'Sanal ürün bilgisi girmeniz gerekmektedir!';
                    echo json_encode($this->result);
                    die();
                }
            }
            if ($tur == 3) {
                if (empty($this->session->userdata('product_file'))) {
                    $this->result->status = false;
                    $this->result->message = 'İndirilebilir ürün kullanımı için dosya yüklemeniz gerekmektedir.';
                    echo json_encode($this->result);
                    die();
                }
            }

            if (!empty($this->session->userdata('product_images'))) {
                $uploaded_file = $this->session->userdata('product_images');
                $seourl = seo($this->input->post("urun_ad")) . "-" . rand(1000, 9999);
                $ana_kategori = $this->input->post("category_1");
                $alt_kategori = $this->input->post("category_2");

                $filter_arr = [];
                if ($sub_filters = $this->home_model->get_sub_filters($this->input->post('filtre'))) {
                    if (!empty($sub_filters)) {
                        foreach ($sub_filters as $fill_key => $fill) {
                            $filter_arr[$fill->slug] = $this->input->post($fill->slug);
                        }
                    }
                }
                $data = array(
                    "kullanici_id" => $kullanici->kullanici_id,
                    "kategori_json" => '["' . $alt_kategori . '"]',
                    "magaza_id" => $magaza->magaza_id,
                    "urun_turu" => $this->input->post("urun_turu"),
                    "urun_bitis_tarihi" => date('Y-m-d H:i:s', strtotime($this->input->post("urun_bitis_tarihi"))),
                    "urun_ad" => $this->input->post("urun_ad"),
                    "urun_resim" => $uploaded_file['image_path'],
                    "urun_resim_min" => $uploaded_file['thumbnail_image'],
                    "urun_marka" => $this->input->post("urun_marka"),
                    "urun_stok" => $this->input->post("urun_stok"),
                    "urun_fiyat" => $this->input->post("fiyat"),
                    "urun_kfiyat" => komisyon_hesap($this->input->post("fiyat")),
                    "urun_durum" => 0,
                    "urun_aciklama" => $this->input->post("urun_aciklama"),
                    "urun_short_aciklama" => $this->input->post("urun_short_aciklama"),
                    "urun_seo" => $seourl,
                    "urun_uniq" => uniqid(),
                    "urun_sanal_bilgi" => $this->input->post("sanal_urun_bilgileri"),
                    "filtre" => $this->input->post('filtre'),
                    "alt_filtreler" => json_encode($filter_arr)
                );

                $insert = $this->magaza_model->urun_add($data);
                $last_id = $this->db->insert_id();

                if (!empty($this->session->userdata('gallery'))) {
                    $galeri_arr_get = $this->session->userdata('gallery');

                    $veri = array('urun_galeri' => json_encode($galeri_arr_get, JSON_UNESCAPED_UNICODE));
                    $insert = $this->magaza_model->urun_update(array('urun_id' => $last_id), $veri);
                }

                if (!empty($this->session->userdata('product_file'))) {
                    $data_upload_file = $this->session->userdata('product_file');
                    $dosya_veri = array(
                        'urun_indir' => $data_upload_file,
                    );
                    $dosya_insert = $this->magaza_model->urun_update(array('urun_id' => $last_id), $dosya_veri);
                }

                $alert = array(
                    "title" => "İşlem Başarılı",
                    "text" => "İlan Başarılı Şekilde Eklendi",
                    "type" => "success"
                );

                $this->result->status = true;
                $this->result->message = 'İlan Başarılı Şekilde Eklendi';
                $this->result->url = base_url("m/" . $magaza->magaza_seo);
                echo json_encode($this->result);
                die();
            } else {
                $this->result->status = false;
                $this->result->message = 'Lütfen İlan Vitrin Fotoğrafı Seçin!';
                echo json_encode($this->result);
                die();
            }
        } else {
            if (strlen($alt_kategori) <= 0) {
                $this->result->status = false;
                $this->result->message = 'İlan kategorisini seçmediniz!';
                echo json_encode($this->result);
                die();
            }
            if (form_error('urun_ad')) {
                $this->result->message = form_error('urun_ad');
            } else if (form_error('urun_turu')) {
                $this->result->message = form_error('urun_turu');
            } else if (form_error('urun_turu[]')) {
                $this->result->message = form_error('urun_turu[]');
            } else if (form_error('urun_stok')) {
                $this->result->message = form_error('urun_stok');
            } else if (form_error('fiyat')) {
                $this->result->message = form_error('fiyat');
            } else if (form_error('urun_aciklama')) {
                $this->result->message = form_error('urun_aciklama');
            } else if (form_error('urun_bitis_tarihi')) {
                $this->result->message = form_error('urun_bitis_tarihi');
            } else if (form_error('urun_short_aciklama')) {
                $this->result->message = form_error('urun_short_aciklama');
            }
            $this->result->status = false;
            echo json_encode($this->result);
            die();
        }

    }

    public function urun_duzenle($uniq)
    {
        if (!magaza_check()) {
            redirect(base_url('magaza-olustur'));
            die();
        }
        $data = new stdClass();
        $kullanici = kullanicicek();
        $urun = $this->magaza_model->urun(array('kullanici_id' => $kullanici->kullanici_id, 'urun_uniq' => $uniq));

        if (!$urun) {
            redirect(base_url());
            die();
        }

        $data->title = "İlan Düzenle";
        $data->description = "";
        $data->keywords = "";
        $data->ayarlar = ayarlar();
        $data->kullanici = $kullanici;
        $data->magaza = $this->magaza_model->magaza(array('kullanici_id' => $kullanici->kullanici_id));
        $data->urun = $urun;
        $data->kadijoin = $this->magaza_model->getwho(array("kullanici_id" => $kullanici->kullanici_id));

        $this->load->view('inc/_header', $data);
        $this->load->view('kpanel/magaza/urun/urun-duzenle', $data);
        $this->load->view('inc/_footer', $data);
    }

    public function urunduzenle($uniq)
    {

        if (!magaza_check()) {
            redirect(base_url('magaza-olustur'));
            die();
        }
        $kullanici = kullanicicek();
        $magaza = magaza($kullanici->kullanici_id);

        $urun = $this->magaza_model->urun(array("urun_uniq" => $uniq));

        $stok = $this->input->post("urun_stok");

        if (!$stok && $stok == 0) {
            $alert = array(
                "title" => "Hata!",
                "text" => "Ürün Stoğu Girmelisiniz!",
                "type" => "warning"
            );

            $this->session->set_flashdata("alert", $alert);
            redirect(base_url("urun-duzenle/" . $uniq));
            die();
        }

        $tur = $this->input->post("urun_turu");

        if ($tur == 2) {
            if (!$this->input->post("sanal_urun_bilgileri")) {
                $alert = array(
                    "title" => "Hata!",
                    "text" => "Sanal ürün bilgisi girmeniz gerekmektedir!",
                    "type" => "warning"
                );
                $this->session->set_flashdata("alert", $alert);
                redirect(base_url("urun-duzenle/" . $uniq));
                die();
            }
        }

        if ($_FILES["file"]["name"]) {

            if (!is_dir('uploads/urunler/images/min'))
                mkdir('uploads/urunler/images/min', 0777);
            $file_name = seo(pathinfo($_FILES["file"]["name"], PATHINFO_FILENAME)) . "." . pathinfo($_FILES["file"]["name"], PATHINFO_EXTENSION);
            $sifrele = uniqid();
            $config["allowed_types"] = "jpg|jpeg|png";
            $config["upload_path"] = "uploads/urunler/images/";
            $config["file_name"] = $sifrele . "_" . $file_name;

            $this->load->library("upload", $config);
            $upload = $this->upload->do_upload("file");
            $kaboom = explode(".", $this->upload->data("file_name"));
            $fileExt = end($kaboom);
            $source_path = 'uploads/urunler/images/' . $this->upload->data("file_name");
            $target_path = 'uploads/urunler/images/min/' . $this->upload->data("file_name");
            $wmax = 300;
            $hmax = 200;
            resize_img_specific($source_path, $target_path, $wmax, $hmax, $fileExt);
            $source_path = 'uploads/urunler/images/' . $this->upload->data("file_name");
            $target_path = 'uploads/urunler/images/' . $this->upload->data("file_name");
            $wmax = 500;
            $hmax = 450;
            resize_img($source_path, $target_path, $wmax, $hmax, $fileExt);

            if ($upload) {

                $uploaded_file = $this->upload->data("file_name");
                if ($urun->urun_ad == $this->input->post("urun_ad")) {
                    $seourl = $urun->urun_seo;
                } else {
                    $seourl = seo($this->input->post("urun_ad")) . "-" . rand(1000, 9999);
                }
                $kategoriler = $this->input->post("kategori");


                $data = array(
                    "kategori_json" => json_encode($kategoriler),
                    "urun_turu" => $this->input->post("urun_turu"),
                    "urun_bitis_tarihi" => date('Y-m-d H:i:s', strtotime($this->input->post("urun_bitis_tarihi"))),
                    "urun_ad" => $this->input->post("urun_ad"),
                    "urun_resim" => "uploads/urunler/images/" . $uploaded_file,
                    "urun_resim_min" => "uploads/urunler/images/min/"  . $uploaded_file,
                    "urun_marka" => $this->input->post("urun_marka"),
                    "urun_stok" => $this->input->post("urun_stok"),
                    "urun_fiyat" => $this->input->post("fiyat"),
                    "urun_kfiyat" => komisyon_hesap($this->input->post("fiyat")),
                    "urun_durum" => 0,
                    "urun_aciklama" => $this->input->post("urun_aciklama"),
                    "urun_seo" => $seourl,
                    "urun_sanal_bilgi" => $this->input->post("sanal_urun_bilgileri")
                );

                $insert = $this->magaza_model->urun_update(array('urun_uniq' => $uniq), $data);


                if ($_FILES['galeri']['name'][0]) {

                    $galeri_arr = array();
                    $countfiles = count($_FILES['galeri']['name']);
                    $files = $_FILES;

                    for ($i = 0; $i < $countfiles; $i++) {

                        $rand_uniq = uniqid(TRUE);
                        $_FILES['files']['name'] = $files['galeri']['name'][$i];
                        $_FILES['files']['type'] = $files['galeri']['type'][$i];
                        $_FILES['files']['tmp_name'] = $files['galeri']['tmp_name'][$i];
                        $_FILES['files']['error'] = $files['galeri']['error'][$i];
                        $_FILES['files']['size'] = $files['galeri']['size'][$i];
                        $configs['upload_path'] = "uploads/img/";
                        $configs["allowed_types"] = "jpg|jpeg|png";
                        $configs['max_size'] = '5000';
                        $configs['file_name'] = $rand_uniq . $_FILES['files']['name'];

                        $this->load->library('upload', $configs);
                        $this->upload->initialize($configs);
                        if ($this->upload->do_upload('files')) {
                            $uploadData = $this->upload->data();
                            $filename = $uploadData['file_name'];
                            $galeri_arr['filenames'][] = $filename;
                        }
                    }


                    $birlestir = array_merge(json_decode($urun->urun_galeri), $galeri_arr['filenames']);
                    $veri = array('urun_galeri' => json_encode($birlestir, JSON_UNESCAPED_UNICODE));
                    $insert = $this->magaza_model->urun_update(array('urun_uniq' => $uniq), $veri);
                }

                if ($_FILES["dosya"]["name"]) {
                    $file_name = seo(pathinfo($_FILES["dosya"]["name"], PATHINFO_FILENAME)) . "." . pathinfo($_FILES["dosya"]["name"], PATHINFO_EXTENSION);
                    $sifrele = uniqid();
                    $dosya_conf["allowed_types"] = "zip";
                    $dosya_conf["upload_path"] = "uploads/dosya/";
                    $dosya_conf["file_name"] = $sifrele . "_" . $file_name;

                    $this->load->library("upload", $dosya_conf);
                    $this->upload->initialize($dosya_conf);
                    $dosya_upload = $this->upload->do_upload("dosya");

                    if ($dosya_upload) {
                        $data_upload_file = $this->upload->data("file_name");
                        $dosya_veri = array(
                            'urun_indir' => "uploads/dosya/" . $data_upload_file,
                        );
                        $dosya_insert = $this->magaza_model->urun_update(array('urun_uniq' => $uniq), $dosya_veri);
                    }
                }

                $alert = array(
                    "title" => "İşlem Başarılı",
                    "text" => "Ürün Başarılı Şekilde Güncellendi",
                    "type" => "success"
                );


                $this->session->set_flashdata("alert", $alert);
                redirect(base_url("urun-duzenle/" . $uniq));
                die();
            } else {

                $alert = array(
                    "title" => "İşlem Başarısız",
                    "text" => "Bir şeyler ters gitti..",
                    "type" => "error"
                );

                $this->session->set_flashdata("alert", $alert);
                redirect(base_url("urun-duzenle/" . $uniq));
                die();
            }
        } else {
            if ($urun->urun_ad == $this->input->post("urun_ad")) {
                $seourl = $urun->urun_seo;
            } else {
                $seourl = seo($this->input->post("urun_ad")) . "-" . rand(1000, 9999);
            }
            $kategoriler = $this->input->post("kategori");

            $stok = $this->input->post("urun_stok");

            if (!$stok && $stok == 0) {
                $alert = array(
                    "title" => "Hata!",
                    "text" => "Ürün Stoğu Girmelisiniz!",
                    "type" => "warning"
                );

                $this->session->set_flashdata("alert", $alert);
                redirect(base_url("urun-duzenle/" . $uniq));
                die();
            }

            $tur = $this->input->post("urun_turu");

            if ($tur == 2) {
                if (!$this->input->post("sanal_urun_bilgileri")) {
                    $alert = array(
                        "title" => "Hata!",
                        "text" => "Sanal ürün bilgisi girmeniz gerekmektedir!",
                        "type" => "warning"
                    );
                    $this->session->set_flashdata("alert", $alert);
                    redirect(base_url("urun-duzenle/" . $uniq));
                    die();
                }
            }

            $data = array(
                "kategori_json" => json_encode($kategoriler),
                "urun_turu" => $this->input->post("urun_turu"),
                "urun_bitis_tarihi" => date('Y-m-d H:i:s', strtotime($this->input->post("urun_bitis_tarihi"))),
                "urun_ad" => $this->input->post("urun_ad"),
                "urun_marka" => $this->input->post("urun_marka"),
                "urun_stok" => $this->input->post("urun_stok"),
                "urun_fiyat" => $this->input->post("fiyat"),
                "urun_kfiyat" => komisyon_hesap($this->input->post("fiyat")),
                "urun_durum" => 0,
                "urun_aciklama" => $this->input->post("urun_aciklama"),
                "urun_seo" => $seourl,
                "urun_sanal_bilgi" => $this->input->post("sanal_urun_bilgileri")
            );


            $insert = $this->magaza_model->urun_update(array('urun_uniq' => $uniq), $data);

            if ($_FILES['galeri']['name'][0]) {

                $galeri_arr = array();
                $countfiles = count($_FILES['galeri']['name']);
                $files = $_FILES;

                for ($i = 0; $i < $countfiles; $i++) {

                    $rand_uniq = uniqid(TRUE);
                    $_FILES['files']['name'] = $files['galeri']['name'][$i];
                    $_FILES['files']['type'] = $files['galeri']['type'][$i];
                    $_FILES['files']['tmp_name'] = $files['galeri']['tmp_name'][$i];
                    $_FILES['files']['error'] = $files['galeri']['error'][$i];
                    $_FILES['files']['size'] = $files['galeri']['size'][$i];
                    $configs['upload_path'] = "uploads/img/";
                    $configs["allowed_types"] = "jpg|jpeg|png";
                    $configs['max_size'] = '5000';
                    $configs['file_name'] = $rand_uniq . $_FILES['files']['name'];

                    $this->load->library('upload', $configs);
                    $this->upload->initialize($configs);
                    if ($this->upload->do_upload('files')) {
                        $uploadData = $this->upload->data();
                        $filename = $uploadData['file_name'];
                        $galeri_arr['filenames'][] = $filename;
                    }
                }

                $birlestir = array_merge(json_decode($urun->urun_galeri), $galeri_arr['filenames']);
                $veri = array('urun_galeri' => json_encode($birlestir, JSON_UNESCAPED_UNICODE));
                $insert = $this->magaza_model->urun_update(array('urun_uniq' => $uniq), $veri);
            }

            if ($_FILES["dosya"]["name"]) {
                $file_name = seo(pathinfo($_FILES["dosya"]["name"], PATHINFO_FILENAME)) . "." . pathinfo($_FILES["dosya"]["name"], PATHINFO_EXTENSION);
                $sifrele = uniqid();
                $dosya_conf["allowed_types"] = "zip";
                $dosya_conf["upload_path"] = "uploads/dosya/";
                $dosya_conf["file_name"] = $sifrele . "_" . $file_name;

                $this->load->library("upload", $dosya_conf);
                $this->upload->initialize($dosya_conf);
                $dosya_upload = $this->upload->do_upload("dosya");

                if ($dosya_upload) {
                    $data_upload_file = $this->upload->data("file_name");
                    $dosya_veri = array(
                        'urun_indir' => "uploads/dosya/" . $data_upload_file,
                    );
                    $dosya_insert = $this->magaza_model->urun_update(array('urun_uniq' => $uniq), $dosya_veri);
                }
            }


            $alert = array(
                "title" => "İşlem Başarılı",
                "text" => "Ürün Başarılı Şekilde Güncellendi",
                "type" => "success"
            );


            $this->session->set_flashdata("alert", $alert);
            redirect(base_url("urun-duzenle/" . $uniq));
            die();
        }
    }

    public function urun_galeri($uniq)
    {
        if (!magaza_check()) {
            redirect(base_url('magaza-olustur'));
            die();
        }
        $data = new stdClass();
        $kullanici = kullanicicek();
        $urun = $this->magaza_model->urun(array('kullanici_id' => $kullanici->kullanici_id, 'urun_uniq' => $uniq));

        if (!$urun) {
            redirect(base_url());
            die();
        }

        $data->title = "Ürün Galeri";
        $data->description = "";
        $data->keywords = "";
        $data->ayarlar = ayarlar();
        $data->kullanici = $kullanici;
        $data->magaza = $this->magaza_model->magaza(array('kullanici_id' => $kullanici->kullanici_id));
        $data->urun = $urun;
        $data->kadijoin = $this->magaza_model->getwho(array("kullanici_id" => $kullanici->kullanici_id));
        $data->magaza_kullanici_bilgi = kullanici_bilgi($data->magaza->kullanici_id);

        $this->load->view('inc/_header', $data);
        $this->load->view('kpanel/magaza/urun/urun-galeri', $data);
        $this->load->view('inc/_footer', $data);
    }

    public function urun_galeri_sil($urununiq, $arrayid)
    {
        if (!magaza_check()) {
            redirect(base_url('magaza-olustur'));
            die();
        }

        $kullanici = kullanicicek();
        $where = $this->magaza_model->urun(array("urun_uniq" => $urununiq, 'kullanici_id' => $kullanici->kullanici_id));

        if (!$where) {
            redirect($_SERVER['HTTP_REFERER']);
            die();
        }

        $galeri = array();
        $galeri = json_decode($where->urun_galeri);
        unlink('./uploads/img/'. $galeri[$arrayid]);
        unset($galeri[$arrayid]);
        $kodla = json_encode(array_values($galeri));
        $insert = $this->magaza_model->urun_update(
            array("urun_uniq" => $urununiq),
            array(
                "urun_galeri " => $kodla,
            )
        );

        redirect($_SERVER['HTTP_REFERER']);
    }

    public function urun_dosya($uniq)
    {
        if (!magaza_check()) {
            redirect(base_url('magaza-olustur'));
            die();
        }
        $data = new stdClass();
        $kullanici = kullanicicek();
        $urun = $this->magaza_model->urun(array('kullanici_id' => $kullanici->kullanici_id, 'urun_uniq' => $uniq));

        if (!$urun) {
            redirect(base_url());
            die();
        }

        $data->title = "Ürün Dosya";
        $data->description = "";
        $data->keywords = "";
        $data->ayarlar = ayarlar();
        $data->kullanici = $kullanici;
        $data->magaza = $this->magaza_model->magaza(array('kullanici_id' => $kullanici->kullanici_id));
        $data->urun = $urun;
        $data->kadijoin = $this->magaza_model->getwho(array("kullanici_id" => $kullanici->kullanici_id));

        $this->load->view('inc/_header', $data);
        $this->load->view('kpanel/magaza/urun/urun-dosya', $data);
        $this->load->view('inc/_footer', $data);
    }

    public function my_download($uniq)
    {
        $this->load->helper('download');
        $kullanici = kullanicicek();
        if (!$kullanici) {
            redirect(base_url());
            die();
        }
        $urun = $this->magaza_model->urun(array("urun_uniq" => $uniq, 'kullanici_id' => $kullanici->kullanici_id));
        if (!$urun) {
            redirect(base_url());
            die();
        }
        force_download($urun->urun_indir, NULL);
    }

    public function download_file($siparis_no)
    {
        if (!aktif_kullanici()) {
            redirect(base_url());
            die();
        }

        $this->load->helper('download');
        $kullanici = kullanicicek();

        $siparis = $this->siparis_model->siparis_download(array('siparis.kullanici_id' => $kullanici->kullanici_id, 'siparis.siparis_no' => $siparis_no));

        if ($siparis) {
            if ($siparis->urun_indir) {
                if ($siparis->siparis_durum == 1 || $siparis->siparis_durum == 2) {
                    force_download($siparis->urun_indir, NULL);
                } else {
                    redirect(base_url());
                    die();
                }
            } else {
                redirect(base_url());
                die();
            }
        } else {
            redirect(base_url());
            die();
        }
    }

    public function urun_dosya_ekle($uniq)
    {
        if (!magaza_check()) {
            redirect(base_url('magaza-olustur'));
            die();
        }
        $kullanici = kullanicicek();

        if ($_FILES["dosya"]["name"]) {
            $urun = $this->magaza_model->urun(array("urun_uniq" => $uniq, 'kullanici_id' => $kullanici->kullanici_id));
            if (!$urun) {
                redirect(base_url());
                die();
            }
            $file_name = seo(pathinfo($_FILES["dosya"]["name"], PATHINFO_FILENAME)) . "." . pathinfo($_FILES["dosya"]["name"], PATHINFO_EXTENSION);
            $sifrele = uniqid();
            $dosya_conf["allowed_types"] = "zip";
            $dosya_conf["upload_path"] = "uploads/dosya/" . $kullanici->kullanici_ad;
            $dosya_conf["file_name"] = $sifrele . "_" . $file_name;

            $this->load->library("upload", $dosya_conf);
            $this->upload->initialize($dosya_conf);
            $dosya_upload = $this->upload->do_upload("dosya");

            if ($dosya_upload) {
                $data_upload_file = $this->upload->data("file_name");
                $dosya_veri = array(
                    'urun_indir' => "uploads/dosya/" . $kullanici->kullanici_ad . "/" . $data_upload_file,
                );
                unlink('./' . $urun->urun_indir);
                $dosya_insert = $this->magaza_model->urun_update(array('urun_uniq' => $uniq), $dosya_veri);
            } else {
                $alert = array(
                    "title" => "Hata!",
                    "text" => "Dosya Türü Desteklenmemektedir! Sadece .zip Yükleyebilirsiniz.",
                    "type" => "error"
                );

                $this->session->set_flashdata("alert", $alert);
                redirect(base_url("urun-dosya/" . $uniq));
                die();
            }
        }

        $alert = array(
            "title" => "İşlem Başarılı",
            "text" => "Dosya Başarılı Şekilde Düzenlendi",
            "type" => "success"
        );

        $this->session->set_flashdata("alert", $alert);
        redirect(base_url("urun-dosya/" . $uniq));
        die();
    }

    public function dosya_sil($urununiq)
    {
        if (!magaza_check()) {
            redirect(base_url('magaza-olustur'));
            die();
        }

        $kullanici = kullanicicek();
        $where = $this->magaza_model->urun(array("urun_uniq" => $urununiq, 'kullanici_id' => $kullanici->kullanici_id));

        if (!$where) {
            redirect($_SERVER['HTTP_REFERER']);
            die();
        }

        unlink('./' . $where->urun_indir);
        $insert = $this->magaza_model->urun_update(array("urun_uniq" => $urununiq), array("urun_indir" => NULL));

        redirect($_SERVER['HTTP_REFERER']);
    }

    public function urunsil($uniq)
    {
        if (!magaza_check()) {
            redirect(base_url('magaza-olustur'));
            die();
        }

        $kullanici = kullanicicek();

        $delete = $this->magaza_model->urun_delete(array("urun_uniq" => $uniq, 'kullanici_id' => $kullanici->kullanici_id));

        if ($delete) {
            redirect($_SERVER['HTTP_REFERER']);
        } else {
            redirect($_SERVER['HTTP_REFERER']);
        }
    }

    public function yorumlar()
    {
        if (!magaza_check()) {
            redirect(base_url('magaza-olustur'));
            die();
        }
        $data = new stdClass();
        $kullanici = kullanicicek();


        $config = array();
        $config["base_url"] = base_url('yorumlar');
        $config["total_rows"] = magaza_yorumsay();
        $config["per_page"] = 12;
        $config["uri_segment"] = 2;


        $config['first_link'] = '&laquo';
        $config['last_link'] = '&raquo';
        $config['attributes'] = array('class' => 'page-link');

        $config['full_tag_open'] = "<ul class='pagination justify-content-center'>";
        $config['full_tag_close'] = "</ul>";
        $config['num_tag_open'] = '<li class="page-item">';
        $config['num_tag_close'] = '</li>';
        $config['cur_tag_open'] = '<li class="page-item active"><a class="page-link" href="#">';
        $config['cur_tag_close'] = "</a></li>";

        $config['next_link'] = 'İleri';
        $config['next_tag_open'] = '<li class="page-item">';
        $config['next_tagl_close'] = "</li>";

        $config['prev_link'] = 'Geri';
        $config['prev_tag_open'] = '<li class="page-item">';
        $config['prev_tagl_close'] = "</li>";

        $config['first_tag_open'] = '<li class="page-item">';
        $config['first_tagl_close'] = "</li>";
        $config['last_tag_open'] = '<li class="page-item">';
        $config['last_tagl_close'] = "</li>";

        $this->pagination->initialize($config);

        $page = ($this->uri->segment(2)) ? $this->uri->segment(2) : 0;
        $data->links = $this->pagination->create_links();
        $data->yorumlar = $this->magaza_model->yorum_sayfalama($config["per_page"], $page);


        $data->title = "Yorumlar";
        $data->description = "";
        $data->keywords = "";
        $data->ayarlar = ayarlar();
        $data->kullanici = $kullanici;
        $data->magaza = $this->magaza_model->magaza(array('kullanici_id' => $kullanici->kullanici_id));
        $data->kadijoin = $this->magaza_model->getwho(array("kullanici_id" => $kullanici->kullanici_id));

        $this->load->view('inc/_header', $data);
        $this->load->view('kpanel/magaza/yorum/yorumlar', $data);
        $this->load->view('inc/_footer', $data);
    }

    public function yorum_itiraz($id)
    {
        if (!magaza_check()) {
            redirect(base_url('magaza-olustur'));
            die();
        }

        $yorum = $this->magaza_model->yorum(array('yorum_id' => $id));

        if (!$this->input->post('itiraz')) {
            $alert = array(
                "title" => "Hata!",
                "text" => "Lütfen açıklama alanını boş bırakmayın!",
                "type" => "error"
            );

            $this->session->set_flashdata("alert", $alert);
            redirect(base_url("yorumlar"));
            die();
        }

        if ($yorum) {

            $data = array(
                'yorum_id' => $yorum->yorum_id,
                'itiraz' => $this->input->post('itiraz'),
                'itiraz_durum' => 0,
                'itiraz_uniq' => uniqid()
            );

            $this->magaza_model->yorum_itiraz_ekle($data);

            $alert = array(
                "title" => "Başarılı!",
                "text" => "Yorum itirazınız iletilmiştir..",
                "type" => "success"
            );

            $this->session->set_flashdata("alert", $alert);
            redirect(base_url("yorumlar"));
            die();
        } else {
            redirect(base_url('yorumlar'));
            die();
        }
    }

    public function kazanclar()
    {
        if (!magaza_check()) {
            redirect(base_url('magaza-olustur'));
            die();
        }
        $data = new stdClass();
        $kullanici = kullanicicek();
        $aylik = aylik_kazanc($kullanici->kullanici_id);
        $data->title = "Kazançlarım";
        $data->description = "";
        $data->keywords = "";
        $data->ayarlar = ayarlar();
        $data->kullanici = $kullanici;
        $data->magaza = $this->magaza_model->magaza(array('kullanici_id' => $kullanici->kullanici_id));
        $data->odenen_kazanclar = odenen_kazanclar($kullanici->kullanici_id);
        $data->odenebilir_kazanclar = odenebilir_kazanclar($kullanici->kullanici_id);
        $data->aylik_kazanc = aylik_toplam_kazanc($kullanici->kullanici_id);
        $data->gunluk_kazanc = gunluk_toplam_kazanc($kullanici->kullanici_id);
        if ($aylik['data']) {
            $data->aylar = json_encode($aylik['data']['ay'], JSON_UNESCAPED_UNICODE);
            $data->veriler = json_encode($aylik['data']['veri'], JSON_UNESCAPED_UNICODE);
        } else {
            $data->aylar = 0;
            $data->veriler = 0;
        }
        //$data->aylar = json_encode($aylik['data']['ay'], JSON_UNESCAPED_UNICODE);
        //$data->veriler = json_encode($aylik['data']['veri'], JSON_UNESCAPED_UNICODE);
        $data->toplam_kazanclar = toplam_kazanclar($kullanici->kullanici_id);
        $data->kadijoin = $this->magaza_model->getwho(array("kullanici_id" => $kullanici->kullanici_id));

        $this->load->view('inc/_header', $data);
        $this->load->view('kpanel/magaza/kazanclar', $data);
        $this->load->view('inc/_footer', $data);
    }

    public function odeme_talep()
    {

        $data = new stdClass();
        $kullanici = kullanicicek();
        $aylik = aylik_kazanc($kullanici->kullanici_id);

        /*$config = array();
        $config["base_url"] = base_url('odeme-talep');
        $config["total_rows"] = paracek_say($kullanici->kullanici_id);
        $config["per_page"] = 10;
        $config["uri_segment"] = 2;


        $config['first_link'] = '&laquo';
        $config['last_link'] = '&raquo';
        $config['attributes'] = array('class' => 'page-link');

        $config['full_tag_open'] = "<ul class='pagination justify-content-center'>";
        $config['full_tag_close'] = "</ul>";
        $config['num_tag_open'] = '<li class="page-item">';
        $config['num_tag_close'] = '</li>';
        $config['cur_tag_open'] = '<li class="page-item active"><a class="page-link" href="#">';
        $config['cur_tag_close'] = "</a></li>";

        $config['next_link'] = 'İleri';
        $config['next_tag_open'] = '<li class="page-item">';
        $config['next_tagl_close'] = "</li>";

        $config['prev_link'] = 'Geri';
        $config['prev_tag_open'] = '<li class="page-item">';
        $config['prev_tagl_close'] = "</li>";

        $config['first_tag_open'] = '<li class="page-item">';
        $config['first_tagl_close'] = "</li>";
        $config['last_tag_open'] = '<li class="page-item">';
        $config['last_tagl_close'] = "</li>";

        $this->pagination->initialize($config);

        $page = ($this->uri->segment(2)) ? $this->uri->segment(2) : 0;
        $data->links = $this->pagination->create_links();
        $data->odeme_taleplerim = $this->magaza_model->paracek_sayfalama(array("para_cek.kullanici_id" => $kullanici->kullanici_id), $config["per_page"], $page);*/

        $data->title = "Para Çekme Talebi";
        $data->description = "";
        $data->keywords = "";
        $data->ayarlar = ayarlar();
        $data->kullanici = $kullanici;
        $data->magaza = $this->magaza_model->magaza(array('kullanici_id' => $kullanici->kullanici_id));
        $data->odenebilir_kazanclar = odenebilir_kazanclar($kullanici->kullanici_id);
        $data->kadijoin = $this->magaza_model->getwho(array("kullanici_id" => $kullanici->kullanici_id));

        // Gold Alım - Satım

        $data->bekleyen_satislarim = $this->siparis_model->siteye_sattiklarim_getir(['user_id' => $kullanici->kullanici_id, 'status' => 0, 'type' => 1]);
        $data->tamamlanan_satislarim = $this->siparis_model->siteye_sattiklarim_getir(['user_id' => $kullanici->kullanici_id, 'status' => 1, 'type' => 1]);
        $data->iptal_edilen_satislarim = $this->siparis_model->siteye_sattiklarim_getir(['user_id' => $kullanici->kullanici_id, 'status' => 2, 'type' => 1]);

        $data->bekleyen_alislarim = $this->siparis_model->siteye_sattiklarim_getir(['user_id' => $kullanici->kullanici_id, 'status' => 0, 'type' => 2]);
        $data->tamamlanan_alislarim = $this->siparis_model->siteye_sattiklarim_getir(['user_id' => $kullanici->kullanici_id, 'status' => 1, 'type' => 2]);
        $data->iptal_edilen_alislarim = $this->siparis_model->siteye_sattiklarim_getir(['user_id' => $kullanici->kullanici_id, 'status' => 2, 'type' => 2]);

        // sorular

        $data->sorular = $this->magaza_model->get_my_sorular($kullanici->kullanici_id);
        foreach ($data->sorular as $key => $val) {
            $data->sorular[$key]->soru_cevap = $this->magaza_model->get_soru_cevap($val->soru_id);
        }

        // destek taleplerim

        $data->taleplerim = $this->magaza_model->get_destek_taleperim($kullanici->kullanici_id);

        //para çek

        $data->odenebilir_kazanclar = !empty(odenebilir_kazanclar($kullanici->kullanici_id)) ? odenebilir_kazanclar($kullanici->kullanici_id) : '0.00';
        // profil sayılar

        $data->sattigim_gold_count = count($data->tamamlanan_satislarim);
        $data->destek_talep_count = count($data->taleplerim);
        $data->aldigim_gold_count = count($data->tamamlanan_alislarim);

        $this->load->view('inc/_header', $data);
        $this->load->view('kpanel/yeni/odeme_talep', $data);
        $this->load->view('inc/_footer', $data);
    }

    public function ininalbilgi()
    {
        $kullanici = kullanicicek();

        if (!$_POST) {
            redirect(base_url());
        }

        $paracek = $this->magaza_model->paracek_check($kullanici->kullanici_id);
        if ($paracek) {
            $alert = array(
                "title" => "Hata!",
                "text" => "Bekleyen Para Çekme Talebiniz Bulunmaktadır. Daha Sonra Tekrar Deneyin..",
                "type" => "warning"
            );

            $this->session->set_flashdata("alert", $alert);
            redirect(base_url('odeme-talep'));
            die();
        }

        $insert = $this->destek_model->kullaniciupdate(
            array("kullanici_id" => $kullanici->kullanici_id),
            array(
                "ininal_no" => htmlspecialchars($this->input->post("iban")),
                "alici_ininal" => htmlspecialchars($this->input->post("alici")),
                "tel_ininal" => htmlspecialchars(trim($this->input->post("telefon"))),
            )
        );

        $alert = array(
            "title" => "İşlem Başarılı",
            "text" => "Ininal Ödeme Talep Bilgileri Güncellendi",
            "type" => "success"
        );

        $this->session->set_flashdata("alert", $alert);
        redirect(base_url('odeme-talep'));
        die();
    }

    public function paparabilgi()
    {
        $kullanici = kullanicicek();

        if (!$_POST) {
            redirect(base_url());
        }

        $paracek = $this->magaza_model->paracek_check($kullanici->kullanici_id);
        if ($paracek) {
            $alert = array(
                "title" => "Hata!",
                "text" => "Bekleyen Para Çekme Talebiniz Bulunmaktadır. Daha Sonra Tekrar Deneyin..",
                "type" => "warning"
            );

            $this->session->set_flashdata("alert", $alert);
            redirect(base_url('odeme-talep'));
            die();
        }

        $insert = $this->destek_model->kullaniciupdate(
            array("kullanici_id" => $kullanici->kullanici_id),
            array(
                "papara_no" => htmlspecialchars($this->input->post("iban")),
                "alici_papara" => htmlspecialchars($this->input->post("alici")),
                "tel_papara" => htmlspecialchars(trim($this->input->post("telefon"))),
            )
        );

        $alert = array(
            "title" => "İşlem Başarılı",
            "text" => "Papara Ödeme Talep Bilgileri Güncellendi",
            "type" => "success"
        );

        $this->session->set_flashdata("alert", $alert);
        redirect(base_url('odeme-talep'));
        die();
    }

    public function iban_bilgi()
    {
        $kullanici = kullanicicek();

        if (!$_POST) {
            redirect(base_url());
        }

        $paracek = $this->magaza_model->paracek_check($kullanici->kullanici_id);
        if ($paracek) {
            $alert = array(
                "title" => "Hata!",
                "text" => "Bekleyen Para Çekme Talebiniz Bulunmaktadır. Daha Sonra Tekrar Deneyin..",
                "type" => "warning"
            );

            $this->session->set_flashdata("alert", $alert);
            redirect(base_url('odeme-talep'));
            die();
        }

        if ($this->input->post("iban")) {
            if (!checkIBAN(htmlspecialchars(trim($this->input->post("iban"))))) {
                $alert = array(
                    "title" => "Hata!",
                    "text" => "IBAN Adresiniz Doğru Değildir! Lütfen Kontrol Ediniz.",
                    "type" => "warning"
                );
                $this->session->set_flashdata("alert", $alert);
                redirect(base_url('odeme-talep'));
                die();
            }
        }

        $insert = $this->destek_model->kullaniciupdate(
            array("kullanici_id" => $kullanici->kullanici_id),
            array(
                "kullanici_iban" => htmlspecialchars(tum_bosluk_sil($this->input->post("iban"))),
                "kullanici_alici" => htmlspecialchars($this->input->post("alici")),
                "kullanici_alici_tel" => htmlspecialchars(trim($this->input->post("telefon"))),
            )
        );

        $alert = array(
            "title" => "İşlem Başarılı",
            "text" => "Ödeme Talep Bilgileri Güncellendi",
            "type" => "success"
        );

        $this->session->set_flashdata("alert", $alert);
        redirect(base_url('odeme-talep'));
        die();
    }

    public function para_cekme()
    {
        $kullanici = kullanicicek();
        $ayar = ayarlar();
        $magaza = $this->magaza_model->magaza(array('kullanici_id' => $kullanici->kullanici_id));

        $odenebilir_kazanclar = $kullanici->bakiye;
        if ($odenebilir_kazanclar < $ayar->para_cekme_limit) {
            $alert = array(
                "title" => "Hata!",
                "text" => "Para Çekme Talebiniz Yapılamamıştır. Para Çekme Alt Limiti " . $ayar->para_cekme_limit . "₺ dir.",
                "type" => "warning"
            );

            $this->session->set_flashdata("alert", $alert);
            redirect(base_url('odeme-talep'));
            die();
        }
        if ($this->input->post("bankname") == "banka") {
            if (!$kullanici->kullanici_iban || !$kullanici->kullanici_alici || !$kullanici->kullanici_alici_tel) {
                $alert = array(
                    "title" => "Hata!",
                    "text" => "Lütfen Banka Bilgilerinizin Dolu Olduğuna Emin Olun!",
                    "type" => "warning"
                );

                $this->session->set_flashdata("alert", $alert);
                redirect(base_url('odeme-talep'));
                die();
            }
        }
        if ($this->input->post("bankname") == "ininal") {
            if (!$kullanici->ininal_no || !$kullanici->tel_ininal || !$kullanici->alici_ininal) {
                $alert = array(
                    "title" => "Hata!",
                    "text" => "Lütfen Banka Bilgilerinizin Dolu Olduğuna Emin Olun!",
                    "type" => "warning"
                );

                $this->session->set_flashdata("alert", $alert);
                redirect(base_url('odeme-talep'));
                die();
            }
        }


        $paracek = $this->magaza_model->paracek_check($kullanici->kullanici_id);
        if ($paracek) {
            $alert = array(
                "title" => "Hata!",
                "text" => "Bekleyen Para Çekme Talebiniz Bulunmaktadır. Daha Sonra Tekrar Deneyin..",
                "type" => "warning"
            );

            $this->session->set_flashdata("alert", $alert);
            redirect(base_url('odeme-talep'));
            die();
        }


        /*$odenebilir_siparisler = $this->magaza_model->odenebilir_kazanclar_id($magaza->magaza_id);
        $id = array();
        foreach ($odenebilir_siparisler as $idler) {
            $id[] = $idler->id;
        }*/


        $data = array(
            'kullanici_id' => $kullanici->kullanici_id,
            'paracek_tutar' => $odenebilir_kazanclar,
            /*'paracek_json' => json_encode($id),*/
            'paracek_durum' => 0,
            'paracek_no' => uretken(5),
            'paracek_uniq' => uniqid()
        );

        $this->yonetim_model->update_user_balance($kullanici->kullanici_id, 0);
        $this->magaza_model->paracek_add($data);


        $alert = array(
            "title" => "İşlem Başarılı",
            "text" => "Para Çekim Talebiniz Başarıyla Oluşturulmuştur.",
            "type" => "success"
        );

        $this->session->set_flashdata("alert", $alert);
        redirect(base_url('odeme-talep'));
        die();
    }

    public function satislarim()
    {

        if (!magaza_check()) {
            redirect(base_url('magaza-olustur'));
            die();
        }

        $data = new stdClass();
        $kullanici = kullanicicek();

        $magaza = $this->magaza_model->magaza(array('kullanici_id' => $kullanici->kullanici_id));

        $config = array();
        $config["base_url"] = base_url('satislarim');
        $config["total_rows"] = siparis_say($kullanici->kullanici_id);
        $config["per_page"] = 12;
        $config["uri_segment"] = 2;


        $config['first_link'] = '&laquo';
        $config['last_link'] = '&raquo';
        $config['attributes'] = array('class' => 'page-link');

        $config['full_tag_open'] = "<ul class='pagination justify-content-center'>";
        $config['full_tag_close'] = "</ul>";
        $config['num_tag_open'] = '<li class="page-item">';
        $config['num_tag_close'] = '</li>';
        $config['cur_tag_open'] = '<li class="page-item active"><a class="page-link" href="#">';
        $config['cur_tag_close'] = "</a></li>";

        $config['next_link'] = 'İleri';
        $config['next_tag_open'] = '<li class="page-item">';
        $config['next_tagl_close'] = "</li>";

        $config['prev_link'] = 'Geri';
        $config['prev_tag_open'] = '<li class="page-item">';
        $config['prev_tagl_close'] = "</li>";

        $config['first_tag_open'] = '<li class="page-item">';
        $config['first_tagl_close'] = "</li>";
        $config['last_tag_open'] = '<li class="page-item">';
        $config['last_tagl_close'] = "</li>";

        $this->pagination->initialize($config);

        $page = ($this->uri->segment(2)) ? $this->uri->segment(2) : 0;
        $data->links = $this->pagination->create_links();
        $data->siparislerim = $this->siparis_model->satislarim_sayfalama(array('siparis.magaza' => $magaza->magaza_id), $config["per_page"], $page);

        $data->title = "Satışlarım";
        $data->description = "";
        $data->keywords = "";
        $data->ayarlar = ayarlar();
        $data->kullanici = $kullanici;
        $data->magaza = $magaza;
        $data->kadijoin = $this->magaza_model->getwho(array("kullanici_id" => $kullanici->kullanici_id));

        $this->load->view('inc/_header', $data);
        $this->load->view('kpanel/magaza/satislarim', $data);
        $this->load->view('inc/_footer', $data);
    }

    public function satis_detay($siparis_no)
    {

        if (!magaza_check()) {
            redirect(base_url('magaza-olustur'));
            die();
        }

        $data = new stdClass();
        $kullanici = kullanicicek();

        $magaza = $this->magaza_model->magaza(array('kullanici_id' => $kullanici->kullanici_id));

        $siparis = $this->siparis_model->siparis(array('siparis.magaza' => $magaza->magaza_id, 'siparis.siparis_no' => $siparis_no));
        if (!$siparis) {
            redirect(base_url('satislarim'));
            die();
        }

        $data->title = "Sipariş Detay";
        $data->description = "";
        $data->keywords = "";
        $data->ayarlar = ayarlar();
        $data->kullanici = $kullanici;
        $data->magaza = $magaza;
        $data->siparis = $siparis;
        $data->kadijoin = $this->magaza_model->getwho(array("kullanici_id" => $kullanici->kullanici_id));

        $this->load->view('inc/_header', $data);
        $this->load->view('kpanel/magaza/satis-detay', $data);
        $this->load->view('inc/_footer', $data);
    }

    public function magaza_foto()
    {
        if (!magaza_check()) {
            redirect(base_url('magaza-olustur'));
            die();
        }

        $kullanici = kullanicicek();

        $magaza = $this->magaza_model->magaza(array('kullanici_id' => $kullanici->kullanici_id));

        if ($_FILES["file"]["name"] || $_FILES['banner']["name"]) {
            $config["allowed_types"] = "jpg|jpeg|png";
            $config["upload_path"] = "uploads/magaza/";
            $config['encrypt_name'] = TRUE;

            $this->load->library("upload", $config);

            if ($_FILES["file"]["name"]) {
                $upload = $this->upload->do_upload("file");
                $uploaded_file = $this->upload->data("file_name");
                $insert = $this->magaza_model->magaza_update(
                    array("magaza_id" => $magaza->magaza_id),
                    array(
                        "magaza_resim" => "uploads/magaza/" . $uploaded_file,
                    )
                );
            } else if ($_FILES['banner']["name"]) {
                $upload = $this->upload->do_upload("banner");
                $uploaded_file = $this->upload->data("file_name");
                $insert = $this->magaza_model->magaza_update(
                    array("magaza_id" => $magaza->magaza_id),
                    array(
                        "magaza_banner" => "uploads/magaza/" . $uploaded_file,
                    )
                );
            }

            if ($upload) {
                $alert = array(
                    "title" => "İşlem Başarılı",
                    "text" => "Mağaza Başarılı Şekilde Güncellendi",
                    "type" => "success"
                );

                $this->session->set_flashdata("alert", $alert);
                redirect(base_url('m/' . $magaza->magaza_seo));
                die();
            }
        } else {

            $alert = array(
                "title" => "Hata!",
                "text" => "Fotoğraf Seçmediniz!",
                "type" => "warning"
            );

            $this->session->set_flashdata("alert", $alert);
            redirect(base_url('m/' . $magaza->magaza_seo));
            die();
        }
    }

    public function sosyal_ayar()
    {
        if (!magaza_check()) {
            redirect(base_url('magaza-olustur'));
            die();
        }

        $kullanici = kullanicicek();

        $magaza = $this->magaza_model->magaza(array('kullanici_id' => $kullanici->kullanici_id));
        $data->kadijoin = $this->magaza_model->getwho(array("kullanici_id" => $kullanici->kullanici_id));

        $insert = $this->magaza_model->magaza_update(
            array("magaza_id" => $magaza->magaza_id),
            array(
                "facebook" => $this->input->post('facebook'),
                "twitter" => $this->input->post('twitter'),
                "youtube" => $this->input->post('youtube'),
                "instagram" => $this->input->post('instagram'),
                "web_site" => $this->input->post('web_site'),
            )
        );

        $alert = array(
            "title" => "İşlem Başarılı",
            "text" => "Mağaza Sosyal Medya Ayarları Başarılı Şekilde Güncellendi",
            "type" => "success"
        );

        $this->session->set_flashdata("alert", $alert);
        redirect(base_url('m/' . $magaza->magaza_seo));
        die();
    }

    public function urun_reklam($uniq)
    {
        if (!magaza_check()) {
            redirect(base_url('magaza-olustur'));
            die();
        }
        $data = new stdClass();
        $kullanici = kullanicicek();
        $urun = $this->magaza_model->urun(array('kullanici_id' => $kullanici->kullanici_id, 'urun_uniq' => $uniq, 'urun_durum' => 1));

        if (!$urun) {
            redirect(base_url());
            die();
        }

        $data->title = "Ürün Reklam";
        $data->description = "";
        $data->keywords = "";
        $data->ayarlar = ayarlar();
        $data->kullanici = $kullanici;
        $data->magaza = $this->magaza_model->magaza(array('kullanici_id' => $kullanici->kullanici_id));
        $data->urun = $urun;
        $data->reklamlar = $this->magaza_model->reklamlar(array('reklam.urun_id' => $urun->urun_id));
        $data->kadijoin = $this->magaza_model->getwho(array("kullanici_id" => $kullanici->kullanici_id));

        $this->load->view('inc/_header', $data);
        $this->load->view('kpanel/magaza/urun/urun-reklam', $data);
        $this->load->view('inc/_footer', $data);
    }

    public function reklam_olustur($uniq)
    {
        if (!magaza_check()) {
            redirect(base_url('magaza-olustur'));
            die();
        }
        $kullanici = kullanicicek();
        $urun = $this->magaza_model->urun(array('kullanici_id' => $kullanici->kullanici_id, 'urun_uniq' => $uniq, 'urun_durum' => 1));
        if (!$urun) {
            redirect(base_url());
            die();
        }

        if (!$this->input->post('reklam_tur')) {
            $alert = array(
                "title" => "Uyarı!",
                "text" => "Lütfen Reklam Türü Seçin!",
                "type" => "warning"
            );

            $this->session->set_flashdata("alert", $alert);
            redirect(base_url('urun-reklam/' . $uniq));
            die();
        }

        if (!$this->input->post('gun_sayisi')) {
            $alert = array(
                "title" => "Uyarı!",
                "text" => "Lütfen Gün Sayısı Girin!",
                "type" => "warning"
            );

            $this->session->set_flashdata("alert", $alert);
            redirect(base_url('urun-reklam/' . $uniq));
            die();
        }

        if (!is_numeric($this->input->post('gun_sayisi'))) {
            $alert = array(
                "title" => "Uyarı!",
                "text" => "Lütfen Gün Sayısını Doğru Girin!",
                "type" => "warning"
            );

            $this->session->set_flashdata("alert", $alert);
            redirect(base_url('urun-reklam/' . $uniq));
            die();
        }

        $reklamsay = reklam_kontrol($urun->urun_id, $this->input->post('reklam_tur'));

        if (!$reklamsay) {
            $alert = array(
                "title" => "Uyarı!",
                "text" => "Ürüne Ait Reklam Var!",
                "type" => "warning"
            );

            $this->session->set_flashdata("alert", $alert);
            redirect(base_url('urun-reklam/' . $uniq));
            die();
        }

        $reklam_bitis = date('Y-m-d H:i:s', strtotime(date('Y-m-d H:i:s') . ' + ' . $this->input->post('gun_sayisi') . ' days'));
        $ayarlar = ayarlar();

        if ($this->input->post('reklam_tur') == 'anasayfa') {
            $urun_fiyat = $ayarlar->anasayfa_urun_reklam * $this->input->post('gun_sayisi');
        } elseif ($this->input->post('reklam_tur') == 'kategori') {
            $urun_fiyat = $ayarlar->kategori_urun_reklam * $this->input->post('gun_sayisi');
        } else {
            $alert = array(
                "title" => "Uyarı!",
                "text" => "Ürün Türü Desteklenmiyor!",
                "type" => "warning"
            );

            $this->session->set_flashdata("alert", $alert);
            redirect(base_url('urun-reklam/' . $uniq));
            die();
        }

        $data = array(
            'kullanici_id' => $kullanici->kullanici_id,
            'urun_id' => $urun->urun_id,
            'magaza_id' => $urun->magaza_id,
            'reklam_turu' => $this->input->post('reklam_tur'),
            'reklam_tutar' => $urun_fiyat,
            'reklam_baslangic' => date('Y-m-d H:i:s'),
            'reklam_bitis' => $reklam_bitis,
            'reklam_gun' => $this->input->post('gun_sayisi'),
            'reklam_durum' => 0,
            'reklam_uniq' => uniqid(),
            'reklam_no' => uretken(6)
        );

        $this->magaza_model->reklam_add($data);

        $alert = array(
            "title" => "Başarılı!",
            "text" => "Siparişiniz Oluşturuldu!",
            "type" => "success"
        );

        $this->session->set_flashdata("alert", $alert);
        redirect(base_url('urun-reklam/' . $uniq));
        die();
    }

    public function initialize_iyzico()
    {
        $ayarlar = ayarlar();
        require_once('application/libraries/iyzipay/IyzipayBootstrap.php');
        IyzipayBootstrap::init();
        $options = new \Iyzipay\Options();
        $options->setApiKey($ayarlar->iyzico_api);
        $options->setSecretKey($ayarlar->iyzico_secret);
        $options->setBaseUrl("https://sandbox-api.iyzipay.com");
        return $options;
    }

    public function reklam_odeme($uniq)
    {
        if (!magaza_check()) {
            redirect(base_url('magaza-olustur'));
            die();
        }
        $data = new stdClass();
        $kullanici = kullanicicek();
        $reklam = $this->magaza_model->reklam(array('reklam.reklam_uniq' => $uniq, 'reklam.kullanici_id' => $kullanici->kullanici_id, 'reklam.reklam_durum' => 0));

        if (!$reklam) {
            redirect(base_url());
            die();
        }

        $data->title = "Reklam Ödeme";
        $data->description = "";
        $data->keywords = "";
        $data->ayarlar = ayarlar();
        $data->kullanici = $kullanici;
        $data->magaza = $this->magaza_model->magaza(array('kullanici_id' => $kullanici->kullanici_id));
        $data->reklam = $reklam;
        $data->options = $this->initialize_iyzico();

        $this->load->view('inc/_header', $data);
        $this->load->view('kpanel/magaza/urun/reklam-odeme', $data);
        $this->load->view('inc/_footer', $data);
    }

    public function reklam_odeme_iptal($uniq)
    {
        if (!magaza_check()) {
            redirect(base_url('magaza-olustur'));
            die();
        }
        $data = new stdClass();
        $kullanici = kullanicicek();
        $reklam = $this->magaza_model->reklam(array('reklam.reklam_uniq' => $uniq, 'reklam.kullanici_id' => $kullanici->kullanici_id, 'reklam.reklam_durum' => 0));

        if (!$reklam) {
            redirect(base_url('ilanlarim'));
            die();
        }

        $sil = $this->magaza_model->reklam_delete(array('reklam.reklam_uniq' => $uniq, 'reklam.kullanici_id' => $kullanici->kullanici_id, 'reklam.reklam_durum' => 0));

        if ($sil) {
            $alert = array(
                "title" => "Başarılı!",
                "text" => "Reklam siparişiniz iptal edildi!",
                "type" => "success"
            );
            $this->session->set_flashdata("alert", $alert);
            redirect($_SERVER['HTTP_REFERER']);
            die();
        } else {
            $alert = array(
                "title" => "Hata!",
                "text" => "Bir sorun oluştu!",
                "type" => "warning"
            );
            $this->session->set_flashdata("alert", $alert);
            redirect($_SERVER['HTTP_REFERER']);
            die();
        }
    }

    public function reklam_odeme_onay()
    {

        if (!magaza_check()) {
            redirect(base_url('magaza-olustur'));
            die();
        }
        $options = $this->initialize_iyzico();
        $kullanici = kullanicicek();
        $request = new \Iyzipay\Request\RetrieveCheckoutFormRequest();
        $request->setLocale(\Iyzipay\Model\Locale::TR);
        $request->setConversationId("123456789");
        $request->setToken($_POST["token"]);
        $checkoutForm = \Iyzipay\Model\CheckoutForm::retrieve($request, $options);
        if ($checkoutForm->getStatus() == "success") {
            $reklam = $this->magaza_model->reklam(array('reklam.reklam_no' => $checkoutForm->getBasketId()));
            $reklam_bitis = date('Y-m-d H:i:s', strtotime(date('Y-m-d H:i:s') . ' + ' . $reklam->reklam_gun . ' days'));
            $urun = $this->magaza_model->urun(array('urun_id' => $reklam->urun_id));
            if ($reklam) {

                $this->magaza_model->reklam_update(array('reklam_no' => $checkoutForm->getBasketId(), 'kullanici_id' => $kullanici->kullanici_id), array('reklam_durum' => 1, 'reklam_bitis' => $reklam_bitis));

                if ($reklam->reklam_turu == 'anasayfa') {
                    $this->magaza_model->urun_update(array('urun_id' => $reklam->urun_id), array('urun_populer' => 1));
                } elseif ($reklam->reklam_turu == 'kategori') {
                    $this->magaza_model->urun_update(array('urun_id' => $reklam->urun_id), array('urun_populer_kat' => 1));
                }

                $alert = array(
                    "title" => "Başarılı!",
                    "text" => "Ödemeniz Yapılmıştır..",
                    "type" => "success"
                );
                $this->session->set_flashdata("alert", $alert);
                redirect(base_url('urun-reklam/' . $urun->urun_uniq));
                die();
            }
        } else {
            $data['status'] = 'Ödeme alınamadı, bir hata oluştu.';
        }
    }

    /**
     * Mesajlaşma Sistemi
     */
    public function mesajlar()
    {
        $data = new stdClass();
        $kullanici = kullanicicek();
        $data->title = "Gelen Mesajlar";
        $data->description = "";
        $data->keywords = "";
        $data->ayarlar = ayarlar();
        $data->kullanici = $kullanici;
        $data->mesaj = $this->mesaj_model->amesaj(array('alan_id' => $kullanici->kullanici_id));
        //prex($data->mesaj[0]);
        //prex(magaza_kbilgi($data->mesaj[0]->gonderen_id));
        $data->giden_mesaj = $this->mesaj_model->amesaj(array('gonderen_id' => $kullanici->kullanici_id));
        $data->magaza = $this->magaza_model->magaza(array('kullanici_id' => $kullanici->kullanici_id));

        $this->load->view('inc/_header', $data);
        $this->load->view('kpanel/mesaj/index', $data);
        $this->load->view('inc/_footer', $data);
    }

    public function mesajlar_tasarim()
    {
        $data = new stdClass();
        $kullanici = kullanicicek();
        $data->title = "Gelen Mesajlar";
        $data->description = "";
        $data->keywords = "";
        $data->ayarlar = ayarlar();
        $data->kullanici = $kullanici;
        $data->mesaj = $this->mesaj_model->amesaj(array('alan_id' => $kullanici->kullanici_id));
        //prex($data->mesaj[0]);
        //prex(magaza_kbilgi($data->mesaj[0]->gonderen_id));
        $data->giden_mesaj = $this->mesaj_model->amesaj(array('gonderen_id' => $kullanici->kullanici_id));
        $data->magaza = $this->magaza_model->magaza(array('kullanici_id' => $kullanici->kullanici_id));

        $this->load->view('inc/_header', $data);
        $this->load->view('kpanel/mesaj/tasarim', $data);
        $this->load->view('inc/_footer', $data);
    }

    public function giden_mesajlar()
    {
        $data = new stdClass();
        $kullanici = kullanicicek();
        $data->title = "Giden Mesajlar";
        $data->description = "";
        $data->keywords = "";
        $data->ayarlar = ayarlar();
        $data->kullanici = $kullanici;
        $data->mesaj = $this->mesaj_model->amesaj(array('gonderen_id' => $kullanici->kullanici_id));
        $data->gelen_mesaj = $this->mesaj_model->amesaj(array('alan_id' => $kullanici->kullanici_id));
        $data->magaza = $this->magaza_model->magaza(array('kullanici_id' => $kullanici->kullanici_id));

        $this->load->view('inc/_header', $data);
        $this->load->view('kpanel/mesaj/giden-mesajlar', $data);
        $this->load->view('inc/_footer', $data);
    }

    public function yeni_mesaj_magaza_sec()
    {
        $data = new stdClass();
        $kullanici = kullanicicek();
        $data->title = "Yeni Mesaj";
        $data->description = "";
        $data->keywords = "";
        $data->ayarlar = ayarlar();
        $data->kullanici = $kullanici;
        $data->magazalar = $this->magaza_model->magazalar_tam();
        $this->load->view('inc/_header', $data);
        $this->load->view('kpanel/mesaj/yeni_magaza_sec', $data);
        $this->load->view('inc/_footer', $data);
    }

    public function yeni_mesaj($magaza_uniq)
    {
        $magaza = magaza_bilgi_uniq($magaza_uniq);

        if (!$magaza) {
            redirect(base_url());
            die();
        }
        $data = new stdClass();
        $kullanici = kullanicicek();
        $data->title = "Yeni Mesaj";
        $data->description = "";
        $data->keywords = "";
        $data->ayarlar = ayarlar();
        $data->kullanici = $kullanici;
        $data->alici = $magaza;
        $data->magaza = $this->magaza_model->magaza(array('kullanici_id' => $kullanici->kullanici_id));

        $this->load->view('inc/_header', $data);
        $this->load->view('kpanel/mesaj/yeni', $data);
        $this->load->view('inc/_footer', $data);
    }

    public function saticiya_mesaj_gonder()
    {
        $magaza = $this->input->post('magaza');

    }

    public function yeni_mesaj_post($magaza_uniq)
    {
        $magaza = magaza_bilgi_uniq($magaza_uniq);
        $kullanici = kullanicicek();

        if (!$magaza) {
            redirect(base_url());
            die();
        }

        if (!$this->input->post('mesaj')) {
            $alert = array(
                "title" => "Uyarı!",
                "text" => "Lütfen Mesaj Alanını Boş Bırakmayın.",
                "type" => "warning"
            );

            $this->session->set_flashdata("alert", $alert);
            redirect(base_url('yeni-mesaj/' . $magaza_uniq));
            die();
        }

        if ($kullanici->kullanici_id == $magaza->kullanici_id) {
            $alert = array(
                "title" => "Hata!",
                "text" => "Kendinize mesaj gönderemezsiniz!",
                "type" => "warning"
            );

            $this->session->set_flashdata("alert", $alert);
            redirect(base_url('mesajlar'));
            die();
        } else {
            $amesaj_id = $this->mesaj_model->add_amesaj($magaza_uniq);
            if ($amesaj_id) {

                $data = array(
                    'amesaj_id' => $amesaj_id,
                    'alan_id' => $magaza->kullanici_id,
                    'gonderen_id' => $kullanici->kullanici_id,
                    'mesaj' => $this->input->post('mesaj'),
                    'okunma' => 1,
                    'uniq' => uniqid()
                );

                $this->mesaj_model->mesaj_add($data);

                $kullanici_bilgi = kullanici_bilgi($magaza->kullanici_id);
                $siteayar = ayarlar();
                mailGonder($kullanici_bilgi->kullanici_mail, 'Bir Yeni Mesajınız Var! 🔔', '<style>
						/* Reset styles */ 
						body { margin: 0; padding: 0; min-width: 100%; width: 100% !important; height: 100% !important;}
						body, table, td, div, p, a { -webkit-font-smoothing: antialiased; text-size-adjust: 100%; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; line-height: 100%; }
						table, td { mso-table-lspace: 0pt; mso-table-rspace: 0pt; border-collapse: collapse !important; border-spacing: 0; }
						img { border: 0; line-height: 100%; outline: none; text-decoration: none; -ms-interpolation-mode: bicubic; }
         							#outlook a { padding: 0; }
						.ReadMsgBody { width: 100%; } .ExternalClass { width: 100%; }
						.ExternalClass, .ExternalClass p, .ExternalClass span, .ExternalClass font, .ExternalClass td, .ExternalClass div { line-height: 100%; }
						/* Rounded corners for advanced mail clients only */ 
						@media all and (min-width: 560px) {
							.container { border-radius: 8px; -webkit-border-radius: 8px; -moz-border-radius: 8px; -khtml-border-radius: 8px;}
						}
						/* Set color for auto links (addresses, dates, etc.) */ 
						a, a:hover {
							color: #127DB3;
						}
						.footer a, .footer a:hover {
							color: #999999;
						}
						</style>

						<body topmargin="0" rightmargin="0" bottommargin="0" leftmargin="0" marginwidth="0" marginheight="0" width="100%" style="border-collapse: collapse; border-spacing: 0; margin: 0; padding: 0; width: 100%; height: 100%; -webkit-font-smoothing: antialiased; text-size-adjust: 100%; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; line-height: 100%;
						background-color: #F0F0F0;
						color: #000000;"
						bgcolor="#F0F0F0"
						text="#000000">
						<!-- SECTION / BACKGROUND -->
						<!-- Set message background color one again -->
						<table width="100%" align="center" border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse; border-spacing: 0; margin: 0; padding: 0; width: 100%;" class="background">
						<tr>
						<td align="center" valign="top" style="border-collapse: collapse; border-spacing: 0; margin: 0; padding: 0;"
						bgcolor="#F0F0F0">
						<!-- WRAPPER -->
						<!-- Set wrapper width (twice) -->
						<table border="0" cellpadding="0" cellspacing="0" align="center"
						width="560" style="border-collapse: collapse; border-spacing: 0; padding: 0; width: inherit;
						max-width: 560px;" class="wrapper">
						<tr>
						<td align="center" valign="top" style="border-collapse: collapse; border-spacing: 0; margin: 0; padding: 0; padding-left: 6.25%; padding-right: 6.25%; width: 87.5%;
						padding-top: 20px;
						padding-bottom: 20px;">

						<a target="_blank" style="text-decoration: none;"
						href="' . base_url() . '"><img border="0" vspace="0" hspace="0"
						src="' . base_url($siteayar->site_logo) . '"
						width="100"
						alt="Logo" title="Yeni bir mesajınız var" style="
						color: #000000;
						font-size: 10px; margin: 0; padding: 0; outline: none; text-decoration: none; -ms-interpolation-mode: bicubic; border: none; display: block;" /></a>
						</td>
						</tr>
						<!-- End of WRAPPER -->
						</table>
						<!-- WRAPPER / CONTEINER -->
						<!-- Set conteiner background color -->
						<table border="0" cellpadding="0" cellspacing="0" align="center"
						bgcolor="#FFFFFF"
						width="560" style="border-collapse: collapse; border-spacing: 0; padding: 0; width: inherit;
						max-width: 560px;" class="container">
						<!-- HEADER -->
						<!-- Set text color and font family ("sans-serif" or "Georgia, serif") -->
						<tr>
						<td align="center" valign="top" style="border-collapse: collapse; border-spacing: 0; margin: 0; padding: 0; padding-left: 6.25%; padding-right: 6.25%; width: 87.5%; font-size: 24px; font-weight: bold; line-height: 130%;
						padding-top: 25px;
						color: #000000;
						font-family: sans-serif;" class="header">Yeni Mesajınız Var!</td>
						</tr>

						<tr>
						<td align="center" valign="top" style="border-collapse: collapse; border-spacing: 0; margin: 0; padding: 0; padding-left: 6.25%; padding-right: 6.25%; width: 87.5%; font-size: 17px; font-weight: 400; line-height: 160%;
						padding-top: 25px; 
						color: #000000;
						font-family: sans-serif;" class="paragraph">Bu Mesaj ' . base_url() . ' Gönderilmiştir.</td>
						</tr>

						<tr>
						<td align="center" valign="top" style="border-collapse: collapse; border-spacing: 0; margin: 0; padding: 0; padding-left: 6.25%; padding-right: 6.25%; width: 87.5%; font-size: 17px; font-weight: 400; line-height: 160%;
						padding-top: 25px; 
						color: #000000;
						font-family: sans-serif;" class="paragraph"> Yeni Mesajınız : <br> ' . $this->input->post('mesaj') . ' <br>
						</td>
						</tr>

						<tr>
						<td align="center" valign="top" style="border-collapse: collapse; border-spacing: 0; margin: 0; padding: 0; padding-left: 6.25%; padding-right: 6.25%; width: 87.5%;
						padding-top: 25px;
						padding-bottom: 5px;" class="button">
						<a
						href="#adres" target="_blank" style="text-decoration: underline;">
						<table border="0" cellpadding="0" cellspacing="0" align="center" style="max-width: 240px; min-width: 120px; border-collapse: collapse; border-spacing: 0; padding: 0;">
						</table></a>
						</td>
						</tr>
						<!-- LINE -->
						<!-- Set line color -->
						<tr>
						<td align="center" valign="top" style="border-collapse: collapse; border-spacing: 0; margin: 0; padding: 0; padding-left: 6.25%; padding-right: 6.25%; width: 87.5%;
						padding-top: 25px;" class="line">
						<hr
						color="#E0E0E0" align="center" width="100%" size="1" noshade style="margin: 0; padding: 0;" />
						</td>
						</tr>

						<tr>
						<td align="center" valign="top" style="border-collapse: collapse; border-spacing: 0; margin: 0; padding: 0; padding-left: 6.25%; padding-right: 6.25%; width: 87.5%;
						padding-top: 25px;" class="line">
						<hr
						color="#E0E0E0" align="center" width="100%" size="1" noshade style="margin: 0; padding: 0;" />
						</td>
						</tr>
						</table>
						<!-- WRAPPER -->
						<!-- Set wrapper width (twice) -->
						<table border="0" cellpadding="0" cellspacing="0" align="center"
						width="560" style="border-collapse: collapse; border-spacing: 0; padding: 0; width: inherit;
						max-width: 560px;" class="wrapper">
						</tr>
						<!-- End of WRAPPER -->
						</table>
						<!-- End of SECTION / BACKGROUND -->
						</td>
						</tr>
						</table>
						</body>');

                $alert = array(
                    "title" => "Başarılı!",
                    "text" => "Mesajınız başarılı şekilde gönderildi!",
                    "type" => "success"
                );

                $this->session->set_flashdata("alert", $alert);
                redirect(base_url('mesajlar'));
                die();
            } else {
                $alert = array(
                    "title" => "Hata!",
                    "text" => "Mesaj gönderilemedi! Lütfen Tekrar Deneyin.",
                    "type" => "warning"
                );

                $this->session->set_flashdata("alert", $alert);
                redirect(base_url('mesajlar'));
                die();
            }
        }
    }

    public function cevap_mesaj_post($uniq)
    {
        $kullanici = kullanicicek();

        if (!$this->input->post('mesaj')) {
            $alert = array(
                "title" => "Uyarı!",
                "text" => "Lütfen Mesaj Alanını Boş Bırakmayın.",
                "type" => "warning"
            );

            $this->session->set_flashdata("alert", $alert);
            redirect(base_url('mesaj/' . $uniq));
            die();
        }

        $mesaj = $this->mesaj_model->amesajRow(array('uniq' => $uniq));

        if (!$mesaj) {
            redirect(base_url());
            die();
        }

        if ($kullanici->kullanici_id == $mesaj->gonderen_id) {
            $alan_id = $mesaj->alan_id;
        } else {
            $alan_id = $mesaj->gonderen_id;
        }

        $data = array(
            'amesaj_id' => $mesaj->id,
            'alan_id' => $alan_id,
            'gonderen_id' => $kullanici->kullanici_id,
            'mesaj' => $this->input->post('mesaj'),
            'okunma' => 1,
            'uniq' => uniqid()
        );

        $this->mesaj_model->mesaj_add($data);

        $kullanici_bilgi = kullanici_bilgi($alan_id);
        $siteayar = ayarlar();
        mailGonder($kullanici_bilgi->kullanici_mail, 'Bir Yeni Mesajınız Var! 🔔', '<style>
						/* Reset styles */ 
						body { margin: 0; padding: 0; min-width: 100%; width: 100% !important; height: 100% !important;}
						body, table, td, div, p, a { -webkit-font-smoothing: antialiased; text-size-adjust: 100%; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; line-height: 100%; }
						table, td { mso-table-lspace: 0pt; mso-table-rspace: 0pt; border-collapse: collapse !important; border-spacing: 0; }
						img { border: 0; line-height: 100%; outline: none; text-decoration: none; -ms-interpolation-mode: bicubic; }
         							#outlook a { padding: 0; }
						.ReadMsgBody { width: 100%; } .ExternalClass { width: 100%; }
						.ExternalClass, .ExternalClass p, .ExternalClass span, .ExternalClass font, .ExternalClass td, .ExternalClass div { line-height: 100%; }
						/* Rounded corners for advanced mail clients only */ 
						@media all and (min-width: 560px) {
							.container { border-radius: 8px; -webkit-border-radius: 8px; -moz-border-radius: 8px; -khtml-border-radius: 8px;}
						}
						/* Set color for auto links (addresses, dates, etc.) */ 
						a, a:hover {
							color: #127DB3;
						}
						.footer a, .footer a:hover {
							color: #999999;
						}
						</style>

						<body topmargin="0" rightmargin="0" bottommargin="0" leftmargin="0" marginwidth="0" marginheight="0" width="100%" style="border-collapse: collapse; border-spacing: 0; margin: 0; padding: 0; width: 100%; height: 100%; -webkit-font-smoothing: antialiased; text-size-adjust: 100%; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; line-height: 100%;
						background-color: #F0F0F0;
						color: #000000;"
						bgcolor="#F0F0F0"
						text="#000000">
						<!-- SECTION / BACKGROUND -->
						<!-- Set message background color one again -->
						<table width="100%" align="center" border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse; border-spacing: 0; margin: 0; padding: 0; width: 100%;" class="background">
						<tr>
						<td align="center" valign="top" style="border-collapse: collapse; border-spacing: 0; margin: 0; padding: 0;"
						bgcolor="#F0F0F0">
						<!-- WRAPPER -->
						<!-- Set wrapper width (twice) -->
						<table border="0" cellpadding="0" cellspacing="0" align="center"
						width="560" style="border-collapse: collapse; border-spacing: 0; padding: 0; width: inherit;
						max-width: 560px;" class="wrapper">
						<tr>
						<td align="center" valign="top" style="border-collapse: collapse; border-spacing: 0; margin: 0; padding: 0; padding-left: 6.25%; padding-right: 6.25%; width: 87.5%;
						padding-top: 20px;
						padding-bottom: 20px;">

						<a target="_blank" style="text-decoration: none;"
						href="' . base_url() . '"><img border="0" vspace="0" hspace="0"
						src="' . base_url($siteayar->site_logo) . '"
						width="100"
						alt="Logo" title="Yeni bir mesajınız var" style="
						color: #000000;
						font-size: 10px; margin: 0; padding: 0; outline: none; text-decoration: none; -ms-interpolation-mode: bicubic; border: none; display: block;" /></a>
						</td>
						</tr>
						<!-- End of WRAPPER -->
						</table>
						<!-- WRAPPER / CONTEINER -->
						<!-- Set conteiner background color -->
						<table border="0" cellpadding="0" cellspacing="0" align="center"
						bgcolor="#FFFFFF"
						width="560" style="border-collapse: collapse; border-spacing: 0; padding: 0; width: inherit;
						max-width: 560px;" class="container">
						<!-- HEADER -->
						<!-- Set text color and font family ("sans-serif" or "Georgia, serif") -->
						<tr>
						<td align="center" valign="top" style="border-collapse: collapse; border-spacing: 0; margin: 0; padding: 0; padding-left: 6.25%; padding-right: 6.25%; width: 87.5%; font-size: 24px; font-weight: bold; line-height: 130%;
						padding-top: 25px;
						color: #000000;
						font-family: sans-serif;" class="header">Yeni Mesajınız Var!</td>
						</tr>

						<tr>
						<td align="center" valign="top" style="border-collapse: collapse; border-spacing: 0; margin: 0; padding: 0; padding-left: 6.25%; padding-right: 6.25%; width: 87.5%; font-size: 17px; font-weight: 400; line-height: 160%;
						padding-top: 25px; 
						color: #000000;
						font-family: sans-serif;" class="paragraph">Bu Mesaj ' . base_url() . ' Gönderilmiştir.</td>
						</tr>

						<tr>
						<td align="center" valign="top" style="border-collapse: collapse; border-spacing: 0; margin: 0; padding: 0; padding-left: 6.25%; padding-right: 6.25%; width: 87.5%; font-size: 17px; font-weight: 400; line-height: 160%;
						padding-top: 25px; 
						color: #000000;
						font-family: sans-serif;" class="paragraph"> Yeni Mesajınız : <br> ' . $this->input->post('mesaj') . ' <br>
						</td>
						</tr>

						<tr>
						<td align="center" valign="top" style="border-collapse: collapse; border-spacing: 0; margin: 0; padding: 0; padding-left: 6.25%; padding-right: 6.25%; width: 87.5%;
						padding-top: 25px;
						padding-bottom: 5px;" class="button">
						<a
						href="#adres" target="_blank" style="text-decoration: underline;">
						<table border="0" cellpadding="0" cellspacing="0" align="center" style="max-width: 240px; min-width: 120px; border-collapse: collapse; border-spacing: 0; padding: 0;">
						</table></a>
						</td>
						</tr>
						<!-- LINE -->
						<!-- Set line color -->
						<tr>
						<td align="center" valign="top" style="border-collapse: collapse; border-spacing: 0; margin: 0; padding: 0; padding-left: 6.25%; padding-right: 6.25%; width: 87.5%;
						padding-top: 25px;" class="line">
						<hr
						color="#E0E0E0" align="center" width="100%" size="1" noshade style="margin: 0; padding: 0;" />
						</td>
						</tr>

						<tr>
						<td align="center" valign="top" style="border-collapse: collapse; border-spacing: 0; margin: 0; padding: 0; padding-left: 6.25%; padding-right: 6.25%; width: 87.5%;
						padding-top: 25px;" class="line">
						<hr
						color="#E0E0E0" align="center" width="100%" size="1" noshade style="margin: 0; padding: 0;" />
						</td>
						</tr>
						</table>
						<!-- WRAPPER -->
						<!-- Set wrapper width (twice) -->
						<table border="0" cellpadding="0" cellspacing="0" align="center"
						width="560" style="border-collapse: collapse; border-spacing: 0; padding: 0; width: inherit;
						max-width: 560px;" class="wrapper">
						</tr>
						<!-- End of WRAPPER -->
						</table>
						<!-- End of SECTION / BACKGROUND -->
						</td>
						</tr>
						</table>
						</body>');

        $alert = array(
            "title" => "Başarılı!",
            "text" => "Mesajınız başarılı şekilde gönderildi!",
            "type" => "success"
        );

        $this->session->set_flashdata("alert", $alert);
        redirect(base_url('mesaj/' . $uniq));
        die();
    }

    public function mesaj($uniq)
    {
        $mesaj = $this->mesaj_model->amesajRow(array('uniq' => $uniq));

        if (!$mesaj) {
            redirect(base_url());
            die();
        }

        $data = new stdClass();
        $kullanici = kullanicicek();
        $data->title = "Mesaj Oku";
        $data->description = "";
        $data->keywords = "";
        $data->ayarlar = ayarlar();
        $data->kullanici = $kullanici;
        $data->mesaj = $this->mesaj_model->amesaj(array('alan_id' => $kullanici->kullanici_id));
        $data->giden_mesaj = $this->mesaj_model->amesaj(array('gonderen_id' => $kullanici->kullanici_id));
        $data->amesaj = $mesaj;
        $data->mesajlar = $this->mesaj_model->mesaj(['amesaj_id' => $mesaj->id]);
        $data->magaza = $this->magaza_model->magaza(array('kullanici_id' => $kullanici->kullanici_id));
        mesajOku();

        $this->load->view('inc/_header', $data);
        $this->load->view('kpanel/mesaj/detay', $data);
        $this->load->view('inc/_footer', $data);
    }


    // Bakiye Yükleme
    public function bakiye_yukle()
    {
        if (!aktif_kullanici()) {
            redirect(base_url('giris-yap'));
            die();
        }

        $kullanici = kullanicicek();

        if (!$this->input->post('tutar') || $this->input->post('tutar') <= 0) {
            $alert = array(
                "title" => "Hata!",
                "text" => "Lütfen Bakiye Tutarını Doğru Girin!",
                "type" => "error"
            );
            $this->session->set_flashdata("alert", $alert);
            redirect(base_url('bakiye'));
            die();
        }

        /*if (!$kullanici->kullanici_adres) {
            $alert = array(
                "title" => "Hata!",
                "text" => "Adres Bilginizi Girmeniz Gerekmektedir!",
                "type" => "error"
            );
            $this->session->set_flashdata("alert", $alert);
            redirect(base_url('hesap-ayarlari'));
            die();
        }*/
        /*if (!$kullanici->kullanici_tel) {
            $alert = array(
                "title" => "Hata!",
                "text" => "Telefon Bilginizi Girmeniz Gerekmektedir!",
                "type" => "error"
            );
            $this->session->set_flashdata("alert", $alert);
            redirect(base_url('hesap-ayarlari'));
            die();
        }*/
        /*if (!$kullanici->kullanici_sehir || !$kullanici->kullanici_ilce) {
            $alert = array(
                "title" => "Hata!",
                "text" => "Şehir ve İlçe Bilginizi Girmeniz Gerekmektedir!",
                "type" => "error"
            );
            $this->session->set_flashdata("alert", $alert);
            redirect(base_url('hesap-ayarlari'));
            die();
        }*/


        $uretken = uretken(10);
        $data = array(
            'kullanici_id' => $kullanici->kullanici_id,
            'bakiye_tutar' => $this->input->post('tutar'),
            'bakiye_no' => $uretken,
            'bakiye_durum' => '0',
            'odeme_tur' => 'Vallet'
        );

        $insert = $this->bakiye_model->bakiye_add($data);

        redirect(base_url('bakiye-odeme/' . $this->input->post('odeme') . '/' . $uretken));
    }

    public function bakiye_odeme($bakiye_no)
    {
        if (!aktif_kullanici()) {
            redirect(base_url('giris-yap'));
            die();
        }

        $data = new stdClass();
        $kullanici = kullanicicek();
        $vericek = $this->bakiye_model->bakiye(array("bakiye.bakiye_no" => $bakiye_no, "bakiye.kullanici_id" => $kullanici->kullanici_id, 'bakiye.bakiye_durum' => '0'));

        if (!$vericek) {
            redirect(base_url());
        }

        $siteayar = ayarlar();


        $data->title = "Bakiye Ödeme Yap";
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;

        $data->siparis = $vericek;
        $data->google_key = $siteayar->google_key;
        $data->ayarlar = $siteayar;
        $data->kullanici = $kullanici;


        $this->load->view('inc/_header', $data);
        $this->load->view('kpanel/bakiye-odeme', $data);
        $this->load->view('inc/_footer', $data);
    }

    public function bakiye_odeme_onay_iyzico()
    {
        if (!aktif_kullanici()) {
            redirect(base_url('giris-yap'));
            die();
        }
        $options = $this->initialize_iyzico();
        $kullanici = kullanicicek();
        $request = new \Iyzipay\Request\RetrieveCheckoutFormRequest();
        $request->setLocale(\Iyzipay\Model\Locale::TR);
        $request->setConversationId("123456789");
        $request->setToken($_POST["token"]);
        $checkoutForm = \Iyzipay\Model\CheckoutForm::retrieve($request, $options);
        if ($checkoutForm->getStatus() == "success") {
            $siparis = $this->bakiye_model->bakiye(array('bakiye.bakiye_no' => $checkoutForm->getBasketId()));

            if ($siparis) {
                $this->bakiye_model->bakiye_update(array('bakiye_no' => $checkoutForm->getBasketId(), 'kullanici_id' => $kullanici->kullanici_id), array('bakiye_durum' => '1', 'odeme_tur' => 'İYZİCO'));

                $tutar = $checkoutForm->getPrice();
                $bakiye = $kullanici->bakiye;

                $this->destek_model->kullaniciupdate(
                    array("kullanici_id" => $kullanici->kullanici_id),
                    array(
                        "bakiye" => $bakiye + $tutar
                    )
                );

                $alert = array(
                    "title" => "Başarılı!",
                    "text" => "Ödemeniz Yapılmıştır..",
                    "type" => "success"
                );
                $this->session->set_flashdata("alert", $alert);
                redirect(base_url('bakiye'));
                die();
            }
        } else {
            $alert = array(
                "title" => "Hata!",
                "text" => "Ödeme alınamadı, bir hata oluştu.",
                "type" => "error"
            );
            $data['status'] = 'Ödeme alınamadı, bir hata oluştu.';
            $this->session->set_flashdata("alert", $alert);
            redirect(base_url('bakiye'));
            die();
        }
    }

    public function odemebildirimiolustur()
    {
        if (!$user = aktif_kullanici()) {
            echo json_encode(array('status' => false));
            die();
        }
        if (!$_POST) {
            echo json_encode(array('status' => false));
            die();
        }
        $info_user = kullanici_bilgi($user->kullanici_id);
        /*if ($info_user->tel_dogrulama == 0) {
            echo json_encode(array('status'=> false, 'message' => 'Lütfen İlk Önce Ayarlardan Telefon Numaranızı Doğrulayınız!!','tel_verify'=>1));
            die();
        }*/

        $ayarlar = ayarlar();

        $this->load->library("form_validation");

        $this->form_validation->set_rules("name", "Gönderen Ad Soyad", "required|trim|xss_clean");
        $this->form_validation->set_rules("date", "Ödeme Tarihi", "required|trim|xss_clean");
        $this->form_validation->set_rules("amount", "Miktar", "required|trim|xss_clean");
        $this->form_validation->set_rules("bank_id", "Banka Hesabı", "required|trim|xss_clean");

        $this->form_validation->set_message(
            array(
                "required" => "{field} Boş Bırakılamaz!",
                "xss_clean" => "XSS filter issue!"
            )
        );

        $validat = $this->form_validation->run();
        if ($validat) {
            if ($this->yonetim_model->talepget(['user_id' => aktif_kullanici()->kullanici_id, 'status' => 0])) {
                echo json_encode(array('status' => false, 'message' => 'Onay bekleyen talebiniz mevcut talebiniz incelendikten sonra tekrar talep oluşturabilirsiniz.'));
                die();
            }
            $data = [
                "name" => $this->input->post("name"),
                "date" => date('Y-m-d H:i:s', strtotime($this->input->post("date"))),
                "amount" => $this->input->post("amount"),
                "bank_id" => $this->input->post("bank_id"),
                "description" => $this->input->post("description"),
                "user_id" => aktif_kullanici()->kullanici_id
            ];
            if ($ayarlar->havale_sms == 1) {
                $adminler = $this->yonetim_model->getAll(array(
                    "kullanici_yetki" => 9
                ));
                $where = $this->yonetim_model->bankaget(
                    array(
                        "id" => $this->input->post("bank_id")
                    )
                );
                foreach ($adminler as $admin):
                    $this->smsSend($admin->kullanici_tel, $where->name . " - " . $this->input->post("amount") . "TL Bakiye yükleme talebi oluşturulmuştur. TR" . rand(1000, 9999));
                endforeach;
            }
            $insert = $this->home_model->odeme_bildirimi_olustur($data);
            echo json_encode(array('status' => $insert ? true : false));
        } else {
            echo json_encode(array('status' => false));
        }

    }

    public function kuponkullan()
    {
        if (!aktif_kullanici()) {
            echo json_encode(array('status' => false));
            die();
        }
        if (!$_POST) {
            echo json_encode(array('status' => false));
            die();
        }

        $ayarlar = ayarlar();

        $this->load->library("form_validation");

        $this->form_validation->set_rules("kod", "Kupon Kodu", "required|trim|xss_clean");

        $this->form_validation->set_message(
            array(
                "required" => "{field} Boş Bırakılamaz!",
                "xss_clean" => "XSS filter issue!"
            )
        );
        $validat = $this->form_validation->run();
        if ($validat) {
            $kupon = $this->kupon_model->get(['kod' => $this->input->post("kod"), 'durum' => 1]);

            if (!$kupon || ($kupon->stok == 0 || date('Y-m-d') > date('Y-m-d', strtotime($kupon->bitis_tarihi)))) {
                echo json_encode(array("status" => false, "message" => "Kupon kodu geçersiz"));
                die();
            }
            $kupon_kayit = $this->kupon_model->get_log(['kod' => $this->input->post("kod"), 'kullanici' => aktif_kullanici()->kullanici_id]);
            if ($kupon_kayit) {
                echo json_encode(array("status" => false, "message" => "Kupon kodunu zaten kullandınız."));
                die();
            }
            $kullanici = $this->yonetim_model->get(['kullanici_id' => aktif_kullanici()->kullanici_id]);
            $kullaniciData = [
                'bakiye' => $kullanici->bakiye + $kupon->tutar,
            ];
            $kuponData = [
                'stok' => $kupon->stok - 1
            ];
            $kuponLogData = [
                'ad' => $kupon->ad,
                'kod' => $kupon->kod,
                'tutar' => $kupon->tutar,
                'kullanici' => $kullanici->kullanici_id
            ];
            $this->yonetim_model->update(['kullanici_id' => $kullanici->kullanici_id], $kullaniciData);
            $this->kupon_model->update(['id' => $kupon->id], $kuponData);
            $this->kupon_model->insert_log($kuponLogData);
            echo json_encode(array('status' => true, 'message' => $kupon->tutar . 'TL Kupon Bakiyesi Hesabınıza Aktarıldı. Kupon Öncesi Bakiye : ' . $kullanici->bakiye . ' Kupon Sonrası Bakiye : ' . ($kullanici->bakiye + $kupon->tutar)));
        } else {
            echo json_encode(array('status' => false, 'message' => validation_errors()));
        }

    }

    public function smsSend($gsm, $mesaj)
    {
        $ayarlar = ayarlar();
        $username = $ayarlar->netgsm_user;
        $pass = $ayarlar->netgsm_pass;
        $header = $ayarlar->netgsm_header;

        $startdate = date('d.m.Y H:i');
        $startdate = str_replace('.', '', $startdate);
        $startdate = str_replace(':', '', $startdate);
        $startdate = str_replace(' ', '', $startdate);

        $stopdate = date('d.m.Y H:i', strtotime('+1 day'));
        $stopdate = str_replace('.', '', $stopdate);
        $stopdate = str_replace(':', '', $stopdate);
        $stopdate = str_replace(' ', '', $stopdate);


        $msg = html_entity_decode($mesaj, ENT_COMPAT, "UTF-8");
        //$msg = rawurlencode($msg);

        $gonderici = html_entity_decode($header, ENT_COMPAT, "UTF-8");
        $gonderici = rawurlencode($gonderici);

        $curl = curl_init();


        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.netgsm.com.tr/sms/send/get',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('usercode' => $username, 'password' => $pass, 'gsmno' => $gsm, 'message' => $msg, 'msgheader' => $gonderici, 'filter' => '0', 'startdate' => $startdate, 'stopdate' => $stopdate, 'dil' => 'TR'),
        ));

        $response = curl_exec($curl);
        curl_close($curl);
        return $response;
    }

    public function bakiye_odeme_onay_stripe()
    {
        $ayarlar = ayarlar();
        require_once('vendor/stripe-php-master/init.php');
        $stripe = new \Stripe\StripeClient($ayarlar->stripe_secret);
        try {

            $session = $stripe->checkout->sessions->retrieve($_GET['session_id']);

            if ($session->status == 'complete') {
                $siparis = $this->bakiye_model->bakiye(array('bakiye.bakiye_no' => $session->metadata->orderId));
                $kullanici_id = $siparis->kullanici_id;
                $kullanici = $this->yonetim_model->get(['kullanici_id' => $kullanici_id]);

                $this->bakiye_model->bakiye_update(array('bakiye_no' => $session->metadata->orderId, 'kullanici_id' => $kullanici_id), array('bakiye_durum' => '1', 'odeme_tur' => 'Stripe'));

                $tutar = $siparis->bakiye_tutar;
                $bakiye = $kullanici->bakiye;
                $this->destek_model->kullaniciupdate(
                    array("kullanici_id" => $kullanici_id),
                    array(
                        "bakiye" => $bakiye + $tutar
                    )
                );

                $alert = array(
                    "title" => "Başarılı!",
                    "text" => "Ödemeniz Yapılmıştır..",
                    "type" => "success"
                );
                $this->session->set_flashdata("alert", $alert);
                redirect(base_url('bakiye'));
                die();
            } else {
                $alert = array(
                    "title" => "Hata!",
                    "text" => "Ödeme alınamadı, bir hata oluştu.",
                    "type" => "error"
                );
                $data['status'] = 'Ödeme alınamadı, bir hata oluştu.';
                $this->session->set_flashdata("alert", $alert);
                redirect(base_url('bakiye'));
                die();
            }
        } catch (Error $e) {
            $alert = array(
                "title" => "Hata!",
                "text" => "Ödeme alınamadı, bir hata oluştu.",
                "type" => "error"
            );
            $this->session->set_flashdata("alert", $alert);
            redirect(base_url('bakiye'));
            die();
        }
    }

    public function bakiye_odeme_onay_paytr()
    {
        if (!aktif_kullanici()) {
            redirect(base_url('giris-yap'));
            die();
        }
        $siteayar = ayarlar();

        $kullanici = kullanicicek();

        $post = $_POST;
        var_dump($_POST);

        $hash = base64_encode(hash_hmac('sha256', $post['merchant_oid'] . $siteayar->paytr_secret . $post['status'] . $post['total_amount'], $siteayar->paytr_api, true));
        if ($hash != $post['hash'])
            die('PAYTR notification failed: bad hash');

        if ($post['status'] == 'success') { ## Ödeme Onaylandı
            $this->bakiye_model->bakiye_update(array('bakiye_no' => $post['merchant_oid'], 'kullanici_id' => $kullanici->kullanici_id), array('bakiye_durum' => '1', 'odeme_tur' => 'PAYTR'));

            $tutar = ($post['payment_amount'] * 100) / (100 + $siteayar->paytr_komisyon);
            $bakiye = $kullanici->bakiye;

            $this->destek_model->kullaniciupdate(
                array("kullanici_id" => $kullanici->kullanici_id),
                array(
                    "bakiye" => $bakiye + $tutar
                )
            );

            $alert = array(
                "title" => "Başarılı!",
                "text" => "Ödemeniz Yapılmıştır..",
                "type" => "success"
            );
            $this->session->set_flashdata("alert", $alert);
            redirect(base_url('bakiye'));
            die();
        } else { ## Ödemeye Onay Verilmedi


            $alert = array(
                "title" => "Hata!",
                "text" => $post['failed_reason_msg'],
                "type" => "error"
            );
            $data['status'] = 'Ödeme alınamadı, bir hata oluştu.';
            $this->session->set_flashdata("alert", $alert);
            redirect(base_url('bakiye'));
            die();
            ## BURADA YAPILMASI GEREKENLER
            ## 1) Siparişi iptal edin.
            ## 2) Eğer ödemenin onaylanmama sebebini kayıt edecekseniz aşağıdaki değerleri kullanabilirsiniz.
            ## $post['failed_reason_code'] - başarısız hata kodu
            ## $post['failed_reason_msg'] - başarısız hata mesajı

        }

        ## Bildirimin alındığını PayTR sistemine bildir.
        echo "OK";
    }

    public function bakiye_sil($bakiye_id)
    {
        $kullanici = kullanicicek();
        $this->bakiye_model->bakiye_update(array('bakiye.kullanici_id' => $kullanici->kullanici_id, 'bakiye.bakiye_id' => $bakiye_id), array('bakiye_durum' => '2'));

        $alert = array(
            "title" => "Başarılı!",
            "text" => "Ödemeniz İptal Edildi..",
            "type" => "success"
        );
        $this->session->set_flashdata("alert", $alert);
        redirect(base_url('bakiye'));
        die();
    }

    public function ilan_sorulari()
    {
        $data = new stdClass();
        $kullanici = kullanicicek();
        $data->title = "İlan Soruları";
        $data->description = "";
        $data->keywords = "";
        $data->ayarlar = ayarlar();
        $data->kullanici = $kullanici;
        $data->magaza = $this->magaza_model->magaza(array('kullanici_id' => $kullanici->kullanici_id));
        $data->sorular = $this->magaza_model->get_sorular($data->magaza->magaza_id);
        foreach ($data->sorular as $key => $val) {
            $data->sorular[$key]->soru_cevap = $this->magaza_model->get_soru_cevap($val->soru_id);
        }

        $this->load->view('inc/_header', $data);
        $this->load->view('kpanel/sorular/index', $data);
        $this->load->view('inc/_footer', $data);
    }

    public function sorularim()
    {
        $data = new stdClass();
        $kullanici = kullanicicek();
        $data->title = "Sorularım";
        $data->description = "";
        $data->keywords = "";
        $data->ayarlar = ayarlar();
        $data->kullanici = $kullanici;

        // Gold Alım - Satım

        $data->bekleyen_satislarim = $this->siparis_model->siteye_sattiklarim_getir(['user_id' => $kullanici->kullanici_id, 'status' => 0, 'type' => 1]);
        $data->tamamlanan_satislarim = $this->siparis_model->siteye_sattiklarim_getir(['user_id' => $kullanici->kullanici_id, 'status' => 1, 'type' => 1]);
        $data->iptal_edilen_satislarim = $this->siparis_model->siteye_sattiklarim_getir(['user_id' => $kullanici->kullanici_id, 'status' => 2, 'type' => 1]);

        $data->bekleyen_alislarim = $this->siparis_model->siteye_sattiklarim_getir(['user_id' => $kullanici->kullanici_id, 'status' => 0, 'type' => 2]);
        $data->tamamlanan_alislarim = $this->siparis_model->siteye_sattiklarim_getir(['user_id' => $kullanici->kullanici_id, 'status' => 1, 'type' => 2]);
        $data->iptal_edilen_alislarim = $this->siparis_model->siteye_sattiklarim_getir(['user_id' => $kullanici->kullanici_id, 'status' => 2, 'type' => 2]);

        // sorular

        $data->sorular = $this->magaza_model->get_my_sorular($kullanici->kullanici_id);
        foreach ($data->sorular as $key => $val) {
            $data->sorular[$key]->soru_cevap = $this->magaza_model->get_soru_cevap($val->soru_id);
        }

        // destek taleplerim

        $data->taleplerim = $this->magaza_model->get_destek_taleperim($kullanici->kullanici_id);

        //para çek


        $data->odenebilir_kazanclar = !empty(odenebilir_kazanclar($kullanici->kullanici_id)) ? odenebilir_kazanclar($kullanici->kullanici_id) : '0.00';
        // profil sayılar

        $data->sattigim_gold_count = count($data->tamamlanan_satislarim);
        $data->destek_talep_count = count($data->taleplerim);
        $data->aldigim_gold_count = count($data->tamamlanan_alislarim);

        $this->load->view('inc/_header', $data);
        $this->load->view('kpanel/yeni/sorularim', $data);
        $this->load->view('inc/_footer', $data);
    }

    public function product_review_post()
    {
        $data = new stdClass();

        $memnuniyet = $this->input->post('memnuniyet');
        $yorum = $this->input->post('yorum');
        $siparis_no = $this->input->post('urun-degerlendir-siparis-no');
        $urun_id = $this->input->post('urun-degerlendir-urun-id');
        $magaza_id = $this->input->post('urun-degerlendir-magaza-id');
        $zaman = date('Y-m-d H:i:s');
        $kullanici_id = kullanicicek()->kullanici_id;

        if (yorum_kontrol($kullanici_id, $siparis_no) != 0) {
            $data->success = false;
            $data->message = 'Bu Siparişe Daha Önce Değerlendirme Yaptınız!';
            print_r(json_encode($data));
            die();
        }

        $arr = [
            'kullanici_id' => $kullanici_id,
            'siparis_no' => $siparis_no,
            'magaza_id' => $magaza_id,
            'urun_id' => $urun_id,
            'yorum_detay' => $yorum,
            'yorum_puan' => $memnuniyet,
            'yorum_zaman' => $zaman
        ];

        if ($this->siparis_model->yorum_add($arr)) {
            $data->success = true;
            $data->message = 'Değerlendirmeniz İletilmiştir En Kısa Süre İçerisinde Yayınlanacaktır.';
            print_r(json_encode($data));
            die();
        } else {
            $data->success = false;
            $data->message = 'Değerlendirmeniz İletilemedi!';
            print_r(json_encode($data));
            die();
        }


    }
}