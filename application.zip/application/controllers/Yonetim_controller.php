<?php

defined('BASEPATH') or exit('No direct script access allowed');

class yonetim_controller extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        date_default_timezone_set('Europe/Istanbul');
    }

    public function yonetim()
    {

        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $data = new stdClass();

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;

        $data->bekleyensiparis = $this->db->where("siparis_durum", 0)->get("siparis")->num_rows();
        //$data->bekleyencekim = $this->db->where("ekim_durum", 0)->get("para_cek")->num_rows();

        $this->db->select('COUNT(paracek_id) as toplam');
        $this->db->where("paracek_durum='0'");
        $aylik_siparis_adet = $this->db->get('para_cek')->result();
        $paradata = [];
        foreach ($aylik_siparis_adet as $row) {
            $paradata[] += $row->toplam;
        }
        $data->bekleyencekim = $paradata[0];

        $data->bekleyentalep = $this->db->where("talep_durum", 0)->get("talep")->num_rows();

        $this->db->select('COUNT(yorum_id) as toplam');
        $this->db->where("yorum_durum='0'");
        $yorumadet = $this->db->get('yorum')->result();
        $yorumdata = [];
        foreach ($yorumadet as $row) {
            $yorumdata[] += $row->toplam;
        }
        $data->bekleyenyorum = $yorumdata[0];

        $data->toplamkategori = $this->db->get("kategori")->num_rows();
        $data->toplamurun = $this->db->where('admin', 1)->get("urunler")->num_rows();
        $data->toplamilan = $this->db->where('admin', 0)->get("urunler")->num_rows();
        $data->toplamkullanici = $this->db->where('kullanici_yetki', 1)->get("kullanici")->num_rows();
        $data->aktifkullanici = $this->db->where(['kullanici_yetki' => 1, 'tel_dogrulama' => 1])->get("kullanici")->num_rows();

        $data->siparisler = $this->db->join('urunler', 'urunler.urun_id = siparis.urun_id')->where(['siparis.siparis_durum' => 2])->get('siparis')->result();
        $data->toplamurunpara = 0;
        $data->toplamilanpara = 0;
        foreach ($data->siparisler as $siparis) {
            if ($siparis->admin == 1) {
                $data->toplamurunpara += $siparis->urun_fiyat;
            } else {
                $data->toplamilanpara += $siparis->urun_fiyat;
            }
        }

        $data->buhaftasiparis = $this->db->join('urunler', 'urunler.urun_id = siparis.urun_id')->where('siparis.siparis_tarih > DATE_SUB(NOW(), INTERVAL 7 DAY) and siparis.siparis_durum = 2')->get('siparis')->result();
        $data->buhaftaurunpara = 0;
        $data->buhaftailanpara = 0;
        foreach ($data->buhaftasiparis as $siparis) {
            if ($siparis->admin == 1) {
                $data->buhaftaurunpara += $siparis->urun_fiyat;
            } else {
                $data->buhaftailanpara += $siparis->urun_fiyat;
            }
        }

        $data->buaysiparis = $this->db->join('urunler', 'urunler.urun_id = siparis.urun_id')->where('siparis.siparis_tarih > DATE_SUB(NOW(), INTERVAL 30 DAY) and siparis.siparis_durum = 2')->get('siparis')->result();
        $data->buayurunpara = 0;
        $data->buayilanpara = 0;
        foreach ($data->buaysiparis as $siparis) {
            if ($siparis->admin == 1) {
                $data->buayurunpara += $siparis->urun_fiyat;
            } else {
                $data->buayilanpara += $siparis->urun_fiyat;
            }
        }


        // $this->db->join('comments', 'comments.id = blogs.id', 'left');

        $data->destekler = $this->yonetim_model->get_bekleyen_destekler();

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/index', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function giris()
    {
        $data = new stdClass();

        $siteayar = ayarlar();

        if (active_user()) {
            redirect(base_url(admin_url()));
        }

        $this->load->library("form_validation");

        $data->title = "Yönetim Paneli - " . $siteayar->site_baslik;
        $data->description = "Yönetim Paneli - " . $siteayar->site_aciklama;
        $data->keywords = "Yönetim Paneli - " . $siteayar->site_keyw;

        $this->load->view('yonetim/inc/_lheader', $data);
        $this->load->view('yonetim/giris/index', $data);
        $this->load->view('yonetim/inc/_lfooter');
    }

    public function do_giris()
    {

        if (active_user()) {
            redirect(base_url(admin_url()));
        }

        $this->load->library("form_validation");

        //Form ile post edilen name(ad) olan dolu boş kontrolü yap.

        $this->form_validation->set_rules("username", "Kullanıcı Adı", "required|trim");
        $this->form_validation->set_rules("password", "Şifre", "required|trim");

        $this->form_validation->set_message(
            array(
                "required" => "{field} Boş Bırakılamaz!",
            )
        );

        $validat = $this->form_validation->run();

        if ($validat) {


            $kullanici = $this->yonetim_model->get(array(
                "kullanici_ad" => $this->input->post("username"),
                "kullanici_yetki" => 9,
            ));

            if ($kullanici && password_verify($this->input->post("password"), $kullanici->kullanici_sifre)) {

                //Giriş Başarılı Alert
                $alert = array(
                    "title" => "Hoşgeldiniz,",
                    "text" => "Başarılı Şekilde Giriş Yaptınız",
                    "type" => "success"
                );
                $this->session->set_flashdata("alert", $alert);
                //Kullanıcı Bilgilerini Session Aktarma
                $this->session->set_userdata("kullanici", $kullanici);

                // - NOT : (set_flashdata) tek kullanımlık session. (set_userdata) öldürülene kadar kullanılan session.

                //Giriş Başarılı İse KUllanıcı Giriş Zamanını Güncelle

                $guncelle = $this->yonetim_model->update(
                    array(
                        "kullanici_ad" => $this->input->post("username"),
                    ),
                    array(
                        "kullanici_sonzaman" => date("Y-m-d H:i:s"),
                        "kullanici_ip" => $_SERVER['REMOTE_ADDR']
                    )
                );


                //Giriş Yapıldığında Yönlendir
                redirect(base_url(admin_url()));

                die();
            } else {

                //Giriş Yapılamadı Alert
                $alert = array(
                    "title" => "Bir Sorun Var!",
                    "text" => "Kullanıcı Adı veya Şifre Yanlış. Lütfen Tekrar Deneyin..",
                    "type" => "error"
                );

                $this->session->set_flashdata("alert", $alert);


                //Giriş Başarısız Yönlendirme
                redirect(base_url(admin_url() . "giris"));

                die();
            }
        } else {

            $data = new stdClass();

            $siteayar = ayarlar();

            if (active_user()) {
                redirect(base_url(admin_url()));
            }

            $data->form_error = true;
            $data->title = "Yönetim Paneli - " . $siteayar->site_baslik;
            $data->description = "Yönetim Paneli - " . $siteayar->site_aciklama;
            $data->keywords = "Yönetim Paneli - " . $siteayar->site_keyw;

            $this->load->view('yonetim/inc/_lheader', $data);
            $this->load->view('yonetim/giris/index', $data);
            $this->load->view('yonetim/inc/_lfooter');
        }
    }

    public function logout()
    {

        $this->session->unset_userdata("kullanici");
        redirect(base_url(admin_url() . 'giris'));
    }

    public function blog_kategori()
    {

        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $data = new stdClass();

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;


        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/blog-kategori/kategoriler', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function blogkategori_ekle()
    {

        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $data = new stdClass();

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;


        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/blog-kategori/kategori-ekle', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function blogkategori_go()
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }
        $this->load->library("form_validation");
        $this->form_validation->set_rules("ad", "Kategori Adı", "required|trim");
        $this->form_validation->set_message(
            array(
                "required" => "{field} Boş Bırakılamaz!",
            )
        );

        $validat = $this->form_validation->run();


        if ($validat) {

            //Seo Boş Bırakılırsa Otomatik Seo Oluştur
            if ($this->input->post("seo") == "") {
                $seourl = seo($this->input->post("ad"));
            } else {
                $seourl = $this->input->post("seo");
            }
            //---Seo Url Bitiş

            //---Bitiş---

            $data = array(
                "kategori_ad" => $this->input->post("ad"),
                "kategori_seo" => $seourl,
                "kategori_sira" => $this->input->post("sira"),
                "kategori_durum" => $this->input->post("durum"),
                "kategori_title" => $this->input->post("title"),
                "kategori_desc" => $this->input->post("desc"),
                "kategori_keyw" => $this->input->post("keyw"),

            );


            $insert = $this->yonetim_model->blogkategoriadd($data);


            $alert = array(
                "title" => "İşlem Başarılı",
                "text" => "Kategori Başarılı Şekilde Eklendi",
                "type" => "success"
            );

            $this->session->set_flashdata("alert", $alert);

            redirect(base_url(admin_url() . "blog-kategori-ekle"));

            die();
        } else {

            if (!active_user()) {
                redirect(base_url(admin_url() . 'giris'));
            }

            $data = new stdClass();

            $siteayar = ayarlar();

            $data->form_error = true;
            $data->title = $siteayar->site_baslik;
            $data->description = $siteayar->site_aciklama;
            $data->keywords = $siteayar->site_keyw;


            $this->load->view('yonetim/inc/_header', $data);
            $this->load->view('yonetim/blog-kategori/kategori-ekle', $data);
            $this->load->view('yonetim/inc/_footer');
        }
    }

    public function blogkategoriduzenle($katid)
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $data = new stdClass();

        // View'e Gönderilecek Değişkenlerin Set Edilmesi

        $where = $this->yonetim_model->blogkategoriget(
            array(
                "id" => $katid
            )
        );

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;
        $data->where = $where;


        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/blog-kategori/kategori-duzenle', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function blogkategori_duzenle($katid)
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $this->load->library("form_validation");
        $this->form_validation->set_rules("ad", "Kategori Adı", "required|trim");
        $this->form_validation->set_message(
            array(
                "required" => "{field} Boş Bırakılamaz!",
            )
        );

        $validat = $this->form_validation->run();


        if ($validat) {

            //Seo Boş Bırakılırsa Otomatik Seo Oluştur
            if ($this->input->post("seo") == "") {
                $seourl = seo($this->input->post("ad"));
            } else {
                $seourl = $this->input->post("seo");
            }
            //---Seo Url Bitiş


            $insert = $this->yonetim_model->blogkategoriupdate(
                array("id" => $katid),
                array(
                    "kategori_ad" => $this->input->post("ad"),
                    "kategori_seo" => $seourl,
                    "kategori_sira" => $this->input->post("sira"),
                    "kategori_durum" => $this->input->post("durum"),
                    "kategori_title" => $this->input->post("title"),
                    "kategori_desc" => $this->input->post("desc"),
                    "kategori_keyw" => $this->input->post("keyw"),

                )
            );


            $alert = array(
                "title" => "İşlem Başarılı",
                "text" => "Kategori Başarılı Şekilde Güncellendi",
                "type" => "success"
            );

            $this->session->set_flashdata("alert", $alert);

            redirect(base_url(admin_url() . "blog-kategori-duzenle/$katid"));

            die();
        } else {

            if (!active_user()) {
                redirect(base_url(admin_url() . 'giris'));
            }

            $data = new stdClass();

            $siteayar = ayarlar();

            $data->form_error = true;
            $data->title = $siteayar->site_baslik;
            $data->description = $siteayar->site_aciklama;
            $data->keywords = $siteayar->site_keyw;


            $this->load->view('yonetim/inc/_header', $data);
            $this->load->view('yonetim/kategori/kategori-duzenle/$katid', $data);
            $this->load->view('yonetim/inc/_footer');
        }
    }

    public function blog_durum($id)
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }
        if ($id) {
            $durumum = ($this->input->post("data") === "true") ? 1 : 0;
            print_r($durumum);
            $this->yonetim_model->blogkatupdate(array("id" => $id), array("kategori_durum" => $durumum));
        }
    }

    public function blogkatdelete($katid)
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $delete = $this->yonetim_model->blogkategoridelete(array("id" => $katid));

        if ($delete) {
            redirect(base_url(admin_url() . "blog-kategori"));
        } else {
            redirect(base_url(admin_url() . "blog-kategori"));
        }
    }


    public function kategoriekle()
    {

        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $data = new stdClass();

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;
        $data->users = $this->db->where(['kullanici_durum' => 1])->get('kullanici')->result();

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/kategori/kategori-ekle', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function onecikankategoriekle()
    {

        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $data = new stdClass();

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;


        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/one-cikan-kategori/kategori-ekle', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function one_cikan_kategori_go()
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $this->load->library("form_validation");

        $this->form_validation->set_rules("name", "Kategori Adı", "required|trim");

        $this->form_validation->set_message(
            array(
                "required" => "{field} Boş Bırakılamaz!",
            )
        );

        $validat = $this->form_validation->run();


        if ($validat) {

            if ($_FILES["file"]["name"]) {
                $file_name = seo(pathinfo($_FILES["file"]["name"], PATHINFO_FILENAME)) . "." . pathinfo($_FILES["file"]["name"], PATHINFO_EXTENSION);
                $sifrele = uniqid();
                $config["allowed_types"] = "jpg|jpeg|png";
                $config["upload_path"] = "uploads/one-cikan-kategori/";
                $config["file_name"] = $sifrele . "_" . $file_name;

                $this->load->library("upload", $config);

                $upload = $this->upload->do_upload("file");

                if ($upload) {


                    //---Bitiş---

                    $uploaded_file = $this->upload->data("file_name");

                    $data = array(
                        "name" => $this->input->post("name"),
                        "order_no" => $this->input->post("order_no"),
                        "icon" => "uploads/one-cikan-kategori/" . $uploaded_file,

                    );


                    $insert = $this->yonetim_model->onecikankategoriadd($data);


                    $alert = array(
                        "title" => "İşlem Başarılı",
                        "text" => "Kategori Başarılı Şekilde Eklendi",
                        "type" => "success"
                    );

                    $this->session->set_flashdata("alert", $alert);

                    redirect(base_url(admin_url() . "one-cikan-kategori-ekle"));

                    die();
                } else {

                    $alert = array(
                        "title" => "İşlem Başarısız",
                        "text" => "Lütfen Kategori Fotoğrafı Ekleyin!",
                        "type" => "error"
                    );

                    $this->session->set_flashdata("alert", $alert);

                    redirect(base_url(admin_url() . "one-cikan-kategori-ekle"));

                    die();
                }
            } else {

                $data = array(
                    "name" => $this->input->post("name"),
                    "order_no" => $this->input->post("order_no"),

                );


                $insert = $this->yonetim_model->onecikankategoriadd($data);


                $alert = array(
                    "title" => "İşlem Başarılı",
                    "text" => "Kategori Başarılı Şekilde Eklendi",
                    "type" => "success"
                );

                $this->session->set_flashdata("alert", $alert);

                redirect(base_url(admin_url() . "one-cikan-kategori-ekle"));

                die();
            }
        } else {

            if (!active_user()) {
                redirect(base_url(admin_url() . 'giris'));
            }

            $data = new stdClass();

            $siteayar = ayarlar();

            $data->form_error = true;
            $data->title = $siteayar->site_baslik;
            $data->description = $siteayar->site_aciklama;
            $data->keywords = $siteayar->site_keyw;


            $this->load->view('yonetim/inc/_header', $data);
            $this->load->view('yonetim/one-cikan-kategori/kategori-ekle', $data);
            $this->load->view('yonetim/inc/_footer');
        }
    }

    public function kategori_go()
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $this->load->library("form_validation");

        $this->form_validation->set_rules("ad", "Kategori Adı", "required|trim");

        $this->form_validation->set_message(
            array(
                "required" => "{field} Boş Bırakılamaz!",
            )
        );

        $validat = $this->form_validation->run();


        $data = json_decode($this->input->post("keyw"), true);

        $header_keyword = implode(",", array_column($data, 'value'));

        if ($validat) {

            if ($_FILES["file"]["name"]) {
                $file_name = seo(pathinfo($_FILES["file"]["name"], PATHINFO_FILENAME)) . "." . pathinfo($_FILES["file"]["name"], PATHINFO_EXTENSION);
                $sifrele = uniqid();
                $config["allowed_types"] = "jpg|jpeg|png";
                $config["upload_path"] = "uploads/kategori/";
                $config["file_name"] = $sifrele . "_" . $file_name;

                $this->load->library("upload", $config);

                $upload = $this->upload->do_upload("file");

                if ($upload) {

                    //Seo Boş Bırakılırsa Otomatik Seo Oluştur
                    if ($this->input->post("seo") == "") {
                        $seourl = seo($this->input->post("ad"));
                    } else {
                        $seourl = $this->input->post("seo");
                    }
                    //---Seo Url Bitiş

                    //---Bitiş---

                    $uploaded_file = $this->upload->data("file_name");

                    $data = array(
                        "kategori_ad" => $this->input->post("ad"),
                        "kategori_seo" => $seourl,
                        "kategori_sira" => $this->input->post("sira"),
                        "kategori_durum" => $this->input->post("durum"),
                        "kategori_populer" => $this->input->post("populer"),
                        "parent" => $this->input->post("parent"),
                        "kategori_resim" => "uploads/kategori/" . $uploaded_file,
                        "kategori_logo_resim" => (!empty($this->session->userdata('images')) ? $this->session->userdata('images')[0] : ''),
                        "kategori_title" => $this->input->post("title"),
                        "kategori_desc" => $this->input->post("desc"),
                        "kategori_keyw" => $header_keyword,
                        "komisyon" => $this->input->post("komisyon"),
                        "kategori_tur" => $this->input->post("kategori_tur"),
                    );


                    $insert = $this->yonetim_model->kategoriadd($data);

                    $this->session->unset_userdata('images');

                    $alert = array(
                        "title" => "İşlem Başarılı",
                        "text" => "Kategori Başarılı Şekilde Eklendi",
                        "type" => "success"
                    );

                    $this->session->set_flashdata("alert", $alert);

                    redirect(base_url(admin_url() . "kategori-ekle"));

                    die();
                } else {

                    $alert = array(
                        "title" => "İşlem Başarısız",
                        "text" => "Lütfen Kategori Fotoğrafı Ekleyin!",
                        "type" => "error"
                    );

                    $this->session->set_flashdata("alert", $alert);

                    redirect(base_url(admin_url() . "kategori-ekle"));

                    die();
                }
            } else {

                //Seo Boş Bırakılırsa Otomatik Seo Oluştur
                if ($this->input->post("seo") == "") {
                    $seourl = seo($this->input->post("ad"));
                } else {
                    $seourl = $this->input->post("seo");
                }

                $data = array(
                    "kategori_ad" => $this->input->post("ad"),
                    "kategori_seo" => $seourl,
                    "kategori_sira" => $this->input->post("sira"),
                    "kategori_durum" => $this->input->post("durum"),
                    "kategori_populer" => $this->input->post("populer"),
                    "parent" => $this->input->post("parent"),
                    "kategori_title" => $this->input->post("title"),
                    "kategori_desc" => $this->input->post("desc"),
                    "kategori_keyw" => $this->input->post("keyw"),
                    "kategori_tur" => $this->input->post("kategori_tur")
                );


                $insert = $this->yonetim_model->kategoriadd($data);


                $alert = array(
                    "title" => "İşlem Başarılı",
                    "text" => "Kategori Başarılı Şekilde Eklendi",
                    "type" => "success"
                );

                $this->session->set_flashdata("alert", $alert);

                redirect(base_url(admin_url() . "kategori-ekle"));

                die();
            }
        } else {

            if (!active_user()) {
                redirect(base_url(admin_url() . 'giris'));
            }

            $data = new stdClass();

            $siteayar = ayarlar();

            $data->form_error = true;
            $data->title = $siteayar->site_baslik;
            $data->description = $siteayar->site_aciklama;
            $data->keywords = $siteayar->site_keyw;


            $this->load->view('yonetim/inc/_header', $data);
            $this->load->view('yonetim/kategori/kategori-ekle', $data);
            $this->load->view('yonetim/inc/_footer');
        }
    }

    public function filtre_go()
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $this->load->library("form_validation");

        $this->form_validation->set_rules("ad", "Filtre Adı", "required|trim");

        $this->form_validation->set_message(
            array(
                "required" => "{field} Boş Bırakılamaz!",
            )
        );

        $validat = $this->form_validation->run();


        if ($validat) {

            if ($_FILES["file"]["name"]) {
                $file_name = seo(pathinfo($_FILES["file"]["name"], PATHINFO_FILENAME)) . "." . pathinfo($_FILES["file"]["name"], PATHINFO_EXTENSION);
                $sifrele = uniqid();
                $config["allowed_types"] = "jpg|jpeg|png";
                $config["upload_path"] = "uploads/img/";
                $config["file_name"] = $sifrele . "_" . $file_name;

                $this->load->library("upload", $config);

                $upload = $this->upload->do_upload("file");

                if ($upload) {

                    $uploaded_file = $this->upload->data("file_name");

                    $data = array(
                        "filtre_adi" => $this->input->post("ad"),
                        "sira" => $this->input->post("sira"),
                        "filtre_resim" => "uploads/img/" . $uploaded_file,
                        "kategori_id" => $this->input->post("kategori"),
                        "slug" => seo($this->input->post("ad"))
                    );


                    $insert = $this->yonetim_model->filtreadd($data);


                    $alert = array(
                        "title" => "İşlem Başarılı",
                        "text" => "Filtre Başarılı Şekilde Eklendi",
                        "type" => "success"
                    );

                    $this->session->set_flashdata("alert", $alert);

                    redirect(base_url(admin_url() . "kategori-filtre-ekle/" . $this->input->post('kategori')));

                    die();
                } else {

                    $alert = array(
                        "title" => "İşlem Başarısız",
                        "text" => "Lütfen Filtre Fotoğrafı Ekleyin!",
                        "type" => "error"
                    );

                    $this->session->set_flashdata("alert", $alert);

                    redirect(base_url(admin_url() . "kategori-filtre-ekle/" . $this->input->post('kategori')));

                    die();
                }
            } else {
                /*$alert = array(
                    "title" => "İşlem Başarısız",
                    "text" => "Lütfen Filtre Fotoğrafı Ekleyin!",
                    "type" => "error"
                );

                $this->session->set_flashdata("alert", $alert);

                redirect(base_url(admin_url() . "kategori-filtre-ekle/".$this->input->post('kategori')));

                die();*/
                $data = array(
                    "filtre_adi" => $this->input->post("ad"),
                    "sira" => $this->input->post("sira"),
                    "kategori_id" => $this->input->post("kategori"),
                    "slug" => seo($this->input->post("ad"))
                );

                $insert = $this->yonetim_model->filtreadd($data);

                $alert = array(
                    "title" => "İşlem Başarılı",
                    "text" => "Filtre Başarılı Şekilde Eklendi",
                    "type" => "success"
                );

                $this->session->set_flashdata("alert", $alert);

                redirect(base_url(admin_url() . "kategori-filtre-ekle/" . $this->input->post('kategori')));

                die();
            }
        } else {

            if (!active_user()) {
                redirect(base_url(admin_url() . 'giris'));
            }

            $data = new stdClass();

            $siteayar = ayarlar();

            $data->form_error = true;
            $data->title = $siteayar->site_baslik;
            $data->description = $siteayar->site_aciklama;
            $data->keywords = $siteayar->site_keyw;

            $this->load->view('yonetim/inc/_header', $data);
            $this->load->view('yonetim/kategori/filtre-ekle', $data);
            $this->load->view('yonetim/inc/_footer');
        }
    }

    public function sub_filtre_go()
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $this->load->library("form_validation");

        $this->form_validation->set_rules("ad", "Filtre Adı", "required|trim");

        $this->form_validation->set_message(
            array(
                "required" => "{field} Boş Bırakılamaz!",
            )
        );

        $validat = $this->form_validation->run();


        if ($validat) {
            if ($this->input->post('type') == 0) {
                $alert = array(
                    "title" => "İşlem Başarısız",
                    "text" => "Lütfen Filtre Tipini Seçiniz!",
                    "type" => "error"
                );

                $this->session->set_flashdata("alert", $alert);

                redirect(base_url(admin_url() . "kategori-alt-filtre/" . $this->input->post('kategori') . '/' . $this->input->post('filtre')));

                die();
            }
            $data = array(
                "filtre_adi" => $this->input->post("ad"),
                "sira" => $this->input->post("sira"),
                "kategori_id" => $this->input->post("kategori"),
                'sub_filter' => $this->input->post('filtre'),
                'type' => $this->input->post('type'),
                "slug" => seo($this->input->post("ad"))
            );

            $insert = $this->yonetim_model->filtreadd($data);

            $alert = array(
                "title" => "İşlem Başarılı",
                "text" => "Alt Filtre Başarılı Şekilde Eklendi",
                "type" => "success"
            );

            $this->session->set_flashdata("alert", $alert);

            redirect(base_url(admin_url() . "kategori-alt-filtre/" . $this->input->post('kategori') . '/' . $this->input->post('filtre')));

            die();
        } else {

            if (!active_user()) {
                redirect(base_url(admin_url() . 'giris'));
            }

            $data = new stdClass();

            $siteayar = ayarlar();

            $data->form_error = true;
            $data->title = $siteayar->site_baslik;
            $data->description = $siteayar->site_aciklama;
            $data->keywords = $siteayar->site_keyw;

            $this->load->view('yonetim/inc/_header', $data);
            $this->load->view('yonetim/kategori/alt-filtre-ekle', $data);
            $this->load->view('yonetim/inc/_footer');
        }
    }

    public function filtre_ozellik_go()
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $this->load->library("form_validation");

        $this->form_validation->set_rules("ad", "Özellik Adı", "required|trim");

        $this->form_validation->set_message(
            array(
                "required" => "{field} Boş Bırakılamaz!",
            )
        );

        $validat = $this->form_validation->run();


        if ($validat) {
            $data = array(
                "name" => $this->input->post("ad"),
                "sira" => $this->input->post("sira"),
                'filtre_id' => $this->input->post('filtre'),
                "slug" => seo($this->input->post("ad"))
            );

            $insert = $this->yonetim_model->ozellikadd($data);

            $alert = array(
                "title" => "İşlem Başarılı",
                "text" => "Özellik Başarılı Şekilde Eklendi",
                "type" => "success"
            );

            $this->session->set_flashdata("alert", $alert);

            redirect(base_url(admin_url() . "ozellik-ekle/" . $this->input->post('kategori') . '/' . $this->input->post('filtre')));

            die();
        } else {

            if (!active_user()) {
                redirect(base_url(admin_url() . 'giris'));
            }

            $data = new stdClass();

            $siteayar = ayarlar();

            $data->form_error = true;
            $data->title = $siteayar->site_baslik;
            $data->description = $siteayar->site_aciklama;
            $data->keywords = $siteayar->site_keyw;

            $this->load->view('yonetim/inc/_header', $data);
            $this->load->view('yonetim/kategori/ozellik-ekle', $data);
            $this->load->view('yonetim/inc/_footer');
        }
    }


    public function kategoriler()
    {

        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $data = new stdClass();

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;


        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/kategori/kategoriler', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function alt_kategoriler()
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $data = new stdClass();

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;

        $type = $_GET['type'];

        $data->kategoriler = $this->yonetim_model->get_sub_categories($type);


        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/kategori/alt-kategoriler', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function alt_kategori_filtreler($id)
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }
        if (empty($id)) {
            redirect(base_url(admin_url()));
        }
        $data = new stdClass();

        if (!$data->alt_kategori = $this->yonetim_model->control_alt_kategori($id)) {
            redirect(base_url(admin_url()));
        }

        $data->filtreler = $this->yonetim_model->kategori_filtreler_getir($id);

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/kategori/filtreler', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function alt_kategori_alt_filtreler($id, $filtre)
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }
        if (empty($id)) {
            redirect(base_url(admin_url()));
        }
        $data = new stdClass();

        if (!$data->alt_kategori = $this->yonetim_model->control_alt_kategori($id)) {
            redirect(base_url(admin_url()));
        }
        if (!$data->filtre = $this->yonetim_model->control_filtre($filtre)) {
            redirect(base_url(admin_url()));
        }

        $data->filtreler = $this->yonetim_model->kategori_alt_filtreler_getir($filtre);

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/kategori/alt-filtreler', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function filtre_ozellikler($id, $filtre)
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }
        if (empty($id)) {
            redirect(base_url(admin_url()));
        }
        $data = new stdClass();

        if (!$data->alt_kategori = $this->yonetim_model->control_alt_kategori($id)) {
            redirect(base_url(admin_url()));
        }
        if (!$data->filtre = $this->yonetim_model->control_filtre($filtre)) {
            redirect(base_url(admin_url()));
        }

        $data->ozellikler = $this->yonetim_model->filtre_ozellikler_getir($filtre);

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/kategori/filtre-ozellikler', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function alt_kategori_filtre_ekle($id)
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }
        if (empty($id)) {
            redirect(base_url(admin_url()));
        }
        $data = new stdClass();

        if (!$data->alt_kategori = $this->yonetim_model->control_alt_kategori($id)) {
            redirect(base_url(admin_url()));
        }

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/kategori/filtre-ekle', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function filtre_ozellik_ekle($id, $filtre)
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }
        if (empty($id)) {
            redirect(base_url(admin_url()));
        }
        $data = new stdClass();

        if (!$data->alt_kategori = $this->yonetim_model->control_alt_kategori($id)) {
            redirect(base_url(admin_url()));
        }
        if (!$data->filtre = $this->yonetim_model->control_filtre($filtre)) {
            redirect(base_url(admin_url()));
        }

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/kategori/ozellik-ekle', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function alt_kategori_alt_filtre_ekle($id, $filtre)
    {

        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }
        if (empty($id)) {
            redirect(base_url(admin_url()));
        }
        $data = new stdClass();

        if (!$data->alt_kategori = $this->yonetim_model->control_alt_kategori($id)) {
            redirect(base_url(admin_url()));
        }
        if (!$data->filtre = $this->yonetim_model->control_filtre($filtre)) {
            redirect(base_url(admin_url()));
        }

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/kategori/alt-filtre-ekle', $data);
        $this->load->view('yonetim/inc/_footer');
    }


    public function one_cikan_kategoriler()
    {

        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $data = new stdClass();

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;


        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/one-cikan-kategori/kategoriler', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function durum($id)
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }
        if ($id) {

            $durumum = ($this->input->post("data") === "true") ? 1 : 0;

            $this->yonetim_model->katupdate(array("kategori_id" => $id), array("kategori_durum" => $durumum));
        }
    }

    public function filtre_durum($id)
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }
        if ($id) {

            $durumum = ($this->input->post("data") === "true") ? 1 : 0;

            $this->yonetim_model->filtrepdate(array("filtre_id" => $id), array("filtre_durum" => $durumum));
        }
    }

    public function ozellik_durum($id)
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }
        if ($id) {

            $durumum = ($this->input->post("data") === "true") ? 1 : 0;

            $this->yonetim_model->ozellikupdate(array("ozellik_id" => $id), array("durum" => $durumum));
        }
    }

    public function kategoriduzenle($katid)
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $data = new stdClass();

        // View'e Gönderilecek Değişkenlerin Set Edilmesi

        $where = $this->yonetim_model->kategoriget(
            array(
                "kategori_id" => $katid
            )
        );

        $data->users = $this->db->where(['kullanici_durum' => 1])->get('kullanici')->result();

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;
        $data->where = $where;


        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/kategori/kategori-duzenle', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function kategorifiltreduzenle($katid)
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $data = new stdClass();

        // View'e Gönderilecek Değişkenlerin Set Edilmesi

        $where = $this->yonetim_model->filtreget(
            array(
                "filtre_id" => $katid
            )
        );

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;
        $data->where = $where;


        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/kategori/kategori-filtre-duzenle', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function kategori_duzenle($katid)
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $this->load->library("form_validation");

        $this->form_validation->set_rules("ad", "Kategori Adı", "required|trim");

        $this->form_validation->set_message(
            array(
                "required" => "{field} Boş Bırakılamaz!",
            )
        );

        $validat = $this->form_validation->run();


        $data = json_decode($this->input->post("keyw"), true);

        $header_keyword = implode(",", array_column($data, 'value'));
        if ($validat) {

            if ($_FILES["file"]["name"]) {
                $file_name = seo(pathinfo($_FILES["file"]["name"], PATHINFO_FILENAME)) . "." . pathinfo($_FILES["file"]["name"], PATHINFO_EXTENSION);
                $sifrele = uniqid();
                $config["allowed_types"] = "jpg|jpeg|png";
                $config["upload_path"] = "uploads/kategori/";
                $config["file_name"] = $sifrele . "_" . $file_name;

                $this->load->library("upload", $config);

                $upload = $this->upload->do_upload("file");

                if ($upload) {

                    //Seo Boş Bırakılırsa Otomatik Seo Oluştur
                    if ($this->input->post("seo") == "") {
                        $seourl = seo($this->input->post("ad"));
                    } else {
                        $seourl = $this->input->post("seo");
                    }
                    //---Seo Url Bitiş

                    $uploaded_file = $this->upload->data("file_name");


                    if (!empty($this->session->userdata('images'))) {
                        $insert = $this->yonetim_model->kategoriupdate(
                            array("kategori_id" => $katid),
                            array(
                                "kategori_ad" => $this->input->post("ad"),
                                "kategori_seo" => $seourl,
                                "kategori_sira" => $this->input->post("sira"),
                                "kategori_durum" => $this->input->post("durum"),
                                "kategori_populer" => $this->input->post("populer"),
                                "kategori_tur" => $this->input->post("kategori_tur"),
                                "parent" => $this->input->post("parent"),
                                "kategori_resim" => "uploads/kategori/" . $uploaded_file,
                                "kategori_logo_resim" => $this->session->userdata('images')[0],
                                "kategori_title" => $this->input->post("title"),
                                "kategori_desc" => $this->input->post("desc"),
                                "kategori_keyw" => $header_keyword,
                                "komisyon" => $this->input->post("komisyon"),
                                "aciklama" => $this->input->post("aciklama"),
                                "nasil_kullanilir" => $this->input->post("nasil_kullanilir"),
                                "ust_baslik" => $this->input->post("ust_baslik"),
                                "ust_baslik_altyazi" => $this->input->post("ust_baslik_altyazi")
                            )
                        );
                    } else {
                        $insert = $this->yonetim_model->kategoriupdate(
                            array("kategori_id" => $katid),
                            array(
                                "kategori_ad" => $this->input->post("ad"),
                                "kategori_seo" => $seourl,
                                "kategori_sira" => $this->input->post("sira"),
                                "kategori_durum" => $this->input->post("durum"),
                                "kategori_populer" => $this->input->post("populer"),
                                "kategori_tur" => $this->input->post("kategori_tur"),
                                "parent" => $this->input->post("parent"),
                                "kategori_resim" => "uploads/kategori/" . $uploaded_file,
                                "kategori_title" => $this->input->post("title"),
                                "kategori_desc" => $this->input->post("desc"),
                                "kategori_keyw" => $header_keyword,
                                "komisyon" => $this->input->post("komisyon"),
                                "aciklama" => $this->input->post("aciklama"),
                                "nasil_kullanilir" => $this->input->post("nasil_kullanilir"),
                                "ust_baslik" => $this->input->post("ust_baslik"),
                                "ust_baslik_altyazi" => $this->input->post("ust_baslik_altyazi")
                            )
                        );
                    }

                    $this->session->unset_userdata('images');

                    $alert = array(
                        "title" => "İşlem Başarılı",
                        "text" => "Kategori Başarılı Şekilde Güncellendi",
                        "type" => "success"
                    );

                    $this->session->set_flashdata("alert", $alert);

                    redirect(base_url(admin_url() . "kategori-duzenle/$katid"));

                    die();
                } else {

                    $alert = array(
                        "title" => "İşlem Başarısız",
                        "text" => "Fotoğraf Yüklenemedi!",
                        "type" => "error"
                    );

                    $this->session->set_flashdata("alert", $alert);

                    redirect(base_url(admin_url() . "kategori-duzenle/$katid"));

                    die();
                }
            } else {

                //Seo Boş Bırakılırsa Otomatik Seo Oluştur
                if ($this->input->post("seo") == "") {
                    $seourl = seo($this->input->post("ad"));
                } else {
                    $seourl = $this->input->post("seo");
                }
                //---Seo Url Bitiş

                if (!empty($this->session->userdata('images'))) {
                    $insert = $this->yonetim_model->kategoriupdate(
                        array("kategori_id" => $katid),
                        array(
                            "kategori_ad" => $this->input->post("ad"),
                            "kategori_seo" => $seourl,
                            "kategori_sira" => $this->input->post("sira"),
                            "kategori_durum" => $this->input->post("durum"),
                            "kategori_populer" => $this->input->post("populer"),
                            "kategori_tur" => $this->input->post("kategori_tur"),
                            "parent" => $this->input->post("parent"),
                            "kategori_logo_resim" => $this->session->userdata('images')[0],
                            "kategori_title" => $this->input->post("title"),
                            "kategori_desc" => $this->input->post("desc"),
                            "kategori_keyw" => $header_keyword,
                            "komisyon" => $this->input->post("komisyon"),
                            "aciklama" => $this->input->post("aciklama"),
                            "nasil_kullanilir" => $this->input->post("nasil_kullanilir"),
                            "ust_baslik" => $this->input->post("ust_baslik"),
                            "ust_baslik_altyazi" => $this->input->post("ust_baslik_altyazi")
                        )
                    );
                } else {
                    $insert = $this->yonetim_model->kategoriupdate(
                        array("kategori_id" => $katid),
                        array(
                            "kategori_ad" => $this->input->post("ad"),
                            "kategori_seo" => $seourl,
                            "kategori_sira" => $this->input->post("sira"),
                            "kategori_durum" => $this->input->post("durum"),
                            "kategori_populer" => $this->input->post("populer"),
                            "kategori_tur" => $this->input->post("kategori_tur"),
                            "parent" => $this->input->post("parent"),
                            "kategori_title" => $this->input->post("title"),
                            "kategori_desc" => $this->input->post("desc"),
                            "kategori_keyw" => $header_keyword,
                            "komisyon" => $this->input->post("komisyon"),
                            "aciklama" => $this->input->post("aciklama"),
                            "nasil_kullanilir" => $this->input->post("nasil_kullanilir"),
                            "ust_baslik" => $this->input->post("ust_baslik"),
                            "ust_baslik_altyazi" => $this->input->post("ust_baslik_altyazi")
                        )
                    );
                }


                $this->session->unset_userdata('images');

                $alert = array(
                    "title" => "İşlem Başarılı",
                    "text" => "Kategori Başarılı Şekilde Güncellendi",
                    "type" => "success"
                );

                $this->session->set_flashdata("alert", $alert);

                redirect(base_url(admin_url() . "kategori-duzenle/$katid"));

                die();
            }
        } else {

            if (!active_user()) {
                redirect(base_url(admin_url() . 'giris'));
            }

            $data = new stdClass();

            $siteayar = ayarlar();

            $data->form_error = true;
            $data->title = $siteayar->site_baslik;
            $data->description = $siteayar->site_aciklama;
            $data->keywords = $siteayar->site_keyw;


            $this->load->view('yonetim/inc/_header', $data);
            $this->load->view('yonetim/kategori/kategori-duzenle/$katid', $data);
            $this->load->view('yonetim/inc/_footer');
        }
    }

    public function kategori_filtre_duzenle($katid)
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $this->load->library("form_validation");

        $this->form_validation->set_rules("ad", "Filtre Adı", "required|trim");

        $this->form_validation->set_message(
            array(
                "required" => "{field} Boş Bırakılamaz!",
            )
        );

        $validat = $this->form_validation->run();


        if ($validat) {

            if ($_FILES["file"]["name"]) {
                $file_name = seo(pathinfo($_FILES["file"]["name"], PATHINFO_FILENAME)) . "." . pathinfo($_FILES["file"]["name"], PATHINFO_EXTENSION);
                $sifrele = uniqid();
                $config["allowed_types"] = "jpg|jpeg|png";
                $config["upload_path"] = "uploads/img/";
                $config["file_name"] = $sifrele . "_" . $file_name;

                $this->load->library("upload", $config);

                $upload = $this->upload->do_upload("file");

                if ($upload) {

                    $uploaded_file = $this->upload->data("file_name");
                    $insert = $this->yonetim_model->kategorifiltreupdate(
                        array("filtre_id" => $katid),
                        array(
                            "filtre_adi" => $this->input->post("ad"),
                            "sira" => $this->input->post("sira"),
                            "filtre_durum" => $this->input->post("durum"),
                            "filtre_resim" => "uploads/img/" . $uploaded_file,
                            "slug" => seo($this->input->post('ad'))
                        )
                    );


                    $alert = array(
                        "title" => "İşlem Başarılı",
                        "text" => "Fİltre Başarılı Şekilde Güncellendi",
                        "type" => "success"
                    );

                    $this->session->set_flashdata("alert", $alert);

                    redirect(base_url(admin_url() . "kategori-filtre-duzenle/$katid"));

                    die();
                } else {

                    $alert = array(
                        "title" => "İşlem Başarısız",
                        "text" => "Fotoğraf Yüklenemedi!",
                        "type" => "error"
                    );

                    $this->session->set_flashdata("alert", $alert);

                    redirect(base_url(admin_url() . "kategori-filtre-duzenle/$katid"));

                    die();
                }
            } else {

                $insert = $this->yonetim_model->kategorifiltreupdate(
                    array("filtre_id" => $katid),
                    array(
                        "filtre_adi" => $this->input->post("ad"),
                        "sira" => $this->input->post("sira"),
                        "filtre_durum" => $this->input->post("durum"),
                        "slug" => seo($this->input->post('ad'))
                    )
                );


                $alert = array(
                    "title" => "İşlem Başarılı",
                    "text" => "Filtre Başarılı Şekilde Güncellendi",
                    "type" => "success"
                );

                $this->session->set_flashdata("alert", $alert);

                redirect(base_url(admin_url() . "kategori-filtre-duzenle/$katid"));

                die();
            }
        } else {

            if (!active_user()) {
                redirect(base_url(admin_url() . 'giris'));
            }

            $data = new stdClass();

            $siteayar = ayarlar();

            $data->form_error = true;
            $data->title = $siteayar->site_baslik;
            $data->description = $siteayar->site_aciklama;
            $data->keywords = $siteayar->site_keyw;

            $this->load->view('yonetim/inc/_header', $data);
            $this->load->view('yonetim/kategori/kategori-filtre-duzenle/$katid', $data);
            $this->load->view('yonetim/inc/_footer');
        }
    }

    public function kategori_random($katid)
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }


        if ($_FILES["file"]["name"]) {
            $file_name = seo(pathinfo($_FILES["file"]["name"], PATHINFO_FILENAME)) . "." . pathinfo($_FILES["file"]["name"], PATHINFO_EXTENSION);
            $sifrele = uniqid();
            $config["allowed_types"] = "jpg|jpeg|png";
            $config["upload_path"] = "uploads/kategori/rand/";
            $config["file_name"] = $sifrele . "_" . $file_name;

            $this->load->library("upload", $config);

            $upload = $this->upload->do_upload("file");

            if ($upload) {

                $uploaded_file = $this->upload->data("file_name");
                $this->yonetim_model->kategoriupdate(
                    array("kategori_id" => $katid),
                    array(
                        "kategori_resim_rand" => "uploads/kategori/rand/" . $uploaded_file,

                    )
                );

                $alert = array(
                    "title" => "İşlem Başarılı",
                    "text" => "Kategori Başarılı Şekilde Güncellendi",
                    "type" => "success"
                );
                $this->session->set_flashdata("alert", $alert);
                redirect(base_url(admin_url() . "kategoriler"));
                die();
            } else {

                $alert = array(
                    "title" => "İşlem Başarısız",
                    "text" => "Fotoğraf Yüklenemedi!",
                    "type" => "error"
                );

                $this->session->set_flashdata("alert", $alert);

                redirect(base_url(admin_url() . "kategoriler"));

                die();
            }
        }
    }

    public function kategori_banner($katid)
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }


        if ($_FILES["file"]["name"]) {
            $file_name = seo(pathinfo($_FILES["file"]["name"], PATHINFO_FILENAME)) . "." . pathinfo($_FILES["file"]["name"], PATHINFO_EXTENSION);
            $sifrele = uniqid();
            $config["allowed_types"] = "jpg|jpeg|png";
            $config["upload_path"] = "uploads/kategori/banner/";
            $config["file_name"] = $sifrele . "_" . $file_name;

            $this->load->library("upload", $config);

            $upload = $this->upload->do_upload("file");

            if ($upload) {

                $uploaded_file = $this->upload->data("file_name");
                $this->yonetim_model->kategoriupdate(
                    array("kategori_id" => $katid),
                    array(
                        "kategori_resim_banner" => "uploads/kategori/banner/" . $uploaded_file,

                    )
                );

                $alert = array(
                    "title" => "İşlem Başarılı",
                    "text" => "Kategori Başarılı Şekilde Güncellendi",
                    "type" => "success"
                );
                $this->session->set_flashdata("alert", $alert);
                redirect(base_url(admin_url() . "kategoriler"));
                die();
            } else {

                $alert = array(
                    "title" => "İşlem Başarısız",
                    "text" => "Fotoğraf Yüklenemedi!",
                    "type" => "error",
                );

                $this->session->set_flashdata("alert", $alert);

                redirect(base_url(admin_url() . "kategoriler"));

                die();
            }
        }
    }

    public function katdelete($katid)
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $delete = $this->yonetim_model->kategoridelete(array("kategori_id" => $katid));

        if ($delete) {
            redirect(base_url(admin_url() . "kategoriler"));
        } else {
            redirect(base_url(admin_url() . "kategoriler"));
        }
    }

    public function kategorifiltresil($filid)
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $delete = $this->yonetim_model->filtredelete(array("filtre_id" => $filid));

        if ($delete) {
            redirect(base_url(admin_url() . "kategori-filtre/" . $filid));
        } else {
            redirect(base_url(admin_url() . "kategori-filtre/" . $filid));
        }
    }

    public function filtreozelliksil($kat, $fil, $ozel)
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $delete = $this->yonetim_model->ozellikdelete(array("ozellik_id" => $ozel));

        if ($delete) {
            redirect(base_url(admin_url() . "filtre-ozellikler/" . $kat . '/' . $fil));
        } else {
            redirect(base_url(admin_url() . "filtre-ozellikler/" . $kat . '/' . $fil));
        }
    }

    public function alt_kategori()
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        if ($this->input->post('kategori_id')) {
            echo $this->yonetim_model->alt_kategori($this->input->post('kategori_id'));
        } else {
            redirect(base_url());
        }
    }

    public function siteayarlari()
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $data = new stdClass();

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/ayarlar/site-ayarlari', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function genel_ayarlar()
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $data = new stdClass();

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/ayarlar/genel-ayarlar', $data);
        $this->load->view('yonetim/inc/_footer');
    }
    public function komisyon_ayarlari()
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $data = new stdClass();

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/ayarlar/komisyon-ayarlar', $data);
        $this->load->view('yonetim/inc/_footer');
    }
    public function odeme_ayarlar()
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $data = new stdClass();

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/ayarlar/odeme-ayarlar', $data);
        $this->load->view('yonetim/inc/_footer');
    }
    public function yonetim_url()
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $data = new stdClass();

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/ayarlar/yonetim-url', $data);
        $this->load->view('yonetim/inc/_footer');
    }
    public function logo_favicon_ayarlar()
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $data = new stdClass();

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/ayarlar/logo-favicon-ayarlar', $data);
        $this->load->view('yonetim/inc/_footer');
    }
    public function google_api_ayarlar()
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $data = new stdClass();

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/ayarlar/google-api-ayarlar', $data);
        $this->load->view('yonetim/inc/_footer');
    }
    public function footer_ayarlar()
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $data = new stdClass();

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/ayarlar/footer-ayarlar', $data);
        $this->load->view('yonetim/inc/_footer');
    }
    public function subheader_ayarlar()
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $data = new stdClass();

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/ayarlar/subheader-ayarlar', $data);
        $this->load->view('yonetim/inc/_footer');
    }
    public function altkisim_ayarlar()
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $data = new stdClass();

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/ayarlar/alt-kisim-ayarlar', $data);
        $this->load->view('yonetim/inc/_footer');
    }
    public function smtp_ayarlar()
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $data = new stdClass();

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/ayarlar/smtp-ayarlar', $data);
        $this->load->view('yonetim/inc/_footer');
    }
    public function netgsm_ayarlar()
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $data = new stdClass();

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/ayarlar/netgsm-ayarlar', $data);
        $this->load->view('yonetim/inc/_footer');
    }
    public function giris_reklam_ayarlar()
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $data = new stdClass();

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/ayarlar/giris-reklam-ayarlar', $data);
        $this->load->view('yonetim/inc/_footer');
    }
    public function canli_destek_ayarlar()
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $data = new stdClass();

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/ayarlar/canli-destek-ayarlar', $data);
        $this->load->view('yonetim/inc/_footer');
    }
    public function sozlesme_ayarlar()
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $data = new stdClass();

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/ayarlar/sozlesme-ayarlar', $data);
        $this->load->view('yonetim/inc/_footer');
    }
    public function turkpin_ayarlar()
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $data = new stdClass();

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/ayarlar/turkpin-ayarlar', $data);
        $this->load->view('yonetim/inc/_footer');
    }
    public function giris_kayit_yazi_ayarlar()
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $data = new stdClass();

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/ayarlar/giris-kayit-yazi-ayarlar', $data);
        $this->load->view('yonetim/inc/_footer');
    }


    public function headerayar()
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }
        $data = new stdClass();
        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;

        $ci = &get_instance();
        $headers = $ci->db->order_by('sort ASC')->get('headers')->result();

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/ayarlar/header', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function dropdown()
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }
        $data = new stdClass();
        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;

        $ci = &get_instance();
        $dropdowns = $ci->db->order_by('sort ASC')->get('dropdowns')->result();

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/ayarlar/dropdown', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function createdropdown()
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $file_name = seo(time() . "-" . pathinfo($_FILES["file"]["name"], PATHINFO_FILENAME)) . "." . pathinfo($_FILES["file"]["name"], PATHINFO_EXTENSION);
        $config["allowed_types"] = "png";
        $config["upload_path"] = "uploads/img/";
        $config["file_name"] = $file_name;

        $this->load->library("upload", $config);

        $upload = $this->upload->do_upload("file");
        if ($upload) {
            $uploaded_file = $this->upload->data("file_name");

            $data = array(
                "img" => $uploaded_file,
                "mainid" => $this->input->post('hdr'),
                "heading" => $this->input->post('heading'),
                "link" => $this->input->post('link'),
                "sort" => $this->input->post('sort')
            );

            $insert = $this->yonetim_model->dropdownadd($data);


            $alert = array(
                "title" => "İşlem Başarılı",
                "text" => "Dropdown oluşturuldu.",
                "type" => "success"
            );

            $this->session->set_flashdata("alert", $alert);
            redirect(base_url(admin_url() . "dropdown"));
            die();

        } else {
            $data = array(
                "img" => "uploads/img/",
                "mainid" => $this->input->post('hdr'),
                "heading" => $this->input->post('heading'),
                "link" => $this->input->post('link'),
                "sort" => $this->input->post('sort')
            );

            $insert = $this->yonetim_model->dropdownadd($data);


            $alert = array(
                "title" => "İşlem Başarılı",
                "text" => "Dropdown oluşturuldu.",
                "type" => "success"
            );

            $this->session->set_flashdata("alert", $alert);
            redirect(base_url(admin_url() . "dropdown"));
            die();
        }
    }

    public function createheader()
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }
        if ($_POST) {
            $heading = $_POST["heading"];
            $icon = $_POST["icon"];
            $sort = $_POST["sort"];
            $drp = $_POST["drp"];
            $link = $_POST["link"];
            $pop = $_POST["gold"];

            if (empty($heading) || empty($sort) || empty($link)) {
                $alert = array(
                    "title" => "Hata!",
                    "text" => "Lütfen boş alan bırakmayın.",
                    "type" => "error"
                );

                $this->session->set_flashdata("alert", $alert);
                redirect(base_url(admin_url() . "header"));
                die();
            }
            if ($_FILES["file"]["name"]) {
                $file_name = seo(pathinfo($_FILES["file"]["name"], PATHINFO_FILENAME)) . "." . pathinfo($_FILES["file"]["name"], PATHINFO_EXTENSION);
                $sifrele = uniqid();
                $config["allowed_types"] = "jpg|jpeg|png";
                $config["upload_path"] = "uploads/img/";
                $config['encrypt_name'] = TRUE;
                //$config["file_name"] = $sifrele . "_" . $file_name;

                $this->load->library("upload", $config);
                $upload = $this->upload->do_upload("file");
                if ($upload) {
                    $uploaded_file = $this->upload->data("file_name");
                    $data = array(
                        "heading" => $heading,
                        "link" => $link,
                        "icon" => "",
                        "dropdown" => $drp,
                        "sort" => $sort,
                        "pop" => $pop,
                        "pngicon" => "uploads/img/" . $uploaded_file
                    );
                    $insert = $this->yonetim_model->headeradd($data);
                    $alert = array(
                        "title" => "Başarılı!",
                        "text" => "Header eklendi.",
                        "type" => "success"
                    );
                    $this->session->set_flashdata("alert", $alert);
                }
            } else {
                $data = array(
                    "heading" => $heading,
                    "link" => $link,
                    "icon" => $icon,
                    "dropdown" => $drp,
                    "sort" => $sort,
                    "pop" => $pop
                );
                $insert = $this->yonetim_model->headeradd($data);
                $alert = array(
                    "title" => "Başarılı!",
                    "text" => "Header eklendi.",
                    "type" => "success"
                );
                $this->session->set_flashdata("alert", $alert);
            }

            redirect(base_url(admin_url() . "header"));
            die();
        } else {
            echo "No Inputs";
            die();
        }
    }

    public function updateheader()
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }
        if ($_POST) {
            $heading = $_POST["heading"];
            $icon = $_POST["icon"];
            $sort = $_POST["sort"];
            $drp = $_POST["drp"];
            $link = $_POST["link"];
            $id = $_POST["id"];
            $pop = $_POST["gold"];

            if (empty($heading) || empty($sort) || empty($link)) {
                $alert = array(
                    "title" => "Hata!",
                    "text" => "Lütfen boş alan bırakmayın.",
                    "type" => "error"
                );

                $this->session->set_flashdata("alert", $alert);
                redirect(base_url(admin_url() . "header"));
                die();
            }
            if ($_FILES["file"]["name"]) {
                $file_name = seo(pathinfo($_FILES["file"]["name"], PATHINFO_FILENAME)) . "." . pathinfo($_FILES["file"]["name"], PATHINFO_EXTENSION);
                $sifrele = uniqid();
                $config["allowed_types"] = "jpg|jpeg|png";
                $config["upload_path"] = "uploads/img/";
                $config['encrypt_name'] = TRUE;
                //$config["file_name"] = $sifrele . "_" . $file_name;

                $this->load->library("upload", $config);
                $upload = $this->upload->do_upload("file");
                if ($upload) {
                    $uploaded_file = $this->upload->data("file_name");
                    $data = array(
                        "heading" => $heading,
                        "link" => $link,
                        "icon" => "",
                        "dropdown" => $drp,
                        "sort" => $sort,
                        "pop" => $pop,
                        "pngicon" => "uploads/img/" . $uploaded_file
                    );
                    $insert = $this->yonetim_model->headerupdate(array("id" => $id), $data);
                    $alert = array(
                        "title" => "Başarılı!",
                        "text" => "Header düzenlendi.",
                        "type" => "success"
                    );
                    $this->session->set_flashdata("alert", $alert);
                }
            } else {
                $data = array(
                    "heading" => $heading,
                    "link" => $link,
                    "icon" => $icon,
                    "dropdown" => $drp,
                    "sort" => $sort,
                    "pop" => $pop
                );
                $insert = $this->yonetim_model->headerupdate(array("id" => $id), $data);
                $alert = array(
                    "title" => "Başarılı!",
                    "text" => "Header düzenlendi.",
                    "type" => "success"
                );
                $this->session->set_flashdata("alert", $alert);
            }
            redirect(base_url(admin_url() . "header"));
            die();
        } else {
            echo "No Inputs";
            die();
        }
    }

    public function getheader()
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }
        if ($_POST) {
            if (!is_array($hd)) {
                $hd = array();
            }
            $ci = &get_instance();
            $headers = $ci->db->select('*')->from('headers')->where(array('id' => $_POST["id"]))->get()->result();
            die(json_encode($headers));
        } else {
            echo "No Inputs";
        }
    }

    public function getdropdown()
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }
        if ($_POST) {
            $ci = &get_instance();
            $headers = $ci->db->select('*')->from('dropdowns')->where(array('id' => $_POST["id"]))->get()->result();
            die(json_encode($headers));
        } else {
            echo "No Inputs";
        }
    }

    public function removeheader()
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }
        $delete = $this->yonetim_model->headerdelete(array("id" => $_POST["id"]));

        if ($delete) {
            redirect(base_url(admin_url() . "header"));
        } else {
            redirect(base_url(admin_url() . "header"));
        }
    }

    public function updatedropdown()
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        /**$oldfile = $this->input->post('oldimg');
         *
         * $update_filename = seo(pathinfo($_FILES["file"]["name"], PATHINFO_FILENAME)) . "." . pathinfo($_FILES["file"]["name"], PATHINFO_EXTENSION);
         * $config["allowed_types"] = "png";
         * $config["upload_path"] = "uploads/img/";
         * $config["file_name"] = $update_filename;
         * $this->load->library("upload", $config);
         *
         * $uwu = $this->upload->do_upload("file");
         * if($uwu){
         * $update_filename = $this->upload->data("file_name");
         * } else {
         * $update_filename = $oldfile;
         * }
         *
         * $data = array(
         * "img" => $update_filename,
         * "mainid" => $this->input->post('hdredit'),
         * "heading"  => $this->input->post('headingedit'),
         * "link" => $this->input->post('linkedit'),
         * "sort" => $this->input->post('sortedit')
         * );
         *
         * $insert = $this->yonetim_model->dropdownupdate(array("id", $this->input->post('id')), $data);
         *
         *
         * $alert = array(
         * "title" => "İşlem Başarılı",
         * "text" => "Dropdown düzenlendi!",
         * "type" => "success"
         * );
         *
         * $this->session->set_flashdata("alert", $alert);
         * redirect(base_url(admin_url() . "dropdown"));
         * die();**/

        $file_name = seo(pathinfo($_FILES["file"]["name"], PATHINFO_FILENAME)) . "." . pathinfo($_FILES["file"]["name"], PATHINFO_EXTENSION);
        $sifrele = uniqid();
        $config["allowed_types"] = "png";
        $config["upload_path"] = "uploads/img/";
        $config["file_name"] = $sifrele . "_" . $file_name;

        $this->load->library("upload", $config);

        $upload = $this->upload->do_upload("file");

        if ($upload) {

            $uploaded_file = $this->upload->data("file_name");

            $data = array(
                "mainid" => $this->input->post('hdredit'),
                "heading" => $this->input->post('headingedit'),
                "link" => $this->input->post('linkedit'),
                "sort" => $this->input->post('sortedit'),
                "img" => $uploaded_file
            );
            $insert = $this->yonetim_model->dropdownupdate(array("id", $this->input->post('id')), $data);

            $alert = array(
                "title" => "İşlem Başarılı",
                "text" => "Dropdown düzenlendi!",
                "type" => "success"
            );

            $this->session->set_flashdata("alert", $alert);

            redirect(base_url(admin_url() . "dropdown"));

            die();
        } else {

            $uploaded_file = $this->upload->data("file_name");

            $data = array(
                "mainid" => $this->input->post('hdredit'),
                "heading" => $this->input->post('headingedit'),
                "link" => $this->input->post('linkedit'),
                "sort" => $this->input->post('sortedit')
            );
            $insert = $this->yonetim_model->dropdownupdate(array("id", $this->input->post('id')), $data);

            $alert = array(
                "title" => "İşlem Başarılı",
                "text" => "Dropdown düzenlendi!",
                "type" => "success"
            );

            $this->session->set_flashdata("alert", $alert);

            redirect(base_url(admin_url() . "dropdown"));

            die();
        }

    }

    public function site_foto()
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $file_name = seo(pathinfo($_FILES["file"]["name"], PATHINFO_FILENAME)) . "." . pathinfo($_FILES["file"]["name"], PATHINFO_EXTENSION);
        $sifrele = uniqid();
        $config["allowed_types"] = "png";
        $config["upload_path"] = "uploads/img/";
        $config["file_name"] = $sifrele . "_" . $file_name;

        $this->load->library("upload", $config);

        $upload = $this->upload->do_upload("file");
        $ayarlar = ayarlar();


        $data = json_decode($this->input->post("keyword"), true);

        $header_keyword = implode(",", array_column($data, 'value'));

        if ($upload) {

            $uploaded_file = $this->upload->data("file_name");

            $data = array(
                "site_foto" => "uploads/img/" . $uploaded_file,
                /*"kategori_json" => json_encode($this->input->post('sayfa_kategori')),*/
                "header_baslik" => $this->input->post('header_baslik'),
                "site_keyw" => $header_keyword,
                "havale_sms" => $this->input->post('havale_sms'),
                "header_aciklama" => $this->input->post('header_aciklama'),
                "footer_aciklama" => $this->input->post('footer_aciklama'),
                "para_cekme_limit" => $this->input->post('para_cekme_limit'),
                "anasayfa_urun_reklam" => $this->input->post('anasayfa_urun_reklam'),
                "kategori_urun_reklam" => $this->input->post('kategori_urun_reklam'),
                /*"slider1" => $this->input->post('slider1'),
                "slider2" => $this->input->post('slider2'),
                "slider3" => $this->input->post('slider3'),
                "slider4" => $this->input->post('slider4'),
                "renk_durum" => $this->input->post('renk_durum'),
                "renk_varsayilan" => $this->input->post('renk_varsayilan'),*/
                "mesaj_detay_kayan_yazi" => $this->input->post('mesaj_detay_kayan_yazi')
            );

            $insert = $this->yonetim_model->ayarupdate(array("ayar_id" => 1), $data);


            $alert = array(
                "title" => "İşlem Başarılı",
                "text" => "Genel Ayarlar Başarılı Şekilde Güncellendi.",
                "type" => "success"
            );

            $this->session->set_flashdata("alert", $alert);
            redirect($_SERVER['HTTP_REFERER']);
            die();
        } else {
            $data = array(
                /*"kategori_json" => json_encode($this->input->post('sayfa_kategori')),*/
                "header_baslik" => $this->input->post('header_baslik'),
                "site_keyw" => $header_keyword,
                "havale_sms" => $this->input->post('havale_sms'),
                "header_aciklama" => $this->input->post('header_aciklama'),
                "footer_aciklama" => $this->input->post('footer_aciklama'),
                "para_cekme_limit" => $this->input->post('para_cekme_limit'),
                "anasayfa_urun_reklam" => $this->input->post('anasayfa_urun_reklam'),
                "kategori_urun_reklam" => $this->input->post('kategori_urun_reklam'),
                /*"slider1" => $this->input->post('slider1'),
                "slider2" => $this->input->post('slider2'),
                "slider3" => $this->input->post('slider3'),
                "slider4" => $this->input->post('slider4'),
                "renk_durum" => $this->input->post('renk_durum'),
                "renk_varsayilan" => $this->input->post('renk_varsayilan'),*/
                "mesaj_detay_kayan_yazi" => $this->input->post('mesaj_detay_kayan_yazi')
            );

            $insert = $this->yonetim_model->ayarupdate(array("ayar_id" => 1), $data);


            $alert = array(
                "title" => "İşlem Başarılı",
                "text" => "Genel Ayarlar Başarılı Şekilde Güncellendi.",
                "type" => "success"
            );

            $this->session->set_flashdata("alert", $alert);
            redirect($_SERVER['HTTP_REFERER']);
            die();
        }
    }

    public function odeme_yontemleri()
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $ayarlar = ayarlar();

        $data = array(
            "iyzico_api" => $this->input->post('iyzico_api'),
            "iyzico_secret" => $this->input->post('iyzico_secret'),
            "iyzico_durum" => $this->input->post('iyzico_durum'),
            "iyzico_komisyon" => $this->input->post('iyzico_komisyon'),
            "paytr_merchant_id" => $this->input->post('paytr_merchant_id'),
            "paytr_api" => $this->input->post('paytr_api'),
            "paytr_secret" => $this->input->post('paytr_secret'),
            "paytr_durum" => $this->input->post('paytr_durum'),
            "paytr_komisyon" => $this->input->post('paytr_komisyon'),
            "weepay_bayiId" => $this->input->post('weepay_bayiId'),
            "weepay_api" => $this->input->post('weepay_api'),
            "weepay_secret" => $this->input->post('weepay_secret'),
            "weepay_durum" => $this->input->post('weepay_durum'),
            "weepay_komisyon" => $this->input->post('weepay_komisyon'),
            "stripe_api" => $this->input->post('stripe_api'),
            "stripe_secret" => $this->input->post('stripe_secret'),
            "stripe_durum" => $this->input->post('stripe_durum'),
            "stripe_komisyon" => $this->input->post('stripe_komisyon'),
            "vallet_username" => $this->input->post('vallet_username'),
            "vallet_password" => $this->input->post('vallet_password'),
            "vallet_shopCode" => $this->input->post('vallet_shopCode'),
            "vallet_hash" => $this->input->post('vallet_hash'),
            "vallet_durum" => $this->input->post('vallet_durum'),
            "vallet_komisyon" => $this->input->post('vallet_komisyon'),
        );

        $insert = $this->yonetim_model->ayarupdate(array("ayar_id" => 1), $data);

        $alert = array(
            "title" => "İşlem Başarılı",
            "text" => "Ödeme Yöntemleri Başarılı Şekilde Güncellendi.",
            "type" => "success"
        );

        $this->session->set_flashdata("alert", $alert);
        redirect($_SERVER['HTTP_REFERER']);
        die();

    }

    public function komisyon_ayarlar()
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $ayarlar = ayarlar();

        $data = array(
            "komisyon" => $this->input->post('komisyon'),
            "havale_komisyon" => $this->input->post('havale_komisyon'),
        );

        $insert = $this->yonetim_model->ayarupdate(array("ayar_id" => 1), $data);

        $alert = array(
            "title" => "İşlem Başarılı",
            "text" => "Komisyon Ayarları Başarılı Şekilde Güncellendi.",
            "type" => "success"
        );

        $this->session->set_flashdata("alert", $alert);
        redirect($_SERVER['HTTP_REFERER']);
        die();

    }

    public function giris_kayit_yazi()
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $ayarlar = ayarlar();

        $data = array(
            "giris_yazi" => $this->input->post('giris_yazi'),
            "sifremi_unuttum_yazi" => $this->input->post('sifremi_unuttum_yazi')
        );

        $insert = $this->yonetim_model->ayarupdate(array("ayar_id" => 1), $data);

        $alert = array(
            "title" => "İşlem Başarılı",
            "text" => "Komisyon Ayarları Başarılı Şekilde Güncellendi.",
            "type" => "success"
        );

        $this->session->set_flashdata("alert", $alert);
        redirect($_SERVER['HTTP_REFERER']);
        die();

    }

    public function sozlesmeler()
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $ayarlar = ayarlar();

        $data = array(
            "hizmet_kosulu" => $this->input->post('hizmet_kosulu'),
            "gizlilik_politikasi" => $this->input->post('gizlilik_politikasi'),
            "hizmet_sozlesmesi" => $this->input->post('hizmet_sozlesmesi'),
        );

        $insert = $this->yonetim_model->ayarupdate(array("ayar_id" => 1), $data);

        $alert = array(
            "title" => "İşlem Başarılı",
            "text" => "Sözleşmeler Başarılı Şekilde Güncellendi.",
            "type" => "success"
        );

        $this->session->set_flashdata("alert", $alert);
        redirect($_SERVER['HTTP_REFERER']);
        die();

    }

    public function turkpin()
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $ayarlar = ayarlar();

        $data = array(
            "turkpin_username" => $this->input->post('turkpin_username'),
            "turkpin_password" => !empty($this->input->post('turkpin_password')) ? $this->input->post('turkpin_password') : $ayarlar->turkpin_password,
        );

        $insert = $this->yonetim_model->ayarupdate(array("ayar_id" => 1), $data);

        $alert = array(
            "title" => "İşlem Başarılı",
            "text" => "Türkpin Bilgileri Başarılı Şekilde Güncellendi.",
            "type" => "success"
        );

        $this->session->set_flashdata("alert", $alert);
        redirect($_SERVER['HTTP_REFERER']);
        die();

    }

    public function canlidestek()
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $ayarlar = ayarlar();

        $data = array(
            "canli_destek_jivo" => $this->input->post('canli_destek_jivo'),
            "canli_destek_tawk" => $this->input->post('canli_destek_tawk'),
        );

        $insert = $this->yonetim_model->ayarupdate(array("ayar_id" => 1), $data);

        $alert = array(
            "title" => "İşlem Başarılı",
            "text" => "Canlı Destek Kodları Başarılı Şekilde Güncellendi.",
            "type" => "success"
        );

        $this->session->set_flashdata("alert", $alert);
        redirect($_SERVER['HTTP_REFERER']);
        die();

    }

    public function ustlogo()
    {

        $file_name = seo(pathinfo($_FILES["file"]["name"], PATHINFO_FILENAME)) . "." . pathinfo($_FILES["file"]["name"], PATHINFO_EXTENSION);
        $sifrele = uniqid();
        $config["allowed_types"] = "png";
        $config["upload_path"] = "uploads/logo/";
        $config["file_name"] = $sifrele . "_" . $file_name;

        $this->load->library("upload", $config);

        $upload = $this->upload->do_upload("file");

        if ($upload) {

            $uploaded_file = $this->upload->data("file_name");

            $data = array(
                "site_logo" => "uploads/logo/" . $uploaded_file
            );
            $insert = $this->yonetim_model->ayarupdate(array("ayar_id" => 1), $data);

            $alert = array(
                "title" => "Logo Değiştirildi!",
                "text" => "Başarılı Şekilde Yüklendi",
                "type" => "success"
            );

            $this->session->set_flashdata("alert", $alert);

            redirect($_SERVER['HTTP_REFERER']);

            die();
        } else {

            $alert = array(
                "title" => "İşlem Başarısız",
                "text" => "Logo yüklenirken bir problem oluştu",
                "type" => "error"
            );

            $this->session->set_flashdata("alert", $alert);

            redirect($_SERVER['HTTP_REFERER']);

            die();
        }
    }

    public function darklogo()
    {

        $file_name = seo(pathinfo($_FILES["file"]["name"], PATHINFO_FILENAME)) . "." . pathinfo($_FILES["file"]["name"], PATHINFO_EXTENSION);
        $sifrele = uniqid();
        $config["allowed_types"] = "png";
        $config["upload_path"] = "uploads/logo/";
        $config["file_name"] = $sifrele . "_" . $file_name;

        $this->load->library("upload", $config);

        $upload = $this->upload->do_upload("file");

        if ($upload) {

            $uploaded_file = $this->upload->data("file_name");

            $data = array(
                "site_darklogo" => "uploads/logo/" . $uploaded_file
            );
            $insert = $this->yonetim_model->ayarupdate(array("ayar_id" => 1), $data);

            $alert = array(
                "title" => "Logo Değiştirildi!",
                "text" => "Başarılı Şekilde Yüklendi",
                "type" => "success"
            );

            $this->session->set_flashdata("alert", $alert);

            redirect($_SERVER['HTTP_REFERER']);

            die();
        } else {

            $alert = array(
                "title" => "İşlem Başarısız",
                "text" => "Logo yüklenirken bir problem oluştu",
                "type" => "error"
            );

            $this->session->set_flashdata("alert", $alert);

            redirect($_SERVER['HTTP_REFERER']);

            die();
        }
    }

    public function faqarkaplan()
    {
        $file_name = seo(pathinfo($_FILES["file"]["name"], PATHINFO_FILENAME)) . "." . pathinfo($_FILES["file"]["name"], PATHINFO_EXTENSION);
        $sifrele = uniqid();
        $config["allowed_types"] = "png";
        $config["upload_path"] = "uploads/logo/";
        $config["file_name"] = $sifrele . "_" . $file_name;

        $this->load->library("upload", $config);

        $upload = $this->upload->do_upload("file");

        if ($upload) {

            $uploaded_file = $this->upload->data("file_name");

            $data = array(
                "faq_bg" => "uploads/logo/" . $uploaded_file
            );
            $insert = $this->yonetim_model->ayarupdate(array("ayar_id" => 1), $data);

            $alert = array(
                "title" => "FAQ Arka Plan Değiştirildi!",
                "text" => "Başarılı Şekilde Yüklendi",
                "type" => "success"
            );

            $this->session->set_flashdata("alert", $alert);

            redirect($_SERVER['HTTP_REFERER']);

            die();
        } else {

            $alert = array(
                "title" => "İşlem Başarısız",
                "text" => "Logo yüklenirken bir problem oluştu",
                "type" => "error"
            );

            $this->session->set_flashdata("alert", $alert);

            redirect($_SERVER['HTTP_REFERER']);

            die();
        }
    }

    public function favicon()
    {

        $file_name = seo(pathinfo($_FILES["file"]["name"], PATHINFO_FILENAME)) . "." . pathinfo($_FILES["file"]["name"], PATHINFO_EXTENSION);
        $sifrele = uniqid();
        $config["allowed_types"] = "png";
        $config["upload_path"] = "uploads/logo/";
        $config["file_name"] = $sifrele . "_" . $file_name;

        $this->load->library("upload", $config);

        $upload = $this->upload->do_upload("file");

        if ($upload) {

            $uploaded_file = $this->upload->data("file_name");

            $data = array(
                "site_favicon" => "uploads/logo/" . $uploaded_file
            );
            $insert = $this->yonetim_model->ayarupdate(array("ayar_id" => 1), $data);

            $alert = array(
                "title" => "Favicon Değiştirildi!",
                "text" => "Başarılı Şekilde Yüklendi",
                "type" => "success"
            );

            $this->session->set_flashdata("alert", $alert);

            redirect($_SERVER['HTTP_REFERER']);

            die();
        } else {

            $alert = array(
                "title" => "İşlem Başarısız",
                "text" => "Logo yüklenirken bir problem oluştu",
                "type" => "error"
            );

            $this->session->set_flashdata("alert", $alert);

            redirect($_SERVER['HTTP_REFERER']);

            die();
        }
    }

    public function kategorilerarka()
    {

        $file_name = seo(pathinfo($_FILES["file"]["name"], PATHINFO_FILENAME)) . "." . pathinfo($_FILES["file"]["name"], PATHINFO_EXTENSION);
        $sifrele = uniqid();
        $config["allowed_types"] = "png";
        $config["upload_path"] = "uploads/logo/";
        $config["file_name"] = $sifrele . "_" . $file_name;

        $this->load->library("upload", $config);

        $upload = $this->upload->do_upload("file");

        if ($upload) {

            $uploaded_file = $this->upload->data("file_name");

            $data = array(
                "site_kategorilerarka" => "uploads/logo/" . $uploaded_file
            );
            $insert = $this->yonetim_model->ayarupdate(array("ayar_id" => 1), $data);

            $alert = array(
                "title" => "Kategori Resmi Değiştirildi!",
                "text" => "Başarılı Şekilde Yüklendi",
                "type" => "success"
            );

            $this->session->set_flashdata("alert", $alert);

            redirect($_SERVER['HTTP_REFERER']);

            die();
        } else {

            $alert = array(
                "title" => "İşlem Başarısız",
                "text" => "Logo yüklenirken bir problem oluştu",
                "type" => "error"
            );

            $this->session->set_flashdata("alert", $alert);

            redirect($_SERVER['HTTP_REFERER']);

            die();
        }
    }

    public function destekarkaplan()
    {

        $file_name = seo(pathinfo($_FILES["file"]["name"], PATHINFO_FILENAME)) . "." . pathinfo($_FILES["file"]["name"], PATHINFO_EXTENSION);
        $sifrele = uniqid();
        $config["allowed_types"] = "png";
        $config["upload_path"] = "uploads/logo/";
        $config["file_name"] = $sifrele . "_" . $file_name;

        $this->load->library("upload", $config);

        $upload = $this->upload->do_upload("file");

        if ($upload) {

            $uploaded_file = $this->upload->data("file_name");

            $data = array(
                "destek_bg" => "uploads/logo/" . $uploaded_file
            );
            $insert = $this->yonetim_model->ayarupdate(array("ayar_id" => 1), $data);

            $alert = array(
                "title" => "Kategori Resmi Değiştirildi!",
                "text" => "Başarılı Şekilde Yüklendi",
                "type" => "success"
            );

            $this->session->set_flashdata("alert", $alert);

            redirect($_SERVER['HTTP_REFERER']);

            die();
        } else {

            $alert = array(
                "title" => "İşlem Başarısız",
                "text" => "Logo yüklenirken bir problem oluştu",
                "type" => "error"
            );

            $this->session->set_flashdata("alert", $alert);

            redirect($_SERVER['HTTP_REFERER']);

            die();
        }
    }


    //DD

    public function newilan()
    {

        $file_name = seo(pathinfo($_FILES["file"]["name"], PATHINFO_FILENAME)) . "." . pathinfo($_FILES["file"]["name"], PATHINFO_EXTENSION);
        $sifrele = uniqid();
        $config["allowed_types"] = "png";
        $config["upload_path"] = "uploads/logo/";
        $config["file_name"] = $sifrele . "_" . $file_name;

        $this->load->library("upload", $config);

        $upload = $this->upload->do_upload("file");

        if ($upload) {

            $uploaded_file = $this->upload->data("file_name");

            $data = array(
                "yeni_ilanlar" => "uploads/logo/" . $uploaded_file
            );
            $insert = $this->yonetim_model->ayarupdate(array("ayar_id" => 1), $data);

            $alert = array(
                "title" => "Kategori Resmi Değiştirildi!",
                "text" => "Başarılı Şekilde Yüklendi",
                "type" => "success"
            );

            $this->session->set_flashdata("alert", $alert);

            redirect($_SERVER['HTTP_REFERER']);

            die();
        } else {

            $alert = array(
                "title" => "İşlem Başarısız",
                "text" => "Logo yüklenirken bir problem oluştu",
                "type" => "error"
            );

            $this->session->set_flashdata("alert", $alert);

            redirect($_SERVER['HTTP_REFERER']);

            die();
        }
    }

    public function vitrinilan()
    {

        $file_name = seo(pathinfo($_FILES["file"]["name"], PATHINFO_FILENAME)) . "." . pathinfo($_FILES["file"]["name"], PATHINFO_EXTENSION);
        $sifrele = uniqid();
        $config["allowed_types"] = "png";
        $config["upload_path"] = "uploads/logo/";
        $config["file_name"] = $sifrele . "_" . $file_name;

        $this->load->library("upload", $config);

        $upload = $this->upload->do_upload("file");

        if ($upload) {

            $uploaded_file = $this->upload->data("file_name");

            $data = array(
                "vitrin_icon" => "uploads/logo/" . $uploaded_file
            );
            $insert = $this->yonetim_model->ayarupdate(array("ayar_id" => 1), $data);

            $alert = array(
                "title" => "Kategori Resmi Değiştirildi!",
                "text" => "Başarılı Şekilde Yüklendi",
                "type" => "success"
            );

            $this->session->set_flashdata("alert", $alert);

            redirect($_SERVER['HTTP_REFERER']);

            die();
        } else {

            $alert = array(
                "title" => "İşlem Başarısız",
                "text" => "Logo yüklenirken bir problem oluştu",
                "type" => "error"
            );

            $this->session->set_flashdata("alert", $alert);

            redirect($_SERVER['HTTP_REFERER']);

            die();
        }
    }

    public function getsubhd()
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }
        if ($_POST) {
            if (!is_array($hd)) {
                $hd = array();
            }
            $ci = &get_instance();
            $headers = $ci->db->select('*')->from('subheaders')->where(array('id' => $_POST["id"]))->get()->result();
            die(json_encode($headers));
        } else {
            echo "No Inputs";
        }
    }

    public function deletesubhd()
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }
        if ($_POST) {
            if (!is_array($hd)) {
                $hd = array();
            }
            $ci = &get_instance();
            $headers = $ci->db->where(array("id" => $_POST["id"]))->delete("subheaders");
            $alert = array(
                "title" => "İşlem Başarılı",
                "text" => "Subheader silindi!",
                "type" => "success"
            );

            $this->session->set_flashdata("alert", $alert);
            die();
        } else {
            echo "No Inputs";
        }
    }

    public function updsub()
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }
        if ($_POST) {
            $baslik = $this->input->post("baslik");
            $link = $this->input->post("link");
            if (empty($link) || empty($baslik)) {
                $alert = array(
                    "title" => "İşlem Başarısız",
                    "text" => "Boş alan bırakmayın.",
                    "type" => "error"
                );

                $this->session->set_flashdata("alert", $alert);

                redirect($_SERVER['HTTP_REFERER']);

                die();
            }
            $data = array(
                "baslik" => $baslik,
                "link" => $link
            );

            $insert = $this->yonetim_model->upsubhd($this->input->post("subid"), $data);
            if ($insert) {
                $alert = array(
                    "title" => "İşlem Başarısız",
                    "text" => "Subheader düzenlenmedi!",
                    "type" => "error"
                );
            } else {
                $alert = array(
                    "title" => "İşlem Başarılı",
                    "text" => "Subheader düzenlendi!",
                    "type" => "success"
                );
            }


            $this->session->set_flashdata("alert", $alert);

            redirect($_SERVER['HTTP_REFERER']);

            die();
        }
    }

    public function subhdekle()
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }
        if ($_POST) {
            $baslik = $this->input->post("baslik");
            $link = $this->input->post("link");
            if (empty($link) || empty($baslik)) {
                $alert = array(
                    "title" => "İşlem Başarısız",
                    "text" => "Boş alan bırakmayın.",
                    "type" => "error"
                );

                $this->session->set_flashdata("alert", $alert);

                redirect($_SERVER['HTTP_REFERER']);

                die();
            }
            $data = array(
                "baslik" => $baslik,
                "link" => $link
            );

            $insert = $this->yonetim_model->addsubhd($data);

            $alert = array(
                "title" => "İşlem Başarılı",
                "text" => "Subheader eklendi",
                "type" => "success"
            );

            $this->session->set_flashdata("alert", $alert);

            redirect($_SERVER['HTTP_REFERER']);

            die();
        }
    }

    public function coksatan()
    {

        $file_name = seo(pathinfo($_FILES["file"]["name"], PATHINFO_FILENAME)) . "." . pathinfo($_FILES["file"]["name"], PATHINFO_EXTENSION);
        $sifrele = uniqid();
        $config["allowed_types"] = "png";
        $config["upload_path"] = "uploads/logo/";
        $config["file_name"] = $sifrele . "_" . $file_name;

        $this->load->library("upload", $config);

        $upload = $this->upload->do_upload("file");

        if ($upload) {

            $uploaded_file = $this->upload->data("file_name");

            $data = array(
                "cok_satanlar" => "uploads/logo/" . $uploaded_file
            );
            $insert = $this->yonetim_model->ayarupdate(array("ayar_id" => 1), $data);

            $alert = array(
                "title" => "Kategori Resmi Değiştirildi!",
                "text" => "Başarılı Şekilde Yüklendi",
                "type" => "success"
            );

            $this->session->set_flashdata("alert", $alert);

            redirect($_SERVER['HTTP_REFERER']);

            die();
        } else {

            $alert = array(
                "title" => "İşlem Başarısız",
                "text" => "Logo yüklenirken bir problem oluştu",
                "type" => "error"
            );

            $this->session->set_flashdata("alert", $alert);

            redirect($_SERVER['HTTP_REFERER']);

            die();
        }
    }

    public function google()
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $data = array(
            "google_key" => $this->input->post("key"),
            "google_secret" => $this->input->post("secret"),
        );

        $insert = $this->yonetim_model->ayarupdate(array("ayar_id" => 1), $data);

        $alert = array(
            "title" => "İşlem Başarılı",
            "text" => "Google API Ayarları Başarılı Şekilde Güncellendi.",
            "type" => "success"
        );

        $this->session->set_flashdata("alert", $alert);

        redirect($_SERVER['HTTP_REFERER']);

        die();
    }

    public function hcaptcha()
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $data = array(
            "h_key" => $this->input->post("key"),
            "h_secret" => $this->input->post("secret"),
        );

        $insert = $this->yonetim_model->ayarupdate(array("ayar_id" => 1), $data);

        $alert = array(
            "title" => "İşlem Başarılı",
            "text" => "H Captcha API Ayarları Başarılı Şekilde Güncellendi.",
            "type" => "success"
        );

        $this->session->set_flashdata("alert", $alert);

        redirect($_SERVER['HTTP_REFERER']);

        die();
    }

    public function yonetimurl()
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $adminurl = $this->input->post("yonetim");

        $insert = $this->destek_model->adminadres($adminurl);


        $alert = array(
            "title" => "İşlem Başarılı",
            "text" => "Yönetici Adresi Başarılı Şekilde Güncellendi.",
            "type" => "success"
        );

        $this->session->set_flashdata("alert", $alert);

        redirect(base_url($adminurl . '/yonetim-url-ayarlari'));

        die();
    }

    public function seoayar()
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $data = array(
            "site_baslik" => $this->input->post("gbaslik"),
            "site_aciklama" => $this->input->post("gaciklama"),
            "site_keyw" => $this->input->post("gkeyw"),
            "iletisim_baslik" => $this->input->post("ibaslik"),
            "iletisim_aciklama" => $this->input->post("iaciklama"),
            "iletisim_keyw" => $this->input->post("ikeyw"),
        );


        $insert = $this->yonetim_model->ayarupdate(array("ayar_id" => 1), $data);


        $alert = array(
            "title" => "İşlem Başarılı",
            "text" => "Seo Ayarları Başarılı Şekilde Güncellendi.",
            "type" => "success"
        );

        $this->session->set_flashdata("alert", $alert);

        redirect($_SERVER['HTTP_REFERER']);

        die();
    }


    public function footerayar()
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $data = array(
            "iletisim_tel" => $this->input->post("tel"),
            "iletisim_sabit" => $this->input->post("sabittel"),
            "iletisim_mail" => $this->input->post("mail"),
            "facebook" => $this->input->post("facebook"),
            "twitter" => $this->input->post("twitter"),
            "instagram" => $this->input->post("instagram"),
            "discord" => $this->input->post("discord"),
            "copyright" => $this->input->post("copyright"),
            "footer_uyari" => $this->input->post("footer_uyari"),
            "analytics" => $this->input->post("analytics"),
            "adres" => $this->input->post("adres"),
            "harita" => $this->input->post("harita"),
        );


        $insert = $this->yonetim_model->ayarupdate(array("ayar_id" => 1), $data);


        $alert = array(
            "title" => "İşlem Başarılı",
            "text" => "Footer Ayarları Başarılı Şekilde Güncellendi.",
            "type" => "success"
        );

        $this->session->set_flashdata("alert", $alert);

        redirect($_SERVER['HTTP_REFERER']);

        die();
    }

    public function smtpayar()
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $data = array(
            "smtp_host" => $this->input->post("host"),
            "smtp_mail" => $this->input->post("kullanici"),
            "smtp_sifre" => $this->input->post("sifre"),
            "smtp_port" => $this->input->post("port"),
            "smtp_gomail" => $this->input->post("gomail"),
        );


        $insert = $this->yonetim_model->ayarupdate(array("ayar_id" => 1), $data);


        $alert = array(
            "title" => "İşlem Başarılı",
            "text" => "SMTP Ayarı Başarılı Şekilde Güncellendi.",
            "type" => "success"
        );

        $this->session->set_flashdata("alert", $alert);

        redirect($_SERVER['HTTP_REFERER']);

        die();
    }

    public function sayfaekle()
    {

        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $data = new stdClass();

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;


        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/sayfa/sayfa-ekle', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function sayfa_go()
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $data = array(
            "sayfa_ad" => $this->input->post("ad"),
            "sayfa_detay" => $this->input->post("detay"),
            "sayfa_seo" => seo($this->input->post("ad")),
            "sayfa_sira" => $this->input->post("sira"),
            "sayfa_konum" => $this->input->post("konum"),
            "sayfa_tur" => $this->input->post("tur"),
            "sayfa_url" => $this->input->post("url"),
            "sayfa_title" => $this->input->post("title"),
            "sayfa_desc" => $this->input->post("desc"),
            "sayfa_keyw" => $this->input->post("keyw"),
        );


        $insert = $this->yonetim_model->sayfaadd($data);


        $alert = array(
            "title" => "İşlem Başarılı",
            "text" => "Sayfa Başarılı Şekilde Oluşturuldu!",
            "type" => "success"
        );

        $this->session->set_flashdata("alert", $alert);

        redirect(base_url(admin_url() . "sayfa-ekle"));

        die();
    }

    public function sayfalar()
    {

        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $data = new stdClass();

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;


        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/sayfa/sayfalar', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function sayfadurum($id)
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        if ($id) {

            $durumum = ($this->input->post("data") === "true") ? 1 : 0;

            $this->yonetim_model->sayfaupdate(array("sayfa_id" => $id), array("sayfa_durum" => $durumum));
        }
    }

    public function sayfaduzenle($sayfaid)
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $data = new stdClass();

        // View'e Gönderilecek Değişkenlerin Set Edilmesi

        $where = $this->yonetim_model->sayfaget(
            array(
                "sayfa_id" => $sayfaid
            )
        );

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;
        $data->where = $where;


        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/sayfa/sayfa-duzenle', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function sayfa_duzenle($sayfaid)
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }


        $insert = $this->yonetim_model->sayfaupdate(
            array("sayfa_id" => $sayfaid),
            array(
                "sayfa_ad" => $this->input->post("ad"),
                "sayfa_detay" => $this->input->post("detay"),
                "sayfa_seo" => seo($this->input->post("ad")),
                "sayfa_sira" => $this->input->post("sira"),
                "sayfa_konum" => $this->input->post("konum"),
                "sayfa_tur" => $this->input->post("tur"),
                "sayfa_url" => $this->input->post("url"),
                "sayfa_title" => $this->input->post("title"),
                "sayfa_desc" => $this->input->post("desc"),
                "sayfa_keyw" => $this->input->post("keyw"),

            )
        );


        $alert = array(
            "title" => "İşlem Başarılı",
            "text" => "Sayfa Başarılı Şekilde Güncellendi",
            "type" => "success"
        );

        $this->session->set_flashdata("alert", $alert);

        redirect(base_url(admin_url() . "sayfa-duzenle/$sayfaid"));

        die();
    }

    public function sayfadelete($sayfaid)
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $delete = $this->yonetim_model->sayfadelete(array("sayfa_id" => $sayfaid));

        if ($delete) {
            redirect(base_url(admin_url() . "sayfalar"));
        } else {
            redirect(base_url(admin_url() . "sayfalar"));
        }
    }


    public function sssekle()
    {

        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $data = new stdClass();

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;


        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/sss/sss-ekle', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function sss_go()
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $data = array(
            "sss_baslik" => $this->input->post("baslik"),
            "sss_aciklama" => $this->input->post("aciklama"),
        );


        $this->yonetim_model->sssadd($data);


        $alert = array(
            "title" => "İşlem Başarılı",
            "text" => "SSS Başarılı Şekilde Oluşturuldu!",
            "type" => "success"
        );

        $this->session->set_flashdata("alert", $alert);

        redirect(base_url(admin_url() . "sss-ekle"));

        die();
    }

    public function sss()
    {

        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $data = new stdClass();

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;


        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/sss/sss', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function sssduzenle($sayfaid)
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $data = new stdClass();

        // View'e Gönderilecek Değişkenlerin Set Edilmesi

        $where = $this->yonetim_model->sssget(
            array(
                "sss_id" => $sayfaid
            )
        );

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;
        $data->where = $where;


        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/sss/sss-duzenle', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function sss_duzenle($sayfaid)
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }


        $insert = $this->yonetim_model->sssupdate(
            array("sss_id" => $sayfaid),
            array(
                "sss_baslik" => $this->input->post("baslik"),
                "sss_aciklama" => $this->input->post("aciklama"),
            )
        );


        $alert = array(
            "title" => "İşlem Başarılı",
            "text" => "SSS Başarılı Şekilde Güncellendi",
            "type" => "success"
        );

        $this->session->set_flashdata("alert", $alert);

        redirect(base_url(admin_url() . "sss-duzenle/$sayfaid"));

        die();
    }

    public function sssdelete($sayfaid)
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $delete = $this->yonetim_model->sssdelete(array("sss_id" => $sayfaid));

        if ($delete) {
            redirect(base_url(admin_url() . "sss"));
        } else {
            redirect(base_url(admin_url() . "sss"));
        }
    }

    //Yönetici İşlemleri

    public function yoneticiekle()
    {

        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $data = new stdClass();

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;


        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/yonetici/yonetici-ekle', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function yonetici_go()
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $this->load->library("form_validation");
        $this->form_validation->set_rules("ad", "Yönetici Ad", "trim|is_unique[kullanici.kullanici_ad]");

        $this->form_validation->set_message(
            array(
                "required" => "{field} Boş Bırakılamaz!",
                "min_length" => "{field} En Az {param} Karakter Olmalıdır!",
                "max_length" => "{field} En Fazla {param} Karakter Olmalıdır!",
                "valid_email" => "{field} Girmeniz Gerekmektedir!",
                "is_unique" => "%s Zaten Sistemde Kayıtlı!"
            )
        );

        $validat = $this->form_validation->run();

        if ($validat) {

            $data = array(
                "kullanici_ad" => $this->input->post("ad"),
                "kullanici_sifre" => password_hash($this->input->post("sifre"), PASSWORD_DEFAULT),
                "kullanici_mail" => $this->input->post("mail"),
                "kullanici_yetki" => $this->input->post("yetki"),
                "kullanici_durum" => $this->input->post("durum"),
                "kullanici_isim" => $this->input->post("isim"),
                "kullanici_soyisim" => $this->input->post("soyisim"),
                "kullanici_bayi" => $this->input->post("kullanici_bayi"),
                "kullanici_bayi_komisyon" => $this->input->post("kullanici_bayi_komisyon"),
                "apiKey" => $this->input->post("apiKey")
            );


            $insert = $this->yonetim_model->yoneticiadd($data);


            $alert = array(
                "title" => "İşlem Başarılı",
                "text" => "Yönetici Başarılı Şekilde Oluşturuldu!",
                "type" => "success"
            );

            $this->session->set_flashdata("alert", $alert);

            redirect(base_url(admin_url() . "kullanici-ekle"));

            die();
        } else {

            $alert = array(
                "title" => "İşlem Başarısız",
                "text" => "Kullanıcı Adı Benzer Olamaz!",
                "type" => "error"
            );

            $this->session->set_flashdata("alert", $alert);

            redirect(base_url(admin_url() . "kullanici-ekle"));
        }
    }

    public function yoneticiler()
    {

        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $data = new stdClass();

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;


        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/yonetici/yoneticiler', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function kullaniciduzenle($kullaniciid)
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $data = new stdClass();

        // View'e Gönderilecek Değişkenlerin Set Edilmesi

        $where = $this->yonetim_model->kullaniciget(
            array(
                "kullanici_id" => $kullaniciid
            )
        );

        if (admin_magaza_check($where->kullanici_id)) {
            $aylik = aylik_kazanc($where->kullanici_id);

            $data->odenen_kazanclar = odenen_kazanclar($where->kullanici_id);
            $data->odenebilir_kazanclar = odenebilir_kazanclar($where->kullanici_id);
            $data->aylik_kazanc = aylik_toplam_kazanc($where->kullanici_id);
            $data->gunluk_kazanc = gunluk_toplam_kazanc($where->kullanici_id);
            if ($aylik['data']) {
                $data->aylar = json_encode($aylik['data']['ay'], JSON_UNESCAPED_UNICODE);
                $data->veriler = json_encode($aylik['data']['veri'], JSON_UNESCAPED_UNICODE);
            } else {
                $data->aylar = 0;
                $data->veriler = 0;
            }
            $data->toplam_kazanclar = toplam_kazanclar($where->kullanici_id);
            $data->magaza = $this->magaza_model->magaza(array('magaza.kullanici_id' => $where->kullanici_id));
        }

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;
        $data->where = $where;


        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/yonetici/yonetici-duzenle', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function kullanici_duzenle($kullaniciid)
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $where = $this->yonetim_model->kullaniciget(
            array(
                "kullanici_id" => $kullaniciid
            )
        );

        if ($this->input->post("sifre") == $where->kullanici_sifre) {
            $sifre = $where->kullanici_sifre;
        } else {
            $sifre = password_hash($this->input->post("sifre"), PASSWORD_DEFAULT);
        }


        $insert = $this->yonetim_model->yoneticiupdate(
            array("kullanici_id" => $kullaniciid),
            array(
                "kullanici_sifre" => $sifre,
                "kullanici_mail" => $this->input->post("mail"),
                "kullanici_yetki" => $this->input->post("yetki"),
                "kullanici_durum" => $this->input->post("durum"),
                "kullanici_isim" => $this->input->post("isim"),
                "kullanici_soyisim" => $this->input->post("soyisim"),
                "bakiye" => $this->input->post("bakiye"),
                "kullanici_bayi" => $this->input->post("kullanici_bayi"),
                "kullanici_bayi_komisyon" => $this->input->post("kullanici_bayi_komisyon"),
                "kullanici_bayi_bakiye" => $this->input->post("kullanici_bayi_bakiye"),
                "apiKey" => $this->input->post("apiKey"),
                "kullanici_tel" => $this->input->post("kullanici_tel")
            )
        );


        $alert = array(
            "title" => "İşlem Başarılı",
            "text" => "Yönetici Başarılı Şekilde Güncellendi!",
            "type" => "success"
        );

        $this->session->set_flashdata("alert", $alert);

        redirect(base_url(admin_url() . "kullanici-duzenle/$kullaniciid"));

        die();
    }

    public function kullanicidelete($kullaniciid)
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $delete = $this->yonetim_model->kullanicidelete(array("kullanici_id" => $kullaniciid));

        if ($delete) {
            redirect(base_url(admin_url() . "kullanicilar"));
        } else {
            redirect(base_url(admin_url() . "kullanicilar"));
        }
    }


    public function bankaekle()
    {

        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $data = new stdClass();

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;


        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/banka/banka-ekle', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function banka_go()
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $this->load->library("form_validation");

        $this->form_validation->set_rules("name", "Banka Başlık", "required");

        $this->form_validation->set_message(
            array(
                "required" => "{field} Boş Bırakılamaz!",
            )
        );

        $validat = $this->form_validation->run();


        if ($validat) {

            if ($_FILES["file"]["name"]) {
                $file_name = seo(pathinfo($_FILES["file"]["name"], PATHINFO_FILENAME)) . "." . pathinfo($_FILES["file"]["name"], PATHINFO_EXTENSION);
                $sifrele = uniqid();
                $config["allowed_types"] = "jpg|jpeg|png";
                $config["upload_path"] = "uploads/banka/";
                $config["file_name"] = $sifrele . "_" . $file_name;

                $this->load->library("upload", $config);

                $upload = $this->upload->do_upload("file");

                if ($upload) {

                    $uploaded_file = $this->upload->data("file_name");

                    $data = array(
                        "name" => $this->input->post("name"),
                        "iban" => $this->input->post("iban"),
                        "description" => $this->input->post("description"),
                        "status" => $this->input->post("status"),
                        "order_no" => $this->input->post("order_no"),
                        "image" => "uploads/banka/" . $uploaded_file
                    );


                    $insert = $this->yonetim_model->bankaadd($data);


                    $alert = array(
                        "title" => "İşlem Başarılı",
                        "text" => "Banka Hesabı Başarılı Şekilde Eklendi",
                        "type" => "success"
                    );

                    $this->session->set_flashdata("alert", $alert);

                    redirect(base_url(admin_url() . "banka-hesabi-ekle"));

                    die();
                } else {

                    $alert = array(
                        "title" => "İşlem Başarısız",
                        "text" => "Lütfen Banka Fotoğrafı Ekleyin!",
                        "type" => "error"
                    );

                    $this->session->set_flashdata("alert", $alert);

                    redirect(base_url(admin_url() . "banka-hesabi-ekle"));

                    die();
                }
            } else {

                $alert = array(
                    "title" => "İşlem Başarısız",
                    "text" => "Lütfen Banka Fotoğrafı Ekleyin!",
                    "type" => "error"
                );

                $this->session->set_flashdata("alert", $alert);

                redirect(base_url(admin_url() . "banka-hesabi-ekle"));

                die();
            }
        } else {

            if (!active_user()) {
                redirect(base_url(admin_url() . 'giris'));
            }

            $data = new stdClass();

            $siteayar = ayarlar();

            $data->form_error = true;
            $data->title = $siteayar->site_baslik;
            $data->description = $siteayar->site_aciklama;
            $data->keywords = $siteayar->site_keyw;


            $this->load->view('yonetim/inc/_header', $data);
            $this->load->view('yonetim/banka/banka-ekle', $data);
            $this->load->view('yonetim/inc/_footer');
        }
    }

    public function bankalar()
    {

        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $data = new stdClass();

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;


        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/banka/bankalar', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function para_cekme_Ayarlari()
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $data = new stdClass();

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;

        $data->yontemler = $this->yonetim_model->get_para_cekme_yontemleri();

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/para_cekme/yontemler', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function para_cekme_yontem_duzenle($id)
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $data = new stdClass();

        // View'e Gönderilecek Değişkenlerin Set Edilmesi

        $where = $this->yonetim_model->para_cekme_yontem_get($id);

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;
        $data->where = $where;


        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/para_cekme/yontem-duzenle', $data);
        $this->load->view('yonetim/inc/_footer');
    }


    public function bankaduzenle($bankaid)
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $data = new stdClass();

        // View'e Gönderilecek Değişkenlerin Set Edilmesi

        $where = $this->yonetim_model->bankaget(
            array(
                "id" => $bankaid
            )
        );

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;
        $data->where = $where;


        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/banka/banka-duzenle', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function paracekmeyontemduzenle($yontemid)
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $this->load->library("form_validation");

        $this->form_validation->set_rules("title", "Yöntem Adı", "required|trim");

        $this->form_validation->set_message(
            array(
                "required" => "{field} Boş Bırakılamaz!",
            )
        );

        $validat = $this->form_validation->run();


        if ($validat) {

            if ($_FILES["file"]["name"]) {
                $file_name = seo(pathinfo($_FILES["file"]["name"], PATHINFO_FILENAME)) . "." . pathinfo($_FILES["file"]["name"], PATHINFO_EXTENSION);
                $sifrele = uniqid();
                $config["allowed_types"] = "jpg|jpeg|png";
                $config["upload_path"] = "uploads/banka/";
                $config["file_name"] = $sifrele . "_" . $file_name;

                $this->load->library("upload", $config);

                $upload = $this->upload->do_upload("file");

                if ($upload) {

                    $uploaded_file = $this->upload->data("file_name");


                    $insert = $this->yonetim_model->paracekmeyontemupdate(
                        array("id" => $yontemid),
                        array(
                            "row_title" => $this->input->post("title"),
                            "row_sira" => $this->input->post("sira"),
                            "row_image" => "uploads/banka/" . $uploaded_file
                        )
                    );


                    $alert = array(
                        "title" => "İşlem Başarılı",
                        "text" => "Para Çekme Durum Başarılı Şekilde Güncellendi",
                        "type" => "success"
                    );

                    $this->session->set_flashdata("alert", $alert);

                    redirect(base_url(admin_url() . "para-cekme-yontem-duzenle/$yontemid"));

                    die();
                } else {

                    $alert = array(
                        "title" => "İşlem Başarısız",
                        "text" => "Fotoğraf Yüklenemedi!",
                        "type" => "error"
                    );

                    $this->session->set_flashdata("alert", $alert);

                    redirect(base_url(admin_url() . "para-cekme-yontem-duzenle/$yontemid"));

                    die();
                }
            } else {

                $insert = $this->yonetim_model->paracekmeyontemupdate(
                    array("id" => $yontemid),
                    array(
                        "row_title" => $this->input->post("title"),
                        "row_sira" => $this->input->post("sira")
                    )
                );


                $alert = array(
                    "title" => "İşlem Başarılı",
                    "text" => "Para Çekme Durum Başarılı Şekilde Güncellendi",
                    "type" => "success"
                );

                $this->session->set_flashdata("alert", $alert);

                redirect(base_url(admin_url() . "para-cekme-yontem-duzenle/$yontemid"));

                die();
            }
        } else {
            redirect(base_url(admin_url() . "para-cekme-yontem-duzenle/$yontemid"));
        }
    }


    public function banka_duzenle($bankaid)
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $this->load->library("form_validation");

        $this->form_validation->set_rules("name", "Banka Adı", "required|trim");

        $this->form_validation->set_message(
            array(
                "required" => "{field} Boş Bırakılamaz!",
            )
        );

        $validat = $this->form_validation->run();


        if ($validat) {

            if ($_FILES["file"]["name"]) {
                $file_name = seo(pathinfo($_FILES["file"]["name"], PATHINFO_FILENAME)) . "." . pathinfo($_FILES["file"]["name"], PATHINFO_EXTENSION);
                $sifrele = uniqid();
                $config["allowed_types"] = "jpg|jpeg|png";
                $config["upload_path"] = "uploads/banka/";
                $config["file_name"] = $sifrele . "_" . $file_name;

                $this->load->library("upload", $config);

                $upload = $this->upload->do_upload("file");

                if ($upload) {

                    $uploaded_file = $this->upload->data("file_name");


                    $insert = $this->yonetim_model->bankaupdate(
                        array("id" => $bankaid),
                        array(
                            "name" => $this->input->post("name"),
                            "iban" => $this->input->post("iban"),
                            "description" => $this->input->post("description"),
                            "status" => $this->input->post("status"),
                            "order_no" => $this->input->post("order_no"),
                            "image" => "uploads/banka/" . $uploaded_file

                        )
                    );


                    $alert = array(
                        "title" => "İşlem Başarılı",
                        "text" => "Banka Başarılı Şekilde Güncellendi",
                        "type" => "success"
                    );

                    $this->session->set_flashdata("alert", $alert);

                    redirect(base_url(admin_url() . "banka-hesabi-duzenle/$bankaid"));

                    die();
                } else {

                    $alert = array(
                        "title" => "İşlem Başarısız",
                        "text" => "Fotoğraf Yüklenemedi!",
                        "type" => "error"
                    );

                    $this->session->set_flashdata("alert", $alert);

                    redirect(base_url(admin_url() . "banka-hesabi-duzenle/$bankaid"));

                    die();
                }
            } else {

                $insert = $this->yonetim_model->bankaupdate(
                    array("id" => $bankaid),
                    array(
                        "name" => $this->input->post("name"),
                        "iban" => $this->input->post("iban"),
                        "description" => $this->input->post("description"),
                        "order_no" => $this->input->post("order_no"),
                        "status" => $this->input->post("status"),

                    )
                );


                $alert = array(
                    "title" => "İşlem Başarılı",
                    "text" => "Banka Başarılı Şekilde Güncellendi",
                    "type" => "success"
                );

                $this->session->set_flashdata("alert", $alert);

                redirect(base_url(admin_url() . "banka-hesabi-duzenle/$bankaid"));

                die();
            }
        } else {
            redirect(base_url(admin_url() . "banka-hesabi-duzenle/$bankaid"));
        }
    }

    public function bankadelete($bankaid)
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $delete = $this->yonetim_model->bankadelete(array("id" => $bankaid));

        if ($delete) {
            redirect(base_url(admin_url() . "banka-hesaplari"));
        } else {
            redirect(base_url(admin_url() . "banka-hesaplari"));
        }
    }

    public function blogekle()
    {

        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $data = new stdClass();

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;


        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/blog/blog-ekle', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function blog_go()
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $this->load->library("form_validation");

        $this->form_validation->set_rules("ad", "Blog Başlık", "required|is_unique[blog.blog_ad]");

        $this->form_validation->set_message(
            array(
                "required" => "{field} Boş Bırakılamaz!",
                "is_unique" => "%s Zaten Sistemde Kayıtlı!"
            )
        );

        $validat = $this->form_validation->run();


        if ($validat) {

            if ($_FILES["file"]["name"]) {
                $file_name = seo(pathinfo($_FILES["file"]["name"], PATHINFO_FILENAME)) . "." . pathinfo($_FILES["file"]["name"], PATHINFO_EXTENSION);
                $sifrele = uniqid();
                $config["allowed_types"] = "jpg|jpeg|png";
                $config["upload_path"] = "uploads/blog/";
                $config["file_name"] = $sifrele . "_" . $file_name;

                $this->load->library("upload", $config);

                $upload = $this->upload->do_upload("file");

                if ($upload) {

                    //Alt Kategori Seçildi İse 1-0 İşlemi
                    if ($this->input->post("altkategori") != 0) {
                        $au = 1;
                    } else {
                        $au = 0;
                    }
                    //---Bitiş---

                    $uploaded_file = $this->upload->data("file_name");

                    $data = array(
                        "blog_ad" => $this->input->post("ad"),
                        "blog_detay" => $this->input->post("detay"),
                        "blog_kategori_id" => $this->input->post("kategori"),
                        "blog_seo" => seo($this->input->post("ad")),
                        "blog_resim" => "uploads/blog/" . $uploaded_file

                    );


                    $insert = $this->yonetim_model->blogadd($data);


                    $alert = array(
                        "title" => "İşlem Başarılı",
                        "text" => "Blog Başarılı Şekilde Eklendi",
                        "type" => "success"
                    );

                    $this->session->set_flashdata("alert", $alert);

                    redirect(base_url(admin_url() . "blog-ekle"));

                    die();
                } else {

                    $alert = array(
                        "title" => "İşlem Başarısız",
                        "text" => "Lütfen Blog Fotoğrafı Ekleyin!",
                        "type" => "error"
                    );

                    $this->session->set_flashdata("alert", $alert);

                    redirect(base_url(admin_url() . "blog-ekle"));

                    die();
                }
            } else {

                $alert = array(
                    "title" => "İşlem Başarısız",
                    "text" => "Lütfen Blog Fotoğrafı Ekleyin!",
                    "type" => "error"
                );

                $this->session->set_flashdata("alert", $alert);

                redirect(base_url(admin_url() . "blog-ekle"));

                die();
            }
        } else {

            if (!active_user()) {
                redirect(base_url(admin_url() . 'giris'));
            }

            $data = new stdClass();

            $siteayar = ayarlar();

            $data->form_error = true;
            $data->title = $siteayar->site_baslik;
            $data->description = $siteayar->site_aciklama;
            $data->keywords = $siteayar->site_keyw;


            $this->load->view('yonetim/inc/_header', $data);
            $this->load->view('yonetim/kategori/kategori-ekle', $data);
            $this->load->view('yonetim/inc/_footer');
        }
    }

    public function bloglar()
    {

        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $data = new stdClass();

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;


        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/blog/bloglar', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function blogduzenle($blogid)
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $data = new stdClass();

        // View'e Gönderilecek Değişkenlerin Set Edilmesi

        $where = $this->yonetim_model->blogget(
            array(
                "blog_id" => $blogid
            )
        );

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;
        $data->where = $where;


        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/blog/blog-duzenle', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function blog_duzenle($blogid)
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $this->load->library("form_validation");

        $this->form_validation->set_rules("ad", "Kategori Adı", "required|trim");

        $this->form_validation->set_message(
            array(
                "required" => "{field} Boş Bırakılamaz!",
            )
        );

        $validat = $this->form_validation->run();


        if ($validat) {

            if ($_FILES["file"]["name"]) {
                $file_name = seo(pathinfo($_FILES["file"]["name"], PATHINFO_FILENAME)) . "." . pathinfo($_FILES["file"]["name"], PATHINFO_EXTENSION);
                $sifrele = uniqid();
                $config["allowed_types"] = "jpg|jpeg|png";
                $config["upload_path"] = "uploads/blog/";
                $config["file_name"] = $sifrele . "_" . $file_name;

                $this->load->library("upload", $config);

                $upload = $this->upload->do_upload("file");

                if ($upload) {

                    $uploaded_file = $this->upload->data("file_name");


                    $insert = $this->yonetim_model->blogupdate(
                        array("blog_id" => $blogid),
                        array(
                            "blog_ad" => $this->input->post("ad"),
                            "blog_detay" => $this->input->post("detay"),
                            "blog_kategori_id" => $this->input->post("kategori"),
                            "blog_seo" => seo($this->input->post("ad")),
                            "blog_resim" => "uploads/blog/" . $uploaded_file

                        )
                    );


                    $alert = array(
                        "title" => "İşlem Başarılı",
                        "text" => "Blog Başarılı Şekilde Güncellendi",
                        "type" => "success"
                    );

                    $this->session->set_flashdata("alert", $alert);

                    redirect(base_url(admin_url() . "blog-duzenle/$blogid"));

                    die();
                } else {

                    $alert = array(
                        "title" => "İşlem Başarısız",
                        "text" => "Fotoğraf Yüklenemedi!",
                        "type" => "error"
                    );

                    $this->session->set_flashdata("alert", $alert);

                    redirect(base_url(admin_url() . "blog-duzenle/$blogid"));

                    die();
                }
            } else {

                $insert = $this->yonetim_model->blogupdate(
                    array("blog_id" => $blogid),
                    array(
                        "blog_ad" => $this->input->post("ad"),
                        "blog_kategori_id" => $this->input->post("kategori"),
                        "blog_detay" => $this->input->post("detay"),
                        "blog_seo" => seo($this->input->post("ad")),

                    )
                );


                $alert = array(
                    "title" => "İşlem Başarılı",
                    "text" => "Blog Başarılı Şekilde Güncellendi",
                    "type" => "success"
                );

                $this->session->set_flashdata("alert", $alert);

                redirect(base_url(admin_url() . "blog-duzenle/$blogid"));

                die();
            }
        } else {

            if (!active_user()) {
                redirect(base_url(admin_url() . 'giris'));
            }

            $data = new stdClass();

            $siteayar = ayarlar();

            $data->form_error = true;
            $data->title = $siteayar->site_baslik;
            $data->description = $siteayar->site_aciklama;
            $data->keywords = $siteayar->site_keyw;


            $this->load->view('yonetim/inc/_header', $data);
            $this->load->view('yonetim/blog/blog-duzenle/$blogid', $data);
            $this->load->view('yonetim/inc/_footer');
        }
    }

    public function blogdelete($blogid)
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $delete = $this->yonetim_model->blogdelete(array("blog_id" => $blogid));

        if ($delete) {
            redirect(base_url(admin_url() . "bloglar"));
        } else {
            redirect(base_url(admin_url() . "bloglar"));
        }
    }

    // Reklam işlemleri

    public function reklamekle()
    {

        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $data = new stdClass();

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;

        $this->session->unset_userdata('images');
        $this->session->unset_userdata('images-two');
        $this->session->unset_userdata('images-three');

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/reklam/reklam-ekle', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function reklam_go()
    {

        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        if ($this->session->userdata('images') && $this->session->userdata('images-two') && $this->session->userdata('images-three')) {

            $data = array(
                "image" => $this->session->userdata('images')[0],
                "image_two" => $this->session->userdata('images-two')[0],
                "image_three" => $this->session->userdata('images-three')[0],
                "link" => $this->input->post("url"),
                "order_no" => $this->input->post("sira"),
                "type" => $this->input->post("tur")
            );

            $insert = $this->yonetim_model->reklamadd($data);

            $alert = array(
                "title" => "İşlem Başarılı",
                "text" => "Reklam Başarılı Şekilde Eklendi",
                "type" => "success"
            );

            $this->session->set_flashdata("alert", $alert);

            redirect(base_url(admin_url() . "reklam-ekle"));

            die();

        } else {

            $alert = array(
                "title" => "İşlem Başarısız!",
                "text" => "Lütfen Fotoğrafları Seçin!",
                "type" => "error"
            );

            $this->session->set_flashdata("alert", $alert);

            redirect(base_url(admin_url() . "reklam-ekle"));

            die();
        }
    }


    public function ust_reklam()
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $data = new stdClass();

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;

        $data->slider = $this->db->where(['type' => 1])->order_by("order_no ASC")->get('home_sliders')->result();

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/reklam/reklam', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function alt_reklam()
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $data = new stdClass();

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;

        $data->slider = $this->db->where(['type' => 2])->order_by("order_no ASC")->get('home_sliders')->result();

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/reklam/reklam', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function reklamduzenle($id)
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $data = new stdClass();

        // View'e Gönderilecek Değişkenlerin Set Edilmesi

        $where = $this->yonetim_model->reklamget(
            array(
                "id" => $id
            )
        );

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;
        $data->where = $where;

        $this->session->unset_userdata('images');
        $this->session->unset_userdata('images-two');
        $this->session->unset_userdata('images-three');

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/reklam/reklam-duzenle', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function reklam_duzenle($id)
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $data = new stdClass();


        $data->link = $this->input->post("url");
        $data->order_no = $this->input->post("sira");
        $data->type = $this->input->post("tur");
        if (!empty($this->session->userdata('images'))) {
            $data->image = $this->session->userdata('images')[0];
        }
        if (!empty($this->session->userdata('images-two'))) {
            $data->image_two = $this->session->userdata('images-two')[0];
        }
        if (!empty($this->session->userdata('images-three'))) {
            $data->image_three = $this->session->userdata('images-three')[0];
        }

        $update = $this->yonetim_model->reklamupdate(array("id" => $id), $data);


        $alert = array(
            "title" => "İşlem Başarılı",
            "text" => "Reklam Başarılı Şekilde Güncellendi",
            "type" => "success"
        );

        $this->session->set_flashdata("alert", $alert);

        redirect(base_url(admin_url() . "reklam-duzenle/$id"));

        die();
    }

    public function reklamdelete($id)
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $delete = $this->yonetim_model->reklamdelete(array("id" => $id));

        if ($delete) {
            redirect($this->input->server('HTTP_REFERER'));
        } else {
            redirect($this->input->server('HTTP_REFERER'));
        }
    }

    //Slider İşlemleri

    public function sliderekle()
    {

        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $data = new stdClass();

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;

        $this->session->unset_userdata('images');

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/slider/slider-ekle', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function slider_go()
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        if ($this->session->userdata('images')) {
            $data = array(
                "slider_resim" => $this->session->userdata('images')[0],
                "slider_url" => $this->input->post("url"),
                "slider_sira" => $this->input->post("sira"),
                "tur" => $this->input->post("tur"),
                "slider_baslik" => $this->input->post("slider_baslik"),
                "slider_aciklama" => $this->input->post("slider_aciklama"),

            );

            $insert = $this->yonetim_model->slideradd($data);

            $alert = array(
                "title" => "İşlem Başarılı",
                "text" => "Slider Başarılı Şekilde Eklendi",
                "type" => "success"
            );

            $this->session->set_flashdata("alert", $alert);

            redirect(base_url(admin_url() . "slider-ekle"));

            die();

        } else {
            $alert = array(
                "title" => "İşlem Başarısız!",
                "text" => "Lütfen Fotoğraf Seçin!",
                "type" => "error"
            );

            $this->session->set_flashdata("alert", $alert);

            redirect(base_url(admin_url() . "slider-ekle"));

            die();
        }
    }

    public function slider()
    {

        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $data = new stdClass();

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;

        $data->slider = $this->db->where(['tur' => 1])->order_by("slider_sira ASC")->get('slider')->result();

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/slider/slider', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function ust_slider()
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $data = new stdClass();

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;

        $data->slider = $this->db->where(['tur' => 3])->order_by("slider_sira ASC")->get('slider')->result();

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/slider/slider', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function alt_slider()
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $data = new stdClass();

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;

        $data->slider = $this->db->where(['tur' => 2])->order_by("slider_sira ASC")->get('slider')->result();

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/slider/slider', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function yan_slider()
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $data = new stdClass();

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;

        $data->slider = $this->db->where(['tur' => 4])->order_by("slider_sira ASC")->get('slider')->result();

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/slider/yan-slider', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function sliderduzenle($sliderid)
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $data = new stdClass();

        // View'e Gönderilecek Değişkenlerin Set Edilmesi

        $where = $this->yonetim_model->sliderget(
            array(
                "slider_id" => $sliderid
            )
        );

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;
        $data->where = $where;

        $this->session->unset_userdata('images');

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/slider/slider-duzenle', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function slider_duzenle($sliderid)
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        if ($this->session->userdata('images')) {
            $insert = $this->yonetim_model->sliderupdate(
                array("slider_id" => $sliderid),
                array(
                    "slider_resim" => $this->session->userdata('images')[0],
                    "slider_url" => $this->input->post("url"),
                    "slider_sira" => $this->input->post("sira"),
                    "tur" => $this->input->post("tur"),
                    "slider_baslik" => $this->input->post("slider_baslik"),
                    "slider_aciklama" => $this->input->post("slider_aciklama"),

                )
            );

            $alert = array(
                "title" => "İşlem Başarılı",
                "text" => "Slider Başarılı Şekilde Güncellendi",
                "type" => "success"
            );

            $this->session->set_flashdata("alert", $alert);

            redirect(base_url(admin_url() . "slider-duzenle/$sliderid"));

            die();
        } else {
            $insert = $this->yonetim_model->sliderupdate(
                array("slider_id" => $sliderid),
                array(
                    "slider_url" => $this->input->post("url"),
                    "slider_sira" => $this->input->post("sira"),
                    "slider_baslik" => $this->input->post("slider_baslik"),
                    "slider_aciklama" => $this->input->post("slider_aciklama"),
                    "tur" => $this->input->post("tur"),
                )
            );

            $alert = array(
                "title" => "İşlem Başarılı",
                "text" => "Slider Başarılı Şekilde Güncellendi",
                "type" => "success"
            );

            $this->session->set_flashdata("alert", $alert);

            redirect(base_url(admin_url() . "slider-duzenle/$sliderid"));

            die();
        }
    }

    public function sliderdelete($sliderid)
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $delete = $this->yonetim_model->sliderdelete(array("slider_id" => $sliderid));

        if ($delete) {
            redirect($this->input->server('HTTP_REFERER'));
        } else {
            redirect($this->input->server('HTTP_REFERER'));
        }
    }

    public function bakiyeler()
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $data = new stdClass();
        $siteayar = ayarlar();
        $kullanici = admin_kullanicicek();
        $data->kullanici = $kullanici;

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;
        $data->bakiyeler = $this->bakiye_model->bakiyelerAdmin();

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/bakiye/bakiye', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function bakiye_iptal($bakiye_id)
    {
        $kullanici = admin_kullanicicek();
        $this->bakiye_model->bakiye_update(array('bakiye.bakiye_id' => $bakiye_id), array('bakiye_durum' => '2'));

        $alert = array(
            "title" => "Başarılı!",
            "text" => "Ödeme İptal Edildi..",
            "type" => "success"
        );
        $this->session->set_flashdata("alert", $alert);
        redirect(base_url(admin_url() . "bakiyeler"));
        die();
    }


    //SMS Şablonlar

    public function smsayar()
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $data = array(
            "netgsm_user" => $this->input->post("username"),
            "netgsm_pass" => $this->input->post("password"),
            "netgsm_header" => $this->input->post("header"),
            "sms_tutar" => $this->input->post("tutar"),
            "netgsm_durum" => $this->input->post("status"),
        );

        $this->yonetim_model->ayarupdate(array("ayar_id" => 1), $data);

        $alert = array(
            "title" => "İşlem Başarılı",
            "text" => "SMS Ayarı Başarılı Şekilde Güncellendi.",
            "type" => "success"
        );

        $this->session->set_flashdata("alert", $alert);
        redirect($_SERVER['HTTP_REFERER']);

        die();
    }

    public function reklamayar()
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $data = array(
            "reklam_baslik" => $this->input->post("reklam_baslik"),
            "reklam_icerik" => $this->input->post("reklam_icerik"),
            "reklam_durum" => $this->input->post("status"),
        );

        $this->yonetim_model->ayarupdate(array("ayar_id" => 1), $data);

        $alert = array(
            "title" => "İşlem Başarılı",
            "text" => "Reklam Ayarı Başarılı Şekilde Güncellendi.",
            "type" => "success"
        );

        $this->session->set_flashdata("alert", $alert);
        redirect($_SERVER['HTTP_REFERER']);

        die();
    }

    public function sms_sablonlar()
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $data = new stdClass();
        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;
        $data->sablonlar = $this->sms_model->sms_sablonlar();


        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/sms-sablon/sms-sablonlar', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function smssablonekle()
    {

        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $data = new stdClass();

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;


        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/sms-sablon/sms-sablon-ekle', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function sms_sablon_ekle()
    {

        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $data = array(
            "sablon_baslik" => $this->input->post("baslik"),
            "sablon_durum" => $this->input->post("durum"),
            "sablon_mesaj" => $this->input->post("sablon")
        );


        $insert = $this->sms_model->sms_sablon_add($data);


        $alert = array(
            "title" => "İşlem Başarılı",
            "text" => "SMS Şablon Başarılı Şekilde Oluşturuldu!",
            "type" => "success"
        );

        $this->session->set_flashdata("alert", $alert);

        redirect(base_url(admin_url() . "sms-sablon-ekle"));

        die();
    }

    public function smssablonduzenle($sablonid)
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $data = new stdClass();

        // View'e Gönderilecek Değişkenlerin Set Edilmesi

        $where = $this->sms_model->sms_sablon(
            array(
                "sablon_id" => $sablonid
            )
        );

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;
        $data->where = $where;


        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/sms-sablon/sms-sablon-duzenle', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function sms_sablon_duzenle($sablonid)
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }


        $insert = $this->sms_model->sms_sablon_update(
            array("sablon_id" => $sablonid),
            array(
                "sablon_baslik" => $this->input->post("baslik"),
                "sablon_durum" => $this->input->post("durum"),
                "sablon_mesaj" => $this->input->post("sablon")
            )
        );


        $alert = array(
            "title" => "İşlem Başarılı",
            "text" => "SMS Şablon Başarılı Şekilde Güncellendi",
            "type" => "success"
        );

        $this->session->set_flashdata("alert", $alert);

        redirect(base_url(admin_url() . "sms-sablon-duzenle/$sablonid"));

        die();
    }

    public function smsdelete($sablonid)
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $delete = $this->sms_model->sms_sablon_sil(array("sablon_id" => $sablonid));

        if ($delete) {
            redirect(base_url(admin_url() . "sms-sablonlar"));
        } else {
            redirect(base_url(admin_url() . "sms-sablonlar"));
        }
    }

    public function cekilisler()
    {
        $data = new stdClass();

        // View'e Gönderilecek Değişkenlerin Set Edilmesi

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;

        $data->cekilisler = $this->db->get("cekilis")->result();

        foreach ($data->cekilisler as $cekilis) {
            $cekilis->magaza_ad = $this->db->where("magaza_id", $cekilis->magaza_id)->get("magaza")->row()->magaza_ad;
        }

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/cekilis/liste', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function tamamlanan_cekilisler()
    {
        $data = new stdClass();

        // View'e Gönderilecek Değişkenlerin Set Edilmesi

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;

        $data->cekilisler = $this->db->where(['status' => 1, 'onay' => 1])->get("cekilis")->result();

        foreach ($data->cekilisler as $cekilis) {
            $cekilis->magaza_ad = $this->db->where("magaza_id", $cekilis->magaza_id)->get("magaza")->row()->magaza_ad;
        }

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/cekilis/tamamlanan', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function aktif_cekilisler()
    {
        $data = new stdClass();

        // View'e Gönderilecek Değişkenlerin Set Edilmesi

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;

        $data->cekilisler = $this->db->where(['status' => 0, 'onay' => 1])->get("cekilis")->result();

        foreach ($data->cekilisler as $cekilis) {
            $cekilis->magaza_ad = $this->db->where("magaza_id", $cekilis->magaza_id)->get("magaza")->row()->magaza_ad;
        }

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/cekilis/aktif', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function cekilisonay($id = null)
    {
        $cekilis = $this->db->where("id", $id)->get("cekilis")->row();

        $this->db->where("id", $id)->update("cekilis", array("onay" => 1));

        $alert = array(
            "title" => "İşlem Başarılı",
            "text" => "Çekiliş başarıyla onaylandı",
            "type" => "success"
        );

        $this->session->set_flashdata("alert", $alert);

        redirect(base_url(admin_url() . "cekilisler"));
    }

    public function cekilisiptal($id = null)
    {
        $cekilis = $this->db->where("id", $id)->get("cekilis")->row();

        $this->db->where("id", $id)->update("cekilis", array("onay" => 2));

        $alert = array(
            "title" => "İşlem Başarılı",
            "text" => "Çekiliş başarıyla iptal edildi",
            "type" => "success"
        );

        $this->session->set_flashdata("alert", $alert);

        redirect(base_url(admin_url() . "cekilisler"));
    }

    public function cekilissil($id = null)
    {
        $cekilis = $this->db->where("id", $id)->get("cekilis")->row();

        $this->db->where("id", $id)->delete("cekilis");

        $alert = array(
            "title" => "İşlem Başarılı",
            "text" => "Çekiliş başarıyla Silindi",
            "type" => "success"
        );

        $this->session->set_flashdata("alert", $alert);

        redirect(base_url(admin_url() . "cekilisler"));
    }


    //Ürün key hevuzu
    public function urunkeyhavuzu()
    {
        $data = new stdClass();

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;

        $data->stocks = $this->db->get("stock")->result();

        foreach ($data->stocks as $stock) {
            $stock->urun_ad = $this->db->where("urun_id", $stock->urun_id)->get("urunler")->row()->urun_ad;
        }

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/urunkey/liste', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function urunkeyhavuzuekle()
    {
        $data = new stdClass();

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;

        $data->urunler = $this->db->get("urunler")->result();

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/urunkey/ekle', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function urunkeyhavuzusave()
    {

        $id = $this->input->post("id");

        $data = [
            'urun_id' => $this->input->post('urun_id'),
            'urun_key' => $this->input->post('urun_key'),
            'status' => 0,
            'seller' => 0,
            'created_at' => date('Y-m-d H:i:s'),
        ];


        if ($id) {
            $update = $this->db->where("id", $id)->update("stock", [
                'urun_id' => $this->input->post('urun_id'),
                'key' => $this->input->post('urun_key'),
                'status' => 0,
                'seller' => 0,
                'created_at' => date('Y-m-d H:i:s'),
            ]);

            $this->session->set_flashdata("alert", [
                "title" => "İşlem Başarılı",
                "text" => "Ürün key havuzu başarıyla güncellendi",
                "type" => "success"
            ]);
        } else {
            $keyler = explode("\n", $data['urun_key']);

            foreach ($keyler as $key => $value) {
                $this->db->insert('stock', [
                    'urun_id' => $this->input->post('urun_id'),
                    'key' => $value,
                    'status' => 0,
                    'seller' => 0,
                    'created_at' => date('Y-m-d H:i:s'),

                ]);
            }

            $this->session->set_flashdata("alert", [
                "title" => "İşlem Başarılı",
                "text" => "Ürün key havuzu başarıyla eklendi",
                "type" => "success"
            ]);
        }


        redirect(base_url(admin_url() . "urun-key-havuzu"));
    }

    public function urunkeyhavuzuduzenle($id = null)
    {
        $data = new stdClass();

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;

        $data->urunler = $this->db->get("urunler")->result();

        $data->stock = $this->db->where("id", $id)->get("stock")->row();

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/urunkey/ekle', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function urunkeyhavuzusil($id = null)
    {
        $this->db->where("id", $id)->delete("stock");

        $this->session->set_flashdata("alert", [
            "title" => "İşlem Başarılı",
            "text" => "Ürün key havuzu başarıyla silindi",
            "type" => "success"
        ]);

        redirect(base_url(admin_url() . "urun-key-havuzu"));
    }

    public function keybekleyensiparisler()
    {
        $data = new stdClass();

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;

        $data->siparisler = $this->db->where(['siparis_epin' => 2, 'siparis_durum !=' => 3])->get('siparis')->result();

        foreach ($data->siparisler as $siparis) {
            $siparis->urun = $this->db->where("urun_id", $siparis->urun_id)->get("urunler")->row();
            $siparis->kullanici = $this->db->where("kullanici_id", $siparis->kullanici_id)->get("kullanici")->row();
        }

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/siparis/keybekleyen', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function keybekleyensiparislerduzenle($id = null)
    {
        $data = new stdClass();

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;

        $data->siparis = $this->db->where('siparis_id', $id)->get('siparis')->row();

        $data->siparis->urun = $this->db->where("urun_id", $data->siparis->urun_id)->get("urunler")->row();
        $data->siparis->kullanici = $this->db->where("kullanici_id", $data->siparis->kullanici_id)->get("kullanici")->row();

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/siparis/keybekleyenduzenle', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function keybekleyensiparislerkayit()
    {
        if ($this->input->post('siparis_epin') == 1) {
            $siparis_durum = 2;
        } else {
            $siparis_durum = 1;
        }

        if ($this->input->post('siparis_epin') != 3) {
            $data = [
                'siparis_id' => $this->input->post('siparis_id'),
                'siparis_epin' => $this->input->post('siparis_epin'),
                'siparis_key' => $this->input->post('siparis_key'),
                'siparis_durum' => $siparis_durum
            ];
        } else {
            $data = [
                'siparis_id' => $this->input->post('siparis_id'),
                'siparis_iptal' => $this->input->post('siparis_iptal'),
                'siparis_durum' => 3
            ];
        }
        if ($this->input->post('siparis_epin') != 3) {
            $this->db->where("siparis_id", $data['siparis_id'])->update("siparis", [
                'siparis_epin' => $data['siparis_epin'],
                'siparis_key' => $data['siparis_key'],
                'siparis_durum' => $data['siparis_durum']
            ]);
        } else {
            $siparis = $this->yonetim_model->get_selected_siparis($this->input->post('siparis_id'));

            $user_balance = kullanici_bilgi($siparis->kullanici_id)->bakiye;
            $new_user_balance = $user_balance + $siparis->siparis_tutar;
            $update_user_balance = $this->yonetim_model->update_user_balance($siparis->kullanici_id, $new_user_balance);

            $this->db->where("siparis_id", $data['siparis_id'])->update("siparis", [
                'siparis_iptal' => $data['siparis_iptal'],
                'siparis_durum' => $data['siparis_durum']
            ]);
        }

        $this->session->set_flashdata("alert", [
            "title" => "İşlem Başarılı",
            "text" => "Sipariş başarıyla güncellendi",
            "type" => "success"
        ]);

        redirect(base_url(admin_url() . "key-bekleyen-siparisler"));
    }

    public function keybekleyensiparislersil($id = null)
    {
        $siparis = $this->yonetim_model->get_selected_siparis($id);

        if ($siparis) {
            $user_balance = kullanici_bilgi($siparis->kullanici_id)->bakiye;
            $new_user_balance = $user_balance + $siparis->siparis_tutar;
            $update_user_balance = $this->yonetim_model->update_user_balance($siparis->kullanici_id, $new_user_balance);
            if ($update_user_balance) {
                if ($this->db->where("siparis_id", $id)->delete("siparis")) {
                    redirect(base_url(admin_url() . "key-bekleyen-siparisler"));
                } else {
                    redirect(base_url(admin_url() . "key-bekleyen-siparisler"));
                }
            } else {
                redirect(base_url(admin_url() . "key-bekleyen-siparisler"));
            }
        } else {
            redirect(base_url(admin_url() . "key-bekleyen-siparisler"));
        }
    }

    public function cekilisdetay($id = null)
    {
        $data = new stdClass();

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;

        $cekilis = $this->db->where('id', $id)->get('cekilis')->row();
        $cekilis->magaza = $this->db->where('magaza_id', $cekilis->magaza_id)->get('magaza')->row();
        $cekilis->esyalar = $this->db->where('cekilis_id', $cekilis->id)->get('cekilis_item')->result();
        $cekilis->katilimcisayi = $this->db->where('cekilis_id', $cekilis->id)->from('cekilis_katilanlar')->count_all_results();

        foreach ($cekilis->esyalar as $key => $esya) {
            $esya->urun_fiyat = $this->db->select('urun_fiyat')->where('urun_id', $esya->urun_id)->get('urunler')->row()->urun_fiyat;
            $esya->urun_ad = $this->db->select('urun_ad')->where('urun_id', $esya->urun_id)->get('urunler')->row()->urun_ad;
            $esya->urun_resim = $this->db->select('urun_resim')->where('urun_id', $esya->urun_id)->get('urunler')->row()->urun_resim;
            $cekilis->toplam_fiyat += ($esya->urun_fiyat) * $esya->urun_miktar;

            if ($esya->bakiye > 1) {
                $cekilis->toplam_fiyat += $esya->bakiye;
                $esya->urun_ad = 'Bakiye';

                $esya->urun_resim = base_url('assets/images/bakiyeresim.jpeg');
                $esya->bakiyem = true;
                $esya->urun_fiyat = $esya->bakiye;
            }
        }

        //çekiliş kazananlar
        if ($cekilis->status == 1) {
            $cekilis->kazananlar = $this->db->where('cekilis_id', $cekilis->id)->get('cekilis_kazananlar')->result();
            // bir kullanıcıyı bir kere kayıt etmek için

            foreach ($cekilis->kazananlar as $kullanici) {
                $kullanici->kullanici = $this->db->where('kullanici_id', $kullanici->kullanici_id)->get('kullanici')->row();
            }
        }

        $data->cekilis = $cekilis;

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/cekilis/detay', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function pvp_server_ekle()
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $data = new stdClass();

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;


        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/pvp-server/ekle', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function server_go()
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $this->load->library("form_validation");

        $this->form_validation->set_rules("server", "Server", "required|trim");

        $this->form_validation->set_message(
            array(
                "required" => "{field} Boş Bırakılamaz!",
            )
        );

        $validat = $this->form_validation->run();


        if ($validat) {

            if ($_FILES["file"]["name"]) {
                $file_name = seo(pathinfo($_FILES["file"]["name"], PATHINFO_FILENAME)) . "." . pathinfo($_FILES["file"]["name"], PATHINFO_EXTENSION);
                $sifrele = uniqid();
                $config["allowed_types"] = "jpg|jpeg|png";
                $config["upload_path"] = "uploads/img/";
                $config["file_name"] = $sifrele . "_" . $file_name;

                $this->load->library("upload", $config);

                $upload = $this->upload->do_upload("file");

                if ($upload) {

                    $uploaded_file = $this->upload->data("file_name");

                    $data = array(
                        "server" => $this->input->post("server"),
                        "sira" => $this->input->post("sira"),
                        "image" => "uploads/img/" . $uploaded_file,
                        "link" => $this->input->post("link"),
                        "server_status" => $this->input->post("server_status"),
                        "beta_tarih" => $this->input->post("beta_tarih"),
                        "offical_tarih" => $this->input->post("offical_tarih"),
                        "oyun_turu" => $this->input->post("oyun_turu"),
                    );

                    $insert = $this->yonetim_model->serveradd($data);


                    $alert = array(
                        "title" => "İşlem Başarılı",
                        "text" => "Pvp Server Başarılı Şekilde Eklendi",
                        "type" => "success"
                    );

                    $this->session->set_flashdata("alert", $alert);

                    redirect(base_url(admin_url() . "pvp-server-ekle/" . $this->input->post('kategori')));

                    die();
                } else {

                    $alert = array(
                        "title" => "İşlem Başarısız",
                        "text" => "Lütfen Server Fotoğrafı Ekleyin!",
                        "type" => "error"
                    );

                    $this->session->set_flashdata("alert", $alert);

                    redirect(base_url(admin_url() . "pvp-server-ekle/" . $this->input->post('kategori')));

                    die();
                }
            } else {
                $alert = array(
                    "title" => "İşlem Başarısız",
                    "text" => "Lütfen Server Fotoğrafı Ekleyin!",
                    "type" => "error"
                );

                $this->session->set_flashdata("alert", $alert);

                redirect(base_url(admin_url() . "pvp-server-ekle/" . $this->input->post('kategori')));

                die();
            }
        } else {

            if (!active_user()) {
                redirect(base_url(admin_url() . 'giris'));
            }

            $data = new stdClass();

            $siteayar = ayarlar();

            $data->form_error = true;
            $data->title = $siteayar->site_baslik;
            $data->description = $siteayar->site_aciklama;
            $data->keywords = $siteayar->site_keyw;

            $this->load->view('yonetim/inc/_header', $data);
            $this->load->view('yonetim/pvp-server/ekle', $data);
            $this->load->view('yonetim/inc/_footer');
        }
    }

    public function pvp_server_listele()
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $data = new stdClass();

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;

        $data->servers = $this->yonetim_model->get_pvp_servers();


        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/pvp-server/listele', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function serverdelete($sliderid)
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $delete = $this->yonetim_model->serverdelete(array("id" => $sliderid));

        if ($delete) {
            redirect(base_url(admin_url() . "pvp-serverlar"));
        } else {
            redirect(base_url(admin_url() . "pvp-serverlar"));
        }
    }

    public function pvp_server_duzenle($serve_id)
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        $data = new stdClass();

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;

        if (!$data->server = $this->yonetim_model->get_selected_pvp_server($serve_id)) {
            redirect(base_url(admin_url() . 'pvp-serverlar'));
        }


        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/pvp-server/duzenle', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function server_update($server_id)
    {
        if (!active_user()) {
            redirect(base_url(admin_url() . 'giris'));
        }

        if (!$server = $this->yonetim_model->get_selected_pvp_server($server_id)) {
            redirect(base_url(admin_url() . 'pvp-serverlar'));
        }

        $this->load->library("form_validation");

        $this->form_validation->set_rules("server", "Server", "required|trim");

        $this->form_validation->set_message(
            array(
                "required" => "{field} Boş Bırakılamaz!",
            )
        );

        $validat = $this->form_validation->run();


        if ($validat) {

            if ($_FILES["file"]["name"]) {
                $file_name = seo(pathinfo($_FILES["file"]["name"], PATHINFO_FILENAME)) . "." . pathinfo($_FILES["file"]["name"], PATHINFO_EXTENSION);
                $sifrele = uniqid();
                $config["allowed_types"] = "jpg|jpeg|png";
                $config["upload_path"] = "uploads/img/";
                $config["file_name"] = $sifrele . "_" . $file_name;

                $this->load->library("upload", $config);

                $upload = $this->upload->do_upload("file");

                if ($upload) {

                    $uploaded_file = $this->upload->data("file_name");

                    $data = array(
                        "server" => $this->input->post("server"),
                        "sira" => $this->input->post("sira"),
                        "image" => "uploads/img/" . $uploaded_file,
                        "link" => $this->input->post("link"),
                        "server_status" => $this->input->post("server_status"),
                        "beta_tarih" => $this->input->post("beta_tarih"),
                        "offical_tarih" => $this->input->post("offical_tarih"),
                        "oyun_turu" => $this->input->post("oyun_turu"),
                    );

                    $insert = $this->yonetim_model->server_update($data, $server_id);


                    $alert = array(
                        "title" => "İşlem Başarılı",
                        "text" => "Pvp Server Başarılı Şekilde Güncellendi",
                        "type" => "success"
                    );

                    $this->session->set_flashdata("alert", $alert);

                    redirect(base_url(admin_url() . "pvp-server-duzenle/" . $server_id));

                    die();
                } else {

                    $alert = array(
                        "title" => "İşlem Başarısız",
                        "text" => "Lütfen Server Fotoğrafı Ekleyin!",
                        "type" => "error"
                    );

                    $this->session->set_flashdata("alert", $alert);

                    redirect(base_url(admin_url() . "pvp-server-duzenle/" . $server_id));

                    die();
                }
            } else {
                $data = array(
                    "server" => $this->input->post("server"),
                    "sira" => $this->input->post("sira"),
                    "link" => $this->input->post("link"),
                    "server_status" => $this->input->post("server_status"),
                    "beta_tarih" => $this->input->post("beta_tarih"),
                    "offical_tarih" => $this->input->post("offical_tarih"),
                    "oyun_turu" => $this->input->post("oyun_turu"),
                );

                $insert = $this->yonetim_model->server_update($data, $server_id);

                $alert = array(
                    "title" => "İşlem Başarılı",
                    "text" => "Pvp Server Başarılı Şekilde Eklendi",
                    "type" => "success"
                );

                $this->session->set_flashdata("alert", $alert);

                redirect(base_url(admin_url() . "pvp-server-duzenle/" . $server_id));

                die();
            }
        } else {

            if (!active_user()) {
                redirect(base_url(admin_url() . 'giris'));
            }

            $data = new stdClass();

            $siteayar = ayarlar();

            $data->form_error = true;
            $data->title = $siteayar->site_baslik;
            $data->description = $siteayar->site_aciklama;
            $data->keywords = $siteayar->site_keyw;

            $this->load->view('yonetim/inc/_header', $data);
            $this->load->view('yonetim/pvp-server/ekle', $data);
            $this->load->view('yonetim/inc/_footer');
        }
    }

    public function siteye_satis_duzenle($id)
    {
        $data = new stdClass();

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;

        if (empty($id)) {
            redirect($this->agent->referrer());
        }
        if (!$data->selected = $this->yonetim_model->get_selected_siteye_satis($id)) {
            redirect($this->agent->referrer());
        }

        if ($_POST) {
            $status = $this->input->post('status', true);
            $delivery_character = $this->input->post('delivery_character_name', true);

            if ($status == 0) {
                $arr = array(
                    "status" => $this->input->post("status"),
                    "delivery_character_name" => $this->input->post("delivery_character_name"),
                );
            } else if ($status == 1) {
                if ($data->selected->type == 2) {
                    //siteden alım
                    $urun = urun_bilgiler($data->selected->urun_id);

                    if ($urun->urun_stok <= 0) {
                        $alert = array(
                            "title" => "Uyarı!!",
                            "text" => "Üründe Yeterli Stok Bulunmamaktadır!!",
                            "type" => "warning"
                        );

                        $this->session->set_flashdata("alert", $alert);

                        redirect($this->agent->referrer());
                        die();
                    }

                    $arr = array(
                        "status" => $this->input->post("status"),
                        "delivery_character_name" => $this->input->post("delivery_character_name"),
                        "delivery_date" => date('Y-m-d H:i:s')
                    );
                    $new_stok = $urun->urun_stok - $data->selected->quantity;
                    $this->yonetim_model->update_urun_stok($urun->urun_id, $new_stok);
                } else if ($data->selected->type == 1) {
                    //siteye satış
                    $urun = urun_bilgiler($data->selected->urun_id);

                    if ($urun->urun_alim_stok <= 0) {
                        $alert = array(
                            "title" => "Uyarı!!",
                            "text" => "Üründe Alım İçin Yeterli Stok Bulunmamaktadır!!",
                            "type" => "warning"
                        );

                        $this->session->set_flashdata("alert", $alert);

                        redirect($this->agent->referrer());
                        die();
                    }

                    $user_balance = kullanici_bilgi($data->selected->user_id)->bakiye;
                    $new_user_balance = $user_balance + $data->selected->price;
                    $update_user_balance = $this->yonetim_model->update_user_balance($data->selected->user_id, $new_user_balance);

                    $arr = array(
                        "status" => $this->input->post("status"),
                        "delivery_character_name" => $this->input->post("delivery_character_name"),
                        "delivery_date" => date('Y-m-d H:i:s')
                    );
                    $new_stok = $urun->urun_alim_stok - $data->selected->quantity;
                    $this->yonetim_model->update_urun_alim_stok($urun->urun_id, $new_stok);
                }
            } else if ($status == 2) {
                if ($data->selected->type == 2) {
                    //siteden alım
                    $user_balance = kullanici_bilgi($data->selected->user_id)->bakiye;
                    $new_user_balance = $user_balance + $data->selected->price;
                    $update_user_balance = $this->yonetim_model->update_user_balance($data->selected->user_id, $new_user_balance);
                }
                $arr = array(
                    "status" => $this->input->post("status"),
                    "delivery_character_name" => $this->input->post("delivery_character_name"),
                    "reason_for_cancellation" => $this->input->post('reason_for_cancellation')
                );
            }

            $update = $this->yonetim_model->update_siteye_satis($arr, $id);

            $alert = array(
                "title" => "İşlem Başarılı",
                "text" => "Güncelleme İşlemi Başarılı",
                "type" => "success"
            );

            $this->session->set_flashdata("alert", $alert);

            redirect($this->agent->referrer());
            die();
        }

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/siteye_satis/duzenle', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function siteye_satis_bekleyen()
    {
        $data = new stdClass();

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;

        $data->siteye_satislar = $this->yonetim_model->get_siteye_satislar(0);

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/siteye_satis/bekleyen', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function siteye_satis_tamamlanan()
    {
        $data = new stdClass();

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;

        $data->siteye_satislar = $this->yonetim_model->get_siteye_satislar(1);

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/siteye_satis/tamamlanan', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function siteye_satis_iptal()
    {
        $data = new stdClass();

        $siteayar = ayarlar();

        $data->title = $siteayar->site_baslik;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;

        $data->siteye_satislar = $this->yonetim_model->get_siteye_satislar(2);

        $this->load->view('yonetim/inc/_header', $data);
        $this->load->view('yonetim/siteye_satis/iptal', $data);
        $this->load->view('yonetim/inc/_footer');
    }

    public function gold_alim_satim_onayla($id)
    {
        $data = $this->yonetim_model->get_gold_alim_satim($id);
        if (!empty($data)) {
            if ($data->type == 1) {
                if ($data->status == 0) {
                    $get_user = kullanici_bilgi($data->user_id);
                    $db_urun = $this->home_model->get_urun($data->urun_id);

                    $this->db->where('kullanici_id', $get_user->kullanici_id)->update('kullanici', [
                        'bakiye' => $get_user->bakiye + ($db_urun->urun_alimfiyat * $data->quantity)
                    ]);

                    $this->yonetim_model->update_gold_alim_satim_status($id, 1);
                    $alert = array(
                        "title" => "Başarılı,",
                        "text" => "Başarılı Şekilde Onaylandı",
                        "type" => "success"
                    );
                    $this->session->set_flashdata("alert", $alert);
                    redirect(base_url(admin_url() . 'siteye-satis-bekleyen'));
                } else if ($data->status == 1) {
                    $get_user = kullanici_bilgi($data->user_id);
                    $db_urun = $this->home_model->get_urun($data->urun_id);

                    $this->db->where('kullanici_id', $get_user->kullanici_id)->update('kullanici', [
                        'bakiye' => $get_user->bakiye - ($db_urun->urun_alimfiyat * $data->quantity)
                    ]);

                    $this->yonetim_model->update_gold_alim_satim_status($id, 0);
                    $alert = array(
                        "title" => "Başarılı,",
                        "text" => "Teslimat Bekliyor Olarak İşaretlendi.",
                        "type" => "success"
                    );
                    $this->session->set_flashdata("alert", $alert);
                    redirect(base_url(admin_url() . 'siteye-satis-bekleyen'));
                } else if ($data->status == 2) {
                    $this->yonetim_model->update_gold_alim_satim_status($id, 0);
                    $alert = array(
                        "title" => "Başarılı,",
                        "text" => "Teslimat Bekliyor Olarak İşaretlendi",
                        "type" => "success"
                    );
                    $this->session->set_flashdata("alert", $alert);
                    redirect(base_url(admin_url() . 'siteye-satis-bekleyen'));
                }
            } else if ($data->type == 2) {
                if ($data->status == 0) {
                    $this->yonetim_model->update_gold_alim_satim_status($id, 1);
                    $alert = array(
                        "title" => "Başarılı,",
                        "text" => "Başarılı Şekilde Onaylandı",
                        "type" => "success"
                    );
                    $this->session->set_flashdata("alert", $alert);
                    redirect(base_url(admin_url() . 'siteye-satis-bekleyen'));
                } else if ($data->status == 1) {
                    $this->yonetim_model->update_gold_alim_satim_status($id, 0);
                    $alert = array(
                        "title" => "Başarılı,",
                        "text" => "Teslimat Bekliyor Olarak İşaretlendi.",
                        "type" => "success"
                    );
                    $this->session->set_flashdata("alert", $alert);
                    redirect(base_url(admin_url() . 'siteye-satis-bekleyen'));
                } else if ($data->status == 2) {
                    $this->yonetim_model->update_gold_alim_satim_status($id, 0);
                    $alert = array(
                        "title" => "Başarılı,",
                        "text" => "Teslimat Bekliyor Olarak İşaretlendi.",
                        "type" => "success"
                    );
                    $this->session->set_flashdata("alert", $alert);
                    redirect(base_url(admin_url() . 'siteye-satis-bekleyen'));
                }
            } else {
                redirect(base_url(admin_url() . 'siteye-satis-bekleyen'));
            }
        } else {
            redirect(base_url(admin_url() . 'siteye-satis-bekleyen'));
        }
    }

    public function gold_alim_satim_sil()
    {
        $id = $this->input->post('id');
        $text = $this->input->post('text');
        if ($db_gold = $this->yonetim_model->get_gold_alim_satim($id)) {
            if ($db_gold->type == 1) {
                if ($db_gold->status == 0) {
                    $this->yonetim_model->delete_gold_alim_satim($id, $text);
                    /*$alert = array(
                        "title" => "Başarılı",
                        "text" => "İşlem İptal Edilmiştir.",
                        "type" => "success"
                    );
                    $this->session->set_flashdata("alert", $alert);*/
                    $data = [
                        'status' => true,
                        'url' => base_url(admin_url() . 'siteye-satis-bekleyen'),
                        'message' => 'Başarılı, İşlem İptal Edilmiştir.'
                    ];
                    echo json_encode($data);
                } else if ($db_gold->status == 1) {
                    $get_user = kullanici_bilgi($db_gold->user_id);
                    $db_urun = $this->home_model->get_urun($db_gold->urun_id);

                    $this->db->where('kullanici_id', $get_user->kullanici_id)->update('kullanici', [
                        'bakiye' => $get_user->bakiye - ($db_urun->urun_alimfiyat * $db_gold->quantity)
                    ]);

                    $this->yonetim_model->delete_gold_alim_satim($id, $text);
                    /*$alert = array(
                        "title" => "Başarılı",
                        "text" => "İşlem İptal Edilmiştir.",
                        "type" => "success"
                    );
                    $this->session->set_flashdata("alert", $alert);*/
                    $data = [
                        'status' => true,
                        'url' => base_url(admin_url() . 'siteye-satis-bekleyen'),
                        'message' => 'Başarılı, İşlem İptal Edilmiştir.'
                    ];
                    echo json_encode($data);
                }
            } else if ($db_gold->type == 2) {
                $get_user = kullanici_bilgi($db_gold->user_id);
                $db_urun = $this->home_model->get_urun($db_gold->urun_id);

                $this->db->where('kullanici_id', $get_user->kullanici_id)->update('kullanici', [
                    'bakiye' => $get_user->bakiye + ($db_urun->urun_alimfiyat * $db_gold->quantity)
                ]);

                $this->yonetim_model->delete_gold_alim_satim($id, $text);
                /*$alert = array(
                    "title" => "Başarılı",
                    "text" => "İşlem İptal Edilmiştir.",
                    "type" => "success"
                );
                $this->session->set_flashdata("alert", $alert);*/
                $data = [
                    'status' => true,
                    'url' => base_url(admin_url() . 'siteye-satis-bekleyen'),
                    'message' => 'Başarılı, İşlem İptal Edilmiştir.'
                ];
                echo json_encode($data);
            }
        } else {
            /*$alert = array(
                "title" => "Hata,",
                "text" => "Yapmaya Çalıştığınız İşlem Geçerli Değildir.",
                "type" => "error"
            );
            $this->session->set_flashdata("alert", $alert);*/
            $data = [
                'status' => false,
                'url' => base_url(admin_url() . 'siteye-satis-bekleyen'),
                'message' => 'Yapmaya Çalıştığınızı İşlem Geçerli Değildir'
            ];
            echo json_encode($data);
        }
    }
    
    public function gold_alim_satim_komple_sil($id)
    {
        $delete = $this->yonetim_model->gold_alim_satim_delete(array("id" => $id));



        if ($delete) {
            $alert = array(
                "title" => "İşlem Başarılı",
                "text" => "Silindi",
                "type" => "success"
            );
            $this->session->set_flashdata("alert", $alert);

            redirect($_SERVER['HTTP_REFERER']);
        } else {
            $alert = array(
                "title" => "Uyarı!!",
                "text" => "Bir Hata Meydana Geldi",
                "type" => "warning"
            );
            $this->session->set_flashdata("alert", $alert);
            redirect($_SERVER['HTTP_REFERER']);
        }
    }

}
