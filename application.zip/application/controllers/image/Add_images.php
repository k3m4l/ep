<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Add_images extends CI_Controller
{

    function __construct()
    {
        parent:: __construct();
    }

    public function add_image()
    {
        $uploaded_images = [];
        $config['upload_path'] = 'uploads/img/';
        $config['allowed_types'] = 'jpg|png|jpeg';
        $config['encrypt_name'] = TRUE;
        $this->load->library('upload', $config);

        if ($this->upload->do_upload('file')) {
            $image_session = $this->session->userdata('images');
            if ($image_session == false) {
                $uploaded_images = [];
            } else {
                $uploaded_images = $image_session;
            }

            $uploaded_images[] = 'uploads/img/' . $this->upload->data('file_name');
            $source = 'uploads/img/' . $this->upload->data('file_name');
            $this->session->set_userdata('images', $uploaded_images);
            pre($this->session->userdata('images'));
        } else {
            $this->output->set_status_header('404');
            print strip_tags($this->upload->display_errors());
            exit;
        }
    }

    public function add_image_two()
    {
        $uploaded_images = [];
        $config['upload_path'] = 'uploads/img/';
        $config['allowed_types'] = 'jpg|png|jpeg';
        $config['encrypt_name'] = TRUE;
        $this->load->library('Upload', $config);

        if ($this->upload->do_upload('file')) {
            $image_session = $this->session->userdata('images-two');
            if ($image_session == false) {
                $uploaded_images = [];
            } else {
                $uploaded_images = $image_session;
            }

            $uploaded_images[] = 'uploads/img/' . $this->upload->data('file_name');
            $source = 'uploads/img/' . $this->upload->data('file_name');
            $this->session->set_userdata('images-two', $uploaded_images);
            pre($this->session->userdata('images-two'));
        } else {
            $this->output->set_status_header('404');
            print strip_tags($this->upload->display_errors());
            exit;
        }
    }

    public function add_image_three()
    {
        $uploaded_images = [];
        $config['upload_path'] = 'uploads/img/';
        $config['allowed_types'] = 'jpg|png|jpeg';
        $config['encrypt_name'] = TRUE;
        $this->load->library('Upload', $config);

        if ($this->upload->do_upload('file')) {
            $image_session = $this->session->userdata('images-three');
            if ($image_session == false) {
                $uploaded_images = [];
            } else {
                $uploaded_images = $image_session;
            }

            $uploaded_images[] = 'uploads/img/' . $this->upload->data('file_name');
            $source = 'uploads/img/' . $this->upload->data('file_name');
            $this->session->set_userdata('images-three', $uploaded_images);
            pre($this->session->userdata('images-three'));
        } else {
            $this->output->set_status_header('404');
            print strip_tags($this->upload->display_errors());
            exit;
        }
    }

    public function add_image_four()
    {
        $uploaded_images = [];
        $config['upload_path'] = 'uploads/img/';
        $config['allowed_types'] = 'jpg|png|jpeg';
        $config['encrypt_name'] = TRUE;
        $this->load->library('Upload', $config);

        if ($this->upload->do_upload('file')) {
            $image_session = $this->session->userdata('images-four');
            if ($image_session == false) {
                $uploaded_images = [];
            } else {
                $uploaded_images = $image_session;
            }

            $uploaded_images[] = 'uploads/img/' . $this->upload->data('file_name');
            $source = 'uploads/img/' . $this->upload->data('file_name');
            $this->session->set_userdata('images-four', $uploaded_images);
            pre($this->session->userdata('images-four'));
        } else {
            $this->output->set_status_header('404');
            print strip_tags($this->upload->display_errors());
            exit;
        }
    }

    public function add_image_ilan()
    {
        $this->load->library('image_lib');

        $uploaded_images = [];
        $config['upload_path'] = 'uploads/img/';
        $config['allowed_types'] = 'jpg|png|jpeg';
        $config['encrypt_name'] = TRUE;
        $this->load->library('upload', $config);

        if (!$this->upload->do_upload('file')) {
            $this->output->set_status_header('404');
            print strip_tags($this->upload->display_errors());
            exit;
        } else {
            $image_data = $this->upload->data();

            /*if($image_data['image_width'] != 1200 && $image_data['image_height'] != 1800) {
                $this->output->set_status_header('404');
                print strip_tags('Yüklenen resim 1200x1800 ölçülerinde olmalıdır');
                exit;
            } else {*/
            $uploaded_image = 'uploads/img/' . $this->upload->data('file_name');
            $source = 'uploads/img/' . $this->upload->data('file_name');

            $this->load->library('image_lib');
            $this->load->library('upload', $config);
            if (!$this->upload->do_upload('file')) {
                $this->output->set_status_header('404');
                print strip_tags($this->upload->display_errors());
                exit;
            } else {
                $image_data_2 = $this->upload->data();
                $image_config_2 = array(
                    'image_library' => 'gd2',
                    'source_image' => $image_data_2['full_path'],
                    'maintain_ratio' => TRUE,
                    'width' => 300,
                    'height' => 200,
                );
                $this->image_lib->clear();
                $this->image_lib->initialize($image_config_2);
                $this->image_lib->resize();

                $uploaded_image_2 = 'uploads/img/' . $this->upload->data('file_name');
                $source = 'uploads/img/' . $this->upload->data('file_name');

                $data = ['image_path' =>$uploaded_image, 'thumbnail_image' =>$uploaded_image_2];
                $this->session->set_userdata('product_images', $data);
                pre($this->session->userdata('product_images'));
            }
            /*}*/
        }
    }

    public function add_gallery()
    {
        $uploaded_images = [];
        $config['upload_path'] = 'uploads/img/';
        $config['allowed_types'] = 'jpg|png|jpeg';
        $config['encrypt_name'] = TRUE;
        $this->load->library('upload', $config);

        if ($this->upload->do_upload('file')) {
            $image_session = $this->session->userdata('gallery');
            if ($image_session == false) {
                $uploaded_images = [];
            } else {
                $uploaded_images = $image_session;
            }

            $uploaded_images[] = $this->upload->data('file_name');
            $source = 'uploads/img/' . $this->upload->data('file_name');
            $this->session->set_userdata('gallery', $uploaded_images);
            pre($this->session->userdata('gallery'));
        } else {
            $this->output->set_status_header('404');
            print strip_tags($this->upload->display_errors());
            exit;
        }
    }

    public function add_product_file()
    {
        $uploaded_images = [];
        $config['upload_path'] = 'uploads/dosya/';
        $config['allowed_types'] = 'zip';
        $config['encrypt_name'] = TRUE;
        $this->load->library('upload', $config);

        if ($this->upload->do_upload('file')) {
            $image_session = $this->session->userdata('product_file');
            if ($image_session == false) {
                $uploaded_images = [];
            } else {
                $uploaded_images = $image_session;
            }

            $uploaded_images[] = 'uploads/dosya/' . $this->upload->data('file_name');
            $source = 'uploads/dosya/' . $this->upload->data('file_name');
            $this->session->set_userdata('product_file', $uploaded_images);
            pre($this->session->userdata('product_file'));
        } else {
            $this->output->set_status_header('404');
            print strip_tags($this->upload->display_errors());
            exit;
        }
    }
}
