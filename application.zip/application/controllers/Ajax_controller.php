<?php
defined('BASEPATH') or exit('No direct script access allowed');


class ajax_controller extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
    }

    public function il_ajax()
    {
        if ($this->input->post('il_id') == "") {
            echo '<option value="">Lütfen Şehir Seçiniz...</option>';
        } else {
            $ilceler = $this->magaza_model->ilceler(array('il_id' => $this->input->post('il_id')));
            foreach ($ilceler as $ilce) {
                echo '<option value="' . $ilce->id . '">' . $ilce->ilce_adi . '</option>';
            }
        }
    }

    public function il_ajax_hesap()
    {
        if ($this->input->post('il_id') == "") {
            echo '<option value="">Lütfen Şehir Seçiniz...</option>';
        } else {
            $ilceler = $this->magaza_model->ilceler(array('il_id' => $this->input->post('il_id')));

            foreach ($ilceler as $ilce) {
                if ($this->input->post('ilce_id') == $ilce->id) {
                    $selected = "selected";
                } else {
                    $selected = "";
                }
                echo '<option ' . $selected . ' value="' . $ilce->id . '">' . $ilce->ilce_adi . '</option>';
            }
        }
    }

    public function il_ajax2()
    {
        if ($this->input->post('il_id') == "") {
            echo '<option value="">Lütfen Şehir Seçiniz...</option>';
        } else {
            $ilceler = $this->magaza_model->ilceler(array('il_id' => $this->input->post('il_id')));
            foreach ($ilceler as $ilce) {
                $veri = '<option ';
                if ($this->input->post('firma_id') == $ilce->id) {
                    $veri .= "selected ";
                }
                $veri .= 'value="' . $ilce->id . '">' . $ilce->ilce_adi . '</option>';
                echo $veri;
            }
        }
    }

    public function sms_sablon()
    {
        $kullanici = kullanicicek();
        if ($this->input->post('sablon_id') == "") {
            echo 'Sms Şablonu Bulunamadı!';
        } else {
            $sablon = $this->sms_model->sms_sablon(array('sablon_id' => $this->input->post('sablon_id')));
            $mesaj = $this->findReplace($sablon->sablon_mesaj, 'baslik', $this->input->post('baslik'));
            $mesaj = $this->findReplace($mesaj, 'kullanici', $kullanici->kullanici_ad);
            echo $mesaj;
        }
    }

    public function smsGonder()
    {
        $kullanici = kullanicicek();
        if ($this->input->post('sablon_id') == "") {
            echo 'Sms Şablonu Bulunamadı!';
        } else {
            $sablon = $this->sms_model->sms_sablon(array('sablon_id' => $this->input->post('sablon_id')));
            $mesaj = $this->findReplace($sablon->sablon_mesaj, 'baslik', $this->input->post('baslik'));
            $mesaj = $this->findReplace($mesaj, 'kullanici', $kullanici->kullanici_ad);
            echo $mesaj;
        }
    }

    public function tel_dogrulama()
    {
        $data = new stdClass();

        $kullanici_id = $this->input->post('kullanici');
        $telefon = $this->input->post('telefon');
        $code = generateVerificationCode();
        $this->destek_model->kullaniciupdate(['kullanici_id' => $kullanici_id], ['kullanici_tel' => $telefon]);
        $info = kullanici_bilgi($kullanici_id);
        if (!empty($info)) {
            $gsm = $info->kullanici_tel;
            $mesaj = 'Herseyoyun.com Telefon Doğrulama Kodu:'.$code;
            if ($info->tel_dogrulama == 0) {
                $simdikiZaman = new DateTime();
                // Başka bir tarih oluştur
                $digertarih = new DateTime($info->tel_dogrulama_kod_tarih);
                // Farkı al
                $fark = $simdikiZaman->diff($digertarih);
                // Dakika cinsinden farkı hesapla
                $dakikaFarki = $fark->days * 24 * 60 + $fark->h * 60 + $fark->i;
                if ($dakikaFarki > 15) {
                    if ($this->smsSend($gsm, $mesaj)) {
                        $update_code = $this->home_model->update_dogrulama_kod($info->kullanici_id, $code);
                        $data->status = [
                            'status' => 'success',
                            'message' => 'Kod Başarılı Şekilde Gönderildi Lütfen Kontrol Ediniz!',
                            'alert_html' => '<div class="alert alert-success alert-dismissible text-left alert-grid" role="alert">
                                                <i class="fas fa-check"></i>
                                                <div><strong>Başarılı</strong><br>
                                                    Doğrulama Kodunuz Başarılı Şekilde Gönderilmiştir. Lütfen Aşağıda ki alana kodu giriniz.
                                                </div>
                                            </div>'
                        ];
                        print_r(json_encode($data));
                        die();
                    } else {
                        $data->status = [
                            'status' => 'error',
                            'message' => 'NETGSM Hatası...',
                            'alert_html' => '<div class="alert alert-danger alert-dismissible text-left alert-grid" role="alert">
                                                <i class="fas fa-times"></i>
                                                <div><strong>Hata !!</strong><br>
                                                    NETGSM Hatası...
                                                </div>
                                            </div>'
                        ];
                        print_r(json_encode($data));
                        die();
                    }
                } else {
                    $data->status = [
                        'status' => 'success',
                        'message' => 'Kod Başarılı Şekilde Gönderildi Lütfen Kontrol Ediniz!',
                        'alert_html' => '<div class="alert alert-success alert-dismissible text-left alert-grid" role="alert">
                                            <i class="fas fa-check"></i>
                                            <div><strong>Başarılı</strong><br>
                                                15 dakikanız henüz dolmadı lütfen doğrulama kodunu girin eğer doğrulama kodu gelmediyse tekrar gönderin!! 
                                            </div>
                                        </div>'
                    ];
                    print_r(json_encode($data));
                    die();
                }
            } else {
                $data->status = [
                    'status' => 'error',
                    'message' => 'Daha Önce Zaten Doğrulama İşlemi Gerçekleştirdiniz.',
                    'alert_html' => '<div class="alert alert-danger alert-dismissible text-left alert-grid" role="alert">
                                        <i class="fas fa-times"></i>
                                        <div><strong>Hata !!</strong><br>
                                            Daha Önce Zaten Doğrulama İşlemi Gerçekleştirdiniz.
                                        </div>
                                    </div>'
                ];
                print_r(json_encode($data));
                die();
            }
        } else {
            $data->status = [
                'status' => 'error',
                'message' => 'Geçersiz İşlem Yapıyorsunuz..',
                'alert_html' => '<div class="alert alert-danger alert-dismissible text-left alert-grid" role="alert">
                    <i class="fas fa-times"></i>
                    <div><strong>Hata !!</strong><br>
                        Geçersiz İşlem Yaptınız. Lütfen Sayfayı Yenileyip Tekrar Deneyiniz.
                    </div>
                </div>'
            ];
            print_r(json_encode($data));
            die();
        }
    }

    public function tel_dogrulama_resend()
    {
        $data = new stdClass();

        $kullanici_id = $this->input->post('kullanici');
        $code = generateVerificationCode();
        $info = kullanici_bilgi($kullanici_id);
        if (!empty($info)) {
            $gsm = $info->kullanici_tel;
            $mesaj = 'Herseyoyun.com Telefon Doğrulama Kodu:'.$code;
            if ($info->tel_dogrulama == 0) {
                    if ($this->smsSend($gsm, $mesaj)) {
                        $update_code = $this->home_model->update_dogrulama_kod($info->kullanici_id, $code);
                        $data->status = [
                            'status' => 'success',
                            'message' => 'Kod Başarılı Şekilde Gönderildi Lütfen Kontrol Ediniz!',
                            'alert_html' => '<div class="alert alert-success alert-dismissible text-left alert-grid" role="alert">
                                                <i class="fas fa-check"></i>
                                                <div><strong>Başarılı</strong><br>
                                                    Doğrulama Kodunuz Başarılı Şekilde Tekrar Gönderilmiştir. Lütfen Aşağıda ki alana kodu giriniz.
                                                </div>
                                            </div>'
                        ];
                        print_r(json_encode($data));
                        die();
                    } else {
                        $data->status = [
                            'status' => 'error',
                            'message' => 'NETGSM Hatası...',
                            'alert_html' => '<div class="alert alert-danger alert-dismissible text-left alert-grid" role="alert">
                                                <i class="fas fa-times"></i>
                                                <div><strong>Hata !!</strong><br>
                                                    NETGSM Hatası...
                                                </div>
                                            </div>'
                        ];
                        print_r(json_encode($data));
                        die();
                    }
            } else {
                $data->status = [
                    'status' => 'error',
                    'message' => 'Daha Önce Zaten Doğrulama İşlemi Gerçekleştirdiniz.',
                    'alert_html' => '<div class="alert alert-danger alert-dismissible text-left alert-grid" role="alert">
                                        <i class="fas fa-times"></i>
                                        <div><strong>Hata !!</strong><br>
                                            Daha Önce Zaten Doğrulama İşlemi Gerçekleştirdiniz.
                                        </div>
                                    </div>'
                ];
                print_r(json_encode($data));
                die();
            }
        } else {
            $data->status = [
                'status' => 'error',
                'message' => 'Geçersiz İşlem Yapıyorsunuz..',
                'alert_html' => '<div class="alert alert-danger alert-dismissible text-left alert-grid" role="alert">
                    <i class="fas fa-times"></i>
                    <div><strong>Hata !!</strong><br>
                        Geçersiz İşlem Yaptınız. Lütfen Sayfayı Yenileyip Tekrar Deneyiniz.
                    </div>
                </div>'
            ];
            print_r(json_encode($data));
            die();
        }
    }

    public function tel_kod_dogrulama()
    {
        $data = new stdClass();

        $kod = $this->input->post('code');
        $user_id = aktif_kullanici()->kullanici_id;

        if ($this->home_model->tel_code_control($kod, $user_id)) {
            $update_tel_dogrulama = $this->home_model->update_tel_dogrulama($user_id);
            $data->status = [
                'status' => 'success',
                'message' => 'Doğrulama İşlemi Başarılı Bir Şekilde Gerçekleştirildi.',
            ];
            print_r(json_encode($data));
            die();
        } else {
            $data->status = [
                'status' => 'error',
                'message' => 'Doğrulama Yaparken Bir Hata Meydana Lütfen Daha Sonra Tekrar Deneyiniz!!',
            ];
            print_r(json_encode($data));
            die();
        }
    }

    public function smsSend($gsm, $mesaj)
    {
        $ayarlar = ayarlar();
        $username = $ayarlar->netgsm_user;
        $pass = $ayarlar->netgsm_pass;
        $header = $ayarlar->netgsm_header;

        $startdate = date('d.m.Y H:i');
        $startdate = str_replace('.', '', $startdate);
        $startdate = str_replace(':', '', $startdate);
        $startdate = str_replace(' ', '', $startdate);

        $stopdate = date('d.m.Y H:i', strtotime('+1 day'));
        $stopdate = str_replace('.', '', $stopdate);
        $stopdate = str_replace(':', '', $stopdate);
        $stopdate = str_replace(' ', '', $stopdate);


        $msg = html_entity_decode($mesaj, ENT_COMPAT, "UTF-8");
        //$msg = rawurlencode($msg);


        $gonderici = html_entity_decode($header, ENT_COMPAT, "UTF-8");
        $gonderici = rawurlencode($gonderici);

        $curl = curl_init();


        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.netgsm.com.tr/sms/send/get',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('usercode' => $username, 'password' => $pass, 'gsmno' => $gsm, 'message' => $msg, 'msgheader' => $gonderici, 'filter' => '0', 'startdate' => $startdate, 'stopdate' => $stopdate, 'dil' => 'TR'),
        ));

        $response = curl_exec($curl);
        curl_close($curl);
        return $response;
    }

    public function sms_gonder()
    {
        $kullanici = kullanicicek();
        $data = new stdClass();
        $sablon_id = $this->input->post('sablon_id');

        if (!$kullanici) {
            $data->status = [
                'status' => 'error',
                'message' => 'Kullanıcı Bulunamadı. Lütfen Giriş Yapın!'
            ];
            print_r(json_encode($data));
            die();
        }
        if (!$sablon_id || $sablon_id == 0) {
            $data->status = [
                'status' => 'error',
                'message' => 'Lütfen Şablon Seçin!'
            ];
            print_r(json_encode($data));
            die();
        }

        $sablon = $this->sms_model->sms_sablon(array('sablon_id' => $this->input->post('sablon_id')));
        if (!$sablon) {
            $data->status = [
                'status' => 'error',
                'message' => 'Şablon Bulunamadı. Bir Şeyler Ters Gitti..'
            ];
            print_r(json_encode($data));
            die();
        }

        $urun = $this->magaza_model->urun(['urun_id' => $this->input->post('urun_id'), 'urun_durum' => 1]);
        if (!$urun) {
            $data->status = [
                'status' => 'error',
                'message' => 'Ürün Bilgisi Bulunamadı. Bir Şeyler Ters Gitti..'
            ];
            print_r(json_encode($data));
            die();
        }

        $bakiye = $kullanici->bakiye;
        $tutar = ayarlar()->sms_tutar;
        if (!$bakiye || $bakiye <= 0) {
            $data->status = [
                'status' => 'error',
                'message' => 'Bakiye Yetersiz! Lütfen Bakiye Yükleyin..'
            ];
            print_r(json_encode($data));
            die();
        } else {
            if ($tutar > $bakiye) {
                $data->status = [
                    'status' => 'error',
                    'message' => 'Bakiye Yetersiz! Lütfen Bakiye Yükleyin..'
                ];
                print_r(json_encode($data));
                die();
            }
        }

        $mesaj = $this->findReplace($sablon->sablon_mesaj, 'baslik', $urun->urun_ad);
        $mesaj = $this->findReplace($mesaj, 'kullanici', $kullanici->kullanici_ad);

        if (!$mesaj) {
            $data->status = [
                'status' => 'error',
                'message' => 'Mesaj Bulunamadı. Bir Şeyler Ters Gitti..'
            ];
            print_r(json_encode($data));
            die();
        }

        $alici = $this->destek_model->kullaniciget(['kullanici_id' => $urun->kullanici_id]);
        if (!$alici->kullanici_tel) {
            $data->status = [
                'status' => 'error',
                'message' => 'Mağaza Kullanıcısına Ait Telefon Numarası Bulunamadı!.'
            ];
            print_r(json_encode($data));
            die();
        }

        if ($alici->kullanici_id == $kullanici->kullanici_id) {
            $data->status = [
                'status' => 'error',
                'message' => 'Kendinize SMS gönderemezsiniz!'
            ];
            print_r(json_encode($data));
            die();
        }

        $mesaj = $this->smsSend($alici->kullanici_tel, $mesaj);

        if ($mesaj == '30') {
            $data->status = [
                'status' => 'error',
                'message' => 'NETGSM Geçersiz Kullanıcı Adı ve Şifre'
            ];
            print_r(json_encode($data));
            die();
        } elseif ($mesaj == '20') {
            $data->status = [
                'status' => 'error',
                'message' => 'NETGSM Gönderilen Mesaj Geçersizdir!'
            ];
            print_r(json_encode($data));
            die();
        } elseif ($mesaj == '40') {
            $data->status = [
                'status' => 'error',
                'message' => 'NETGSM Mesaj Başlığı Geçersizdir!'
            ];
            print_r(json_encode($data));
            die();
        } elseif ($mesaj == '50') {
            $data->status = [
                'status' => 'error',
                'message' => 'NETGSM Abone hesabınız ile İYS kontrollü gönderimler yapılamamaktadır.'
            ];
            print_r(json_encode($data));
            die();
        } elseif ($mesaj == '51') {
            $data->status = [
                'status' => 'error',
                'message' => 'NETGSM Aboneliğinize tanımlı İYS Marka bilgisi bulunamadı.'
            ];
            print_r(json_encode($data));
            die();
        } elseif ($mesaj == '70') {
            $data->status = [
                'status' => 'error',
                'message' => 'NETGSM Hatalı sorgulama. Gönderdiğiniz parametrelerden birisi hatalı veya zorunlu alanlardan birinin eksik.'
            ];
            print_r(json_encode($data));
            die();
        } elseif ($mesaj == '80') {
            $data->status = [
                'status' => 'error',
                'message' => 'NETGSM Gönderim sınır aşımı.'
            ];
            print_r(json_encode($data));
            die();
        } elseif ($mesaj == '85') {
            $data->status = [
                'status' => 'error',
                'message' => 'NETGSM Mükerrer Gönderim sınır aşımı. Aynı numaraya 1 dakika içerisinde 20`den fazla görev oluşturulamaz.'
            ];
            print_r(json_encode($data));
            die();
        } elseif ($mesaj == '100' || $mesaj == '101') {
            $data->status = [
                'status' => 'error',
                'message' => 'NETGSM Sistem hatası.'
            ];
            print_r(json_encode($data));
            die();
        }

        $bakiyeGuncel = $bakiye - $tutar;
        $this->destek_model->kullaniciupdate(['kullanici_id' => $kullanici->kullanici_id], ['bakiye' => $bakiyeGuncel]);

        $jsonData = [
            'sablon_id' => $sablon_id,
            'gonderen_id' => $kullanici->kullanici_id,
            'alici_id' => $urun->kullanici_id,
            'magaza_id' => $urun->magaza_id,
            'urun_id' => $urun->urun_id,
            'bakiye' => $bakiye,
            'tutar' => $tutar,
            'mesaj' => $mesaj
        ];
        $this->sms_model->sms_log_add(['sms_log_data' => json_encode($jsonData)]);

        $data->status = [
            'status' => 'success',
            'message' => 'Sms Gönderildi.'
        ];
        print_r(json_encode($data));
    }

    function findReplace($string, $find, $replace)
    {
        if (preg_match("/[a-zA-Z\_]+/", $find)) {
            return (string)preg_replace("/\{\{(\s+)?($find)(\s+)?\}\}/", $replace, $string);
        } else {
            throw new \Exception("Find statement must match regex pattern: /[a-zA-Z]+/");
        }
    }

    public function username_check()
    {
        if ($this->input->post('seo') == "") {
            $response['durum'] = 'error';
            $response['baslik'] = 'Hata';
            print_r(json_encode($response));
            die;
        }
        $firma = $this->magaza_model->magaza_username_check(array('magaza_seo' => $this->input->post('seo')));
        if ($firma) {
            $response['durum'] = 'error';
            $response['baslik'] = 'Hata';
            print_r(json_encode($response));
            die;
        } else {
            $response['durum'] = 'success';
            $response['baslik'] = 'Kullanılabilir';
            print_r(json_encode($response));
            die;
        }
    }

    public function magaza_olustur()
    {
        date_default_timezone_set('Europe/Istanbul');

        /**
         * Kullanıcı Giriş Kontrolü
         */
        if (!aktif_kullanici()) {
            $response['durum'] = 'error';
            $response['s_baslik'] = 'Lütfen Giriş Yapın!';
            $response['redirect'] = true;
            $response['redirect_url'] = 'giris-yap';
            print_r(json_encode($response));
            die;
        }

        /**
         * Mağaza Kontrolü / Varsa Yönlendirme İşlemi Yapsın.
         */
        if (magaza_check()) {
            $response['durum'] = 'error';
            $response['s_baslik'] = 'Hesabınıza Kayıtlı Mağaza Bulunmaktadır!';
            $response['redirect'] = true;
            $response['redirect_url'] = 'hesabim';
            print_r(json_encode($response));
            die;
        }

        /**
         * TC Kimlik Doğrulama İşlemi
         */
        $bilgiler = array(
            "isim" => yazi_boyut($this->input->post('ad'), 'u'),
            "soyisim" => yazi_boyut($this->input->post('soyad'), 'u'),
            "dogumyili" => $this->input->post('dogum_tarihi'),
            "tcno" => $this->input->post('tc')
        );

        $sonuc = tcno_dogrula($bilgiler);

        if ($sonuc != "true") {
            $response['durum'] = 'error';
            $response['s_baslik'] = 'TC Kimlik Doğrulaması Yapılamadı!';
            $response['redirect'] = false;
            print_r(json_encode($response));
            die;
        }

        /**
         * Mağaza Kullanıcı Adı Kontrol
         */
        $magaza_kullanici = $this->magaza_model->magaza_username_check(array('magaza_seo' => $this->input->post('magaza_seo')));
        if ($magaza_kullanici) {
            $response['durum'] = 'error';
            $response['s_baslik'] = 'Mağaza Kullanıcı Adı Zaten Var!';
            $response['redirect'] = false;
            print_r(json_encode($response));
            die;
        }

        /**
         * Mağaza TC Kontrol
         */
        $magaza_tc = $this->magaza_model->magaza_username_check(array('tc' => $this->input->post('tc')));
        if ($magaza_tc) {
            $response['durum'] = 'error';
            $response['s_baslik'] = 'Bu TC Kimlik Numarasına Ait Mağaza Bulunmaktadır!';
            $response['redirect'] = false;
            print_r(json_encode($response));
            die;
        }

        /**
         * Vergi Numarası Kontrol
         */
        if ($this->input->post('vergi_dairesi') && $this->input->post('vergi_numarasi')) {
            $magaza_vergi = $this->magaza_model->magaza_username_check(array('vergi_dairesi' => $this->input->post('vergi_dairesi'), 'vergi_numarasi' => $this->input->post('vergi_numarasi')));
            if ($magaza_vergi) {
                $response['durum'] = 'error';
                $response['s_baslik'] = 'Bu TC Kimlik Numarasına Ait Mağaza Bulunmaktadır!';
                $response['redirect'] = false;
                print_r(json_encode($response));
                die;
            }
        }

        /*
         * Kontorller
         */
        if (empty($this->input->post('magaza_ad'))) {
            $response['durum'] = 'error';
            $response['s_baslik'] = 'Mağaza Adı Kısmını Boş Bırakmayınız!';
            $response['redirect'] = false;
            print_r(json_encode($response));
            die;
        }
        if (empty($this->input->post('magazaseo'))) {
            $response['durum'] = 'error';
            $response['s_baslik'] = 'Mağaza Kullanıcı Adı Kısmını Boş Bırakmayınız!';
            $response['redirect'] = false;
            print_r(json_encode($response));
            die;
        }

        $rand_key = rand(99999, 9999999);
        curl_resim_kaydet("https://ui-avatars.com/api/?rounded=true&name=" . $this->input->post("magaza_ad") . "&color=fffff&rounded=true&bold=true&size=150&background=754ffc", 'uploads/magaza/' . $rand_key . '.jpg');

        $data = array(
            'magaza_ad' => $this->input->post('magaza_ad'),
            'magaza_seo' => seo($this->input->post('magaza_seo')),
            'isim' => yazi_boyut($this->input->post('ad'), 'u'),
            'soyisim' => yazi_boyut($this->input->post('soyad'), 'u'),
            'telefon' => $_SESSION['magazatel'],
            'tc' => $this->input->post('tc'),
            'dogum_tarihi' => $this->input->post('dogum_tarihi'),
            'firma_ad' => $this->input->post('firma_ad'),
            'vergi_dairesi' => $this->input->post('vergi_dairesi'),
            'vergi_numarasi' => $this->input->post('vergi_numarasi'),
            'magaza_tur' => $this->input->post('magaza_tur'),
            'sehir' => $this->input->post('sehir'),
            'ilce' => $this->input->post('ilce'),
            'fatura_adres' => $this->input->post('fatura_adres'),
            'magaza_hakkinda' => $this->input->post('magaza_bilgi'),
            'magaza_uniq' => uniqid(),
            'kullanici_id' => kullanicicek()->kullanici_id,
            'magaza_durum' => 0,
            'magaza_resim' => 'uploads/magaza/' . $rand_key . '.jpg'
        );


        /**
         * Data Insert İşlemi
         */
        $this->magaza_model->magaza_add($data);

        $response['durum'] = 'success';
        $response['s_baslik'] = 'Mağaza başvurunuz alınmıştır. En kısa zamanda dönüş yapılacaktır.';
        $response['redirect'] = true;
        $response['redirect_url'] = 'hesabim';
        print_r(json_encode($response));
    }

    public function magaza_basvuru_guncelle()
    {
        date_default_timezone_set('Europe/Istanbul');
        /**
         * Kullanıcı Giriş Kontrolü
         */
        if (!aktif_kullanici()) {
            $response['durum'] = 'error';
            $response['s_baslik'] = 'Lütfen Giriş Yapın!';
            $response['redirect'] = true;
            $response['redirect_url'] = 'giris-yap';
            print_r(json_encode($response));
            die;
        }

        /**
         * Mağaza Kontrolü / Varsa Yönlendirme İşlemi Yapsın.
         */
        if (magaza_check()) {
            $db_magaza = $this->magaza_model->magaza(array('kullanici_id' => kullanicicek()->kullanici_id));
            if ($db_magaza->magaza_durum == 1) {
                $response['durum'] = 'error';
                $response['s_baslik'] = 'Hesabınıza Kayıtlı Mağaza Bulunmaktadır!';
                $response['redirect'] = true;
                $response['redirect_url'] = 'hesabim';
                print_r(json_encode($response));
                die;
            } else if ($db_magaza->magaza_durum == 0) {
                $response['durum'] = 'error';
                $response['s_baslik'] = 'Mağaza Başvurunuz Zaten Alınmıştır! En Kısa Zamanda Dönüş Yapılacaktır.';
                $response['redirect'] = false;
                print_r(json_encode($response));
                die;
            }
        }

        /**
         * TC Kimlik Doğrulama İşlemi
         */
        $bilgiler = array(
            "isim" => yazi_boyut($this->input->post('ad'), 'u'),
            "soyisim" => yazi_boyut($this->input->post('soyad'), 'u'),
            "dogumyili" => $this->input->post('dogum_tarihi'),
            "tcno" => $this->input->post('tc')
        );

        $sonuc = tcno_dogrula($bilgiler);

        if ($sonuc != "true") {
            $response['durum'] = 'error';
            $response['s_baslik'] = 'TC Kimlik Doğrulaması Yapılamadı!';
            $response['redirect'] = false;
            print_r(json_encode($response));
            die;
        }

        /**
         * Mağaza Kullanıcı Adı Kontrol
         */
        $magaza_kullanici = $this->magaza_model->magaza_username_check(array('magaza_seo' => $this->input->post('magaza_seo'), 'kullanici_id !=' => kullanicicek()->kullanici_id));
        if ($magaza_kullanici) {
            $response['durum'] = 'error';
            $response['s_baslik'] = 'Mağaza Kullanıcı Adı Zaten Var!';
            $response['redirect'] = false;
            print_r(json_encode($response));
            die;
        }

        /**
         * Mağaza TC Kontrol
         */
        $magaza_tc = $this->magaza_model->magaza_username_check(array('tc' => $this->input->post('tc'), 'kullanici_id !=' => kullanicicek()->kullanici_id));
        if ($magaza_tc) {
            $response['durum'] = 'error';
            $response['s_baslik'] = 'Bu TC Kimlik Numarasına Ait Mağaza Bulunmaktadır!';
            $response['redirect'] = false;
            print_r(json_encode($response));
            die;
        }

        /**
         * Vergi Numarası Kontrol
         */
        if ($this->input->post('vergi_dairesi') && $this->input->post('vergi_numarasi')) {
            $magaza_vergi = $this->magaza_model->magaza_username_check(array('vergi_dairesi' => $this->input->post('vergi_dairesi'), 'vergi_numarasi' => $this->input->post('vergi_numarasi'), 'kullanici_id !=' => kullanicicek()->kullanici_id));
            if ($magaza_vergi) {
                $response['durum'] = 'error';
                $response['s_baslik'] = 'Bu TC Kimlik Numarasına Ait Mağaza Bulunmaktadır!';
                $response['redirect'] = false;
                print_r(json_encode($response));
                die;
            }
        }

        $rand_key = rand(99999, 9999999);
        curl_resim_kaydet("https://ui-avatars.com/api/?rounded=true&name=" . $this->input->post("magaza_ad") . "&color=fffff&rounded=true&bold=true&size=150&background=754ffc", 'uploads/magaza/' . $rand_key . '.jpg');

        $data = array(
            'magaza_ad' => $this->input->post('magaza_ad'),
            'magaza_seo' => seo($this->input->post('magaza_seo')),
            'isim' => yazi_boyut($this->input->post('ad'), 'u'),
            'soyisim' => yazi_boyut($this->input->post('soyad'), 'u'),
            'telefon' => $_SESSION['magazatel'],
            'tc' => $this->input->post('tc'),
            'dogum_tarihi' => $this->input->post('dogum_tarihi'),
            'firma_ad' => $this->input->post('firma_ad'),
            'vergi_dairesi' => $this->input->post('vergi_dairesi'),
            'vergi_numarasi' => $this->input->post('vergi_numarasi'),
            'magaza_tur' => $this->input->post('magaza_tur'),
            'sehir' => $this->input->post('sehir'),
            'ilce' => $this->input->post('ilce'),
            'fatura_adres' => $this->input->post('fatura_adres'),
            'magaza_hakkinda' => $this->input->post('magaza_bilgi'),
            'magaza_uniq' => uniqid(),
            'kullanici_id' => kullanicicek()->kullanici_id,
            'magaza_durum' => 0,
            'magaza_resim' => 'uploads/magaza/' . $rand_key . '.jpg'
        );


        /**
         * Data Insert İşlemi
         */
        $this->magaza_model->magaza_update(['kullanici_id' => kullanicicek()->kullanici_id] ,$data);

        $response['durum'] = 'success';
        $response['s_baslik'] = 'Mağaza başvurunuz güncellenmiştir. En kısa zamanda dönüş yapılacaktır.';
        $response['redirect'] = true;
        $response['redirect_url'] = 'hesabim';
        print_r(json_encode($response));
    }

    public function sponsor_olustur()
    {
        date_default_timezone_set('Europe/Istanbul');

        /**
         * Kullanıcı Giriş Kontrolü
         */
        if (!aktif_kullanici()) {
            $response['durum'] = 'error';
            $response['s_baslik'] = 'Lütfen Giriş Yapın!';
            $response['redirect'] = true;
            $response['redirect_url'] = 'giris-yap';
            print_r(json_encode($response));
            die;
        }

        /**
         * Mağaza Kontrolü / Varsa Yönlendirme İşlemi Yapsın.
         */
        if (sponsor_check()) {
            $response['durum'] = 'error';
            $response['s_baslik'] = 'Sponsor başvurunuz zaten bulunmakta!';
            $response['redirect'] = true;
            $response['redirect_url'] = 'hesabim';
            print_r(json_encode($response));
            die;
        }

        /**
         * TC Kimlik Doğrulama İşlemi
         */
        $bilgiler = array(
            "isim" => yazi_boyut($this->input->post('spo_ad'), 'u'),
            "soyisim" => yazi_boyut($this->input->post('spo_soyad'), 'u'),
            "dogumyili" => $this->input->post('spo_dogum_tarihi'),
            "tcno" => $this->input->post('spo_tc')
        );

        $sonuc = tcno_dogrula($bilgiler);

        if ($sonuc != "true") {
            $response['durum'] = 'error';
            $response['s_baslik'] = 'TC Kimlik Doğrulaması Yapılamadı!';
            $response['redirect'] = false;
            print_r(json_encode($response));
            die;
        }

        /**
         * Mağaza TC Kontrol
         */
        $magaza_tc = $this->magaza_model->magaza_username_check(array('tc' => $this->input->post('tc')));
        if ($magaza_tc) {
            $response['durum'] = 'error';
            $response['s_baslik'] = 'Bu TC Kimlik Numarasına Ait Mağaza Bulunmaktadır!';
            $response['redirect'] = false;
            print_r(json_encode($response));
            die;
        }

        $data = array(
            'isim' => yazi_boyut($this->input->post('spo_ad'), 'u'),
            'soyisim' => yazi_boyut($this->input->post('spo_soyad'), 'u'),
            'tc' => $this->input->post('spo_tc'),
            'dogum_tarihi' => $this->input->post('spo_dogum_tarihi'),
            'sehir' => $this->input->post('sehir'),
            'ilce' => $this->input->post('ilce'),
            'kats' => implode(', ', $this->input->post('kategoriler')),
            'kullanici_id' => kullanicicek()->kullanici_id,
        );

        /**
         * Data Insert İşlemi
         */
        $this->magaza_model->sponsor_add($data);

        $response['durum'] = 'success';
        $response['s_baslik'] = 'Sponsor başvurunuz alınmıştır. En kısa zamanda dönüş yapılacaktır.';
        $response['redirect'] = true;
        $response['redirect_url'] = 'hesabim';
        print_r(json_encode($response));
    }

    public function kategoriler()
    {
        $data = [];
        $parent_key = '0';
        $row = $this->db->query('SELECT kategori_id, kategori_ad from kategori');

        if ($row->num_rows() > 0) {
            $data = $this->membersTree($parent_key);
        } else {
            $data = ["id" => "0", "name" => "Kategori Bulunamadı", "text" => "Alt Kategori Bulunamadı", "nodes" => []];
        }

        echo json_encode(array_values($data));
    }

    public function membersTree($parent_key)
    {
        $row1 = [];
        $row = $this->db->query('SELECT kategori_id, kategori_ad, kategori_seo from kategori WHERE parent="' . $parent_key . '"')->result_array();

        foreach ($row as $key => $value) {
            $id = $value['kategori_id'];
            $row1[$key]['id'] = $value['kategori_id'];
            $row1[$key]['name'] = $value['kategori_ad'];
            $row1[$key]['text'] = $value['kategori_ad'];
            $row1[$key]['href'] = base_url('kategori/' . $value['kategori_seo']);
            $row1[$key]['nodes'] = array_values($this->membersTree($value['kategori_id']));
        }

        return $row1;
    }

    public function reklam_kontrol()
    {

        $onayli_reklam = $this->magaza_model->reklamlar(array('reklam_durum' => 1));

        if ($onayli_reklam) {
            foreach ($onayli_reklam as $oreklam) {
                if (gunHesapla($oreklam->reklam_bitis)) {
                    $this->magaza_model->reklam_delete(array('reklam_id' => $oreklam->reklam_id));

                    if ($oreklam->reklam_turu == 'anasayfa') {
                        $this->magaza_model->urun_update(array('urun_id' => $oreklam->urun_id), array('urun_populer' => 0));
                    } elseif ($oreklam->reklam_turu == 'kategori') {
                        $this->magaza_model->urun_update(array('urun_id' => $oreklam->urun_id), array('urun_populer_kat' => 0));
                    }
                }
            }
        }
    }

    public function siparis_kontrol()
    {

        $siparisler = $this->siparis_model->siparis_kontrol(array('siparis.siparis_durum' => 1));
        if ($siparisler) {
            foreach ($siparisler as $siparis) {

                $teslimat_kontrol = teslimat_kontrol2($siparis->siparis_no);

                if (!$teslimat_kontrol) {
                    $this->siparis_model->siparis_update(array('siparis_id' => $siparis->siparis_id), array('siparis_durum' => 2));
                }
            }
        }
    }

    public function ajax_search()
    {
        $search_type = $this->input->post('search_type', true);
        $input_value = $this->input->post('input_value', true);

        $data = array(
            'result' => 0,
            'response' => ''
        );

        if (!empty($search_type) && !empty($input_value)) {
            $data['result'] = 1;
            $response = '<div id="searchBoxPanel" class="searchBoxPanel">';
            $urunler = $this->destek_model->urunara($input_value);
            $response .= ' <div class="searchResultComp"><div class="row searchResultDiv" id="searchResultDiv" style="margin: 0;">';
            $categories = $this->destek_model->kategoriara($input_value);

            if(!empty($urunler)){
                $response .= '<div class="col-12 text-center search-result-title">
                                         Ürünler
                                      </div>';
                $response .= '<div class="flex-row-category">';
                foreach ($urunler as $key => $urun){
                    if($urun->admin == 1){
                        $kategori_id = json_decode($urun->kategori_json);
                        $kategori = $this->db->where('kategori_id', $kategori_id[0])->get('kategori')->result();

                        $response .= '<div class="col-6 col-lg-3 searchCategoryDiv" style="padding: 0 5px;">
                                      <div class="MidiSearchDiv">
                                        <a href="' . base_url('kategori/'.$kategori[0]->kategori_seo) . '"><img src="' . base_url($urun->urun_resim) . '" alt="Pr" style="max-height: 120px;"> ' . $urun->urun_ad . '</a>
                                      </div>
                                   </div>';

                    }

                }

                $response .= '<div class="col-12 text-center search-result-title">
                                         İlanlar
                                      </div>';
                $response .= '<div class="flex-row-product">';
                foreach ($urunler as $key => $urun) {
                    if($urun->admin != 1) {
                        if ($urun->urun_bitis_tarihi > date('Y-m-d H:i:s')) {
                            $response .= '<div class="col-12 col-lg-4" style="padding: 0 5px;">
                                            <div class="MiniSearchDiv">
                                            <a href="' . base_url($urun->urun_seo) . '"><img src="' . base_url($urun->urun_resim) . '" alt="Product"> ' . $urun->urun_ad . '</a>
                                          </div>
                                        </div>';
                        }
                    }

                }

                $response .= '<div class="col-12 text-center search-result-title"> Kategoriler </div>';
                $response .= '<div class="flex-row-category">';
                foreach ($categories as $key => $cat){

                    $response .= '    <div class="col-6 col-lg-3 searchCategoryDiv" style="padding: 0 5px;">
                                          <div class="MidiSearchDiv">
                                            <a href="' . base_url('kategoriler/'.$cat->kategori_seo) . '"><img src="' . base_url($cat->kategori_resim) . '" alt="Pr" style="max-height: 120px;"> ' . $cat->kategori_ad . '</a>
                                          </div>
                                   </div>';
                }
                $response .= '</div>';
                $response .='</div></div>';
                $response .= '</div>';
                end($urunler);
                if ($key != key($urunler)) {
                    $response .= '<hr>';
                }
            } else {
                $response .= '<div style="margin-top: 5px;" class="suggestions__group-title">Arama Sonucu</div>';
                $response .= '<div style="margin-bottom: 10px; width: 100%;" class="suggestions__group-content"><span class="suggestions__item suggestions__category">' . $input_value . '</span></div>';
            }
            $response .= '</div></div></div>';
            $data['response'] = $response;
        }
        echo json_encode($data);
    }

    public function soru_sor()
    {
        $data = new stdClass();

        $soru = $this->input->post('soru');
        $urun_id = $this->input->post('urun_id');
        $kullanici_id = $this->input->post('kullanici_id');
        if (empty($soru)) {
            $data->status = [
                'status' => 'error',
                'message' => 'Lütfen Soru Alanını Boş Bırakmayınız!!'
            ];
            print_r(json_encode($data));
            die();
        }
        if (empty($urun_id)) {
            $data->status = [
                'status' => 'error',
                'message' => 'Yapmaya Çalıştığınız İşlem Geçerli Değildir!'
            ];
            print_r(json_encode($data));
            die();
        }
        if (empty($kullanici_id)) {
            $data->status = [
                'status' => 'error',
                'message' => 'Yapmaya Çalıştığınız İşlem Geçerli Değildir!'
            ];
            print_r(json_encode($data));
            die();
        }

        $magaza = $this->db->from('urunler')->where(['urun_id' => $urun_id])->get()->row()->magaza_id;

        $this->db->set(['soru' => $soru, 'urun_id' => $urun_id, 'kullanici_id' => $kullanici_id, 'soru_durum' => 1, 'tarih' => date('Y-m-d H:i:s'), 'magaza_id' => $magaza])->insert('sorular');

        $data->status = [
            'status' => 'success',
            'message' => 'Sorunuz Satıcıya Başarılı Bir Şekilde Gönderilmiştir.!'
        ];
        print_r(json_encode($data));
        die();
    }

    public function soru_cevap()
    {
        $data = new stdClass();

        $cevap = $this->input->post('soru_id');
        $soru = $this->input->post('cevap');
        $tarih = date('Y-m-d H:i:s');
        $soru_durum = 1;

        if (empty($cevap)) {
            $data->status = [
                'status' => 'error',
                'message' => 'Yapmaya Çalıştığınız İşlem Geçerli Değildir!'
            ];
            print_r(json_encode($data));
            die();
        }
        if (empty($soru)) {
            $data->status = [
                'status' => 'error',
                'message' => 'Lütfen Cevap Alanını Boş Bırakmayınız!!'
            ];
            print_r(json_encode($data));
            die();
        }
        if (!$this->home_model->control_soru($cevap)) {
            $data->status = [
                'status' => 'error',
                'message' => 'Yapmaya Çalıştığınız İşlem Geçerli Değildir!'
            ];
            print_r(json_encode($data));
            die();
        }

        $this->db->set(['soru' => $soru, 'soru_durum' => $soru_durum, 'tarih' => $tarih, 'cevap' => $cevap])->insert('sorular');

        $data->status = [
            'status' => 'success',
            'message' => 'Cevabınız Başarılı Bir Şekilde Kayıt Edilmiştir.'
        ];
        print_r(json_encode($data));
        die();
    }

    public function sohbet_add_mesaj()
    {
        $data = new stdClass();

        $username = $this->input->post('username');
        $mesaj = $this->input->post('mesaj');
        $kullanici_id = $this->input->post('kullanici_id');
        $tarih = date('Y-m-d H:i:s');

        if (!$db_kullanici = $this->mesaj_model->control_username($username)) {
            $data->status = [
                'status' => 'error',
                'message' => 'Böyle Bir Kullanıcı Bulunamadı Lütfen Kontrol Ediniz!'
            ];
            print_r(json_encode($data));
            die();
        }
        if ($db_kullanici->kullanici_id == $kullanici_id) {
            $alert = array(
                'status' => 'error',
                "text" => "Kendinize mesaj gönderemezsiniz!"
            );
            print_r(json_encode($data));
            die();
        }

        $add_data = [
            'alan_id' => $db_kullanici->kullanici_id,
            'gonderen_id' => $kullanici_id,
            'tarih' => $tarih,
            'uniq' => uniqid()
        ];

        if ($amesaj_id = $this->mesaj_model->add_amesaj_new($add_data)) {
            $mesaj_data = [
                'amesaj_id' => $amesaj_id,
                'alan_id' => $db_kullanici->kullanici_id,
                'gonderen_id' => $kullanici_id,
                'mesaj' => $mesaj,
                'tarih' => $tarih,
                'okunma' => 1,
                'uniq' => $add_data['uniq']
            ];
            if ($this->mesaj_model->mesaj_add($mesaj_data)) {
                $siteayar = ayarlar();
                mailGonder($db_kullanici->kullanici_mail, 'Bir Yeni Mesajınız Var! 🔔', '<style>
						/* Reset styles */ 
						body { margin: 0; padding: 0; min-width: 100%; width: 100% !important; height: 100% !important;}
						body, table, td, div, p, a { -webkit-font-smoothing: antialiased; text-size-adjust: 100%; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; line-height: 100%; }
						table, td { mso-table-lspace: 0pt; mso-table-rspace: 0pt; border-collapse: collapse !important; border-spacing: 0; }
						img { border: 0; line-height: 100%; outline: none; text-decoration: none; -ms-interpolation-mode: bicubic; }
         							#outlook a { padding: 0; }
						.ReadMsgBody { width: 100%; } .ExternalClass { width: 100%; }
						.ExternalClass, .ExternalClass p, .ExternalClass span, .ExternalClass font, .ExternalClass td, .ExternalClass div { line-height: 100%; }
						/* Rounded corners for advanced mail clients only */ 
						@media all and (min-width: 560px) {
							.container { border-radius: 8px; -webkit-border-radius: 8px; -moz-border-radius: 8px; -khtml-border-radius: 8px;}
						}
						/* Set color for auto links (addresses, dates, etc.) */ 
						a, a:hover {
							color: #127DB3;
						}
						.footer a, .footer a:hover {
							color: #999999;
						}
						</style>

						<body topmargin="0" rightmargin="0" bottommargin="0" leftmargin="0" marginwidth="0" marginheight="0" width="100%" style="border-collapse: collapse; border-spacing: 0; margin: 0; padding: 0; width: 100%; height: 100%; -webkit-font-smoothing: antialiased; text-size-adjust: 100%; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; line-height: 100%;
						background-color: #F0F0F0;
						color: #000000;"
						bgcolor="#F0F0F0"
						text="#000000">
						<!-- SECTION / BACKGROUND -->
						<!-- Set message background color one again -->
						<table width="100%" align="center" border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse; border-spacing: 0; margin: 0; padding: 0; width: 100%;" class="background">
						<tr>
						<td align="center" valign="top" style="border-collapse: collapse; border-spacing: 0; margin: 0; padding: 0;"
						bgcolor="#F0F0F0">
						<!-- WRAPPER -->
						<!-- Set wrapper width (twice) -->
						<table border="0" cellpadding="0" cellspacing="0" align="center"
						width="560" style="border-collapse: collapse; border-spacing: 0; padding: 0; width: inherit;
						max-width: 560px;" class="wrapper">
						<tr>
						<td align="center" valign="top" style="border-collapse: collapse; border-spacing: 0; margin: 0; padding: 0; padding-left: 6.25%; padding-right: 6.25%; width: 87.5%;
						padding-top: 20px;
						padding-bottom: 20px;">

						<a target="_blank" style="text-decoration: none;"
						href="' . base_url() . '"><img border="0" vspace="0" hspace="0"
						src="' . base_url($siteayar->site_logo) . '"
						width="100"
						alt="Logo" title="Yeni bir mesajınız var" style="
						color: #000000;
						font-size: 10px; margin: 0; padding: 0; outline: none; text-decoration: none; -ms-interpolation-mode: bicubic; border: none; display: block;" /></a>
						</td>
						</tr>
						<!-- End of WRAPPER -->
						</table>
						<!-- WRAPPER / CONTEINER -->
						<!-- Set conteiner background color -->
						<table border="0" cellpadding="0" cellspacing="0" align="center"
						bgcolor="#FFFFFF"
						width="560" style="border-collapse: collapse; border-spacing: 0; padding: 0; width: inherit;
						max-width: 560px;" class="container">
						<!-- HEADER -->
						<!-- Set text color and font family ("sans-serif" or "Georgia, serif") -->
						<tr>
						<td align="center" valign="top" style="border-collapse: collapse; border-spacing: 0; margin: 0; padding: 0; padding-left: 6.25%; padding-right: 6.25%; width: 87.5%; font-size: 24px; font-weight: bold; line-height: 130%;
						padding-top: 25px;
						color: #000000;
						font-family: sans-serif;" class="header">Yeni Mesajınız Var!</td>
						</tr>

						<tr>
						<td align="center" valign="top" style="border-collapse: collapse; border-spacing: 0; margin: 0; padding: 0; padding-left: 6.25%; padding-right: 6.25%; width: 87.5%; font-size: 17px; font-weight: 400; line-height: 160%;
						padding-top: 25px; 
						color: #000000;
						font-family: sans-serif;" class="paragraph">Bu Mesaj ' . base_url() . ' Gönderilmiştir.</td>
						</tr>

						<tr>
						<td align="center" valign="top" style="border-collapse: collapse; border-spacing: 0; margin: 0; padding: 0; padding-left: 6.25%; padding-right: 6.25%; width: 87.5%; font-size: 17px; font-weight: 400; line-height: 160%;
						padding-top: 25px; 
						color: #000000;
						font-family: sans-serif;" class="paragraph"> Yeni Mesajınız : <br> ' . $this->input->post('mesaj') . ' <br>
						</td>
						</tr>

						<tr>
						<td align="center" valign="top" style="border-collapse: collapse; border-spacing: 0; margin: 0; padding: 0; padding-left: 6.25%; padding-right: 6.25%; width: 87.5%;
						padding-top: 25px;
						padding-bottom: 5px;" class="button">
						<a
						href="#adres" target="_blank" style="text-decoration: underline;">
						<table border="0" cellpadding="0" cellspacing="0" align="center" style="max-width: 240px; min-width: 120px; border-collapse: collapse; border-spacing: 0; padding: 0;">
						</table></a>
						</td>
						</tr>
						<!-- LINE -->
						<!-- Set line color -->
						<tr>
						<td align="center" valign="top" style="border-collapse: collapse; border-spacing: 0; margin: 0; padding: 0; padding-left: 6.25%; padding-right: 6.25%; width: 87.5%;
						padding-top: 25px;" class="line">
						<hr
						color="#E0E0E0" align="center" width="100%" size="1" noshade style="margin: 0; padding: 0;" />
						</td>
						</tr>

						<tr>
						<td align="center" valign="top" style="border-collapse: collapse; border-spacing: 0; margin: 0; padding: 0; padding-left: 6.25%; padding-right: 6.25%; width: 87.5%;
						padding-top: 25px;" class="line">
						<hr
						color="#E0E0E0" align="center" width="100%" size="1" noshade style="margin: 0; padding: 0;" />
						</td>
						</tr>
						</table>
						<!-- WRAPPER -->
						<!-- Set wrapper width (twice) -->
						<table border="0" cellpadding="0" cellspacing="0" align="center"
						width="560" style="border-collapse: collapse; border-spacing: 0; padding: 0; width: inherit;
						max-width: 560px;" class="wrapper">
						</tr>
						<!-- End of WRAPPER -->
						</table>
						<!-- End of SECTION / BACKGROUND -->
						</td>
						</tr>
						</table>
						</body>');

                $data->status = array(
                    "status" => "success",
                    "message" => "Mesajınız başarılı şekilde gönderildi!",
                );
                print_r(json_encode($data));
                die();
            } else {
                $data->status = [
                    'status' => 'error',
                    'message' => 'Mesaj Gönderilirken Bir Hata Meydana Geldi Lütfen Daha Sonra Tekrar Deneyiniz!'
                ];
                print_r(json_encode($data));
                die();
            }
        } else {
            $data->status = [
                'status' => 'error',
                'message' => 'Mesaj Gönderilirken Bir Hata Meydana Geldi Lütfen Daha Sonra Tekrar Deneyiniz!'
            ];
            print_r(json_encode($data));
            die();
        }
    }

    public function sohbet_getir()
    {
        $data = new stdClass();

        $uniq = $this->input->post('uniq');
        $kullanici_id = $this->input->post('kullanici_id');
        $kullanici = kullanicicek();

        if ($mesajlar = $this->mesaj_model->mesajResult(['uniq' => $uniq])) {
            $html = '';
            foreach ($mesajlar as $key => $val) {
                if ($val->gonderen_id == $kullanici->kullanici_id) {
                    $gonderen_kullanici = kullanici_bilgi($val->gonderen_id);
                    if (strpos($gonderen_kullanici->kullanici_resim, "/.jpg") !== false) {
                        $pp_gonderen = 'https://ui-avatars.com/api/?name='. $gonderen_kullanici->kullanici_isim .'+'. $gonderen_kullanici->kullanici_soyisim .'&background=0D8ABC&color=fff';
                    } else {
                        $pp_gonderen = base_url($gonderen_kullanici->kullanici_resim);
                    }
                    $html .= '<div class="mm-chat mm-own">
                                  <div class="mm-chat-bar">
                                      <div class="mmc-text">'.$val->mesaj.'
                                          <div class="mmc-date">'.$val->tarih.'</div>
                                      </div>              
                                      <div class="mmc-date">
                                          <div class="circle-chat ml-2">
                                              <span class="user-img-chat">
                                                <img src="'. $pp_gonderen .'">
                                              </span>
                                              <span class="user-chat-name">'.$gonderen_kullanici->kullanici_ad.'</span>
                                          </div>
                                      </div>
                                  </div>
                              </div>
                    ';
                } else {
                    $alan_kullanici = $this->mesaj_model->get_kullanici_bilgi($val->gonderen_id);
                    if (strpos($alan_kullanici->kullanici_resim, "/.jpg") !== false) {
                        $pp = 'https://ui-avatars.com/api/?name='. $alan_kullanici->kullanici_isim .'+'. $alan_kullanici->kullanici_soyisim .'&background=0D8ABC&color=fff';
                    } else {
                        $pp = base_url($alan_kullanici->kullanici_resim);
                    }
                    $html .= '<div class="mm-chat mm-you">
                                  <div class="mm-chat-bar">
                                      <div class="mmc-date">
                                          <div class="circle-chat mr-2">
                                              <span class="user-img-chat">
                                                <img src="'. $pp .'">
                                              </span>
                                              <span class="user-chat-name">'.$alan_kullanici->kullanici_ad.'</span>
                                          </div>
                                      </div>
                                       <div class="mmc-text">'.$val->mesaj.'
                                          <div class="mmc-date">'.$val->tarih.'</div>
                                      </div>    
                                  </div>
                              </div>
                    ';
                }
            }
            $data->status = "success";
            $data->html = $html;
            /*$data->status = [
                'status' => 'success',
                'html' => $html
            ];*/
            print_r(json_encode($data));
            die();
        } else {
            $data->status = [
                'status' => 'error',
                'message' => 'Beklenmedik Bir Hata Meydana Geldi Lütfen Daha Sonra Tekrar Deneyiniz!'
            ];
            print_r(json_encode($data));
            die();
        }
    }

    public function send_re_message()
    {
        $data = new stdClass();

        $uniq = $this->input->post('uniq');
        $message = $this->input->post('message');
        //$kullanici = $this->input->post('kullanici_id');
        $kullanici = kullanicicek();

        if (!$message) {
            $data->status = "error";
            $data->message = "Lütfen Mesaj Alanını Boş Bırakmayınız!";
            print_r(json_encode($data));
            die();
        }

        $mesaj = $this->mesaj_model->amesajRow(array('uniq' => $uniq));

        if (!$mesaj) {
            $data->status = "error";
            $data->message = "Yaptığınız İşlem Geçersizdir!";
            print_r(json_encode($data));
            die();
        }

        if ($kullanici->kullanici_id == $mesaj->gonderen_id) {
            $alan_id = $mesaj->alan_id;
        } else {
            $alan_id = $mesaj->gonderen_id;
        }

        $data_mesaj = array(
            'amesaj_id' => $mesaj->id,
            'alan_id' => $alan_id,
            'gonderen_id' => $kullanici->kullanici_id,
            'mesaj' => $message,
            'okunma' => 1,
            'uniq' => $uniq
        );

        $this->mesaj_model->mesaj_add($data_mesaj);

        $kullanici_bilgi = kullanici_bilgi($alan_id);
        $siteayar = ayarlar();
        if (1 == 2) {
        mailGonder($kullanici_bilgi->kullanici_mail, 'Bir Yeni Mesajınız Var! 🔔', '<style>
						/* Reset styles */ 
						body { margin: 0; padding: 0; min-width: 100%; width: 100% !important; height: 100% !important;}
						body, table, td, div, p, a { -webkit-font-smoothing: antialiased; text-size-adjust: 100%; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; line-height: 100%; }
						table, td { mso-table-lspace: 0pt; mso-table-rspace: 0pt; border-collapse: collapse !important; border-spacing: 0; }
						img { border: 0; line-height: 100%; outline: none; text-decoration: none; -ms-interpolation-mode: bicubic; }
         							#outlook a { padding: 0; }
						.ReadMsgBody { width: 100%; } .ExternalClass { width: 100%; }
						.ExternalClass, .ExternalClass p, .ExternalClass span, .ExternalClass font, .ExternalClass td, .ExternalClass div { line-height: 100%; }
						/* Rounded corners for advanced mail clients only */ 
						@media all and (min-width: 560px) {
							.container { border-radius: 8px; -webkit-border-radius: 8px; -moz-border-radius: 8px; -khtml-border-radius: 8px;}
						}
						/* Set color for auto links (addresses, dates, etc.) */ 
						a, a:hover {
							color: #127DB3;
						}
						.footer a, .footer a:hover {
							color: #999999;
						}
						</style>

						<body topmargin="0" rightmargin="0" bottommargin="0" leftmargin="0" marginwidth="0" marginheight="0" width="100%" style="border-collapse: collapse; border-spacing: 0; margin: 0; padding: 0; width: 100%; height: 100%; -webkit-font-smoothing: antialiased; text-size-adjust: 100%; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; line-height: 100%;
						background-color: #F0F0F0;
						color: #000000;"
						bgcolor="#F0F0F0"
						text="#000000">
						<!-- SECTION / BACKGROUND -->
						<!-- Set message background color one again -->
						<table width="100%" align="center" border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse; border-spacing: 0; margin: 0; padding: 0; width: 100%;" class="background">
						<tr>
						<td align="center" valign="top" style="border-collapse: collapse; border-spacing: 0; margin: 0; padding: 0;"
						bgcolor="#F0F0F0">
						<!-- WRAPPER -->
						<!-- Set wrapper width (twice) -->
						<table border="0" cellpadding="0" cellspacing="0" align="center"
						width="560" style="border-collapse: collapse; border-spacing: 0; padding: 0; width: inherit;
						max-width: 560px;" class="wrapper">
						<tr>
						<td align="center" valign="top" style="border-collapse: collapse; border-spacing: 0; margin: 0; padding: 0; padding-left: 6.25%; padding-right: 6.25%; width: 87.5%;
						padding-top: 20px;
						padding-bottom: 20px;">

						<a target="_blank" style="text-decoration: none;"
						href="' . base_url() . '"><img border="0" vspace="0" hspace="0"
						src="' . base_url($siteayar->site_logo) . '"
						width="100"
						alt="Logo" title="Yeni bir mesajınız var" style="
						color: #000000;
						font-size: 10px; margin: 0; padding: 0; outline: none; text-decoration: none; -ms-interpolation-mode: bicubic; border: none; display: block;" /></a>
						</td>
						</tr>
						<!-- End of WRAPPER -->
						</table>
						<!-- WRAPPER / CONTEINER -->
						<!-- Set conteiner background color -->
						<table border="0" cellpadding="0" cellspacing="0" align="center"
						bgcolor="#FFFFFF"
						width="560" style="border-collapse: collapse; border-spacing: 0; padding: 0; width: inherit;
						max-width: 560px;" class="container">
						<!-- HEADER -->
						<!-- Set text color and font family ("sans-serif" or "Georgia, serif") -->
						<tr>
						<td align="center" valign="top" style="border-collapse: collapse; border-spacing: 0; margin: 0; padding: 0; padding-left: 6.25%; padding-right: 6.25%; width: 87.5%; font-size: 24px; font-weight: bold; line-height: 130%;
						padding-top: 25px;
						color: #000000;
						font-family: sans-serif;" class="header">Yeni Mesajınız Var!</td>
						</tr>

						<tr>
						<td align="center" valign="top" style="border-collapse: collapse; border-spacing: 0; margin: 0; padding: 0; padding-left: 6.25%; padding-right: 6.25%; width: 87.5%; font-size: 17px; font-weight: 400; line-height: 160%;
						padding-top: 25px; 
						color: #000000;
						font-family: sans-serif;" class="paragraph">Bu Mesaj ' . base_url() . ' Gönderilmiştir.</td>
						</tr>

						<tr>
						<td align="center" valign="top" style="border-collapse: collapse; border-spacing: 0; margin: 0; padding: 0; padding-left: 6.25%; padding-right: 6.25%; width: 87.5%; font-size: 17px; font-weight: 400; line-height: 160%;
						padding-top: 25px; 
						color: #000000;
						font-family: sans-serif;" class="paragraph"> Yeni Mesajınız : <br> ' . $this->input->post('message') . ' <br>
						</td>
						</tr>

						<tr>
						<td align="center" valign="top" style="border-collapse: collapse; border-spacing: 0; margin: 0; padding: 0; padding-left: 6.25%; padding-right: 6.25%; width: 87.5%;
						padding-top: 25px;
						padding-bottom: 5px;" class="button">
						<a
						href="#adres" target="_blank" style="text-decoration: underline;">
						<table border="0" cellpadding="0" cellspacing="0" align="center" style="max-width: 240px; min-width: 120px; border-collapse: collapse; border-spacing: 0; padding: 0;">
						</table></a>
						</td>
						</tr>
						<!-- LINE -->
						<!-- Set line color -->
						<tr>
						<td align="center" valign="top" style="border-collapse: collapse; border-spacing: 0; margin: 0; padding: 0; padding-left: 6.25%; padding-right: 6.25%; width: 87.5%;
						padding-top: 25px;" class="line">
						<hr
						color="#E0E0E0" align="center" width="100%" size="1" noshade style="margin: 0; padding: 0;" />
						</td>
						</tr>

						<tr>
						<td align="center" valign="top" style="border-collapse: collapse; border-spacing: 0; margin: 0; padding: 0; padding-left: 6.25%; padding-right: 6.25%; width: 87.5%;
						padding-top: 25px;" class="line">
						<hr
						color="#E0E0E0" align="center" width="100%" size="1" noshade style="margin: 0; padding: 0;" />
						</td>
						</tr>
						</table>
						<!-- WRAPPER -->
						<!-- Set wrapper width (twice) -->
						<table border="0" cellpadding="0" cellspacing="0" align="center"
						width="560" style="border-collapse: collapse; border-spacing: 0; padding: 0; width: inherit;
						max-width: 560px;" class="wrapper">
						</tr>
						<!-- End of WRAPPER -->
						</table>
						<!-- End of SECTION / BACKGROUND -->
						</td>
						</tr>
						</table>
						</body>');
        }

        $html = '';

        if (strpos($kullanici->kullanici_resim, "/.jpg") !== false) {
            $pp_gonderen = 'https://ui-avatars.com/api/?name='. $kullanici->kullanici_isim .'+'. $kullanici->kullanici_soyisim .'&background=0D8ABC&color=fff';
        } else {
            $pp_gonderen = base_url($kullanici->kullanici_resim);
        }
        $html .= '<div class="mm-chat mm-own">
                                  <div class="mm-chat-bar">
                                      <div class="mmc-text">'.$message.'
                                          <div class="mmc-date">'.date('Y-m-d H:i:s').'</div>
                                      </div>              
                                      <div class="mmc-date">
                                          <div class="circle-chat ml-2">
                                              <span class="user-img-chat">
                                                <img src="'. $pp_gonderen .'">
                                              </span>
                                              <span class="user-chat-name">'.$kullanici->kullanici_ad.'</span>
                                          </div>
                                      </div>
                                  </div>
                              </div>
                    ';

        $data->status = "success";
        $data->html = $html;
        /*$data->status = array(
            "status" => "success",
            "message" => "Mesajınız başarılı şekilde gönderildi!",
        );*/
        print_r(json_encode($data));
        die();
    }
}
