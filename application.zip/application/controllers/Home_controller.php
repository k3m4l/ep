<?php

use Anilken\Turkpin\Turkpin;

defined('BASEPATH') or exit('No direct script access allowed');

class home_controller extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->helper('security');
        $this->load->helper('url');
        $this->load->library("pagination");
    }

    public function bakiye_odeme_onay_weepay()
    {
        $name = rand();
        if ($_POST['paymentStatus'] == true) {
            require_once('application/libraries/weepay/weepayBootstrap.php');
            weepayBootstrap::initialize();
            $options = new \weepay\Auth();
            $ayarlar = ayarlar();
            $options->setBayiID($ayarlar->weepay_bayiId);
            $options->setApiKey($ayarlar->weepay_api);
            $options->setSecretKey($ayarlar->weepay_secret);
            $options->setBaseUrl("https://api.weepay.co/");
            $request = new \weepay\Request\GetPaymentRequest();
            $request->setPaymentId($_POST['paymentId']);
            $request->setLocale(\weepay\Model\Locale::TR);
            $getPaymentRequest = \weepay\Model\GetPaymentRequestInitialize::create($request, $options);
            $siparis = $this->bakiye_model->bakiye(array('bakiye.bakiye_no' => $getPaymentRequest->getOrderId()));
            $kullanici_id = $siparis->kullanici_id;
            $kullanici = $this->yonetim_model->get(['kullanici_id' => $kullanici_id]);
            $this->session->set_userdata("aktifkullanici", $kullanici);
            $_SESSION["aktifkullanici"] = $kullanici;
            if (!$siparis) {
                $alert = array(
                    "title" => "Hata!",
                    "text" => "Sipariş bulunamadı, bir hata oluştu.",
                    "type" => "error"
                );
                $this->session->set_flashdata("alert", $alert);
                redirect(base_url('giris-yap'));
                die();
            }
            if ($getPaymentRequest->getStatus() == 'success') {
                if ($getPaymentRequest->getPaymentStatus() == 'SUCCESS') {
                    $this->bakiye_model->bakiye_update(array('bakiye_no' => $getPaymentRequest->getOrderId(), 'kullanici_id' => $kullanici_id), array('bakiye_durum' => '1', 'odeme_tur' => 'WeePay'));

                    $tutar = $siparis->bakiye_tutar;
                    $bakiye = $kullanici->bakiye;
                    $this->destek_model->kullaniciupdate(
                        array("kullanici_id" => $kullanici_id),
                        array(
                            "bakiye" => $bakiye + $tutar
                        )
                    );

                    $alert = array(
                        "title" => "Başarılı!",
                        "text" => "Ödemeniz Yapılmıştır..",
                        "type" => "success"
                    );
                    $this->session->set_flashdata("alert", $alert);
                    redirect(base_url('bakiye'));
                    die();
                }
            }
        }
        $alert = array(
            "title" => "Hata!",
            "text" => "Ödeme alınamadı, bir hata oluştu.",
            "type" => "error"
        );
        $data['status'] = 'Ödeme alınamadı, bir hata oluştu.';
        $this->session->set_flashdata("alert", $alert);
        redirect(base_url('bakiye'));
        die();
    }

    public function bakiye_odeme_onay_vallet()
    {
        $ayarlar = ayarlar();
        $vallet_config = array(
            'userName' => $ayarlar->vallet_usernmae,
            'password' => $ayarlar->vallet_password,
            'shopCode' => $ayarlar->vallet_shopCode,
            'hash' => $ayarlar->vallet_hash,
        );
        $post = array();
        $post['status'] = $_POST['status'];
        $post['paymentStatus'] = $_POST['paymentStatus'];
        $post['hash'] = $_POST['hash'];
        $post['paymentCurrency'] = $_POST['paymentCurrency'];
        $post['paymentAmount'] = $_POST['paymentAmount'];
        $post['paymentType'] = $_POST['paymentType'];
        $post['paymentTime'] = $_POST['paymentTime'];
        $post['conversationId'] = $_POST['conversationId'];
        $post['orderId'] = $_POST['orderId'];
        $post['shopCode'] = $_POST['shopCode'];
        $post['orderPrice'] = $_POST['orderPrice'];
        $post['productsTotalPrice'] = $_POST['productsTotalPrice'];
        $post['productType'] = $_POST['productType'];
        $post['callbackOkUrl'] = $_POST['callbackOkUrl'];
        $post['callbackFailUrl'] = $_POST['callbackFailUrl'];


        if (empty($post['status']) || empty($post['paymentStatus']) || empty($post['hash']) || empty($post['paymentCurrency']) || empty($post['paymentAmount']) || empty($post['paymentType']) || empty($post['orderId']) || empty($post['shopCode']) || empty($post['orderPrice']) || empty($post['productsTotalPrice']) || empty($post['productType']) || empty($post['callbackOkUrl']) || empty($post['callbackFailUrl'])) {
            /*Eksik Form Datası Mevcut*/
            echo 'EKSIK_FORM_DATASI';
            exit();
        } else {
            $hash_string = $post['orderId'] . $post['paymentCurrency'] . $post['orderPrice'] . $post['productsTotalPrice'] . $post['productType'] . $vallet_config["shopCode"] . $vallet_config["hash"];
            $MY_HASH = base64_encode(pack('H*', sha1($hash_string)));
            if ($MY_HASH !== $post['hash']) {
                /*Hash Uyuşmuyor*/
                echo 'HATALI_HASH_IMZASI';
                exit();
            } else {
                if ($post['paymentStatus'] == 'paymentOk') {
                    $payment = $this->bakiye_model->bakiye(array('bakiye.bakiye_no' => $post['orderId']));
                    /*Sipariş bilginizi sisteminizden çekin ve doğrulayın*/
                    if (!$payment) {
                        /*Böyle bir sipariş sistemimde yok*/
                        echo 'GECERSIZ_SIPARIS_NUMARASI';
                        exit();
                    } else if ($payment->bakiye_durum == 1) {
                        /*Zaten ödenmiş ve işlenmiş*/
                        echo 'OK';
                        exit();
                    } else if ($post['orderPrice'] != ($payment->bakiye_tutar + ($payment->bakiye_tutar * $ayarlar->vallet_komisyon / 100))) {
                        echo 'TUTAR_HATALI';
                        exit();
                    } else {
                        $kullanici = $this->yonetim_model->get(['kullanici_id' => $payment->kullanici_id]);
                        $this->bakiye_model->bakiye_update(array('bakiye_no' => $payment->bakiye_no, 'kullanici_id' => $payment->kullanici_id), array('bakiye_durum' => '1', 'odeme_tur' => 'Vallet', 'tur' => $post['paymentType']));

                        $tutar = $payment->bakiye_tutar;
                        $bakiye = $kullanici->bakiye;
                        $this->destek_model->kullaniciupdate(
                            array("kullanici_id" => $payment->kullanici_id),
                            array(
                                "bakiye" => $bakiye + $tutar
                            )
                        );
                        echo 'OK';
                        exit();
                    }
                }
            }
        }
    }

    function change_theme($id)
    {
        $_SESSION['theme'] = $id;
        echo 'OK';
    }

    public function index()
    {
        $data = new stdClass();

        $data->title = "";
        $data->description = "";
        $data->keywords = "";
        $data->anasayfa = true;
        $data->ayarlar = ayarlar();
        $data->kullanici = kullanicicek();
        $data->magazalar = $this->magaza_model->magazalar(array('magaza_durum' => 1));
        $data->bloglar = $this->destek_model->anasayfa_blog();
        //$data->sliders = $this->db->where('tur', 3)->get('slider')->result();
        $ust_reklam_query = $this->db->where(['type' => 1, 'status' => 1])
                             ->order_by("order_no ASC")
                             ->get('home_sliders');

		$data->ust_reklam = ($ust_reklam_query) ? $ust_reklam_query->result() : array();

		$alt_reklam_query = $this->db->where(['type' => 2, 'status' => 1])
									 ->order_by("order_no ASC")
									 ->get('home_sliders');

		$data->alt_reklam = ($alt_reklam_query) ? $alt_reklam_query->result() : array();

        // slider
        $data->alt_slider = $this->home_model->slidercek(['tur' => 2]);
        $data->orta_slider = $this->home_model->slidercek(['tur' => 1]);

        try {
        $data->vitrin_1 = $this->home_model->vitrinler(['type' => 0]) ?: array();
        $data->vitrin_2 = $this->home_model->vitrinler(['type' => 1]) ?: array();
    } catch (Exception $e) {
        $data->vitrin_1 = array();
        $data->vitrin_2 = array();
        log_message('error', 'Vitrin yükleme hatası: ' . $e->getMessage());
    }

        $this->load->view('inc/_header', $data);
        $this->load->view('index', $data);
        $this->load->view('inc/_footer', $data);
    }

    public function index_tasarim()
    {

        $data = new stdClass();

        $data->title = "";
        $data->description = "";
        $data->keywords = "";
        $data->anasayfa = true;
        $data->ayarlar = ayarlar();
        $data->kullanici = kullanicicek();
        $data->magazalar = $this->magaza_model->magazalar(array('magaza_durum' => 1));
        $data->bloglar = $this->destek_model->anasayfa_blog();

        $data->sliders = $this->db->where('tur', 3)->get('slider')->result();
        $data->ust_reklam = $this->db->where(['type' => 1])->order_by("order_no ASC")->get('home_sliders')->result();
        $data->alt_reklam = $this->db->where(['type' => 2])->order_by("order_no ASC")->get('home_sliders')->result();
        $this->load->view('inc/_header', $data);
        $this->load->view('index-tasarim', $data);
        $this->load->view('inc/_footer', $data);
    }

    public function hata()
    {
        $data = new stdClass();

        $data->title = "";
        $data->description = "";
        $data->keywords = "";
        $data->ayarlar = ayarlar();
        $data->kullanici = kullanicicek();


        $this->load->view('inc/_header', $data);
        $this->load->view('404/index', $data);
        $this->load->view('inc/_footer', $data);
    }

    public function urun_detay($seo)
    {
        $data = new stdClass();

        $vericek = $this->magaza_model->urun(array("urun_seo" => $seo, "urun_bitis_tarihi>" => date('Y-m-d H:i'), 'urun_durum' => 1));

        if (!$vericek) {
            redirect(base_url());
        }

        $urunDurum = $vericek->urun_durum;
        if ($urunDurum != 1 && $urunDurum != 2) {
            redirect(base_url());
        }

        $siteayar = ayarlar();

        $config = array();
        $config["base_url"] = base_url($vericek->urun_seo);
        $config["total_rows"] = yorum_say($vericek->urun_id);
        $config["per_page"] = 5;
        $config["uri_segment"] = 2;


        $config['first_link'] = '&laquo';
        $config['last_link'] = '&raquo';
        $config['attributes'] = array('class' => 'page-link');

        $config['full_tag_open'] = "<ul class='pagination justify-content-center'>";
        $config['full_tag_close'] = "</ul>";
        $config['num_tag_open'] = '<li class="page-item">';
        $config['num_tag_close'] = '</li>';
        $config['cur_tag_open'] = '<li class="page-item active"><a class="page-link" href="#">';
        $config['cur_tag_close'] = "</a></li>";

        $config['next_link'] = 'İleri';
        $config['next_tag_open'] = '<li class="page-item">';
        $config['next_tagl_close'] = "</li>";

        $config['prev_link'] = 'Geri';
        $config['prev_tag_open'] = '<li class="page-item">';
        $config['prev_tagl_close'] = "</li>";

        $config['first_tag_open'] = '<li class="page-item">';
        $config['first_tagl_close'] = "</li>";
        $config['last_tag_open'] = '<li class="page-item">';
        $config['last_tagl_close'] = "</li>";

        $this->pagination->initialize($config);

        $page = ($this->uri->segment(2)) ? $this->uri->segment(2) : 0;
        $data->links = $this->pagination->create_links();

        $data->yorumlar = $this->siparis_model->yorumlar_sayfalama(array('yorum.urun_id' => $vericek->urun_id, 'yorum.yorum_durum' => 1), $config["per_page"], $page);
        if (!empty($data->yorumlar)) {
            $yorumlar_yildiz_toplam = $this->siparis_model->yorum_yildiz_toplam($vericek->urun_id);
            $data->rating = $yorumlar_yildiz_toplam->yorum_puan / count($data->yorumlar);
        }

        $data->kadijoin = $this->magaza_model->getwho(array("kullanici_id" => $vericek->kullanici_id));
        $categories = json_decode($vericek->kategori_json);
        $data->kategori = $this->home_model->kategoricek(array("kategori_id" => $categories[0]));
        if ($data->kategori->parent != 0)
            $data->ust_kategori = $this->home_model->kategoricek(array("kategori_id" => $data->kategori->parent));
        $magaza = magaza($vericek->kullanici_id);

        if (!$magaza) {
            redirect(base_url());
        }
        //if($vericek->urun_alim=="0"){
        $data->title = $vericek->urun_ad;
        /*}
else{
    $data->title = "E-PIN";
}*/
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;

        $data->iller = $this->magaza_model->iller();
        $data->urun = $vericek;
        $data->google_key = $siteayar->google_key;
        $data->ayarlar = $siteayar;
        $data->kullanici = kullanicicek();
        $data->magaza = $magaza;
        if ($vericek->admin != 1) {
            $data->yorum_ortalamasi = yorum_ortalamasi($vericek->magaza_id);
            $data->urun_yorum_ortalamasi = urun_yorum_ortalamasi($vericek->magaza_id, $vericek->urun_id);
            $data->sms_sablonlar = $this->sms_model->sms_sablonlar(['sablon_durum' => '1']);
        }
        $data->sorular = $this->home_model->sorular_cek($vericek->urun_id);
        foreach ($data->sorular as $key => $val) {
            $data->sorular[$key]->soru_cevap = $this->magaza_model->get_soru_cevap($val->soru_id);
            $data->sorular[$key]->soru_cevap->magaza = magaza_bilgi($val->magaza_id);
        }
        $data->user_magaza = magaza_kbilgi($data->kullanici->kullanici_id);

        $this->load->view('inc/_header', $data);
        $this->load->view('urun/index', $data);
        $this->load->view('inc/_footer', $data);
    }

    public function satis_olustur($urun_uniq)
    {
        if (!aktif_kullanici()) {
            redirect(base_url('giris-yap'));
            die();
        }

        $kullanici = kullanicicek();

        $urun = $this->magaza_model->urun(array('urun_uniq' => $urun_uniq));
        $komisyon = $this->magaza_model->urun_komisyon(array('urun_uniq' => $urun_uniq));

        if (!$urun) {
            redirect(base_url());
            die();
        }

        /* if ($kullanici->kullanici_id == $urun->kullanici_id) {
            $alert = array(
                "title" => "Hata!",
                "text" => "Kendinize ait ürünü satın alamazsınız!",
                "type" => "error"
            );
            $this->session->set_flashdata("alert", $alert);
            redirect(base_url());
            die();
        }*/

        if ($urun->urun_stok == 0) {
            $alert = array(
                "title" => "Hata!",
                "text" => "Ürün Stokta Kalmadı!",
                "type" => "error"
            );
            $this->session->set_flashdata("alert", $alert);
            redirect(base_url());
            die();
        }


        $urun->urun_alimfiyat = $urun->urun_alimfiyat * $this->input->post('adet');
        $urunkfiyat = ($urun->urun_kfiyat * $komisyon) / 100;
        $urun->urun_kfiyat = round($urun->urun_kfiyat - $urunkfiyat, 2);
        $uretken = uretken(10);
        $data = array(
            'kullanici_id' => $kullanici->kullanici_id,
            'urun_id' => $urun->urun_id,
            'magaza' => $urun->magaza_id,
            'siparis_tutar' => $urun->urun_alimfiyat,
            'siparis_ktutar' => $urun->urun_kfiyat,
            'siparis_ad' => $this->input->post('ad'),
            'siparis_soyad' => $this->input->post('soyad'),
            'siparis_tel' => $this->input->post('telefon'),
            'oyun_nick' => $this->input->post('oyun_nick'),
            'adet' => $this->input->post('adet'),
            'siparis_no' => $uretken,
            'siparis_durum' => 0,
            'siparis_zaman' => date('Y-m-d'),
            'siparis_ay' => date('Y-m'),
            'siparis_uniq' => uniqid(),
            'komisyon' => $komisyon
        );

        $insert = $this->siparis_model->siparis_satis_add($data);
        $lastid = $this->db->insert_id();

        $json = json_decode($urun->kategori_json, true);
        $destek = "0";
        foreach ($json as $a) {
            $kate = $this->home_model->kategoricek(array("kategori_id" => $a));
            if ($kate->parent == "56" || $kate->kategori_id == "56") {
                $destek = "1";

                $talep_no = uretken(13);
                $datas = array(
                    'kullanici_id' => $kullanici->kullanici_id,
                    'siparis_no' => "",
                    'talep' => $urun->urun_ad . " Satışı Destek Talebi",
                    'talep_aciklama' => $uretken . " numaralı satış işlemimiz için yardımcı olabilir misiniz?",
                    'talep_no' => $talep_no,
                    'talep_durum' => 0
                );

                $this->siparis_model->talep_add($datas);

                $siparis_durum = array(
                    'ticket' => $talep_no
                );
                $this->siparis_model->satis_update(array('siparis_id' => $lastid), $siparis_durum);

                break;
                continue;
            }
        }

        if ($this->input->post('odeme') == 'bakiye') {

            $kullanici = kullanicicek();


            $siparis = $this->siparis_model->siparis_satis(array('siparis_satis.siparis_no' => $uretken));

            if ($siparis) {
                //  $this->siparis_model->siparis_update(array('siparis_no' => $uretken, 'kullanici_id' => $kullanici->kullanici_id), array('siparis_durum' => 1));

                $urun = $this->magaza_model->urun(array('urun_id' => $siparis->urun_id));
                if ($urun) {
                    $stok = $urun->urun_stok - 1;
                    /*if ($stok > 0) {
                            $this->magaza_model->urun_update(array('urun_id' => $siparis->urun_id), array('urun_stok' => $stok));
                        } else {
                            $this->magaza_model->urun_update(array('urun_id' => $siparis->urun_id), array('urun_stok' => $stok, 'urun_durum' => 2));
                        }*/


                    $alert = array(
                        "title" => "Başarılı!",
                        "text" => "Satış İşlemi Başlatıldı",
                        "type" => "success"
                    );
                    $this->session->set_flashdata("alert", $alert);
                    redirect(base_url('satislar'));
                    die();
                }
            } else {
                $alert = array(
                    "title" => "Hata!",
                    "text" => "Sipariş Bulunamadı!",
                    "type" => "error"
                );
                $this->session->set_flashdata("alert", $alert);
                redirect(base_url('satislar'));
                die();
            }


            die();
        }
        redirect(base_url('odeme/' . $this->input->post('odeme') . '/' . $uretken));
    }

    public function siparis_detay($seo)
    {
        if (!aktif_kullanici()) {
            redirect(base_url('giris-yap'));
            die();
        }

        $data = new stdClass();

        $vericek = $this->magaza_model->urun(array("urun_seo" => $seo, "urun_durum" => 1));

        if (!$vericek) {
            redirect(base_url());
        }


        $siteayar = ayarlar();

        $magaza = magaza($vericek->kullanici_id);

        if (!$magaza) {
            redirect(base_url());
        }

        $data->title = $vericek->urun_ad;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;

        $data->urun = $vericek;
        $data->google_key = $siteayar->google_key;
        $data->ayarlar = $siteayar;
        $data->kullanici = kullanicicek();
        $data->magaza = $magaza;
        $data->iller = $this->magaza_model->iller();


        $this->load->view('inc/_header', $data);
        $this->load->view('siparis/index', $data);
        $this->load->view('inc/_footer', $data);
    }

    public function siparis_olustur($urun_uniq)
    {
        if (!aktif_kullanici()) {
            redirect(base_url('giris-yap'));
            die();
        }

        $kullanici = kullanicicek();

        $urun = $this->magaza_model->urun(array('urun_uniq' => $urun_uniq));
        $komisyon = $this->magaza_model->urun_komisyon(array('urun_uniq' => $urun_uniq));

        if (!$urun) {
            redirect(base_url());
            die();
        }

        if ($kullanici->kullanici_id == $urun->kullanici_id) {
            $alert = array(
                "title" => "Hata!",
                "text" => "Kendinize ait ürünü satın alamazsınız!",
                "type" => "error"
            );
            $this->session->set_flashdata("alert", $alert);
            redirect(base_url());
            die();
        }

        if ($urun->urun_stok == 0) {
            $alert = array(
                "title" => "Hata!",
                "text" => "Ürün Stokta Kalmadı!",
                "type" => "error"
            );
            $this->session->set_flashdata("alert", $alert);
            redirect(base_url());
            die();
        }


        $urunkfiyat = ($urun->urun_kfiyat * $komisyon) / 100;
        $urun->urun_kfiyat = round($urun->urun_kfiyat - $urunkfiyat, 2);
        $uretken = uretken(10);
        $data = array(
            'kullanici_id' => $kullanici->kullanici_id,
            'urun_id' => $urun->urun_id,
            'magaza' => $urun->magaza_id,
            'siparis_tutar' => $urun->urun_fiyat,
            'siparis_ktutar' => $urun->urun_kfiyat,
            'siparis_ad' => $this->input->post('ad'),
            'siparis_soyad' => $this->input->post('soyad'),
            'siparis_tel' => $this->input->post('telefon'),
            'siparis_adres' => $this->input->post('adres'),
            'siparis_il' => $this->input->post('sehir'),
            'siparis_ilce' => $this->input->post('ilce'),
            'siparis_posta' => $this->input->post('posta'),
            'siparis_no' => $uretken,
            'siparis_durum' => 0,
            'siparis_zaman' => date('Y-m-d'),
            'siparis_ay' => date('Y-m'),
            'siparis_uniq' => uniqid(),
            'komisyon' => $komisyon
        );

        $insert = $this->siparis_model->siparis_add($data);
        $lastid = $this->db->insert_id();


        $json = json_decode($urun->kategori_json, true);
        $destek = "0";
        foreach ($json as $a) {
            $kate = $this->home_model->kategoricek(array("kategori_id" => $a));
            if ($kate->parent == "56" || $kate->kategori_id == "56") {
                $destek = "1";

                $talep_no = uretken(13);
                $datas = array(
                    'kullanici_id' => $kullanici->kullanici_id,
                    'siparis_no' => "",
                    'talep' => $urun->urun_ad . " Alışı Destek Talebi",
                    'talep_aciklama' => $uretken . " numaralı alış işlemimiz için yardımcı olabilir misiniz?",
                    'talep_no' => $talep_no,
                    'talep_durum' => 0
                );

                $this->siparis_model->talep_add($datas);

                $siparis_durum = array(
                    'ticket' => $talep_no
                );
                $this->siparis_model->satis_update(array('siparis_id' => $lastid), $siparis_durum);

                break;
                continue;
            }
        }


        if ($this->input->post('odeme') == 'bakiye') {

            $kullanici = kullanicicek();

            if ($kullanici->bakiye <= 0) {

                $alert = array(
                    "title" => "Hata!",
                    "text" => "Bakiyeniz Yetersiz!",
                    "type" => "error"
                );
                $this->session->set_flashdata("alert", $alert);
                redirect(base_url('siparislerim'));
                die();
            } else {
                if ($kullanici->bakiye < $urun->urun_fiyat) {
                    $alert = array(
                        "title" => "Hata!",
                        "text" => "Bakiyeniz Yetersiz!",
                        "type" => "error"
                    );
                    $this->session->set_flashdata("alert", $alert);
                    redirect(base_url('siparislerim'));
                    die();
                }

                $this->destek_model->kullaniciupdate(
                    array("kullanici_id" => $kullanici->kullanici_id),
                    array(
                        "bakiye" => $kullanici->bakiye - $urun->urun_fiyat
                    )
                );

                $siparis = $this->siparis_model->siparis(array('siparis.siparis_no' => $uretken));

                if ($siparis) {
                    $this->siparis_model->siparis_update(array('siparis_no' => $uretken, 'kullanici_id' => $kullanici->kullanici_id), array('siparis_durum' => 1));

                    $urun = $this->magaza_model->urun(array('urun_id' => $siparis->urun_id));
                    if ($urun) {
                        $stok = $urun->urun_stok - 1;
                        if ($stok > 0) {
                            $this->magaza_model->urun_update(array('urun_id' => $siparis->urun_id), array('urun_stok' => $stok));
                        } else {
                            $this->magaza_model->urun_update(array('urun_id' => $siparis->urun_id), array('urun_stok' => $stok, 'urun_durum' => 2));
                        }


                        $alert = array(
                            "title" => "Başarılı!",
                            "text" => "Sipariş Ödemesi Yapıldı",
                            "type" => "success"
                        );
                        $this->session->set_flashdata("alert", $alert);
                        redirect(base_url('siparislerim'));
                        die();
                    }
                } else {
                    $alert = array(
                        "title" => "Hata!",
                        "text" => "Sipariş Bulunamadı!",
                        "type" => "error"
                    );
                    $this->session->set_flashdata("alert", $alert);
                    redirect(base_url('siparislerim'));
                    die();
                }
            }


            die();
        }
        redirect(base_url('odeme/' . $this->input->post('odeme') . '/' . $uretken));
    }

    public function initialize_iyzico()
    {
        $ayarlar = ayarlar();
        require_once('application/libraries/iyzipay/IyzipayBootstrap.php');
        IyzipayBootstrap::init();
        $options = new \Iyzipay\Options();
        $options->setApiKey($ayarlar->iyzico_api);
        $options->setSecretKey($ayarlar->iyzico_secret);
        $options->setBaseUrl("https://sandbox-api.iyzipay.com");
        return $options;
    }

    function generate_string($strength = 16, $amount = null)
    {
        $permitted_chars = '0123456789abcdefghijklmnopqrstuvwxyzAB23456789CDEFGHIJKLMNOPQRSTUVWXYZ';
        $input_length = strlen($permitted_chars);
        $random_string = '';
        for ($i = 0; $i < $strength; $i++) {
            $random_character = $permitted_chars[mt_rand(0, $input_length - 1)];
            $random_string .= $random_character;
        }

        if ($amount == null)
            return str_shuffle($random_string);
        else
            return 'TO-' . $amount . '-' . str_shuffle($random_string);
    }

    public function odeme_yap($urun_id = null)
    {
        if (!aktif_kullanici()) {
            $response = array(
                'status' => 'error',
                'message' => 'Giriş yapmalısınız',
            );

            return $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode($response));
        }

        $urun = $this->db->where('urun_id', $urun_id)->get('urunler')->row();
        if (!$urun) {
            $response = array(
                'status' => 'error',
                'message' => 'Ürün Bulunamadı',
            );

            return $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode($response));
        }

        if ($urun->urun_stok == 0 || $urun->urun_stok < 0) {
            $response = array(
                'status' => 'warning',
                'message' => 'Bu ürün stokta bulunmamaktadır.',
            );

            return $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode($response));
        }

        $kullanici = kullanicicek();

        if ($kullanici->bakiye < $urun->urun_fiyat) {
            $response = array(
                'status' => 'error',
                'message' => 'Bakiyeniz Yetersiz',
            );

            return $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode($response));
        }
        $qty = $this->input->post('qty');


        if ($kullanici->bakiye < ($urun->urun_fiyat * $qty)) {
            $response = array(
                'status' => 'error',
                'message' => 'Bakiyeniz Yetersiz',
            );

            return $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode($response));
        }

        $uretken = uretken(10);
        if (in_array($urun->urun_id, [38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 120, 121, 122, 123, 124])) {
            $this->db->where('kullanici_id', $kullanici->kullanici_id)->update('kullanici', [
                'bakiye' => $kullanici->bakiye - $urun->urun_fiyat
            ]);
            $papayamount = 0;
            if ($urun->urun_id == 38) {
                $papayamount = 5;
            }
            if ($urun->urun_id == 39) {
                $papayamount = 10;
            }
            if ($urun->urun_id == 40) {
                $papayamount = 25;
            }
            if ($urun->urun_id == 41) {
                $papayamount = 50;
            }
            if ($urun->urun_id == 42) {
                $papayamount = 75;
            }
            if ($urun->urun_id == 43) {
                $papayamount = 100;
            }
            if ($urun->urun_id == 44) {
                $papayamount = 150;
            }
            if ($urun->urun_id == 45) {
                $papayamount = 250;
            }
            if ($urun->urun_id == 46) {
                $papayamount = 500;
            }
            if ($urun->urun_id == 47) {
                $papayamount = 1000;
            }
            if ($urun->urun_id == 120) {
                $papayamount = 2000;
            }
            if ($urun->urun_id == 121) {
                $papayamount = 5000;
            }
            if ($urun->urun_id == 122) {
                $papayamount = 10000;
            }
            if ($urun->urun_id == 123) {
                $papayamount = 25000;
            }
            if ($urun->urun_id == 124) {
                $papayamount = 50000;
            }

            for ($i = 0; $i < $qty; $i++) {
                $papaykey = $this->generate_string(32, $papayamount);
                $papayhash = $this->generate_string(16);

                $this->db->insert('papaycard', [
                    'papaykey' => $papaykey,
                    'papayhash' => $papayhash,
                    "amount" => $papayamount,
                ]);

                $this->db->insert('siparis', [
                    'kullanici_id' => $kullanici->kullanici_id,
                    'magaza' => $urun->magaza_id,
                    'urun_id' => $urun->urun_id,
                    'siparis_tutar' => $urun->urun_fiyat,
                    'siparis_ad' => $kullanici->kullanici_isim,
                    'siparis_soyad' => $kullanici->kullanici_soyisim,
                    'siparis_tel' => $kullanici->kullanici_tel,
                    'siparis_no' => $uretken,
                    'siparis_durum' => 2,
                    'siparis_tarih' => date('Y-m-d H:i:s'),
                    'product_id' => $urun->product_id,
                    'siparis_key' => "ID: " . $papaykey . "\n Key: " . $papayhash,
                    'siparis_epin' => 1,
                ]);
            }

            $response = array(
                'status' => 'success',
                'message' => 'Ürünü başarıyla satın aldınız. Altta bulunan "Siparişlerim Sayfasına Git" butonuna tıklayarak satın aldığınız ürünün detaylarını görebilirsiniz.',
            );

            return $this->output
                ->set_content_type('application/json')
                ->set_output(json_encode($response));
        } else if ($urun->turkpin == 2) { //Türk pin ile teslimat eğer bakiye yokise key havuzundan kullanacak
            $api = new Turkpin('agentsunucu@gmail.com', 'Mehmet.3434');
            try {
                $epinOrder = $api->epinOrder($urun->epin_id, $urun->product_id);

                $this->db->where('urun_id', $urun->urun_id)->update('urunler', [
                    'urun_stok' => $urun->urun_stok - 1
                ]);

                $this->db->where('kullanici_id', $kullanici->kullanici_id)->update('kullanici', [
                    'bakiye' => $kullanici->bakiye - $urun->urun_fiyat
                ]);

                $this->db->insert('siparis', [
                    'kullanici_id' => $kullanici->kullanici_id,
                    'magaza' => $urun->magaza_id,
                    'urun_id' => $urun->urun_id,
                    'siparis_tutar' => $urun->urun_fiyat,
                    'siparis_ad' => $kullanici->kullanici_isim,
                    'siparis_soyad' => $kullanici->kullanici_soyisim,
                    'siparis_tel' => $kullanici->kullanici_tel,
                    'siparis_no' => $uretken,
                    'siparis_durum' => 1,
                    'siparis_tarih' => date('Y-m-d H:i:s'),
                    'turkpin' => 2,
                    'order_no' => $epinOrder['order_no'],
                    'epin_id' => $urun->epin_id,
                    'product_id' => $urun->product_id,
                    'siparis_key' => $epinOrder['order_no'][0]['code'],
                    'siparis_epin' => 1,
                ]);
                $response = array(
                    'status' => 'success',
                    'message' => 'Ürünü başarıyla satın aldınız. Altta bulunan "Siparişlerim Sayfasına Git" butonuna tıklayarak satın aldığınız ürünün detaylarını görebilirsiniz.',
                );

                return $this->output
                    ->set_content_type('application/json')
                    ->set_output(json_encode($response));
            } catch (\Exception $e) {
                $havuzkey = $this->db->where(['status' => 0, 'urun_id' => $urun->urun_id])->get('stock')->row();

                if ($havuzkey) {
                    $this->db->where('id', $havuzkey->id)->update('stock', [
                        'status' => 1,
                        'seller' => $kullanici->kullanici_id,
                    ]);

                    $this->db->where('urun_id', $urun->urun_id)->update('urunler', [
                        'urun_stok' => $urun->urun_stok - 1
                    ]);

                    $this->db->where('kullanici_id', $kullanici->kullanici_id)->update('kullanici', [
                        'bakiye' => $kullanici->bakiye - $urun->urun_fiyat
                    ]);

                    $this->db->insert('siparis', [
                        'kullanici_id' => $kullanici->kullanici_id,
                        'magaza' => $urun->magaza_id,
                        'urun_id' => $urun->urun_id,
                        'siparis_tutar' => $urun->urun_fiyat,
                        'siparis_ad' => $kullanici->kullanici_isim,
                        'siparis_soyad' => $kullanici->kullanici_soyisim,
                        'siparis_tel' => $kullanici->kullanici_tel,
                        'siparis_no' => $uretken,
                        'siparis_durum' => 1,
                        'siparis_tarih' => date('Y-m-d H:i:s'),
                        'turkpin' => 1,
                        'siparis_key' => $havuzkey->key,
                        'siparis_epin' => 1,

                    ]);

                    $response = array(
                        'status' => 'success',
                        'message' => 'Ürünü başarıyla satın aldınız. Altta bulunan "Siparişlerim Sayfasına Git" butonuna tıklayarak satın aldığınız ürünün detaylarını görebilirsiniz.',
                    );

                    return $this->output->set_content_type('application/json')->set_output(json_encode($response));
                    die;
                } else {

                    $this->db->where('urun_id', $urun->urun_id)->update('urunler', [
                        'urun_stok' => $urun->urun_stok - 1
                    ]);

                    $this->db->where('kullanici_id', $kullanici->kullanici_id)->update('kullanici', [
                        'bakiye' => $kullanici->bakiye - $urun->urun_fiyat
                    ]);

                    $this->db->insert('siparis', [
                        'kullanici_id' => $kullanici->kullanici_id,
                        'magaza' => $urun->magaza_id,
                        'urun_id' => $urun->urun_id,
                        'siparis_tutar' => $urun->urun_fiyat,
                        'siparis_ad' => $kullanici->kullanici_isim,
                        'siparis_soyad' => $kullanici->kullanici_soyisim,
                        'siparis_tel' => $kullanici->kullanici_tel,
                        'siparis_no' => $uretken,
                        'siparis_durum' => 1,
                        'siparis_tarih' => date('Y-m-d H:i:s'),
                        'siparis_epin' => 2,
                    ]);

                    $response = array(
                        'status' => 'success',
                        'message' => 'Ürününüz Beklemede, en kısa sürede teslim edilecektir.',
                    );

                    return $this->output->set_content_type('application/json')->set_output(json_encode($response));
                    die;
                }
            }
        } else {
            $havuzkey = $this->db->where(['status' => 0, 'urun_id' => $urun->urun_id])->get('stock')->row();
            if ($havuzkey) {
                $this->db->where('id', $havuzkey->id)->update('stock', [
                    'status' => 1,
                    'seller' => $kullanici->kullanici_id,
                ]);

                $this->db->where('urun_id', $urun->urun_id)->update('urunler', [
                    'urun_stok' => $urun->urun_stok - 1
                ]);

                $this->db->where('kullanici_id', $kullanici->kullanici_id)->update('kullanici', [
                    'bakiye' => $kullanici->bakiye - $urun->urun_fiyat
                ]);

                $this->db->insert('siparis', [
                    'kullanici_id' => $kullanici->kullanici_id,
                    'magaza' => $urun->magaza_id,
                    'urun_id' => $urun->urun_id,
                    'siparis_tutar' => $urun->urun_fiyat,
                    'siparis_ad' => $kullanici->kullanici_isim,
                    'siparis_soyad' => $kullanici->kullanici_soyisim,
                    'siparis_tel' => $kullanici->kullanici_tel,
                    'siparis_no' => $uretken,
                    'siparis_durum' => 1,
                    'siparis_tarih' => date('Y-m-d H:i:s'),
                    'turkpin' => 1,
                    'siparis_key' => $havuzkey->key,
                    'siparis_epin' => 1,
                ]);

                $magaza_bilgi = magaza_bilgi($urun->magaza_id);

                if ($amesaj = $this->mesaj_model->control_amesaj($kullanici->kullanici_id, $magaza_bilgi->kullanici_id)) {
                    $oto_mesaj = '<a href="' . base_url($urun->urun_seo) . '">' . $urun->urun_ad . '</a> başlıklı ilanı, ' . date('Y-m-d H:i:s') . ' tarihinde ' . $urun->urun_fiyat . ' ₺ karşılığında satın aldınız. <br><br> Satın aldığınız ürüne siparişlerim sayfasından ulaşabilirsiniz. <br><br> Teslim Edilen Stok <br><br> ' . $havuzkey->key . ' ';

                    $mesaj_data = array(
                        'amesaj_id' => $amesaj->id,
                        'alan_id' => $kullanici->kullanici_id,
                        'gonderen_id' => $magaza_bilgi->kullanici_id,
                        'mesaj' => $oto_mesaj,
                        'okunma' => 1,
                        'uniq' => uniqid()
                    );

                    $this->mesaj_model->mesaj_add($mesaj_data);
                } else if ($amesaj = $this->mesaj_model->control_amesaj_reverse($kullanici->kullanici_id, $magaza_bilgi->kullanici_id)) {
                    $oto_mesaj = '<a href="' . base_url($urun->urun_seo) . '">' . $urun->urun_ad . '</a> başlıklı ilanı, ' . date('Y-m-d H:i:s') . ' tarihinde ' . $urun->urun_fiyat . ' ₺ karşılığında satın aldınız. <br><br> Satın aldığınız ürüne siparişlerim sayfasından ulaşabilirsiniz. <br><br> Teslim Edilen Stok <br><br> ' . $havuzkey->key . ' ';

                    $mesaj_data = array(
                        'amesaj_id' => $amesaj->id,
                        'alan_id' => $kullanici->kullanici_id,
                        'gonderen_id' => $magaza_bilgi->kullanici_id,
                        'mesaj' => $oto_mesaj,
                        'okunma' => 1,
                        'uniq' => uniqid()
                    );

                    $this->mesaj_model->mesaj_add($mesaj_data);
                } else {
                    $this->mesaj_model->add_amesaj_oto($urun->magaza_id, $kullanici->kullanici_id);
                    $amesaj = $this->mesaj_model->control_amesaj($kullanici->kullanici_id, $magaza_bilgi->kullanici_id);

                    $oto_mesaj = '<a href="' . base_url($urun->urun_seo) . '">' . $urun->urun_ad . '</a> başlıklı ilanı, ' . date('Y-m-d H:i:s') . ' tarihinde ' . $urun->urun_fiyat . ' ₺ karşılığında satın aldınız. <br><br> Satın aldığınız ürüne siparişlerim sayfasından ulaşabilirsiniz. <br><br> Teslim Edilen Stok <br><br> ' . $havuzkey->key . ' ';

                    $mesaj_data = array(
                        'amesaj_id' => $amesaj->id,
                        'alan_id' => $kullanici->kullanici_id,
                        'gonderen_id' => $magaza_bilgi->kullanici_id,
                        'mesaj' => $oto_mesaj,
                        'okunma' => 1,
                        'uniq' => uniqid()
                    );

                    $this->mesaj_model->mesaj_add($mesaj_data);
                }

                $response = array(
                    'status' => 'success',
                    'message' => 'Ürünü başarıyla satın aldınız. Altta bulunan "Siparişlerim Sayfasına Git" butonuna tıklayarak satın aldığınız ürünün detaylarını görebilirsiniz.',
                );

                return $this->output->set_content_type('application/json')->set_output(json_encode($response));
                die;
            } else {
                $this->db->where('urun_id', $urun->urun_id)->update('urunler', [
                    'urun_stok' => $urun->urun_stok - 1,
                    'urun_alim' => 1
                ]);
                $this->db->where('kullanici_id', $kullanici->kullanici_id)->update('kullanici', [
                    'bakiye' => $kullanici->bakiye - $urun->urun_fiyat
                ]);
                if (!empty($urun->urun_sanal_bilgi)) {
                    $this->db->insert('siparis', [
                        'kullanici_id' => $kullanici->kullanici_id,
                        'magaza' => $urun->magaza_id,
                        'urun_id' => $urun->urun_id,
                        'siparis_tutar' => $urun->urun_fiyat,
                        'siparis_ad' => $kullanici->kullanici_isim,
                        'siparis_soyad' => $kullanici->kullanici_soyisim,
                        'siparis_tel' => $kullanici->kullanici_tel,
                        'siparis_no' => $uretken,
                        'siparis_durum' => 1,
                        'siparis_tarih' => date('Y-m-d H:i:s'),
                        'siparis_key' => $urun->urun_sanal_bilgi,
                        'siparis_epin' => 0,
                    ]);
                } else {
                    $this->db->insert('siparis', [
                        'kullanici_id' => $kullanici->kullanici_id,
                        'magaza' => $urun->magaza_id,
                        'urun_id' => $urun->urun_id,
                        'siparis_tutar' => $urun->urun_fiyat,
                        'siparis_ad' => $kullanici->kullanici_isim,
                        'siparis_soyad' => $kullanici->kullanici_soyisim,
                        'siparis_tel' => $kullanici->kullanici_tel,
                        'siparis_no' => $uretken,
                        'siparis_durum' => 1,
                        'siparis_tarih' => date('Y-m-d H:i:s'),
                        'siparis_epin' => 2,
                    ]);
                }

                $magaza_bilgi = magaza_bilgi($urun->magaza_id);

                if ($amesaj = $this->mesaj_model->control_amesaj($kullanici->kullanici_id, $magaza_bilgi->kullanici_id)) {
                    $oto_mesaj = '<a href="' . base_url($urun->urun_seo) . '">' . $urun->urun_ad . '</a> başlıklı ilanı, ' . date('Y-m-d H:i:s') . ' tarihinde ' . $urun->urun_fiyat . ' ₺ karşılığında satın aldınız. <br><br> Satın aldığınız ürüne siparişlerim sayfasından ulaşabilirsiniz. <br><br> Teslim Edilen Stok <br><br> ' . $urun->urun_sanal_bilgi . ' ';

                    $mesaj_data = array(
                        'amesaj_id' => $amesaj->id,
                        'alan_id' => $kullanici->kullanici_id,
                        'gonderen_id' => $magaza_bilgi->kullanici_id,
                        'mesaj' => $oto_mesaj,
                        'okunma' => 1,
                        'uniq' => uniqid()
                    );

                    $this->mesaj_model->mesaj_add($mesaj_data);
                } else if ($amesaj = $this->mesaj_model->control_amesaj_reverse($kullanici->kullanici_id, $magaza_bilgi->kullanici_id)) {
                    $oto_mesaj = '<a href="' . base_url($urun->urun_seo) . '">' . $urun->urun_ad . '</a> başlıklı ilanı, ' . date('Y-m-d H:i:s') . ' tarihinde ' . $urun->urun_fiyat . ' ₺ karşılığında satın aldınız. <br><br> Satın aldığınız ürüne siparişlerim sayfasından ulaşabilirsiniz. <br><br> Teslim Edilen Stok <br><br> ' . $urun->urun_sanal_bilgi . ' ';

                    $mesaj_data = array(
                        'amesaj_id' => $amesaj->id,
                        'alan_id' => $kullanici->kullanici_id,
                        'gonderen_id' => $magaza_bilgi->kullanici_id,
                        'mesaj' => $oto_mesaj,
                        'okunma' => 1,
                        'uniq' => uniqid()
                    );

                    $this->mesaj_model->mesaj_add($mesaj_data);
                } else {
                    $this->mesaj_model->add_amesaj_oto($urun->magaza_id, $kullanici->kullanici_id);
                    $amesaj = $this->mesaj_model->control_amesaj($kullanici->kullanici_id, $magaza_bilgi->kullanici_id);

                    $oto_mesaj = '<a href="' . base_url($urun->urun_seo) . '">' . $urun->urun_ad . '</a> başlıklı ilanı, ' . date('Y-m-d H:i:s') . ' tarihinde ' . $urun->urun_fiyat . ' ₺ karşılığında satın aldınız. <br><br> Satın aldığınız ürüne siparişlerim sayfasından ulaşabilirsiniz. <br><br> Teslim Edilen Stok <br><br> ' . $urun->urun_sanal_bilgi . ' ';

                    $mesaj_data = array(
                        'amesaj_id' => $amesaj->id,
                        'alan_id' => $kullanici->kullanici_id,
                        'gonderen_id' => $magaza_bilgi->kullanici_id,
                        'mesaj' => $oto_mesaj,
                        'okunma' => 1,
                        'uniq' => uniqid()
                    );

                    $this->mesaj_model->mesaj_add($mesaj_data);
                }

                $response = array(
                    'status' => 'success',
                    'message' => 'Ürününüz Beklemede, en kısa sürede teslim edilecektir.',
                );

                return $this->output->set_content_type('application/json')->set_output(json_encode($response));
                die;
            }
        }

        $response = array(
            'status' => 'false',
            'message' => 'İşlem Başarısız!',
        );

        $this->output
            ->set_content_type('application/json')
            ->set_output(json_encode($response));
    }

    public function odeme($siparis_no)
    {
        if (!aktif_kullanici()) {
            redirect(base_url('giris-yap'));
            die();
        }

        $data = new stdClass();
        $kullanici = kullanicicek();
        $vericek = $this->siparis_model->siparis(array("siparis.siparis_no" => $siparis_no, "siparis.kullanici_id" => $kullanici->kullanici_id, 'siparis.siparis_durum' => 0));

        if (!$vericek) {
            redirect(base_url());
        }

        $siteayar = ayarlar();


        $data->title = "Ödeme Yap";
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;

        $data->siparis = $vericek;
        $data->google_key = $siteayar->google_key;
        $data->ayarlar = $siteayar;
        $data->kullanici = $kullanici;
        $data->options = $this->initialize_iyzico();


        $this->load->view('inc/_header', $data);
        $this->load->view('siparis/odeme', $data);
        $this->load->view('inc/_footer', $data);
    }

    public function odeme_onay()
    {
        if (!aktif_kullanici()) {
            redirect(base_url('giris-yap'));
            die();
        }
        $options = $this->initialize_iyzico();
        $kullanici = kullanicicek();
        $request = new \Iyzipay\Request\RetrieveCheckoutFormRequest();
        $request->setLocale(\Iyzipay\Model\Locale::TR);
        $request->setConversationId("123456789");
        $request->setToken($_POST["token"]);
        $checkoutForm = \Iyzipay\Model\CheckoutForm::retrieve($request, $options);
        if ($checkoutForm->getStatus() == "success") {
            $siparis = $this->siparis_model->siparis(array('siparis.siparis_no' => $checkoutForm->getBasketId()));

            if ($siparis) {
                $siparis_update = $this->siparis_model->siparis_update(array('siparis_no' => $checkoutForm->getBasketId(), 'kullanici_id' => $kullanici->kullanici_id), array('siparis_durum' => 1));

                $urun = $this->magaza_model->urun(array('urun_id' => $siparis->urun_id));
                if ($urun) {
                    $stok = $urun->urun_stok - 1;
                    if ($stok > 0) {
                        $this->magaza_model->urun_update(array('urun_id' => $siparis->urun_id), array('urun_stok' => $stok));
                    } else {
                        $this->magaza_model->urun_update(array('urun_id' => $siparis->urun_id), array('urun_stok' => $stok, 'urun_durum' => 2));
                    }


                    $alert = array(
                        "title" => "Başarılı!",
                        "text" => "Ödemeniz Yapılmıştır..",
                        "type" => "success"
                    );
                    $this->session->set_flashdata("alert", $alert);
                    redirect(base_url('siparislerim'));
                    die();
                }
            }
        } else {
            $data['status'] = 'Ödeme alınamadı, bir hata oluştu.';
        }
    }

    function odeme_basarili()
    {
        $alert = array(
            "title" => "Başarılı!",
            "text" => "Ödemeniz Yapılmıştır..",
            "type" => "success"
        );
        $this->session->set_flashdata("alert", $alert);
        redirect(base_url('siparislerim'));
        die();
    }

    function odeme_basarisiz()
    {
        $alert = array(
            "title" => "Başarısız!",
            "text" => "Ödeme alınamadı, bir hata oluştu.",
            "type" => "error"
        );
        $this->session->set_flashdata("alert", $alert);
        redirect(base_url('siparislerim'));
        die();
    }

    public function odeme_onay_paytr()
    {
        if (!aktif_kullanici()) {
            redirect(base_url('giris-yap'));
            die();
        }
        $siteayar = ayarlar();

        $kullanici = kullanicicek();

        $post = $_POST;
        var_dump($_POST);

        $hash = base64_encode(hash_hmac('sha256', $post['merchant_oid'] . $siteayar->paytr_secret . $post['status'] . $post['total_amount'], $siteayar->paytr_api, true));
        if ($hash != $post['hash'])
            die('PAYTR notification failed: bad hash');

        if ($post['status'] == 'success') { ## Ödeme Onaylandı
            $siparis = $this->siparis_model->siparis(array('siparis.siparis_no' => $checkoutForm->getBasketId()));

            if ($siparis) {
                $siparis_update = $this->siparis_model->siparis_update(array('siparis_no' => $checkoutForm->getBasketId(), 'kullanici_id' => $kullanici->kullanici_id), array('siparis_durum' => 1));

                $urun = $this->magaza_model->urun(array('urun_id' => $siparis->urun_id));
                if ($urun) {
                    $stok = $urun->urun_stok - 1;
                    if ($stok > 0) {
                        $this->magaza_model->urun_update(array('urun_id' => $siparis->urun_id), array('urun_stok' => $stok));
                    } else {
                        $this->magaza_model->urun_update(array('urun_id' => $siparis->urun_id), array('urun_stok' => $stok, 'urun_durum' => 2));
                    }


                    $alert = array(
                        "title" => "Başarılı!",
                        "text" => "Ödemeniz Yapılmıştır..",
                        "type" => "success"
                    );
                    $this->session->set_flashdata("alert", $alert);
                    redirect(base_url('siparislerim'));
                    die();
                }
            }
        } else { ## Ödemeye Onay Verilmedi
            $data['status'] = 'Ödeme alınamadı, bir hata oluştu.';
            ## BURADA YAPILMASI GEREKENLER
            ## 1) Siparişi iptal edin.
            ## 2) Eğer ödemenin onaylanmama sebebini kayıt edecekseniz aşağıdaki değerleri kullanabilirsiniz.
            ## $post['failed_reason_code'] - başarısız hata kodu
            ## $post['failed_reason_msg'] - başarısız hata mesajı

        }

        ## Bildirimin alındığını PayTR sistemine bildir.
        echo "OK";
    }

    public function odeme_onay_bakiye($siparis_no)
    {
        if (!aktif_kullanici()) {
            redirect(base_url('giris-yap'));
            die();
        }
        $siteayar = ayarlar();
        $kullanici = kullanicicek();


        if ($kullanici->bakiye <= 0) {

            $alert = array(
                "title" => "Hata!",
                "text" => "Bakiyeniz Yetersiz!",
                "type" => "error"
            );
            $this->session->set_flashdata("alert", $alert);
            redirect(base_url('siparislerim'));
            die();
        } else {

            $siparis = $this->siparis_model->siparis(array('siparis.siparis_no' => $siparis_no));

            if ($kullanici->bakiye < $siparis->siparis_tutar) {
                $alert = array(
                    "title" => "Hata!",
                    "text" => "Bakiyeniz Yetersiz!",
                    "type" => "error"
                );
                $this->session->set_flashdata("alert", $alert);
                redirect(base_url('siparislerim'));
                die();
            }

            $this->destek_model->kullaniciupdate(
                array("kullanici_id" => $kullanici->kullanici_id),
                array(
                    "bakiye" => $kullanici->bakiye - $siparis->siparis_tutar
                )
            );

            if ($siparis) {
                $this->siparis_model->siparis_update(array('siparis_no' => $siparis_no, 'kullanici_id' => $kullanici->kullanici_id), array('siparis_durum' => 1));

                $urun = $this->magaza_model->urun(array('urun_id' => $siparis->urun_id));
                if ($urun) {
                    $stok = $urun->urun_stok - 1;
                    if ($stok > 0) {
                        $this->magaza_model->urun_update(array('urun_id' => $siparis->urun_id), array('urun_stok' => $stok));
                    } else {
                        $this->magaza_model->urun_update(array('urun_id' => $siparis->urun_id), array('urun_stok' => $stok, 'urun_durum' => 2));
                    }


                    $alert = array(
                        "title" => "Başarılı!",
                        "text" => "Sipariş Ödemesi Yapıldı",
                        "type" => "success"
                    );
                    $this->session->set_flashdata("alert", $alert);
                    redirect(base_url('siparislerim'));
                    die();
                }
            } else {
                $alert = array(
                    "title" => "Hata!",
                    "text" => "Sipariş Bulunamadı!",
                    "type" => "error"
                );
                $this->session->set_flashdata("alert", $alert);
                redirect(base_url('siparislerim'));
                die();
            }
        }


        echo "OK";
    }

    public function magaza_detay($seo)
    {
        $data = new stdClass();

        $vericek = $this->magaza_model->magaza(array("magaza_seo" => $seo));

        if ($vericek->kullanici_id == kullanicicek()->kullanici_id) {
            if ($vericek->magaza_durum != 1) {
                redirect(base_url('magaza-olustur'));
            }
        } else {
            if ($vericek->magaza_durum != 1) {
                redirect(base_url());
            }
        }
        if (!$vericek) {
            redirect(base_url());
        }


        $siteayar = ayarlar();

        $config = array();
        $config["base_url"] = base_url("m/" . $vericek->magaza_seo);
        $config["total_rows"] = magaza_urunsay($vericek->kullanici_id, $vericek->magaza_seo);
        $config["per_page"] = 12;
        $config["uri_segment"] = 3;


        $config['first_link'] = '&laquo';
        $config['last_link'] = '&raquo';
        $config['attributes'] = array('class' => 'page-link');

        $config['full_tag_open'] = "<ul class='pagination justify-content-center'>";
        $config['full_tag_close'] = "</ul>";
        $config['num_tag_open'] = '<li class="page-item">';
        $config['num_tag_close'] = '</li>';
        $config['cur_tag_open'] = '<li class="page-item active"><a class="page-link" href="#">';
        $config['cur_tag_close'] = "</a></li>";

        $config['next_link'] = 'İleri';
        $config['next_tag_open'] = '<li class="page-item">';
        $config['next_tagl_close'] = "</li>";

        $config['prev_link'] = 'Geri';
        $config['prev_tag_open'] = '<li class="page-item">';
        $config['prev_tagl_close'] = "</li>";

        $config['first_tag_open'] = '<li class="page-item">';
        $config['first_tagl_close'] = "</li>";
        $config['last_tag_open'] = '<li class="page-item">';
        $config['last_tagl_close'] = "</li>";

        $this->pagination->initialize($config);

        $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
        $data->links = $this->pagination->create_links();
        $data->kadijoin = $this->magaza_model->getwho(array("kullanici_id" => $vericek->kullanici_id));
        $data->urunler = $this->magaza_model->magaza_urun_sayfalama(array('urunler.magaza_id' => $vericek->magaza_id, 'urunler.urun_durum' => 1), $config["per_page"], $page);
        $data->title = $vericek->magaza_ad;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;

        $data->urun = $vericek;
        $data->google_key = $siteayar->google_key;
        $data->ayarlar = $siteayar;
        $data->kullanici = kullanicicek();
        $data->magaza = $vericek;
        $data->magaza_kullanici_bilgi = kullanici_bilgi($vericek->kullanici_id);

        $data->yorum_ortalamasi = yorum_ortalamasi($vericek->magaza_id);

        //ilanlar
        $data->aktif_ilanlar = $this->magaza_model->get_magaza_ilanlar($vericek->kullanici_id, 1);
        $data->bekleyen_ilanlar = $this->magaza_model->get_magaza_ilanlar($vericek->kullanici_id, 0);
        $data->pasif_ilanlar = $this->magaza_model->get_magaza_ilanlar($vericek->kullanici_id, 2);

        //ilan soruları
        $data->sorular = $this->magaza_model->get_sorular($data->magaza->magaza_id);
        foreach ($data->sorular as $key => $val) {
            $data->sorular[$key]->soru_cevap = $this->magaza_model->get_soru_cevap($val->soru_id);
        }

        //yorumlar
        $data->yorumlar = $this->magaza_model->get_yorumlar($vericek->magaza_id);
        if (!empty($data->yorumlar)) {
            $yorumlar_yildiz_toplam = $this->siparis_model->magaza_yorum_yildiz_toplam($vericek->magaza_id);
            $data->rating = $yorumlar_yildiz_toplam->yorum_puan / count($data->yorumlar);
        }
        //Çekilişler
        $data->aktif_cekilisler = $this->magaza_model->get_cekilisler($vericek->magaza_id, 0);
        $data->bekleyen_cekilisler = $this->magaza_model->get_cekilisler($vericek->magaza_id, 1);
        $data->iptal_cekilisler = $this->magaza_model->get_cekilisler($vericek->magaza_id, 2);

        // Sayılar
        $data->ilan_count = count($data->aktif_ilanlar);
        $data->order_count = $this->magaza_model->get_order_count($data->magaza->magaza_id);
        $data->sales_count = $this->magaza_model->get_sales_count($data->magaza->magaza_id);
        $data->total_earning = $this->magaza_model->get_total_earning($data->magaza->magaza_id);
        $data->month_total_earning = $this->magaza_model->get_month_total_earning($data->magaza->magaza_id);
        $data->month_order_count = $this->magaza_model->get_month_order_count($data->magaza->magaza_id);


        $this->load->view('inc/_header', $data);
        $this->load->view('magaza/index', $data);
        $this->load->view('inc/_footer', $data);
    }

    public function kategoridetay($seo)
    {
        $data = new stdClass();

        $vericek = $this->home_model->kategoricek(array("kategori_seo" => $seo));
        if (!$vericek) {
            redirect(base_url());
        }
        if ($vericek->kategori_durum == 0) {
            redirect(base_url());
        }
        $data->kategori = $vericek;
        if ($data->kategori->parent != 0)
            $data->ust_kategori = $this->home_model->kategoricek(array("kategori_id" => $data->kategori->parent));

        $config = array();
        $config["base_url"] = base_url("kategori/$seo");
        $config["total_rows"] = kat_urunsay($vericek->kategori_id);
        $config["per_page"] = 12;
        $config["uri_segment"] = 3;

        //Pagenation Tasarım

        $config['first_link'] = '&laquo';
        $config['last_link'] = '&raquo';

        $config['full_tag_open'] = "<ul class='pagination justify-content-center'>";
        $config['full_tag_close'] = "</ul>";
        $config['num_tag_open'] = '<li class="page-item page-link">';
        $config['num_tag_close'] = '</li>';
        $config['cur_tag_open'] = '<li class="page-item active"><a class="page-link" href="#">';
        $config['cur_tag_close'] = "</a></li>";

        $config['next_link'] = 'İleri';
        $config['next_tag_open'] = '<li class="page-item page-link">';
        $config['next_tagl_close'] = "</li>";

        $config['prev_link'] = 'Geri';
        $config['prev_tag_open'] = '<li class="page-item page-link">';
        $config['prev_tagl_close'] = "</li>";

        $config['first_tag_open'] = '<li class="page-item page-link">';
        $config['first_tagl_close'] = "</li>";
        $config['last_tag_open'] = '<li class="page-item page-link">';
        $config['last_tagl_close'] = "</li>";


        $this->pagination->initialize($config);

        $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;

        //$data->links = $this->pagination->create_links();

        //$data->urunler = $this->magaza_model->kat_urun_sayfalama(array("urunler.urun_durum" => 1), $vericek->kategori_id, $config["per_page"], $page);
        if ($vericek->kategori_tur == 1) {
            if (!empty($_GET['type'])) {
                $filters_array = [];
                $sub_filters = $this->home_model->get_sub_filters($_GET['type']);
                foreach (!empty($sub_filters) ? $sub_filters : [] as $key => $val) {
                    $filters_array[$val->slug] = $this->input->get($val->slug, true);
                }
                json_encode($filters_array);
            }

            $sub_filters = $this->input->get('DataDetail[]');
            //ilanlar listele
            $data->urunler = $this->magaza_model->new_liste_urunler($vericek, $_GET['type'], $_GET['desc'], $_GET['title'], $_GET['min'], $_GET['maks'], $filters_array);
            //$data->urunler = $this->db->where(['urun_durum' => 1, 'urun_bitis_tarihi>' => date('Y-m-d H:i'), 'urun_alim' => 0])->like('kategori_json', $vericek->kategori_id)->order_by('urun_sira', 'ASC')->get('urunler')->result();
            //if($vericek->kategori_tur == 1)
            //$this->db->where('urunler.urun_bitis_tarihi>', date('Y-m-d H:i'));
            $data->vitrin_urunler = $this->magaza_model->kat_vitrin_urun_sayfalama(array("urunler.urun_durum" => 1), $vericek->kategori_id);
            $data->filtreler = $this->magaza_model->get_kategori_filtreler($vericek->kategori_id);
            if (!empty($_GET['type'])) {
                $data->sub_filters = $this->home_model->get_sub_filters($_GET['type']);
                foreach (!empty($data->sub_filters) ? $data->sub_filters : [] as $key => $val) {
                    if ($val->type == 1) {
                        $data->sub_filters[$key]->ozellikler = $this->home_model->get_filter_ozellik($val->filtre_id);
                    }
                }
            }
        } else {
            // ürünler listele
            $data->urunler = $this->db->where(['urun_durum' => 1])->like('kategori_json', $vericek->kategori_id)->order_by('urun_sira', 'ASC')->get('urunler')->result();
            //if($vericek->kategori_tur == 1)
            //$this->db->where('urunler.urun_bitis_tarihi>', date('Y-m-d H:i'));
            $data->vitrin_urunler = $this->magaza_model->kat_vitrin_urun_sayfalama(array("urunler.urun_durum" => 1), $vericek->kategori_id);

            $product_ids = array();
            foreach ($data->urunler as $product) {
                $product_ids[] = $product->urun_id;
            }

            $config['base_url'] = base_url('kategori/'.$seo);
            $config['total_rows'] = $this->home_model->count_comments_by_product_ids($product_ids);
            $config['per_page'] = 3;
            $config['use_page_numbers'] = true;
            $config['page_query_string'] = true;
            $config['reuse_query_string'] = true;

            // Sayfalama yapılandırmasını HTML yapınıza göre düzenleyin
            $config['full_tag_open'] = '<ul class="pegi-list">';
            $config['full_tag_close'] = '</ul>';

            $config['first_link'] = 'İlk';  // İlk sayfa
            $config['first_tag_open'] = '<li class="pegi-item">';
            $config['first_tag_close'] = '</li>';

            $config['last_link'] = 'End';  // Son sayfa
            $config['last_tag_open'] = '<li class="pegi-item">';
            $config['last_tag_close'] = '</li>';

            $config['next_link'] = '»';  // Sonraki sayfa
            $config['next_tag_open'] = '<li class="pegi-item pegi-next">';
            $config['next_tag_close'] = '</li>';

            $config['prev_link'] = '«';  // Önceki sayfa
            $config['prev_tag_open'] = '<li class="pegi-item">';
            $config['prev_tag_close'] = '</li>';

            $config['cur_tag_open'] = '<li class="pegi-item active">';  // Mevcut sayfa
            $config['cur_tag_close'] = '</li>';

            $config['num_tag_open'] = '<li class="pegi-item">';  // Diğer sayfalar
            $config['num_tag_close'] = '</li>';

            // Sayfalama yapılandırmasını başlat
            $this->pagination->initialize($config);

            // Yorumları çekmek için limit ve offset kullan
            $page = $this->input->get('per_page', true);
            if (empty($page)) {
                $page = 1;
            }
            $data->yorumlar = $this->home_model->get_comments_by_product_ids($product_ids, $config['per_page'], $page);
            $data->yorum_pagi = $this->pagination->create_links();

        }

        $this->load->library("form_validation");

        if (empty($vericek->kategori_title)) {
            $data->title = $vericek->kategori_ad;
        } else {
            $data->title = $vericek->kategori_title;
        }

        if (empty($vericek->kategori_desc)) {
            $data->description = $vericek->kategori_ad;
        } else {
            $data->description = $vericek->kategori_desc;
        }

        if (empty($vericek->kategori_keyw)) {
            $data->keywords = $vericek->kategori_ad;
        } else {
            $data->keywords = $vericek->kategori_keyw;
        }

        $data->where = $vericek;
        $data->ayarlar = ayarlar();
        $data->kullanici = kullanicicek();
        $data->kategoriler = kategoriler();
        $this->load->view('inc/_header', $data);
        if ($vericek->kategori_tur == 1) {
            $this->load->view('kategori/new-liste', $data);
        } else if($vericek->kategori_tur == 2) {
            $this->load->view('kategori/gold-alim-satim', $data);
        } else {
            $this->load->view('kategori/index', $data);
        }
        $this->load->view('inc/_footer', $data);
    }

    public function sayfa($seo)
    {

        $data = new stdClass();


        $vericek = $this->home_model->sayfa(array("sayfa_seo" => $seo));


        if (empty($vericek->sayfa_title)) {
            $data->title = $vericek->sayfa_ad;
        } else {
            $data->title = $vericek->sayfa_title;
        }

        if (empty($vericek->sayfa_desc)) {
            $data->description = $vericek->sayfa_ad;
        } else {
            $data->description = $vericek->sayfa_desc;
        }

        if (empty($vericek->sayfa_keyw)) {
            $data->keywords = $vericek->sayfa_ad;
        } else {
            $data->keywords = $vericek->sayfa_keyw;
        }


        $data->where = $vericek;
        $data->ayarlar = ayarlar();
        $data->kullanici = kullanicicek();

        $this->load->view('inc/_header', $data);
        $this->load->view('sayfa/index', $data);
        $this->load->view('inc/_footer', $data);
    }

    public function iletisim()
    {

        $data = new stdClass();


        $siteayar = ayarlar();


        if (empty($siteayar->iletisim_baslik)) {
            $data->title = "";
        } else {
            $data->title = $siteayar->iletisim_baslik;
        }

        if (empty($siteayar->iletisim_aciklama)) {
            $data->description = "";
        } else {
            $data->description = $siteayar->iletisim_aciklama;
        }

        if (empty($siteayar->iletisim_keyw)) {
            $data->keywords = "";
        } else {
            $data->keywords = $siteayar->iletisim_keyw;
        }

        $data->ayarlar = $siteayar;
        $data->kullanici = kullanicicek();


        $this->load->view('inc/_header', $data);
        $this->load->view('iletisim/index', $data);
        $this->load->view('inc/_footer', $data);
    }

    public function sss()
    {

        $data = new stdClass();


        $siteayar = ayarlar();


        if (empty($siteayar->iletisim_baslik)) {
            $data->title = "";
        } else {
            $data->title = $siteayar->iletisim_baslik;
        }

        if (empty($siteayar->iletisim_aciklama)) {
            $data->description = "";
        } else {
            $data->description = $siteayar->iletisim_aciklama;
        }

        if (empty($siteayar->iletisim_keyw)) {
            $data->keywords = "";
        } else {
            $data->keywords = $siteayar->iletisim_keyw;
        }


        $data->ayarlar = $siteayar;
        $data->kullanici = kullanicicek();


        $this->load->view('inc/_header', $data);
        $this->load->view('sss/sss', $data);
        $this->load->view('inc/_footer', $data);
    }

    public function bloglar()
    {

        $data = new stdClass();
        $config = array();
        $config["base_url"] = base_url("blog");
        $config["total_rows"] = blogsay();
        $config["per_page"] = 12;
        $config["uri_segment"] = 3;

        //Pagenation Tasarım

        $config['first_link'] = '&laquo';
        $config['last_link'] = '&raquo';

        $config['full_tag_open'] = "<ul class='pagination justify-content-center'>";
        $config['full_tag_close'] = "</ul>";
        $config['num_tag_open'] = '<li class="page-item page-link">';
        $config['num_tag_close'] = '</li>';
        $config['cur_tag_open'] = '<li class="page-item active"><a class="page-link" href="#">';
        $config['cur_tag_close'] = "</a></li>";

        $config['next_link'] = 'İleri';
        $config['next_tag_open'] = '<li class="page-item page-link">';
        $config['next_tagl_close'] = "</li>";

        $config['prev_link'] = 'Geri';
        $config['prev_tag_open'] = '<li class="page-item page-link">';
        $config['prev_tagl_close'] = "</li>";

        $config['first_tag_open'] = '<li class="page-item page-link">';
        $config['first_tagl_close'] = "</li>";
        $config['last_tag_open'] = '<li class="page-item page-link">';
        $config['last_tagl_close'] = "</li>";


        $this->pagination->initialize($config);

        $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;

        $data->links = $this->pagination->create_links();

        $data->bloglar = $this->home_model->get_blog($config["per_page"], $page);

        $this->load->library("form_validation");

        $siteayar = ayarlar();
        $data->ayarlar = $siteayar;
        $data->kullanici = kullanicicek();
        $data->title = "Blog Yazıları";
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;


        $this->load->view('inc/_header', $data);
        $this->load->view('blog/index', $data);
        $this->load->view('inc/_footer');
    }

    public function blogdetay($seo)
    {

        $data = new stdClass();


        $vericek = $this->home_model->blogcek(array("blog_seo" => $seo));

        if (!$vericek) {
            redirect(base_url());
        }

        $siteayar = ayarlar();
        $data->ayarlar = $siteayar;
        $data->kullanici = kullanicicek();

        $data->title = $vericek->blog_ad;
        $data->description = substr(html_entity_decode(strip_tags($vericek->blog_detay)), 0, 300) . '...';
        $data->keywords = $siteayar->site_keyw;


        $data->where = $vericek;

        $this->load->view('inc/_header', $data);
        $this->load->view('blog/blogdetay', $data);
        $this->load->view('inc/_footer');
    }

    public function blogkategoridetay($seo)
    {

        $data = new stdClass();
        $vericek = blogkategoricek($seo);
        $config = array();

        $config["base_url"] = base_url("blog-kategori/" . $vericek->kategori_seo);
        $config["total_rows"] = kategoriblogsay($vericek->id);
        $config["per_page"] = 12;
        $config["uri_segment"] = 3;

        //Pagenation Tasarım

        $config['first_link'] = '&laquo';
        $config['last_link'] = '&raquo';

        $config['full_tag_open'] = "<ul class='pagination justify-content-center'>";
        $config['full_tag_close'] = "</ul>";
        $config['num_tag_open'] = '<li class="page-item page-link">';
        $config['num_tag_close'] = '</li>';
        $config['cur_tag_open'] = '<li class="page-item active"><a class="page-link" href="#">';
        $config['cur_tag_close'] = "</a></li>";

        $config['next_link'] = 'İleri';
        $config['next_tag_open'] = '<li class="page-item page-link">';
        $config['next_tagl_close'] = "</li>";

        $config['prev_link'] = 'Geri';
        $config['prev_tag_open'] = '<li class="page-item page-link">';
        $config['prev_tagl_close'] = "</li>";

        $config['first_tag_open'] = '<li class="page-item page-link">';
        $config['first_tagl_close'] = "</li>";
        $config['last_tag_open'] = '<li class="page-item page-link">';
        $config['last_tagl_close'] = "</li>";

        $this->pagination->initialize($config);

        $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;

        $data->links = $this->pagination->create_links();

        $data->bloglar = $this->home_model->kategori_get_blog($config["per_page"], $page, $vericek->id);


        if (!$vericek) {
            redirect(base_url());
        }

        $siteayar = ayarlar();
        $data->ayarlar = $siteayar;
        $data->kullanici = kullanicicek();

        $data->title = $vericek->kategori_ad;
        $data->description = $siteayar->site_aciklama;
        $data->keywords = $siteayar->site_keyw;


        $data->where = $vericek;

        $this->load->view('inc/_header', $data);
        $this->load->view('blog/blogkategori', $data);
        $this->load->view('inc/_footer');
    }

    //Çekiliş
    public function cekilisler()
    {
        $this->db->order_by('id', 'asc');
        $veriler = $this->db->where(['onay' => 1, 'status' => 0, 'end_date >=' => date('Y-m-d H:i:s')])->get('cekilis')->result();
        //$veriler = $this->db->where(['onay' => 1, 'status' => 0])->get('cekilis')->result();
        $kullanici = kullanicicek();

        foreach ($veriler as $key => $value) {
            $value->magaza = $this->db->where('magaza_id', $value->magaza_id)->get('magaza')->row();
            $value->esyalar = $this->db->where('cekilis_id', $value->id)->get('cekilis_item')->result();
            $value->katilimcisayi = $this->db->where('cekilis_id', $value->id)->from('cekilis_katilanlar')->count_all_results();
            $value->resim = $value->image;

            $katildimi = $this->db->where(
                [
                    'cekilis_id' => $value->id,
                    'katilan' => $kullanici->kullanici_id
                ])->get('cekilis_katilanlar')->row();
            if (isset($katildimi)) {
                $value->katildimi = true;
            } else {
                $value->katildimi = false;
            }

            foreach ($value->esyalar as $key => $esya) {

                $esya->urun_fiyat = $this->db->select('urun_fiyat')->where('urun_id', $esya->urun_id)->get('urunler')->row()->urun_fiyat;
                $esya->urun_resim = $this->db->select('urun_resim')->where('urun_id', $esya->urun_id)->get('urunler')->row()->urun_resim;

                $value->toplam_fiyat += ($esya->urun_fiyat) * $esya->urun_miktar;
                if ($esya->bakiye > 1) {
                    $value->toplam_fiyat += $esya->bakiye;
                    $esya->urun_resim = base_url('assets/images/gift.png');
                    $esya->bakiyem = true;
                    $esya->urun_fiyat = $esya->bakiye;
                }
            }
        }
        $sonaerenler = $this->db->where(['onay' => 1, 'status' => 1])->get('cekilis')->result();

        foreach ($sonaerenler as $key => $value) {
            $value->magaza = $this->db->where('magaza_id', $value->magaza_id)->get('magaza')->row();
            $value->esyalar = $this->db->where('cekilis_id', $value->id)->get('cekilis_item')->result();
            $value->katilimcisayi = $this->db->where('cekilis_id', $value->id)->from('cekilis_katilanlar')->count_all_results();
            $value->resim = $value->image;

            foreach ($value->esyalar as $key => $esya) {

                $esya->urun_fiyat = $this->db->select('urun_fiyat')->where('urun_id', $esya->urun_id)->get('urunler')->row()->urun_fiyat;
                $esya->urun_resim = $this->db->select('urun_resim')->where('urun_id', $esya->urun_id)->get('urunler')->row()->urun_resim;

                $value->toplam_fiyat += ($esya->urun_fiyat) * $esya->urun_miktar;
                if ($esya->bakiye > 1) {
                    $value->toplam_fiyat += $esya->bakiye;
                    $esya->urun_resim = base_url('assets/images/gift.png');
                    $esya->bakiyem = true;
                    $esya->urun_fiyat = $esya->bakiye;
                }
            }
        }

        $siteayar = ayarlar();

        $data = [
            'siteayar' => $siteayar,
            'kullanici' => kullanicicek(),
            'veriler' => $veriler,
            'sonaerenler' => $sonaerenler,
            'title' => "Çekilişler",
            'description' => "",
            'keywords' => "",
            'anasayfa' => true,
            'ayarlar' => ayarlar(),
            'kullanici' => kullanicicek(),
        ];


        $this->load->view('inc/_header', $data);
        $this->load->view('cekilis/index', $data);
        $this->load->view('inc/_footer');
    }

    public function cekilis_katil($id = null)
    {
        if ($id == null) {
            redirect(base_url('cekilisler'));
        }

        $cekilis = $this->db->where('id', $id)->get('cekilis')->row();
        $kullanici = kullanicicek();
        $cekiliskatilma = $this->db->where(['cekilis_id' => $id, 'katilan' => $kullanici->kullanici_id])->get('cekilis_katilanlar')->row();

        if (!$kullanici) {
            $this->session->set_flashdata("alert", [
                "title" => "Hata!",
                "text" => "Çekilişe katılmak için giriş yapmalısınız.",
                "type" => "error"
            ]);
            return redirect(base_url('cekilisler'));
        }

        if ($cekiliskatilma) {
            $this->session->set_flashdata("alert", [
                "title" => "Hata!",
                "text" => "Bu çekilişe zaten katıldınız.",
                "type" => "error"
            ]);
            return redirect(base_url('cekilisler'));
        }

        if (!$cekilis) {
            $this->session->set_flashdata("alert", [
                "title" => "Hata!",
                "text" => "Böyle bir çekiliş bulunamadı.",
                "type" => "error"
            ]);
            return redirect(base_url('cekilisler'));
        }

        $data = [
            'cekilis_id' => $cekilis->id,
            'katilan' => $kullanici->kullanici_id,
            'katilma_tarihi' => date('Y-m-d H:i:s')
        ];

        $this->db->insert('cekilis_katilanlar', $data);

        $this->session->set_flashdata("alert", [
            "title" => "Başarılı!",
            "text" => "Çekilişe başarıyla katıldınız.",
            "type" => "success"
        ]);

        return redirect(base_url('cekilisler'));
    }

    public function cekilisdetay($id = null)
    {
        $cekilis = $this->db->where('id', $id)->get('cekilis')->row();

        if (!$cekilis) {
            $this->session->set_flashdata("alert", [
                "title" => "Hata!",
                "text" => "Böyle bir çekiliş bulunamadı.",
                "type" => "error"
            ]);
            return redirect(base_url('cekilisler'));
        }

        $cekilis->magaza = $this->db->where('magaza_id', $cekilis->magaza_id)->get('magaza')->row();
        $cekilis->esyalar = $this->db->where('cekilis_id', $cekilis->id)->get('cekilis_item')->result();
        $cekilis->katilimcisayi = $this->db->where('cekilis_id', $cekilis->id)->from('cekilis_katilanlar')->count_all_results();

        foreach ($cekilis->esyalar as $key => $esya) {
            $esya->urun_fiyat = $this->db->select('urun_fiyat')->where('urun_id', $esya->urun_id)->get('urunler')->row()->urun_fiyat;
            $esya->urun_resim = $this->db->select('urun_resim')->where('urun_id', $esya->urun_id)->get('urunler')->row()->urun_resim;
            $cekilis->toplam_fiyat += ($esya->urun_fiyat) * $esya->urun_miktar;

            if ($esya->bakiye > 1) {
                $cekilis->toplam_fiyat += $esya->bakiye;
                $esya->urun_resim = base_url('assets/images/gift.png');
                $esya->bakiyem = true;
                $esya->urun_fiyat = $esya->bakiye;
            }
        }

        //çekiliş kazananlar
        if ($cekilis->status == 1) {
            $cekilis->kazananlar = $this->db->where('cekilis_id', $cekilis->id)->get('cekilis_kazananlar')->result();
            // bir kullanıcıyı bir kere kayıt etmek için

            foreach ($cekilis->kazananlar as $kullanici) {
                $kullanici->kullanici = $this->db->where('kullanici_id', $kullanici->kullanici_id)->get('kullanici')->row();
            }
        }

        $kullanici = kullanicicek();
        $katildimi = $this->db->where(
            [
                'cekilis_id' => $cekilis->id,
                'katilan' => $kullanici->kullanici_id
            ]
        )->get('cekilis_katilanlar')->row();
        if (isset($katildimi)) {
            $cekilis->katildimi = true;
        } else {
            $cekilis->katildimi = false;
        }


        $siteayar = ayarlar();


        $data = [
            'ayarlar' => ayarlar(),
            'kullanici' => kullanicicek(),
            'title' => $cekilis->title . ' - ' . $siteayar->site_ad,
            'description' => $siteayar->site_aciklama,
            'keywords' => $siteayar->site_keyw,
            'cekilis' => $cekilis,
        ];

        $this->load->view('inc/_header', $data);
        $this->load->view('cekilis/detay', $data);
        $this->load->view('inc/_footer');
    }


    public function cekiliskontrol()
    {
        $cekilisler = $this->db->where(['status' => 0, 'onay' => 1])->get('cekilis')->result();
        foreach ($cekilisler as $cekilis) {
            // çekiliş bitiş tarihi sorgulama
            if (strtotime($cekilis->end_date) < strtotime(date('Y-m-d H:i:s'))) {
                $this->cekilis_sonuc($cekilis->id);
            }
        }
    }

    public function cekilis_sonuc($id = null)
    {
        $cekilis = $this->db->where('id', $id)->get('cekilis')->row();

        if (!$cekilis) {
            exit;
        }

        $cekilis->magaza = $this->db->where('magaza_id', $cekilis->magaza_id)->get('magaza')->row();
        $cekilis->esyalar = $this->db->where('cekilis_id', $cekilis->id)->get('cekilis_item')->result();
        $cekilis->katilimcisayi = $this->db->where('cekilis_id', $cekilis->id)->from('cekilis_katilanlar')->count_all_results();
        //$kazananlar = $this->db->where('cekilis_id', $cekilis->id)->order_by('id', 'RANDOM')->limit($cekilis->winner_count)->get('cekilis_katilanlar')->result();
        $winners = []; // Kazananları depolamak için dizi
        while (count($winners) < $cekilis->winner_count) {
            // Rastgele bir kazanan seç
            $winner = $this->db->where('cekilis_id', $cekilis->id)
                ->order_by('id', 'RANDOM')
                ->limit(1)
                ->get('cekilis_katilanlar')
                ->row();
            // Eğer seçilen kullanıcı daha önce kazanmadıysa diziye ekle
            if ($winner && !in_array($winner->katilan, $winners)) {
                $winners[] = $winner->katilan;
            }
        }
        $w_count = 0;
        foreach ($cekilis->esyalar as $key => $esya) {
            for ($i = 0; $i < $esya->urun_miktar; $i++) {
                if ($winners[$w_count]) {
                    $kazanan_kisi = $winners[$w_count];
                } else {
                    //$kazanan_kisi = array_rand($winners, 1);
                }
                if ($esya->bakiye > 0) {
                    $cekilis->urunler[] = [
                        'bakiye' => 1,
                        'bakiyemiktar' => $esya->bakiye,
                        'kazanan' => $kazanan_kisi,
                    ];
                } else {
                    //$cekilis->urunler[] = $esya->urun_id;
                    $cekilis->urunler[] = [
                        'urun' => $esya->urun_id,
                        'kazanan' => $kazanan_kisi,
                    ];
                }
                $w_count++;
            }
        }
        foreach ($cekilis->urunler as $key => $value) {
            $kazanan = $this->db->where(['katilan' => $value['kazanan'], 'cekilis_id' => $cekilis->id])->get('cekilis_katilanlar')->row();
            //$kazanan = $this->db->where('cekilis_id', $cekilis->id)->order_by('id', 'RANDOM')->limit(1)->get('cekilis_katilanlar')->row();
            $kazanan->kullanici = $this->db->where('kullanici_id', $kazanan->katilan)->get('kullanici')->row();
            $kazanan->urun_id = $value['urun'];
            if ($value['bakiyemiktar'] > 1) {
                $this->db->update('kullanici', ['bakiye' => $kazanan->kullanici->bakiye + $value['bakiyemiktar']], ['kullanici_id' => $kazanan->kullanici->kullanici_id]);
            } else {
                $urun = $this->db->where('urun_id', $value['urun'])->get('urunler')->row();
            }

            if ($urun->turkpin == 2) { //Türk pin ile teslimat eğer bakiye yokise key havuzundan kullanacak
                $api = new Turkpin('agentsunucu@gmail.com', 'Mehmet.3434');
                $uretken = uretken(10);
                try {
                    $epinOrder = $api->epinOrder($urun->epin_id, $urun->product_id);

                    $this->db->insert('siparis', [
                        'kullanici_id' => $kazanan->kullanici->kullanici_id,
                        'magaza' => $urun->magaza_id,
                        'urun_id' => $urun->urun_id,
                        'siparis_tutar' => $urun->urun_fiyat,
                        'siparis_ad' => $kazanan->kullanici->kullanici_isim,
                        'siparis_soyad' => $kazanan->kullanici->kullanici_soyisim,
                        'siparis_tel' => $kazanan->kullanici->kullanici_tel,
                        'siparis_no' => $uretken,
                        'siparis_durum' => 1,
                        'siparis_tarih' => date('Y-m-d H:i:s'),
                        'turkpin' => 2,
                        'order_no' => $epinOrder['order_no'],
                        'epin_id' => $urun->epin_id,
                        'product_id' => $urun->product_id,
                        'siparis_key' => $epinOrder['order_no'][0]['code'],
                        'siparis_epin' => 1,

                    ]);

                    $this->db->insert('cekilis_kazananlar', [
                        'cekilis_id' => $kazanan->cekilis_id,
                        'kullanici_id' => $kazanan->kullanici->kullanici_id,
                        'urun_id' => $urun->urun_id,
                        'tarih' => date('Y-m-d H:i:s'),
                    ]);
                } catch (\Exception $e) {
                    $havuzkey = $this->db->where(['status' => 0, 'urun_id' => $urun->urun_id])->get('stock')->row();

                    if ($havuzkey) {
                        $this->db->where('id', $havuzkey->id)->update('stock', [
                            'status' => 1,
                            'seller' => $kazanan->kullanici->kullanici_id,
                        ]);

                        $this->db->insert('siparis', [
                            'kullanici_id' => $kazanan->kullanici->kullanici_id,
                            'magaza' => $urun->magaza_id,
                            'urun_id' => $urun->urun_id,
                            'siparis_tutar' => $urun->urun_fiyat,
                            'siparis_ad' => $kazanan->kullanici->kullanici_isim,
                            'siparis_soyad' => $kazanan->kullanici->kullanici_soyisim,
                            'siparis_tel' => $kazanan->kullanici->kullanici_tel,
                            'siparis_no' => $uretken,
                            'siparis_durum' => 1,
                            'siparis_tarih' => date('Y-m-d H:i:s'),
                            'turkpin' => 1,
                            'siparis_key' => $havuzkey->key,
                            'siparis_epin' => 1,

                        ]);

                        $this->db->insert('cekilis_kazananlar', [
                            'cekilis_id' => $kazanan->cekilis_id,
                            'kullanici_id' => $kazanan->kullanici->kullanici_id,
                            'urun_id' => $urun->urun_id,
                            'tarih' => date('Y-m-d H:i:s'),
                        ]);
                    } else {

                        $this->db->insert('siparis', [
                            'kullanici_id' => $kazanan->kullanici->kullanici_id,
                            'magaza' => $urun->magaza_id,
                            'urun_id' => $urun->urun_id,
                            'siparis_tutar' => $urun->urun_fiyat,
                            'siparis_ad' => $kazanan->kullanici->kullanici_isim,
                            'siparis_soyad' => $kazanan->kullanici->kullanici_soyisim,
                            'siparis_tel' => $kazanan->kullanici->kullanici_tel,
                            'siparis_no' => $uretken,
                            'siparis_durum' => 1,
                            'siparis_tarih' => date('Y-m-d H:i:s'),
                            'siparis_epin' => 2,
                        ]);

                        $this->db->insert('cekilis_kazananlar', [
                            'cekilis_id' => $kazanan->cekilis_id,
                            'kullanici_id' => $kazanan->kullanici->kullanici_id,
                            'urun_id' => $urun->urun_id,
                            'tarih' => date('Y-m-d H:i:s'),
                        ]);
                    }
                }
            } else {
                $havuzkey = $this->db->where(['status' => 0, 'urun_id' => $urun->urun_id])->get('stock')->row();
                $uretken = uretken(10);
                if ($havuzkey) {
                    $this->db->where('id', $havuzkey->id)->update('stock', [
                        'status' => 1,
                        'seller' => $kazanan->kullanici->kullanici_id,
                    ]);

                    $this->db->insert('siparis', [
                        'kullanici_id' => $kazanan->kullanici->kullanici_id,
                        'magaza' => $urun->magaza_id,
                        'urun_id' => $urun->urun_id,
                        'siparis_tutar' => $urun->urun_fiyat,
                        'siparis_ad' => $kazanan->kullanici->kullanici_isim,
                        'siparis_soyad' => $kazanan->kullanici->kullanici_soyisim,
                        'siparis_tel' => $kazanan->kullanici->kullanici_tel,
                        'siparis_no' => $uretken,
                        'siparis_durum' => 1,
                        'siparis_tarih' => date('Y-m-d H:i:s'),
                        'turkpin' => 1,
                        'siparis_key' => $havuzkey->key,
                        'siparis_epin' => 1,

                    ]);

                    $this->db->insert('cekilis_kazananlar', [
                        'cekilis_id' => $kazanan->cekilis_id,
                        'kullanici_id' => $kazanan->kullanici->kullanici_id,
                        'urun_id' => $urun->urun_id,
                        'tarih' => date('Y-m-d H:i:s'),
                    ]);
                } else {

                    $this->db->insert('siparis', [
                        'kullanici_id' => $kazanan->kullanici->kullanici_id,
                        'magaza' => $urun->magaza_id,
                        'urun_id' => $urun->urun_id,
                        'siparis_tutar' => $urun->urun_fiyat,
                        'siparis_ad' => $kazanan->kullanici->kullanici_isim,
                        'siparis_soyad' => $kazanan->kullanici->kullanici_soyisim,
                        'siparis_tel' => $kazanan->kullanici->kullanici_tel,
                        'siparis_no' => $uretken,
                        'siparis_durum' => 1,
                        'siparis_tarih' => date('Y-m-d H:i:s'),
                        'siparis_epin' => 2,
                    ]);

                    $this->db->insert('cekilis_kazananlar', [
                        'cekilis_id' => $kazanan->cekilis_id,
                        'kullanici_id' => $kazanan->kullanici->kullanici_id,
                        'urun_id' => $urun->urun_id,
                        'tarih' => date('Y-m-d H:i:s'),
                    ]);
                }
            }
            //unset($cekilis->urunler[$key]);
            $this->db->where('id', $cekilis->id)->update('cekilis', [
                'status' => 1,
            ]);
        }

        //Urun teslim kısmı buraya

        die;
    }

    //Çekiliş Oluştur
    public function cekilis_olustur()
    {
        if (!aktif_kullanici()) {
            redirect(base_url('giris-yap'));
        }
        if (!magaza_check()) {
            redirect(base_url('magaza-olustur'));
        }
        $data = new stdClass();

        $data = [
            'ayarlar' => ayarlar(),
            'kullanici' => kullanicicek(),
            'magaza' => $this->db->get('magaza')->result(),
            'urunler' => $this->db->get('urunler')->result(),
        ];

        $this->load->view('inc/_header', $data);
        $this->load->view('cekilis/olustur', $data);
        $this->load->view('inc/_footer');
    }

    public function cekilis_baslat()
    {
        $kullaniciid = aktif_kullanici();
        $kullanici = $this->db->where('kullanici_id', $kullaniciid->kullanici_id)->get('kullanici')->row();

        $magaza = $this->db->where('kullanici_id', $kullanici->kullanici_id)->get('magaza')->row();

        $data = [
            'title' => $this->input->post('title'),
            'aciklama' => $this->input->post('aciklama'),
            'end_date' => $this->input->post('bitis_tarihi'),
            'magaza_id' => $magaza->magaza_id,
            'turu' => $this->input->post('cekilis_turu'),
            'winner_count' => $this->input->post('winner_count'),
        ];

        $file_name = seo(pathinfo($_FILES["file"]["name"], PATHINFO_FILENAME)) . "." . pathinfo($_FILES["file"]["name"], PATHINFO_EXTENSION);
        $sifrele = uniqid();
        $config["allowed_types"] = "png|jpg|jpeg|webp";
        $config["upload_path"] = "uploads/img/";
        $config["file_name"] = $sifrele . "_" . $file_name;

        $this->load->library("upload", $config);

        $upload = $this->upload->do_upload("file");
        if ($upload) {
            $uploaded_file = $this->upload->data("file_name"); // dosya adı
            $data["image"] = "uploads/img/" . $uploaded_file;
        }

        //Boşlukları kontrol et
        foreach ($data as $key => $value) {
            if (empty($value)) {
                $this->session->set_flashdata("alert", [
                    "title" => "Hata!",
                    "message" => "Lütfen tüm alanları doldurunuz.",
                    "type" => "error",
                ]);
                redirect(base_url("cekilis/olustur"));
            }
        }

        $esyalar = $this->input->post('urunler');
        $bakiye = $this->input->post('bakiye');

        $toplamtutar = 0;
        $toplamadet = 0;

        foreach ($esyalar as $key => $value) {
            $urun = $this->db->where('urun_id', $value)->get('urunler')->row();

            $toplamadet += $this->input->post('miktar')[$key];

            $toplamtutar += $urun->urun_fiyat * $this->input->post('miktar')[$key];


            $stok = $urun->urun_stok;

            if ($stok < $this->input->post('miktar')[$key]) {
                $this->session->set_flashdata("alert", [
                    "title" => "Hata!",
                    "text" => "Stokta Yeterli Ürün Yok",
                    "type" => "error"
                ]);
                return redirect(base_url('cekilis/olustur'));
            }
        }


        foreach ($bakiye as $key => $value) {
            $toplamtutar += $value;
        }

        if ($toplamtutar < 1) {
            $this->session->set_flashdata("alert", [
                "title" => "Hata!",
                "text" => "Lütfen ürün Giriniz",
                "type" => "error"
            ]);
            return redirect(base_url('cekilis/olustur'));
        }

        if ($kullanici->bakiye < $toplamtutar) {
            $this->session->set_flashdata("alert", [
                "title" => "Hata!",
                "text" => "Yetersiz Bakiye",
                "type" => "error"
            ]);
            return redirect(base_url('cekilis/olustur'));
        }
        if (!empty($esyalar)) {
            if ($this->input->post('winner_count') > count($esyalar)) {
                $this->session->set_flashdata("alert", [
                    "title" => "Hata!",
                    "text" => "Kazanan Sayısı Ürün Sayısından Büyük Olamaz",
                    "type" => "error"
                ]);
                return redirect(base_url('cekilis/olustur'));
            } else if (count($esyalar) > $this->input->post('winner_count')) {
                $this->session->set_flashdata("alert", [
                    "title" => "Hata!",
                    "text" => "Ürün Sayısı Kazanan Sayısından Büyük Olamaz",
                    "type" => "error"
                ]);
                return redirect(base_url('cekilis/olustur'));
            }
        }
        if (!empty($bakiye)) {
            if ($this->input->post('winner_count') > count($bakiye)) {
                $this->session->set_flashdata("alert", [
                    "title" => "Hata!",
                    "text" => "Kazanan Sayısı Ürün Sayısından Büyük Olamaz",
                    "type" => "error"
                ]);
                return redirect(base_url('cekilis/olustur'));
            } else if (count($bakiye) > $this->input->post('winner_count')) {
                $this->session->set_flashdata("alert", [
                    "title" => "Hata!",
                    "text" => "Ürün Sayısı Kazanan Sayısından Büyük Olamaz",
                    "type" => "error"
                ]);
                return redirect(base_url('cekilis/olustur'));
            }
        }

        $this->db->where('kullanici_id', $kullanici->kullanici_id)->update('kullanici', ['bakiye' => $kullanici->bakiye - $toplamtutar]);

        $this->db->insert('cekilis', $data);
        $cekilis_id = $this->db->insert_id();

        foreach ($bakiye as $key => $value) {
            $data = [
                'cekilis_id' => $cekilis_id,
                'bakiye' => $value,
                'urun_id' => -1,
                'urun_miktar' => 1,
            ];

            $this->db->insert('cekilis_item', $data);
        }

        foreach ($esyalar as $key => $value) {
            $data = [
                'cekilis_id' => $cekilis_id,
                'urun_id' => $value,
                'urun_miktar' => $this->input->post('miktar')[$key],
            ];

            $urun = $this->db->where('urun_id', $value)->get('urunler')->row();
            $this->db->where('urun_id', $value)->update('urunler', [
                'urun_stok' => $urun->urun_stok - $this->input->post('miktar')[$key]
            ]);

            $this->db->insert('cekilis_item', $data);
        }

        $this->session->set_flashdata("alert", [
            "title" => "Başarılı!",
            "text" => "Çekiliş başarıyla oluşturuldu",
            "type" => "success"
        ]);

        return redirect(base_url('cekilis/olustur'));
    }

    function bayimiz_olun()
    {
        if (!aktif_kullanici()) {
            redirect(base_url('giris-yap'));
        }
        $data = new stdClass();
        $data->title = "Bayimiz Olun";
        $data->description = "";
        $data->keywords = "";
        $data->anasayfa = true;
        $data->ayarlar = ayarlar();
        $data->kullanici = kullanicicek();
        $data->basvuru_durum = $this->home_model->basvuru_durum($data->kullanici->kullanici_id);
        $this->load->view('inc/_header', $data);
        $this->load->view('bayi_basvuru/index', $data);
        $this->load->view('inc/_footer');
    }

    function basvuru_formu_gonder()
    {
        if (!$_POST) {
            redirect(base_url());
        }
        if (!aktif_kullanici()) {
            redirect(base_url('giris-yap'));
        }
        $data = $_POST;
        if ($this->home_model->basvuru_olustur($data)) {
            redirect(base_url('bayimiz-olun'));
        } else {
            redirect(base_url('bayimiz-olun?error=hata'));
        }
    }

    //Kateogiriler

    public function kategoriler()
    {
        $data = new stdClass();


        $data->title = "Tüm Kategoriler";
        $data->description = "";
        $data->keywords = "";
        $data->anasayfa = true;
        $data->ayarlar = ayarlar();
        $data->kullanici = kullanicicek();
        $data->kategoriler = $this->db->where('parent', 0)->where('kategori_durum', 1)->order_by('kategori_sira', 'ASC')->get('kategori')->result();

        $this->load->view('inc/_header', $data);
        $this->load->view('kategori/liste', $data);
        $this->load->view('inc/_footer');
    }

    public function kategorilerdetay($seo = null)
    {
        $data = new stdClass();

        $data->title = "Tüm Kategoriler";
        $data->description = "";
        $data->keywords = "";
        $data->anasayfa = true;
        $data->ayarlar = ayarlar();
        $data->kullanici = kullanicicek();
        $kategori = $this->db->where('kategori_seo', $seo)->get('kategori')->row();
        $data->kategoriler = $this->db->where('parent', $kategori->kategori_id)->order_by('kategori_sira', 'ASC')->get('kategori')->result();
        $data->kategori = $kategori;

        $data->title = $kategori->kategori_title;
        $data->description = $kategori->kategori_desc;
        $data->keywords = $kategori->kategori_keyw;

        $this->load->view('inc/_header', $data);
        $this->load->view('kategori/liste', $data);
        $this->load->view('inc/_footer');
    }

    private function ust_kategoriler($parent_id, $list = array())
    {
        $ust_kategori = $this->db->where('kategori_id', $parent_id)->get('kategori')->row();
        array_push($list, $ust_kategori);
        if ($ust_kategori->parent) {
            return $this->ust_kategoriler($ust_kategori->parent, $list);
        }
        return $list;
    }

    //Türkpn
    public function turkpin_kategori_post()
    {
        $api = new Turkpin('agentsunucu@gmail.com', 'Mehmet.3434');

        $response = array(
            'status' => 'success',
            'message' => 'Veri başarıyla geldi',
            'epinlist' => $api->epinList(),
        );

        $this->output
            ->set_content_type('application/json')
            ->set_output(json_encode($response));
    }

    public function turkpin_urun_post()
    {
        $api = new Turkpin('agentsunucu@gmail.com', 'Mehmet.3434');

        $epin_id = $this->input->post('epin_id');

        $response = array(
            'status' => 'success',
            'message' => 'Veri başarıyla geldi',
            'epinlist' => $api->epinProducts($epin_id),
        );

        $this->output
            ->set_content_type('application/json')
            ->set_output(json_encode($response));
    }

    public function cron_siparis_onayla()
    {
        error_reporting(E_ALL);
        ini_set("display_errors", 1);

        $get_siparsiler = $this->home_model->get_onaylanacak_siparisler();

        foreach ($get_siparsiler as $key => $val) {
            if (empty($this->home_model->siparis_teslimat_control($val->siparis_no))) {
                $magaza_bilgi = magaza_bilgi($val->magaza);
                $satici_bilgi = kullanici_bilgi($magaza_bilgi->kullanici_id);

                $kategori_id = json_decode($val->kategori_json)[0];

                $category = $this->home_model->kategoricek(array('kategori_id' => $kategori_id));

                $komisyon_tutar = kategori_komisyon_hesap($val->siparis_tutar, $category->komisyon);

                $satici_odenecek_tutar = $val->siparis_tutar - $komisyon_tutar;
                $satici_odenecek_tutar = number_format($satici_odenecek_tutar, 2);

                $satici_arr = [
                    'bakiye' => number_format($satici_bilgi->bakiye + $satici_odenecek_tutar, 2)
                ];

                $this->siparis_model->update_bakiye(array('kullanici_id' => $satici_bilgi->kullanici_id), $satici_arr);
                $this->siparis_model->siparis_update(array('siparis_no' => $val->siparis_no), array('siparis_durum' => 2));
            } else {
                continue;
            }
        }
        echo 'Siparişler başarılı bir şekilde teslim edildi.';
    }

    public function banka_getir()
    {
        if (!aktif_kullanici()) {
            echo json_encode(array('status' => false));
            die();
        }
        if (!$_POST) {
            echo json_encode(array('status' => false));
            die();
        }

        $banka_id = $this->input->post('banka');

        if ($banka = $this->home_model->get_banka($banka_id)) {
            echo json_encode(array('status' => true, 'banka' => $banka));
        }
    }

    public function pvp_servers()
    {
        $data = new stdClass();

        $data->title = "Tüm Kategoriler";
        $data->description = "";
        $data->keywords = "";
        $data->anasayfa = true;
        $data->ayarlar = ayarlar();
        $data->kullanici = kullanicicek();

        $data->servers = $this->home_model->get_pvp_servers();

        $this->load->view('inc/_header', $data);
        $this->load->view('auth/pvp-tasarim', $data);
        $this->load->view('inc/_footer');
    }

    public function bize_sat_urun_kontrol($urun)
    {
        if (!aktif_kullanici()) {
            echo json_encode(array('status' => false));
            die();
        }
        if (!$_POST) {
            echo json_encode(array('status' => false));
            die();
        }

        if ($db_urun = $this->home_model->get_urun($urun)) {
            echo json_encode(array('status' => true, 'urun' => $db_urun));
        } else {
            echo json_encode(array('status' => false));
            die();
        }
    }

    public function bize_sat_ekle($type, $urun)
    {
        if (!$user = aktif_kullanici()) {
            echo json_encode(array('status' => false, 'message' => 'Lütfen Giriş Yapınız'));
            die();
        }
        if (!$_POST) {
            echo json_encode(array('status' => false, 'message' => 'Yaptığınız İşlem Geçerli Değildir.'));
            die();
        }
        $qty = $this->input->post('qty', true);
        $urun_id = $urun;
        $character = $this->input->post('character', true);
        $gold_type = $type;

        if (empty($qty) || empty($urun_id) || empty($character)) {
            echo json_encode(array('status' => false, 'message' => 'Lütfen Hiç Bir Alanı Boş Bırakmayınız.'));
            die();
        }

        if ($gold_type == 1) {
            //siteye satış
            if (!$this->home_model->control_bize_sat($user->kullanici_id)) {
                if ($db_urun = $this->home_model->get_urun($urun)) {
                    if ($db_urun->urun_alim_stok <= 0) {
                        echo json_encode(array('status' => false, 'message' => 'Satış İçin Stoklarımız Dolmuştur. Lütfen Daha Sonra Tekrar Deneyiniz...'));
                        die();
                    }
                    if ($db_urun->urun_alim_stok < $qty) {
                        echo json_encode(array('status' => false, 'message' => 'Satılabilir Stok : '.$db_urun->urun_alim_stok));
                        die();
                    }

                    $uretken = uretken(10);
                    $arr = [
                        'urun_id' => $urun_id,
                        'user_id' => $user->kullanici_id,
                        'quantity' => $qty,
                        'price' => $db_urun->urun_alimfiyat * $qty,
                        'character_name' => $character,
                        'siparis_no' => $uretken,
                        'type' => $gold_type,
                        'added_time' => date('Y-m-d H:i:s')
                    ];
                    $this->home_model->bizesatadd($arr);
                    echo json_encode(array('status' => true, 'message' => 'Satış Siparişi Başarıyla Oluşturuldu. Yönlendiriliyorsunuz.', 'url' => 'https://kemalellidort.com.tr/satislar'));
                } else {
                    echo json_encode(array('status' => false, 'message' => 'Yaptığınız İşlem Geçerli Değildir.'));
                    die();
                }
            } else {
                echo json_encode(array('status' => false, 'message' => 'Bekleyen Satış Siparişiniz Bulunmaktadır Lütfen Teslim Ediniz...'));
                die();
            }
        } else if ($gold_type == 2) {
            //siteden alım
            if ($db_urun = $this->home_model->get_urun($urun)) {
                if ($user->bakiye < ($db_urun->urun_fiyat * $qty)) {
                    echo json_encode(array('status' => false, 'message' => 'Bakiyeniz Yetersizdir. Lütfen Bakiye Yükleyiniz...'));
                    die();
                }
                if ($db_urun->urun_stok <= 0) {
                    echo json_encode(array('status' => false, 'message' => 'Yeterli Stok Bulunmamaktadır. Lütfen Daha Sonra Tekrar Deneyiniz...'));
                    die();
                }
                if ($db_urun->urun_stok < $qty) {
                    echo json_encode(array('status' => false, 'message' => 'Yeterli Stok Bulunmamaktadır. Stok : '.$db_urun->urun_stok));
                    die();
                }

                $this->db->where('kullanici_id', $user->kullanici_id)->update('kullanici', [
                    'bakiye' => $user->bakiye - ($db_urun->urun_fiyat * $qty)
                ]);

                $uretken = uretken(10);
                $arr = [
                    'urun_id' => $urun_id,
                    'user_id' => $user->kullanici_id,
                    'quantity' => $qty,
                    'price' => $db_urun->urun_fiyat * $qty,
                    'character_name' => $character,
                    'siparis_no' => $uretken,
                    'type' => $gold_type,
                    'added_time' => date('Y-m-d H:i:s')
                ];
                $this->home_model->bizesatadd($arr);
                echo json_encode(array('status' => true, 'message' => 'Siparişiniz Başarılı Şekilde Alınmıştır. Yönlendiriliyorsunuz.', 'url' => 'https://kemalellidort.com.tr/satislar'));
            } else {
                echo json_encode(array('status' => false, 'message' => 'Yaptığınız İşlem Geçerli Değildir.'));
                die();
            }
        } else {
            echo json_encode(array('status' => false, 'message' => 'Yapmaya Çalıştığınız İşlem Geçersizdır!!'));
            die();
        }
    }

    public function get_excel()
    {
        $data = $this->home_model->get_excel_users();

        // Excel dosyasını oluştur
        $filename = 'users.csv';

        // Dosyayı yazma modunda aç
        $file = fopen($filename, 'w');

        // Başlık satırını yaz
        fputcsv($file, array('ID', 'Kullanıcı Adı', 'Telefon'));

        // Veritabanı sonuçlarını Excel dosyasına yaz
        foreach ($data as $row) {
            fputcsv($file, array($row->kullanici_id, $row->kullanici_ad, $row->kullanici_tel));
        }

        // Dosyayı kapat
        fclose($file);

        // Dosyayı indirme işlemi
        header('Content-Type: application/csv');
        header('Content-Disposition: attachment;filename="'. $filename .'"');
        header('Cache-Control: max-age=0');

        readfile($filename);
        exit;
    }

    public function bakim_modu()
    {
        $this->load->view('bakim_modu');
    }


}
